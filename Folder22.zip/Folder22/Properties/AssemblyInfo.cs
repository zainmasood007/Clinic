using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: Guid("cd1e0b03-f563-4d0c-9d73-91dd1a8f8a9c")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyTitle("DentistClinic")]
[assembly: ComVisible(false)]
[assembly: AssemblyCopyright("Copyright ©  2012")]
[assembly: AssemblyProduct("DentistClinic")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyVersion("1.0.0.0")]
