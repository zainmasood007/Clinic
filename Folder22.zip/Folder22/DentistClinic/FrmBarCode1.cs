using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.IO;
using System.Windows.Forms;
using ComponentAce.Barcoding;
using DentistClinic.Properties;
using NumericText;

namespace DentistClinic
{
	public class FrmBarCode1 : BaseForm
	{
		private struct ImageBarcode
		{
			public string Barcode;

			public string Header;

			public string ItemName;

			public byte[] Photo;

			public int BCount;

			public string Price;
		}

		private IContainer components = null;

		private BarcodeLabel barcodeLabel;

		private TextBox valueTextBox;

		private Label label2;

		private Label label3;

		private TextBox xDimensionTextBox;

		private TextBox wideToNarrowRatioTextBox;

		private Label label4;

		private Label label5;

		private ComboBox symbologyComboBox;

		private ComboBox smoothingModeComboBox;

		private Label label7;

		private CheckBox includeTextCheckBox;

		private CheckBox includeCheckSumCheckBox;

		private Button textFontButton;

		private FontDialog textFontDialog;

		private Label label8;

		private ComboBox sizingComboBox;

		private Label label9;

		private TextBox topMarginTextBox;

		private Label label10;

		private Label label11;

		private TextBox leftMarginTextBox;

		private Label label13;

		private TextBox rightMarginTextBox;

		private TextBox bottomMarginTextBox;

		private Label label14;

		private ComboBox angleComboBox;

		private Button printButton;

		private PrintDocument printDocument;

		private Label label12;

		private Label label15;

		private ComboBox unitsComboBox;

		private Label label16;

		private TextBox barcodeWidthTextBox;

		private Label label17;

		private TextBox barcodeHeightTextBox;

		private Label label18;

		private Button SaveButton;

		private SaveFileDialog saveFileDialog;

		private TextBox errorTextBox;

		private TextBox textBox1;

		private Button button1;

		private TextBox textBox2;

		private PictureBox pictureBox1;

		private Label label1;

		private Label label6;

		private BarcodeLabel barcodeLabel1;

		private GroupBox groupBox1;

		private Label label19;

		private ComboBox comboBox3;

		private Label label20;

		private TextBox textBox3;

		private Label label21;

		private Panel panel1;

		private global::NumericText.NumericText textBox4;

		private CheckBox checkBox1;

		private Label label22;

		private TextBox textBox5;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private GraphicsUnit units = GraphicsUnit.Pixel;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmBarCode1));
			valueTextBox = new System.Windows.Forms.TextBox();
			label2 = new System.Windows.Forms.Label();
			label3 = new System.Windows.Forms.Label();
			xDimensionTextBox = new System.Windows.Forms.TextBox();
			wideToNarrowRatioTextBox = new System.Windows.Forms.TextBox();
			label4 = new System.Windows.Forms.Label();
			label5 = new System.Windows.Forms.Label();
			symbologyComboBox = new System.Windows.Forms.ComboBox();
			smoothingModeComboBox = new System.Windows.Forms.ComboBox();
			label7 = new System.Windows.Forms.Label();
			includeTextCheckBox = new System.Windows.Forms.CheckBox();
			includeCheckSumCheckBox = new System.Windows.Forms.CheckBox();
			textFontButton = new System.Windows.Forms.Button();
			textFontDialog = new System.Windows.Forms.FontDialog();
			label8 = new System.Windows.Forms.Label();
			sizingComboBox = new System.Windows.Forms.ComboBox();
			label9 = new System.Windows.Forms.Label();
			topMarginTextBox = new System.Windows.Forms.TextBox();
			label10 = new System.Windows.Forms.Label();
			label11 = new System.Windows.Forms.Label();
			leftMarginTextBox = new System.Windows.Forms.TextBox();
			label13 = new System.Windows.Forms.Label();
			rightMarginTextBox = new System.Windows.Forms.TextBox();
			bottomMarginTextBox = new System.Windows.Forms.TextBox();
			label14 = new System.Windows.Forms.Label();
			angleComboBox = new System.Windows.Forms.ComboBox();
			printButton = new System.Windows.Forms.Button();
			printDocument = new System.Drawing.Printing.PrintDocument();
			label12 = new System.Windows.Forms.Label();
			label15 = new System.Windows.Forms.Label();
			unitsComboBox = new System.Windows.Forms.ComboBox();
			label16 = new System.Windows.Forms.Label();
			barcodeWidthTextBox = new System.Windows.Forms.TextBox();
			label17 = new System.Windows.Forms.Label();
			barcodeHeightTextBox = new System.Windows.Forms.TextBox();
			label18 = new System.Windows.Forms.Label();
			barcodeLabel = new ComponentAce.Barcoding.BarcodeLabel();
			SaveButton = new System.Windows.Forms.Button();
			saveFileDialog = new System.Windows.Forms.SaveFileDialog();
			errorTextBox = new System.Windows.Forms.TextBox();
			textBox1 = new System.Windows.Forms.TextBox();
			button1 = new System.Windows.Forms.Button();
			textBox2 = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			label6 = new System.Windows.Forms.Label();
			barcodeLabel1 = new ComponentAce.Barcoding.BarcodeLabel();
			groupBox1 = new System.Windows.Forms.GroupBox();
			label19 = new System.Windows.Forms.Label();
			comboBox3 = new System.Windows.Forms.ComboBox();
			label20 = new System.Windows.Forms.Label();
			textBox3 = new System.Windows.Forms.TextBox();
			label21 = new System.Windows.Forms.Label();
			panel1 = new System.Windows.Forms.Panel();
			textBox4 = new global::NumericText.NumericText();
			checkBox1 = new System.Windows.Forms.CheckBox();
			label22 = new System.Windows.Forms.Label();
			textBox5 = new System.Windows.Forms.TextBox();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			groupBox1.SuspendLayout();
			panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			SuspendLayout();
			valueTextBox.AccessibleDescription = null;
			valueTextBox.AccessibleName = null;
			resources.ApplyResources(valueTextBox, "valueTextBox");
			valueTextBox.BackgroundImage = null;
			valueTextBox.Name = "valueTextBox";
			valueTextBox.TextChanged += new System.EventHandler(valueTextBox_TextChanged);
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.BackColor = System.Drawing.Color.Transparent;
			label2.Font = null;
			label2.Name = "label2";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.BackColor = System.Drawing.Color.Transparent;
			label3.Font = null;
			label3.Name = "label3";
			xDimensionTextBox.AccessibleDescription = null;
			xDimensionTextBox.AccessibleName = null;
			resources.ApplyResources(xDimensionTextBox, "xDimensionTextBox");
			xDimensionTextBox.BackgroundImage = null;
			xDimensionTextBox.Font = null;
			xDimensionTextBox.Name = "xDimensionTextBox";
			xDimensionTextBox.TextChanged += new System.EventHandler(xdimensionTextBox_TextChanged);
			wideToNarrowRatioTextBox.AccessibleDescription = null;
			wideToNarrowRatioTextBox.AccessibleName = null;
			resources.ApplyResources(wideToNarrowRatioTextBox, "wideToNarrowRatioTextBox");
			wideToNarrowRatioTextBox.BackgroundImage = null;
			wideToNarrowRatioTextBox.Font = null;
			wideToNarrowRatioTextBox.Name = "wideToNarrowRatioTextBox";
			wideToNarrowRatioTextBox.TextChanged += new System.EventHandler(wideToNarrowTextBox_TextChanged);
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.BackColor = System.Drawing.Color.Transparent;
			label4.Font = null;
			label4.Name = "label4";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label5");
			label5.BackColor = System.Drawing.Color.Transparent;
			label5.Font = null;
			label5.Name = "label5";
			label5.UseWaitCursor = true;
			symbologyComboBox.AccessibleDescription = null;
			symbologyComboBox.AccessibleName = null;
			resources.ApplyResources(symbologyComboBox, "symbologyComboBox");
			symbologyComboBox.BackgroundImage = null;
			symbologyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			symbologyComboBox.Font = null;
			symbologyComboBox.FormattingEnabled = true;
			symbologyComboBox.Name = "symbologyComboBox";
			symbologyComboBox.SelectedIndexChanged += new System.EventHandler(symbologyComboBox_SelectedIndexChanged);
			smoothingModeComboBox.AccessibleDescription = null;
			smoothingModeComboBox.AccessibleName = null;
			resources.ApplyResources(smoothingModeComboBox, "smoothingModeComboBox");
			smoothingModeComboBox.BackgroundImage = null;
			smoothingModeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			smoothingModeComboBox.Font = null;
			smoothingModeComboBox.FormattingEnabled = true;
			smoothingModeComboBox.Name = "smoothingModeComboBox";
			smoothingModeComboBox.SelectedIndexChanged += new System.EventHandler(smoothingModeComboBox_SelectedIndexChanged);
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "label7");
			label7.BackColor = System.Drawing.Color.Transparent;
			label7.Font = null;
			label7.Name = "label7";
			label7.UseWaitCursor = true;
			includeTextCheckBox.AccessibleDescription = null;
			includeTextCheckBox.AccessibleName = null;
			resources.ApplyResources(includeTextCheckBox, "includeTextCheckBox");
			includeTextCheckBox.BackColor = System.Drawing.Color.Transparent;
			includeTextCheckBox.BackgroundImage = null;
			includeTextCheckBox.Font = null;
			includeTextCheckBox.Name = "includeTextCheckBox";
			includeTextCheckBox.UseVisualStyleBackColor = false;
			includeTextCheckBox.CheckedChanged += new System.EventHandler(includeTextCheckBox_CheckedChanged);
			includeCheckSumCheckBox.AccessibleDescription = null;
			includeCheckSumCheckBox.AccessibleName = null;
			resources.ApplyResources(includeCheckSumCheckBox, "includeCheckSumCheckBox");
			includeCheckSumCheckBox.BackColor = System.Drawing.Color.Transparent;
			includeCheckSumCheckBox.BackgroundImage = null;
			includeCheckSumCheckBox.Font = null;
			includeCheckSumCheckBox.Name = "includeCheckSumCheckBox";
			includeCheckSumCheckBox.UseVisualStyleBackColor = false;
			includeCheckSumCheckBox.CheckedChanged += new System.EventHandler(includeCheckSumCheckBox_CheckedChanged);
			textFontButton.AccessibleDescription = null;
			textFontButton.AccessibleName = null;
			resources.ApplyResources(textFontButton, "textFontButton");
			textFontButton.BackgroundImage = null;
			textFontButton.Font = null;
			textFontButton.ForeColor = System.Drawing.Color.Black;
			textFontButton.Name = "textFontButton";
			textFontButton.UseVisualStyleBackColor = true;
			textFontButton.Click += new System.EventHandler(textFontButton_Click);
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "label8");
			label8.BackColor = System.Drawing.Color.Transparent;
			label8.Font = null;
			label8.Name = "label8";
			sizingComboBox.AccessibleDescription = null;
			sizingComboBox.AccessibleName = null;
			resources.ApplyResources(sizingComboBox, "sizingComboBox");
			sizingComboBox.BackgroundImage = null;
			sizingComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			sizingComboBox.Font = null;
			sizingComboBox.FormattingEnabled = true;
			sizingComboBox.Name = "sizingComboBox";
			sizingComboBox.SelectedIndexChanged += new System.EventHandler(sizingComboBox_SelectedIndexChanged);
			label9.AccessibleDescription = null;
			label9.AccessibleName = null;
			resources.ApplyResources(label9, "label9");
			label9.BackColor = System.Drawing.Color.Transparent;
			label9.Font = null;
			label9.Name = "label9";
			topMarginTextBox.AccessibleDescription = null;
			topMarginTextBox.AccessibleName = null;
			resources.ApplyResources(topMarginTextBox, "topMarginTextBox");
			topMarginTextBox.BackgroundImage = null;
			topMarginTextBox.Font = null;
			topMarginTextBox.Name = "topMarginTextBox";
			topMarginTextBox.TextChanged += new System.EventHandler(topMarginTextBox_TextChanged);
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "label10");
			label10.BackColor = System.Drawing.Color.Transparent;
			label10.Font = null;
			label10.Name = "label10";
			label11.AccessibleDescription = null;
			label11.AccessibleName = null;
			resources.ApplyResources(label11, "label11");
			label11.BackColor = System.Drawing.Color.Transparent;
			label11.Font = null;
			label11.Name = "label11";
			leftMarginTextBox.AccessibleDescription = null;
			leftMarginTextBox.AccessibleName = null;
			resources.ApplyResources(leftMarginTextBox, "leftMarginTextBox");
			leftMarginTextBox.BackgroundImage = null;
			leftMarginTextBox.Font = null;
			leftMarginTextBox.Name = "leftMarginTextBox";
			leftMarginTextBox.TextChanged += new System.EventHandler(leftMarginTextBox_TextChanged);
			label13.AccessibleDescription = null;
			label13.AccessibleName = null;
			resources.ApplyResources(label13, "label13");
			label13.BackColor = System.Drawing.Color.Transparent;
			label13.Font = null;
			label13.Name = "label13";
			rightMarginTextBox.AccessibleDescription = null;
			rightMarginTextBox.AccessibleName = null;
			resources.ApplyResources(rightMarginTextBox, "rightMarginTextBox");
			rightMarginTextBox.BackgroundImage = null;
			rightMarginTextBox.Font = null;
			rightMarginTextBox.Name = "rightMarginTextBox";
			rightMarginTextBox.TextChanged += new System.EventHandler(rightMarginTextBox_TextChanged);
			bottomMarginTextBox.AccessibleDescription = null;
			bottomMarginTextBox.AccessibleName = null;
			resources.ApplyResources(bottomMarginTextBox, "bottomMarginTextBox");
			bottomMarginTextBox.BackgroundImage = null;
			bottomMarginTextBox.Font = null;
			bottomMarginTextBox.Name = "bottomMarginTextBox";
			bottomMarginTextBox.TextChanged += new System.EventHandler(bottomMarginTextBox_TextChanged);
			label14.AccessibleDescription = null;
			label14.AccessibleName = null;
			resources.ApplyResources(label14, "label14");
			label14.BackColor = System.Drawing.Color.Transparent;
			label14.Font = null;
			label14.Name = "label14";
			angleComboBox.AccessibleDescription = null;
			angleComboBox.AccessibleName = null;
			resources.ApplyResources(angleComboBox, "angleComboBox");
			angleComboBox.BackgroundImage = null;
			angleComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			angleComboBox.Font = null;
			angleComboBox.FormattingEnabled = true;
			angleComboBox.Name = "angleComboBox";
			angleComboBox.SelectedIndexChanged += new System.EventHandler(angleComboBox_SelectedIndexChanged);
			printButton.AccessibleDescription = null;
			printButton.AccessibleName = null;
			resources.ApplyResources(printButton, "printButton");
			printButton.BackgroundImage = null;
			printButton.Font = null;
			printButton.ForeColor = System.Drawing.Color.Black;
			printButton.Name = "printButton";
			printButton.UseVisualStyleBackColor = true;
			printButton.Click += new System.EventHandler(printButton_Click);
			printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(printDocument_PrintPage);
			label12.AccessibleDescription = null;
			label12.AccessibleName = null;
			resources.ApplyResources(label12, "label12");
			label12.BackColor = System.Drawing.Color.Transparent;
			label12.Font = null;
			label12.Name = "label12";
			label15.AccessibleDescription = null;
			label15.AccessibleName = null;
			resources.ApplyResources(label15, "label15");
			label15.BackColor = System.Drawing.Color.Transparent;
			label15.Font = null;
			label15.Name = "label15";
			unitsComboBox.AccessibleDescription = null;
			unitsComboBox.AccessibleName = null;
			resources.ApplyResources(unitsComboBox, "unitsComboBox");
			unitsComboBox.BackgroundImage = null;
			unitsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			unitsComboBox.Font = null;
			unitsComboBox.FormattingEnabled = true;
			unitsComboBox.Name = "unitsComboBox";
			unitsComboBox.SelectedIndexChanged += new System.EventHandler(unitsComboBox_SelectedIndexChanged);
			label16.AccessibleDescription = null;
			label16.AccessibleName = null;
			resources.ApplyResources(label16, "label16");
			label16.BackColor = System.Drawing.Color.Transparent;
			label16.Font = null;
			label16.Name = "label16";
			barcodeWidthTextBox.AccessibleDescription = null;
			barcodeWidthTextBox.AccessibleName = null;
			resources.ApplyResources(barcodeWidthTextBox, "barcodeWidthTextBox");
			barcodeWidthTextBox.BackgroundImage = null;
			barcodeWidthTextBox.Font = null;
			barcodeWidthTextBox.Name = "barcodeWidthTextBox";
			barcodeWidthTextBox.TextChanged += new System.EventHandler(barcodeWidthTextBox_TextChanged);
			label17.AccessibleDescription = null;
			label17.AccessibleName = null;
			resources.ApplyResources(label17, "label17");
			label17.BackColor = System.Drawing.Color.Transparent;
			label17.Font = null;
			label17.Name = "label17";
			barcodeHeightTextBox.AccessibleDescription = null;
			barcodeHeightTextBox.AccessibleName = null;
			resources.ApplyResources(barcodeHeightTextBox, "barcodeHeightTextBox");
			barcodeHeightTextBox.BackgroundImage = null;
			barcodeHeightTextBox.Font = null;
			barcodeHeightTextBox.Name = "barcodeHeightTextBox";
			barcodeHeightTextBox.TextChanged += new System.EventHandler(barcodeHeightTextBox_TextChanged);
			label18.AccessibleDescription = null;
			label18.AccessibleName = null;
			resources.ApplyResources(label18, "label18");
			label18.BackColor = System.Drawing.Color.Transparent;
			label18.Font = null;
			label18.Name = "label18";
			barcodeLabel.AccessibleDescription = null;
			barcodeLabel.AccessibleName = null;
			resources.ApplyResources(barcodeLabel, "barcodeLabel");
			barcodeLabel.BackColor = System.Drawing.Color.White;
			barcodeLabel.BackgroundImage = null;
			barcodeLabel.BarcodeHeight = 100f;
			barcodeLabel.BarcodeWidth = 400f;
			barcodeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			barcodeLabel.ForeColor = System.Drawing.Color.Black;
			barcodeLabel.Name = "barcodeLabel";
			barcodeLabel.SizingType = ComponentAce.Barcoding.SizingType.SizeBased;
			barcodeLabel.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.Default;
			barcodeLabel.Symbology = ComponentAce.Barcoding.SymbologyType.Plessey;
			barcodeLabel.Value = "1234567";
			barcodeLabel.XDimension = 2f;
			barcodeLabel.Load += new System.EventHandler(barcodeLabel_Load);
			SaveButton.AccessibleDescription = null;
			SaveButton.AccessibleName = null;
			resources.ApplyResources(SaveButton, "SaveButton");
			SaveButton.BackgroundImage = null;
			SaveButton.Font = null;
			SaveButton.ForeColor = System.Drawing.Color.Black;
			SaveButton.Name = "SaveButton";
			SaveButton.UseVisualStyleBackColor = true;
			SaveButton.Click += new System.EventHandler(SaveButton_Click);
			resources.ApplyResources(saveFileDialog, "saveFileDialog");
			errorTextBox.AccessibleDescription = null;
			errorTextBox.AccessibleName = null;
			resources.ApplyResources(errorTextBox, "errorTextBox");
			errorTextBox.BackColor = System.Drawing.Color.White;
			errorTextBox.BackgroundImage = null;
			errorTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
			errorTextBox.ForeColor = System.Drawing.Color.Red;
			errorTextBox.Name = "errorTextBox";
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Font = null;
			textBox1.Name = "textBox1";
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.ForeColor = System.Drawing.Color.Black;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			textBox2.AccessibleDescription = null;
			textBox2.AccessibleName = null;
			resources.ApplyResources(textBox2, "textBox2");
			textBox2.BackgroundImage = null;
			textBox2.Font = null;
			textBox2.Name = "textBox2";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.BackColor = System.Drawing.Color.Transparent;
			label1.Font = null;
			label1.Name = "label1";
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "label6");
			label6.Font = null;
			label6.Name = "label6";
			barcodeLabel1.AccessibleDescription = null;
			barcodeLabel1.AccessibleName = null;
			resources.ApplyResources(barcodeLabel1, "barcodeLabel1");
			barcodeLabel1.BackColor = System.Drawing.Color.White;
			barcodeLabel1.BackgroundImage = null;
			barcodeLabel1.BarcodeHeight = 100f;
			barcodeLabel1.BarcodeWidth = 400f;
			barcodeLabel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			barcodeLabel1.Font = null;
			barcodeLabel1.ForeColor = System.Drawing.Color.Black;
			barcodeLabel1.Name = "barcodeLabel1";
			barcodeLabel1.SizingType = ComponentAce.Barcoding.SizingType.SizeBased;
			barcodeLabel1.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.Default;
			barcodeLabel1.Symbology = ComponentAce.Barcoding.SymbologyType.Code128;
			barcodeLabel1.Value = "1234567";
			barcodeLabel1.XDimension = 2f;
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(barcodeLabel1);
			groupBox1.Controls.Add(barcodeLabel);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			label19.AccessibleDescription = null;
			label19.AccessibleName = null;
			resources.ApplyResources(label19, "label19");
			label19.BackColor = System.Drawing.Color.Transparent;
			label19.Font = null;
			label19.ForeColor = System.Drawing.Color.Black;
			label19.Name = "label19";
			comboBox3.AccessibleDescription = null;
			comboBox3.AccessibleName = null;
			resources.ApplyResources(comboBox3, "comboBox3");
			comboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox3.BackgroundImage = null;
			comboBox3.Font = null;
			comboBox3.FormattingEnabled = true;
			comboBox3.Name = "comboBox3";
			comboBox3.SelectedIndexChanged += new System.EventHandler(comboBox3_SelectedIndexChanged);
			comboBox3.SelectedValueChanged += new System.EventHandler(comboBox3_SelectedIndexChanged);
			label20.AccessibleDescription = null;
			label20.AccessibleName = null;
			resources.ApplyResources(label20, "label20");
			label20.BackColor = System.Drawing.Color.Transparent;
			label20.Font = null;
			label20.Name = "label20";
			textBox3.AccessibleDescription = null;
			textBox3.AccessibleName = null;
			resources.ApplyResources(textBox3, "textBox3");
			textBox3.BackgroundImage = null;
			textBox3.Name = "textBox3";
			textBox3.TextChanged += new System.EventHandler(textBox3_TextChanged);
			label21.AccessibleDescription = null;
			label21.AccessibleName = null;
			resources.ApplyResources(label21, "label21");
			label21.Font = null;
			label21.ForeColor = System.Drawing.Color.IndianRed;
			label21.Name = "label21";
			panel1.AccessibleDescription = null;
			panel1.AccessibleName = null;
			resources.ApplyResources(panel1, "panel1");
			panel1.BackColor = System.Drawing.Color.Transparent;
			panel1.BackgroundImage = null;
			panel1.Controls.Add(textBox4);
			panel1.Controls.Add(label21);
			panel1.Font = null;
			panel1.Name = "panel1";
			textBox4.AccessibleDescription = null;
			textBox4.AccessibleName = null;
			resources.ApplyResources(textBox4, "textBox4");
			textBox4.BackgroundImage = null;
			textBox4.Font = null;
			textBox4.Name = "textBox4";
			textBox4.TextChanged += new System.EventHandler(textBox4_TextChanged);
			checkBox1.AccessibleDescription = null;
			checkBox1.AccessibleName = null;
			resources.ApplyResources(checkBox1, "checkBox1");
			checkBox1.BackColor = System.Drawing.Color.Transparent;
			checkBox1.BackgroundImage = null;
			checkBox1.Name = "checkBox1";
			checkBox1.UseVisualStyleBackColor = false;
			label22.AccessibleDescription = null;
			label22.AccessibleName = null;
			resources.ApplyResources(label22, "label22");
			label22.BackColor = System.Drawing.Color.Transparent;
			label22.Font = null;
			label22.Name = "label22";
			textBox5.AccessibleDescription = null;
			textBox5.AccessibleName = null;
			resources.ApplyResources(textBox5, "textBox5");
			textBox5.BackgroundImage = null;
			textBox5.Name = "textBox5";
			pictureBox1.AccessibleDescription = null;
			pictureBox1.AccessibleName = null;
			resources.ApplyResources(pictureBox1, "pictureBox1");
			pictureBox1.BackColor = System.Drawing.Color.White;
			pictureBox1.BackgroundImage = null;
			pictureBox1.Font = null;
			pictureBox1.ImageLocation = null;
			pictureBox1.Name = "pictureBox1";
			pictureBox1.TabStop = false;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.WhiteSmoke;
			BackgroundImage = null;
			base.Controls.Add(textBox5);
			base.Controls.Add(label22);
			base.Controls.Add(checkBox1);
			base.Controls.Add(panel1);
			base.Controls.Add(label20);
			base.Controls.Add(textBox3);
			base.Controls.Add(label19);
			base.Controls.Add(comboBox3);
			base.Controls.Add(groupBox1);
			base.Controls.Add(label1);
			base.Controls.Add(label6);
			base.Controls.Add(textBox2);
			base.Controls.Add(button1);
			base.Controls.Add(textBox1);
			base.Controls.Add(errorTextBox);
			base.Controls.Add(label12);
			base.Controls.Add(SaveButton);
			base.Controls.Add(printButton);
			base.Controls.Add(label13);
			base.Controls.Add(rightMarginTextBox);
			base.Controls.Add(label14);
			base.Controls.Add(bottomMarginTextBox);
			base.Controls.Add(label18);
			base.Controls.Add(label11);
			base.Controls.Add(barcodeHeightTextBox);
			base.Controls.Add(leftMarginTextBox);
			base.Controls.Add(label17);
			base.Controls.Add(label10);
			base.Controls.Add(barcodeWidthTextBox);
			base.Controls.Add(topMarginTextBox);
			base.Controls.Add(label16);
			base.Controls.Add(label9);
			base.Controls.Add(angleComboBox);
			base.Controls.Add(unitsComboBox);
			base.Controls.Add(label15);
			base.Controls.Add(sizingComboBox);
			base.Controls.Add(label8);
			base.Controls.Add(textFontButton);
			base.Controls.Add(includeCheckSumCheckBox);
			base.Controls.Add(includeTextCheckBox);
			base.Controls.Add(smoothingModeComboBox);
			base.Controls.Add(label7);
			base.Controls.Add(symbologyComboBox);
			base.Controls.Add(label5);
			base.Controls.Add(wideToNarrowRatioTextBox);
			base.Controls.Add(label4);
			base.Controls.Add(xDimensionTextBox);
			base.Controls.Add(label3);
			base.Controls.Add(label2);
			base.Controls.Add(valueTextBox);
			base.Controls.Add(pictureBox1);
			Font = null;
			ForeColor = System.Drawing.Color.Black;
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Name = "FrmBarCode1";
			base.ShowIcon = false;
			base.Load += new System.EventHandler(mainForm_Load);
			groupBox1.ResumeLayout(false);
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		public FrmBarCode1()
		{
			InitializeComponent();
		}

		private void valueTextBox_TextChanged(object sender, EventArgs e)
		{
			try
			{
				SetBarcodeValue();
			}
			catch
			{
			}
		}

		private void xdimensionTextBox_TextChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.XDimension = (float)Convert.ToDouble(xDimensionTextBox.Text);
			}
			catch
			{
			}
		}

		private void wideToNarrowTextBox_TextChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.Options.WideToNarrowRatio = (int)Convert.ToDouble(wideToNarrowRatioTextBox.Text);
			}
			catch
			{
			}
		}

		private void mainForm_Load(object sender, EventArgs e)
		{
			try
			{
				symbologyComboBox.Items.AddRange(Enum.GetNames(typeof(SymbologyType)));
				symbologyComboBox.Text = "Code128";
				smoothingModeComboBox.Items.AddRange(Enum.GetNames(typeof(SmoothingMode)));
				sizingComboBox.Items.AddRange(Enum.GetNames(typeof(SizingType)));
				unitsComboBox.Items.AddRange(Enum.GetNames(typeof(GraphicsUnit)));
				angleComboBox.Items.AddRange(Enum.GetNames(typeof(RotationAngle)));
				barcodeLabel.Options.WideToNarrowRatio = (int)Convert.ToDouble(wideToNarrowRatioTextBox.Text);
				barcodeLabel.XDimension = (float)Convert.ToDouble(xDimensionTextBox.Text);
			}
			catch
			{
			}
			try
			{
				UpdateControls();
			}
			catch
			{
			}
			textBox1.Text = Settings.Default.Pioneers;
			try
			{
				DataTable dataTable = Codes.Search2("select Id,Name from Items");
				comboBox3.DataSource = dataTable;
				comboBox3.DisplayMember = dataTable.Columns[1].ToString();
				comboBox3.ValueMember = dataTable.Columns[0].ToString();
				comboBox3.Text = "";
			}
			catch
			{
			}
		}

		private void UpdateControls()
		{
			symbologyComboBox.SelectedIndex = (int)barcodeLabel.Symbology;
			unitsComboBox.SelectedIndex = (int)units;
			sizingComboBox.SelectedIndex = (int)barcodeLabel.SizingType;
			smoothingModeComboBox.SelectedIndex = (int)barcodeLabel.SmoothingMode;
			valueTextBox.Text = barcodeLabel.Value;
			barcodeLabel.Options.IncludeText = false;
			includeCheckSumCheckBox.Checked = barcodeLabel.Options.CheckSum;
			includeTextCheckBox.Checked = barcodeLabel.Options.IncludeText;
			angleComboBox.SelectedIndex = (int)((float)barcodeLabel.Options.Angle / 90f);
			barcodeLabel.BarcodeMargins.Top = 25f;
			barcodeLabel.BarcodeMargins.Bottom = 25f;
			barcodeLabel.BarcodeMargins.Right = 5f;
			barcodeLabel.BarcodeMargins.Left = 50f;
			topMarginTextBox.Text = barcodeLabel.BarcodeMargins.Top.ToString();
			leftMarginTextBox.Text = barcodeLabel.BarcodeMargins.Left.ToString();
			bottomMarginTextBox.Text = barcodeLabel.BarcodeMargins.Bottom.ToString();
			rightMarginTextBox.Text = barcodeLabel.BarcodeMargins.Right.ToString();
			barcodeWidthTextBox.Text = barcodeLabel.BarcodeWidth.ToString();
			barcodeHeightTextBox.Text = barcodeLabel.BarcodeHeight.ToString();
		}

		private void symbologyComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.Symbology = (SymbologyType)symbologyComboBox.SelectedIndex;
				SetBarcodeValue();
			}
			catch
			{
			}
		}

		private void smoothingModeComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.SmoothingMode = (SmoothingMode)smoothingModeComboBox.SelectedIndex;
			}
			catch
			{
			}
		}

		private void textFontButton_Click(object sender, EventArgs e)
		{
			try
			{
				textFontDialog.Font = barcodeLabel.Options.TextFont;
				if (textFontDialog.ShowDialog() == DialogResult.OK)
				{
					barcodeLabel.Options.TextFont = textFontDialog.Font;
				}
			}
			catch
			{
			}
		}

		private void includeCheckSumCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.Options.CheckSum = includeCheckSumCheckBox.Checked;
				SetBarcodeValue();
			}
			catch
			{
			}
		}

		private void includeTextCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.Options.IncludeText = includeTextCheckBox.Checked;
				textFontButton.Enabled = includeTextCheckBox.Checked;
			}
			catch
			{
			}
		}

		private void sizingComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.SizingType = (SizingType)sizingComboBox.SelectedIndex;
				xDimensionTextBox.Enabled = barcodeLabel.SizingType != SizingType.SizeBased;
				if (barcodeLabel.SizingType == SizingType.XDimensionBased)
				{
				}
			}
			catch
			{
			}
		}

		private void topMarginTextBox_TextChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.BarcodeMargins.Top = (float)Convert.ToDouble(topMarginTextBox.Text);
			}
			catch
			{
			}
		}

		private void leftMarginTextBox_TextChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.BarcodeMargins.Left = (float)Convert.ToDouble(leftMarginTextBox.Text);
			}
			catch
			{
			}
		}

		private void bottomMarginTextBox_TextChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.BarcodeMargins.Bottom = (float)Convert.ToDouble(bottomMarginTextBox.Text);
			}
			catch
			{
			}
		}

		private void rightMarginTextBox_TextChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.BarcodeMargins.Right = (float)Convert.ToDouble(rightMarginTextBox.Text);
			}
			catch
			{
			}
		}

		private void angleComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.Options.Angle = (RotationAngle)(angleComboBox.SelectedIndex * 90);
			}
			catch
			{
			}
		}

		private void printButton_Click(object sender, EventArgs e)
		{
			try
			{
				Settings.Default.Pioneers = textBox1.Text;
				Settings.Default.Save();
				PrintDialog printDialog = new PrintDialog();
				if (printDialog.ShowDialog() == DialogResult.OK)
				{
					printDocument.PrinterSettings = printDialog.PrinterSettings;
					printDocument.Print();
				}
			}
			catch
			{
			}
		}

		private void printDocument_PrintPage(object sender, PrintPageEventArgs e)
		{
			try
			{
				e.Graphics.PageUnit = units;
				barcodeLabel.Draw(e.Graphics, new PointF(0f, 0f), new SizeF(barcodeLabel.BarcodeWidth, barcodeLabel.BarcodeHeight), barcodeLabel.BarcodeMargins);
			}
			catch
			{
			}
		}

		private void unitsComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				units = (GraphicsUnit)unitsComboBox.SelectedIndex;
			}
			catch
			{
			}
		}

		private void barcodeWidthTextBox_TextChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.BarcodeWidth = float.Parse(barcodeWidthTextBox.Text);
			}
			catch
			{
			}
		}

		private void barcodeHeightTextBox_TextChanged(object sender, EventArgs e)
		{
			try
			{
				barcodeLabel.BarcodeHeight = float.Parse(barcodeHeightTextBox.Text);
			}
			catch
			{
			}
		}

		private void SaveButton_Click(object sender, EventArgs e)
		{
			try
			{
				Settings.Default.Pioneers = textBox1.Text;
				Settings.Default.Save();
				if (saveFileDialog.ShowDialog() == DialogResult.OK)
				{
					barcodeLabel.SaveImage(saveFileDialog.FileName, units, 96f, 96f);
				}
			}
			catch
			{
			}
		}

		private bool SetBarcodeValue()
		{
			try
			{
				barcodeLabel.Value = valueTextBox.Text;
				barcodeLabel1.Value = valueTextBox.Text;
				valueTextBox.ForeColor = Color.Black;
				errorTextBox.Text = "";
				SaveButton.Enabled = true;
				printButton.Enabled = true;
				return true;
			}
			catch
			{
				valueTextBox.ForeColor = Color.Red;
				errorTextBox.Text = "القيمة المدخلة غير متوافقة مع نوع الترميز المختار";
				SaveButton.Enabled = false;
				printButton.Enabled = false;
				return false;
			}
		}

		private void barcodeLabel_Load(object sender, EventArgs e)
		{
		}

		private void button1_Click(object sender, EventArgs e)
		{
			DataSet1 dataSet = new DataSet1();
			try
			{
				new dataClass(".\\sqlExpress");
				ArrayList arrayList = new ArrayList();
				ImageBarcode imageBarcode = default(ImageBarcode);
				for (int i = 0; i < Convert.ToInt32(textBox4.Text); i++)
				{
					BarcodeLabel barcodeLabel = new BarcodeLabel();
					barcodeLabel.Symbology = (SymbologyType)symbologyComboBox.SelectedIndex;
					string text2 = (barcodeLabel.Value = valueTextBox.Text);
					barcodeLabel.BarcodeMargins.Left = (float)Convert.ToDouble(leftMarginTextBox.Text);
					barcodeLabel.BarcodeMargins.Right = (float)Convert.ToDouble(rightMarginTextBox.Text);
					barcodeLabel.BarcodeMargins.Top = (float)Convert.ToDouble(topMarginTextBox.Text);
					barcodeLabel.BarcodeMargins.Bottom = (float)Convert.ToDouble(bottomMarginTextBox.Text);
					barcodeLabel.Options.IncludeText = includeTextCheckBox.Checked;
					MemoryStream memoryStream = new MemoryStream();
					barcodeLabel.GetImage().Save(memoryStream, ImageFormat.Jpeg);
					byte[] array = (imageBarcode.Photo = memoryStream.ToArray());
					imageBarcode.Header = textBox1.Text;
					imageBarcode.Barcode = valueTextBox.Text;
					imageBarcode.ItemName = comboBox3.Text;
					imageBarcode.BCount = 1;
					imageBarcode.Price = textBox3.Text;
					arrayList.Add(imageBarcode);
					((DataTable)(object)dataSet.Barcode1).Rows.Add(imageBarcode.Barcode, imageBarcode.Header, imageBarcode.ItemName, imageBarcode.Photo, imageBarcode.BCount, imageBarcode.Price);
				}
				new frmrptbarcode(dataSet);
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
			}
			catch
			{
			}
		}

		private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				if (comboBox3.Text != "<-اختر->" || comboBox3.Text != "")
				{
					if (comboBox3.Focused)
					{
						valueTextBox.Text = comboBox3.SelectedValue.ToString();
					}
					DataTable dataTable = new DataTable();
					dataTable = Codes.Search2("select Price from ItemsUnit where Barcode = '" + valueTextBox.Text + "'");
					decimal num = Convert.ToDecimal(dataTable.Rows[0][0].ToString());
					textBox3.Text = num.ToString("#.##");
					dataTable = Codes.Search2("SELECT     ISNULL(SUM(dbo.Store.Quantity / dbo.ItemsUnit.ItMain), 0) AS Expr1\r\n            FROM         dbo.ItemsUnit INNER JOIN\r\n                                  dbo.Store ON dbo.ItemsUnit.ItemID = dbo.Store.ItemID where ItemsUnit.Barcode = '" + valueTextBox.Text + "'");
					decimal num2 = Convert.ToDecimal(dataTable.Rows[0][0].ToString());
					textBox5.Text = num2.ToString("#.##");
					textBox1.Text = "Pioneers   " + textBox3.Text + " LE";
				}
			}
			catch
			{
			}
		}

		private void textBox3_TextChanged(object sender, EventArgs e)
		{
		}

		private void textBox4_TextChanged(object sender, EventArgs e)
		{
		}

		private void button2_Click_1(object sender, EventArgs e)
		{
		}
	}
}
