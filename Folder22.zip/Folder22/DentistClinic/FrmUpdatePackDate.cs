using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmUpdatePackDate : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox2;

		private Label label3;

		private GroupBox groupBox1;

		private DateTimePicker recalldateTimePicker2;

		private Button button3;

		private GroupBox groupBox3;

		private DataGridView dataGridView1;

		private Button saveBtn;

		private MaskedTextBox maskedTextBox1;

		private DateTimePicker FromTextBox;

		private ComboBox comboBox2;

		private DataGridViewTextBoxColumn PackDate;

		private DataGridViewTextBoxColumn Time;

		private DataGridViewTextBoxColumn Column1;

		private DataTable dtPackDate = new DataTable();

		private int Patient;

		private int Doctor;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmUpdatePackDate));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			groupBox2 = new System.Windows.Forms.GroupBox();
			this.label3 = new System.Windows.Forms.Label();
			groupBox1 = new System.Windows.Forms.GroupBox();
			comboBox2 = new System.Windows.Forms.ComboBox();
			FromTextBox = new System.Windows.Forms.DateTimePicker();
			maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
			button3 = new System.Windows.Forms.Button();
			recalldateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			groupBox3 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			saveBtn = new System.Windows.Forms.Button();
			PackDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Time = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			groupBox2.SuspendLayout();
			groupBox1.SuspendLayout();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "nationalityLabel");
			label.Name = "nationalityLabel";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label1");
			label2.Name = "label1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label7");
			label3.Name = "label7";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label2");
			label4.Name = "label2";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(this.label3);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			this.label3.AccessibleDescription = null;
			this.label3.AccessibleName = null;
			resources.ApplyResources(this.label3, "label3");
			this.label3.Name = "label3";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(comboBox2);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(FromTextBox);
			groupBox1.Controls.Add(maskedTextBox1);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(button3);
			groupBox1.Controls.Add(label);
			groupBox1.Controls.Add(recalldateTimePicker2);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			comboBox2.AccessibleDescription = null;
			comboBox2.AccessibleName = null;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.BackgroundImage = null;
			comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox2.FormattingEnabled = true;
			comboBox2.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox2.Items"),
				resources.GetString("comboBox2.Items1")
			});
			comboBox2.Name = "comboBox2";
			FromTextBox.AccessibleDescription = null;
			FromTextBox.AccessibleName = null;
			resources.ApplyResources(FromTextBox, "FromTextBox");
			FromTextBox.BackgroundImage = null;
			FromTextBox.CalendarFont = null;
			FromTextBox.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			FromTextBox.Name = "FromTextBox";
			FromTextBox.Value = new System.DateTime(2018, 8, 28, 12, 0, 0, 0);
			maskedTextBox1.AccessibleDescription = null;
			maskedTextBox1.AccessibleName = null;
			resources.ApplyResources(maskedTextBox1, "maskedTextBox1");
			maskedTextBox1.BackgroundImage = null;
			maskedTextBox1.Name = "maskedTextBox1";
			maskedTextBox1.ValidatingType = typeof(System.DateTime);
			maskedTextBox1.TextChanged += new System.EventHandler(maskedTextBox1_TextChanged_1);
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackColor = System.Drawing.Color.Gainsboro;
			button3.BackgroundImage = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = false;
			button3.Click += new System.EventHandler(button3_Click);
			recalldateTimePicker2.AccessibleDescription = null;
			recalldateTimePicker2.AccessibleName = null;
			resources.ApplyResources(recalldateTimePicker2, "recalldateTimePicker2");
			recalldateTimePicker2.BackgroundImage = null;
			recalldateTimePicker2.CalendarFont = null;
			recalldateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			recalldateTimePicker2.Name = "recalldateTimePicker2";
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(dataGridView1);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(PackDate, Time, Column1);
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			saveBtn.AccessibleDescription = null;
			saveBtn.AccessibleName = null;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			saveBtn.BackgroundImage = null;
			saveBtn.Name = "saveBtn";
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			dataGridViewCellStyle.Format = "d";
			dataGridViewCellStyle.NullValue = null;
			PackDate.DefaultCellStyle = dataGridViewCellStyle;
			resources.ApplyResources(PackDate, "PackDate");
			PackDate.Name = "PackDate";
			PackDate.ReadOnly = true;
			resources.ApplyResources(Time, "Time");
			Time.Name = "Time";
			Time.ReadOnly = true;
			resources.ApplyResources(Column1, "Column1");
			Column1.Name = "Column1";
			Column1.ReadOnly = true;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(saveBtn);
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FrmUpdatePackDate";
			base.Load += new System.EventHandler(FrmPackDate_Load);
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
		}

		public FrmUpdatePackDate(DataTable dt, int PatientId, int DoctorId)
		{
			InitializeComponent();
			dtPackDate = dt;
			Patient = PatientId;
			Doctor = DoctorId;
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("select AppointFrom, AppointTo from Properties");
				DateTime dateTime = Convert.ToDateTime(dataTable.Rows[0][0].ToString());
				DateTime dateTime2 = Convert.ToDateTime(dataTable.Rows[0][1].ToString());
				int num = 0;
				int num2 = 0;
				int num3 = 0;
				num = ((dateTime.Hour < 12) ? dateTime.Hour : (dateTime.Hour - 12));
				num2 = ((dateTime2.Hour < 12) ? dateTime2.Hour : (dateTime2.Hour - 12));
				num3 = ((FromTextBox.Value.Hour < 12) ? FromTextBox.Value.Hour : (FromTextBox.Value.Hour - 12));
				if (comboBox2.Text == "الفترة الصباحية" && num > num3)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Cannot Reserve when Clinic Not open");
					}
					else
					{
						MessageBox.Show("برجاء حجز الكشف في موعد عمل العيادة");
					}
					return;
				}
				if (comboBox2.Text == "الفترة المسائية" && (num < num3 || num2 < num3 || num2 == num3))
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Cannot Reserve when Clinic Not open");
					}
					else
					{
						MessageBox.Show("برجاء حجز الكشف في موعد عمل العيادة");
					}
					return;
				}
				bool flag = true;
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					if (Convert.ToDateTime(dataGridView1.Rows[i].Cells[0].Value).ToShortDateString() == recalldateTimePicker2.Value.ToShortDateString())
					{
						flag = false;
						break;
					}
				}
				if (flag)
				{
					dataGridView1.Rows.Add(recalldateTimePicker2.Value, FromTextBox.Value.ToString("hh:mm"));
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("You Have Save This Date Before");
				}
				else
				{
					MessageBox.Show("تم ادخال هذا التاريخ من قبل");
				}
			}
			catch
			{
			}
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				for (int i = 0; i < dtPackDate.Rows.Count; i++)
				{
					DataTable dataTable = Codes.Search2("select * from Appointments where ID = '" + dtPackDate.Rows[i][2].ToString() + "' and AppointNum = 0");
					if (dataTable.Rows.Count == 0)
					{
						Codes.Delete2("delete from Appointments where ID = '" + dtPackDate.Rows[i][2].ToString() + "'");
					}
					else
					{
						Codes.Edit2("update Appointments set PackDone = 1 where ID = '" + dtPackDate.Rows[i][2].ToString() + "'");
					}
				}
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					Codes.Add2("INSERT INTO Appointments\r\n                      (AppointNum, PatuentID, DoctorID, detectDate, detectStartTime, detectEndTime, packDate, ExpDate, ChairNum, Price, Done, PackDone, packprice,Status,Accepted,Period)\r\nVALUES     (0,'" + Patient + "','" + Doctor + "','" + Convert.ToDateTime(dataGridView1.Rows[i].Cells[0].Value).ToString("MM/dd/yyyy") + "','" + dataGridView1.Rows[i].Cells[1].Value.ToString() + "','','" + Convert.ToDateTime(dataGridView1.Rows[i].Cells[0].Value).ToString("MM/dd/yyyy") + "','" + Convert.ToDateTime(dataGridView1.Rows[i].Cells[0].Value).ToString("MM/dd/yyyy") + "','',0, 1, 0, 0,'',1,0)");
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Updated Successfully");
				}
				else
				{
					MessageBox.Show("تم التعديل بنجاح");
				}
				Close();
			}
			catch
			{
			}
		}

		private void FrmPackDate_Load(object sender, EventArgs e)
		{
			try
			{
				for (int i = 0; i < dtPackDate.Rows.Count; i++)
				{
					dataGridView1.Rows.Add(Convert.ToDateTime(dtPackDate.Rows[i][0]), dtPackDate.Rows[i][1].ToString(), dtPackDate.Rows[i][2].ToString());
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = Codes.Search2("select AppointFrom from Properties");
				string text = "";
				text = ((Convert.ToDateTime(dataTable.Rows[0][0]).Hour <= 12) ? Convert.ToDateTime(dataTable.Rows[0][0]).Hour.ToString() : (Convert.ToDateTime(dataTable.Rows[0][0]).Hour - 12).ToString());
				if (Convert.ToInt32(text) < 10)
				{
					text = "0" + text;
				}
				maskedTextBox1.Text = text + ":00";
				comboBox2.SelectedIndex = 0;
			}
			catch
			{
			}
		}

		private void maskedTextBox1_TextChanged_1(object sender, EventArgs e)
		{
			try
			{
				FromTextBox.Text = maskedTextBox1.Text;
			}
			catch
			{
			}
		}
	}
}
