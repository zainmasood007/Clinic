using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmPatientInoculation : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox4;

		private TextBox textBox2;

		private RadioButton radioButton2;

		private RadioButton radioButton1;

		private Button SearchBtn;

		private ComboBox PatientcomboBox;

		private GroupBox groupBox2;

		private TextBox AgetextBox;

		private TextBox NametextBox;

		private Label label3;

		private Label label1;

		private TextBox textBox1;

		private TextBox textBox5;

		private Label label8;

		private Label label6;

		private TextBox textBox4;

		private Label label4;

		private Label label2;

		private TextBox textBox6;

		private Label label7;

		private TextBox textBox8;

		private Label label10;

		private TextBox textBox7;

		private Label label9;

		private Label label14;

		private Label label13;

		private TextBox textBox10;

		private Label label12;

		private TextBox textBox9;

		private Label label11;

		private TextBox textBox12;

		private Label label15;

		private TextBox textBox11;

		private GroupBox groupBox1;

		private DataGridView dataGridView1;

		private TextBox textBox13;

		private DateTimePicker dateTimePicker1;

		private DateTimePicker dateTimePicker2;

		private Button SaveBtn;

		private DateTimePicker dateTimePicker3;

		private TextBox textBox3;

		private TextBox textBox14;

		private DataGridViewTextBoxColumn Column7;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Column2;

		private DataGridViewTextBoxColumn Column3;

		private DataGridViewTextBoxColumn Column4;

		private DataGridViewTextBoxColumn Column8;

		private DataGridViewTextBoxColumn Column9;

		private DataGridViewTextBoxColumn Column5;

		private DataGridViewCheckBoxColumn Column6;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private int patientId;

		private DataTable dttt;

		private GeneralMethods MethodsClass = new GeneralMethods();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmPatientInoculation));
			groupBox4 = new System.Windows.Forms.GroupBox();
			textBox14 = new System.Windows.Forms.TextBox();
			dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
			textBox2 = new System.Windows.Forms.TextBox();
			radioButton2 = new System.Windows.Forms.RadioButton();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			radioButton1 = new System.Windows.Forms.RadioButton();
			SearchBtn = new System.Windows.Forms.Button();
			PatientcomboBox = new System.Windows.Forms.ComboBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			textBox3 = new System.Windows.Forms.TextBox();
			dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			textBox13 = new System.Windows.Forms.TextBox();
			textBox12 = new System.Windows.Forms.TextBox();
			label15 = new System.Windows.Forms.Label();
			AgetextBox = new System.Windows.Forms.TextBox();
			textBox11 = new System.Windows.Forms.TextBox();
			label14 = new System.Windows.Forms.Label();
			label12 = new System.Windows.Forms.Label();
			textBox10 = new System.Windows.Forms.TextBox();
			textBox9 = new System.Windows.Forms.TextBox();
			label13 = new System.Windows.Forms.Label();
			label11 = new System.Windows.Forms.Label();
			textBox7 = new System.Windows.Forms.TextBox();
			label9 = new System.Windows.Forms.Label();
			label6 = new System.Windows.Forms.Label();
			textBox8 = new System.Windows.Forms.TextBox();
			label10 = new System.Windows.Forms.Label();
			textBox6 = new System.Windows.Forms.TextBox();
			label7 = new System.Windows.Forms.Label();
			textBox5 = new System.Windows.Forms.TextBox();
			label8 = new System.Windows.Forms.Label();
			textBox4 = new System.Windows.Forms.TextBox();
			label4 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			textBox1 = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			NametextBox = new System.Windows.Forms.TextBox();
			label3 = new System.Windows.Forms.Label();
			groupBox1 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column6 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			SaveBtn = new System.Windows.Forms.Button();
			groupBox4.SuspendLayout();
			groupBox2.SuspendLayout();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.Controls.Add(textBox14);
			groupBox4.Controls.Add(dateTimePicker3);
			groupBox4.Controls.Add(textBox2);
			groupBox4.Controls.Add(radioButton2);
			groupBox4.Controls.Add(dateTimePicker1);
			groupBox4.Controls.Add(radioButton1);
			groupBox4.Controls.Add(SearchBtn);
			groupBox4.Controls.Add(PatientcomboBox);
			groupBox4.ForeColor = System.Drawing.Color.Black;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			resources.ApplyResources(textBox14, "textBox14");
			textBox14.Name = "textBox14";
			textBox14.ReadOnly = true;
			resources.ApplyResources(dateTimePicker3, "dateTimePicker3");
			dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker3.Name = "dateTimePicker3";
			dateTimePicker3.Value = new System.DateTime(2016, 9, 27, 0, 0, 0, 0);
			resources.ApplyResources(textBox2, "textBox2");
			textBox2.Name = "textBox2";
			resources.ApplyResources(radioButton2, "radioButton2");
			radioButton2.Name = "radioButton2";
			radioButton2.UseVisualStyleBackColor = true;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			dateTimePicker1.Value = new System.DateTime(2016, 9, 27, 0, 0, 0, 0);
			resources.ApplyResources(radioButton1, "radioButton1");
			radioButton1.Checked = true;
			radioButton1.Name = "radioButton1";
			radioButton1.TabStop = true;
			radioButton1.UseVisualStyleBackColor = true;
			resources.ApplyResources(SearchBtn, "SearchBtn");
			SearchBtn.BackColor = System.Drawing.Color.Gainsboro;
			SearchBtn.Name = "SearchBtn";
			SearchBtn.UseVisualStyleBackColor = false;
			SearchBtn.Click += new System.EventHandler(SearchBtn_Click);
			resources.ApplyResources(PatientcomboBox, "PatientcomboBox");
			PatientcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			PatientcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientcomboBox.FormattingEnabled = true;
			PatientcomboBox.Name = "PatientcomboBox";
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(textBox3);
			groupBox2.Controls.Add(dateTimePicker2);
			groupBox2.Controls.Add(textBox13);
			groupBox2.Controls.Add(textBox12);
			groupBox2.Controls.Add(label15);
			groupBox2.Controls.Add(AgetextBox);
			groupBox2.Controls.Add(textBox11);
			groupBox2.Controls.Add(label14);
			groupBox2.Controls.Add(label12);
			groupBox2.Controls.Add(textBox10);
			groupBox2.Controls.Add(textBox9);
			groupBox2.Controls.Add(label13);
			groupBox2.Controls.Add(label11);
			groupBox2.Controls.Add(textBox7);
			groupBox2.Controls.Add(label9);
			groupBox2.Controls.Add(label6);
			groupBox2.Controls.Add(textBox8);
			groupBox2.Controls.Add(label10);
			groupBox2.Controls.Add(textBox6);
			groupBox2.Controls.Add(label7);
			groupBox2.Controls.Add(textBox5);
			groupBox2.Controls.Add(label8);
			groupBox2.Controls.Add(textBox4);
			groupBox2.Controls.Add(label4);
			groupBox2.Controls.Add(label2);
			groupBox2.Controls.Add(textBox1);
			groupBox2.Controls.Add(label1);
			groupBox2.Controls.Add(NametextBox);
			groupBox2.Controls.Add(label3);
			groupBox2.ForeColor = System.Drawing.Color.Black;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			resources.ApplyResources(textBox3, "textBox3");
			textBox3.Name = "textBox3";
			textBox3.ReadOnly = true;
			resources.ApplyResources(dateTimePicker2, "dateTimePicker2");
			dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker2.Name = "dateTimePicker2";
			dateTimePicker2.Value = new System.DateTime(2016, 9, 28, 0, 0, 0, 0);
			resources.ApplyResources(textBox13, "textBox13");
			textBox13.Name = "textBox13";
			textBox13.ReadOnly = true;
			resources.ApplyResources(textBox12, "textBox12");
			textBox12.Name = "textBox12";
			textBox12.ReadOnly = true;
			resources.ApplyResources(label15, "label15");
			label15.Name = "label15";
			resources.ApplyResources(AgetextBox, "AgetextBox");
			AgetextBox.Name = "AgetextBox";
			AgetextBox.ReadOnly = true;
			resources.ApplyResources(textBox11, "textBox11");
			textBox11.Name = "textBox11";
			textBox11.ReadOnly = true;
			resources.ApplyResources(label14, "label14");
			label14.Name = "label14";
			resources.ApplyResources(label12, "label12");
			label12.Name = "label12";
			resources.ApplyResources(textBox10, "textBox10");
			textBox10.Name = "textBox10";
			textBox10.ReadOnly = true;
			resources.ApplyResources(textBox9, "textBox9");
			textBox9.Name = "textBox9";
			textBox9.ReadOnly = true;
			resources.ApplyResources(label13, "label13");
			label13.Name = "label13";
			resources.ApplyResources(label11, "label11");
			label11.Name = "label11";
			resources.ApplyResources(textBox7, "textBox7");
			textBox7.Name = "textBox7";
			textBox7.ReadOnly = true;
			resources.ApplyResources(label9, "label9");
			label9.Name = "label9";
			resources.ApplyResources(label6, "label6");
			label6.Name = "label6";
			resources.ApplyResources(textBox8, "textBox8");
			textBox8.Name = "textBox8";
			textBox8.ReadOnly = true;
			resources.ApplyResources(label10, "label10");
			label10.Name = "label10";
			resources.ApplyResources(textBox6, "textBox6");
			textBox6.Name = "textBox6";
			textBox6.ReadOnly = true;
			resources.ApplyResources(label7, "label7");
			label7.Name = "label7";
			resources.ApplyResources(textBox5, "textBox5");
			textBox5.Name = "textBox5";
			textBox5.ReadOnly = true;
			resources.ApplyResources(label8, "label8");
			label8.Name = "label8";
			resources.ApplyResources(textBox4, "textBox4");
			textBox4.Name = "textBox4";
			textBox4.ReadOnly = true;
			resources.ApplyResources(label4, "label4");
			label4.Name = "label4";
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.Name = "textBox1";
			textBox1.ReadOnly = true;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			resources.ApplyResources(NametextBox, "NametextBox");
			NametextBox.Name = "NametextBox";
			NametextBox.ReadOnly = true;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(dataGridView1);
			groupBox1.ForeColor = System.Drawing.Color.Black;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(Column7, Column1, Column2, Column3, Column4, Column8, Column9, Column5, Column6);
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.Name = "dataGridView1";
			dataGridView1.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(dataGridView1_CellValueChanged);
			dataGridView1.CurrentCellDirtyStateChanged += new System.EventHandler(dataGridView1_CurrentCellDirtyStateChanged);
			resources.ApplyResources(Column7, "Column7");
			Column7.Name = "Column7";
			resources.ApplyResources(Column1, "Column1");
			Column1.Name = "Column1";
			resources.ApplyResources(Column2, "Column2");
			Column2.Name = "Column2";
			resources.ApplyResources(Column3, "Column3");
			Column3.Name = "Column3";
			resources.ApplyResources(Column4, "Column4");
			Column4.Name = "Column4";
			resources.ApplyResources(Column8, "Column8");
			Column8.Name = "Column8";
			resources.ApplyResources(Column9, "Column9");
			Column9.Name = "Column9";
			resources.ApplyResources(Column5, "Column5");
			Column5.Name = "Column5";
			resources.ApplyResources(Column6, "Column6");
			Column6.Name = "Column6";
			resources.ApplyResources(SaveBtn, "SaveBtn");
			SaveBtn.BackColor = System.Drawing.Color.Gainsboro;
			SaveBtn.Name = "SaveBtn";
			SaveBtn.UseVisualStyleBackColor = false;
			SaveBtn.Click += new System.EventHandler(SaveBtn_Click);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(SaveBtn);
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox4);
			base.Name = "FrmPatientInoculation";
			base.Load += new System.EventHandler(FrmPatientInoculation_Load);
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
		}

		public FrmPatientInoculation()
		{
			InitializeComponent();
		}

		private void FrmPatientInoculation_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("SELECT dbo.ChildData.PatientID, dbo.PatientData.PName FROM dbo.ChildData INNER JOIN dbo.PatientData ON dbo.ChildData.PatientID = dbo.PatientData.ID where PatientData.Active = 'True'");
				PatientcomboBox.DataSource = null;
				PatientcomboBox.DataSource = dataTable;
				PatientcomboBox.DisplayMember = dataTable.Columns["PName"].ToString();
				PatientcomboBox.ValueMember = dataTable.Columns[0].ToString();
				PatientcomboBox.SelectedIndex = -1;
			}
			catch
			{
			}
			dataGridView1.Columns[1].ReadOnly = true;
			dataGridView1.Columns[2].ReadOnly = true;
			dataGridView1.Columns[3].ReadOnly = true;
			dataGridView1.Columns[4].ReadOnly = true;
		}

		private void SearchBtn_Click(object sender, EventArgs e)
		{
			dataGridView1.Rows.Clear();
			dttt = null;
			dataGridView1.Columns[7].DefaultCellStyle.Format = "yyyy/MM/dd";
			DataTable dataTable = new DataTable();
			if (radioButton1.Checked)
			{
				if (PatientcomboBox.SelectedIndex == -1)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter patient name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المريض");
					}
					return;
				}
				dataTable = Codes.Search2("SELECT dbo.ChildData.PatientID, dbo.PatientData.PName, dbo.PatientData.Sex, dbo.PatientData.BirthDate, dbo.ChildData.PregnancyPeriod, dbo.ChildData.BirthType, dbo.ChildData.PregnancyNo, dbo.ChildData.ChildNo, dbo.ChildData.BreastFeeding, dbo.ChildData.Allergies, dbo.ChildData.Weight, dbo.ChildData.Surgery, dbo.ChildData.Notes FROM dbo.ChildData INNER JOIN dbo.PatientData ON dbo.ChildData.PatientID = dbo.PatientData.ID where dbo.PatientData.ID = '" + PatientcomboBox.SelectedValue.ToString() + "'");
			}
			else
			{
				if (textBox2.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Mobile No.");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل رقم الموبايل");
					}
					return;
				}
				dataTable = Codes.Search2("SELECT dbo.ChildData.PatientID, dbo.PatientData.PName, dbo.PatientData.Sex, dbo.PatientData.BirthDate, dbo.ChildData.PregnancyPeriod, dbo.ChildData.BirthType, dbo.ChildData.PregnancyNo, dbo.ChildData.ChildNo, dbo.ChildData.BreastFeeding, dbo.ChildData.Allergies, dbo.ChildData.Weight, dbo.ChildData.Surgery, dbo.ChildData.Notes FROM dbo.ChildData INNER JOIN dbo.PatientData ON dbo.ChildData.PatientID = dbo.PatientData.ID where dbo.PatientData.Mob = '" + textBox2.Text + "' and PatientData.Active = 'True'");
			}
			if (dataTable.Rows.Count > 0)
			{
				patientId = Convert.ToInt32(dataTable.Rows[0][0].ToString());
				NametextBox.Text = dataTable.Rows[0][1].ToString();
				textBox1.Text = dataTable.Rows[0][2].ToString();
				dateTimePicker2.Value = Convert.ToDateTime(dataTable.Rows[0][3].ToString());
				textBox4.Text = dataTable.Rows[0][4].ToString();
				textBox5.Text = dataTable.Rows[0][5].ToString();
				textBox6.Text = dataTable.Rows[0][6].ToString();
				textBox7.Text = dataTable.Rows[0][7].ToString();
				textBox8.Text = dataTable.Rows[0][8].ToString();
				textBox9.Text = dataTable.Rows[0][9].ToString();
				textBox10.Text = dataTable.Rows[0][10].ToString();
				textBox11.Text = dataTable.Rows[0][11].ToString();
				textBox12.Text = dataTable.Rows[0][12].ToString();
				string text = "";
				DataTable dataTable2 = Codes.Search2("SELECT dbo.Surgery.Name FROM dbo.PatientSurgery INNER JOIN dbo.Surgery ON dbo.PatientSurgery.SurgeryID = dbo.Surgery.ID where dbo.PatientSurgery.PatientID = '" + patientId + "'");
				if (dataTable2.Rows.Count > 0)
				{
					for (int i = 0; i < dataTable2.Rows.Count; i++)
					{
						text = ((i != 0) ? (text + " - " + dataTable2.Rows[i][0].ToString()) : (" / " + dataTable2.Rows[0][0].ToString()));
					}
				}
				textBox11.Text += text;
				TimeSpan timeSpan = DateTime.Today.Subtract(Convert.ToDateTime(dataTable.Rows[0]["BirthDate"].ToString()));
				DateTime today = DateTime.Today;
				DateTime dateTime = Convert.ToDateTime(dataTable.Rows[0]["BirthDate"].ToString());
				int num = Convert.ToInt32(timeSpan.TotalDays / 364.25);
				int num2 = today.Month - dateTime.Month;
				if (num2 < 0)
				{
					num2 = 0;
				}
				string text2;
				if (num == 0)
				{
					text2 = ((!(Settings.Default.Language == "en-GB")) ? (num2 + "شهر") : (num2 + "Month"));
					AgetextBox.Text = num2.ToString();
					textBox3.Text = "0";
				}
				else if (num2 == 0)
				{
					text2 = ((!(Settings.Default.Language == "en-GB")) ? (num + "سنة ") : (num + "Year "));
					AgetextBox.Text = num2.ToString();
					textBox3.Text = num.ToString();
				}
				else
				{
					AgetextBox.Text = num2.ToString();
					textBox3.Text = num.ToString();
					text2 = ((!(Settings.Default.Language == "en-GB")) ? (AgetextBox.Text + "شهر و" + textBox3.Text + "سنة ") : (AgetextBox.Text + "Month ," + textBox3.Text + "Year "));
				}
				textBox13.Text = text2;
				DataTable dataTable3 = Codes.Search2("select * from Inoculations");
				dttt = Codes.Search2("select * from PatientInoculation where PatientID = '" + patientId + "'");
				for (int i = 0; i < dataTable3.Rows.Count; i++)
				{
					dataGridView1.Rows.Add(dataTable3.Rows[i][0].ToString(), dataTable3.Rows[i][5].ToString(), dataTable3.Rows[i][2].ToString(), dataTable3.Rows[i][1].ToString());
				}
				if (dttt.Rows.Count <= 0)
				{
					return;
				}
				foreach (DataGridViewRow item in (IEnumerable)dataGridView1.Rows)
				{
					for (int j = 0; j < dttt.Rows.Count; j++)
					{
						if (item.Cells[0].Value.ToString() == dttt.Rows[j][2].ToString() && Convert.ToInt32(dttt.Rows[j][1].ToString()) == patientId)
						{
							string text3 = "";
							text3 = ((!(Settings.Default.Language == "en-GB")) ? (dttt.Rows[j][3].ToString() + "شهر و" + dttt.Rows[j][4].ToString() + "سنة") : (dttt.Rows[j][3].ToString() + "Month ," + dttt.Rows[j][4].ToString() + "Year"));
							item.Cells[4].Value = text3;
							item.Cells[5].Value = dttt.Rows[j][3].ToString();
							item.Cells[6].Value = dttt.Rows[j][4].ToString();
							item.Cells[8].Value = true;
							item.Cells[7].Value = Convert.ToDateTime(dttt.Rows[j][5].ToString());
							dataGridView1.Columns[7].DefaultCellStyle.Format = "yyyy/MM/dd";
							break;
						}
					}
				}
			}
			else if (Settings.Default.Language == "en-GB")
			{
				MessageBox.Show("No Data");
			}
			else
			{
				MessageBox.Show("لا يوجد بيانات");
			}
		}

		private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
		{
			if (dataGridView1.Rows.Count > 0 && e.ColumnIndex == 8)
			{
				if (Convert.ToBoolean(dataGridView1[8, e.RowIndex].Value))
				{
					dataGridView1[7, e.RowIndex].Value = DateTime.Now.ToString("yyyy/MM/dd");
					dataGridView1[4, e.RowIndex].Value = textBox13.Text;
					dataGridView1[5, e.RowIndex].Value = AgetextBox.Text;
					dataGridView1[6, e.RowIndex].Value = textBox3.Text;
					dataGridView1.Invalidate();
				}
				else if (!Convert.ToBoolean(dataGridView1[8, e.RowIndex].Value))
				{
					dataGridView1[7, e.RowIndex].Value = "";
					dataGridView1[4, e.RowIndex].Value = "";
					dataGridView1[5, e.RowIndex].Value = "";
					dataGridView1[6, e.RowIndex].Value = "";
					dataGridView1.Invalidate();
				}
			}
		}

		private void dataGridView1_CurrentCellDirtyStateChanged(object sender, EventArgs e)
		{
			if (dataGridView1.IsCurrentCellDirty)
			{
				dataGridView1.CommitEdit(DataGridViewDataErrorContexts.Commit);
			}
		}

		private void SaveBtn_Click(object sender, EventArgs e)
		{
			if (dataGridView1.Rows.Count == 0)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter patient name");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم المريض");
				}
				return;
			}
			bool flag = false;
			try
			{
				if (dttt.Rows.Count == 0)
				{
					for (int i = 0; i < dataGridView1.Rows.Count; i++)
					{
						if (Convert.ToBoolean(dataGridView1.Rows[i].Cells[8].Value))
						{
							Codes.Add2("insert into PatientInoculation(PatientID, InoculateID, Age, MPeriod, Date) values('" + patientId + "','" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[5].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[6].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[7].Value.ToString() + "')");
							flag = true;
						}
					}
					if (!flag)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please enter vaccination");
						}
						else
						{
							MessageBox.Show("من فضلك ادخل التطعيم");
						}
						return;
					}
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					MethodsClass.UserMove("أضافة تطعيم لمريض ");
					return;
				}
				foreach (DataGridViewRow item in (IEnumerable)dataGridView1.Rows)
				{
					for (int j = 0; j < dttt.Rows.Count; j++)
					{
						if (!(item.Cells[0].Value.ToString() == dttt.Rows[j][2].ToString()) || Convert.ToInt32(dttt.Rows[j][1].ToString()) != patientId || Convert.ToBoolean(item.Cells[8].Value))
						{
							if (!(item.Cells[0].Value.ToString() != dttt.Rows[j][2].ToString()) || !Convert.ToBoolean(item.Cells[8].Value))
							{
								if (item.Cells[0].Value.ToString() == dttt.Rows[j][2].ToString() && Convert.ToInt32(dttt.Rows[j][1].ToString()) == patientId && Convert.ToBoolean(item.Cells[8].Value))
								{
									Codes.Edit2("update PatientInoculation set Age = '" + item.Cells[5].Value.ToString() + "' , MPeriod = '" + item.Cells[6].Value.ToString() + "',Date = '" + item.Cells[7].Value.ToString() + "' where InoculateID = '" + item.Cells[0].Value.ToString() + "' and PatientID = '" + patientId + "'");
									flag = true;
									break;
								}
								continue;
							}
							Codes.Add2("insert into PatientInoculation(PatientID, InoculateID, Age, MPeriod, Date) values('" + patientId + "','" + item.Cells[0].Value.ToString() + "','" + item.Cells[5].Value.ToString() + "','" + item.Cells[6].Value.ToString() + "','" + item.Cells[7].Value.ToString() + "')");
							flag = true;
							break;
						}
						Codes.Delete2("delete from PatientInoculation where InoculateID = '" + item.Cells[0].Value.ToString() + "' and PatientID = '" + patientId + "'");
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter vaccination");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل التطعيم");
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				MethodsClass.UserMove("أضافة تطعيم لمريض ");
			}
			catch
			{
			}
		}
	}
}
