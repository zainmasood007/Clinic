using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Windows.Forms;

namespace DentistClinic
{
	public class FrmRptEmailConfig : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private ComboBox comboBox1;

		private Label label1;

		private GroupBox groupBox2;

		private DataGridView dataGridView1;

		private DataGridViewTextBoxColumn RptID;

		private DataGridViewCheckBoxColumn Checked;

		private DataGridViewTextBoxColumn RptName;

		private DataGridViewTextBoxColumn Period;

		private DataGridViewTextBoxColumn DayOrMonth;

		private DataGridViewTextBoxColumn Time;

		private GroupBox groupBox3;

		private Button button1;

		private Button button2;

		private NotifyIcon TrayIcon;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		public static string period;

		public static string dayOrMonth;

		public static string time;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmRptEmailConfig));
			groupBox1 = new System.Windows.Forms.GroupBox();
			comboBox1 = new System.Windows.Forms.ComboBox();
			label1 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			RptID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Checked = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			RptName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Period = new System.Windows.Forms.DataGridViewTextBoxColumn();
			DayOrMonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Time = new System.Windows.Forms.DataGridViewTextBoxColumn();
			groupBox3 = new System.Windows.Forms.GroupBox();
			button2 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			TrayIcon = new System.Windows.Forms.NotifyIcon(components);
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox3.SuspendLayout();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(comboBox1);
			groupBox1.Controls.Add(label1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.Font = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Name = "comboBox1";
			comboBox1.SelectedIndexChanged += new System.EventHandler(comboBox1_SelectedIndexChanged);
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.Name = "label1";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(dataGridView1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(RptID, Checked, RptName, Period, DayOrMonth, Time);
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_CellMouseDoubleClick);
			resources.ApplyResources(RptID, "RptID");
			RptID.Name = "RptID";
			resources.ApplyResources(Checked, "Checked");
			Checked.Name = "Checked";
			resources.ApplyResources(RptName, "RptName");
			RptName.Name = "RptName";
			RptName.ReadOnly = true;
			resources.ApplyResources(Period, "Period");
			Period.Name = "Period";
			Period.ReadOnly = true;
			resources.ApplyResources(DayOrMonth, "DayOrMonth");
			DayOrMonth.Name = "DayOrMonth";
			DayOrMonth.ReadOnly = true;
			DayOrMonth.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			DayOrMonth.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			resources.ApplyResources(Time, "Time");
			Time.Name = "Time";
			Time.ReadOnly = true;
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(button2);
			groupBox3.Controls.Add(button1);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			TrayIcon.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
			resources.ApplyResources(TrayIcon, "TrayIcon");
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FrmRptEmailConfig";
			base.Load += new System.EventHandler(FrmRptEmailConfig_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox3.ResumeLayout(false);
			ResumeLayout(false);
		}

		public FrmRptEmailConfig()
		{
			InitializeComponent();
		}

		private void FrmRptEmailConfig_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataSource = Codes.Search2("select ID,Email from RptEmails");
				comboBox1.DataSource = dataSource;
				comboBox1.ValueMember = "ID";
				comboBox1.DisplayMember = "Email";
			}
			catch
			{
			}
		}

		private void FillGrid()
		{
			dataGridView1.Rows.Clear();
			DataTable dataTable = Codes.Search2("select * from RptsForEmail");
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				DataTable dataTable2 = Codes.Search2(string.Concat("select * from RptEmailConfig where RptID = '", dataTable.Rows[i][0].ToString(), "' and EmailID = '", comboBox1.SelectedValue, "'"));
				if (dataTable2.Rows.Count > 0)
				{
					dataGridView1.Rows.Add(dataTable.Rows[i][0].ToString(), true, dataTable.Rows[i][2].ToString(), dataTable2.Rows[0][3].ToString(), dataTable2.Rows[0][4].ToString(), Convert.ToDateTime(dataTable2.Rows[0][5].ToString()).ToString("HH:mm"));
				}
				else
				{
					dataGridView1.Rows.Add(dataTable.Rows[i][0].ToString(), false, dataTable.Rows[i][2].ToString(), 1, "يوم", "21:00");
				}
			}
		}

		private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				if (dataGridView1.CurrentCell.ColumnIndex == 3 || dataGridView1.CurrentCell.ColumnIndex == 4)
				{
					period = dataGridView1.CurrentRow.Cells[3].Value.ToString();
					dayOrMonth = dataGridView1.CurrentRow.Cells[4].Value.ToString();
					FrmPeriodValue frmPeriodValue = new FrmPeriodValue();
					frmPeriodValue.ShowDialog();
					dataGridView1.CurrentRow.Cells[3].Value = period;
					dataGridView1.CurrentRow.Cells[4].Value = dayOrMonth;
				}
				else if (dataGridView1.CurrentCell.ColumnIndex == 5)
				{
					time = dataGridView1.CurrentCell.Value.ToString();
					FrmTimeValue frmTimeValue = new FrmTimeValue();
					frmTimeValue.ShowDialog();
					dataGridView1.CurrentCell.Value = time;
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				Codes.Delete2(string.Concat("delete from RptEmailConfig where EmailID = '", comboBox1.SelectedValue, "'"));
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					if (Convert.ToBoolean(dataGridView1.Rows[i].Cells[1].Value))
					{
						Codes.Add2(string.Concat("insert into RptEmailConfig (EmailID, RptID, Period, DayOrMonth, Time) Values ('", comboBox1.SelectedValue, "', '", dataGridView1.Rows[i].Cells[0].Value.ToString(), "', '", dataGridView1.Rows[i].Cells[3].Value.ToString(), "', '", dataGridView1.Rows[i].Cells[4].Value.ToString(), "', '", dataGridView1.Rows[i].Cells[5].Value.ToString(), "')"));
					}
				}
				MessageBox.Show("تم حفظ البيانات بنجاح");
			}
			catch
			{
			}
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				FillGrid();
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				try
				{
					string[] files = Directory.GetFiles(Application.StartupPath + "\\", "*.pdf");
					string[] array = files;
					foreach (string path in array)
					{
						File.Delete(path);
					}
				}
				catch
				{
				}
				DataTable dataTable = Codes.Search2("select Active from EmailCnfgs");
				bool flag = false;
				try
				{
					flag = Convert.ToBoolean(dataTable.Rows[0][0].ToString());
				}
				catch
				{
				}
				if (!flag)
				{
					return;
				}
				DataTable dataTable2 = Codes.Search2(string.Concat("select * from RptEmails where ID = '", comboBox1.SelectedValue, "'"));
				for (int j = 0; j < dataTable2.Rows.Count; j++)
				{
					DataTable dataTable3 = Codes.Search2("select * from RptsForEmail");
					for (int k = 0; k < dataTable3.Rows.Count; k++)
					{
						DataTable dataTable4 = Codes.Search2("select * from RptEmailConfig where EmailID = '" + dataTable2.Rows[j][0].ToString() + "' and RptID = '" + dataTable3.Rows[k][0].ToString() + "'");
						if (dataTable4.Rows.Count <= 0)
						{
							continue;
						}
						if (dataTable3.Rows[k][1].ToString() == "DoctorAcount")
						{
							DataTable dataTable5 = Codes.Search2("SELECT     ID, Name\r\nFROM         Empdata\r\nWHERE     (Designation = N'Doctor')");
							for (int l = 0; l < dataTable5.Rows.Count; l++)
							{
								SendEmails(dataTable4.Rows[0][1].ToString(), dataTable4.Rows[0][2].ToString(), DateTime.Today, DateTime.Today, dataTable5.Rows[l][0].ToString(), dataTable5.Rows[l][1].ToString());
							}
						}
						else if (dataTable3.Rows[k][1].ToString() == "NetDailyClinic")
						{
							SendEmails(dataTable4.Rows[0][1].ToString(), dataTable4.Rows[0][2].ToString(), DateTime.Today, DateTime.Today, "", "");
						}
						else
						{
							SendEmails(dataTable4.Rows[0][1].ToString(), dataTable4.Rows[0][2].ToString(), DateTime.Today, DateTime.Today, "", "");
						}
					}
				}
			}
			catch
			{
			}
		}

		private void SendEmails(string emailID, string rptID, DateTime lastDate, DateTime dateToBegin, string ID, string name)
		{
			try
			{
				DataTable dataTable = Codes.Search2("select RptName,RptNameAr from RptsForEmail where ID = '" + rptID + "'");
				string text = dataTable.Rows[0][0].ToString();
				string fileName = Application.StartupPath + "\\Report.pdf";
				switch (text)
				{
				case "Patients":
				{
					string text2 = "حسابات الزبائن " + dateToBegin.ToString("dd-MM-yyyy") + " إلى " + lastDate.ToString("dd-MM-yyyy");
					fileName = Application.StartupPath + "\\" + text2 + ".pdf";
					new frmAllPatientAcount(dateToBegin, lastDate, fileName);
					break;
				}
				case "DailyClinic":
				{
					string text2 = "يومية العيادة خلال الفترة من " + dateToBegin.ToString("dd-MM-yyyy") + " إلى " + lastDate.ToString("dd-MM-yyyy");
					fileName = Application.StartupPath + "\\" + text2 + ".pdf";
					new FrmRptStockMove(dateToBegin, lastDate, fileName);
					break;
				}
				case "NetDailyClinic":
				{
					string text2 = "صافي يومية العيادة خلال الفترة من " + dateToBegin.ToString("dd-MM-yyyy") + " إلى " + lastDate.ToString("dd-MM-yyyy");
					fileName = Application.StartupPath + "\\" + text2 + ".pdf";
					new NetDailyClinicRptFrm(dateToBegin, lastDate, fileName);
					break;
				}
				case "Profitability":
				{
					string text2 = "الربحية خلال الفترة من " + dateToBegin.ToString("dd-MM-yyyy") + " إلى " + lastDate.ToString("dd-MM-yyyy");
					fileName = Application.StartupPath + "\\" + text2 + ".pdf";
					new FrmRptReb7ya(dateToBegin, lastDate, fileName);
					break;
				}
				case "UserMove":
				{
					string text2 = "دخول مستخدم خلال الفترة من " + dateToBegin.ToString("dd-MM-yyyy") + " إلى " + lastDate.ToString("dd-MM-yyyy");
					fileName = Application.StartupPath + "\\" + text2 + ".pdf";
					new FrmLoginUser(dateToBegin, lastDate, fileName);
					break;
				}
				case "DoctorAcount":
				{
					string text2 = " حساب قسم " + name + " خلال الفترة من " + dateToBegin.ToString("dd-MM-yyyy") + " إلى " + lastDate.ToString("dd-MM-yyyy");
					fileName = Application.StartupPath + "\\" + text2 + ".pdf";
					new FrmDoctorAcountByDate(dateToBegin, lastDate, fileName, ID);
					break;
				}
				}
				using (WebClient webClient = new WebClient())
				{
					using (webClient.OpenRead("http://www.google.com"))
					{
						DataTable dataTable2 = Codes.Search2("select * from EmailCnfgs");
						MailMessage mailMessage = new MailMessage();
						mailMessage.From = new MailAddress(dataTable2.Rows[0][1].ToString(), "Easy Clinic System");
						MailMessage mailMessage2 = mailMessage;
						DataTable dataTable3 = Codes.Search2("select Email from RptEmails where ID= '" + emailID + "'");
						mailMessage2.To.Add(dataTable3.Rows[0][0].ToString());
						mailMessage2.Subject = dataTable.Rows[0][1].ToString();
						mailMessage2.IsBodyHtml = false;
						mailMessage2.Body = dataTable.Rows[0][1].ToString();
						Attachment item = new Attachment(fileName);
						mailMessage2.Attachments.Add(item);
						SmtpClient smtpClient = new SmtpClient(dataTable2.Rows[0][2].ToString());
						smtpClient.EnableSsl = Convert.ToBoolean(dataTable2.Rows[0][5].ToString());
						smtpClient.Credentials = new NetworkCredential(dataTable2.Rows[0][3].ToString(), dataClass.Decrypt(dataTable2.Rows[0][4].ToString()));
						SmtpClient smtpClient2 = smtpClient;
						if (dataTable2.Rows[0][6].ToString() != null)
						{
							smtpClient2.Port = Convert.ToInt32(dataTable2.Rows[0][6].ToString());
						}
						MessageBox.Show("تم ارسال البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						smtpClient2.Send(mailMessage2);
						mailMessage2.Dispose();
						Codes.Add2("insert into RptSent (EmailID, RptID, Date) Values ('" + emailID + "', '" + rptID + "', '" + lastDate.ToString("MM/dd/yyyy") + "')");
						TrayIcon.Visible = true;
						TrayIcon.ShowBalloonTip(100);
					}
				}
			}
			catch
			{
			}
		}
	}
}
