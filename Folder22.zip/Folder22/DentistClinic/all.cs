using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DentistClinic
{
	public class all : Form
	{
		private IContainer components = null;

		private Button button1;

		private Button button2;

		private Button button3;

		private Button button4;

		private Button button5;

		private Button button6;

		private Button button7;

		private Button button8;

		private Button button9;

		private Button button10;

		public all()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			PationtInfo pationtInfo = new PationtInfo(0);
			pationtInfo.ShowDialog();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			EmpData empData = new EmpData();
			empData.ShowDialog();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			Appointments appointments = new Appointments();
			appointments.ShowDialog();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			FmSearchPatient fmSearchPatient = new FmSearchPatient();
			fmSearchPatient.ShowDialog();
		}

		private void button5_Click(object sender, EventArgs e)
		{
			Company company = new Company();
			company.ShowDialog();
		}

		private void button6_Click(object sender, EventArgs e)
		{
			PatientAccountFrm patientAccountFrm = new PatientAccountFrm();
			patientAccountFrm.ShowDialog();
		}

		private void button7_Click(object sender, EventArgs e)
		{
			PatientPayAccount patientPayAccount = new PatientPayAccount(0);
			patientPayAccount.ShowDialog();
		}

		private void button8_Click(object sender, EventArgs e)
		{
			DoctorReserve doctorReserve = new DoctorReserve();
			doctorReserve.ShowDialog();
		}

		private void all_Load(object sender, EventArgs e)
		{
			PatientAccount.docid = 1;
			DoctorReserve.DoctorId = 1;
		}

		private void button9_Click(object sender, EventArgs e)
		{
			SecretaryReserve secretaryReserve = new SecretaryReserve();
			secretaryReserve.Show();
		}

		private void button10_Click(object sender, EventArgs e)
		{
			DoctorAccount doctorAccount = new DoctorAccount();
			doctorAccount.ShowDialog();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			button1 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			button4 = new System.Windows.Forms.Button();
			button5 = new System.Windows.Forms.Button();
			button6 = new System.Windows.Forms.Button();
			button7 = new System.Windows.Forms.Button();
			button8 = new System.Windows.Forms.Button();
			button9 = new System.Windows.Forms.Button();
			button10 = new System.Windows.Forms.Button();
			SuspendLayout();
			button1.Location = new System.Drawing.Point(335, 50);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(75, 34);
			button1.TabIndex = 0;
			button1.Text = "patient";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			button2.Location = new System.Drawing.Point(188, 50);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(75, 34);
			button2.TabIndex = 1;
			button2.Text = "emp";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			button3.Location = new System.Drawing.Point(53, 50);
			button3.Name = "button3";
			button3.Size = new System.Drawing.Size(75, 34);
			button3.TabIndex = 2;
			button3.Text = "appointmedt";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			button4.Location = new System.Drawing.Point(457, 50);
			button4.Name = "button4";
			button4.Size = new System.Drawing.Size(98, 34);
			button4.TabIndex = 3;
			button4.Text = "search patient";
			button4.UseVisualStyleBackColor = true;
			button4.Click += new System.EventHandler(button4_Click);
			button5.Location = new System.Drawing.Point(457, 115);
			button5.Name = "button5";
			button5.Size = new System.Drawing.Size(98, 34);
			button5.TabIndex = 4;
			button5.Text = "Company";
			button5.UseVisualStyleBackColor = true;
			button5.Click += new System.EventHandler(button5_Click);
			button6.Location = new System.Drawing.Point(294, 115);
			button6.Name = "button6";
			button6.Size = new System.Drawing.Size(116, 34);
			button6.TabIndex = 5;
			button6.Text = "patientaccount";
			button6.UseVisualStyleBackColor = true;
			button6.Click += new System.EventHandler(button6_Click);
			button7.Location = new System.Drawing.Point(147, 115);
			button7.Name = "button7";
			button7.Size = new System.Drawing.Size(116, 34);
			button7.TabIndex = 6;
			button7.Text = "patientpay";
			button7.UseVisualStyleBackColor = true;
			button7.Click += new System.EventHandler(button7_Click);
			button8.Location = new System.Drawing.Point(25, 115);
			button8.Name = "button8";
			button8.Size = new System.Drawing.Size(116, 34);
			button8.TabIndex = 7;
			button8.Text = "DOCTOR RESERVE";
			button8.UseVisualStyleBackColor = true;
			button8.Click += new System.EventHandler(button8_Click);
			button9.Location = new System.Drawing.Point(25, 164);
			button9.Name = "button9";
			button9.Size = new System.Drawing.Size(116, 34);
			button9.TabIndex = 8;
			button9.Text = "secretary reserve";
			button9.UseVisualStyleBackColor = true;
			button9.Click += new System.EventHandler(button9_Click);
			button10.Location = new System.Drawing.Point(207, 164);
			button10.Name = "button10";
			button10.Size = new System.Drawing.Size(116, 34);
			button10.TabIndex = 9;
			button10.Text = "doctoraccount";
			button10.UseVisualStyleBackColor = true;
			button10.Click += new System.EventHandler(button10_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(604, 304);
			base.Controls.Add(button10);
			base.Controls.Add(button9);
			base.Controls.Add(button8);
			base.Controls.Add(button7);
			base.Controls.Add(button6);
			base.Controls.Add(button5);
			base.Controls.Add(button4);
			base.Controls.Add(button3);
			base.Controls.Add(button2);
			base.Controls.Add(button1);
			base.Name = "all";
			Text = "all";
			base.Load += new System.EventHandler(all_Load);
			ResumeLayout(false);
		}
	}
}
