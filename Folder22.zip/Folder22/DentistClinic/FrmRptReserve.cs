using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmRptReserve : ReportBaseForm
	{
		private IContainer components = null;

		private CrystalReportViewer crystalReportViewer1;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmRptReserve));
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			SuspendLayout();
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(crystalReportViewer1);
			Font = null;
			base.Name = "FrmRptReserve";
			ResumeLayout(false);
		}

		public FrmRptReserve(DataSet ds)
		{
			InitializeComponent();
			RptReserve rptReserve = new RptReserve();
			rptReserve.SetDataSource(ds);
			crystalReportViewer1.ReportSource = rptReserve;
		}

		public FrmRptReserve(DataSet ds, int x)
		{
			InitializeComponent();
			RptReserveVisits rptReserveVisits = new RptReserveVisits();
			rptReserveVisits.SetDataSource(ds);
			crystalReportViewer1.ReportSource = rptReserveVisits;
		}
	}
}
