using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using DentistClinic.Properties;
using FloatTextBox;
using VistaButtonTest;

namespace DentistClinic
{
	public class FrmVisit : BaseForm
	{
		public static int docid;

		private bool b;

		private DataSet1 ds = new DataSet1();

		private string Teeth1;

		private string BuyPrice;

		private string CompanyPrice;

		private string companyId;

		private int patientid;

		private int appointid;

		private bool done = false;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private ClassDataBase dc;

		private dataClass codes;

		private double total;

		private GUI gui = new GUI();

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private GroupBox groupBox4;

		private ComboBox PatientComboBox;

		private GroupBox groupBox1;

		private DataGridView dataGridView1;

		private TextBox PricetextBox;

		private ComboBox doctorcomboBox;

		private Button ADDBtn;

		private GroupBox groupBox5;

		private Button saveBtn;

		private DateTimePicker appdateTimePicker1;

		private TextBox tottextBox;

		private GroupBox groupBox2;

		private Label label7;

		private DateTimePicker dateTimePicker1;

		private Button button1;

		private ComboBox commentTextBox;

		private Button button2;

		private Button button3;

		private Button button4;

		private Button button5;

		private Button button6;

		private TextBox textBox3;

		private GroupBox groupBox3;

		private GroupBox groupBox6;

		private TextBox textBox1;

		private TextBox textBox4;

		private TextBox textBox2;

		private TextBox textBox5;

		private TextBox textBox7;

		private TextBox textBox6;

		private TextBox textBox8;

		private DateTimePicker dateTimePicker2;

		private TextBox textBox9;

		private CheckBox checkBox3;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private ComboBox AssistantcomboBox;

		private Button button16;

		private GroupBox groupBox7;

		private Button button17;

		private Label label70;

		private TextBox txtStore;

		private ComboBox itemIdComboBox;

		private FloatText floatText1;

		private Label label71;

		private FloatText txtQty;

		private Label label72;

		private GroupBox groupBox22;

		private DataGridView dataGridView3;

		private Button button7;

		private ComboBox comboCategory;

		private FloatText floatText5;

		private Panel PaidPanel;

		private ComboBox TreasuryCom;

		private TextBox EsalNoTxt;

		private Label lblTreasury;

		private Label label45;

		private RadioButton radioButton5;

		private RadioButton radioButton6;

		private GroupBox groupBox29;

		private ComboBox OfferName;

		private TextBox OfferPrice;

		private Button button23;

		private DateTimePicker dateTimePicker4;

		private TextBox Rased;

		private RadioButton PayNaqdy;

		private RadioButton PayBefore;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlSelectCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlInsertCommand2;

		private DataGridViewTextBoxColumn Service;

		private DataGridViewTextBoxColumn Price;

		private DataGridViewTextBoxColumn ServiceDate;

		private DataGridViewTextBoxColumn Teethn;

		private DataGridViewTextBoxColumn TiD;

		private DataGridViewTextBoxColumn Cost;

		private DataGridViewTextBoxColumn Count;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Column2;

		private DataGridViewTextBoxColumn Column4;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;

		private DataGridViewTextBoxColumn ItemId;

		private DataGridViewTextBoxColumn Column3;

		public FrmVisit(int PATIENTID, int AppointID)
		{
			patientid = PATIENTID;
			appointid = AppointID;
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
		}

		public void GetBean()
		{
			try
			{
				DataTable dataTable = codes.Search2("select distinct(Service) from CompanyService");
				commentTextBox.DataSource = null;
				commentTextBox.DataSource = dataTable;
				commentTextBox.DisplayMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void PatientAccount_Load(object sender, EventArgs e)
		{
			try
			{
				if (Convert.ToBoolean(codes.Search2("select AvoidPay2 from Properties").Rows[0][0].ToString()))
				{
					checkBox3.Enabled = false;
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataSource = codes.Search2("select distinct name,OfferID from Offers where StartDate<='" + DateTime.Now.ToString("MM/dd/yyyy") + "' and EndDate >='" + DateTime.Now.ToString("MM/dd/yyyy") + "'");
				OfferName.DataSource = dataSource;
				OfferName.ValueMember = "OfferID";
				OfferName.DisplayMember = "name";
				if (UsersClass.AutoEsal)
				{
					EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
					EsalNoTxt.Enabled = false;
				}
				else
				{
					EsalNoTxt.Text = "";
					EsalNoTxt.Enabled = true;
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select * from Categories");
				comboCategory.DataSource = dataTable;
				comboCategory.ValueMember = dataTable.Columns[0].ToString();
				comboCategory.DisplayMember = dataTable.Columns[1].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = codes.Search2("select * from Items");
				itemIdComboBox.DataSource = null;
				itemIdComboBox.DataSource = dataTable2;
				itemIdComboBox.DisplayMember = dataTable2.Columns[1].ToString();
				itemIdComboBox.ValueMember = dataTable2.Columns[0].ToString();
				itemIdComboBox.SelectedIndex = -1;
			}
			catch
			{
			}
			try
			{
				appdateTimePicker1.Value = DateTime.Today;
				dateTimePicker2.Value = DateTime.Today;
			}
			catch
			{
			}
			try
			{
				DataTable dataTable3 = codes.Search2("select ChangeServicePrice from users where userName ='" + Main.usernames + "' and userPassward ='" + Main.passward + "'");
				PricetextBox.Enabled = Convert.ToBoolean(dataTable3.Rows[0][0].ToString());
			}
			catch
			{
			}
			try
			{
				DataTable dataTable4 = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				TreasuryCom.DataSource = null;
				TreasuryCom.DataSource = dataTable4;
				TreasuryCom.DisplayMember = dataTable4.Columns[1].ToString();
				TreasuryCom.ValueMember = dataTable4.Columns[0].ToString();
			}
			catch
			{
			}
			DataTable dataTable5 = new DataTable();
			try
			{
				dataTable5 = dc.Select("SelectAllDoctor");
				gui.loadComboBox(doctorcomboBox, dataTable5);
			}
			catch
			{
			}
			try
			{
				DataTable dataTable6 = new DataTable();
				if (Convert.ToBoolean(codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString()))
				{
					dataTable6 = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True' order by PName");
					PatientComboBox.DataSource = dataTable6;
					PatientComboBox.DisplayMember = dataTable6.Columns[1].ToString();
					PatientComboBox.ValueMember = dataTable6.Columns[0].ToString();
				}
				else
				{
					dataTable6 = dc.Select("SelectAllPatient");
					gui.loadComboBox(PatientComboBox, dataTable6);
				}
			}
			catch
			{
			}
			try
			{
				dataTable5 = dc.Select("SelectAllAssistant");
				gui.loadComboBox(AssistantcomboBox, dataTable5);
			}
			catch
			{
			}
			try
			{
				doctorcomboBox.SelectedValue = docid;
				PatientComboBox.SelectedValue = patientid;
			}
			catch
			{
			}
			PricetextBox.Enabled = UsersClass.ChangeServicePrice;
			floatText1.Enabled = UsersClass.ChangeServicePrice;
		}

		private void commentTextBox_TextChanged(object sender, EventArgs e)
		{
			string text = commentTextBox.Text;
			if (text.StartsWith(" "))
			{
				MessageBox.Show("لا يمكن ترك فراغ في بداية الإسم", "تنبيه");
				commentTextBox.Text = "";
			}
		}

		private void PricetextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && PricetextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
				}
				else
				{
					MessageBox.Show("من فضلك ادخل ارقام فقط");
					e.Handled = true;
				}
			}
			catch
			{
			}
		}

		private void PricetextBox_Leave(object sender, EventArgs e)
		{
			try
			{
				if (PricetextBox.Text == "")
				{
					PricetextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void ADDBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (commentTextBox.Text != "")
				{
					dataGridView1.Rows.Add(commentTextBox.Text, Convert.ToDouble(floatText5.Text) * Convert.ToDouble(PricetextBox.Text), dateTimePicker1.Value.ToString("yyyy/MM/dd"), "General", "33", CompanyPrice, floatText5.Text, 0, 0, OfferName.SelectedValue);
					b = true;
					total = Convert.ToDouble(tottextBox.Text);
					total += Convert.ToDouble(floatText5.Text) * Convert.ToDouble(PricetextBox.Text);
					tottextBox.Text = total.ToString();
					commentTextBox.Text = "";
					PricetextBox.Text = "0";
					floatText5.Text = "1";
					AssistantcomboBox.Enabled = false;
				}
				else
				{
					MessageBox.Show("من فضلك ادخل الخدمة", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
			try
			{
				total = 0.0;
				if (dataGridView1.Rows.Count > 1)
				{
					for (int i = 1; i < dataGridView1.Rows.Count; i++)
					{
						total += Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString());
						tottextBox.Text = total.ToString();
					}
				}
				else
				{
					tottextBox.Text = total.ToString();
				}
			}
			catch
			{
			}
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (!checkBox3.Checked)
				{
					goto IL_0118;
				}
				if (PayNaqdy.Checked)
				{
					if (EsalNoTxt.Text == "")
					{
						MessageBox.Show("من فضلك ادخل رقم الايصال");
						return;
					}
					DataTable dataTable = codes.Search2("select EsalNo from Esal where EsalNo ='" + EsalNoTxt.Text + "'");
					if (dataTable.Rows.Count <= 0)
					{
						goto IL_0118;
					}
					MessageBox.Show("رقم الايصال مسجل من قبل");
				}
				else if (Rased.Text == "0.00" || Rased.Text == "0")
				{
					MessageBox.Show("لا يمكن الدفع من مدفوعات سابقة لان الحساب السابق للمريض بصفر");
				}
				else
				{
					if (!(Convert.ToDecimal(tottextBox.Text) > Convert.ToDecimal(Rased.Text)))
					{
						goto IL_0118;
					}
					MessageBox.Show("لا يمكن الدفع من مدفوعات سابقة لان الحساب السابق للمريض أقل من اجمالي المطلوب");
				}
				goto end_IL_0001;
				IL_0118:
				string[] array = new string[8] { "PatientId", "DoctorID", "Bean", "Price", "Date", "BeanDate", "TeathId", "Assistant" };
				string text = "";
				double num = 0.0;
				double num2 = 0.0;
				for (int i = 0; i < dataGridView3.Rows.Count; i++)
				{
					num += Convert.ToDouble(dataGridView3.Rows[i].Cells[1].Value) * Convert.ToDouble(dataGridView3.Rows[i].Cells[2].Value);
				}
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					num2 += Convert.ToDouble(dataGridView1.Rows[i].Cells["Cost"].Value);
				}
				string value = codes.Search("select isnull(sum(Madeen),0) -  isnull(sum(Daen),0) from Company5 where CompanyId = '" + companyId + "'").Rows[0][0].ToString();
				string text2 = EsalNoTxt.Text;
				if (dataGridView1.Rows.Count > 1)
				{
					try
					{
						codes.Edit2("UPDATE PatientData SET NextVisit ='" + textBox7.Text + "' where ID='" + PatientComboBox.SelectedValue.ToString() + "'");
					}
					catch
					{
					}
					string value2 = codes.Search2(string.Concat("insert into PatientVisits (PatientID, VisitDate, BloodPressure, SugarMeasure, Weight, Other, Result, NextVisitRequirements, NextVisitDate, Notes) values ('", PatientComboBox.SelectedValue, "', '", appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "', '", textBox1.Text, "', '", textBox2.Text, "', '", textBox4.Text, "', '", textBox5.Text, "', '", textBox6.Text, "', '", textBox7.Text, "', '", dateTimePicker2.Value.ToString("MM/dd/yyyy"), "', '", textBox9.Text, "'); Select @@identity")).Rows[0][0].ToString();
					if (checkBox3.Checked)
					{
						if (PayNaqdy.Checked)
						{
							codes.Edit2("update Stock Set Value= Value + '" + tottextBox.Text + "' where ID = '" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "'");
							codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ( 'زيارة','" + Convert.ToDecimal(tottextBox.Text) + "','" + PatientComboBox.Text + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
						}
						else
						{
							decimal num3 = Convert.ToDecimal(Rased.Text) - Convert.ToDecimal(tottextBox.Text);
							codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ( 'زيارة مدفوعة من رصيد سابق','" + Convert.ToDecimal(tottextBox.Text) + "','" + PatientComboBox.Text + " إيصال رقم: " + EsalNoTxt.Text + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
							codes.Search2(string.Concat("insert into PatientBeforePay (PatientID,Daen,Madeen,Raseed,Bayan,[Date],EsalNum,StockID) values (", PatientComboBox.SelectedValue, ",", Convert.ToDecimal(tottextBox.Text) * -1m, ",0,", num3, ",'زيارة مدفوعة من رصيد سابق','", appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "','0','0')"));
						}
						for (int i = 1; i < dataGridView1.Rows.Count; i++)
						{
							codes.Add2(string.Concat("INSERT INTO PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay,BeanDate,VisitID,Assistant,StockId,ServiceCount,OfferNumUsed, OfferID) VALUES('", Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), "','", Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), "','", dataGridView1.Rows[i - 1].Cells["Service"].Value.ToString(), "','", dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString(), "', 1,'", dataGridView1.Rows[i - 1].Cells["ServiceDate"].Value.ToString(), "','", dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString(), "','", dataGridView1.Rows[i - 1].Cells["ServiceDate"].Value.ToString(), "','", Convert.ToInt32(value2), "','", AssistantcomboBox.Text, "','", Convert.ToInt32(TreasuryCom.SelectedValue.ToString()), "','", dataGridView1.Rows[i - 1].Cells["Count"].Value.ToString(), "',", dataGridView1.Rows[i - 1].Cells[8].Value.ToString(), ",'", dataGridView1.Rows[i - 1].Cells[9].Value, "')"));
							DataTable dataTable2 = codes.Search2("select max(ID) from PatientAccount");
							codes.Add2("insert into AccountDetails (PatientId, DoctorId, Date, Bean, Price, PricePay, PatientAcountId, StockId) values('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','" + dataGridView1.Rows[i - 1].Cells["ServiceDate"].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells["Service"].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString() + "','" + Convert.ToInt32(dataTable2.Rows[0][0].ToString()) + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
							codes.Add2("insert into Esal (EsalNo, PatientAcountId, Date,Assistant) values('" + text2 + "','" + Convert.ToInt32(dataTable2.Rows[0][0].ToString()) + "','" + dataGridView1.Rows[i - 1].Cells["ServiceDate"].Value.ToString() + "','" + AssistantcomboBox.Text + "')");
							if (num2 != 0.0)
							{
								codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + dataGridView1.Rows[i - 1].Cells["Cost"].Value.ToString() + "','" + (Convert.ToDouble(value) + Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Cost"].Value.ToString())) + "','" + dataGridView1.Rows[i - 1].Cells["Service"].Value.ToString() + "'+' - '+'" + PatientComboBox.Text + "'+' - '+'" + doctorcomboBox.Text + "','" + dataGridView1.Rows[i - 1].Cells["ServiceDate"].Value.ToString() + "','" + Convert.ToInt32(dataTable2.Rows[0][0].ToString()) + "')");
							}
						}
						if (dataGridView3.Rows.Count > 0)
						{
							try
							{
								text = codes.Search2(string.Concat("insert into PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay, BeanDate,ServiceCount) values('", PatientComboBox.SelectedValue, "','", doctorcomboBox.SelectedValue, "','سحب كميات اصناف','", num.ToString(), "','True','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "','", num.ToString(), "','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "',1);select @@identity")).Rows[0][0].ToString();
								codes.Add2("insert into AccountDetails (PatientId, DoctorId, Date, Bean, Price, PricePay, PatientAcountId, StockId) values('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','سحب كميات اصناف','" + num.ToString() + "','" + num.ToString() + "','" + text + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
								codes.Add2("insert into Esal (EsalNo, PatientAcountId, Date,Assistant) values('" + text2 + "','" + text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + AssistantcomboBox.Text + "')");
							}
							catch
							{
							}
						}
						try
						{
							if (PayNaqdy.Checked)
							{
								string[] fields = new string[3] { "PatientID", "Pay", "Date" };
								dc.Insert("AddPatientPay", fields, Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), tottextBox.Text, appdateTimePicker1.Value.ToString("MM/dd/yyyy"));
							}
						}
						catch
						{
						}
						b = true;
					}
					else
					{
						for (int i = 1; i < dataGridView1.Rows.Count; i++)
						{
							string text3 = codes.Search2(string.Concat("INSERT INTO PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay,BeanDate,VisitID,Assistant,ServiceCount,OfferNumUsed, OfferID) VALUES('", Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), "','", Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), "','", dataGridView1.Rows[i - 1].Cells["Service"].Value.ToString(), "','", dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString(), "', 0,'", dataGridView1.Rows[i - 1].Cells["ServiceDate"].Value.ToString(), "', 0,'", dataGridView1.Rows[i - 1].Cells["ServiceDate"].Value.ToString(), "','", Convert.ToInt32(value2), "','", AssistantcomboBox.Text, "','", dataGridView1.Rows[i - 1].Cells["Count"].Value.ToString(), "',", dataGridView1.Rows[i - 1].Cells[8].Value.ToString(), ",'", dataGridView1.Rows[i - 1].Cells[9].Value, "');select @@identity")).Rows[0][0].ToString();
							b = true;
							codes.Add2("insert into Esal (EsalNo, PatientAcountId, Date,Assistant) values('" + text2 + "','" + text3 + "','" + dataGridView1.Rows[i - 1].Cells["ServiceDate"].Value.ToString() + "','" + AssistantcomboBox.Text + "')");
							if (num2 != 0.0)
							{
								codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + dataGridView1.Rows[i - 1].Cells["Cost"].Value.ToString() + "','" + (Convert.ToDouble(value) + Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Cost"].Value.ToString())) + "','" + dataGridView1.Rows[i - 1].Cells["Service"].Value.ToString() + "'+' - '+'" + PatientComboBox.Text + "'+' - '+'" + doctorcomboBox.Text + "','" + dataGridView1.Rows[i - 1].Cells["ServiceDate"].Value.ToString() + "','" + text3 + "')");
							}
						}
						if (dataGridView3.Rows.Count > 0)
						{
							try
							{
								text = codes.Search2(string.Concat("insert into PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay, BeanDate,ServiceCount) values('", PatientComboBox.SelectedValue, "','", doctorcomboBox.SelectedValue, "','سحب كميات اصناف','", num.ToString(), "','False','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "',0,'", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "',1);select @@identity")).Rows[0][0].ToString();
								codes.Add2("insert into Esal (EsalNo, PatientAcountId, Date,Assistant) values('" + text2 + "','" + text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + AssistantcomboBox.Text + "')");
							}
							catch
							{
							}
						}
					}
					if (b)
					{
						try
						{
							codes.Edit2("update PatientData set LastVistDate='" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "'");
						}
						catch
						{
						}
						try
						{
							if (dataGridView3.Rows.Count > 0)
							{
								codes.Add2(string.Concat("insert into Sahb (PatientId, Date,PatientAccountId) values('", PatientComboBox.SelectedValue, "','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "','", text, "')"));
								string text4 = codes.Search2("select max(ID) from Sahb").Rows[0][0].ToString();
								for (int i = 0; i < dataGridView3.Rows.Count; i++)
								{
									decimal num4 = 0m;
									try
									{
										DataTable dataTable3 = codes.Search2("select Qnt from store where ItemID='" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "'");
										num4 = Convert.ToDecimal(dataTable3.Rows[0][0].ToString());
									}
									catch
									{
									}
									decimal num5 = 0m;
									try
									{
										DataTable dataTable4 = codes.Search2("select BuyPrice from store where ItemID='" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "'");
										num5 = Convert.ToDecimal(dataTable4.Rows[0][0].ToString());
									}
									catch
									{
									}
									decimal num6 = 0m;
									try
									{
										DataTable dataTable5 = codes.Search2("select SalePrice from Items where ID='" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "'");
										num6 = Convert.ToDecimal(dataTable5.Rows[0][0].ToString());
									}
									catch
									{
									}
									codes.Add2("INSERT INTO ItemsMove\r\n                      (ItemId, StoreId, IncomeQnt, IncomePrice, OutcomeQnt, OutcomePrice, LastQnt, LastIncomePrice, LastOutComePrice, Bayan, MoveDate, UserId, Time,Type)\r\n                       VALUES ('" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "',0,0,0,'" + dataGridView3.Rows[i].Cells[2].Value.ToString() + "','" + dataGridView3.Rows[i].Cells[1].Value.ToString() + "','" + num4 + "','" + num5 + "','" + num6 + "','كشوفات','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Main.userId + "','" + dateTimePicker1.Value.ToShortTimeString() + "','خروج')");
									codes.Add2("insert into Sahb_details (SahbId, ItemId, Price, Qty) values('" + text4 + "','" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "','" + dataGridView3.Rows[i].Cells[1].Value.ToString() + "','" + dataGridView3.Rows[i].Cells[2].Value.ToString() + "')");
									codes.Edit2("update Store set Qnt = Qnt - '" + dataGridView3.Rows[i].Cells[2].Value.ToString() + "' where ItemId = '" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "'");
									codes.Add2("insert into SahbItem (TypeSahb, ItemId, Qty, Date, Notes) values('استهلاك مرضى','" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "','" + dataGridView3.Rows[i].Cells[2].Value.ToString() + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','')");
								}
							}
						}
						catch
						{
						}
						MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						MethodsClass.UserMove("تسجيل زيارة لمريض");
						if (checkBox3.Checked)
						{
							ds.Clear();
							DataTable tableText = dc.GetTableText("select ClinicType from DentalData ");
							Convert.ToBoolean(tableText.Rows[0][0]);
							string text5 = "";
							DataTable dataTable6 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
							try
							{
								text5 = dataTable6.Rows[0][0].ToString();
							}
							catch
							{
							}
							for (int i = 1; i < dataGridView1.Rows.Count; i++)
							{
								((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, dataGridView1.Rows[i - 1].Cells["ServiceDate"].Value.ToString(), dataGridView1.Rows[i - 1].Cells["Service"].Value.ToString(), tottextBox.Text, dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString(), dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString(), dataGridView1.Rows[i - 1].Cells["Teethn"].Value.ToString(), text5, Main.usernames, "", Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Count"].Value), Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Price"].Value) / Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Count"].Value));
							}
							for (int j = 0; j < dataGridView3.Rows.Count; j++)
							{
								string text6 = (Convert.ToDecimal(dataGridView3.Rows[j].Cells[2].Value.ToString()) * Convert.ToDecimal(dataGridView3.Rows[j].Cells[1].Value.ToString())).ToString();
								((DataTable)(object)ds.SahbItemEsal).Rows.Add(dataGridView3.Rows[j].Cells[0].Value.ToString(), dataGridView3.Rows[j].Cells[2].Value.ToString(), dataGridView3.Rows[j].Cells[1].Value.ToString(), text6);
							}
							sqlConnection1.ConnectionString = codes.ConnectionStr;
							sqlDataAdapter1.Fill(ds);
							sqlConnection2.ConnectionString = Codes.ConnectionStr;
							sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
							sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
							sqlDataAdapter2.Fill(ds);
							DataTable dataTable7 = Codes.Search2("select EsalPrinter from Properties");
							string text7 = dataTable7.Rows[0][0].ToString();
							if (text7 == "A5")
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptA5.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = "0";
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = "0";
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
								statmentRptFrm.ShowDialog();
							}
							else
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = "0";
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = "0";
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								reportDocument.SetParameterValue("Assistant", AssistantcomboBox.Text);
								StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
								statmentRptFrm.ShowDialog();
							}
						}
						dataGridView1.Rows.Clear();
						try
						{
							string[] fields2 = new string[1] { "ID" };
							dc.Update("updateTrueVisit", fields2, appointid);
						}
						catch
						{
						}
						done = true;
						Close();
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				else
				{
					MessageBox.Show("لا يوجد بيانات للحفظ", "تنبيه");
				}
				GetBean();
				end_IL_0001:;
			}
			catch
			{
			}
		}

		private void PatientAccount_FormClosing(object sender, FormClosingEventArgs e)
		{
			try
			{
				if (!done)
				{
					if (MessageBox.Show("تم الفحص", "تنبيه", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
					{
						string[] fields = new string[1] { "ID" };
						b = dc.Update("updateTrueVisit", fields, appointid);
						if (b)
						{
							MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
					}
					else
					{
						e.Cancel = false;
					}
				}
				else
				{
					e.Cancel = false;
				}
			}
			catch
			{
			}
		}

		private void PatientAccount_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			OldServiceProvidedFrm oldServiceProvidedFrm = new OldServiceProvidedFrm(patientid);
			oldServiceProvidedFrm.ShowDialog();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			FrmImage frmImage = new FrmImage(patientid);
			frmImage.ShowDialog();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			PatientPayAccount patientPayAccount = new PatientPayAccount(patientid);
			patientPayAccount.ShowDialog();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			try
			{
				PationtInfo pationtInfo = new PationtInfo(patientid);
				pationtInfo.ShowDialog();
			}
			catch
			{
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			PrescriptionFrm prescriptionFrm = new PrescriptionFrm(patientid);
			prescriptionFrm.Show();
		}

		private void button6_Click(object sender, EventArgs e)
		{
			CommentFrm commentFrm = new CommentFrm(patientid);
			commentFrm.ShowDialog();
		}

		public void VistaColor(VistaButton vis)
		{
			if (vis.ButtonColor == Color.Red)
			{
				vis.ButtonColor = Color.LightGray;
				vis.BackColor = Color.Maroon;
			}
			else
			{
				vis.ButtonColor = Color.Red;
				vis.BackColor = Color.Red;
			}
		}

		private void commentTextBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("select isnull(sum(Daen),0) from PatientBeforePay where PatientID=" + PatientComboBox.SelectedValue);
				Rased.Text = Math.Round(Convert.ToDecimal(dataTable.Rows[0][0]), 2).ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("SELECT dbo.Company.Name,dbo.Company.ID,dbo.Company.Status,dbo.Company.Discount,dbo.Company.Nesba\r\nFROM         dbo.Company INNER JOIN\r\n                      dbo.PatientData ON dbo.Company.ID = dbo.PatientData.company where PatientData.ID='" + PatientComboBox.SelectedValue.ToString() + "'");
				string text = dataTable.Rows[0][2].ToString();
				companyId = dataTable.Rows[0][1].ToString();
				DataTable dataTable2 = codes.Search2(string.Concat("select Price from CompanyService where Service='", commentTextBox.Text, "' and CompanyID = '", comboCategory.SelectedValue, "'"));
				if (dataTable2.Rows.Count > 0)
				{
					if (text == "1")
					{
						if (Convert.ToBoolean(dataTable.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(dataTable.Rows[0][3]) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = Convert.ToDouble(dataTable.Rows[0][3]).ToString();
						}
						PricetextBox.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text == "2")
					{
						string text2 = codes.Search2("SELECT dbo.DiscountCategory.Discount FROM DiscountCategory where Category = '" + comboCategory.Text + "'").Rows[0][0].ToString();
						if (Convert.ToBoolean(dataTable.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(text2) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = text2;
						}
						PricetextBox.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text == "3")
					{
						string text2 = codes.Search2("SELECT     Discount\r\nFROM         dbo.DiscountService where Service = '" + commentTextBox.Text + "'").Rows[0][0].ToString();
						if (Convert.ToBoolean(dataTable.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(text2) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = text2;
						}
						PricetextBox.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text == "4")
					{
						PricetextBox.Text = dataTable2.Rows[0][0].ToString();
						CompanyPrice = "0";
					}
				}
				else
				{
					PricetextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void appdateTimePicker1_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Friday)
				{
					textBox3.Text = "الجمعة";
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Monday)
				{
					textBox3.Text = "الإثنين";
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Saturday)
				{
					textBox3.Text = "السبت";
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Sunday)
				{
					textBox3.Text = "الأحد";
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Thursday)
				{
					textBox3.Text = "الخميس";
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Tuesday)
				{
					textBox3.Text = "الثلاثاء";
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Wednesday)
				{
					textBox3.Text = "الأربعاء";
				}
			}
			catch
			{
			}
		}

		private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				if (dateTimePicker2.Value.DayOfWeek == DayOfWeek.Friday)
				{
					textBox8.Text = "الجمعة";
				}
				else if (dateTimePicker2.Value.DayOfWeek == DayOfWeek.Monday)
				{
					textBox8.Text = "الإثنين";
				}
				else if (dateTimePicker2.Value.DayOfWeek == DayOfWeek.Saturday)
				{
					textBox8.Text = "السبت";
				}
				else if (dateTimePicker2.Value.DayOfWeek == DayOfWeek.Sunday)
				{
					textBox8.Text = "الأحد";
				}
				else if (dateTimePicker2.Value.DayOfWeek == DayOfWeek.Thursday)
				{
					textBox8.Text = "الخميس";
				}
				else if (dateTimePicker2.Value.DayOfWeek == DayOfWeek.Tuesday)
				{
					textBox8.Text = "الثلاثاء";
				}
				else if (dateTimePicker2.Value.DayOfWeek == DayOfWeek.Wednesday)
				{
					textBox8.Text = "الأربعاء";
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
		{
		}

		private void button16_Click(object sender, EventArgs e)
		{
			FrmSahbAmount frmSahbAmount = new FrmSahbAmount(Convert.ToInt32(PatientComboBox.SelectedValue), Convert.ToInt32(doctorcomboBox.SelectedValue));
			frmSahbAmount.ShowDialog();
		}

		private void checkBox3_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox3.Checked)
			{
				PayBefore.Visible = true;
				PayNaqdy.Visible = true;
				PaidPanel.Visible = true;
			}
			else
			{
				PaidPanel.Visible = false;
				PayBefore.Visible = false;
				PayNaqdy.Visible = false;
			}
		}

		private void itemIdComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				if (itemIdComboBox.SelectedIndex == -1)
				{
					txtStore.Text = "0";
					floatText1.Text = "0";
					return;
				}
				DataTable dataTable = codes.Search2(string.Concat("SELECT     dbo.Store.Qnt, dbo.Items.SalePrice, dbo.Store.BuyPrice\r\nFROM         dbo.Items INNER JOIN\r\n                      dbo.Store ON dbo.Items.Id = dbo.Store.ItemId where dbo.Store.ItemId='", itemIdComboBox.SelectedValue, "'"));
				txtStore.Text = dataTable.Rows[0][0].ToString();
				floatText1.Text = dataTable.Rows[0][1].ToString();
				BuyPrice = dataTable.Rows[0][2].ToString();
			}
			catch
			{
			}
		}

		private void button17_Click(object sender, EventArgs e)
		{
			if (itemIdComboBox.SelectedIndex == -1)
			{
				MessageBox.Show("من فضلك ادخل اسم الصنف");
				return;
			}
			if (txtQty.Text == "0")
			{
				MessageBox.Show("من فضلك ادخل الكمية");
				return;
			}
			if (Convert.ToDecimal(txtQty.Text) > Convert.ToDecimal(txtStore.Text))
			{
				MessageBox.Show("الكمية اكبر من المخزون");
				return;
			}
			if (Convert.ToDecimal(floatText1.Text) < Convert.ToDecimal(BuyPrice))
			{
				MessageBox.Show("سعر البيع اقل من سعر الشراء");
			}
			bool flag = false;
			if (dataGridView3.Rows.Count == 0)
			{
				dataGridView3.Rows.Add(itemIdComboBox.Text, floatText1.Text, txtQty.Text, itemIdComboBox.SelectedValue.ToString(), (Convert.ToDouble(floatText1.Text) * Convert.ToDouble(txtQty.Text)).ToString());
				tottextBox.Text = (Convert.ToDouble(tottextBox.Text) + Convert.ToDouble(floatText1.Text) * Convert.ToDouble(txtQty.Text)).ToString();
				return;
			}
			for (int i = 0; i < dataGridView3.Rows.Count; i++)
			{
				if (itemIdComboBox.Text == dataGridView3.Rows[i].Cells[0].Value.ToString())
				{
					flag = true;
					break;
				}
			}
			if (flag)
			{
				MessageBox.Show("تم ادخال اسم الصنف قبل ");
				return;
			}
			dataGridView3.Rows.Add(itemIdComboBox.Text, floatText1.Text, txtQty.Text, itemIdComboBox.SelectedValue.ToString(), (Convert.ToDouble(floatText1.Text) * Convert.ToDouble(txtQty.Text)).ToString());
			tottextBox.Text = (Convert.ToDouble(tottextBox.Text) + Convert.ToDouble(floatText1.Text) * Convert.ToDouble(txtQty.Text)).ToString();
		}

		private void button7_Click(object sender, EventArgs e)
		{
			FrmAnalyzes frmAnalyzes = new FrmAnalyzes(patientid);
			frmAnalyzes.ShowDialog();
		}

		private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				commentTextBox.DataSource = null;
				string text = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
				DataTable dataTable = codes.Search2(string.Concat("select Service from CompanyService where CompanyID = '", comboCategory.SelectedValue, "' and Service != '", text, "'"));
				commentTextBox.DataSource = dataTable;
				commentTextBox.DisplayMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void EsalNoTxt_KeyPress(object sender, KeyPressEventArgs e)
		{
			if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
			{
				if (e.KeyChar == '.' && EsalNoTxt.Text.Contains("."))
				{
					e.Handled = true;
				}
			}
			else
			{
				e.Handled = true;
				MessageBox.Show("من فضلك أدخل رقم الإيصال بالارقام");
			}
		}

		private void groupBox4_Enter(object sender, EventArgs e)
		{
		}

		private void radioButton5_CheckedChanged(object sender, EventArgs e)
		{
			if (radioButton5.Checked)
			{
				groupBox3.Visible = true;
				groupBox29.Visible = false;
				dataGridView1.Columns[7].Visible = false;
				dataGridView1.Columns[8].Visible = false;
				dataGridView1.Columns[6].Visible = false;
			}
			else
			{
				groupBox3.Visible = false;
				groupBox29.Visible = true;
				dataGridView1.Columns[6].Visible = true;
				dataGridView1.Columns[7].Visible = true;
				dataGridView1.Columns[8].Visible = true;
			}
		}

		private void button23_Click(object sender, EventArgs e)
		{
			try
			{
				if (OfferName.Text != "")
				{
					DataTable dataTable = Codes.Search2(string.Concat("select ServiceID,Servicename ,serviceNum ,ServicePrice from Offers where OfferID='", OfferName.SelectedValue, "'"));
					for (int i = 0; i < dataTable.Rows.Count; i++)
					{
						DataTable dataTable2 = Codes.Search2(string.Concat("select isnull(sum(OfferNumUsed),0) from PatientAccount where OfferID='", OfferName.SelectedValue, "' and Bean='", dataTable.Rows[i]["Servicename"].ToString(), "' and PatientId='", PatientComboBox.SelectedValue, "'"));
						dataGridView1.Rows.Add(dataTable.Rows[i][1].ToString(), Convert.ToDouble(dataTable.Rows[i][3].ToString()), dateTimePicker1.Value.ToString("yyyy/MM/dd"), "General", "33", 0, dataTable.Rows[i][2].ToString(), dataTable2.Rows[0][0].ToString(), 0, OfferName.SelectedValue);
					}
					b = true;
					total = Convert.ToDouble(tottextBox.Text);
					total += Convert.ToDouble(OfferPrice.Text);
					tottextBox.Text = total.ToString();
					commentTextBox.Text = "";
					PricetextBox.Text = "0";
					floatText5.Text = "1";
					AssistantcomboBox.Enabled = false;
				}
				else
				{
					MessageBox.Show("من فضلك ادخل العرض", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void OfferName_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2(string.Concat("select Price from Offers where OfferID='", OfferName.SelectedValue, "'"));
				OfferPrice.Text = dataTable.Rows[0][0].ToString();
			}
			catch
			{
			}
		}

		private void PayNaqdy_CheckedChanged(object sender, EventArgs e)
		{
			if (PayNaqdy.Checked)
			{
				DataTable dataTable = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				if (dataTable.Rows.Count > 0)
				{
					PaidPanel.Visible = true;
					return;
				}
				PaidPanel.Visible = false;
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please add Treasury validity");
				}
				else
				{
					MessageBox.Show("من فضلك اضف صلاحية للخزينة");
				}
			}
			else
			{
				PaidPanel.Visible = false;
			}
		}

		private void PayBefore_CheckedChanged(object sender, EventArgs e)
		{
			if (PayBefore.Checked && (Rased.Text == "0.00" || Rased.Text == "0"))
			{
				MessageBox.Show("لا يمكن الدفع من رصيد سابق لان الرصيد السابق للمريض بصفر");
			}
		}

		private void groupBox5_Enter(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmVisit));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			groupBox4 = new System.Windows.Forms.GroupBox();
			Rased = new System.Windows.Forms.TextBox();
			groupBox29 = new System.Windows.Forms.GroupBox();
			OfferName = new System.Windows.Forms.ComboBox();
			OfferPrice = new System.Windows.Forms.TextBox();
			button23 = new System.Windows.Forms.Button();
			dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
			radioButton5 = new System.Windows.Forms.RadioButton();
			radioButton6 = new System.Windows.Forms.RadioButton();
			AssistantcomboBox = new System.Windows.Forms.ComboBox();
			textBox8 = new System.Windows.Forms.TextBox();
			dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			groupBox3 = new System.Windows.Forms.GroupBox();
			floatText5 = new FloatTextBox.FloatText();
			comboCategory = new System.Windows.Forms.ComboBox();
			commentTextBox = new System.Windows.Forms.ComboBox();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			PricetextBox = new System.Windows.Forms.TextBox();
			ADDBtn = new System.Windows.Forms.Button();
			textBox3 = new System.Windows.Forms.TextBox();
			button4 = new System.Windows.Forms.Button();
			appdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			PatientComboBox = new System.Windows.Forms.ComboBox();
			groupBox1 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox5 = new System.Windows.Forms.GroupBox();
			button7 = new System.Windows.Forms.Button();
			saveBtn = new System.Windows.Forms.Button();
			button6 = new System.Windows.Forms.Button();
			button5 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			button16 = new System.Windows.Forms.Button();
			tottextBox = new System.Windows.Forms.TextBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			this.label7 = new System.Windows.Forms.Label();
			groupBox6 = new System.Windows.Forms.GroupBox();
			textBox9 = new System.Windows.Forms.TextBox();
			textBox7 = new System.Windows.Forms.TextBox();
			textBox6 = new System.Windows.Forms.TextBox();
			textBox5 = new System.Windows.Forms.TextBox();
			textBox4 = new System.Windows.Forms.TextBox();
			textBox2 = new System.Windows.Forms.TextBox();
			textBox1 = new System.Windows.Forms.TextBox();
			checkBox3 = new System.Windows.Forms.CheckBox();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			groupBox7 = new System.Windows.Forms.GroupBox();
			txtQty = new FloatTextBox.FloatText();
			label72 = new System.Windows.Forms.Label();
			floatText1 = new FloatTextBox.FloatText();
			label71 = new System.Windows.Forms.Label();
			button17 = new System.Windows.Forms.Button();
			label70 = new System.Windows.Forms.Label();
			txtStore = new System.Windows.Forms.TextBox();
			itemIdComboBox = new System.Windows.Forms.ComboBox();
			groupBox22 = new System.Windows.Forms.GroupBox();
			dataGridView3 = new System.Windows.Forms.DataGridView();
			PaidPanel = new System.Windows.Forms.Panel();
			TreasuryCom = new System.Windows.Forms.ComboBox();
			EsalNoTxt = new System.Windows.Forms.TextBox();
			lblTreasury = new System.Windows.Forms.Label();
			label45 = new System.Windows.Forms.Label();
			PayNaqdy = new System.Windows.Forms.RadioButton();
			PayBefore = new System.Windows.Forms.RadioButton();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			Service = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ServiceDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Teethn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			TiD = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Cost = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Count = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ItemId = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label7 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label8 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label9 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label10 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label11 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label12 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label13 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label14 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label15 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label16 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label17 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label18 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label19 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label20 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label21 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label22 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label23 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label24 = new System.Windows.Forms.Label();
			groupBox4.SuspendLayout();
			groupBox29.SuspendLayout();
			groupBox3.SuspendLayout();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox5.SuspendLayout();
			groupBox2.SuspendLayout();
			groupBox6.SuspendLayout();
			groupBox7.SuspendLayout();
			groupBox22.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
			PaidPanel.SuspendLayout();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "titelLabel");
			label.Name = "titelLabel";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label1");
			label2.Name = "label1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label2");
			label3.Name = "label2";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "nameLabel");
			label4.Name = "nameLabel";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "addressLabel");
			label5.Name = "addressLabel";
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "label3");
			label6.BackColor = System.Drawing.Color.Transparent;
			label6.ForeColor = System.Drawing.Color.Firebrick;
			label6.Name = "label3";
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "label4");
			label7.Name = "label4";
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "label8");
			label8.Name = "label8";
			label9.AccessibleDescription = null;
			label9.AccessibleName = null;
			resources.ApplyResources(label9, "label5");
			label9.BackColor = System.Drawing.Color.Transparent;
			label9.Name = "label5";
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "label6");
			label10.BackColor = System.Drawing.Color.Transparent;
			label10.Name = "label6";
			label11.AccessibleDescription = null;
			label11.AccessibleName = null;
			resources.ApplyResources(label11, "label9");
			label11.BackColor = System.Drawing.Color.Transparent;
			label11.Name = "label9";
			label12.AccessibleDescription = null;
			label12.AccessibleName = null;
			resources.ApplyResources(label12, "label11");
			label12.BackColor = System.Drawing.Color.Transparent;
			label12.Name = "label11";
			label13.AccessibleDescription = null;
			label13.AccessibleName = null;
			resources.ApplyResources(label13, "label12");
			label13.BackColor = System.Drawing.Color.Transparent;
			label13.Name = "label12";
			label14.AccessibleDescription = null;
			label14.AccessibleName = null;
			resources.ApplyResources(label14, "label13");
			label14.BackColor = System.Drawing.Color.Transparent;
			label14.Name = "label13";
			label15.AccessibleDescription = null;
			label15.AccessibleName = null;
			resources.ApplyResources(label15, "label10");
			label15.Name = "label10";
			label16.AccessibleDescription = null;
			label16.AccessibleName = null;
			resources.ApplyResources(label16, "label14");
			label16.Name = "label14";
			label17.AccessibleDescription = null;
			label17.AccessibleName = null;
			resources.ApplyResources(label17, "label15");
			label17.BackColor = System.Drawing.Color.Transparent;
			label17.Name = "label15";
			label18.AccessibleDescription = null;
			label18.AccessibleName = null;
			resources.ApplyResources(label18, "label40");
			label18.Name = "label40";
			label19.AccessibleDescription = null;
			label19.AccessibleName = null;
			resources.ApplyResources(label19, "label82");
			label19.Name = "label82";
			label20.AccessibleDescription = null;
			label20.AccessibleName = null;
			resources.ApplyResources(label20, "label83");
			label20.Name = "label83";
			label21.AccessibleDescription = null;
			label21.AccessibleName = null;
			resources.ApplyResources(label21, "label115");
			label21.Name = "label115";
			label22.AccessibleDescription = null;
			label22.AccessibleName = null;
			resources.ApplyResources(label22, "label116");
			label22.Name = "label116";
			label23.AccessibleDescription = null;
			label23.AccessibleName = null;
			resources.ApplyResources(label23, "label117");
			label23.Name = "label117";
			label24.AccessibleDescription = null;
			label24.AccessibleName = null;
			resources.ApplyResources(label24, "label110");
			label24.Name = "label110";
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(label24);
			groupBox4.Controls.Add(Rased);
			groupBox4.Controls.Add(radioButton5);
			groupBox4.Controls.Add(radioButton6);
			groupBox4.Controls.Add(AssistantcomboBox);
			groupBox4.Controls.Add(label18);
			groupBox4.Controls.Add(textBox8);
			groupBox4.Controls.Add(label15);
			groupBox4.Controls.Add(dateTimePicker2);
			groupBox4.Controls.Add(label16);
			groupBox4.Controls.Add(textBox3);
			groupBox4.Controls.Add(label8);
			groupBox4.Controls.Add(button4);
			groupBox4.Controls.Add(appdateTimePicker1);
			groupBox4.Controls.Add(label5);
			groupBox4.Controls.Add(doctorcomboBox);
			groupBox4.Controls.Add(label4);
			groupBox4.Controls.Add(label);
			groupBox4.Controls.Add(PatientComboBox);
			groupBox4.Controls.Add(groupBox29);
			groupBox4.Controls.Add(groupBox3);
			groupBox4.ForeColor = System.Drawing.Color.Black;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			groupBox4.Enter += new System.EventHandler(groupBox4_Enter);
			Rased.AccessibleDescription = null;
			Rased.AccessibleName = null;
			resources.ApplyResources(Rased, "Rased");
			Rased.BackColor = System.Drawing.Color.White;
			Rased.BackgroundImage = null;
			Rased.Font = null;
			Rased.ForeColor = System.Drawing.Color.Black;
			Rased.Name = "Rased";
			Rased.ReadOnly = true;
			groupBox29.AccessibleDescription = null;
			groupBox29.AccessibleName = null;
			resources.ApplyResources(groupBox29, "groupBox29");
			groupBox29.BackColor = System.Drawing.Color.Transparent;
			groupBox29.BackgroundImage = null;
			groupBox29.Controls.Add(OfferName);
			groupBox29.Controls.Add(label21);
			groupBox29.Controls.Add(label22);
			groupBox29.Controls.Add(label23);
			groupBox29.Controls.Add(OfferPrice);
			groupBox29.Controls.Add(button23);
			groupBox29.Controls.Add(dateTimePicker4);
			groupBox29.Name = "groupBox29";
			groupBox29.TabStop = false;
			OfferName.AccessibleDescription = null;
			OfferName.AccessibleName = null;
			resources.ApplyResources(OfferName, "OfferName");
			OfferName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			OfferName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			OfferName.BackgroundImage = null;
			OfferName.FormattingEnabled = true;
			OfferName.Name = "OfferName";
			OfferName.SelectedIndexChanged += new System.EventHandler(OfferName_SelectedIndexChanged);
			OfferPrice.AccessibleDescription = null;
			OfferPrice.AccessibleName = null;
			resources.ApplyResources(OfferPrice, "OfferPrice");
			OfferPrice.BackgroundImage = null;
			OfferPrice.Name = "OfferPrice";
			button23.AccessibleDescription = null;
			button23.AccessibleName = null;
			resources.ApplyResources(button23, "button23");
			button23.BackColor = System.Drawing.Color.Gainsboro;
			button23.BackgroundImage = null;
			button23.Name = "button23";
			button23.UseVisualStyleBackColor = false;
			button23.Click += new System.EventHandler(button23_Click);
			dateTimePicker4.AccessibleDescription = null;
			dateTimePicker4.AccessibleName = null;
			resources.ApplyResources(dateTimePicker4, "dateTimePicker4");
			dateTimePicker4.BackgroundImage = null;
			dateTimePicker4.CalendarFont = null;
			dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker4.Name = "dateTimePicker4";
			radioButton5.AccessibleDescription = null;
			radioButton5.AccessibleName = null;
			resources.ApplyResources(radioButton5, "radioButton5");
			radioButton5.BackgroundImage = null;
			radioButton5.Checked = true;
			radioButton5.Name = "radioButton5";
			radioButton5.TabStop = true;
			radioButton5.UseVisualStyleBackColor = true;
			radioButton5.CheckedChanged += new System.EventHandler(radioButton5_CheckedChanged);
			radioButton6.AccessibleDescription = null;
			radioButton6.AccessibleName = null;
			resources.ApplyResources(radioButton6, "radioButton6");
			radioButton6.BackgroundImage = null;
			radioButton6.Name = "radioButton6";
			radioButton6.UseVisualStyleBackColor = true;
			AssistantcomboBox.AccessibleDescription = null;
			AssistantcomboBox.AccessibleName = null;
			resources.ApplyResources(AssistantcomboBox, "AssistantcomboBox");
			AssistantcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			AssistantcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			AssistantcomboBox.BackgroundImage = null;
			AssistantcomboBox.FormattingEnabled = true;
			AssistantcomboBox.Name = "AssistantcomboBox";
			textBox8.AccessibleDescription = null;
			textBox8.AccessibleName = null;
			resources.ApplyResources(textBox8, "textBox8");
			textBox8.BackColor = System.Drawing.Color.White;
			textBox8.BackgroundImage = null;
			textBox8.Font = null;
			textBox8.Name = "textBox8";
			textBox8.ReadOnly = true;
			dateTimePicker2.AccessibleDescription = null;
			dateTimePicker2.AccessibleName = null;
			resources.ApplyResources(dateTimePicker2, "dateTimePicker2");
			dateTimePicker2.BackgroundImage = null;
			dateTimePicker2.CalendarFont = null;
			dateTimePicker2.Font = null;
			dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker2.Name = "dateTimePicker2";
			dateTimePicker2.ValueChanged += new System.EventHandler(dateTimePicker2_ValueChanged);
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(floatText5);
			groupBox3.Controls.Add(label20);
			groupBox3.Controls.Add(comboCategory);
			groupBox3.Controls.Add(label19);
			groupBox3.Controls.Add(commentTextBox);
			groupBox3.Controls.Add(label2);
			groupBox3.Controls.Add(dateTimePicker1);
			groupBox3.Controls.Add(label7);
			groupBox3.Controls.Add(PricetextBox);
			groupBox3.Controls.Add(ADDBtn);
			groupBox3.Controls.Add(label3);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			floatText5.AccessibleDescription = null;
			floatText5.AccessibleName = null;
			resources.ApplyResources(floatText5, "floatText5");
			floatText5.BackgroundImage = null;
			floatText5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText5.Name = "floatText5";
			comboCategory.AccessibleDescription = null;
			comboCategory.AccessibleName = null;
			resources.ApplyResources(comboCategory, "comboCategory");
			comboCategory.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboCategory.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboCategory.BackgroundImage = null;
			comboCategory.FormattingEnabled = true;
			comboCategory.Name = "comboCategory";
			comboCategory.SelectedIndexChanged += new System.EventHandler(comboCategory_SelectedIndexChanged);
			commentTextBox.AccessibleDescription = null;
			commentTextBox.AccessibleName = null;
			resources.ApplyResources(commentTextBox, "commentTextBox");
			commentTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			commentTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			commentTextBox.BackgroundImage = null;
			commentTextBox.FormattingEnabled = true;
			commentTextBox.Name = "commentTextBox";
			commentTextBox.SelectedIndexChanged += new System.EventHandler(commentTextBox_SelectedIndexChanged);
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			PricetextBox.AccessibleDescription = null;
			PricetextBox.AccessibleName = null;
			resources.ApplyResources(PricetextBox, "PricetextBox");
			PricetextBox.BackgroundImage = null;
			PricetextBox.Name = "PricetextBox";
			PricetextBox.Leave += new System.EventHandler(PricetextBox_Leave);
			PricetextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(PricetextBox_KeyPress);
			ADDBtn.AccessibleDescription = null;
			ADDBtn.AccessibleName = null;
			resources.ApplyResources(ADDBtn, "ADDBtn");
			ADDBtn.BackColor = System.Drawing.Color.Gainsboro;
			ADDBtn.BackgroundImage = null;
			ADDBtn.Name = "ADDBtn";
			ADDBtn.UseVisualStyleBackColor = false;
			ADDBtn.Click += new System.EventHandler(ADDBtn_Click);
			textBox3.AccessibleDescription = null;
			textBox3.AccessibleName = null;
			resources.ApplyResources(textBox3, "textBox3");
			textBox3.BackColor = System.Drawing.Color.White;
			textBox3.BackgroundImage = null;
			textBox3.Font = null;
			textBox3.Name = "textBox3";
			textBox3.ReadOnly = true;
			button4.AccessibleDescription = null;
			button4.AccessibleName = null;
			resources.ApplyResources(button4, "button4");
			button4.BackColor = System.Drawing.Color.Gainsboro;
			button4.BackgroundImage = null;
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = false;
			button4.Click += new System.EventHandler(button4_Click);
			appdateTimePicker1.AccessibleDescription = null;
			appdateTimePicker1.AccessibleName = null;
			resources.ApplyResources(appdateTimePicker1, "appdateTimePicker1");
			appdateTimePicker1.BackgroundImage = null;
			appdateTimePicker1.CalendarFont = null;
			appdateTimePicker1.Font = null;
			appdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			appdateTimePicker1.Name = "appdateTimePicker1";
			appdateTimePicker1.ValueChanged += new System.EventHandler(appdateTimePicker1_ValueChanged);
			doctorcomboBox.AccessibleDescription = null;
			doctorcomboBox.AccessibleName = null;
			resources.ApplyResources(doctorcomboBox, "doctorcomboBox");
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.BackgroundImage = null;
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Name = "doctorcomboBox";
			PatientComboBox.AccessibleDescription = null;
			PatientComboBox.AccessibleName = null;
			resources.ApplyResources(PatientComboBox, "PatientComboBox");
			PatientComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			PatientComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientComboBox.BackgroundImage = null;
			PatientComboBox.FormattingEnabled = true;
			PatientComboBox.Name = "PatientComboBox";
			PatientComboBox.SelectedIndexChanged += new System.EventHandler(commentTextBox_SelectedIndexChanged);
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(dataGridView1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridViewCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(Service, Price, ServiceDate, Teethn, TiD, Cost, Count, Column1, Column2, Column4);
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
			dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
			dataGridView1.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(dataGridView1_RowsAdded);
			dataGridView1.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(dataGridView1_RowsRemoved);
			groupBox5.AccessibleDescription = null;
			groupBox5.AccessibleName = null;
			resources.ApplyResources(groupBox5, "groupBox5");
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.BackgroundImage = null;
			groupBox5.Controls.Add(button7);
			groupBox5.Controls.Add(saveBtn);
			groupBox5.Controls.Add(button6);
			groupBox5.Controls.Add(button5);
			groupBox5.Controls.Add(button1);
			groupBox5.Controls.Add(button2);
			groupBox5.Controls.Add(button3);
			groupBox5.Font = null;
			groupBox5.Name = "groupBox5";
			groupBox5.TabStop = false;
			groupBox5.Enter += new System.EventHandler(groupBox5_Enter);
			button7.AccessibleDescription = null;
			button7.AccessibleName = null;
			resources.ApplyResources(button7, "button7");
			button7.BackColor = System.Drawing.Color.Gainsboro;
			button7.BackgroundImage = null;
			button7.Name = "button7";
			button7.UseVisualStyleBackColor = false;
			button7.Click += new System.EventHandler(button7_Click);
			saveBtn.AccessibleDescription = null;
			saveBtn.AccessibleName = null;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			saveBtn.BackgroundImage = null;
			saveBtn.Name = "saveBtn";
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			button6.AccessibleDescription = null;
			button6.AccessibleName = null;
			resources.ApplyResources(button6, "button6");
			button6.BackColor = System.Drawing.Color.Gainsboro;
			button6.BackgroundImage = null;
			button6.Name = "button6";
			button6.UseVisualStyleBackColor = false;
			button6.Click += new System.EventHandler(button6_Click);
			button5.AccessibleDescription = null;
			button5.AccessibleName = null;
			resources.ApplyResources(button5, "button5");
			button5.BackColor = System.Drawing.Color.Gainsboro;
			button5.BackgroundImage = null;
			button5.Name = "button5";
			button5.UseVisualStyleBackColor = false;
			button5.Click += new System.EventHandler(button5_Click);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.BackgroundImage = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackColor = System.Drawing.Color.Gainsboro;
			button2.BackgroundImage = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = false;
			button2.Click += new System.EventHandler(button2_Click);
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackColor = System.Drawing.Color.Gainsboro;
			button3.BackgroundImage = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = false;
			button3.Click += new System.EventHandler(button3_Click);
			button16.AccessibleDescription = null;
			button16.AccessibleName = null;
			resources.ApplyResources(button16, "button16");
			button16.BackColor = System.Drawing.Color.Gainsboro;
			button16.BackgroundImage = null;
			button16.Name = "button16";
			button16.UseVisualStyleBackColor = false;
			button16.Click += new System.EventHandler(button16_Click);
			tottextBox.AccessibleDescription = null;
			tottextBox.AccessibleName = null;
			resources.ApplyResources(tottextBox, "tottextBox");
			tottextBox.BackColor = System.Drawing.Color.White;
			tottextBox.BackgroundImage = null;
			tottextBox.ForeColor = System.Drawing.Color.Maroon;
			tottextBox.Name = "tottextBox";
			tottextBox.ReadOnly = true;
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(this.label7);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			this.label7.AccessibleDescription = null;
			this.label7.AccessibleName = null;
			resources.ApplyResources(this.label7, "label7");
			this.label7.Name = "label7";
			groupBox6.AccessibleDescription = null;
			groupBox6.AccessibleName = null;
			resources.ApplyResources(groupBox6, "groupBox6");
			groupBox6.BackColor = System.Drawing.Color.Transparent;
			groupBox6.BackgroundImage = null;
			groupBox6.Controls.Add(button16);
			groupBox6.Controls.Add(textBox9);
			groupBox6.Controls.Add(label17);
			groupBox6.Controls.Add(textBox7);
			groupBox6.Controls.Add(label14);
			groupBox6.Controls.Add(textBox6);
			groupBox6.Controls.Add(label13);
			groupBox6.Controls.Add(textBox5);
			groupBox6.Controls.Add(textBox4);
			groupBox6.Controls.Add(textBox2);
			groupBox6.Controls.Add(textBox1);
			groupBox6.Controls.Add(label12);
			groupBox6.Controls.Add(label11);
			groupBox6.Controls.Add(label10);
			groupBox6.Controls.Add(label9);
			groupBox6.Name = "groupBox6";
			groupBox6.TabStop = false;
			textBox9.AccessibleDescription = null;
			textBox9.AccessibleName = null;
			resources.ApplyResources(textBox9, "textBox9");
			textBox9.BackColor = System.Drawing.Color.White;
			textBox9.BackgroundImage = null;
			textBox9.Font = null;
			textBox9.Name = "textBox9";
			textBox7.AccessibleDescription = null;
			textBox7.AccessibleName = null;
			resources.ApplyResources(textBox7, "textBox7");
			textBox7.BackColor = System.Drawing.Color.White;
			textBox7.BackgroundImage = null;
			textBox7.Name = "textBox7";
			textBox6.AccessibleDescription = null;
			textBox6.AccessibleName = null;
			resources.ApplyResources(textBox6, "textBox6");
			textBox6.BackColor = System.Drawing.Color.White;
			textBox6.BackgroundImage = null;
			textBox6.Name = "textBox6";
			textBox5.AccessibleDescription = null;
			textBox5.AccessibleName = null;
			resources.ApplyResources(textBox5, "textBox5");
			textBox5.BackColor = System.Drawing.Color.White;
			textBox5.BackgroundImage = null;
			textBox5.Name = "textBox5";
			textBox4.AccessibleDescription = null;
			textBox4.AccessibleName = null;
			resources.ApplyResources(textBox4, "textBox4");
			textBox4.BackColor = System.Drawing.Color.White;
			textBox4.BackgroundImage = null;
			textBox4.Name = "textBox4";
			textBox2.AccessibleDescription = null;
			textBox2.AccessibleName = null;
			resources.ApplyResources(textBox2, "textBox2");
			textBox2.BackColor = System.Drawing.Color.White;
			textBox2.BackgroundImage = null;
			textBox2.Name = "textBox2";
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackColor = System.Drawing.Color.White;
			textBox1.BackgroundImage = null;
			textBox1.Name = "textBox1";
			checkBox3.AccessibleDescription = null;
			checkBox3.AccessibleName = null;
			resources.ApplyResources(checkBox3, "checkBox3");
			checkBox3.BackColor = System.Drawing.Color.Transparent;
			checkBox3.BackgroundImage = null;
			checkBox3.Name = "checkBox3";
			checkBox3.UseVisualStyleBackColor = false;
			checkBox3.CheckedChanged += new System.EventHandler(checkBox3_CheckedChanged);
			sqlSelectCommand1.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[35]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[14]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData"),
					new System.Data.Common.DataColumnMapping("Powred", "Powred"),
					new System.Data.Common.DataColumnMapping("ClinicType", "ClinicType"),
					new System.Data.Common.DataColumnMapping("EyeClinic", "EyeClinic"),
					new System.Data.Common.DataColumnMapping("FemaleClinic", "FemaleClinic"),
					new System.Data.Common.DataColumnMapping("NaturalClinic", "NaturalClinic")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			groupBox7.AccessibleDescription = null;
			groupBox7.AccessibleName = null;
			resources.ApplyResources(groupBox7, "groupBox7");
			groupBox7.BackColor = System.Drawing.Color.Transparent;
			groupBox7.BackgroundImage = null;
			groupBox7.Controls.Add(txtQty);
			groupBox7.Controls.Add(label72);
			groupBox7.Controls.Add(floatText1);
			groupBox7.Controls.Add(label71);
			groupBox7.Controls.Add(label70);
			groupBox7.Controls.Add(txtStore);
			groupBox7.Controls.Add(itemIdComboBox);
			groupBox7.Controls.Add(button17);
			groupBox7.Name = "groupBox7";
			groupBox7.TabStop = false;
			txtQty.AccessibleDescription = null;
			txtQty.AccessibleName = null;
			resources.ApplyResources(txtQty, "txtQty");
			txtQty.BackgroundImage = null;
			txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			txtQty.Font = null;
			txtQty.Name = "txtQty";
			label72.AccessibleDescription = null;
			label72.AccessibleName = null;
			resources.ApplyResources(label72, "label72");
			label72.Name = "label72";
			floatText1.AccessibleDescription = null;
			floatText1.AccessibleName = null;
			resources.ApplyResources(floatText1, "floatText1");
			floatText1.BackgroundImage = null;
			floatText1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText1.Font = null;
			floatText1.Name = "floatText1";
			label71.AccessibleDescription = null;
			label71.AccessibleName = null;
			resources.ApplyResources(label71, "label71");
			label71.Name = "label71";
			button17.AccessibleDescription = null;
			button17.AccessibleName = null;
			resources.ApplyResources(button17, "button17");
			button17.BackColor = System.Drawing.Color.Gainsboro;
			button17.BackgroundImage = null;
			button17.Name = "button17";
			button17.UseVisualStyleBackColor = false;
			button17.Click += new System.EventHandler(button17_Click);
			label70.AccessibleDescription = null;
			label70.AccessibleName = null;
			resources.ApplyResources(label70, "label70");
			label70.Name = "label70";
			txtStore.AccessibleDescription = null;
			txtStore.AccessibleName = null;
			resources.ApplyResources(txtStore, "txtStore");
			txtStore.BackgroundImage = null;
			txtStore.Font = null;
			txtStore.Name = "txtStore";
			txtStore.ReadOnly = true;
			itemIdComboBox.AccessibleDescription = null;
			itemIdComboBox.AccessibleName = null;
			resources.ApplyResources(itemIdComboBox, "itemIdComboBox");
			itemIdComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			itemIdComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			itemIdComboBox.BackgroundImage = null;
			itemIdComboBox.Font = null;
			itemIdComboBox.FormattingEnabled = true;
			itemIdComboBox.Name = "itemIdComboBox";
			itemIdComboBox.SelectedIndexChanged += new System.EventHandler(itemIdComboBox_SelectedIndexChanged);
			groupBox22.AccessibleDescription = null;
			groupBox22.AccessibleName = null;
			resources.ApplyResources(groupBox22, "groupBox22");
			groupBox22.BackColor = System.Drawing.Color.Transparent;
			groupBox22.BackgroundImage = null;
			groupBox22.Controls.Add(dataGridView3);
			groupBox22.Font = null;
			groupBox22.Name = "groupBox22";
			groupBox22.TabStop = false;
			dataGridView3.AccessibleDescription = null;
			dataGridView3.AccessibleName = null;
			dataGridView3.AllowUserToAddRows = false;
			resources.ApplyResources(dataGridView3, "dataGridView3");
			dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView3.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView3.BackgroundImage = null;
			dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView3.Columns.AddRange(dataGridViewTextBoxColumn6, dataGridViewTextBoxColumn7, dataGridViewTextBoxColumn8, ItemId, Column3);
			dataGridView3.Font = null;
			dataGridView3.Name = "dataGridView3";
			dataGridView3.ReadOnly = true;
			PaidPanel.AccessibleDescription = null;
			PaidPanel.AccessibleName = null;
			resources.ApplyResources(PaidPanel, "PaidPanel");
			PaidPanel.BackColor = System.Drawing.Color.Transparent;
			PaidPanel.BackgroundImage = null;
			PaidPanel.Controls.Add(TreasuryCom);
			PaidPanel.Controls.Add(EsalNoTxt);
			PaidPanel.Controls.Add(lblTreasury);
			PaidPanel.Controls.Add(label45);
			PaidPanel.Font = null;
			PaidPanel.Name = "PaidPanel";
			TreasuryCom.AccessibleDescription = null;
			TreasuryCom.AccessibleName = null;
			resources.ApplyResources(TreasuryCom, "TreasuryCom");
			TreasuryCom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			TreasuryCom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			TreasuryCom.BackgroundImage = null;
			TreasuryCom.FormattingEnabled = true;
			TreasuryCom.Name = "TreasuryCom";
			EsalNoTxt.AccessibleDescription = null;
			EsalNoTxt.AccessibleName = null;
			resources.ApplyResources(EsalNoTxt, "EsalNoTxt");
			EsalNoTxt.BackgroundImage = null;
			EsalNoTxt.Font = null;
			EsalNoTxt.Name = "EsalNoTxt";
			EsalNoTxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(EsalNoTxt_KeyPress);
			lblTreasury.AccessibleDescription = null;
			lblTreasury.AccessibleName = null;
			resources.ApplyResources(lblTreasury, "lblTreasury");
			lblTreasury.BackColor = System.Drawing.Color.Transparent;
			lblTreasury.Name = "lblTreasury";
			label45.AccessibleDescription = null;
			label45.AccessibleName = null;
			resources.ApplyResources(label45, "label45");
			label45.BackColor = System.Drawing.Color.Transparent;
			label45.Name = "label45";
			PayNaqdy.AccessibleDescription = null;
			PayNaqdy.AccessibleName = null;
			resources.ApplyResources(PayNaqdy, "PayNaqdy");
			PayNaqdy.BackColor = System.Drawing.Color.Transparent;
			PayNaqdy.BackgroundImage = null;
			PayNaqdy.Checked = true;
			PayNaqdy.Name = "PayNaqdy";
			PayNaqdy.TabStop = true;
			PayNaqdy.UseVisualStyleBackColor = false;
			PayNaqdy.CheckedChanged += new System.EventHandler(PayNaqdy_CheckedChanged);
			PayBefore.AccessibleDescription = null;
			PayBefore.AccessibleName = null;
			resources.ApplyResources(PayBefore, "PayBefore");
			PayBefore.BackColor = System.Drawing.Color.Transparent;
			PayBefore.BackgroundImage = null;
			PayBefore.Name = "PayBefore";
			PayBefore.UseVisualStyleBackColor = false;
			PayBefore.CheckedChanged += new System.EventHandler(PayBefore_CheckedChanged);
			sqlSelectCommand2.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlSelectCommand2.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[50]
			{
				new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
				new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
				new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
				new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
				new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
				new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
				new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
				new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
				new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
				new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
				new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
				new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
				new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
				new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
				new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
				new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
				new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
				new System.Data.SqlClient.SqlParameter("@Lactating", System.Data.SqlDbType.Bit, 0, "Lactating"),
				new System.Data.SqlClient.SqlParameter("@Pregnant", System.Data.SqlDbType.Bit, 0, "Pregnant"),
				new System.Data.SqlClient.SqlParameter("@HepatitisB", System.Data.SqlDbType.Bit, 0, "HepatitisB"),
				new System.Data.SqlClient.SqlParameter("@Hepatitisc", System.Data.SqlDbType.Bit, 0, "Hepatitisc"),
				new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
				new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
				new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
				new System.Data.SqlClient.SqlParameter("@Endodontics", System.Data.SqlDbType.Bit, 0, "Endodontics"),
				new System.Data.SqlClient.SqlParameter("@Fixed", System.Data.SqlDbType.Bit, 0, "Fixed"),
				new System.Data.SqlClient.SqlParameter("@Implant", System.Data.SqlDbType.Bit, 0, "Implant"),
				new System.Data.SqlClient.SqlParameter("@Opretive", System.Data.SqlDbType.Bit, 0, "Opretive"),
				new System.Data.SqlClient.SqlParameter("@Bleaching", System.Data.SqlDbType.Bit, 0, "Bleaching"),
				new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers"),
				new System.Data.SqlClient.SqlParameter("@DoctoreName", System.Data.SqlDbType.NVarChar, 0, "DoctoreName"),
				new System.Data.SqlClient.SqlParameter("@NextVisit", System.Data.SqlDbType.NVarChar, 0, "NextVisit"),
				new System.Data.SqlClient.SqlParameter("@Accept", System.Data.SqlDbType.Bit, 0, "Accept"),
				new System.Data.SqlClient.SqlParameter("@Taqweem", System.Data.SqlDbType.Bit, 0, "Taqweem"),
				new System.Data.SqlClient.SqlParameter("@Photo", System.Data.SqlDbType.Image, 0, "Photo"),
				new System.Data.SqlClient.SqlParameter("@BloodType", System.Data.SqlDbType.NVarChar, 0, "BloodType"),
				new System.Data.SqlClient.SqlParameter("@Active", System.Data.SqlDbType.Bit, 0, "Active"),
				new System.Data.SqlClient.SqlParameter("@FileNo", System.Data.SqlDbType.Int, 0, "FileNo"),
				new System.Data.SqlClient.SqlParameter("@Patient", System.Data.SqlDbType.Bit, 0, "Patient"),
				new System.Data.SqlClient.SqlParameter("@Facebook", System.Data.SqlDbType.Bit, 0, "Facebook"),
				new System.Data.SqlClient.SqlParameter("@Adv", System.Data.SqlDbType.Bit, 0, "Adv"),
				new System.Data.SqlClient.SqlParameter("@FormerPatient", System.Data.SqlDbType.NVarChar, 0, "FormerPatient"),
				new System.Data.SqlClient.SqlParameter("@Discount", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Discount", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Without", System.Data.SqlDbType.Bit, 0, "Without"),
				new System.Data.SqlClient.SqlParameter("@Doctor", System.Data.SqlDbType.Bit, 0, "Doctor"),
				new System.Data.SqlClient.SqlParameter("@DoctorId", System.Data.SqlDbType.NVarChar, 0, "DoctorId")
			});
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[51]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
					new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
					new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
					new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
					new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
					new System.Data.Common.DataColumnMapping("Implant", "Implant"),
					new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
					new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers"),
					new System.Data.Common.DataColumnMapping("DoctoreName", "DoctoreName"),
					new System.Data.Common.DataColumnMapping("NextVisit", "NextVisit"),
					new System.Data.Common.DataColumnMapping("Accept", "Accept"),
					new System.Data.Common.DataColumnMapping("Taqweem", "Taqweem"),
					new System.Data.Common.DataColumnMapping("Photo", "Photo"),
					new System.Data.Common.DataColumnMapping("BloodType", "BloodType"),
					new System.Data.Common.DataColumnMapping("Active", "Active"),
					new System.Data.Common.DataColumnMapping("FileNo", "FileNo"),
					new System.Data.Common.DataColumnMapping("Patient", "Patient"),
					new System.Data.Common.DataColumnMapping("Facebook", "Facebook"),
					new System.Data.Common.DataColumnMapping("Adv", "Adv"),
					new System.Data.Common.DataColumnMapping("FormerPatient", "FormerPatient"),
					new System.Data.Common.DataColumnMapping("Discount", "Discount"),
					new System.Data.Common.DataColumnMapping("Without", "Without"),
					new System.Data.Common.DataColumnMapping("Doctor", "Doctor"),
					new System.Data.Common.DataColumnMapping("DoctorId", "DoctorId")
				})
			});
			resources.ApplyResources(Service, "Service");
			Service.Name = "Service";
			Service.ReadOnly = true;
			resources.ApplyResources(Price, "Price");
			Price.Name = "Price";
			Price.ReadOnly = true;
			resources.ApplyResources(ServiceDate, "ServiceDate");
			ServiceDate.Name = "ServiceDate";
			ServiceDate.ReadOnly = true;
			resources.ApplyResources(Teethn, "Teethn");
			Teethn.Name = "Teethn";
			Teethn.ReadOnly = true;
			resources.ApplyResources(TiD, "TiD");
			TiD.Name = "TiD";
			TiD.ReadOnly = true;
			resources.ApplyResources(Cost, "Cost");
			Cost.Name = "Cost";
			Cost.ReadOnly = true;
			resources.ApplyResources(Count, "Count");
			Count.Name = "Count";
			Count.ReadOnly = true;
			resources.ApplyResources(Column1, "Column1");
			Column1.Name = "Column1";
			Column1.ReadOnly = true;
			resources.ApplyResources(Column2, "Column2");
			Column2.Name = "Column2";
			resources.ApplyResources(Column4, "Column4");
			Column4.Name = "Column4";
			Column4.ReadOnly = true;
			resources.ApplyResources(dataGridViewTextBoxColumn6, "dataGridViewTextBoxColumn6");
			dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
			dataGridViewTextBoxColumn6.ReadOnly = true;
			resources.ApplyResources(dataGridViewTextBoxColumn7, "dataGridViewTextBoxColumn7");
			dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
			dataGridViewTextBoxColumn7.ReadOnly = true;
			resources.ApplyResources(dataGridViewTextBoxColumn8, "dataGridViewTextBoxColumn8");
			dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
			dataGridViewTextBoxColumn8.ReadOnly = true;
			resources.ApplyResources(ItemId, "ItemId");
			ItemId.Name = "ItemId";
			ItemId.ReadOnly = true;
			resources.ApplyResources(Column3, "Column3");
			Column3.Name = "Column3";
			Column3.ReadOnly = true;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(PayNaqdy);
			base.Controls.Add(PayBefore);
			base.Controls.Add(PaidPanel);
			base.Controls.Add(groupBox22);
			base.Controls.Add(groupBox7);
			base.Controls.Add(checkBox3);
			base.Controls.Add(groupBox6);
			base.Controls.Add(tottextBox);
			base.Controls.Add(groupBox2);
			base.Controls.Add(label6);
			base.Controls.Add(groupBox5);
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox4);
			Font = null;
			base.KeyPreview = true;
			base.Name = "FrmVisit";
			base.Load += new System.EventHandler(PatientAccount_Load);
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(PatientAccount_FormClosing);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(PatientAccount_KeyDown);
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			groupBox29.ResumeLayout(false);
			groupBox29.PerformLayout();
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox5.ResumeLayout(false);
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox6.ResumeLayout(false);
			groupBox6.PerformLayout();
			groupBox7.ResumeLayout(false);
			groupBox7.PerformLayout();
			groupBox22.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
			PaidPanel.ResumeLayout(false);
			PaidPanel.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
