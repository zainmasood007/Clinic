using System.ComponentModel;
using CrystalDecisions.CrystalReports.Engine;

namespace DentistClinic.Reports
{
	public class NeurologicalFormRPT : ReportClass
	{
		public override string ResourceName
		{
			get
			{
				return "NeurologicalFormRPT.rpt";
			}
			set
			{
			}
		}

		public override bool NewGenerator
		{
			get
			{
				return true;
			}
			set
			{
			}
		}

		public override string FullResourceName
		{
			get
			{
				return "DentistClinic.Reports.NeurologicalFormRPT.rpt";
			}
			set
			{
			}
		}

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section Section1 => ReportDefinition.Sections[0];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section Section2 => ReportDefinition.Sections[1];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section Section3 => ReportDefinition.Sections[2];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section Section4 => ReportDefinition.Sections[3];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section ReportFooterSection13 => ReportDefinition.Sections[4];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section ReportFooterSection14 => ReportDefinition.Sections[5];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section ReportFooterSection15 => ReportDefinition.Sections[6];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section ReportFooterSection16 => ReportDefinition.Sections[7];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section ReportFooterSection17 => ReportDefinition.Sections[8];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section ReportFooterSection18 => ReportDefinition.Sections[9];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section ReportFooterSection19 => ReportDefinition.Sections[10];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section ReportFooterSection20 => ReportDefinition.Sections[11];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section ReportFooterSection21 => ReportDefinition.Sections[12];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section ReportFooterSection22 => ReportDefinition.Sections[13];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section ReportFooterSection23 => ReportDefinition.Sections[14];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section ReportFooterSection24 => ReportDefinition.Sections[15];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section ReportFooterSection2 => ReportDefinition.Sections[16];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section Section5 => ReportDefinition.Sections[17];
	}
}
