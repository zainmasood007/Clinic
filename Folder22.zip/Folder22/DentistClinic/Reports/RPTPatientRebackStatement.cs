using System.ComponentModel;
using CrystalDecisions.CrystalReports.Engine;

namespace DentistClinic.Reports
{
	public class RPTPatientRebackStatement : ReportClass
	{
		public override string ResourceName
		{
			get
			{
				return "RPTPatientRebackStatement.rpt";
			}
			set
			{
			}
		}

		public override bool NewGenerator
		{
			get
			{
				return true;
			}
			set
			{
			}
		}

		public override string FullResourceName
		{
			get
			{
				return "DentistClinic.Reports.RPTPatientRebackStatement.rpt";
			}
			set
			{
			}
		}

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section Section1 => ReportDefinition.Sections[0];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section Section2 => ReportDefinition.Sections[1];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section GroupHeaderSection1 => ReportDefinition.Sections[2];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section Section3 => ReportDefinition.Sections[3];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section GroupFooterSection1 => ReportDefinition.Sections[4];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section Section4 => ReportDefinition.Sections[5];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section Section5 => ReportDefinition.Sections[6];
	}
}
