using System.ComponentModel;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace DentistClinic.Reports
{
	public class RptLoginUser : ReportClass
	{
		string _ResourceName;
		public override string ResourceName
		{
			get
			{
				return "RptLoginUser.rpt";
			}
			set
			{
				_ResourceName = value;
			}
		}
		bool _NewGenerator;
		public override bool NewGenerator
		{
			get
			{
				return true;
			}
			set
			{
				_NewGenerator = value;
			}
		}
		string _FullResourceName;
		public override string FullResourceName
		{
			get
			{
				return "RptLoginUser.rpt";
			}
			set
			{
				_FullResourceName = value;
			}
		}

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section Section1 => ReportDefinition.Sections[0];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section Section2 => ReportDefinition.Sections[1];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section Section3 => ReportDefinition.Sections[2];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public Section Section4 => ReportDefinition.Sections[3];

		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public Section Section5 => ReportDefinition.Sections[4];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public IParameterField Parameter_Date2 => DataDefinition.ParameterFields[0];

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public IParameterField Parameter_Date1 => DataDefinition.ParameterFields[1];
	}
}
