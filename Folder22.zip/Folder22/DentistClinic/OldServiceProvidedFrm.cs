using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace DentistClinic
{
	public class OldServiceProvidedFrm : BaseForm
	{
		private IContainer components = null;

		private FlowLayoutPanel flowLayoutPanel1;

		private Panel panel1;

		private Label label1;

		private Label label3;

		private Label label2;

		private dataClass codes;

		private int Patient;

		private int doct;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			panel1 = new System.Windows.Forms.Panel();
			label2 = new System.Windows.Forms.Label();
			label3 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			flowLayoutPanel1.SuspendLayout();
			panel1.SuspendLayout();
			SuspendLayout();
			flowLayoutPanel1.AutoScroll = true;
			flowLayoutPanel1.Controls.Add(panel1);
			flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			flowLayoutPanel1.Name = "flowLayoutPanel1";
			flowLayoutPanel1.Size = new System.Drawing.Size(899, 650);
			flowLayoutPanel1.TabIndex = 0;
			panel1.BackColor = System.Drawing.Color.LightSlateGray;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(label2);
			panel1.Controls.Add(label3);
			panel1.Controls.Add(label1);
			panel1.Location = new System.Drawing.Point(3, 3);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(865, 48);
			panel1.TabIndex = 0;
			label2.BackColor = System.Drawing.Color.SlateGray;
			label2.Font = new System.Drawing.Font("Arial", 15.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label2.ForeColor = System.Drawing.Color.White;
			label2.Location = new System.Drawing.Point(492, 6);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(172, 33);
			label2.TabIndex = 1;
			label2.Text = "السعر";
			label3.BackColor = System.Drawing.Color.SlateGray;
			label3.Font = new System.Drawing.Font("Arial", 15.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label3.ForeColor = System.Drawing.Color.White;
			label3.Location = new System.Drawing.Point(676, 6);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(172, 33);
			label3.TabIndex = 2;
			label3.Text = "التاريخ";
			label1.BackColor = System.Drawing.Color.SlateGray;
			label1.Font = new System.Drawing.Font("Arial", 15.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label1.ForeColor = System.Drawing.Color.White;
			label1.Location = new System.Drawing.Point(9, 6);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(475, 33);
			label1.TabIndex = 0;
			label1.Text = "الخدمة";
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			base.ClientSize = new System.Drawing.Size(899, 650);
			base.Controls.Add(flowLayoutPanel1);
			base.Name = "OldServiceProvidedFrm";
			Text = "خدمات سابقة";
			base.Load += new System.EventHandler(OldServiceProvidedFrm_Load);
			flowLayoutPanel1.ResumeLayout(false);
			panel1.ResumeLayout(false);
			ResumeLayout(false);
		}

		public OldServiceProvidedFrm(int PatinetId)
		{
			InitializeComponent();
			codes = new dataClass(".\\sqlExpress");
			Patient = PatinetId;
		}

		private void OldServiceProvidedFrm_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("SELECT DISTINCT (PatientAccount.TeathId), Teath.Name FROM PatientAccount INNER JOIN  Teath ON PatientAccount.TeathId = Teath.Id where PatientAccount.PatientId=" + Patient);
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					Panel panel = new Panel();
					panel.Name = "pang" + i;
					panel.Size = new Size(600, 33);
					panel.BackColor = Color.DarkGray;
					Label label = new Label();
					label.Name = "gLab" + i;
					label.Font = new Font("Arial", 14f, FontStyle.Bold, GraphicsUnit.Point, 0);
					label.ForeColor = Color.White;
					label.Size = new Size(475, 25);
					label.Text = dataTable.Rows[i][1].ToString();
					panel.Controls.Add(label);
					flowLayoutPanel1.Controls.Add(panel);
					DataTable dataTable2 = codes.Search2("select * from PatientAccount where PatientId=" + Patient + " and TeathId=" + dataTable.Rows[i][0].ToString());
					if (dataTable2.Rows.Count > 0)
					{
						for (int j = 0; j < dataTable2.Rows.Count; j++)
						{
							Panel panel2 = new Panel();
							panel2.Name = "pan" + j;
							panel2.Size = new Size(865, 33);
							panel2.BackColor = Color.LightSlateGray;
							Label label2 = new Label();
							label2.Name = "byanLab" + j;
							label2.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
							label2.ForeColor = Color.White;
							label2.Size = new Size(475, 25);
							label2.Text = dataTable2.Rows[j][3].ToString();
							Label label3 = new Label();
							label3.Name = "byanLab" + j;
							label3.Font = new Font("Arial", 12f);
							label3.ForeColor = Color.White;
							label3.Size = new Size(172, 25);
							label3.Text = Math.Round(Convert.ToDecimal(dataTable2.Rows[j]["Price"].ToString()), 2).ToString();
							label3.Location = new Point(490, 6);
							Label label4 = new Label();
							label4.Name = "byanLab" + j;
							label4.Font = new Font("Arial", 12f);
							label4.ForeColor = Color.White;
							label4.Size = new Size(172, 25);
							label4.Text = Convert.ToDateTime(dataTable2.Rows[j]["BeanDate"].ToString()).ToShortDateString();
							label4.Location = new Point(681, 6);
							panel2.Controls.Add(label2);
							panel2.Controls.Add(label4);
							panel2.Controls.Add(label3);
							flowLayoutPanel1.Controls.Add(panel2);
						}
					}
				}
			}
			catch
			{
			}
		}
	}
}
