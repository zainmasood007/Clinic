using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmCity : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox4;

		private Label label3;

		private GroupBox groupBox3;

		private DataGridView dataGridView1;

		private GroupBox groupBox2;

		private Button saveBtn;

		private Button EditBtn;

		private GroupBox groupBox1;

		private TextBox NametextBox;

		private Label label1;

		private Button BackBtn;

		private ClassDataBase dc;

		private int ID;

		private GUI gui = new GUI();

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmCity));
			groupBox4 = new System.Windows.Forms.GroupBox();
			label3 = new System.Windows.Forms.Label();
			groupBox3 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox2 = new System.Windows.Forms.GroupBox();
			BackBtn = new System.Windows.Forms.Button();
			saveBtn = new System.Windows.Forms.Button();
			EditBtn = new System.Windows.Forms.Button();
			groupBox1 = new System.Windows.Forms.GroupBox();
			NametextBox = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			groupBox4.SuspendLayout();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox2.SuspendLayout();
			groupBox1.SuspendLayout();
			SuspendLayout();
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(label3);
			groupBox4.Font = null;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(dataGridView1);
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseClick);
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(BackBtn);
			groupBox2.Controls.Add(saveBtn);
			groupBox2.Controls.Add(EditBtn);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			BackBtn.AccessibleDescription = null;
			BackBtn.AccessibleName = null;
			resources.ApplyResources(BackBtn, "BackBtn");
			BackBtn.BackColor = System.Drawing.Color.Gainsboro;
			BackBtn.BackgroundImage = null;
			BackBtn.Name = "BackBtn";
			BackBtn.UseVisualStyleBackColor = false;
			BackBtn.Click += new System.EventHandler(BackBtn_Click);
			saveBtn.AccessibleDescription = null;
			saveBtn.AccessibleName = null;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			saveBtn.BackgroundImage = null;
			saveBtn.Name = "saveBtn";
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			EditBtn.AccessibleDescription = null;
			EditBtn.AccessibleName = null;
			resources.ApplyResources(EditBtn, "EditBtn");
			EditBtn.BackColor = System.Drawing.Color.Gainsboro;
			EditBtn.BackgroundImage = null;
			EditBtn.Name = "EditBtn";
			EditBtn.UseVisualStyleBackColor = false;
			EditBtn.Click += new System.EventHandler(EditBtn_Click);
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(NametextBox);
			groupBox1.Controls.Add(label1);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			NametextBox.AccessibleDescription = null;
			NametextBox.AccessibleName = null;
			resources.ApplyResources(NametextBox, "NametextBox");
			NametextBox.BackgroundImage = null;
			NametextBox.Font = null;
			NametextBox.Name = "NametextBox";
			NametextBox.TextChanged += new System.EventHandler(NametextBox_TextChanged);
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.BackColor = System.Drawing.Color.Transparent;
			label1.Font = null;
			label1.Name = "label1";
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox4);
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FrmCity";
			base.Load += new System.EventHandler(FrmMainComplaint_Load);
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			ResumeLayout(false);
		}

		public FrmCity()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		public void RefreshData()
		{
			try
			{
				DataTable dataSource = codes.Search2("SELECT * from City ");
				dataGridView1.DataSource = dataSource;
				dataGridView1.Columns[0].Visible = false;
			}
			catch
			{
			}
		}

		private void searchBtn_Click(object sender, EventArgs e)
		{
			RefreshData();
		}

		public void Clear()
		{
			NametextBox.Text = "";
			EditBtn.Enabled = false;
			BackBtn.Enabled = false;
			saveBtn.Enabled = true;
		}

		public void DataGrid()
		{
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].HeaderText = "City Name";
				dataGridView1.Columns[1].Width = 460;
			}
			else
			{
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].HeaderText = "اسم المدينة";
				dataGridView1.Columns[1].Width = 460;
			}
		}

		public void AllData()
		{
			DataTable tableText = dc.GetTableText("select * from City");
			dataGridView1.DataSource = tableText;
			DataGrid();
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (NametextBox.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter City Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المدينة");
					}
					return;
				}
				DataTable tableText = dc.GetTableText("select * from City where Name='" + NametextBox.Text + "'");
				if (tableText.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This City Before");
					}
					else
					{
						MessageBox.Show("اسم المدينة مسجل من قبل");
					}
				}
				else
				{
					codes.Add("insert into City (Name) Values ('" + NametextBox.Text + "')");
					MethodsClass.UserMove("أضافة مدينة");
					AllData();
					loadCombo();
					Clear();
				}
			}
			catch
			{
			}
		}

		private void NametextBox_TextChanged(object sender, EventArgs e)
		{
			string text = NametextBox.Text;
			if (text.StartsWith(" "))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("It IS Not Allowed To Use Space In The Beginning", "Notes");
				}
				else
				{
					MessageBox.Show("لا يمكن ترك فراغ في بداية الإسم", "تنبيه");
				}
				NametextBox.Text = "";
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					if (NametextBox.Text == "")
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please Enter City Name");
						}
						else
						{
							MessageBox.Show("من فضلك ادخل اسم المدينة");
						}
						return;
					}
					DataTable tableText = dc.GetTableText("select * from City where Name='" + NametextBox.Text + "'and CId <>'" + ID + "'");
					if (tableText.Rows.Count > 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Have Save This City Before");
						}
						else
						{
							MessageBox.Show("اسم المدينة مسجل من قبل");
						}
						AllData();
						return;
					}
					codes.Edit("update City set Name ='" + NametextBox.Text + "' where ID = '" + ID + "'");
					MethodsClass.UserMove("تعديل مدينة");
					loadCombo();
					Clear();
					AllData();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Select Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اختر البيانات أولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			EditBtn.Enabled = true;
			BackBtn.Enabled = true;
			saveBtn.Enabled = false;
			ID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
			NametextBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
		}

		private void FrmMainComplaint_Load(object sender, EventArgs e)
		{
			AllData();
			loadCombo();
			Clear();
			EditBtn.Enabled = false;
			BackBtn.Enabled = false;
			saveBtn.Enabled = true;
		}

		private void BackBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					if (NametextBox.Text == "")
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please Enter City Name");
						}
						else
						{
							MessageBox.Show("من فضلك ادخل اسم المدينة");
						}
						return;
					}
					DataTable tableText = dc.GetTableText("select * from City where Name='" + NametextBox.Text + "'and CId <>'" + ID + "'");
					if (tableText.Rows.Count > 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Have Save This City Before");
						}
						else
						{
							MessageBox.Show("اسم المدينة مسجل من قبل");
						}
						AllData();
					}
					else
					{
						codes.Delete("delete from  City where ID = '" + ID + "'");
						MethodsClass.UserMove("حذف مدينة");
						loadCombo();
						Clear();
						AllData();
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Select Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اختر البيانات أولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void loadCombo()
		{
		}
	}
}
