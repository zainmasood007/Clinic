using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace DentistClinic
{
	public class frmShowAppointments : BaseForm
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private GroupBox groupBox1;

		private DateTimePicker date2;

		private DateTimePicker date1;

		private Label label3;

		private Label label2;

		private Button ViewRptBtn;

		private GroupBox groupBox2;

		private DataSet1 dataSet11;

		private DataGridView dataGridView1;

		private ComboBox doctorcomboBox;

		private Label label1;

		public frmShowAppointments()
		{
			InitializeComponent();
		}

		private void frmAllPatientAcount_Load(object sender, EventArgs e)
		{
			DataTable dataTable = Codes.Search2("select * from Empdata where Designation='Doctor'");
			doctorcomboBox.DataSource = dataTable;
			doctorcomboBox.ValueMember = dataTable.Columns["ID"].ToString();
			doctorcomboBox.DisplayMember = dataTable.Columns["Name"].ToString();
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			dataGridView1.Rows.Clear();
			dataGridView1.Columns.Clear();
			int num = 0;
			try
			{
				string text = "AM";
				dataGridView1.Columns.Add("Date", "التاريخ");
				DataTable dataTable = Codes.Search2("select AppointPeriod, AppointFrom, AppointTo from Properties");
				DateTime dateTime = Convert.ToDateTime(dataTable.Rows[0][1]);
				DateTime dateTime2 = Convert.ToDateTime(dataTable.Rows[0][2]);
				decimal num2 = dateTime.Hour;
				_ = (decimal)dateTime2.Hour;
				_ = (decimal)Math.Abs(dateTime.Hour - dateTime2.Hour);
				decimal num3 = Math.Abs(dateTime.Hour - dateTime2.Hour);
				decimal num4 = Convert.ToDecimal(dataTable.Rows[0][0]) / 60m;
				Convert.ToDecimal(dataTable.Rows[0][0]);
				num3 = 60m / Convert.ToDecimal(dataTable.Rows[0][0]) * num3;
				if (dateTime.Hour > 12)
				{
					num2 = dateTime.Hour - 12;
					text = "PM";
				}
				if (dateTime2.Hour > 12)
				{
					_ = (decimal)(dateTime2.Hour - 12);
				}
				string text2 = "";
				string text3 = "";
				decimal num5 = 0m;
				decimal num6 = 0m;
				_ = 0m;
				for (decimal num7 = num2; num7 < num3; num7 += num4)
				{
					num++;
					++num6;
					if (num6 == num3 + 1m)
					{
						break;
					}
					num5 = num7;
					if (num7 == 12m)
					{
						text = ((!(text == "AM")) ? "AM" : "PM");
					}
					if (num7 >= 13m)
					{
						num5 = num7 - 12m;
					}
					if (num5 - Math.Truncate(num5) > 9m)
					{
						string text4 = Math.Truncate(num5).ToString();
						string text5 = "";
						if (num5 - Math.Truncate(num5) == 0m)
						{
							text5 = "00";
						}
						else
						{
							text5 = Math.Truncate((num5 - Math.Truncate(num5)) * 60m).ToString();
							if (Convert.ToInt32(text5) < 10)
							{
								text5 = "0" + text5;
							}
						}
						decimal num8 = num5 + num4;
						if (num8 > 12m)
						{
							num8 -= 12m;
						}
						string text6 = Math.Truncate(num8).ToString();
						string text7 = Math.Truncate((num8 - Math.Truncate(num8)) * 60m).ToString();
						if (Convert.ToInt32(text7) < 10)
						{
							text7 = "0" + text7;
						}
						text2 = text4 + ":" + text5;
						text3 = text6 + ":" + text7;
					}
					else
					{
						string text4 = "";
						text4 = ((!(Math.Truncate(num5) < 10m)) ? Math.Truncate(num5).ToString() : ("0" + Math.Truncate(num5)));
						string text5 = "";
						if (num7 - Math.Truncate(num5) == 0m)
						{
							text5 = "00";
						}
						else
						{
							text5 = Math.Truncate((num5 - Math.Truncate(num5)) * 60m).ToString();
							if (Convert.ToInt32(text5) < 10)
							{
								text5 = "0" + text5;
							}
						}
						decimal num8 = num5 + num4;
						if (num8 >= 13m)
						{
							num8 -= 12m;
						}
						string text6 = "";
						text6 = ((!(Math.Truncate(num8) < 10m)) ? Math.Truncate(num8).ToString() : ("0" + Math.Truncate(num8)));
						string text7 = Math.Truncate((num8 - Math.Truncate(num8)) * 60m).ToString();
						if (Convert.ToInt32(text7) < 10)
						{
							text7 = "0" + text7;
						}
						text2 = text4 + ":" + text5;
						text3 = text6 + ":" + text7;
					}
					dataGridView1.Columns.Add(text2 + " - " + text3 + " " + text, text2 + " - " + text3 + " " + text);
					dataGridView1.Columns[num].Width = 120;
				}
				int num9 = Convert.ToInt32((date2.Value - date1.Value).TotalDays);
				for (int i = 0; i < num9 + 1; i++)
				{
					dataGridView1.Rows.Add();
					dataGridView1.Rows[i].Cells[0].Value = date1.Value.AddDays(i).ToString("yyyy/MM/dd");
					DataTable dataTable2 = Codes.Search2(string.Concat("select detectStartTime,detectEndTime,Period from Appointments where DoctorID=", doctorcomboBox.SelectedValue, " and Done='False' and detectDate = '", date1.Value.AddDays(i).ToString("MM/dd/yyyy"), "' "));
					for (int j = 0; j < dataTable2.Rows.Count; j++)
					{
						bool flag = Convert.ToBoolean(dataTable2.Rows[j][2].ToString());
						string text8 = "";
						text8 = ((!flag) ? "AM" : "PM");
						string text9 = dataTable2.Rows[j][0].ToString() + " - " + dataTable2.Rows[j][1].ToString() + " " + text8;
						foreach (DataGridViewColumn column in dataGridView1.Columns)
						{
							if (column.HeaderText == text9)
							{
								int index = column.Index;
								dataGridView1.Rows[i].Cells[index].Style.BackColor = Color.Red;
							}
						}
					}
					dataGridView1.Rows[i].Cells[0].Style.BackColor = Color.FromArgb(51, 153, 255);
				}
				try
				{
					dataGridView1.CurrentCell = dataGridView1.CurrentRow.Cells[0];
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void frmAllPatientAcount_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void dataGridView1_CellLeave(object sender, DataGridViewCellEventArgs e)
		{
			try
			{
			}
			catch
			{
			}
		}

		private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
		{
		}

		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			try
			{
				dataGridView1.CurrentCell = dataGridView1.CurrentRow.Cells[0];
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.frmShowAppointments));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			groupBox1 = new System.Windows.Forms.GroupBox();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			label1 = new System.Windows.Forms.Label();
			date2 = new System.Windows.Forms.DateTimePicker();
			date1 = new System.Windows.Forms.DateTimePicker();
			ViewRptBtn = new System.Windows.Forms.Button();
			label3 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			dataSet11 = new DataSet1();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(doctorcomboBox);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(date2);
			groupBox1.Controls.Add(date1);
			groupBox1.Controls.Add(ViewRptBtn);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(label2);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			resources.ApplyResources(doctorcomboBox, "doctorcomboBox");
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Name = "doctorcomboBox";
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			resources.ApplyResources(date2, "date2");
			date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date2.Name = "date2";
			resources.ApplyResources(date1, "date1");
			date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date1.Name = "date1";
			resources.ApplyResources(ViewRptBtn, "ViewRptBtn");
			ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
			ViewRptBtn.Name = "ViewRptBtn";
			ViewRptBtn.UseVisualStyleBackColor = false;
			ViewRptBtn.Click += new System.EventHandler(ViewRptBtn_Click);
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(dataGridView1);
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			dataGridViewCellStyle.SelectionBackColor = System.Drawing.Color.Transparent;
			dataGridViewCellStyle.SelectionForeColor = System.Drawing.Color.Transparent;
			dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8f);
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Transparent;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8f);
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
			dataGridView1.CellLeave += new System.Windows.Forms.DataGridViewCellEventHandler(dataGridView1_CellLeave);
			dataGridView1.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(dataGridView1_CellFormatting);
			dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(dataGridView1_CellClick);
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.MaximizeBox = true;
			base.Name = "frmShowAppointments";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.Load += new System.EventHandler(frmAllPatientAcount_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(frmAllPatientAcount_KeyDown);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}
	}
}
