using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmMainComplaint : BaseForm
	{
		private ClassDataBase dc;

		private int ID;

		private GUI gui = new GUI();

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		private IContainer components = null;

		private GroupBox groupBox5;

		private ComboBox comboBox3;

		private Button searchBtn;

		private GroupBox groupBox4;

		private Label label3;

		private GroupBox groupBox3;

		private DataGridView dataGridView1;

		private GroupBox groupBox2;

		private Button saveBtn;

		private Button EditBtn;

		private GroupBox groupBox1;

		private TextBox NametextBox;

		private Label label1;

		private Label label2;

		private Button BackBtn;

		public FrmMainComplaint()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		public void RefreshData()
		{
			try
			{
				DataTable dataSource = codes.Search2(string.Concat("SELECT * from MainComplaint where CId='", comboBox3.SelectedValue, "'"));
				dataGridView1.DataSource = dataSource;
				dataGridView1.Columns[0].Visible = false;
			}
			catch
			{
			}
		}

		private void searchBtn_Click(object sender, EventArgs e)
		{
			RefreshData();
		}

		public void Clear()
		{
			comboBox3.SelectedIndex = -1;
			NametextBox.Text = "";
			EditBtn.Enabled = false;
			saveBtn.Enabled = true;
		}

		public void DataGrid()
		{
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].HeaderText = "Complaint Name";
				dataGridView1.Columns[1].Width = 460;
			}
			else
			{
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].HeaderText = "اسم الشكوى";
				dataGridView1.Columns[1].Width = 460;
			}
		}

		public void AllData()
		{
			DataTable tableText = dc.GetTableText("select * from MainComplaint");
			dataGridView1.DataSource = tableText;
			DataGrid();
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (NametextBox.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Complaint Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الشكوى");
					}
					return;
				}
				DataTable tableText = dc.GetTableText("select * from MainComplaint where Complaint='" + NametextBox.Text + "'");
				if (tableText.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This Complaint Before");
					}
					else
					{
						MessageBox.Show("اسم الشكوى مسجل من قبل");
					}
				}
				else
				{
					codes.Add("insert into MainComplaint(Complaint) Values ('" + NametextBox.Text + "')");
					MethodsClass.UserMove("أضافة شكوي");
					AllData();
					loadCombo();
					Clear();
				}
			}
			catch
			{
			}
		}

		private void NametextBox_TextChanged(object sender, EventArgs e)
		{
			string text = NametextBox.Text;
			if (text.StartsWith(" "))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("It IS Not Allowed To Use Space In The Beginning", "Notes");
				}
				else
				{
					MessageBox.Show("لا يمكن ترك فراغ في بداية الإسم", "تنبيه");
				}
				NametextBox.Text = "";
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					if (NametextBox.Text == "")
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please Enter Complaint Name");
						}
						else
						{
							MessageBox.Show("من فضلك ادخل اسم الشكوى");
						}
						return;
					}
					DataTable tableText = dc.GetTableText("select * from MainComplaint where Complaint='" + NametextBox.Text + "'and CId <>'" + ID + "'");
					if (tableText.Rows.Count > 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Have Save This Complaint Before");
						}
						else
						{
							MessageBox.Show("اسم الشكوى مسجل من قبل");
						}
						AllData();
						return;
					}
					codes.Edit("update MainComplaint set Complaint ='" + NametextBox.Text + "' where CId = '" + ID + "'");
					MethodsClass.UserMove("تعديل شكوي");
					loadCombo();
					Clear();
					AllData();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Select Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اختر البيانات أولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			EditBtn.Enabled = true;
			saveBtn.Enabled = false;
			ID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
			NametextBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
		}

		private void FrmMainComplaint_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataSource = codes.Search2("select * from MainComplaint");
				comboBox3.DataSource = dataSource;
				comboBox3.ValueMember = "CId";
				comboBox3.DisplayMember = "Complaint";
			}
			catch
			{
			}
			AllData();
			loadCombo();
			Clear();
			EditBtn.Enabled = false;
			saveBtn.Enabled = true;
		}

		private void BackBtn_Click(object sender, EventArgs e)
		{
			AllData();
			loadCombo();
			Clear();
		}

		private void loadCombo()
		{
			try
			{
				DataTable dataSource = codes.Search2("select * from MainComplaint");
				comboBox3.DataSource = dataSource;
				comboBox3.ValueMember = "CId";
				comboBox3.DisplayMember = "Complaint";
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmMainComplaint));
			groupBox5 = new System.Windows.Forms.GroupBox();
			label2 = new System.Windows.Forms.Label();
			comboBox3 = new System.Windows.Forms.ComboBox();
			searchBtn = new System.Windows.Forms.Button();
			groupBox4 = new System.Windows.Forms.GroupBox();
			label3 = new System.Windows.Forms.Label();
			groupBox3 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox2 = new System.Windows.Forms.GroupBox();
			BackBtn = new System.Windows.Forms.Button();
			saveBtn = new System.Windows.Forms.Button();
			EditBtn = new System.Windows.Forms.Button();
			groupBox1 = new System.Windows.Forms.GroupBox();
			NametextBox = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			groupBox5.SuspendLayout();
			groupBox4.SuspendLayout();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox2.SuspendLayout();
			groupBox1.SuspendLayout();
			SuspendLayout();
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.Controls.Add(label2);
			groupBox5.Controls.Add(comboBox3);
			groupBox5.Controls.Add(searchBtn);
			resources.ApplyResources(groupBox5, "groupBox5");
			groupBox5.Name = "groupBox5";
			groupBox5.TabStop = false;
			resources.ApplyResources(label2, "label2");
			label2.BackColor = System.Drawing.Color.Transparent;
			label2.Name = "label2";
			comboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox3.FormattingEnabled = true;
			resources.ApplyResources(comboBox3, "comboBox3");
			comboBox3.Name = "comboBox3";
			searchBtn.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(searchBtn, "searchBtn");
			searchBtn.Name = "searchBtn";
			searchBtn.UseVisualStyleBackColor = false;
			searchBtn.Click += new System.EventHandler(searchBtn_Click);
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.Controls.Add(label3);
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.Controls.Add(dataGridView1);
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseClick);
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(BackBtn);
			groupBox2.Controls.Add(saveBtn);
			groupBox2.Controls.Add(EditBtn);
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			BackBtn.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(BackBtn, "BackBtn");
			BackBtn.Name = "BackBtn";
			BackBtn.UseVisualStyleBackColor = false;
			BackBtn.Click += new System.EventHandler(BackBtn_Click);
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.Name = "saveBtn";
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			EditBtn.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(EditBtn, "EditBtn");
			EditBtn.Name = "EditBtn";
			EditBtn.UseVisualStyleBackColor = false;
			EditBtn.Click += new System.EventHandler(EditBtn_Click);
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(NametextBox);
			groupBox1.Controls.Add(label1);
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			resources.ApplyResources(NametextBox, "NametextBox");
			NametextBox.Name = "NametextBox";
			NametextBox.TextChanged += new System.EventHandler(NametextBox_TextChanged);
			resources.ApplyResources(label1, "label1");
			label1.BackColor = System.Drawing.Color.Transparent;
			label1.Name = "label1";
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(groupBox5);
			base.Controls.Add(groupBox4);
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.Name = "FrmMainComplaint";
			base.Load += new System.EventHandler(FrmMainComplaint_Load);
			groupBox5.ResumeLayout(false);
			groupBox5.PerformLayout();
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			ResumeLayout(false);
		}
	}
}
