using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Media;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class DoctorReserve : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private DateTimePicker dateTimePicker1;

		private GroupBox groupBox2;

		private Label label1;

		private DataGridView dataGridView1;

		private Label label3;

		private Timer timer1;

		private Button DeletBtn;

		private ComboBox comboBox2;

		private ContextMenuStrip contextMenuStrip1;

		private ToolStripMenuItem toolStripMenuItem_0;

		private ClassDataBase dc;

		private int appointID;

		private bool b = false;

		private int id;

		private int patientId;

		private int rowIndex;

		private GUI gui = new GUI();

		private DataGridViewButtonColumn m;

		public static int DoctorId;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private int GridID;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.DoctorReserve));
			groupBox1 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			groupBox2 = new System.Windows.Forms.GroupBox();
			comboBox2 = new System.Windows.Forms.ComboBox();
			label1 = new System.Windows.Forms.Label();
			label3 = new System.Windows.Forms.Label();
			timer1 = new System.Windows.Forms.Timer(components);
			DeletBtn = new System.Windows.Forms.Button();
			contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(components);
			toolStripMenuItem_0 = new System.Windows.Forms.ToolStripMenuItem();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox2.SuspendLayout();
			contextMenuStrip1.SuspendLayout();
			SuspendLayout();
			resources.ApplyResources(label, "label7");
			label.Name = "label7";
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(dataGridView1);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowTemplate.Height = 30;
			dataGridView1.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_CellMouseUp);
			dataGridView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(dataGridView1_MouseDoubleClick);
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			dataGridView1.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_CellMouseDoubleClick);
			dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseClick);
			dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(dataGridView1_CellContentClick);
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			dateTimePicker1.ValueChanged += new System.EventHandler(dateTimePicker1_ValueChanged);
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(comboBox2);
			groupBox2.Controls.Add(label);
			groupBox2.Controls.Add(label3);
			groupBox2.Controls.Add(dateTimePicker1);
			groupBox2.Controls.Add(label1);
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.FormattingEnabled = true;
			comboBox2.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox2.Items"),
				resources.GetString("comboBox2.Items1")
			});
			comboBox2.Name = "comboBox2";
			comboBox2.SelectedIndexChanged += new System.EventHandler(dateTimePicker1_ValueChanged);
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			resources.ApplyResources(label3, "label3");
			label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			label3.ForeColor = System.Drawing.Color.Maroon;
			label3.Name = "label3";
			timer1.Enabled = true;
			timer1.Interval = 10000;
			timer1.Tick += new System.EventHandler(timer1_Tick);
			resources.ApplyResources(DeletBtn, "DeletBtn");
			DeletBtn.BackColor = System.Drawing.Color.Gainsboro;
			DeletBtn.Name = "DeletBtn";
			DeletBtn.UseVisualStyleBackColor = false;
			DeletBtn.Click += new System.EventHandler(DeletBtn_Click);
			contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { toolStripMenuItem_0 });
			contextMenuStrip1.Name = "contextMenuStrip1";
			resources.ApplyResources(contextMenuStrip1, "contextMenuStrip1");
			contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(contextMenuStrip1_Opening);
			contextMenuStrip1.Click += new System.EventHandler(contextMenuStrip1_Click);
			toolStripMenuItem_0.Name = "خدماتالمريضToolStripMenuItem";
			resources.ApplyResources(toolStripMenuItem_0, "خدماتالمريضToolStripMenuItem");
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			base.Controls.Add(groupBox1);
			base.Controls.Add(DeletBtn);
			base.Controls.Add(groupBox2);
			base.Name = "DoctorReserve";
			base.Load += new System.EventHandler(DoctorReserve_Load);
			base.Activated += new System.EventHandler(DoctorReserve_Activated);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(DoctorReserve_KeyDown);
			groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			contextMenuStrip1.ResumeLayout(false);
			ResumeLayout(false);
		}

		public DoctorReserve()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		public void DataGrid(bool Prd)
		{
			m = new DataGridViewButtonColumn();
			m.Name = "PName";
			m.HeaderText = "Patient Name";
			string[] array = new string[3] { "ID", "detectDate", "Prd" };
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView1.Columns["PName"].HeaderText = "Patient Name";
				dataGridView1.Columns["PName"].Width = 150;
				dataGridView1.Columns["Services"].HeaderText = "Services";
				dataGridView1.Columns["Services"].Width = 150;
				dataGridView1.Columns["AppointNum"].HeaderText = "Appointment No.";
				dataGridView1.Columns[1].Width = 100;
				dataGridView1.Columns["ID"].HeaderText = "Appointment Code";
				dataGridView1.Columns["Titel"].HeaderText = " ";
				dataGridView1.Columns["Doctor ID"].Visible = false;
				dataGridView1.Columns["Patient ID"].Visible = false;
				dataGridView1.Columns["PAddress"].HeaderText = "Address";
				dataGridView1.Columns["PAddress"].Width = 200;
				dataGridView1.Columns["Tel"].HeaderText = "Phone";
				dataGridView1.Columns["Mob"].HeaderText = "Mobile";
				dataGridView1.Columns["Price"].HeaderText = "Price";
				dataGridView1.Columns["detectStartTime"].HeaderText = "From";
				dataGridView1.Columns["detectEndTime"].HeaderText = "TO";
				dataGridView1.Columns["Titel"].HeaderText = " ";
				dataGridView1.Columns["NextvisitTXT"].HeaderText = "Next Visit";
				dataGridView1.Columns["NextvisitTXT"].Width = 200;
				dataGridView1.Columns["FileNo"].HeaderText = "File Number";
			}
			else
			{
				dataGridView1.Columns["PName"].Width = 150;
				dataGridView1.Columns[1].HeaderText = "رقم الكشف";
				dataGridView1.Columns["Services"].HeaderText = "الخدمات";
				dataGridView1.Columns["Services"].Width = 150;
				dataGridView1.Columns[1].Width = 100;
				dataGridView1.Columns["ID"].HeaderText = "كود الكشف";
				dataGridView1.Columns["ID"].Visible = false;
				dataGridView1.Columns["Doctor ID"].Visible = false;
				dataGridView1.Columns["Patient ID"].Visible = false;
				dataGridView1.Columns["PAddress"].Width = 200;
				dataGridView1.Columns["AppointNum"].HeaderText = "رقم الكشف";
				dataGridView1.Columns["PName"].HeaderText = "اسم المريض";
				dataGridView1.Columns["Titel"].HeaderText = " ";
				dataGridView1.Columns["Tel"].HeaderText = "التليفون";
				dataGridView1.Columns["Mob"].HeaderText = "الموبايل";
				dataGridView1.Columns["PAddress"].HeaderText = "العنوان";
				dataGridView1.Columns["Price"].HeaderText = "سعر الخدمة";
				dataGridView1.Columns["detectStartTime"].HeaderText = "من";
				dataGridView1.Columns["detectEndTime"].HeaderText = "الى";
				dataGridView1.Columns["NextvisitTXT"].HeaderText = "الزيارة القادمة";
				dataGridView1.Columns["NextvisitTXT"].Width = 200;
				dataGridView1.Columns["FileNo"].HeaderText = "كود المريض";
			}
			if (!b)
			{
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns.Add("Age", "Age");
				}
				else
				{
					dataGridView1.Columns.Add("Age", "السن");
				}
			}
			b = true;
			dataGridView1.Columns["Status"].Visible = false;
			if (Settings.Default.Language == "en-GB")
			{
				foreach (DataGridViewRow item in (IEnumerable)dataGridView1.Rows)
				{
					if (item.Cells["Status"].Value.ToString() == "Confirmed")
					{
						item.DefaultCellStyle.BackColor = Color.FromArgb(187, 240, 188);
					}
					else if (item.Cells["Status"].Value.ToString() == "Not Confirmed")
					{
						item.DefaultCellStyle.BackColor = Color.FromArgb(201, 226, 245);
					}
					else if (item.Cells["Status"].Value.ToString() == "Cancelled")
					{
						item.DefaultCellStyle.BackColor = Color.FromArgb(240, 209, 200);
					}
				}
			}
			else if (Settings.Default.Language == "en-GB")
			{
				foreach (DataGridViewRow item2 in (IEnumerable)dataGridView1.Rows)
				{
					if (item2.Cells["Status"].Value.ToString() == "Confirmed")
					{
						item2.DefaultCellStyle.BackColor = Color.FromArgb(187, 240, 188);
					}
					else if (item2.Cells["Status"].Value.ToString() == "Not Confirmed")
					{
						item2.DefaultCellStyle.BackColor = Color.FromArgb(201, 226, 245);
					}
					else if (item2.Cells["Status"].Value.ToString() == "Cancelled")
					{
						item2.DefaultCellStyle.BackColor = Color.FromArgb(240, 209, 200);
					}
				}
			}
			else
			{
				foreach (DataGridViewRow item3 in (IEnumerable)dataGridView1.Rows)
				{
					if (item3.Cells["Status"].Value.ToString() == "تم التأكيد")
					{
						item3.DefaultCellStyle.BackColor = Color.FromArgb(187, 240, 188);
					}
					else if (item3.Cells["Status"].Value.ToString() == "لم يؤكد")
					{
						item3.DefaultCellStyle.BackColor = Color.FromArgb(201, 226, 245);
					}
					else if (item3.Cells["Status"].Value.ToString() == "تم إلغاؤه")
					{
						item3.DefaultCellStyle.BackColor = Color.FromArgb(240, 209, 200);
					}
				}
			}
			dataGridView1.Columns[13].Visible = false;
			dataGridView1.Columns[14].Visible = false;
			dataGridView1.Columns[15].Visible = false;
			dataGridView1.Columns[16].Visible = false;
			dataGridView1.Columns[17].Visible = false;
			dataGridView1.Columns[18].Visible = false;
			dataGridView1.Columns[19].Visible = false;
			dataGridView1.Columns[20].Visible = false;
			dataGridView1.Columns[21].Visible = false;
			dataGridView1.Columns[22].Visible = false;
			dataGridView1.Columns[23].Visible = false;
			dataGridView1.Columns[24].Visible = false;
			dataGridView1.Columns[25].Visible = false;
			dataGridView1.Columns[26].Visible = false;
			dataGridView1.Columns[27].Visible = false;
			dataGridView1.Columns[28].Visible = false;
			dataGridView1.Columns[29].Visible = false;
			dataGridView1.Columns[30].Visible = false;
			dataGridView1.Columns[31].Visible = false;
			dataGridView1.Columns[32].Visible = false;
			dataGridView1.Columns[33].Visible = false;
			dataGridView1.Columns[34].Visible = false;
			dataGridView1.Columns[35].Visible = false;
			dataGridView1.Columns[36].Visible = false;
			dataGridView1.Columns[37].Visible = false;
			dataGridView1.Columns[38].Visible = false;
			dataGridView1.Columns["BirthDate"].Visible = false;
			dataGridView1.Columns["Age"].Visible = true;
			dataGridView1.Columns["detectStartTime"].Visible = true;
			dataGridView1.Columns["detectEndTime"].Visible = true;
			for (int i = 0; i < dataGridView1.Rows.Count; i++)
			{
				try
				{
					int num = Convert.ToInt32(DateTime.Today.Subtract(Convert.ToDateTime(dataGridView1.Rows[i].Cells["BirthDate"].Value.ToString())).TotalDays / 364.25);
					if (Settings.Default.Language == "en-GB")
					{
						dataGridView1.Rows[i].Cells["Age"].Value = num + " Year";
					}
					else
					{
						dataGridView1.Rows[i].Cells["Age"].Value = num + " سنة";
					}
				}
				catch
				{
				}
			}
		}

		public void sound()
		{
			SoundPlayer soundPlayer = new SoundPlayer(Resources.translate_tts);
			soundPlayer.Play();
		}

		public void Doctor(bool Prd)
		{
			try
			{
				string[] array = new string[3] { "ID", "detectDate", "Prd" };
				DataTable dataTable = codes.Search2("select ServiceName,ServiceDetect from Properties");
				DataTable dataTable2 = new DataTable();
				DataTable dataTable3 = codes.Search2("select AcceptPatients from Properties");
				dataTable2 = (Convert.ToBoolean(dataTable3.Rows[0][0].ToString()) ? codes.Search2("SELECT Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID',PatientData.FileNo, PatientData.Titel, PatientData.PName,'' As Services,PatientData.NextvisitTXT,PatientAccount.Price, PatientData.Tel, PatientData.Mob, PatientData.PAddress,PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes,PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy,PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status,NextVisit,Appointments.Accepted,Appointments.detectStartTime,detectEndTime FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID INNER JOIN Empdata INNER JOIN Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID INNER JOIN PatientAccount ON Appointments.ID = PatientAccount.AppointNum WHERE (Appointments.Status='تم التأكيد' or Appointments.Status='Confirmed') and (Empdata.ID = '" + DoctorId + "') AND (Appointments.detectDate = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "')   and (Appointments.Done='False' and  Appointments.Period='" + Prd + "') and (PatientAccount.Bean ='" + dataTable.Rows[0][0].ToString() + "' or PatientAccount.Bean ='" + dataTable.Rows[0][1].ToString() + "') and PatientData.Active = 'True' GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID,PatientData.FileNo, PatientData.Titel, PatientData.PName,PatientData.NextvisitTXT, PatientData.Tel, PatientData.Mob, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name,PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever,PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed,PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.Opretive, PatientData.Bleaching,Appointments.Status ,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime,PatientAccount.Bean ,Appointments.AcceptDate order by   CONVERT(VARCHAR(10),Appointments.AcceptDate, 108) asc") : ((!(codes.Search2("select AppointSystem from Properties").Rows[0][0].ToString() == "1")) ? codes.Search2("SELECT Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID',PatientData.FileNo, PatientData.Titel, PatientData.PName,'' As Services,PatientData.NextvisitTXT,PatientAccount.Price, PatientData.Tel, PatientData.Mob, PatientData.PAddress,PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes,PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy,PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status,NextVisit,Appointments.Accepted,Appointments.detectStartTime,detectEndTime FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID INNER JOIN Empdata INNER JOIN Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID INNER JOIN PatientAccount ON Appointments.ID = PatientAccount.AppointNum WHERE (Empdata.ID = '" + DoctorId + "') AND (Appointments.detectDate = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "')   and (Appointments.Done='False' and  Appointments.Period='" + Prd + "') and (PatientAccount.Bean ='" + dataTable.Rows[0][0].ToString() + "' or PatientAccount.Bean ='" + dataTable.Rows[0][1].ToString() + "') and PatientData.Active = 'True' GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID,PatientData.FileNo, PatientData.Titel, PatientData.PName,PatientData.NextvisitTXT, PatientData.Tel, PatientData.Mob, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name,PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever,PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed,PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.Opretive, PatientData.Bleaching,Appointments.Status ,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime,PatientAccount.Bean order by Appointments.appointNum asc") : codes.Search2("SELECT Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID',PatientData.FileNo, PatientData.Titel, PatientData.PName,'' As Services,PatientData.NextvisitTXT,PatientAccount.Price, PatientData.Tel, PatientData.Mob, PatientData.PAddress,PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes,PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy,PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status,NextVisit,Appointments.Accepted,Appointments.detectStartTime,detectEndTime FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID INNER JOIN Empdata INNER JOIN Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID INNER JOIN PatientAccount ON Appointments.ID = PatientAccount.AppointNum WHERE (Empdata.ID = '" + DoctorId + "') AND (Appointments.detectDate = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "')   and (Appointments.Done='False' and  Appointments.Period='" + Prd + "') and (PatientAccount.Bean ='" + dataTable.Rows[0][0].ToString() + "' or PatientAccount.Bean ='" + dataTable.Rows[0][1].ToString() + "') and PatientData.Active = 'True' GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID,PatientData.FileNo, PatientData.Titel, PatientData.PName,PatientData.NextvisitTXT, PatientData.Tel, PatientData.Mob, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name,PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever,PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed,PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.Opretive, PatientData.Bleaching,Appointments.Status ,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime,PatientAccount.Bean order by LEFT(Appointments.detectStartTime, 2),substring(Appointments.detectStartTime,4,2) asc")));
				gui.loadDataGrid(dataGridView1, dataTable2);
				DataGrid(Prd);
				try
				{
					for (int i = 0; i < dataTable2.Rows.Count; i++)
					{
						string text = "";
						DataTable dataTable4 = codes.Search2("select  Bean from ReserveService where AppointNum='" + dataTable2.Rows[i][0].ToString() + "'");
						for (int j = 0; j < dataTable4.Rows.Count; j++)
						{
							text = ((!(text == "")) ? (text + " - " + dataTable4.Rows[j][0].ToString()) : dataTable4.Rows[j][0].ToString());
						}
						dataGridView1.Rows[i].Cells["Services"].Value = text;
					}
				}
				catch
				{
				}
				if (dataGridView1.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						label3.Text = "Number Of Reservations: " + Convert.ToString(dataGridView1.Rows.Count.ToString());
					}
					else
					{
						label3.Text = "عدد الحجوزات : " + Convert.ToString(dataGridView1.Rows.Count.ToString());
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					label3.Text = "No Reservation";
				}
				else
				{
					label3.Text = "لا يوجد حجز";
				}
			}
			catch
			{
			}
		}

		private void DoctorReserve_Load(object sender, EventArgs e)
		{
			comboBox2.SelectedIndex = 0;
			Doctor(Prd: false);
		}

		private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
		{
			bool prd = false;
			if (comboBox2.SelectedIndex == 1)
			{
				prd = true;
			}
			Doctor(prd);
		}

		private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
		{
		}

		private void DoctorReserve_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				int pATIENTID = int.Parse(dataGridView1.CurrentRow.Cells[4].Value.ToString());
				PatientAccount patientAccount = new PatientAccount(pATIENTID, int.Parse(dataGridView1.CurrentRow.Cells[1].Value.ToString()));
				patientAccount.Show();
				bool prd = false;
				if (comboBox2.SelectedIndex == 1)
				{
					prd = true;
				}
				Doctor(prd);
				if (dataGridView1.Rows.Count > 0)
				{
					sound();
					if (Settings.Default.Language == "en-GB")
					{
						label3.Text = "Number Of Reservations: " + Convert.ToString(dataGridView1.Rows.Count.ToString());
					}
					else
					{
						label3.Text = "عدد الحجوزات : " + Convert.ToString(dataGridView1.Rows.Count.ToString());
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					label3.Text = "No Reservation";
				}
				else
				{
					label3.Text = "لا يوجد حجز";
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				bool prd = false;
				if (comboBox2.SelectedIndex == 1)
				{
					prd = true;
				}
				Doctor(prd);
			}
			catch
			{
			}
		}

		private void DoctorReserve_Activated(object sender, EventArgs e)
		{
			try
			{
				bool prd = false;
				if (comboBox2.SelectedIndex == 1)
				{
					prd = true;
				}
				Doctor(prd);
			}
			catch
			{
			}
		}

		private void DeletBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					string[] fields;
					string text;
					if (Settings.Default.Language == "en-GB")
					{
						if (MessageBox.Show("Are you Sure You Want To Delete", "Notes", MessageBoxButtons.OKCancel) != DialogResult.OK)
						{
							return;
						}
						fields = new string[1] { "id" };
						codes.Search2("select * from Appointments where id='" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'");
						text = codes.Search2("select PricePay from dbo.PatientAccount where AppointNum ='" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'").Rows[0][0].ToString();
						if (dc.Delete("DeleteAppointment", fields, dataGridView1.Rows[GridID].Cells["ID"].Value.ToString()))
						{
							string text2 = codes.Search2("select ID from Stock").Rows[0][0].ToString();
							codes.Edit2("update Stock Set Value= Value - " + text + " where ID = '" + text2 + "'");
							codes.Delete2("delete from PatientAccount where AppointNum = '" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'");
							if (Convert.ToDecimal(text) > 0m)
							{
								codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('حذف كشف' ," + text + ",'" + dataGridView1.Rows[GridID].Cells["PName"].Value.ToString() + "','" + DateTime.Today.ToString("MM/dd/yyyy") + "','" + text2 + "')");
							}
							MessageBox.Show("Data Delete Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							bool prd = false;
							if (comboBox2.SelectedIndex == 1)
							{
								prd = true;
							}
							Doctor(prd);
						}
						else
						{
							MessageBox.Show("Error Happend While Delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						return;
					}
					if (MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.OKCancel) != DialogResult.OK)
					{
						return;
					}
					fields = new string[1] { "id" };
					codes.Search2("select * from Appointments where id='" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'");
					text = codes.Search2("select PricePay from dbo.PatientAccount where AppointNum ='" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'").Rows[0][0].ToString();
					if (dc.Delete("DeleteAppointment", fields, dataGridView1.Rows[GridID].Cells["ID"].Value.ToString()))
					{
						string text2 = codes.Search2("select ID from Stock").Rows[0][0].ToString();
						codes.Edit2("update Stock Set Value= Value - " + text + " where ID = '" + text2 + "'");
						codes.Delete2("delete from PatientAccount where AppointNum = '" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'");
						if (Convert.ToDecimal(text) > 0m)
						{
							codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('حذف كشف' ," + text + ",'" + dataGridView1.Rows[GridID].Cells["PName"].Value.ToString() + "','" + DateTime.Today.ToString("MM/dd/yyyy") + "','" + text2 + "')");
						}
						MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						bool prd = false;
						if (comboBox2.SelectedIndex == 1)
						{
							prd = true;
						}
						Doctor(prd);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Data");
				}
				else
				{
					MessageBox.Show("من فضلك اختر سجل");
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				GridID = dataGridView1.CurrentRow.Index;
			}
			catch
			{
			}
		}

		private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
		}

		private void dataGridView1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				try
				{
					id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["ID"].Value);
					patientId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["Patient ID"].Value);
					contextMenuStrip1.Show(dataGridView1, e.Location);
					contextMenuStrip1.Show(Cursor.Position);
				}
				catch
				{
				}
			}
		}

		private void contextMenuStrip1_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select ServiceName from Properties");
				DataTable dt = codes.Search2("select Bean,Price from ReserveService where AppointNum = '" + id + "' and Bean != '" + dataTable.Rows[0][0].ToString() + "'");
				FrmAddServices frmAddServices = new FrmAddServices(patientId, dt);
				frmAddServices.ShowDialog();
			}
			catch
			{
			}
		}

		private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
		{
		}
	}
}
