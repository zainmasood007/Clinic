using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmNesbaAssistant : BaseForm
	{
		private ClassDataBase dc;

		private string id;

		private GUI gui = new GUI();

		private GeneralMethods MethodsClass = new GeneralMethods();

		private dataClass codes;

		private IContainer components = null;

		private GroupBox groupBox2;

		private ComboBox doctorcomboBox;

		private ComboBox commentTextBox;

		private TextBox textBox3;

		private TextBox textBox2;

		private TextBox textBox1;

		private TextBox PricetextBox;

		private TextBox textBox4;

		private Button saveBtn;

		private ComboBox comboBox1;

		private GroupBox groupBox3;

		private ComboBox comboBox3;

		private Button button4;

		private GroupBox groupBox4;

		private DataGridView dataGridView1;

		private Button button1;

		private Button button2;

		private Button button3;

		public FrmNesbaAssistant()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
		}

		private void FrmNesbaAssistant_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataSource = codes.Search2("SELECT     dbo.NesbaAssistant.ID,dbo.NesbaAssistant.Assistant, dbo.Company.Name, dbo.NesbaAssistant.Service, dbo.NesbaAssistant.Price, dbo.NesbaAssistant.Cost, dbo.NesbaAssistant.Safy, \r\n                      dbo.NesbaAssistant.Nesba, dbo.NesbaAssistant.NesbaValue\r\nFROM         dbo.NesbaAssistant INNER JOIN\r\n                      dbo.Company ON dbo.NesbaAssistant.Company = dbo.Company.ID");
				dataGridView1.DataSource = dataSource;
				dataGridView1.Columns[0].Visible = false;
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns[1].HeaderText = "Assistant";
					dataGridView1.Columns[2].HeaderText = "Company";
					dataGridView1.Columns[3].HeaderText = "Service";
					dataGridView1.Columns[4].HeaderText = "Price";
					dataGridView1.Columns[5].HeaderText = "Cost on the clinic";
					dataGridView1.Columns[6].HeaderText = "Total";
					dataGridView1.Columns[7].HeaderText = "Percent";
					dataGridView1.Columns[8].HeaderText = "Total After Discount";
				}
				else
				{
					dataGridView1.Columns[1].HeaderText = "المساعد";
					dataGridView1.Columns[2].HeaderText = "الشركة";
					dataGridView1.Columns[3].HeaderText = "الخدمة";
					dataGridView1.Columns[4].HeaderText = "سعر الخدمة";
					dataGridView1.Columns[5].HeaderText = "تكلفةعلى العيادة";
					dataGridView1.Columns[6].HeaderText = "الصافى";
					dataGridView1.Columns[7].HeaderText = "النسبة";
					dataGridView1.Columns[8].HeaderText = "الصافى بعد الخصم";
				}
				dataGridView1.Columns[6].Visible = false;
				dataGridView1.Columns[8].Visible = false;
			}
			catch
			{
			}
			DataTable dataTable = new DataTable();
			try
			{
				dataTable = codes.Search2("SELECT ID, Name FROM Empdata WHERE (Designation = N'Assistant')");
				gui.loadComboBox(doctorcomboBox, dataTable);
			}
			catch
			{
			}
			try
			{
				codes.Search2("select ServiceName from Properties ").Rows[0][0].ToString();
				DataTable dataTable2 = codes.Search2("select distinct(Service) from CompanyService ");
				commentTextBox.DataSource = null;
				commentTextBox.DataSource = dataTable2;
				commentTextBox.DisplayMember = dataTable2.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				comboBox1.DataSource = null;
				DataTable tableText = dc.GetTableText("select * from Company");
				gui.loadComboBox(comboBox1, tableText);
				comboBox1.SelectedItem = comboBox1.Items[0];
			}
			catch
			{
			}
			comboBox1_SelectedIndexChanged(sender, e);
			try
			{
				DataTable dt = codes.Search2("SELECT ID, Name FROM Empdata WHERE (Designation = N'Assistant')");
				gui.loadComboBox(comboBox3, dt);
				comboBox3.SelectedIndex = -1;
			}
			catch
			{
			}
		}

		private void commentTextBox_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

		private void PricetextBox_TextChanged(object sender, EventArgs e)
		{
			textBox2.Text = (Convert.ToDecimal(PricetextBox.Text) - Convert.ToDecimal(textBox1.Text)).ToString();
			textBox4.Text = (Convert.ToDecimal(textBox2.Text) * Convert.ToDecimal(textBox3.Text) / 100m).ToString();
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
			textBox2.Text = (Convert.ToDecimal(PricetextBox.Text) - Convert.ToDecimal(textBox1.Text)).ToString();
			textBox4.Text = (Convert.ToDecimal(textBox2.Text) * Convert.ToDecimal(textBox3.Text) / 100m).ToString();
		}

		private void textBox3_TextChanged(object sender, EventArgs e)
		{
			textBox4.Text = (Convert.ToDecimal(textBox2.Text) * Convert.ToDecimal(textBox3.Text) / 100m).ToString();
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			if (doctorcomboBox.SelectedItem == null)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Assistant Name");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم المساعد");
				}
				return;
			}
			if (comboBox1.SelectedItem == null)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Company Name");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم الشركة");
				}
				return;
			}
			if (commentTextBox.SelectedItem == null)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Service Name");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم الخدمة");
				}
				return;
			}
			DataTable dataTable = codes.Search2(string.Concat("select * from NesbaAssistant where Assistant = '", doctorcomboBox.Text, "' and Company = '", comboBox1.SelectedValue, "' and Service = '", commentTextBox.Text, "'"));
			if (dataTable.Rows.Count > 0)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("This data was previously recorded");
				}
				else
				{
					MessageBox.Show("هذه البيانات تم تسجيلها سابقا");
				}
			}
			else
			{
				codes.Add2(string.Concat("insert into NesbaAssistant (Assistant, Company, Service, Price, Cost, Safy, Nesba, NesbaValue) values('", doctorcomboBox.Text, "','", comboBox1.SelectedValue, "','", commentTextBox.Text, "','", PricetextBox.Text, "','", textBox1.Text, "','", textBox2.Text, "','", textBox3.Text, "','", textBox4.Text, "')"));
			}
			if (Settings.Default.Language == "en-GB")
			{
				MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else
			{
				MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			MethodsClass.UserMove("أضافة حساب لمساعد");
			textBox1.Text = "0";
			textBox3.Text = "0";
			try
			{
				DataTable dataSource = codes.Search2("SELECT     dbo.NesbaAssistant.ID,dbo.NesbaAssistant.Assistant, dbo.Company.Name, dbo.NesbaAssistant.Service, dbo.NesbaAssistant.Price, dbo.NesbaAssistant.Cost, dbo.NesbaAssistant.Safy, \r\n                      dbo.NesbaAssistant.Nesba, dbo.NesbaAssistant.NesbaValue\r\nFROM         dbo.NesbaAssistant INNER JOIN\r\n                      dbo.Company ON dbo.NesbaAssistant.Company = dbo.Company.ID");
				dataGridView1.DataSource = dataSource;
				dataGridView1.Columns[0].Visible = false;
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns[1].HeaderText = "Assistant";
					dataGridView1.Columns[2].HeaderText = "Company";
					dataGridView1.Columns[3].HeaderText = "Service";
					dataGridView1.Columns[4].HeaderText = "Price";
					dataGridView1.Columns[5].HeaderText = "Cost on the clinic";
					dataGridView1.Columns[6].HeaderText = "Total";
					dataGridView1.Columns[7].HeaderText = "Percent";
					dataGridView1.Columns[8].HeaderText = "Total After Discount";
				}
				else
				{
					dataGridView1.Columns[1].HeaderText = "المساعد";
					dataGridView1.Columns[2].HeaderText = "الشركة";
					dataGridView1.Columns[3].HeaderText = "الخدمة";
					dataGridView1.Columns[4].HeaderText = "سعر الخدمة";
					dataGridView1.Columns[5].HeaderText = "تكلفةعلى العيادة";
					dataGridView1.Columns[6].HeaderText = "الصافى";
					dataGridView1.Columns[7].HeaderText = "النسبة";
					dataGridView1.Columns[8].HeaderText = "الصافى بعد الخصم";
				}
				dataGridView1.Columns[6].Visible = false;
				dataGridView1.Columns[8].Visible = false;
			}
			catch
			{
			}
			button2.Enabled = false;
			button3.Enabled = false;
			saveBtn.Enabled = true;
		}

		private void button4_Click(object sender, EventArgs e)
		{
			if (comboBox3.SelectedItem == null)
			{
				MessageBox.Show("من فضلك ادخل اسم المساعد");
				return;
			}
			dataGridView1.DataSource = null;
			dataGridView1.Rows.Clear();
			try
			{
				DataTable dataSource = codes.Search2("SELECT     dbo.NesbaAssistant.ID,dbo.NesbaAssistant.Assistant, dbo.Company.Name, dbo.NesbaAssistant.Service, dbo.NesbaAssistant.Price, dbo.NesbaAssistant.Cost, dbo.NesbaAssistant.Safy, \r\n                      dbo.NesbaAssistant.Nesba, dbo.NesbaAssistant.NesbaValue\r\nFROM         dbo.NesbaAssistant INNER JOIN\r\n                      dbo.Company ON dbo.NesbaAssistant.Company = dbo.Company.ID where dbo.NesbaAssistant.Assistant = '" + comboBox3.Text + "'");
				dataGridView1.DataSource = dataSource;
				dataGridView1.Columns[0].Visible = false;
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns[1].HeaderText = "Assistant";
					dataGridView1.Columns[2].HeaderText = "Company";
					dataGridView1.Columns[3].HeaderText = "Service";
					dataGridView1.Columns[4].HeaderText = "Price";
					dataGridView1.Columns[5].HeaderText = "Cost on the clinic";
					dataGridView1.Columns[6].HeaderText = "Total";
					dataGridView1.Columns[7].HeaderText = "Percent";
					dataGridView1.Columns[8].HeaderText = "Total After Discount";
				}
				else
				{
					dataGridView1.Columns[1].HeaderText = "المساعد";
					dataGridView1.Columns[2].HeaderText = "الشركة";
					dataGridView1.Columns[3].HeaderText = "الخدمة";
					dataGridView1.Columns[4].HeaderText = "سعر الخدمة";
					dataGridView1.Columns[5].HeaderText = "تكلفةعلى العيادة";
					dataGridView1.Columns[6].HeaderText = "الصافى";
					dataGridView1.Columns[7].HeaderText = "النسبة";
					dataGridView1.Columns[8].HeaderText = "الصافى بعد الخصم";
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			textBox1.Text = "0";
			textBox3.Text = "0";
			try
			{
				DataTable dataSource = codes.Search2("SELECT     dbo.NesbaAssistant.ID,dbo.NesbaAssistant.Assistant, dbo.Company.Name, dbo.NesbaAssistant.Service, dbo.NesbaAssistant.Price, dbo.NesbaAssistant.Cost, dbo.NesbaAssistant.Safy, \r\n                      dbo.NesbaAssistant.Nesba, dbo.NesbaAssistant.NesbaValue\r\nFROM         dbo.NesbaAssistant INNER JOIN\r\n                      dbo.Company ON dbo.NesbaAssistant.Company = dbo.Company.ID");
				dataGridView1.DataSource = dataSource;
				dataGridView1.Columns[0].Visible = false;
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns[1].HeaderText = "Assistant";
					dataGridView1.Columns[2].HeaderText = "Company";
					dataGridView1.Columns[3].HeaderText = "Service";
					dataGridView1.Columns[4].HeaderText = "Price";
					dataGridView1.Columns[5].HeaderText = "Cost on the clinic";
					dataGridView1.Columns[6].HeaderText = "Total";
					dataGridView1.Columns[7].HeaderText = "Percent";
					dataGridView1.Columns[8].HeaderText = "Total After Discount";
				}
				else
				{
					dataGridView1.Columns[1].HeaderText = "المساعد";
					dataGridView1.Columns[2].HeaderText = "الشركة";
					dataGridView1.Columns[3].HeaderText = "الخدمة";
					dataGridView1.Columns[4].HeaderText = "سعر الخدمة";
					dataGridView1.Columns[5].HeaderText = "تكلفةعلى العيادة";
					dataGridView1.Columns[6].HeaderText = "الصافى";
					dataGridView1.Columns[7].HeaderText = "النسبة";
					dataGridView1.Columns[8].HeaderText = "الصافى بعد الخصم";
				}
			}
			catch
			{
			}
			button2.Enabled = false;
			button3.Enabled = false;
			saveBtn.Enabled = true;
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			button2.Enabled = true;
			button3.Enabled = true;
			saveBtn.Enabled = false;
			id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
			doctorcomboBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
			comboBox1.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
			commentTextBox.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
			PricetextBox.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
			textBox1.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
			textBox2.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
			textBox3.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
			textBox4.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2(string.Concat("select * from NesbaAssistant where Assistant = '", doctorcomboBox.Text, "' and Company = '", comboBox1.SelectedValue, "' and Service = '", commentTextBox.Text, "' and ID != '", id, "'"));
				if (dataTable.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Can not edit because This data was previously recorded");
					}
					else
					{
						MessageBox.Show("لا يمكن التعديل لان هذه البيانات تم تسجيلها سابقا");
					}
				}
				else
				{
					codes.Edit2(string.Concat("update NesbaAssistant set Assistant = '", doctorcomboBox.Text, "',Company = '", comboBox1.SelectedValue, "',Service = '", commentTextBox.Text, "',Price = '", PricetextBox.Text, "',Cost = '", textBox1.Text, "',Safy = '", textBox2.Text, "',Nesba = '", textBox3.Text, "',NesbaValue = '", textBox4.Text, "' where ID = '", id, "'"));
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Updated Successfully", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم تعديل البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					MethodsClass.UserMove("تعديل حساب لمساعد");
				}
			}
			catch
			{
			}
			textBox1.Text = "0";
			textBox3.Text = "0";
			try
			{
				DataTable dataSource = codes.Search2("SELECT     dbo.NesbaAssistant.ID,dbo.NesbaAssistant.Assistant, dbo.Company.Name, dbo.NesbaAssistant.Service, dbo.NesbaAssistant.Price, dbo.NesbaAssistant.Cost, dbo.NesbaAssistant.Safy, \r\n                      dbo.NesbaAssistant.Nesba, dbo.NesbaAssistant.NesbaValue\r\nFROM         dbo.NesbaAssistant INNER JOIN\r\n                      dbo.Company ON dbo.NesbaAssistant.Company = dbo.Company.ID");
				dataGridView1.DataSource = dataSource;
				dataGridView1.Columns[0].Visible = false;
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns[1].HeaderText = "Assistant";
					dataGridView1.Columns[2].HeaderText = "Company";
					dataGridView1.Columns[3].HeaderText = "Service";
					dataGridView1.Columns[4].HeaderText = "Price";
					dataGridView1.Columns[5].HeaderText = "Cost on the clinic";
					dataGridView1.Columns[6].HeaderText = "Total";
					dataGridView1.Columns[7].HeaderText = "Percent";
					dataGridView1.Columns[8].HeaderText = "Total After Discount";
				}
				else
				{
					dataGridView1.Columns[1].HeaderText = "المساعد";
					dataGridView1.Columns[2].HeaderText = "الشركة";
					dataGridView1.Columns[3].HeaderText = "الخدمة";
					dataGridView1.Columns[4].HeaderText = "سعر الخدمة";
					dataGridView1.Columns[5].HeaderText = "تكلفةعلى العيادة";
					dataGridView1.Columns[6].HeaderText = "الصافى";
					dataGridView1.Columns[7].HeaderText = "النسبة";
					dataGridView1.Columns[8].HeaderText = "الصافى بعد الخصم";
				}
			}
			catch
			{
			}
			button2.Enabled = false;
			button3.Enabled = false;
			saveBtn.Enabled = true;
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				codes.Delete2("delete from NesbaAssistant where ID = '" + id + "'");
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Deleted Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				MethodsClass.UserMove("حذف حساب لمساعد");
			}
			catch
			{
			}
			textBox1.Text = "0";
			textBox3.Text = "0";
			try
			{
				DataTable dataSource = codes.Search2("SELECT     dbo.NesbaAssistant.ID,dbo.NesbaAssistant.Assistant, dbo.Company.Name, dbo.NesbaAssistant.Service, dbo.NesbaAssistant.Price, dbo.NesbaAssistant.Cost, dbo.NesbaAssistant.Safy, \r\n                      dbo.NesbaAssistant.Nesba, dbo.NesbaAssistant.NesbaValue\r\nFROM         dbo.NesbaAssistant INNER JOIN\r\n                      dbo.Company ON dbo.NesbaAssistant.Company = dbo.Company.ID");
				dataGridView1.DataSource = dataSource;
				dataGridView1.Columns[0].Visible = false;
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns[1].HeaderText = "Assistant";
					dataGridView1.Columns[2].HeaderText = "Company";
					dataGridView1.Columns[3].HeaderText = "Service";
					dataGridView1.Columns[4].HeaderText = "Price";
					dataGridView1.Columns[5].HeaderText = "Cost on the clinic";
					dataGridView1.Columns[6].HeaderText = "Total";
					dataGridView1.Columns[7].HeaderText = "Percent";
					dataGridView1.Columns[8].HeaderText = "Total After Discount";
				}
				else
				{
					dataGridView1.Columns[1].HeaderText = "المساعد";
					dataGridView1.Columns[2].HeaderText = "الشركة";
					dataGridView1.Columns[3].HeaderText = "الخدمة";
					dataGridView1.Columns[4].HeaderText = "سعر الخدمة";
					dataGridView1.Columns[5].HeaderText = "تكلفةعلى العيادة";
					dataGridView1.Columns[6].HeaderText = "الصافى";
					dataGridView1.Columns[7].HeaderText = "النسبة";
					dataGridView1.Columns[8].HeaderText = "الصافى بعد الخصم";
				}
			}
			catch
			{
			}
			button2.Enabled = false;
			button3.Enabled = false;
			saveBtn.Enabled = true;
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = dc.GetTableText("select Price from CompanyService where Service = '" + commentTextBox.Text + "'");
				PricetextBox.Text = tableText.Rows[0][0].ToString();
				DataTable tableText2 = dc.GetTableText(string.Concat("SELECT Name, ID, Status, Discount FROM dbo.Company where ID = '", comboBox1.SelectedValue, "'"));
				string text = tableText2.Rows[0][2].ToString();
				if (tableText.Rows.Count > 0)
				{
					if (text == "1")
					{
						string value = (Convert.ToDouble(tableText.Rows[0][0]) * Convert.ToDouble(tableText2.Rows[0][3]) / 100.0).ToString();
						PricetextBox.Text = (Convert.ToDouble(tableText.Rows[0][0]) - Convert.ToDouble(value)).ToString();
					}
					if (text == "2")
					{
						string value2 = codes.Search2("SELECT distinct dbo.DiscountCategory.Discount\r\nFROM         dbo.CompanyService INNER JOIN\r\n                      dbo.Categories ON dbo.CompanyService.CompanyID = dbo.Categories.ID INNER JOIN\r\n                      dbo.DiscountCategory ON dbo.Categories.Name = dbo.DiscountCategory.Category where CompanyService.Service = '" + commentTextBox.Text + "'").Rows[0][0].ToString();
						string value = (Convert.ToDouble(tableText.Rows[0][0]) * Convert.ToDouble(value2) / 100.0).ToString();
						PricetextBox.Text = (Convert.ToDouble(tableText.Rows[0][0]) - Convert.ToDouble(value)).ToString();
					}
					if (text == "3")
					{
						string value2 = codes.Search2("SELECT     Discount\r\nFROM         dbo.DiscountService where Service = '" + commentTextBox.Text + "'").Rows[0][0].ToString();
						string value = (Convert.ToDouble(tableText.Rows[0][0]) * Convert.ToDouble(value2) / 100.0).ToString();
						PricetextBox.Text = (Convert.ToDouble(tableText.Rows[0][0]) - Convert.ToDouble(value)).ToString();
					}
					if (text == "4")
					{
						PricetextBox.Text = tableText.Rows[0][0].ToString();
						string value = "0";
					}
				}
				else
				{
					PricetextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmNesbaAssistant));
			groupBox2 = new System.Windows.Forms.GroupBox();
			comboBox1 = new System.Windows.Forms.ComboBox();
			textBox4 = new System.Windows.Forms.TextBox();
			textBox3 = new System.Windows.Forms.TextBox();
			textBox2 = new System.Windows.Forms.TextBox();
			textBox1 = new System.Windows.Forms.TextBox();
			PricetextBox = new System.Windows.Forms.TextBox();
			commentTextBox = new System.Windows.Forms.ComboBox();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			saveBtn = new System.Windows.Forms.Button();
			groupBox3 = new System.Windows.Forms.GroupBox();
			button4 = new System.Windows.Forms.Button();
			comboBox3 = new System.Windows.Forms.ComboBox();
			groupBox4 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			button1 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label7 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label8 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label9 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label10 = new System.Windows.Forms.Label();
			groupBox2.SuspendLayout();
			groupBox3.SuspendLayout();
			groupBox4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "titelLabel");
			label.Name = "titelLabel";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label1");
			label2.Name = "label1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label2");
			label3.Name = "label2";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label3");
			label4.Name = "label3";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label4");
			label5.Name = "label4";
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "label5");
			label6.Name = "label5";
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "label6");
			label7.Name = "label6";
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "label7");
			label8.Name = "label7";
			label9.AccessibleDescription = null;
			label9.AccessibleName = null;
			resources.ApplyResources(label9, "label8");
			label9.Name = "label8";
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "label9");
			label10.Name = "label9";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(comboBox1);
			groupBox2.Controls.Add(label9);
			groupBox2.Controls.Add(textBox4);
			groupBox2.Controls.Add(label8);
			groupBox2.Controls.Add(label7);
			groupBox2.Controls.Add(textBox3);
			groupBox2.Controls.Add(label6);
			groupBox2.Controls.Add(textBox2);
			groupBox2.Controls.Add(label5);
			groupBox2.Controls.Add(textBox1);
			groupBox2.Controls.Add(label4);
			groupBox2.Controls.Add(PricetextBox);
			groupBox2.Controls.Add(label3);
			groupBox2.Controls.Add(commentTextBox);
			groupBox2.Controls.Add(label2);
			groupBox2.Controls.Add(label);
			groupBox2.Controls.Add(doctorcomboBox);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Name = "comboBox1";
			comboBox1.SelectedIndexChanged += new System.EventHandler(comboBox1_SelectedIndexChanged);
			textBox4.AccessibleDescription = null;
			textBox4.AccessibleName = null;
			resources.ApplyResources(textBox4, "textBox4");
			textBox4.BackgroundImage = null;
			textBox4.Name = "textBox4";
			textBox4.ReadOnly = true;
			textBox3.AccessibleDescription = null;
			textBox3.AccessibleName = null;
			resources.ApplyResources(textBox3, "textBox3");
			textBox3.BackgroundImage = null;
			textBox3.Name = "textBox3";
			textBox3.TextChanged += new System.EventHandler(textBox3_TextChanged);
			textBox2.AccessibleDescription = null;
			textBox2.AccessibleName = null;
			resources.ApplyResources(textBox2, "textBox2");
			textBox2.BackgroundImage = null;
			textBox2.Name = "textBox2";
			textBox2.ReadOnly = true;
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Name = "textBox1";
			textBox1.TextChanged += new System.EventHandler(textBox1_TextChanged);
			PricetextBox.AccessibleDescription = null;
			PricetextBox.AccessibleName = null;
			resources.ApplyResources(PricetextBox, "PricetextBox");
			PricetextBox.BackgroundImage = null;
			PricetextBox.Name = "PricetextBox";
			PricetextBox.TextChanged += new System.EventHandler(PricetextBox_TextChanged);
			commentTextBox.AccessibleDescription = null;
			commentTextBox.AccessibleName = null;
			resources.ApplyResources(commentTextBox, "commentTextBox");
			commentTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			commentTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			commentTextBox.BackgroundImage = null;
			commentTextBox.FormattingEnabled = true;
			commentTextBox.Name = "commentTextBox";
			commentTextBox.SelectedIndexChanged += new System.EventHandler(comboBox1_SelectedIndexChanged);
			doctorcomboBox.AccessibleDescription = null;
			doctorcomboBox.AccessibleName = null;
			resources.ApplyResources(doctorcomboBox, "doctorcomboBox");
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.BackgroundImage = null;
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Name = "doctorcomboBox";
			saveBtn.AccessibleDescription = null;
			saveBtn.AccessibleName = null;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.BackgroundImage = null;
			saveBtn.Name = "saveBtn";
			saveBtn.UseVisualStyleBackColor = true;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(label10);
			groupBox3.Controls.Add(button4);
			groupBox3.Controls.Add(comboBox3);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			button4.AccessibleDescription = null;
			button4.AccessibleName = null;
			resources.ApplyResources(button4, "button4");
			button4.BackgroundImage = null;
			button4.Font = null;
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = true;
			button4.Click += new System.EventHandler(button4_Click);
			comboBox3.AccessibleDescription = null;
			comboBox3.AccessibleName = null;
			resources.ApplyResources(comboBox3, "comboBox3");
			comboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox3.BackgroundImage = null;
			comboBox3.Font = null;
			comboBox3.FormattingEnabled = true;
			comboBox3.Name = "comboBox3";
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(dataGridView1);
			groupBox4.Font = null;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackgroundImage = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(button3);
			base.Controls.Add(button2);
			base.Controls.Add(button1);
			base.Controls.Add(saveBtn);
			base.Controls.Add(groupBox4);
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			Font = null;
			base.Name = "FrmNesbaAssistant";
			base.Load += new System.EventHandler(FrmNesbaAssistant_Load);
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			groupBox4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
		}
	}
}
