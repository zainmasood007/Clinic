using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace DentistClinic
{
	public class ReportBaseForm : Form
	{
		private IContainer components = null;

		public ReportBaseForm()
		{
			SetStyle(ControlStyles.ResizeRedraw, value: true);
			InitializeComponent();
		}

		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Rectangle rect = new Rectangle(0, 0, base.ClientSize.Width, base.ClientSize.Height);
				using (LinearGradientBrush brush = new LinearGradientBrush(rect, Color.SteelBlue, Color.LightSteelBlue, 270f))
				{
					e.Graphics.FillRectangle(brush, rect);
				}
				foreach (Control control in base.Controls)
				{
					if (control is GroupBox)
					{
						control.BackColor = Color.Transparent;
					}
				}
			}
			catch
			{
			}
		}

		private void ReportBaseForm_Load(object sender, EventArgs e)
		{
			try
			{
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.ReportBaseForm));
			SuspendLayout();
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(430, 279);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.Name = "ReportBaseForm";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "ReportBaseForm";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.Load += new System.EventHandler(ReportBaseForm_Load);
			ResumeLayout(false);
		}
	}
}
