using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmDeanSupplier : BaseForm
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		private string ID = "";

		private string Supplier5ID = "";

		private string bayan = "";

		private decimal take = 0m;

		private IContainer components = null;

		private GroupBox groupBox1;

		private ComboBox comboBox2;

		private Label label4;

		private ComboBox comboBox1;

		private Label label3;

		private DateTimePicker dateTimePicker1;

		private Label label2;

		private TextBox textBox11;

		private TextBox textBox4;

		private Label label5;

		private Label label7;

		private GroupBox groupBox4;

		private ComboBox comboBox3;

		private Label label10;

		private DateTimePicker dateTimePicker3;

		private Label label1;

		private DateTimePicker dateTimePicker2;

		private Label label8;

		private Button button3;

		private GroupBox groupBox3;

		private DataGridView dataGridView1;

		private GroupBox groupBox2;

		private Button button2;

		private Button button1;

		private Button button11;

		public FrmDeanSupplier()
		{
			InitializeComponent();
		}

		private void FrmDeanSupplier_Load(object sender, EventArgs e)
		{
			try
			{
				getSuppliers();
				comboBox1.SelectedItem = comboBox1.Items[0];
				comboBox2.SelectedItem = comboBox2.Items[0];
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = Codes.Search2("select * from Supplier");
				DataRow dataRow = dataTable.NewRow();
				if (Settings.Default.Language == "en-GB")
				{
					dataRow["SupName"] = "All Suppliers";
				}
				else
				{
					dataRow["SupName"] = "كل الموردين";
				}
				dataTable.Rows.InsertAt(dataRow, 0);
				comboBox3.DataSource = dataTable;
				comboBox3.DisplayMember = dataTable.Columns[1].ToString();
				comboBox3.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				if (Settings.Default.Language == "en-GB")
				{
					Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [Supplier Name], SupplierNotice.Discount AS [Discount], SupplierNotice.Overto AS [Add], SupplierNotice.Date AS [Date], \r\n                         SupplierNotice.Note AS [Notes],Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID  where SupplierNotice.Note ='رصيد اول المدة'");
				}
				else
				{
					Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [اسم المورد], SupplierNotice.Discount AS خصم, SupplierNotice.Overto AS إضافة, SupplierNotice.Date AS التاريخ, \r\n                         SupplierNotice.Note AS البيان,Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID  where SupplierNotice.Note ='رصيد اول المدة'");
				}
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[6].Visible = false;
			}
			catch
			{
			}
		}

		private void Clear()
		{
			comboBox1.SelectedIndex = 0;
			comboBox2.SelectedIndex = 0;
			dateTimePicker1.Value = DateTime.Today;
			textBox4.Text = "0";
			button11.Visible = true;
			comboBox2.Enabled = true;
			button1.Visible = false;
			button2.Visible = false;
			if (Settings.Default.Language == "en-GB")
			{
				Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [Supplier Name], SupplierNotice.Discount AS [Discount], SupplierNotice.Overto AS [Add], SupplierNotice.Date AS [Date], \r\n                         SupplierNotice.Note AS [Notes],Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID  where SupplierNotice.Note ='رصيد اول المدة'");
			}
			else
			{
				Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [اسم المورد], SupplierNotice.Discount AS خصم, SupplierNotice.Overto AS إضافة, SupplierNotice.Date AS التاريخ, \r\n                         SupplierNotice.Note AS البيان,Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID  where SupplierNotice.Note ='رصيد اول المدة'");
			}
			dataGridView1.Columns[0].Visible = false;
			dataGridView1.Columns[6].Visible = false;
		}

		private void getSuppliers()
		{
			try
			{
				try
				{
					DataTable dataTable = Codes.Search2("select * from Supplier");
					DataRow dataRow = dataTable.NewRow();
					if (Settings.Default.Language == "en-GB")
					{
						dataRow["SupName"] = "<-Choose->";
					}
					else
					{
						dataRow["SupName"] = "<-اختر->";
					}
					comboBox2.DataSource = dataTable;
					comboBox2.DisplayMember = dataTable.Columns[1].ToString();
					comboBox2.ValueMember = dataTable.Columns[0].ToString();
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && textBox4.Text.Contains("."))
					{
						e.Handled = true;
					}
				}
				else
				{
					e.Handled = true;
				}
			}
			catch
			{
			}
		}

		private void textBox4_Leave(object sender, EventArgs e)
		{
			try
			{
				if (textBox4.Text == "")
				{
					textBox4.Text = "0";
				}
			}
			catch
			{
			}
		}

		private DataTable Search2(SqlCommand cmd, string Selectcmdmand)
		{
			DataTable dataTable = new DataTable();
			cmd.CommandType = CommandType.Text;
			cmd.CommandText = Selectcmdmand;
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(cmd);
			sqlDataAdapter.Fill(dataTable);
			return dataTable;
		}

		private void button11_Click(object sender, EventArgs e)
		{
			try
			{
				if (comboBox2.SelectedItem != null && comboBox2.SelectedIndex != -1)
				{
					DataTable dataTable = Codes.Search2("select * from Supplier5 where SupplierID='" + comboBox2.SelectedValue.ToString() + "' and Bayan like '%رصيد اول المدة%'");
					if (dataTable.Rows.Count > 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Have Save This Before");
						}
						else
						{
							MessageBox.Show("رصيد أول المدة لهذا المورد مسجل من قبل");
						}
					}
					else if (Convert.ToDouble(textBox4.Text) > 0.0)
					{
						using (SqlConnection sqlConnection = new SqlConnection(Codes.ConnectionStr))
						{
							sqlConnection.Open();
							SqlCommand sqlCommand = sqlConnection.CreateCommand();
							SqlTransaction sqlTransaction = sqlConnection.BeginTransaction();
							sqlCommand.Connection = sqlConnection;
							sqlCommand.Transaction = sqlTransaction;
							try
							{
								if (comboBox1.SelectedIndex == 1)
								{
									DataTable dataTable2 = Search2(sqlCommand, "select sum(Daen),sum(Madeen) from Supplier5 where SupplierID=" + comboBox2.SelectedValue.ToString());
									decimal num;
									decimal num2;
									try
									{
										num = Convert.ToDecimal(dataTable2.Rows[0][0].ToString());
										num2 = Convert.ToDecimal(dataTable2.Rows[0][1].ToString());
									}
									catch
									{
										num = 0m;
										num2 = 0m;
									}
									decimal num3 = num - num2 - Convert.ToDecimal(textBox4.Text);
									sqlCommand.CommandText = "insert into Supplier5 (SupplierID,Daen,Madeen,Raseed,Bayan,[Date]) values (" + comboBox2.SelectedValue.ToString() + ",0," + Convert.ToDecimal(textBox4.Text) + "," + num3 + ", ' مدين ' + + '" + textBox11.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "')";
									sqlCommand.ExecuteNonQuery();
									string text = Search2(sqlCommand, "select max(id) from supplier5").Rows[0][0].ToString();
									sqlCommand.CommandText = "insert into SupplierNotice (SupplierID,Discount,Overto,Date,Note,Supplier5ID) values (" + comboBox2.SelectedValue.ToString() + "," + Convert.ToDecimal(textBox4.Text) + ",0,'" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + textBox11.Text + "','" + text + "')";
									sqlCommand.ExecuteNonQuery();
									Codes.Add("insert into SupplierAccounts (SupplierID,Pay,[Date],Notes)values(" + comboBox2.SelectedValue.ToString() + "," + Convert.ToDecimal(textBox4.Text) + ",'" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + textBox11.Text + "')");
									textBox4.Text = "0";
								}
								else
								{
									DataTable dataTable2 = Search2(sqlCommand, "select sum(Daen),sum(Madeen) from Supplier5 where SupplierID=" + comboBox2.SelectedValue.ToString());
									decimal num;
									decimal num2;
									try
									{
										num = Convert.ToDecimal(dataTable2.Rows[0][0].ToString());
										num2 = Convert.ToDecimal(dataTable2.Rows[0][1].ToString());
									}
									catch
									{
										num = 0m;
										num2 = 0m;
									}
									decimal num3 = num - num2 + Convert.ToDecimal(textBox4.Text);
									sqlCommand.CommandText = "insert into Supplier5 (SupplierID,Daen,Madeen,Raseed,Bayan,[Date]) values (" + comboBox2.SelectedValue.ToString() + "," + Convert.ToDecimal(textBox4.Text) + ",0," + num3 + ",' دائن ' + + '" + textBox11.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "')";
									sqlCommand.ExecuteNonQuery();
									string text = Search2(sqlCommand, "select max(id) from supplier5").Rows[0][0].ToString();
									sqlCommand.CommandText = "insert into SupplierNotice (SupplierID,Discount,Overto,Date,Note,Supplier5ID) values (" + comboBox2.SelectedValue.ToString() + ",0 ,'" + Convert.ToDecimal(textBox4.Text) + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + textBox11.Text + "','" + text + "')";
									sqlCommand.ExecuteNonQuery();
									Codes.Add("insert into SupplierAccounts (SupplierID,Pay,[Date],Notes)values(" + comboBox2.SelectedValue.ToString() + ",0,'" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + textBox11.Text + "')");
									textBox4.Text = "0";
								}
								sqlTransaction.Commit();
								if (Settings.Default.Language == "en-GB")
								{
									MessageBox.Show("Data Have Been Saved");
								}
								else
								{
									MessageBox.Show("تم حفظ البيانات بنجاح");
								}
								MethodsClass.UserMove("أضافة رصيد أول المدة لمورد");
							}
							catch (Exception)
							{
								sqlTransaction.Rollback();
								if (Settings.Default.Language == "en-GB")
								{
									MessageBox.Show("Error Happend While Saving");
								}
								else
								{
									MessageBox.Show("حدث خطأ أثناء حفظ البيانات");
								}
								return;
							}
						}
						if (Settings.Default.Language == "en-GB")
						{
							Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [Supplier Name], SupplierNotice.Discount AS [Discount], SupplierNotice.Overto AS [Add], SupplierNotice.Date AS [Date], \r\n                         SupplierNotice.Note AS [Notes],Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID  where SupplierNotice.Note ='رصيد اول المدة'");
						}
						else
						{
							Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [اسم المورد], SupplierNotice.Discount AS خصم, SupplierNotice.Overto AS إضافة, SupplierNotice.Date AS التاريخ, \r\n                         SupplierNotice.Note AS البيان,Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID  where SupplierNotice.Note ='رصيد اول المدة'");
						}
						dataGridView1.Columns[0].Visible = false;
						dataGridView1.Columns[6].Visible = false;
						Clear();
					}
					else
					{
						MessageBox.Show("من فضلك ادخل المبلغ");
					}
				}
				else
				{
					MessageBox.Show("من فضلك اختار اسم المورد");
				}
			}
			catch
			{
				MessageBox.Show("تاكد من إدخال المبلغ بطريقه صحيحه");
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				if (comboBox3.SelectedIndex == 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [Supplier Name], SupplierNotice.Discount AS [Discount], SupplierNotice.Overto AS [Add], SupplierNotice.Date AS [Date], \r\n                         SupplierNotice.Note AS [Notes],Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID  where SupplierNotice.Note ='رصيد اول المدة'");
					}
					else
					{
						Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [اسم المورد], SupplierNotice.Discount AS خصم, SupplierNotice.Overto AS إضافة, SupplierNotice.Date AS التاريخ, \r\n                         SupplierNotice.Note AS البيان,Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID   where SupplierNotice.Note ='رصيد اول المدة' ");
					}
					dataGridView1.Columns[0].Visible = false;
					dataGridView1.Columns[6].Visible = false;
				}
				else
				{
					if (Settings.Default.Language == "en-GB")
					{
						Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [Supplier Name], SupplierNotice.Discount AS [Discount], SupplierNotice.Overto AS [Add], SupplierNotice.Date AS [Date], \r\n                         SupplierNotice.Note AS [Notes],Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID  where SupplierNotice.Note ='رصيد اول المدة' and SupplierNotice.SupplierID='" + comboBox3.SelectedValue.ToString() + "' ");
					}
					else
					{
						Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [اسم المورد], SupplierNotice.Discount AS خصم, SupplierNotice.Overto AS إضافة, SupplierNotice.Date AS التاريخ, \r\n                         SupplierNotice.Note AS البيان,Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID where SupplierNotice.Note ='رصيد اول المدة' and SupplierNotice.SupplierID='" + comboBox3.SelectedValue.ToString() + "' ");
					}
					dataGridView1.Columns[0].Visible = false;
					dataGridView1.Columns[6].Visible = false;
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				if (dataGridView1.CurrentRow.Cells[6].Value.ToString() == "")
				{
					MessageBox.Show("This Notes can not be modified or deleted");
					return;
				}
				ID = dataGridView1.CurrentRow.Cells[0].Value.ToString();
				decimal num = 0m;
				decimal num2 = 0m;
				num = Convert.ToDecimal(dataGridView1.CurrentRow.Cells[2].Value.ToString());
				num2 = Convert.ToDecimal(dataGridView1.CurrentRow.Cells[3].Value.ToString());
				if (num > 0m)
				{
					textBox4.Text = num.ToString();
					comboBox1.SelectedIndex = 1;
				}
				else
				{
					textBox4.Text = num2.ToString();
					comboBox1.SelectedIndex = 0;
				}
				take = num2 - num;
				comboBox2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
				dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[4].Value.ToString());
				textBox11.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
				bayan = dataGridView1.CurrentRow.Cells[5].Value.ToString();
				Supplier5ID = dataGridView1.CurrentRow.Cells[6].Value.ToString();
				button11.Visible = false;
				comboBox2.Enabled = false;
				button1.Visible = true;
				button2.Visible = true;
			}
			catch
			{
			}
		}

		public void DealSupplier5(int Supplier5ID, string SupplierId, decimal NewDaen, decimal NewMadean, decimal NewRassed, string NewDate, string bayan)
		{
			decimal num = 0m;
			DataTable dataTable = Codes.Search2("select max (id) from Supplier5 where Id<'" + Supplier5ID + "' and SupplierID='" + SupplierId + "'");
			if (dataTable.Rows.Count <= 0)
			{
				return;
			}
			Codes.Edit2("UPDATE Supplier5 SET Daen ='" + NewDaen + "', Madeen ='" + NewMadean + "', Raseed ='" + NewRassed + "',Date='" + NewDate + "',Bayan='" + bayan + "' where Id='" + Supplier5ID + "'");
			num = NewRassed;
			DataTable dataTable2 = Codes.Search2("select id from Supplier5 where id>'" + Supplier5ID + "' and SupplierID='" + SupplierId + "'");
			for (int i = 0; i < dataTable2.Rows.Count; i++)
			{
				DataTable dataTable3 = Codes.Search2("SELECT     Daen, Madeen, Raseed FROM  Supplier5 where Id='" + dataTable2.Rows[i][0].ToString() + "'");
				if (Convert.ToDecimal(dataTable3.Rows[0][0].ToString()) > 0m)
				{
					num += Convert.ToDecimal(dataTable3.Rows[0][0].ToString());
					Codes.Edit2("UPDATE Supplier5 SET Raseed ='" + num + "' where Id='" + dataTable2.Rows[i][0].ToString() + "'");
				}
				if (Convert.ToDecimal(dataTable3.Rows[0][1].ToString()) > 0m)
				{
					num -= Convert.ToDecimal(dataTable3.Rows[0][1].ToString());
					Codes.Edit2("UPDATE Supplier5 SET  Raseed ='" + num + "' where Id='" + dataTable2.Rows[i][0].ToString() + "'");
				}
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (textBox4.Text != "0")
				{
					using (SqlConnection sqlConnection = new SqlConnection(Codes.ConnectionStr))
					{
						sqlConnection.Open();
						SqlCommand sqlCommand = sqlConnection.CreateCommand();
						SqlTransaction sqlTransaction = sqlConnection.BeginTransaction();
						sqlCommand.Connection = sqlConnection;
						sqlCommand.Transaction = sqlTransaction;
						try
						{
							if (comboBox1.SelectedIndex == 1)
							{
								DataTable dataTable = Search2(sqlCommand, "select raseed from Supplier5 where id = '" + Supplier5ID + "'");
								decimal newRassed = 0m;
								if (dataTable.Rows.Count > 0)
								{
									newRassed = Convert.ToDecimal(dataTable.Rows[0][0].ToString());
								}
								newRassed -= take + Convert.ToDecimal(textBox4.Text);
								DealSupplier5(Convert.ToInt32(Supplier5ID), comboBox2.SelectedValue.ToString(), 0m, Convert.ToDecimal(textBox4.Text), newRassed, dateTimePicker1.Value.ToString("MM/dd/yyyy"), " مدين " + textBox11.Text);
								sqlCommand.CommandText = "update SupplierNotice set Discount='" + textBox4.Text + "', Overto='0', Date='" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "', Note='" + textBox11.Text + "' where ID='" + ID + "'";
								sqlCommand.ExecuteNonQuery();
							}
							else
							{
								DataTable dataTable = Search2(sqlCommand, "select raseed from Supplier5 where id = '" + Supplier5ID + "'");
								decimal newRassed = 0m;
								if (dataTable.Rows.Count > 0)
								{
									newRassed = Convert.ToDecimal(dataTable.Rows[0][0].ToString());
								}
								newRassed -= take - Convert.ToDecimal(textBox4.Text);
								DealSupplier5(Convert.ToInt32(Supplier5ID), comboBox2.SelectedValue.ToString(), Convert.ToDecimal(textBox4.Text), 0m, newRassed, dateTimePicker1.Value.ToString("MM/dd/yyyy"), " دائن " + textBox11.Text);
								sqlCommand.CommandText = "update SupplierNotice set Discount='0', Overto='" + textBox4.Text + "', Date='" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "', Note='" + textBox11.Text + "' where ID='" + ID + "'";
								sqlCommand.ExecuteNonQuery();
							}
							sqlTransaction.Commit();
							if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("Data Have Been Saved");
							}
							else
							{
								MessageBox.Show("تم حفظ البيانات بنجاح");
							}
							MethodsClass.UserMove("تعديل رصيد أول المدة لمورد");
						}
						catch (Exception)
						{
							sqlTransaction.Rollback();
							if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("Error Happend While Saving");
							}
							else
							{
								MessageBox.Show("حدث خطأ أثناء حفظ البيانات");
							}
							return;
						}
					}
					if (Settings.Default.Language == "en-GB")
					{
						Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [Supplier Name], SupplierNotice.Discount AS [Discount], SupplierNotice.Overto AS [Add], SupplierNotice.Date AS [Date], \r\n                         SupplierNotice.Note AS [Notes],Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID  where SupplierNotice.Note ='رصيد اول المدة'");
					}
					else
					{
						Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [اسم المورد], SupplierNotice.Discount AS خصم, SupplierNotice.Overto AS إضافة, SupplierNotice.Date AS التاريخ, \r\n                         SupplierNotice.Note AS البيان,Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID where SupplierNotice.Note ='رصيد اول المدة'");
					}
					dataGridView1.Columns[0].Visible = false;
					dataGridView1.Columns[6].Visible = false;
					Clear();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Amount", "Error", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("من فضلك أدخل المبلغ", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
			}
		}

		public void DealSupplier5(SqlCommand cmd, int Supplier5ID, string SupplierId, decimal NewDaen, decimal NewMadean, decimal NewRassed, string NewDate, string bayan)
		{
			decimal num = 0m;
			DataTable dataTable = Search2(cmd, "select max (id) from Supplier5 where Id<'" + Supplier5ID + "' and SupplierID='" + SupplierId + "'");
			if (dataTable.Rows.Count <= 0)
			{
				return;
			}
			cmd.CommandText = "UPDATE Supplier5 SET Daen ='" + NewDaen + "', Madeen ='" + NewMadean + "', Raseed ='" + NewRassed + "',Date='" + NewDate + "',Bayan='" + bayan + "' where Id='" + Supplier5ID + "'";
			cmd.ExecuteNonQuery();
			num = NewRassed;
			DataTable dataTable2 = Search2(cmd, "select id from Supplier5 where id>'" + Supplier5ID + "' and SupplierID='" + SupplierId + "'");
			for (int i = 0; i < dataTable2.Rows.Count; i++)
			{
				DataTable dataTable3 = Search2(cmd, "SELECT     Daen, Madeen, Raseed FROM  Supplier5 where Id='" + dataTable2.Rows[i][0].ToString() + "'");
				if (Convert.ToDecimal(dataTable3.Rows[0][0].ToString()) > 0m)
				{
					num += Convert.ToDecimal(dataTable3.Rows[0][0].ToString());
					cmd.CommandText = "UPDATE Supplier5 SET Raseed ='" + num + "' where Id='" + dataTable2.Rows[i][0].ToString() + "'";
					cmd.ExecuteNonQuery();
				}
				if (Convert.ToDecimal(dataTable3.Rows[0][1].ToString()) > 0m)
				{
					num -= Convert.ToDecimal(dataTable3.Rows[0][1].ToString());
					cmd.CommandText = "UPDATE Supplier5 SET  Raseed ='" + num + "' where Id='" + dataTable2.Rows[i][0].ToString() + "'";
					cmd.ExecuteNonQuery();
				}
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				DialogResult dialogResult = DialogResult.None;
				dialogResult = ((!(Settings.Default.Language == "en-GB")) ? MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Question) : MessageBox.Show("Are You Sure You Want To Delete This Data?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question));
				if (dialogResult != DialogResult.Yes)
				{
					return;
				}
				using (SqlConnection sqlConnection = new SqlConnection(Codes.ConnectionStr))
				{
					sqlConnection.Open();
					SqlCommand sqlCommand = sqlConnection.CreateCommand();
					SqlTransaction sqlTransaction = sqlConnection.BeginTransaction();
					sqlCommand.Connection = sqlConnection;
					sqlCommand.Transaction = sqlTransaction;
					try
					{
						if (comboBox1.SelectedIndex == 0)
						{
							sqlCommand.CommandText = "delete from Supplier5 where id='" + Supplier5ID + "'";
							sqlCommand.ExecuteNonQuery();
							sqlCommand.CommandText = string.Concat("update Supplier5 set raseed =raseed-'", take, "'  where id > '", Supplier5ID, "' and SupplierID='", comboBox2.SelectedValue, "'");
							sqlCommand.ExecuteNonQuery();
						}
						else
						{
							sqlCommand.CommandText = "delete from Supplier5 where id='" + Supplier5ID + "'";
							sqlCommand.ExecuteNonQuery();
							sqlCommand.CommandText = string.Concat("update Supplier5 set raseed =raseed-'", take, "'  where id > '", Supplier5ID, "' and SupplierID='", comboBox2.SelectedValue, "'");
							sqlCommand.ExecuteNonQuery();
						}
						sqlCommand.CommandText = "delete from SupplierNotice where ID='" + ID + "'";
						sqlCommand.ExecuteNonQuery();
						sqlTransaction.Commit();
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Deleted Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove("حذف رصيد أول المدة لمورد");
					}
					catch (Exception)
					{
						sqlTransaction.Rollback();
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("An Error Occurred During The Deletion Process ");
						}
						else
						{
							MessageBox.Show("حدث خطأ أثناء حذف البيانات");
						}
						return;
					}
				}
				if (Settings.Default.Language == "en-GB")
				{
					Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [Supplier Name], SupplierNotice.Discount AS [Discount], SupplierNotice.Overto AS [Add], SupplierNotice.Date AS [Date], \r\n                         SupplierNotice.Note AS [Notes],Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID  where SupplierNotice.Note ='رصيد اول المدة'");
				}
				else
				{
					Codes.FillDataGrid2(dataGridView1, "SELECT        SupplierNotice.ID, Supplier.SupName AS [اسم المورد], SupplierNotice.Discount AS خصم, SupplierNotice.Overto AS إضافة, SupplierNotice.Date AS التاريخ, \r\n                         SupplierNotice.Note AS البيان,Supplier5ID\r\nFROM            SupplierNotice INNER JOIN\r\n                         Supplier ON SupplierNotice.SupplierID = Supplier.SupplierID where SupplierNotice.Note ='رصيد اول المدة'");
				}
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[6].Visible = false;
				Clear();
			}
			catch
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("An Error Occurred During The Deletion Process ", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmDeanSupplier));
			groupBox1 = new System.Windows.Forms.GroupBox();
			comboBox2 = new System.Windows.Forms.ComboBox();
			label4 = new System.Windows.Forms.Label();
			comboBox1 = new System.Windows.Forms.ComboBox();
			label3 = new System.Windows.Forms.Label();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label2 = new System.Windows.Forms.Label();
			textBox11 = new System.Windows.Forms.TextBox();
			textBox4 = new System.Windows.Forms.TextBox();
			label5 = new System.Windows.Forms.Label();
			label7 = new System.Windows.Forms.Label();
			groupBox4 = new System.Windows.Forms.GroupBox();
			comboBox3 = new System.Windows.Forms.ComboBox();
			label10 = new System.Windows.Forms.Label();
			dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
			label1 = new System.Windows.Forms.Label();
			dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			label8 = new System.Windows.Forms.Label();
			button3 = new System.Windows.Forms.Button();
			groupBox3 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox2 = new System.Windows.Forms.GroupBox();
			button2 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			button11 = new System.Windows.Forms.Button();
			groupBox1.SuspendLayout();
			groupBox4.SuspendLayout();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox2.SuspendLayout();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(comboBox2);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(comboBox1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(dateTimePicker1);
			groupBox1.Controls.Add(label5);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(textBox11);
			groupBox1.Controls.Add(textBox4);
			groupBox1.Controls.Add(label7);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			comboBox2.AccessibleDescription = null;
			comboBox2.AccessibleName = null;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.BackgroundImage = null;
			comboBox2.Font = null;
			comboBox2.FormattingEnabled = true;
			comboBox2.Name = "comboBox2";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Font = null;
			label4.ForeColor = System.Drawing.Color.Black;
			label4.Name = "label4";
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox1.Font = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox1.Items"),
				resources.GetString("comboBox1.Items1")
			});
			comboBox1.Name = "comboBox1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Font = null;
			label3.ForeColor = System.Drawing.Color.Black;
			label3.Name = "label3";
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.CustomFormat = null;
			dateTimePicker1.Font = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Font = null;
			label2.ForeColor = System.Drawing.Color.Black;
			label2.Name = "label2";
			textBox11.AccessibleDescription = null;
			textBox11.AccessibleName = null;
			resources.ApplyResources(textBox11, "textBox11");
			textBox11.BackgroundImage = null;
			textBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			textBox11.Font = null;
			textBox11.Name = "textBox11";
			textBox4.AccessibleDescription = null;
			textBox4.AccessibleName = null;
			resources.ApplyResources(textBox4, "textBox4");
			textBox4.BackgroundImage = null;
			textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			textBox4.Font = null;
			textBox4.Name = "textBox4";
			textBox4.Leave += new System.EventHandler(textBox4_Leave);
			textBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(textBox4_KeyPress);
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label5");
			label5.Font = null;
			label5.ForeColor = System.Drawing.Color.Black;
			label5.Name = "label5";
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "label7");
			label7.Font = null;
			label7.ForeColor = System.Drawing.Color.Black;
			label7.Name = "label7";
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(comboBox3);
			groupBox4.Controls.Add(label10);
			groupBox4.Controls.Add(dateTimePicker3);
			groupBox4.Controls.Add(button3);
			groupBox4.Controls.Add(label1);
			groupBox4.Controls.Add(dateTimePicker2);
			groupBox4.Controls.Add(label8);
			groupBox4.Font = null;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			comboBox3.AccessibleDescription = null;
			comboBox3.AccessibleName = null;
			resources.ApplyResources(comboBox3, "comboBox3");
			comboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox3.BackgroundImage = null;
			comboBox3.Font = null;
			comboBox3.FormattingEnabled = true;
			comboBox3.Name = "comboBox3";
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "label10");
			label10.Font = null;
			label10.ForeColor = System.Drawing.Color.Black;
			label10.Name = "label10";
			dateTimePicker3.AccessibleDescription = null;
			dateTimePicker3.AccessibleName = null;
			resources.ApplyResources(dateTimePicker3, "dateTimePicker3");
			dateTimePicker3.BackgroundImage = null;
			dateTimePicker3.CalendarFont = null;
			dateTimePicker3.CustomFormat = null;
			dateTimePicker3.Font = null;
			dateTimePicker3.Name = "dateTimePicker3";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.ForeColor = System.Drawing.Color.Black;
			label1.Name = "label1";
			dateTimePicker2.AccessibleDescription = null;
			dateTimePicker2.AccessibleName = null;
			resources.ApplyResources(dateTimePicker2, "dateTimePicker2");
			dateTimePicker2.BackgroundImage = null;
			dateTimePicker2.CalendarFont = null;
			dateTimePicker2.CustomFormat = null;
			dateTimePicker2.Font = null;
			dateTimePicker2.Name = "dateTimePicker2";
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "label8");
			label8.Font = null;
			label8.ForeColor = System.Drawing.Color.Black;
			label8.Name = "label8";
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackgroundImage = null;
			button3.Font = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(dataGridView1);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(button2);
			groupBox2.Controls.Add(button1);
			groupBox2.Controls.Add(button11);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			button11.AccessibleDescription = null;
			button11.AccessibleName = null;
			resources.ApplyResources(button11, "button11");
			button11.BackgroundImage = null;
			button11.Font = null;
			button11.Name = "button11";
			button11.UseVisualStyleBackColor = true;
			button11.Click += new System.EventHandler(button11_Click);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightGray;
			BackgroundImage = null;
			base.Controls.Add(groupBox4);
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FrmDeanSupplier";
			base.Load += new System.EventHandler(FrmDeanSupplier_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox2.ResumeLayout(false);
			ResumeLayout(false);
		}
	}
}
