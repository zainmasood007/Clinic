using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Media;
using System.Net;
using System.Net.Mail;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using DentistClinic.Properties;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;

namespace DentistClinic
{
	public class Main : Form
	{
		private class MenuColorTable : ProfessionalColorTable
		{
			public override Color MenuBorder => Color.FromArgb(69, 203, 235);

			public override Color MenuItemBorder => Color.FromArgb(69, 203, 235);

			public override Color MenuItemSelected => Color.FromArgb(69, 203, 235);

			public override Color MenuItemSelectedGradientBegin => Color.FromArgb(69, 203, 235);

			public override Color MenuItemSelectedGradientEnd => Color.FromArgb(69, 203, 235);

			public override Color MenuStripGradientBegin => Color.FromArgb(69, 203, 235);

			public override Color MenuStripGradientEnd => Color.FromArgb(69, 203, 235);

			public MenuColorTable()
			{
				base.UseSystemColors = false;
			}
		}

		private class BlueRenderer : ToolStripProfessionalRenderer
		{
			protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
			{
				if (!e.Item.Selected)
				{
					base.OnRenderItemBackground(e);
					return;
				}
				Rectangle rect = new Rectangle(Point.Empty, e.Item.Size);
				SolidBrush brush = new SolidBrush(Color.FromArgb(69, 203, 235));
				e.Graphics.FillRectangle(brush, rect);
			}
		}

		private const short SWP_NOSIZE = 1;

		private const short SWP_NOMOVE = 2;

		private const int SWP_NOZORDER = 4;

		private const int SWP_SHOWWINDOW = 64;

		private const int WS_THICKFRAME = 262144;

		private const int GWL_STYLE = -16;

		private IContainer components = null;

		private SaveFileDialog saveBackupDialog;

		private OpenFileDialog openBackupDialog;

		private Panel panel1;

		private Button TpatientXray;

		private Button tAppointment;

		private Button tAddPatient;

		private Button tPatientPay;

		private Button tPatientAccount;

		private Button vistaButton2;

		private Button AppointmentListBtn;

		private Panel panelappointment;

		private Button FrmLimitOrderRptBtn;

		private MenuStrip menuStrip1;

		private ToolStripMenuItem PatientBtn;

		private ToolStripMenuItem toolStripMenuItem_0;

		private ToolStripMenuItem AddPatientBtn;

		private ToolStripMenuItem searchPatientBtn;

		private ToolStripMenuItem CompanyService;

		private ToolStripMenuItem MainComplaintBtn;

		private ToolStripMenuItem SecretaryPatientBtn;

		private ToolStripMenuItem DoctorPatientBtn;

		private ToolStripMenuItem AccountBtn;

		private ToolStripMenuItem expensesToolStripMenuItem;

		private ToolStripMenuItem ReportsBtn;

		private ToolStripMenuItem toolStripMenuItem7;

		private ToolStripMenuItem EmployeeBtn;

		private ToolStripMenuItem IncomingSuppBtn;

		private ToolStripMenuItem ItemsFrmBtn;

		private ToolStripMenuItem button1;

		private ToolStripMenuItem DentalDataBtn;

		private ToolStripMenuItem PatientListBtn;

		private ToolStripMenuItem PackPatientListBtn;

		private ToolStripMenuItem medicineFrmBtn;

		private ToolStripMenuItem PrescriptionFrmBtn;

		private ToolStripMenuItem DoctorVisits;

		private ToolStripMenuItem PatientSurgery;

		private ToolStripMenuItem revenuesToolStripMenuItem;

		private ToolStripMenuItem doctorAcountBtn;

		private ToolStripMenuItem toolStripMenuItem1;

		private ToolStripMenuItem toolStripMenuItem3;

		private ToolStripMenuItem PatientAccountRptBtn;

		private ToolStripMenuItem AllPatientAccountBtn;

		private ToolStripMenuItem MovementOfPatientStatmentBtn;

		private ToolStripMenuItem OldServicesRptFrmBtn;

		private ToolStripMenuItem RptTaqweem;

		private ToolStripMenuItem DoctorAcountRptBtn;

		private ToolStripMenuItem DoctorPaymentBtn;

		private ToolStripMenuItem MovementOfPatByDr;

		private ToolStripMenuItem expensesToolStripMenuItem1;

		private ToolStripMenuItem revenuesToolStripMenuItem1;

		private ToolStripMenuItem dailyClinicToolStripMenuItem;

		private ToolStripMenuItem NetDailyClinicRptFrmBtn;

		private ToolStripMenuItem ClinicMonthGraphRptFrmBtn;

		private ToolStripMenuItem DailymeasureRotFrmBtn;

		private ToolStripMenuItem BtnFrmRptReb7ya;

		private ToolStripMenuItem FrmInventoryRptBtn;

		private ToolStripMenuItem FrmSearchMedicine;

		private ToolStripMenuItem FrmRptSahbItemBtn;

		private ToolStripMenuItem BtnFrmRptCompanies_Services;

		private ToolStripMenuItem SupplierBtn;

		private ToolStripMenuItem IncomingBillFrmBtn;

		private ToolStripMenuItem FrmSupplierAccountsBtn;

		private ToolStripMenuItem FrmRptBillByDateBtn;

		private ToolStripMenuItem SahbItemsBtn;

		private ToolStripMenuItem FrmBillIncomeRptBtn;

		private ToolStripMenuItem BtnFrmSell;

		private ToolStripMenuItem FrmRptSellByDateBtn;

		private ToolStripMenuItem FormSupplier5Btn;

		private ToolStripMenuItem addEmployeeBtn;

		private ToolStripMenuItem PermissionBtn;

		private ToolStripMenuItem FrmPropertiesBtn;

		private ToolStripMenuItem btnBackup_Restore;

		private ToolStripMenuItem FrmPatientInoculationBtn;

		private ToolStripMenuItem FrmRptPatientDebtBtn;

		private ToolStripMenuItem FrmBillBtn;

		private Panel panel2;

		private Label label4;

		private Label label3;

		private Label label1;

		private ToolStripMenuItem FrmRptSurgeryBtn;

		private ToolStripMenuItem CompanyPayBtn;

		private ToolStripMenuItem FrmRptCompanyAcountBtn;

		private ToolStripMenuItem FrmRptSpecialBtn;

		private ToolStripMenuItem AssistantAccountBtn;

		private ToolStripMenuItem toolStripMenuItem2;

		private ToolStripMenuItem RptAssistantPaymentBtn;

		private ToolStripMenuItem AssistantAcountDate;

		private ToolStripMenuItem FrmAssistantRptBtn;

		private ToolStripMenuItem RptLoginUserBtn;

		private ToolStripMenuItem StockFrmBtn;

		private ToolStripMenuItem StockUsersFrmBtn;

		public Label label2;

		private ToolStripMenuItem FrmTarnsbetweenStockBtn;

		private ToolStripMenuItem StockTransRptFrmBtn;

		private ToolStripMenuItem FrmDeanSupplierBtn;

		private ToolStripMenuItem ReserveServiceRptFrmBtn;

		private ToolStripMenuItem FrmEsalBtn;

		private ToolStripMenuItem FrmRptRayAnalyzeBtn;

		private ToolStripMenuItem CategoryBtn;

		private System.Windows.Forms.Timer timer1;

		public Label label5;

		private Label label6;

		private Button button14;

		private Panel panel4;

		private Panel panel3;

		private Label label8;

		private ComboBox comboBox1;

		private Label label7;

		private Button button3;

		private Label label9;

		private Label label10;

		private ToolStripMenuItem PatientPointRptBtn;

		private ToolStripMenuItem RptKnowFromBtn;

		private ToolStripMenuItem toolStripMenuItem4;

		private ToolStripMenuItem toolStripMenuItem5;

		private Panel panel5;

		private Button button2;

		private ToolStripMenuItem toolStripMenuItem6;

		private ToolStripMenuItem toolStripMenuItem_1;

		private ToolStripMenuItem toolStripMenuItem_2;

		private ToolStripMenuItem toolStripMenuItem10;

		private ToolStripMenuItem toolStripMenuItem11;

		private ToolStripMenuItem toolStripMenuItem12;

		private System.Windows.Forms.Timer timerEmail;

		private NotifyIcon TrayIcon;

		private ToolStripMenuItem toolStripMenuItem_3;

		private Label label11;

		public Label label12;

		private ToolStripMenuItem toolStripMenuItem_4;

		private ToolStripMenuItem toolStripMenuItem_5;

		private Button button4;

		private ToolStripMenuItem toolStripMenuItem_6;

		private ToolStripMenuItem toolStripMenuItem_7;

		private ToolStripMenuItem toolStripMenuItem_8;

		private ToolStripMenuItem toolStripMenuItem9;

		private ToolStripMenuItem toolStripMenuItem_9;

		private ToolStripMenuItem toolStripMenuItem_10;

		private ToolStripMenuItem toolStripMenuItem_11;

		private System.Windows.Forms.Timer timerMobile;

		private FolderBrowserDialog folderBrowserDialog1;

		private System.Windows.Forms.Timer timer2;

		private ToolStripMenuItem naturaltherapy;

		private ToolStripMenuItem toolStripMenuItem14;

		private ToolStripMenuItem orthopedicalPhysiotherapyToolStripMenuItem;

		private ToolStripMenuItem neurologicalPhysiotherapyToolStripMenuItem;

		private ToolStripMenuItem toolStripMenuItem_12;

		private ToolStripMenuItem toolStripMenuItem_13;

		private ToolStripMenuItem appointmentBtn;

		private ToolStripMenuItem editReBackDateBtn;

		private ToolStripMenuItem secretPatientList;

		private ToolStripMenuItem secretRebackPatientList;

		private ToolStripMenuItem BookingVisits;

		private ToolStripMenuItem SecretaryVisits;

		private ToolStripMenuItem RptVisits;

		private ToolStripMenuItem FrmInoculationBtn;

		private ToolStripMenuItem FrmVisitMedicalRepBtn;

		private ToolStripMenuItem AppointmentspBtn;

		private ToolStripMenuItem FrmBeforeAndAfterBtn;

		private ToolStripMenuItem selectdate;

		private ToolStripMenuItem CompanyBtn;

		private ToolStripMenuItem PatintPayBtn;

		private ToolStripMenuItem PatientAccountUpdateBtn;

		private ToolStripMenuItem DiscountPointsBtn;

		private ToolStripMenuItem toolStripMenuItem_14;

		private ToolStripMenuItem toolStripMenuItem_15;

		private ToolStripMenuItem XrayBtn;

		private ToolStripMenuItem FrmAnalyzesBtn;

		private ToolStripMenuItem PatientAcountBtn;

		private ToolStripMenuItem PatientAcountBtn2;

		private ToolStripMenuItem toolStripMenuItem_16;

		private ToolStripMenuItem FrmFilePatientBtn;

		private ToolStripMenuItem Surgery;

		private ToolStripMenuItem toolStripMenuItem_17;

		private ToolStripMenuItem toolStripMenuItem_18;

		private Button button5;

		private Button button6;

		private ToolStripMenuItem toolStripMenuItem_19;

		public Label label13;

		private Label label14;

		public Label label15;

		private Label label16;

		private ToolStripMenuItem toolStripMenuItem_20;

		private ToolStripMenuItem toolStripMenuItem_21;

		private ToolStripMenuItem toolStripMenuItem_22;

		private ToolStripMenuItem toolStripMenuItem_23;

		private ToolStripMenuItem toolStripMenuItem_24;

		private ToolStripMenuItem toolStripMenuItem_25;

		private ToolStripMenuItem toolStripMenuItem_26;

		private ToolStripMenuItem toolStripMenuItem_27;

		private ToolStripMenuItem toolStripMenuItem_28;

		private ToolStripMenuItem toolStripMenuItem_29;

		private ToolStripMenuItem toolStripMenuItem_30;

		private ToolStripMenuItem toolStripMenuItem_31;

		private ToolStripMenuItem toolStripMenuItem_32;

		public static int EmpID;

		public static string userId;

		public static string a;

		private int numberMonitor;

		private Assembly assembly;

		private bool Eshar = false;

		public static bool RestoreDB = false;

		private Stream soundStream;

		private SoundPlayer sp;

		public static bool Exit = false;

		private bool result;

		public static string usernames;

		public static string passward;

		private dataClass Codes;

		private ClassDataBase dc;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private static Server srvSql;

		public static string BackupDate = "";

		private int count = 0;

		private string API;

		private string Username;

		private string Password;

		private string SenderName;

		private string Msg;

		private bool ForceRestart = false;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.saveBackupDialog = new System.Windows.Forms.SaveFileDialog();
            this.openBackupDialog = new System.Windows.Forms.OpenFileDialog();
            this.panelappointment = new System.Windows.Forms.Panel();
            this.AppointmentListBtn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.PatientBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.AddPatientBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.searchPatientBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.CategoryBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.CompanyService = new System.Windows.Forms.ToolStripMenuItem();
            this.MainComplaintBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_21 = new System.Windows.Forms.ToolStripMenuItem();
            this.SecretaryPatientBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.appointmentBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.editReBackDateBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.secretPatientList = new System.Windows.Forms.ToolStripMenuItem();
            this.secretRebackPatientList = new System.Windows.Forms.ToolStripMenuItem();
            this.PatientAcountBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.AppointmentspBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.BookingVisits = new System.Windows.Forms.ToolStripMenuItem();
            this.SecretaryVisits = new System.Windows.Forms.ToolStripMenuItem();
            this.RptVisits = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmVisitMedicalRepBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.CompanyBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.PatintPayBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.PatientAccountUpdateBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_15 = new System.Windows.Forms.ToolStripMenuItem();
            this.XrayBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmAnalyzesBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.DiscountPointsBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_16 = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmInoculationBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_23 = new System.Windows.Forms.ToolStripMenuItem();
            this.DoctorPatientBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.PatientListBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.PackPatientListBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.PatientAcountBtn2 = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmFilePatientBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.medicineFrmBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.PrescriptionFrmBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.DoctorVisits = new System.Windows.Forms.ToolStripMenuItem();
            this.Surgery = new System.Windows.Forms.ToolStripMenuItem();
            this.PatientSurgery = new System.Windows.Forms.ToolStripMenuItem();
            this.selectdate = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmRptSpecialBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_17 = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmBeforeAndAfterBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmPatientInoculationBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_26 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_27 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_29 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_32 = new System.Windows.Forms.ToolStripMenuItem();
            this.AccountBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.expensesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revenuesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_3 = new System.Windows.Forms.ToolStripMenuItem();
            this.doctorAcountBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.AssistantAccountBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.CompanyPayBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.StockFrmBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.StockUsersFrmBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmTarnsbetweenStockBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.ReportsBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.PatientAccountRptBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.AllPatientAccountBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.MovementOfPatientStatmentBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.OldServicesRptFrmBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmRptPatientDebtBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.RptTaqweem = new System.Windows.Forms.ToolStripMenuItem();
            this.PatientPointRptBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.RptKnowFromBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.DoctorAcountRptBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.DoctorPaymentBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.MovementOfPatByDr = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.AssistantAcountDate = new System.Windows.Forms.ToolStripMenuItem();
            this.RptAssistantPaymentBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmAssistantRptBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.expensesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.revenuesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.dailyClinicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.NetDailyClinicRptFrmBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.ClinicMonthGraphRptFrmBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.DailymeasureRotFrmBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnFrmRptReb7ya = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmInventoryRptBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmRptSurgeryBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmRptCompanyAcountBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.StockTransRptFrmBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_22 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_24 = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmSearchMedicine = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmRptSahbItemBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnFrmRptCompanies_Services = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmBillBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.RptLoginUserBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.ReserveServiceRptFrmBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmEsalBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmRptRayAnalyzeBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_20 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_31 = new System.Windows.Forms.ToolStripMenuItem();
            this.EmployeeBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.addEmployeeBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.IncomingSuppBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.ItemsFrmBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.SupplierBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmDeanSupplierBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmSupplierAccountsBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FormSupplier5Btn = new System.Windows.Forms.ToolStripMenuItem();
            this.IncomingBillFrmBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmBillIncomeRptBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmRptBillByDateBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.SahbItemsBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnFrmSell = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmRptSellByDateBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.naturaltherapy = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.orthopedicalPhysiotherapyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.neurologicalPhysiotherapyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_12 = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.ToolStripMenuItem();
            this.DentalDataBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.PermissionBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmPropertiesBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.btnBackup_Restore = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_19 = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel4 = new System.Windows.Forms.Panel();
            this.button14 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.timerEmail = new System.Windows.Forms.Timer(this.components);
            this.TrayIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.timerMobile = new System.Windows.Forms.Timer(this.components);
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.vistaButton2 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.FrmLimitOrderRptBtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.TpatientXray = new System.Windows.Forms.Button();
            this.tAppointment = new System.Windows.Forms.Button();
            this.tAddPatient = new System.Windows.Forms.Button();
            this.tPatientPay = new System.Windows.Forms.Button();
            this.tPatientAccount = new System.Windows.Forms.Button();
            this.toolStripMenuItem_0 = new System.Windows.Forms.ToolStripMenuItem();
            this.panelappointment.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // saveBackupDialog
            // 
            this.saveBackupDialog.FileName = "Backup.bak";
            this.saveBackupDialog.Filter = "Backup File|*.bak";
            // 
            // openBackupDialog
            // 
            this.openBackupDialog.FileName = "Backup.bak";
            this.openBackupDialog.Filter = "Backup File|*.bak";
            // 
            // panelappointment
            // 
            this.panelappointment.BackColor = System.Drawing.Color.Transparent;
            this.panelappointment.Controls.Add(this.AppointmentListBtn);
            this.panelappointment.Location = new System.Drawing.Point(10000, 10000);
            this.panelappointment.Name = "panelappointment";
            this.panelappointment.Size = new System.Drawing.Size(26, 60);
            this.panelappointment.TabIndex = 31;
            this.panelappointment.Visible = false;
            // 
            // AppointmentListBtn
            // 
            this.AppointmentListBtn.BackColor = System.Drawing.Color.Transparent;
            this.AppointmentListBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AppointmentListBtn.Font = new System.Drawing.Font("Arial", 12F);
            this.AppointmentListBtn.Image = ((System.Drawing.Image)(resources.GetObject("AppointmentListBtn.Image")));
            this.AppointmentListBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.AppointmentListBtn.Location = new System.Drawing.Point(16, 11);
            this.AppointmentListBtn.Name = "AppointmentListBtn";
            this.AppointmentListBtn.Size = new System.Drawing.Size(106, 34);
            this.AppointmentListBtn.TabIndex = 25;
            this.AppointmentListBtn.Text = "الكشف";
            this.AppointmentListBtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.AppointmentListBtn.UseVisualStyleBackColor = false;
            this.AppointmentListBtn.Click += new System.EventHandler(this.AppointmentListBtn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(203)))), ((int)(((byte)(235)))));
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PatientBtn,
            this.SecretaryPatientBtn,
            this.DoctorPatientBtn,
            this.AccountBtn,
            this.ReportsBtn,
            this.EmployeeBtn,
            this.IncomingSuppBtn,
            this.naturaltherapy,
            this.button1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(1284, 52);
            this.menuStrip1.TabIndex = 59;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // PatientBtn
            // 
            this.PatientBtn.AutoSize = false;
            this.PatientBtn.BackColor = System.Drawing.Color.Transparent;
            this.PatientBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PatientBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.PatientBtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddPatientBtn,
            this.searchPatientBtn,
            this.CategoryBtn,
            this.CompanyService,
            this.MainComplaintBtn,
            this.toolStripMenuItem_6,
            this.toolStripMenuItem_21});
            this.PatientBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.PatientBtn.ForeColor = System.Drawing.Color.Transparent;
            this.PatientBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PatientBtn.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.PatientBtn.Name = "PatientBtn";
            this.PatientBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.PatientBtn.Size = new System.Drawing.Size(122, 48);
            this.PatientBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PatientBtn.Click += new System.EventHandler(this.PatientBtn_Click);
            // 
            // AddPatientBtn
            // 
            this.AddPatientBtn.BackColor = System.Drawing.SystemColors.Control;
            this.AddPatientBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddPatientBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.AddPatientBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AddPatientBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.AddPatientBtn.Name = "AddPatientBtn";
            this.AddPatientBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.AddPatientBtn.RightToLeftAutoMirrorImage = true;
            this.AddPatientBtn.Size = new System.Drawing.Size(179, 24);
            this.AddPatientBtn.Text = "إضافة مريض";
            this.AddPatientBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.AddPatientBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.AddPatientBtn.Click += new System.EventHandler(this.AddPatientBtn_Click_2);
            // 
            // searchPatientBtn
            // 
            this.searchPatientBtn.BackColor = System.Drawing.SystemColors.Control;
            this.searchPatientBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.searchPatientBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.searchPatientBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.searchPatientBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.searchPatientBtn.Name = "searchPatientBtn";
            this.searchPatientBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchPatientBtn.RightToLeftAutoMirrorImage = true;
            this.searchPatientBtn.Size = new System.Drawing.Size(179, 24);
            this.searchPatientBtn.Text = "البحث عن مريض";
            this.searchPatientBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.searchPatientBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.searchPatientBtn.Click += new System.EventHandler(this.searchPatientBtn_Click_2);
            // 
            // CategoryBtn
            // 
            this.CategoryBtn.BackColor = System.Drawing.SystemColors.Control;
            this.CategoryBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.CategoryBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CategoryBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CategoryBtn.Name = "CategoryBtn";
            this.CategoryBtn.Size = new System.Drawing.Size(179, 24);
            this.CategoryBtn.Text = "فئات الخدمات";
            this.CategoryBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.CategoryBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.CategoryBtn.Click += new System.EventHandler(this.CategoryBtn_Click);
            // 
            // CompanyService
            // 
            this.CompanyService.BackColor = System.Drawing.SystemColors.Control;
            this.CompanyService.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.CompanyService.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CompanyService.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CompanyService.Name = "CompanyService";
            this.CompanyService.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CompanyService.RightToLeftAutoMirrorImage = true;
            this.CompanyService.Size = new System.Drawing.Size(179, 24);
            this.CompanyService.Text = "خدمات المرضى";
            this.CompanyService.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.CompanyService.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.CompanyService.Click += new System.EventHandler(this.CompanyService_Click_2);
            // 
            // MainComplaintBtn
            // 
            this.MainComplaintBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(234)))), ((int)(((byte)(252)))));
            this.MainComplaintBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.MainComplaintBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.MainComplaintBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MainComplaintBtn.Name = "MainComplaintBtn";
            this.MainComplaintBtn.Size = new System.Drawing.Size(179, 24);
            this.MainComplaintBtn.Text = "الشكوى الرئيسية";
            this.MainComplaintBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.MainComplaintBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.MainComplaintBtn.Click += new System.EventHandler(this.MainComplaintBtn_Click_2);
            // 
            // toolStripMenuItem_6
            // 
            this.toolStripMenuItem_6.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem_6.Name = "toolStripMenuItem_6";
            this.toolStripMenuItem_6.Size = new System.Drawing.Size(179, 24);
            this.toolStripMenuItem_6.Text = "الباركود";
            this.toolStripMenuItem_6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem_6.Click += new System.EventHandler(this.toolStripMenuItem_6_Click);
            // 
            // toolStripMenuItem_21
            // 
            this.toolStripMenuItem_21.Name = "toolStripMenuItem_21";
            this.toolStripMenuItem_21.Size = new System.Drawing.Size(179, 24);
            this.toolStripMenuItem_21.Text = "العروض";
            this.toolStripMenuItem_21.Click += new System.EventHandler(this.toolStripMenuItem_21_Click);
            // 
            // SecretaryPatientBtn
            // 
            this.SecretaryPatientBtn.AutoSize = false;
            this.SecretaryPatientBtn.BackColor = System.Drawing.Color.Transparent;
            this.SecretaryPatientBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SecretaryPatientBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.SecretaryPatientBtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.appointmentBtn,
            this.editReBackDateBtn,
            this.secretPatientList,
            this.secretRebackPatientList,
            this.PatientAcountBtn,
            this.AppointmentspBtn,
            this.BookingVisits,
            this.SecretaryVisits,
            this.RptVisits,
            this.FrmVisitMedicalRepBtn,
            this.CompanyBtn,
            this.PatintPayBtn,
            this.PatientAccountUpdateBtn,
            this.toolStripMenuItem_15,
            this.XrayBtn,
            this.FrmAnalyzesBtn,
            this.DiscountPointsBtn,
            this.toolStripMenuItem_14,
            this.toolStripMenuItem_16,
            this.FrmInoculationBtn,
            this.toolStripMenuItem_23});
            this.SecretaryPatientBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.SecretaryPatientBtn.ForeColor = System.Drawing.Color.Transparent;
            this.SecretaryPatientBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.SecretaryPatientBtn.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.SecretaryPatientBtn.Name = "SecretaryPatientBtn";
            this.SecretaryPatientBtn.Size = new System.Drawing.Size(130, 48);
            this.SecretaryPatientBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.SecretaryPatientBtn.Click += new System.EventHandler(this.SecretaryPatientBtn_Click);
            // 
            // appointmentBtn
            // 
            this.appointmentBtn.BackColor = System.Drawing.SystemColors.Control;
            this.appointmentBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.appointmentBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.appointmentBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.appointmentBtn.Name = "appointmentBtn";
            this.appointmentBtn.Size = new System.Drawing.Size(247, 24);
            this.appointmentBtn.Text = "حجز كشف لمريض";
            this.appointmentBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.appointmentBtn.Click += new System.EventHandler(this.appointmentBtn_Click);
            // 
            // editReBackDateBtn
            // 
            this.editReBackDateBtn.BackColor = System.Drawing.SystemColors.Control;
            this.editReBackDateBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.editReBackDateBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.editReBackDateBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.editReBackDateBtn.Name = "editReBackDateBtn";
            this.editReBackDateBtn.Size = new System.Drawing.Size(247, 24);
            this.editReBackDateBtn.Text = "تعديل تاريخ إعادة الكشف";
            this.editReBackDateBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.editReBackDateBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.editReBackDateBtn.Click += new System.EventHandler(this.editReBackDateBtn_Click);
            // 
            // secretPatientList
            // 
            this.secretPatientList.BackColor = System.Drawing.SystemColors.Control;
            this.secretPatientList.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.secretPatientList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.secretPatientList.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.secretPatientList.Name = "secretPatientList";
            this.secretPatientList.Size = new System.Drawing.Size(247, 24);
            this.secretPatientList.Text = "قائمة الكشف";
            this.secretPatientList.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.secretPatientList.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.secretPatientList.Click += new System.EventHandler(this.secretPatientList_Click);
            // 
            // secretRebackPatientList
            // 
            this.secretRebackPatientList.BackColor = System.Drawing.SystemColors.Control;
            this.secretRebackPatientList.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.secretRebackPatientList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.secretRebackPatientList.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.secretRebackPatientList.Name = "secretRebackPatientList";
            this.secretRebackPatientList.Size = new System.Drawing.Size(247, 24);
            this.secretRebackPatientList.Text = "قائمة اعادة الكشف";
            this.secretRebackPatientList.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.secretRebackPatientList.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.secretRebackPatientList.Click += new System.EventHandler(this.secretRebackPatientList_Click);
            // 
            // PatientAcountBtn
            // 
            this.PatientAcountBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(234)))), ((int)(((byte)(252)))));
            this.PatientAcountBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PatientAcountBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PatientAcountBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PatientAcountBtn.Name = "PatientAcountBtn";
            this.PatientAcountBtn.Size = new System.Drawing.Size(247, 24);
            this.PatientAcountBtn.Text = "كشف سريع";
            this.PatientAcountBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.PatientAcountBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PatientAcountBtn.Click += new System.EventHandler(this.PatientAcountBtn_Click_2);
            // 
            // AppointmentspBtn
            // 
            this.AppointmentspBtn.Name = "AppointmentspBtn";
            this.AppointmentspBtn.Size = new System.Drawing.Size(247, 24);
            this.AppointmentspBtn.Text = "الحجز السريع";
            this.AppointmentspBtn.Click += new System.EventHandler(this.AppointmentspBtn_Click);
            // 
            // BookingVisits
            // 
            this.BookingVisits.BackColor = System.Drawing.SystemColors.Control;
            this.BookingVisits.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.BookingVisits.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BookingVisits.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BookingVisits.Name = "BookingVisits";
            this.BookingVisits.Size = new System.Drawing.Size(247, 24);
            this.BookingVisits.Text = "حجز زيارة لمريض";
            this.BookingVisits.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BookingVisits.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BookingVisits.Click += new System.EventHandler(this.BookingVisits_Click_1);
            // 
            // SecretaryVisits
            // 
            this.SecretaryVisits.BackColor = System.Drawing.SystemColors.Control;
            this.SecretaryVisits.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SecretaryVisits.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SecretaryVisits.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.SecretaryVisits.Name = "SecretaryVisits";
            this.SecretaryVisits.Size = new System.Drawing.Size(247, 24);
            this.SecretaryVisits.Text = "قائمة الزيارات";
            this.SecretaryVisits.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.SecretaryVisits.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.SecretaryVisits.Click += new System.EventHandler(this.SecretaryVisits_Click_1);
            // 
            // RptVisits
            // 
            this.RptVisits.BackColor = System.Drawing.SystemColors.Control;
            this.RptVisits.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.RptVisits.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RptVisits.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.RptVisits.Name = "RptVisits";
            this.RptVisits.Size = new System.Drawing.Size(247, 24);
            this.RptVisits.Text = "تقرير متابعة الزيارات";
            this.RptVisits.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.RptVisits.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.RptVisits.Click += new System.EventHandler(this.RptVisits_Click_1);
            // 
            // FrmVisitMedicalRepBtn
            // 
            this.FrmVisitMedicalRepBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmVisitMedicalRepBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmVisitMedicalRepBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmVisitMedicalRepBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmVisitMedicalRepBtn.Name = "FrmVisitMedicalRepBtn";
            this.FrmVisitMedicalRepBtn.Size = new System.Drawing.Size(247, 24);
            this.FrmVisitMedicalRepBtn.Text = "زيارات الميديكال ريب";
            this.FrmVisitMedicalRepBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmVisitMedicalRepBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmVisitMedicalRepBtn.Click += new System.EventHandler(this.FrmVisitMedicalRepBtn_Click);
            // 
            // CompanyBtn
            // 
            this.CompanyBtn.BackColor = System.Drawing.SystemColors.Control;
            this.CompanyBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.CompanyBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CompanyBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CompanyBtn.Name = "CompanyBtn";
            this.CompanyBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CompanyBtn.RightToLeftAutoMirrorImage = true;
            this.CompanyBtn.Size = new System.Drawing.Size(247, 24);
            this.CompanyBtn.Text = "الشركات";
            this.CompanyBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.CompanyBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.CompanyBtn.Click += new System.EventHandler(this.CompanyBtn_Click_2);
            // 
            // PatintPayBtn
            // 
            this.PatintPayBtn.BackColor = System.Drawing.SystemColors.Control;
            this.PatintPayBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PatintPayBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PatintPayBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PatintPayBtn.Name = "PatintPayBtn";
            this.PatintPayBtn.Size = new System.Drawing.Size(247, 24);
            this.PatintPayBtn.Text = "مدفوعات المرضى";
            this.PatintPayBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.PatintPayBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PatintPayBtn.Click += new System.EventHandler(this.PatintPayBtn_Click_2);
            // 
            // PatientAccountUpdateBtn
            // 
            this.PatientAccountUpdateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(234)))), ((int)(((byte)(252)))));
            this.PatientAccountUpdateBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PatientAccountUpdateBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PatientAccountUpdateBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PatientAccountUpdateBtn.Name = "PatientAccountUpdateBtn";
            this.PatientAccountUpdateBtn.Size = new System.Drawing.Size(247, 24);
            this.PatientAccountUpdateBtn.Text = "تعديل مدفوعات المرضى";
            this.PatientAccountUpdateBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.PatientAccountUpdateBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PatientAccountUpdateBtn.Click += new System.EventHandler(this.PatientAccountUpdateBtn_Click_1);
            // 
            // toolStripMenuItem_15
            // 
            this.toolStripMenuItem_15.Name = "toolStripMenuItem_15";
            this.toolStripMenuItem_15.Size = new System.Drawing.Size(247, 24);
            this.toolStripMenuItem_15.Text = "الأشعات و التحاليل";
            this.toolStripMenuItem_15.Click += new System.EventHandler(this.toolStripMenuItem_15_Click);
            // 
            // XrayBtn
            // 
            this.XrayBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(234)))), ((int)(((byte)(252)))));
            this.XrayBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.XrayBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.XrayBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.XrayBtn.Name = "XrayBtn";
            this.XrayBtn.Size = new System.Drawing.Size(247, 24);
            this.XrayBtn.Text = "أشعة المرضى";
            this.XrayBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.XrayBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.XrayBtn.Click += new System.EventHandler(this.XrayBtn_Click_2);
            // 
            // FrmAnalyzesBtn
            // 
            this.FrmAnalyzesBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(234)))), ((int)(((byte)(252)))));
            this.FrmAnalyzesBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmAnalyzesBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmAnalyzesBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmAnalyzesBtn.Name = "FrmAnalyzesBtn";
            this.FrmAnalyzesBtn.Size = new System.Drawing.Size(247, 24);
            this.FrmAnalyzesBtn.Text = "تحاليل المرضى";
            this.FrmAnalyzesBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmAnalyzesBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmAnalyzesBtn.Click += new System.EventHandler(this.FrmAnalyzesBtn_Click);
            // 
            // DiscountPointsBtn
            // 
            this.DiscountPointsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(234)))), ((int)(((byte)(252)))));
            this.DiscountPointsBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.DiscountPointsBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DiscountPointsBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DiscountPointsBtn.Name = "DiscountPointsBtn";
            this.DiscountPointsBtn.Size = new System.Drawing.Size(247, 24);
            this.DiscountPointsBtn.Text = "استخدام نقاط مريض";
            this.DiscountPointsBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DiscountPointsBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DiscountPointsBtn.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolStripMenuItem_14
            // 
            this.toolStripMenuItem_14.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem_14.Name = "toolStripMenuItem_14";
            this.toolStripMenuItem_14.Size = new System.Drawing.Size(247, 24);
            this.toolStripMenuItem_14.Text = "إشعار خصم وأضافة لمريض";
            this.toolStripMenuItem_14.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem_14.Click += new System.EventHandler(this.toolStripMenuItem_14_Click);
            // 
            // toolStripMenuItem_16
            // 
            this.toolStripMenuItem_16.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem_16.Name = "toolStripMenuItem_16";
            this.toolStripMenuItem_16.Size = new System.Drawing.Size(247, 24);
            this.toolStripMenuItem_16.Text = "الملاحظات";
            this.toolStripMenuItem_16.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem_16.Click += new System.EventHandler(this.toolStripMenuItem_16_Click);
            // 
            // FrmInoculationBtn
            // 
            this.FrmInoculationBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmInoculationBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmInoculationBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmInoculationBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmInoculationBtn.Name = "FrmInoculationBtn";
            this.FrmInoculationBtn.Size = new System.Drawing.Size(247, 24);
            this.FrmInoculationBtn.Text = "إضافة تطعيمات";
            this.FrmInoculationBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmInoculationBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmInoculationBtn.Click += new System.EventHandler(this.FrmInoculationBtn_Click);
            // 
            // toolStripMenuItem_23
            // 
            this.toolStripMenuItem_23.Name = "toolStripMenuItem_23";
            this.toolStripMenuItem_23.Size = new System.Drawing.Size(247, 24);
            this.toolStripMenuItem_23.Text = "مدفوعات مقدمة للمرضى";
            this.toolStripMenuItem_23.Click += new System.EventHandler(this.toolStripMenuItem_23_Click);
            // 
            // DoctorPatientBtn
            // 
            this.DoctorPatientBtn.AutoSize = false;
            this.DoctorPatientBtn.BackColor = System.Drawing.Color.Transparent;
            this.DoctorPatientBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DoctorPatientBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.DoctorPatientBtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PatientListBtn,
            this.PackPatientListBtn,
            this.PatientAcountBtn2,
            this.FrmFilePatientBtn,
            this.medicineFrmBtn,
            this.PrescriptionFrmBtn,
            this.DoctorVisits,
            this.Surgery,
            this.PatientSurgery,
            this.selectdate,
            this.FrmRptSpecialBtn,
            this.toolStripMenuItem_17,
            this.FrmBeforeAndAfterBtn,
            this.FrmPatientInoculationBtn,
            this.toolStripMenuItem_26,
            this.toolStripMenuItem_27,
            this.toolStripMenuItem_29,
            this.toolStripMenuItem_32});
            this.DoctorPatientBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.DoctorPatientBtn.ForeColor = System.Drawing.Color.Transparent;
            this.DoctorPatientBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DoctorPatientBtn.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.DoctorPatientBtn.Name = "DoctorPatientBtn";
            this.DoctorPatientBtn.Size = new System.Drawing.Size(130, 48);
            this.DoctorPatientBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DoctorPatientBtn.Click += new System.EventHandler(this.DoctorPatientBtn_Click);
            // 
            // PatientListBtn
            // 
            this.PatientListBtn.BackColor = System.Drawing.SystemColors.Control;
            this.PatientListBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PatientListBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PatientListBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PatientListBtn.Name = "PatientListBtn";
            this.PatientListBtn.Size = new System.Drawing.Size(202, 24);
            this.PatientListBtn.Text = "قائمة الكشف";
            this.PatientListBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.PatientListBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PatientListBtn.Click += new System.EventHandler(this.PatientListBtn_Click);
            // 
            // PackPatientListBtn
            // 
            this.PackPatientListBtn.BackColor = System.Drawing.SystemColors.Control;
            this.PackPatientListBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PackPatientListBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PackPatientListBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PackPatientListBtn.Name = "PackPatientListBtn";
            this.PackPatientListBtn.Size = new System.Drawing.Size(202, 24);
            this.PackPatientListBtn.Text = "قائمة إعادة الكشف";
            this.PackPatientListBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.PackPatientListBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PackPatientListBtn.Click += new System.EventHandler(this.PackPatientListBtn_Click);
            // 
            // PatientAcountBtn2
            // 
            this.PatientAcountBtn2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(234)))), ((int)(((byte)(252)))));
            this.PatientAcountBtn2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PatientAcountBtn2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PatientAcountBtn2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PatientAcountBtn2.Name = "PatientAcountBtn2";
            this.PatientAcountBtn2.Size = new System.Drawing.Size(202, 24);
            this.PatientAcountBtn2.Text = "كشف سريع";
            this.PatientAcountBtn2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.PatientAcountBtn2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PatientAcountBtn2.Click += new System.EventHandler(this.PatientAcountBtn_Click_2);
            // 
            // FrmFilePatientBtn
            // 
            this.FrmFilePatientBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(234)))), ((int)(((byte)(252)))));
            this.FrmFilePatientBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmFilePatientBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmFilePatientBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmFilePatientBtn.Name = "FrmFilePatientBtn";
            this.FrmFilePatientBtn.Size = new System.Drawing.Size(202, 24);
            this.FrmFilePatientBtn.Text = "ملف المريض";
            this.FrmFilePatientBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmFilePatientBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmFilePatientBtn.Click += new System.EventHandler(this.FrmFilePatientBtn_Click_2);
            // 
            // medicineFrmBtn
            // 
            this.medicineFrmBtn.BackColor = System.Drawing.SystemColors.Control;
            this.medicineFrmBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.medicineFrmBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.medicineFrmBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.medicineFrmBtn.Name = "medicineFrmBtn";
            this.medicineFrmBtn.Size = new System.Drawing.Size(202, 24);
            this.medicineFrmBtn.Text = "الأدوية";
            this.medicineFrmBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.medicineFrmBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.medicineFrmBtn.Click += new System.EventHandler(this.medicineFrmBtn_Click_1);
            // 
            // PrescriptionFrmBtn
            // 
            this.PrescriptionFrmBtn.BackColor = System.Drawing.SystemColors.Control;
            this.PrescriptionFrmBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PrescriptionFrmBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PrescriptionFrmBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PrescriptionFrmBtn.Name = "PrescriptionFrmBtn";
            this.PrescriptionFrmBtn.Size = new System.Drawing.Size(202, 24);
            this.PrescriptionFrmBtn.Text = "الروشتات";
            this.PrescriptionFrmBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.PrescriptionFrmBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PrescriptionFrmBtn.Click += new System.EventHandler(this.PrescriptionFrmBtn_Click_1);
            // 
            // DoctorVisits
            // 
            this.DoctorVisits.BackColor = System.Drawing.SystemColors.Control;
            this.DoctorVisits.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.DoctorVisits.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DoctorVisits.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DoctorVisits.Name = "DoctorVisits";
            this.DoctorVisits.Size = new System.Drawing.Size(202, 24);
            this.DoctorVisits.Text = "قائمة الزيارات";
            this.DoctorVisits.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DoctorVisits.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DoctorVisits.Click += new System.EventHandler(this.DoctorVisits_Click_1);
            // 
            // Surgery
            // 
            this.Surgery.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(234)))), ((int)(((byte)(252)))));
            this.Surgery.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Surgery.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Surgery.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.Surgery.Name = "Surgery";
            this.Surgery.Size = new System.Drawing.Size(202, 24);
            this.Surgery.Text = "قائمة العمليات";
            this.Surgery.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Surgery.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.Surgery.Click += new System.EventHandler(this.Surgery_Click_1);
            // 
            // PatientSurgery
            // 
            this.PatientSurgery.BackColor = System.Drawing.SystemColors.Control;
            this.PatientSurgery.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PatientSurgery.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PatientSurgery.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PatientSurgery.Name = "PatientSurgery";
            this.PatientSurgery.Size = new System.Drawing.Size(202, 24);
            this.PatientSurgery.Text = "عمليات المرضى";
            this.PatientSurgery.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.PatientSurgery.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PatientSurgery.Click += new System.EventHandler(this.PatientSurgery_Click_1);
            // 
            // selectdate
            // 
            this.selectdate.Name = "selectdate";
            this.selectdate.Size = new System.Drawing.Size(202, 24);
            this.selectdate.Text = "تحديد ميعاد العملية";
            this.selectdate.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // FrmRptSpecialBtn
            // 
            this.FrmRptSpecialBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmRptSpecialBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmRptSpecialBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmRptSpecialBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmRptSpecialBtn.Name = "FrmRptSpecialBtn";
            this.FrmRptSpecialBtn.Size = new System.Drawing.Size(202, 24);
            this.FrmRptSpecialBtn.Text = "خطابات التحويل";
            this.FrmRptSpecialBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmRptSpecialBtn.Visible = false;
            this.FrmRptSpecialBtn.Click += new System.EventHandler(this.FrmRptSpecialBtn_Click);
            // 
            // toolStripMenuItem_17
            // 
            this.toolStripMenuItem_17.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem_17.Name = "toolStripMenuItem_17";
            this.toolStripMenuItem_17.Size = new System.Drawing.Size(202, 24);
            this.toolStripMenuItem_17.Text = "التقرير الطبى";
            this.toolStripMenuItem_17.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem_17.Click += new System.EventHandler(this.toolStripMenuItem_17_Click);
            // 
            // FrmBeforeAndAfterBtn
            // 
            this.FrmBeforeAndAfterBtn.Name = "FrmBeforeAndAfterBtn";
            this.FrmBeforeAndAfterBtn.Size = new System.Drawing.Size(202, 24);
            this.FrmBeforeAndAfterBtn.Text = "قبل وبعد ";
            this.FrmBeforeAndAfterBtn.Click += new System.EventHandler(this.FrmBeforeAndAfterBtn_Click);
            // 
            // FrmPatientInoculationBtn
            // 
            this.FrmPatientInoculationBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmPatientInoculationBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmPatientInoculationBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmPatientInoculationBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmPatientInoculationBtn.Name = "FrmPatientInoculationBtn";
            this.FrmPatientInoculationBtn.Size = new System.Drawing.Size(202, 24);
            this.FrmPatientInoculationBtn.Text = "تطعيمات للمريض";
            this.FrmPatientInoculationBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmPatientInoculationBtn.Click += new System.EventHandler(this.FrmPatientInoculationBtn_Click);
            // 
            // toolStripMenuItem_26
            // 
            this.toolStripMenuItem_26.Name = "toolStripMenuItem_26";
            this.toolStripMenuItem_26.Size = new System.Drawing.Size(202, 24);
            this.toolStripMenuItem_26.Text = "التشخيص الورقي";
            this.toolStripMenuItem_26.Click += new System.EventHandler(this.toolStripMenuItem_26_Click);
            // 
            // toolStripMenuItem_27
            // 
            this.toolStripMenuItem_27.Name = "toolStripMenuItem_27";
            this.toolStripMenuItem_27.Size = new System.Drawing.Size(202, 24);
            this.toolStripMenuItem_27.Text = "الأجازة المرضية";
            this.toolStripMenuItem_27.Click += new System.EventHandler(this.toolStripMenuItem_27_Click);
            // 
            // toolStripMenuItem_29
            // 
            this.toolStripMenuItem_29.Name = "toolStripMenuItem_29";
            this.toolStripMenuItem_29.Size = new System.Drawing.Size(202, 24);
            this.toolStripMenuItem_29.Text = "شهادة حضور";
            this.toolStripMenuItem_29.Click += new System.EventHandler(this.toolStripMenuItem_29_Click);
            // 
            // toolStripMenuItem_32
            // 
            this.toolStripMenuItem_32.Name = "toolStripMenuItem_32";
            this.toolStripMenuItem_32.Size = new System.Drawing.Size(202, 24);
            this.toolStripMenuItem_32.Text = "التواصل مع المرضي";
            this.toolStripMenuItem_32.Click += new System.EventHandler(this.toolStripMenuItem_32_Click);
            // 
            // AccountBtn
            // 
            this.AccountBtn.AutoSize = false;
            this.AccountBtn.BackColor = System.Drawing.Color.Transparent;
            this.AccountBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.AccountBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.AccountBtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.expensesToolStripMenuItem,
            this.revenuesToolStripMenuItem,
            this.toolStripMenuItem_3,
            this.doctorAcountBtn,
            this.AssistantAccountBtn,
            this.CompanyPayBtn,
            this.StockFrmBtn,
            this.StockUsersFrmBtn,
            this.FrmTarnsbetweenStockBtn});
            this.AccountBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.AccountBtn.ForeColor = System.Drawing.Color.Transparent;
            this.AccountBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.AccountBtn.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.AccountBtn.Name = "AccountBtn";
            this.AccountBtn.Size = new System.Drawing.Size(130, 48);
            this.AccountBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // expensesToolStripMenuItem
            // 
            this.expensesToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.expensesToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.expensesToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.expensesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.expensesToolStripMenuItem.Name = "expensesToolStripMenuItem";
            this.expensesToolStripMenuItem.Size = new System.Drawing.Size(228, 24);
            this.expensesToolStripMenuItem.Text = "المصروفات";
            this.expensesToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.expensesToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.expensesToolStripMenuItem.Click += new System.EventHandler(this.expensesToolStripMenuItem_Click);
            // 
            // revenuesToolStripMenuItem
            // 
            this.revenuesToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.revenuesToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.revenuesToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.revenuesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.revenuesToolStripMenuItem.Name = "revenuesToolStripMenuItem";
            this.revenuesToolStripMenuItem.Size = new System.Drawing.Size(228, 24);
            this.revenuesToolStripMenuItem.Text = "الإيرادات";
            this.revenuesToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.revenuesToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.revenuesToolStripMenuItem.Click += new System.EventHandler(this.revenuesToolStripMenuItem_Click);
            // 
            // toolStripMenuItem_3
            // 
            this.toolStripMenuItem_3.Name = "toolStripMenuItem_3";
            this.toolStripMenuItem_3.Size = new System.Drawing.Size(228, 24);
            this.toolStripMenuItem_3.Text = "نسب  الأطباء";
            this.toolStripMenuItem_3.Click += new System.EventHandler(this.toolStripMenuItem_3_Click);
            // 
            // doctorAcountBtn
            // 
            this.doctorAcountBtn.BackColor = System.Drawing.SystemColors.Control;
            this.doctorAcountBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.doctorAcountBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.doctorAcountBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.doctorAcountBtn.Name = "doctorAcountBtn";
            this.doctorAcountBtn.Size = new System.Drawing.Size(228, 24);
            this.doctorAcountBtn.Text = "حسابات الأطباء";
            this.doctorAcountBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.doctorAcountBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.doctorAcountBtn.Click += new System.EventHandler(this.doctorAcountBtn_Click);
            // 
            // AssistantAccountBtn
            // 
            this.AssistantAccountBtn.BackColor = System.Drawing.SystemColors.Control;
            this.AssistantAccountBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AssistantAccountBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AssistantAccountBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.AssistantAccountBtn.Name = "AssistantAccountBtn";
            this.AssistantAccountBtn.Size = new System.Drawing.Size(228, 24);
            this.AssistantAccountBtn.Text = "حسابات المساعدين";
            this.AssistantAccountBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.AssistantAccountBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.AssistantAccountBtn.Click += new System.EventHandler(this.AssistantAccountBtn_Click);
            // 
            // CompanyPayBtn
            // 
            this.CompanyPayBtn.BackColor = System.Drawing.SystemColors.Control;
            this.CompanyPayBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.CompanyPayBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CompanyPayBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CompanyPayBtn.Name = "CompanyPayBtn";
            this.CompanyPayBtn.Size = new System.Drawing.Size(228, 24);
            this.CompanyPayBtn.Text = "حساب شركة";
            this.CompanyPayBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.CompanyPayBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.CompanyPayBtn.Visible = false;
            this.CompanyPayBtn.Click += new System.EventHandler(this.CompanyPayBtn_Click);
            // 
            // StockFrmBtn
            // 
            this.StockFrmBtn.BackColor = System.Drawing.SystemColors.Control;
            this.StockFrmBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.StockFrmBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StockFrmBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.StockFrmBtn.Name = "StockFrmBtn";
            this.StockFrmBtn.Size = new System.Drawing.Size(228, 24);
            this.StockFrmBtn.Text = "الخزائن";
            this.StockFrmBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.StockFrmBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.StockFrmBtn.Click += new System.EventHandler(this.StockFrmBtn_Click);
            // 
            // StockUsersFrmBtn
            // 
            this.StockUsersFrmBtn.BackColor = System.Drawing.SystemColors.Control;
            this.StockUsersFrmBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.StockUsersFrmBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StockUsersFrmBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.StockUsersFrmBtn.Name = "StockUsersFrmBtn";
            this.StockUsersFrmBtn.Size = new System.Drawing.Size(228, 24);
            this.StockUsersFrmBtn.Text = "إضافة خزينة لمستخدم";
            this.StockUsersFrmBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.StockUsersFrmBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.StockUsersFrmBtn.Click += new System.EventHandler(this.StockUsersFrmBtn_Click);
            // 
            // FrmTarnsbetweenStockBtn
            // 
            this.FrmTarnsbetweenStockBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmTarnsbetweenStockBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmTarnsbetweenStockBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmTarnsbetweenStockBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmTarnsbetweenStockBtn.Name = "FrmTarnsbetweenStockBtn";
            this.FrmTarnsbetweenStockBtn.Size = new System.Drawing.Size(228, 24);
            this.FrmTarnsbetweenStockBtn.Text = "التحويل من خزينة لأخرى";
            this.FrmTarnsbetweenStockBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmTarnsbetweenStockBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmTarnsbetweenStockBtn.Click += new System.EventHandler(this.FrmTarnsbetweenStockBtn_Click);
            // 
            // ReportsBtn
            // 
            this.ReportsBtn.AutoSize = false;
            this.ReportsBtn.BackColor = System.Drawing.Color.Transparent;
            this.ReportsBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ReportsBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ReportsBtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.FrmSearchMedicine,
            this.FrmRptSahbItemBtn,
            this.BtnFrmRptCompanies_Services,
            this.FrmBillBtn,
            this.RptLoginUserBtn,
            this.ReserveServiceRptFrmBtn,
            this.FrmEsalBtn,
            this.FrmRptRayAnalyzeBtn,
            this.toolStripMenuItem_5,
            this.toolStripMenuItem_20,
            this.toolStripMenuItem_28,
            this.toolStripMenuItem_30,
            this.toolStripMenuItem_31});
            this.ReportsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ReportsBtn.ForeColor = System.Drawing.Color.Transparent;
            this.ReportsBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ReportsBtn.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.ReportsBtn.Name = "ReportsBtn";
            this.ReportsBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ReportsBtn.Size = new System.Drawing.Size(130, 48);
            this.ReportsBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripMenuItem7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PatientAccountRptBtn,
            this.AllPatientAccountBtn,
            this.MovementOfPatientStatmentBtn,
            this.OldServicesRptFrmBtn,
            this.FrmRptPatientDebtBtn,
            this.RptTaqweem,
            this.PatientPointRptBtn,
            this.RptKnowFromBtn,
            this.toolStripMenuItem4,
            this.toolStripMenuItem6,
            this.toolStripMenuItem_7,
            this.toolStripMenuItem_18,
            this.toolStripMenuItem_25});
            this.toolStripMenuItem7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem7.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.toolStripMenuItem7.Size = new System.Drawing.Size(262, 24);
            this.toolStripMenuItem7.Text = "تقارير المرضى";
            this.toolStripMenuItem7.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolStripMenuItem7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // PatientAccountRptBtn
            // 
            this.PatientAccountRptBtn.BackColor = System.Drawing.SystemColors.Control;
            this.PatientAccountRptBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PatientAccountRptBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PatientAccountRptBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PatientAccountRptBtn.Name = "PatientAccountRptBtn";
            this.PatientAccountRptBtn.Size = new System.Drawing.Size(243, 24);
            this.PatientAccountRptBtn.Text = "تقرير حساب مريض";
            this.PatientAccountRptBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.PatientAccountRptBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PatientAccountRptBtn.Click += new System.EventHandler(this.PatientAccountRptBtn_Click);
            // 
            // AllPatientAccountBtn
            // 
            this.AllPatientAccountBtn.BackColor = System.Drawing.SystemColors.Control;
            this.AllPatientAccountBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AllPatientAccountBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AllPatientAccountBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.AllPatientAccountBtn.Name = "AllPatientAccountBtn";
            this.AllPatientAccountBtn.Size = new System.Drawing.Size(243, 24);
            this.AllPatientAccountBtn.Text = "تقرير حسابات كل المرضى";
            this.AllPatientAccountBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.AllPatientAccountBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.AllPatientAccountBtn.Click += new System.EventHandler(this.AllPatientAccountBtn_Click);
            // 
            // MovementOfPatientStatmentBtn
            // 
            this.MovementOfPatientStatmentBtn.BackColor = System.Drawing.SystemColors.Control;
            this.MovementOfPatientStatmentBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.MovementOfPatientStatmentBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.MovementOfPatientStatmentBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MovementOfPatientStatmentBtn.Name = "MovementOfPatientStatmentBtn";
            this.MovementOfPatientStatmentBtn.Size = new System.Drawing.Size(243, 24);
            this.MovementOfPatientStatmentBtn.Text = "تقرير كشوفات المرضى";
            this.MovementOfPatientStatmentBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.MovementOfPatientStatmentBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.MovementOfPatientStatmentBtn.Click += new System.EventHandler(this.MovementOfPatientStatmentBtn_Click);
            // 
            // OldServicesRptFrmBtn
            // 
            this.OldServicesRptFrmBtn.BackColor = System.Drawing.SystemColors.Control;
            this.OldServicesRptFrmBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.OldServicesRptFrmBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.OldServicesRptFrmBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.OldServicesRptFrmBtn.Name = "OldServicesRptFrmBtn";
            this.OldServicesRptFrmBtn.Size = new System.Drawing.Size(243, 24);
            this.OldServicesRptFrmBtn.Text = "تقرير خدمات المرضى";
            this.OldServicesRptFrmBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.OldServicesRptFrmBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.OldServicesRptFrmBtn.Click += new System.EventHandler(this.OldServicesRptFrmBtn_Click_1);
            // 
            // FrmRptPatientDebtBtn
            // 
            this.FrmRptPatientDebtBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmRptPatientDebtBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmRptPatientDebtBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmRptPatientDebtBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmRptPatientDebtBtn.Name = "FrmRptPatientDebtBtn";
            this.FrmRptPatientDebtBtn.Size = new System.Drawing.Size(243, 24);
            this.FrmRptPatientDebtBtn.Text = "تقرير مديونيات المرضى";
            this.FrmRptPatientDebtBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmRptPatientDebtBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmRptPatientDebtBtn.Click += new System.EventHandler(this.FrmRptPatientDebtBtn_Click);
            // 
            // RptTaqweem
            // 
            this.RptTaqweem.BackColor = System.Drawing.SystemColors.Control;
            this.RptTaqweem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.RptTaqweem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RptTaqweem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.RptTaqweem.Name = "RptTaqweem";
            this.RptTaqweem.Size = new System.Drawing.Size(243, 24);
            this.RptTaqweem.Text = "تقرير مرضى التقويم";
            this.RptTaqweem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.RptTaqweem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.RptTaqweem.Visible = false;
            this.RptTaqweem.Click += new System.EventHandler(this.RptTaqweem_Click_1);
            // 
            // PatientPointRptBtn
            // 
            this.PatientPointRptBtn.BackColor = System.Drawing.SystemColors.Control;
            this.PatientPointRptBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PatientPointRptBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PatientPointRptBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PatientPointRptBtn.Name = "PatientPointRptBtn";
            this.PatientPointRptBtn.Size = new System.Drawing.Size(243, 24);
            this.PatientPointRptBtn.Text = "تقرير نقاط مريض";
            this.PatientPointRptBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.PatientPointRptBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PatientPointRptBtn.Click += new System.EventHandler(this.PatientPointRptBtn_Click);
            // 
            // RptKnowFromBtn
            // 
            this.RptKnowFromBtn.BackColor = System.Drawing.SystemColors.Control;
            this.RptKnowFromBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.RptKnowFromBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RptKnowFromBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.RptKnowFromBtn.Name = "RptKnowFromBtn";
            this.RptKnowFromBtn.Size = new System.Drawing.Size(243, 24);
            this.RptKnowFromBtn.Text = "تقرير معرفة عن";
            this.RptKnowFromBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.RptKnowFromBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.RptKnowFromBtn.Click += new System.EventHandler(this.RptKnowFromBtn_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripMenuItem4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(243, 24);
            this.toolStripMenuItem4.Text = "بيانات المرضى";
            this.toolStripMenuItem4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolStripMenuItem4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click_1);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripMenuItem6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem6.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(243, 24);
            this.toolStripMenuItem6.Text = "تاريخ الولادة المتوقعة";
            this.toolStripMenuItem6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolStripMenuItem6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // toolStripMenuItem_7
            // 
            this.toolStripMenuItem_7.Name = "toolStripMenuItem_7";
            this.toolStripMenuItem_7.Size = new System.Drawing.Size(243, 24);
            this.toolStripMenuItem_7.Text = "تقرير إشعارات المرضي";
            this.toolStripMenuItem_7.Click += new System.EventHandler(this.toolStripMenuItem_7_Click);
            // 
            // toolStripMenuItem_18
            // 
            this.toolStripMenuItem_18.Name = "toolStripMenuItem_18";
            this.toolStripMenuItem_18.Size = new System.Drawing.Size(243, 24);
            this.toolStripMenuItem_18.Text = "تقرير إعادة كشوفات مريض";
            this.toolStripMenuItem_18.Click += new System.EventHandler(this.toolStripMenuItem_18_Click);
            // 
            // toolStripMenuItem_25
            // 
            this.toolStripMenuItem_25.Name = "toolStripMenuItem_25";
            this.toolStripMenuItem_25.Size = new System.Drawing.Size(243, 24);
            this.toolStripMenuItem_25.Text = "عروض المرضي";
            this.toolStripMenuItem_25.Click += new System.EventHandler(this.toolStripMenuItem_25_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripMenuItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DoctorAcountRptBtn,
            this.DoctorPaymentBtn,
            this.MovementOfPatByDr,
            this.toolStripMenuItem_4,
            this.toolStripMenuItem_13});
            this.toolStripMenuItem1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(262, 24);
            this.toolStripMenuItem1.Text = "تقارير الأطباء";
            this.toolStripMenuItem1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // DoctorAcountRptBtn
            // 
            this.DoctorAcountRptBtn.BackColor = System.Drawing.SystemColors.Control;
            this.DoctorAcountRptBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.DoctorAcountRptBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DoctorAcountRptBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DoctorAcountRptBtn.Name = "DoctorAcountRptBtn";
            this.DoctorAcountRptBtn.Size = new System.Drawing.Size(237, 24);
            this.DoctorAcountRptBtn.Text = "تقرير حساب طبيب";
            this.DoctorAcountRptBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DoctorAcountRptBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DoctorAcountRptBtn.Click += new System.EventHandler(this.DoctorAcountRptBtn_Click);
            // 
            // DoctorPaymentBtn
            // 
            this.DoctorPaymentBtn.BackColor = System.Drawing.SystemColors.Control;
            this.DoctorPaymentBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.DoctorPaymentBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DoctorPaymentBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DoctorPaymentBtn.Name = "DoctorPaymentBtn";
            this.DoctorPaymentBtn.Size = new System.Drawing.Size(237, 24);
            this.DoctorPaymentBtn.Text = "تقرير مدفوعات طبيب";
            this.DoctorPaymentBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DoctorPaymentBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DoctorPaymentBtn.Click += new System.EventHandler(this.DoctorPaymentBtn_Click);
            // 
            // MovementOfPatByDr
            // 
            this.MovementOfPatByDr.BackColor = System.Drawing.SystemColors.Control;
            this.MovementOfPatByDr.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.MovementOfPatByDr.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.MovementOfPatByDr.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MovementOfPatByDr.Name = "MovementOfPatByDr";
            this.MovementOfPatByDr.Size = new System.Drawing.Size(237, 24);
            this.MovementOfPatByDr.Text = "تقرير كشوفات طبيب";
            this.MovementOfPatByDr.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.MovementOfPatByDr.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.MovementOfPatByDr.Click += new System.EventHandler(this.MovementOfPatByDr_Click);
            // 
            // toolStripMenuItem_4
            // 
            this.toolStripMenuItem_4.Name = "toolStripMenuItem_4";
            this.toolStripMenuItem_4.Size = new System.Drawing.Size(237, 24);
            this.toolStripMenuItem_4.Text = "تقرير مواعيد الأطباء";
            this.toolStripMenuItem_4.Click += new System.EventHandler(this.toolStripMenuItem_4_Click);
            // 
            // toolStripMenuItem_13
            // 
            this.toolStripMenuItem_13.Name = "toolStripMenuItem_13";
            this.toolStripMenuItem_13.Size = new System.Drawing.Size(237, 24);
            this.toolStripMenuItem_13.Text = "تقرير إعادة كشوفات طبيب";
            this.toolStripMenuItem_13.Click += new System.EventHandler(this.toolStripMenuItem_13_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripMenuItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AssistantAcountDate,
            this.RptAssistantPaymentBtn,
            this.FrmAssistantRptBtn});
            this.toolStripMenuItem2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(262, 24);
            this.toolStripMenuItem2.Text = "تقارير المساعدين";
            this.toolStripMenuItem2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolStripMenuItem2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // AssistantAcountDate
            // 
            this.AssistantAcountDate.BackColor = System.Drawing.SystemColors.Control;
            this.AssistantAcountDate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AssistantAcountDate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AssistantAcountDate.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.AssistantAcountDate.Name = "AssistantAcountDate";
            this.AssistantAcountDate.Size = new System.Drawing.Size(219, 24);
            this.AssistantAcountDate.Text = "تقرير حساب مساعد";
            this.AssistantAcountDate.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.AssistantAcountDate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.AssistantAcountDate.Click += new System.EventHandler(this.AssistantAcountDate_Click);
            // 
            // RptAssistantPaymentBtn
            // 
            this.RptAssistantPaymentBtn.BackColor = System.Drawing.SystemColors.Control;
            this.RptAssistantPaymentBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.RptAssistantPaymentBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RptAssistantPaymentBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.RptAssistantPaymentBtn.Name = "RptAssistantPaymentBtn";
            this.RptAssistantPaymentBtn.Size = new System.Drawing.Size(219, 24);
            this.RptAssistantPaymentBtn.Text = "تقرير مدفوعات مساعد";
            this.RptAssistantPaymentBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.RptAssistantPaymentBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.RptAssistantPaymentBtn.Visible = false;
            this.RptAssistantPaymentBtn.Click += new System.EventHandler(this.RptAssistantPaymentBtn_Click_1);
            // 
            // FrmAssistantRptBtn
            // 
            this.FrmAssistantRptBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmAssistantRptBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmAssistantRptBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmAssistantRptBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmAssistantRptBtn.Name = "FrmAssistantRptBtn";
            this.FrmAssistantRptBtn.Size = new System.Drawing.Size(219, 24);
            this.FrmAssistantRptBtn.Text = "تقرير خدمات المساعدين";
            this.FrmAssistantRptBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmAssistantRptBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmAssistantRptBtn.Click += new System.EventHandler(this.FrmAssistantRptBtn_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripMenuItem3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.expensesToolStripMenuItem1,
            this.revenuesToolStripMenuItem1,
            this.dailyClinicToolStripMenuItem,
            this.NetDailyClinicRptFrmBtn,
            this.ClinicMonthGraphRptFrmBtn,
            this.DailymeasureRotFrmBtn,
            this.BtnFrmRptReb7ya,
            this.FrmInventoryRptBtn,
            this.FrmRptSurgeryBtn,
            this.FrmRptCompanyAcountBtn,
            this.StockTransRptFrmBtn,
            this.toolStripMenuItem5,
            this.toolStripMenuItem_1,
            this.toolStripMenuItem_22,
            this.toolStripMenuItem_24});
            this.toolStripMenuItem3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(262, 24);
            this.toolStripMenuItem3.Text = "تقارير العيادة";
            this.toolStripMenuItem3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolStripMenuItem3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // expensesToolStripMenuItem1
            // 
            this.expensesToolStripMenuItem1.BackColor = System.Drawing.SystemColors.Control;
            this.expensesToolStripMenuItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.expensesToolStripMenuItem1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.expensesToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.expensesToolStripMenuItem1.Name = "expensesToolStripMenuItem1";
            this.expensesToolStripMenuItem1.Size = new System.Drawing.Size(237, 24);
            this.expensesToolStripMenuItem1.Text = "تقرير المصروفات";
            this.expensesToolStripMenuItem1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.expensesToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.expensesToolStripMenuItem1.Click += new System.EventHandler(this.expensesToolStripMenuItem1_Click);
            // 
            // revenuesToolStripMenuItem1
            // 
            this.revenuesToolStripMenuItem1.BackColor = System.Drawing.SystemColors.Control;
            this.revenuesToolStripMenuItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.revenuesToolStripMenuItem1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.revenuesToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.revenuesToolStripMenuItem1.Name = "revenuesToolStripMenuItem1";
            this.revenuesToolStripMenuItem1.Size = new System.Drawing.Size(237, 24);
            this.revenuesToolStripMenuItem1.Text = "تقرير الإيرادات";
            this.revenuesToolStripMenuItem1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.revenuesToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.revenuesToolStripMenuItem1.Click += new System.EventHandler(this.revenuesToolStripMenuItem1_Click);
            // 
            // dailyClinicToolStripMenuItem
            // 
            this.dailyClinicToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.dailyClinicToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.dailyClinicToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dailyClinicToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.dailyClinicToolStripMenuItem.Name = "dailyClinicToolStripMenuItem";
            this.dailyClinicToolStripMenuItem.Size = new System.Drawing.Size(237, 24);
            this.dailyClinicToolStripMenuItem.Text = "تقرير يومية العيادة";
            this.dailyClinicToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.dailyClinicToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.dailyClinicToolStripMenuItem.Click += new System.EventHandler(this.dailyClinicToolStripMenuItem_Click);
            // 
            // NetDailyClinicRptFrmBtn
            // 
            this.NetDailyClinicRptFrmBtn.BackColor = System.Drawing.SystemColors.Control;
            this.NetDailyClinicRptFrmBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.NetDailyClinicRptFrmBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NetDailyClinicRptFrmBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.NetDailyClinicRptFrmBtn.Name = "NetDailyClinicRptFrmBtn";
            this.NetDailyClinicRptFrmBtn.Size = new System.Drawing.Size(237, 24);
            this.NetDailyClinicRptFrmBtn.Text = "تقرير صافى يومية العيادة";
            this.NetDailyClinicRptFrmBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.NetDailyClinicRptFrmBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.NetDailyClinicRptFrmBtn.Click += new System.EventHandler(this.NetDailyClinicRptFrmBtn_Click_1);
            // 
            // ClinicMonthGraphRptFrmBtn
            // 
            this.ClinicMonthGraphRptFrmBtn.BackColor = System.Drawing.SystemColors.Control;
            this.ClinicMonthGraphRptFrmBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ClinicMonthGraphRptFrmBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ClinicMonthGraphRptFrmBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ClinicMonthGraphRptFrmBtn.Name = "ClinicMonthGraphRptFrmBtn";
            this.ClinicMonthGraphRptFrmBtn.Size = new System.Drawing.Size(237, 24);
            this.ClinicMonthGraphRptFrmBtn.Text = "التقرير الشهرى";
            this.ClinicMonthGraphRptFrmBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ClinicMonthGraphRptFrmBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.ClinicMonthGraphRptFrmBtn.Click += new System.EventHandler(this.ClinicMonthGraphRptFrmBtn_Click_1);
            // 
            // DailymeasureRotFrmBtn
            // 
            this.DailymeasureRotFrmBtn.BackColor = System.Drawing.SystemColors.Control;
            this.DailymeasureRotFrmBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.DailymeasureRotFrmBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DailymeasureRotFrmBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DailymeasureRotFrmBtn.Name = "DailymeasureRotFrmBtn";
            this.DailymeasureRotFrmBtn.Size = new System.Drawing.Size(237, 24);
            this.DailymeasureRotFrmBtn.Text = "مقارنة التقرير اليومى";
            this.DailymeasureRotFrmBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DailymeasureRotFrmBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DailymeasureRotFrmBtn.Click += new System.EventHandler(this.DailymeasureRotFrmBtn_Click_1);
            // 
            // BtnFrmRptReb7ya
            // 
            this.BtnFrmRptReb7ya.BackColor = System.Drawing.SystemColors.Control;
            this.BtnFrmRptReb7ya.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.BtnFrmRptReb7ya.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnFrmRptReb7ya.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnFrmRptReb7ya.Name = "BtnFrmRptReb7ya";
            this.BtnFrmRptReb7ya.Size = new System.Drawing.Size(237, 24);
            this.BtnFrmRptReb7ya.Text = "تقرير الربحية";
            this.BtnFrmRptReb7ya.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnFrmRptReb7ya.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnFrmRptReb7ya.Click += new System.EventHandler(this.BtnFrmRptReb7ya_Click_1);
            // 
            // FrmInventoryRptBtn
            // 
            this.FrmInventoryRptBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmInventoryRptBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmInventoryRptBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmInventoryRptBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmInventoryRptBtn.Name = "FrmInventoryRptBtn";
            this.FrmInventoryRptBtn.Size = new System.Drawing.Size(237, 24);
            this.FrmInventoryRptBtn.Text = "تقرير جرد للمخزن";
            this.FrmInventoryRptBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmInventoryRptBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmInventoryRptBtn.Click += new System.EventHandler(this.FrmInventoryRptBtn_Click_1);
            // 
            // FrmRptSurgeryBtn
            // 
            this.FrmRptSurgeryBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmRptSurgeryBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmRptSurgeryBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmRptSurgeryBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmRptSurgeryBtn.Name = "FrmRptSurgeryBtn";
            this.FrmRptSurgeryBtn.Size = new System.Drawing.Size(237, 24);
            this.FrmRptSurgeryBtn.Text = "تقرير إجمالى العمليات";
            this.FrmRptSurgeryBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmRptSurgeryBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmRptSurgeryBtn.Click += new System.EventHandler(this.FrmRptSurgeryBtn_Click);
            // 
            // FrmRptCompanyAcountBtn
            // 
            this.FrmRptCompanyAcountBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmRptCompanyAcountBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmRptCompanyAcountBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmRptCompanyAcountBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmRptCompanyAcountBtn.Name = "FrmRptCompanyAcountBtn";
            this.FrmRptCompanyAcountBtn.Size = new System.Drawing.Size(237, 24);
            this.FrmRptCompanyAcountBtn.Text = "تقرير حساب شركة";
            this.FrmRptCompanyAcountBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmRptCompanyAcountBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmRptCompanyAcountBtn.Visible = false;
            this.FrmRptCompanyAcountBtn.Click += new System.EventHandler(this.FrmRptCompanyAcountBtn_Click);
            // 
            // StockTransRptFrmBtn
            // 
            this.StockTransRptFrmBtn.BackColor = System.Drawing.SystemColors.Control;
            this.StockTransRptFrmBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.StockTransRptFrmBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.StockTransRptFrmBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.StockTransRptFrmBtn.Name = "StockTransRptFrmBtn";
            this.StockTransRptFrmBtn.Size = new System.Drawing.Size(237, 24);
            this.StockTransRptFrmBtn.Text = "تقرير التحويل بين الخزائن";
            this.StockTransRptFrmBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.StockTransRptFrmBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.StockTransRptFrmBtn.Click += new System.EventHandler(this.StockTransRptFrmBtn_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripMenuItem5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(237, 24);
            this.toolStripMenuItem5.Text = "حركة صنف شاملة";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem_1
            // 
            this.toolStripMenuItem_1.Name = "toolStripMenuItem_1";
            this.toolStripMenuItem_1.Size = new System.Drawing.Size(237, 24);
            this.toolStripMenuItem_1.Text = "تقرير عرض الحجوزات";
            this.toolStripMenuItem_1.Click += new System.EventHandler(this.toolStripMenuItem_1_Click);
            // 
            // toolStripMenuItem_22
            // 
            this.toolStripMenuItem_22.Name = "toolStripMenuItem_22";
            this.toolStripMenuItem_22.Size = new System.Drawing.Size(237, 24);
            this.toolStripMenuItem_22.Text = "تقرير حركة خزينة جديد";
            this.toolStripMenuItem_22.Click += new System.EventHandler(this.toolStripMenuItem_22_Click);
            // 
            // toolStripMenuItem_24
            // 
            this.toolStripMenuItem_24.Name = "toolStripMenuItem_24";
            this.toolStripMenuItem_24.Size = new System.Drawing.Size(237, 24);
            this.toolStripMenuItem_24.Text = "تقرير كشوفات التجميل";
            this.toolStripMenuItem_24.Click += new System.EventHandler(this.toolStripMenuItem_24_Click);
            // 
            // FrmSearchMedicine
            // 
            this.FrmSearchMedicine.BackColor = System.Drawing.SystemColors.Control;
            this.FrmSearchMedicine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmSearchMedicine.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmSearchMedicine.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmSearchMedicine.Name = "FrmSearchMedicine";
            this.FrmSearchMedicine.Size = new System.Drawing.Size(262, 24);
            this.FrmSearchMedicine.Text = "تقرير عدد الدواء فى الروشتات";
            this.FrmSearchMedicine.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmSearchMedicine.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmSearchMedicine.Click += new System.EventHandler(this.FrmSearchMedicine_Click_1);
            // 
            // FrmRptSahbItemBtn
            // 
            this.FrmRptSahbItemBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmRptSahbItemBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmRptSahbItemBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmRptSahbItemBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmRptSahbItemBtn.Name = "FrmRptSahbItemBtn";
            this.FrmRptSahbItemBtn.Size = new System.Drawing.Size(262, 24);
            this.FrmRptSahbItemBtn.Text = "تقرير سحب كميات الأصناف";
            this.FrmRptSahbItemBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmRptSahbItemBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmRptSahbItemBtn.Visible = false;
            this.FrmRptSahbItemBtn.Click += new System.EventHandler(this.FrmRptSahbItemBtn_Click_1);
            // 
            // BtnFrmRptCompanies_Services
            // 
            this.BtnFrmRptCompanies_Services.BackColor = System.Drawing.SystemColors.Control;
            this.BtnFrmRptCompanies_Services.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.BtnFrmRptCompanies_Services.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnFrmRptCompanies_Services.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnFrmRptCompanies_Services.Name = "BtnFrmRptCompanies_Services";
            this.BtnFrmRptCompanies_Services.Size = new System.Drawing.Size(262, 24);
            this.BtnFrmRptCompanies_Services.Text = "تقرير خدمات شركات";
            this.BtnFrmRptCompanies_Services.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnFrmRptCompanies_Services.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnFrmRptCompanies_Services.Click += new System.EventHandler(this.BtnFrmRptCompanies_Services_Click_1);
            // 
            // FrmBillBtn
            // 
            this.FrmBillBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmBillBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmBillBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmBillBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmBillBtn.Name = "FrmBillBtn";
            this.FrmBillBtn.Size = new System.Drawing.Size(262, 24);
            this.FrmBillBtn.Text = "الفواتير";
            this.FrmBillBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmBillBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmBillBtn.Click += new System.EventHandler(this.FrmBillBtn_Click);
            // 
            // RptLoginUserBtn
            // 
            this.RptLoginUserBtn.BackColor = System.Drawing.SystemColors.Control;
            this.RptLoginUserBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.RptLoginUserBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RptLoginUserBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.RptLoginUserBtn.Name = "RptLoginUserBtn";
            this.RptLoginUserBtn.Size = new System.Drawing.Size(262, 24);
            this.RptLoginUserBtn.Text = "تقرير حركة مستخدم";
            this.RptLoginUserBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.RptLoginUserBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.RptLoginUserBtn.Click += new System.EventHandler(this.RptLoginUserBtn_Click);
            // 
            // ReserveServiceRptFrmBtn
            // 
            this.ReserveServiceRptFrmBtn.BackColor = System.Drawing.SystemColors.Control;
            this.ReserveServiceRptFrmBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ReserveServiceRptFrmBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ReserveServiceRptFrmBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ReserveServiceRptFrmBtn.Name = "ReserveServiceRptFrmBtn";
            this.ReserveServiceRptFrmBtn.Size = new System.Drawing.Size(262, 24);
            this.ReserveServiceRptFrmBtn.Text = "تقرير حجوزات خدمات";
            this.ReserveServiceRptFrmBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ReserveServiceRptFrmBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.ReserveServiceRptFrmBtn.Click += new System.EventHandler(this.ReserveServiceRptFrmBtn_Click);
            // 
            // FrmEsalBtn
            // 
            this.FrmEsalBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmEsalBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmEsalBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmEsalBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmEsalBtn.Name = "FrmEsalBtn";
            this.FrmEsalBtn.Size = new System.Drawing.Size(262, 24);
            this.FrmEsalBtn.Text = "الإيصالات";
            this.FrmEsalBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmEsalBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmEsalBtn.Click += new System.EventHandler(this.FrmEsalBtn_Click);
            // 
            // FrmRptRayAnalyzeBtn
            // 
            this.FrmRptRayAnalyzeBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmRptRayAnalyzeBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmRptRayAnalyzeBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmRptRayAnalyzeBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmRptRayAnalyzeBtn.Name = "FrmRptRayAnalyzeBtn";
            this.FrmRptRayAnalyzeBtn.Size = new System.Drawing.Size(262, 24);
            this.FrmRptRayAnalyzeBtn.Text = "تقرير أشعة وتحاليل";
            this.FrmRptRayAnalyzeBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmRptRayAnalyzeBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmRptRayAnalyzeBtn.Click += new System.EventHandler(this.FrmRptRayAnalyzeBtn_Click);
            // 
            // toolStripMenuItem_5
            // 
            this.toolStripMenuItem_5.Name = "toolStripMenuItem_5";
            this.toolStripMenuItem_5.Size = new System.Drawing.Size(262, 24);
            this.toolStripMenuItem_5.Text = "تقرير أسعار خدمات شركات";
            this.toolStripMenuItem_5.Click += new System.EventHandler(this.toolStripMenuItem_5_Click);
            // 
            // toolStripMenuItem_20
            // 
            this.toolStripMenuItem_20.Name = "toolStripMenuItem_20";
            this.toolStripMenuItem_20.Size = new System.Drawing.Size(262, 24);
            this.toolStripMenuItem_20.Text = "تقرير كل الخدمات";
            this.toolStripMenuItem_20.Click += new System.EventHandler(this.toolStripMenuItem_20_Click);
            // 
            // toolStripMenuItem_28
            // 
            this.toolStripMenuItem_28.Name = "toolStripMenuItem_28";
            this.toolStripMenuItem_28.Size = new System.Drawing.Size(262, 24);
            this.toolStripMenuItem_28.Text = "تقرير الأجازات المرضية";
            this.toolStripMenuItem_28.Click += new System.EventHandler(this.toolStripMenuItem_28_Click);
            // 
            // toolStripMenuItem_30
            // 
            this.toolStripMenuItem_30.Name = "toolStripMenuItem_30";
            this.toolStripMenuItem_30.Size = new System.Drawing.Size(262, 24);
            this.toolStripMenuItem_30.Text = "تقرير شهادة حضور";
            this.toolStripMenuItem_30.Click += new System.EventHandler(this.toolStripMenuItem_30_Click);
            // 
            // toolStripMenuItem_31
            // 
            this.toolStripMenuItem_31.Name = "toolStripMenuItem_31";
            this.toolStripMenuItem_31.Size = new System.Drawing.Size(262, 24);
            this.toolStripMenuItem_31.Text = "التواصل مع المرضي";
            this.toolStripMenuItem_31.Click += new System.EventHandler(this.toolStripMenuItem_31_Click);
            // 
            // EmployeeBtn
            // 
            this.EmployeeBtn.AutoSize = false;
            this.EmployeeBtn.BackColor = System.Drawing.Color.Transparent;
            this.EmployeeBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.EmployeeBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.EmployeeBtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEmployeeBtn});
            this.EmployeeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.EmployeeBtn.ForeColor = System.Drawing.Color.Transparent;
            this.EmployeeBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.EmployeeBtn.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.EmployeeBtn.Name = "EmployeeBtn";
            this.EmployeeBtn.Size = new System.Drawing.Size(130, 48);
            this.EmployeeBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.EmployeeBtn.Click += new System.EventHandler(this.EmployeeBtn_Click);
            // 
            // addEmployeeBtn
            // 
            this.addEmployeeBtn.BackColor = System.Drawing.SystemColors.Control;
            this.addEmployeeBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.addEmployeeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.addEmployeeBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addEmployeeBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.addEmployeeBtn.Name = "addEmployeeBtn";
            this.addEmployeeBtn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.addEmployeeBtn.RightToLeftAutoMirrorImage = true;
            this.addEmployeeBtn.Size = new System.Drawing.Size(159, 24);
            this.addEmployeeBtn.Text = "اضافة موظف";
            this.addEmployeeBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.addEmployeeBtn.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.addEmployeeBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.addEmployeeBtn.Click += new System.EventHandler(this.addEmployeeBtn_Click);
            // 
            // IncomingSuppBtn
            // 
            this.IncomingSuppBtn.AutoSize = false;
            this.IncomingSuppBtn.BackColor = System.Drawing.Color.Transparent;
            this.IncomingSuppBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.IncomingSuppBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.IncomingSuppBtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ItemsFrmBtn,
            this.SupplierBtn,
            this.FrmDeanSupplierBtn,
            this.FrmSupplierAccountsBtn,
            this.FormSupplier5Btn,
            this.IncomingBillFrmBtn,
            this.FrmBillIncomeRptBtn,
            this.FrmRptBillByDateBtn,
            this.SahbItemsBtn,
            this.BtnFrmSell,
            this.FrmRptSellByDateBtn});
            this.IncomingSuppBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.IncomingSuppBtn.ForeColor = System.Drawing.Color.Transparent;
            this.IncomingSuppBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.IncomingSuppBtn.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.IncomingSuppBtn.Name = "IncomingSuppBtn";
            this.IncomingSuppBtn.Size = new System.Drawing.Size(122, 48);
            this.IncomingSuppBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // ItemsFrmBtn
            // 
            this.ItemsFrmBtn.BackColor = System.Drawing.SystemColors.Control;
            this.ItemsFrmBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ItemsFrmBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ItemsFrmBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ItemsFrmBtn.Name = "ItemsFrmBtn";
            this.ItemsFrmBtn.Size = new System.Drawing.Size(233, 24);
            this.ItemsFrmBtn.Text = "الأصناف";
            this.ItemsFrmBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ItemsFrmBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.ItemsFrmBtn.Click += new System.EventHandler(this.ItemsFrmBtn_Click_1);
            // 
            // SupplierBtn
            // 
            this.SupplierBtn.BackColor = System.Drawing.SystemColors.Control;
            this.SupplierBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SupplierBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SupplierBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.SupplierBtn.Name = "SupplierBtn";
            this.SupplierBtn.Size = new System.Drawing.Size(233, 24);
            this.SupplierBtn.Text = "الموردين";
            this.SupplierBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.SupplierBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.SupplierBtn.Click += new System.EventHandler(this.SupplierBtn_Click_1);
            // 
            // FrmDeanSupplierBtn
            // 
            this.FrmDeanSupplierBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmDeanSupplierBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmDeanSupplierBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmDeanSupplierBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmDeanSupplierBtn.Name = "FrmDeanSupplierBtn";
            this.FrmDeanSupplierBtn.Size = new System.Drawing.Size(233, 24);
            this.FrmDeanSupplierBtn.Text = "رصيد أول المدة للمورد";
            this.FrmDeanSupplierBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmDeanSupplierBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmDeanSupplierBtn.Click += new System.EventHandler(this.FrmDeanSupplierBtn_Click_1);
            // 
            // FrmSupplierAccountsBtn
            // 
            this.FrmSupplierAccountsBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmSupplierAccountsBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmSupplierAccountsBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmSupplierAccountsBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmSupplierAccountsBtn.Name = "FrmSupplierAccountsBtn";
            this.FrmSupplierAccountsBtn.Size = new System.Drawing.Size(233, 24);
            this.FrmSupplierAccountsBtn.Text = "حسابات الموردين";
            this.FrmSupplierAccountsBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmSupplierAccountsBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmSupplierAccountsBtn.Click += new System.EventHandler(this.FrmSupplierAccountsBtn_Click);
            // 
            // FormSupplier5Btn
            // 
            this.FormSupplier5Btn.BackColor = System.Drawing.SystemColors.Control;
            this.FormSupplier5Btn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FormSupplier5Btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FormSupplier5Btn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FormSupplier5Btn.Name = "FormSupplier5Btn";
            this.FormSupplier5Btn.Size = new System.Drawing.Size(233, 24);
            this.FormSupplier5Btn.Text = "كشف حساب مورد";
            this.FormSupplier5Btn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FormSupplier5Btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FormSupplier5Btn.Click += new System.EventHandler(this.FormSupplier5Btn_Click);
            // 
            // IncomingBillFrmBtn
            // 
            this.IncomingBillFrmBtn.BackColor = System.Drawing.SystemColors.Control;
            this.IncomingBillFrmBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.IncomingBillFrmBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.IncomingBillFrmBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.IncomingBillFrmBtn.Name = "IncomingBillFrmBtn";
            this.IncomingBillFrmBtn.Size = new System.Drawing.Size(233, 24);
            this.IncomingBillFrmBtn.Text = "فاتورة مشتريات";
            this.IncomingBillFrmBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.IncomingBillFrmBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.IncomingBillFrmBtn.Click += new System.EventHandler(this.IncomingBillFrmBtn_Click);
            // 
            // FrmBillIncomeRptBtn
            // 
            this.FrmBillIncomeRptBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmBillIncomeRptBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmBillIncomeRptBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmBillIncomeRptBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmBillIncomeRptBtn.Name = "FrmBillIncomeRptBtn";
            this.FrmBillIncomeRptBtn.Size = new System.Drawing.Size(233, 24);
            this.FrmBillIncomeRptBtn.Text = "تقارير فواتير المشتريات";
            this.FrmBillIncomeRptBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmBillIncomeRptBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmBillIncomeRptBtn.Click += new System.EventHandler(this.FrmBillIncomeRptBtn_Click);
            // 
            // FrmRptBillByDateBtn
            // 
            this.FrmRptBillByDateBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmRptBillByDateBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmRptBillByDateBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmRptBillByDateBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmRptBillByDateBtn.Name = "FrmRptBillByDateBtn";
            this.FrmRptBillByDateBtn.Size = new System.Drawing.Size(233, 24);
            this.FrmRptBillByDateBtn.Text = "تقرير مشتريات خلال فترة";
            this.FrmRptBillByDateBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmRptBillByDateBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmRptBillByDateBtn.Click += new System.EventHandler(this.FrmRptBillByDateBtn_Click);
            // 
            // SahbItemsBtn
            // 
            this.SahbItemsBtn.BackColor = System.Drawing.SystemColors.Control;
            this.SahbItemsBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SahbItemsBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SahbItemsBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.SahbItemsBtn.Name = "SahbItemsBtn";
            this.SahbItemsBtn.Size = new System.Drawing.Size(233, 24);
            this.SahbItemsBtn.Text = "تسوية كميات";
            this.SahbItemsBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.SahbItemsBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.SahbItemsBtn.Visible = false;
            this.SahbItemsBtn.Click += new System.EventHandler(this.SahbItemsBtn_Click);
            // 
            // BtnFrmSell
            // 
            this.BtnFrmSell.BackColor = System.Drawing.SystemColors.Control;
            this.BtnFrmSell.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.BtnFrmSell.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnFrmSell.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnFrmSell.Name = "BtnFrmSell";
            this.BtnFrmSell.Size = new System.Drawing.Size(233, 24);
            this.BtnFrmSell.Text = "فاتورة مبيعات";
            this.BtnFrmSell.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnFrmSell.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnFrmSell.Click += new System.EventHandler(this.BtnFrmSell_Click);
            // 
            // FrmRptSellByDateBtn
            // 
            this.FrmRptSellByDateBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmRptSellByDateBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmRptSellByDateBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmRptSellByDateBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmRptSellByDateBtn.Name = "FrmRptSellByDateBtn";
            this.FrmRptSellByDateBtn.Size = new System.Drawing.Size(233, 24);
            this.FrmRptSellByDateBtn.Text = "تقرير مبيعات عن فترة";
            this.FrmRptSellByDateBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmRptSellByDateBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmRptSellByDateBtn.Click += new System.EventHandler(this.FrmRptSellByDateBtn_Click);
            // 
            // naturaltherapy
            // 
            this.naturaltherapy.AutoSize = false;
            this.naturaltherapy.BackColor = System.Drawing.Color.Transparent;
            this.naturaltherapy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.naturaltherapy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.naturaltherapy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem14,
            this.orthopedicalPhysiotherapyToolStripMenuItem,
            this.neurologicalPhysiotherapyToolStripMenuItem,
            this.toolStripMenuItem_12});
            this.naturaltherapy.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.naturaltherapy.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.naturaltherapy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.naturaltherapy.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.naturaltherapy.Name = "naturaltherapy";
            this.naturaltherapy.Size = new System.Drawing.Size(130, 48);
            this.naturaltherapy.Text = "العلاج الطبيعي";
            this.naturaltherapy.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.naturaltherapy.Click += new System.EventHandler(this.naturaltherapy_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripMenuItem14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem14.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem14.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(307, 24);
            this.toolStripMenuItem14.Text = "Pediatric  Assessment  ";
            this.toolStripMenuItem14.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolStripMenuItem14.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem14.Click += new System.EventHandler(this.toolStripMenuItem14_Click);
            // 
            // orthopedicalPhysiotherapyToolStripMenuItem
            // 
            this.orthopedicalPhysiotherapyToolStripMenuItem.Name = "orthopedicalPhysiotherapyToolStripMenuItem";
            this.orthopedicalPhysiotherapyToolStripMenuItem.Size = new System.Drawing.Size(307, 24);
            this.orthopedicalPhysiotherapyToolStripMenuItem.Text = "Orthopedical – physiotherapy ";
            this.orthopedicalPhysiotherapyToolStripMenuItem.Click += new System.EventHandler(this.orthopedicalPhysiotherapyToolStripMenuItem_Click);
            // 
            // neurologicalPhysiotherapyToolStripMenuItem
            // 
            this.neurologicalPhysiotherapyToolStripMenuItem.Name = "neurologicalPhysiotherapyToolStripMenuItem";
            this.neurologicalPhysiotherapyToolStripMenuItem.Size = new System.Drawing.Size(307, 24);
            this.neurologicalPhysiotherapyToolStripMenuItem.Text = "Neurological – physiotherapy";
            this.neurologicalPhysiotherapyToolStripMenuItem.Click += new System.EventHandler(this.neurologicalPhysiotherapyToolStripMenuItem_Click);
            // 
            // toolStripMenuItem_12
            // 
            this.toolStripMenuItem_12.Name = "toolStripMenuItem_12";
            this.toolStripMenuItem_12.Size = new System.Drawing.Size(307, 24);
            this.toolStripMenuItem_12.Text = "تسجيل أجهزة العلاج الطبيعي";
            this.toolStripMenuItem_12.Click += new System.EventHandler(this.toolStripMenuItem_12_Click);
            // 
            // button1
            // 
            this.button1.AutoSize = false;
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.button1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DentalDataBtn,
            this.PermissionBtn,
            this.FrmPropertiesBtn,
            this.btnBackup_Restore,
            this.toolStripMenuItem_2,
            this.toolStripMenuItem_8,
            this.toolStripMenuItem_19});
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.button1.ImageTransparentColor = System.Drawing.Color.Transparent;
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 48);
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // DentalDataBtn
            // 
            this.DentalDataBtn.BackColor = System.Drawing.SystemColors.Control;
            this.DentalDataBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.DentalDataBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DentalDataBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DentalDataBtn.Name = "DentalDataBtn";
            this.DentalDataBtn.Size = new System.Drawing.Size(314, 24);
            this.DentalDataBtn.Text = "بيانات العيادة";
            this.DentalDataBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DentalDataBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DentalDataBtn.Click += new System.EventHandler(this.DentalDataBtn_Click);
            // 
            // PermissionBtn
            // 
            this.PermissionBtn.BackColor = System.Drawing.SystemColors.Control;
            this.PermissionBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.PermissionBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PermissionBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.PermissionBtn.Name = "PermissionBtn";
            this.PermissionBtn.Size = new System.Drawing.Size(314, 24);
            this.PermissionBtn.Text = "المستخدمون و الصلاحيات";
            this.PermissionBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.PermissionBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PermissionBtn.Click += new System.EventHandler(this.PermissionBtn_Click);
            // 
            // FrmPropertiesBtn
            // 
            this.FrmPropertiesBtn.BackColor = System.Drawing.SystemColors.Control;
            this.FrmPropertiesBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.FrmPropertiesBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FrmPropertiesBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.FrmPropertiesBtn.Name = "FrmPropertiesBtn";
            this.FrmPropertiesBtn.Size = new System.Drawing.Size(314, 24);
            this.FrmPropertiesBtn.Text = "خصائص عامة";
            this.FrmPropertiesBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.FrmPropertiesBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.FrmPropertiesBtn.Click += new System.EventHandler(this.FrmPropertiesBtn_Click);
            // 
            // btnBackup_Restore
            // 
            this.btnBackup_Restore.BackColor = System.Drawing.SystemColors.Control;
            this.btnBackup_Restore.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnBackup_Restore.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBackup_Restore.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnBackup_Restore.Name = "btnBackup_Restore";
            this.btnBackup_Restore.Size = new System.Drawing.Size(314, 24);
            this.btnBackup_Restore.Text = "عمل نسخة احتياطية";
            this.btnBackup_Restore.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBackup_Restore.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnBackup_Restore.Visible = false;
            this.btnBackup_Restore.Click += new System.EventHandler(this.btnBackup_Restore_Click);
            // 
            // toolStripMenuItem_2
            // 
            this.toolStripMenuItem_2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem10,
            this.toolStripMenuItem11,
            this.toolStripMenuItem12});
            this.toolStripMenuItem_2.Name = "toolStripMenuItem_2";
            this.toolStripMenuItem_2.Size = new System.Drawing.Size(314, 24);
            this.toolStripMenuItem_2.Text = "إعدادات الإرسال على البريد الإلكتروني";
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripMenuItem10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem10.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(340, 24);
            this.toolStripMenuItem10.Text = "ضبط إعدادات البريد الإلكتروني المرسل منه";
            this.toolStripMenuItem10.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolStripMenuItem10.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripMenuItem11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem11.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(340, 24);
            this.toolStripMenuItem11.Text = "عناوين البريد الإلكتروني المرسل إليها";
            this.toolStripMenuItem11.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolStripMenuItem11.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem11.Click += new System.EventHandler(this.toolStripMenuItem11_Click);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripMenuItem12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem12.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(340, 24);
            this.toolStripMenuItem12.Text = "إعدادات التقارير المرسلة للبريد الإلكتروني";
            this.toolStripMenuItem12.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolStripMenuItem12.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem12.Click += new System.EventHandler(this.toolStripMenuItem12_Click);
            // 
            // toolStripMenuItem_8
            // 
            this.toolStripMenuItem_8.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem9,
            this.toolStripMenuItem_9,
            this.toolStripMenuItem_10,
            this.toolStripMenuItem_11});
            this.toolStripMenuItem_8.Name = "toolStripMenuItem_8";
            this.toolStripMenuItem_8.Size = new System.Drawing.Size(314, 24);
            this.toolStripMenuItem_8.Text = "إعدادات الإرسال علي الموبايل";
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(333, 24);
            this.toolStripMenuItem9.Text = "إعدادات رسائل SMS";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // toolStripMenuItem_9
            // 
            this.toolStripMenuItem_9.Name = "toolStripMenuItem_9";
            this.toolStripMenuItem_9.Size = new System.Drawing.Size(333, 24);
            this.toolStripMenuItem_9.Text = "أرقام الموبايل المرسل إليها";
            this.toolStripMenuItem_9.Click += new System.EventHandler(this.toolStripMenuItem_9_Click);
            // 
            // toolStripMenuItem_10
            // 
            this.toolStripMenuItem_10.Name = "toolStripMenuItem_10";
            this.toolStripMenuItem_10.Size = new System.Drawing.Size(333, 24);
            this.toolStripMenuItem_10.Text = "إرسال رسائل قصيرة لمجموعة من المرضي";
            this.toolStripMenuItem_10.Click += new System.EventHandler(this.toolStripMenuItem_10_Click);
            // 
            // toolStripMenuItem_11
            // 
            this.toolStripMenuItem_11.Name = "toolStripMenuItem_11";
            this.toolStripMenuItem_11.Size = new System.Drawing.Size(333, 24);
            this.toolStripMenuItem_11.Text = "إعدادات التقارير المرسلة";
            this.toolStripMenuItem_11.Click += new System.EventHandler(this.toolStripMenuItem_11_Click);
            // 
            // toolStripMenuItem_19
            // 
            this.toolStripMenuItem_19.Name = "toolStripMenuItem_19";
            this.toolStripMenuItem_19.Size = new System.Drawing.Size(314, 24);
            this.toolStripMenuItem_19.Text = "تغيير قاعدة البيانات";
            this.toolStripMenuItem_19.Visible = false;
            this.toolStripMenuItem_19.Click += new System.EventHandler(this.toolStripMenuItem_19_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 6000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button14);
            this.panel4.Location = new System.Drawing.Point(172, 175);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(50, 39);
            this.panel4.TabIndex = 68;
            // 
            // button14
            // 
            this.button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button14.Location = new System.Drawing.Point(0, -1);
            this.button14.Margin = new System.Windows.Forms.Padding(0);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(50, 50);
            this.button14.TabIndex = 0;
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.comboBox1);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(0, 175);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(172, 194);
            this.panel3.TabIndex = 67;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(177)))), ((int)(((byte)(235)))));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button3.Location = new System.Drawing.Point(48, 132);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 30);
            this.button3.TabIndex = 69;
            this.button3.Text = "دخول";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_2);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(3, 57);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label8.Size = new System.Drawing.Size(166, 30);
            this.label8.TabIndex = 69;
            this.label8.Text = "اسم المستخدم";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(12, 94);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboBox1.Size = new System.Drawing.Size(145, 21);
            this.comboBox1.TabIndex = 69;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(177)))), ((int)(((byte)(235)))));
            this.label7.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label7.Size = new System.Drawing.Size(172, 39);
            this.label7.TabIndex = 65;
            this.label7.Text = "شات  داخلى";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(177)))), ((int)(((byte)(235)))));
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(2, 158);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label9.Size = new System.Drawing.Size(35, 17);
            this.label9.TabIndex = 69;
            this.label9.Text = "شات";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(34, 158);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(41, 17);
            this.label10.TabIndex = 70;
            this.label10.Text = "0";
            // 
            // timerEmail
            // 
            this.timerEmail.Enabled = true;
            this.timerEmail.Interval = 6000;
            this.timerEmail.Tick += new System.EventHandler(this.timerEmail_Tick);
            // 
            // TrayIcon
            // 
            this.TrayIcon.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.TrayIcon.BalloonTipText = "تم ارسال التقارير على البريد الالكترونى بنجاح";
            this.TrayIcon.BalloonTipTitle = "رسائل البريد الالكترونى";
            this.TrayIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("TrayIcon.Icon")));
            this.TrayIcon.Text = "رسائل البريد الالكترونى";
            // 
            // timerMobile
            // 
            this.timerMobile.Enabled = true;
            this.timerMobile.Interval = 6000;
            this.timerMobile.Tick += new System.EventHandler(this.timerMobile_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 10000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.AutoSize = true;
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel5.Controls.Add(this.panel2);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1386, 788);
            this.panel5.TabIndex = 71;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.vistaButton2);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(0, 680);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1367, 33);
            this.panel2.TabIndex = 60;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold);
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button5.Location = new System.Drawing.Point(116, -1);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(96, 34);
            this.button5.TabIndex = 70;
            this.button5.Text = "إتصل بنا";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click_2);
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button4.Location = new System.Drawing.Point(213, -11);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(120, 46);
            this.button4.TabIndex = 63;
            this.button4.Text = "الدعم الفني";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_2);
            // 
            // vistaButton2
            // 
            this.vistaButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.vistaButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.vistaButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.vistaButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.vistaButton2.FlatAppearance.BorderSize = 0;
            this.vistaButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vistaButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.vistaButton2.ForeColor = System.Drawing.Color.White;
            this.vistaButton2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.vistaButton2.Location = new System.Drawing.Point(2, 0);
            this.vistaButton2.Name = "vistaButton2";
            this.vistaButton2.Size = new System.Drawing.Size(112, 35);
            this.vistaButton2.TabIndex = 37;
            this.vistaButton2.Text = "عن البرنامج";
            this.vistaButton2.UseVisualStyleBackColor = false;
            this.vistaButton2.Click += new System.EventHandler(this.vistaButton2_Click);
            this.vistaButton2.MouseHover += new System.EventHandler(this.vistaButton2_MouseHover);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(177)))), ((int)(((byte)(235)))));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button2.Location = new System.Drawing.Point(1186, -4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(180, 37);
            this.button2.TabIndex = 49;
            this.button2.Text = "عرض الحجوزات على الشاشات";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(789, 6);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(394, 25);
            this.label1.TabIndex = 62;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(507, 5);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(276, 25);
            this.label3.TabIndex = 61;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(336, 5);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label4.Size = new System.Drawing.Size(165, 25);
            this.label4.TabIndex = 61;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.FrmLimitOrderRptBtn);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.TpatientXray);
            this.panel1.Controls.Add(this.tAppointment);
            this.panel1.Controls.Add(this.tAddPatient);
            this.panel1.Controls.Add(this.tPatientPay);
            this.panel1.Controls.Add(this.tPatientAccount);
            this.panel1.Location = new System.Drawing.Point(23, 628);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1321, 49);
            this.panel1.TabIndex = 52;
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.label15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label15.Location = new System.Drawing.Point(130, 6);
            this.label15.Name = "label15";
            this.label15.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label15.Size = new System.Drawing.Size(48, 37);
            this.label15.TabIndex = 71;
            this.label15.Text = "0";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label13.Location = new System.Drawing.Point(257, 6);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label13.Size = new System.Drawing.Size(48, 37);
            this.label13.TabIndex = 69;
            this.label13.Text = "0";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.label14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label14.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(305, 6);
            this.label14.Name = "label14";
            this.label14.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label14.Size = new System.Drawing.Size(66, 37);
            this.label14.TabIndex = 68;
            this.label14.Text = "الكشوفات";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.Click += new System.EventHandler(this.label14_Click_1);
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.label16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label16.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(178, 6);
            this.label16.Name = "label16";
            this.label16.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label16.Size = new System.Drawing.Size(79, 37);
            this.label16.TabIndex = 70;
            this.label16.Text = "إعادة الكشف";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // button6
            // 
            this.button6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.button6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button6.Location = new System.Drawing.Point(986, 6);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(106, 37);
            this.button6.TabIndex = 67;
            this.button6.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click_2);
            this.button6.MouseLeave += new System.EventHandler(this.button6_MouseLeave_1);
            this.button6.MouseHover += new System.EventHandler(this.button6_MouseHover_1);
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label12.Location = new System.Drawing.Point(8, 6);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label12.Size = new System.Drawing.Size(48, 37);
            this.label12.TabIndex = 66;
            this.label12.Text = "0";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.label11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label11.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(56, 6);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label11.Size = new System.Drawing.Size(73, 37);
            this.label11.TabIndex = 65;
            this.label11.Text = "عدد العمليات";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.Click += new System.EventHandler(this.label11_Click_1);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(519, 6);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(44, 37);
            this.label2.TabIndex = 62;
            this.label2.Text = "0";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(371, 6);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(46, 37);
            this.label5.TabIndex = 63;
            this.label5.Text = "0";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmLimitOrderRptBtn
            // 
            this.FrmLimitOrderRptBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.FrmLimitOrderRptBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.FrmLimitOrderRptBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.FrmLimitOrderRptBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FrmLimitOrderRptBtn.FlatAppearance.BorderSize = 0;
            this.FrmLimitOrderRptBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FrmLimitOrderRptBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.FrmLimitOrderRptBtn.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.FrmLimitOrderRptBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.FrmLimitOrderRptBtn.Location = new System.Drawing.Point(563, 6);
            this.FrmLimitOrderRptBtn.Name = "FrmLimitOrderRptBtn";
            this.FrmLimitOrderRptBtn.Size = new System.Drawing.Size(106, 37);
            this.FrmLimitOrderRptBtn.TabIndex = 52;
            this.FrmLimitOrderRptBtn.UseVisualStyleBackColor = false;
            this.FrmLimitOrderRptBtn.Click += new System.EventHandler(this.FrmLimitOrderRptBtn_Click);
            this.FrmLimitOrderRptBtn.MouseLeave += new System.EventHandler(this.FrmLimitOrderRptBtn_MouseLeave);
            this.FrmLimitOrderRptBtn.MouseHover += new System.EventHandler(this.FrmLimitOrderRptBtn_MouseHover);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.label6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label6.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(417, 6);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label6.Size = new System.Drawing.Size(102, 37);
            this.label6.TabIndex = 64;
            this.label6.Text = "مديونيات المرضى";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Click += new System.EventHandler(this.FrmRptPatientDebtBtn_Click);
            // 
            // TpatientXray
            // 
            this.TpatientXray.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.TpatientXray.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.TpatientXray.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.TpatientXray.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TpatientXray.FlatAppearance.BorderSize = 0;
            this.TpatientXray.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TpatientXray.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.TpatientXray.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.TpatientXray.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.TpatientXray.Location = new System.Drawing.Point(775, 6);
            this.TpatientXray.Name = "TpatientXray";
            this.TpatientXray.Size = new System.Drawing.Size(106, 37);
            this.TpatientXray.TabIndex = 50;
            this.TpatientXray.UseVisualStyleBackColor = false;
            this.TpatientXray.Click += new System.EventHandler(this.button5_Click);
            this.TpatientXray.MouseLeave += new System.EventHandler(this.TpatientXray_MouseLeave);
            this.TpatientXray.MouseHover += new System.EventHandler(this.TpatientXray_MouseHover);
            // 
            // tAppointment
            // 
            this.tAppointment.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tAppointment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.tAppointment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tAppointment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tAppointment.FlatAppearance.BorderSize = 0;
            this.tAppointment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tAppointment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.tAppointment.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tAppointment.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tAppointment.Location = new System.Drawing.Point(669, 6);
            this.tAppointment.Name = "tAppointment";
            this.tAppointment.Size = new System.Drawing.Size(106, 37);
            this.tAppointment.TabIndex = 51;
            this.tAppointment.UseVisualStyleBackColor = false;
            this.tAppointment.Click += new System.EventHandler(this.button6_Click);
            this.tAppointment.MouseLeave += new System.EventHandler(this.button6_MouseLeave);
            this.tAppointment.MouseHover += new System.EventHandler(this.button6_MouseHover);
            // 
            // tAddPatient
            // 
            this.tAddPatient.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tAddPatient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.tAddPatient.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tAddPatient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tAddPatient.FlatAppearance.BorderSize = 0;
            this.tAddPatient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tAddPatient.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.tAddPatient.ForeColor = System.Drawing.Color.Black;
            this.tAddPatient.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tAddPatient.Location = new System.Drawing.Point(1198, 6);
            this.tAddPatient.Name = "tAddPatient";
            this.tAddPatient.Size = new System.Drawing.Size(106, 37);
            this.tAddPatient.TabIndex = 47;
            this.tAddPatient.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.tAddPatient.UseVisualStyleBackColor = false;
            this.tAddPatient.Click += new System.EventHandler(this.button2_Click);
            this.tAddPatient.MouseLeave += new System.EventHandler(this.AddPatient_MouseLeave);
            this.tAddPatient.MouseHover += new System.EventHandler(this.AddPatient_MouseHover);
            // 
            // tPatientPay
            // 
            this.tPatientPay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tPatientPay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.tPatientPay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tPatientPay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tPatientPay.FlatAppearance.BorderSize = 0;
            this.tPatientPay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tPatientPay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.tPatientPay.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tPatientPay.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tPatientPay.Location = new System.Drawing.Point(1092, 6);
            this.tPatientPay.Name = "tPatientPay";
            this.tPatientPay.Size = new System.Drawing.Size(106, 37);
            this.tPatientPay.TabIndex = 48;
            this.tPatientPay.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.tPatientPay.UseVisualStyleBackColor = false;
            this.tPatientPay.Click += new System.EventHandler(this.button3_Click);
            this.tPatientPay.MouseLeave += new System.EventHandler(this.button3_MouseLeave);
            this.tPatientPay.MouseHover += new System.EventHandler(this.button3_MouseHover);
            // 
            // tPatientAccount
            // 
            this.tPatientAccount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tPatientAccount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(221)))), ((int)(((byte)(247)))));
            this.tPatientAccount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tPatientAccount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tPatientAccount.FlatAppearance.BorderSize = 0;
            this.tPatientAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tPatientAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.tPatientAccount.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tPatientAccount.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tPatientAccount.Location = new System.Drawing.Point(881, 6);
            this.tPatientAccount.Name = "tPatientAccount";
            this.tPatientAccount.Size = new System.Drawing.Size(106, 37);
            this.tPatientAccount.TabIndex = 49;
            this.tPatientAccount.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.tPatientAccount.UseVisualStyleBackColor = false;
            this.tPatientAccount.Click += new System.EventHandler(this.button4_Click);
            this.tPatientAccount.MouseLeave += new System.EventHandler(this.tPatientAccount_MouseLeave);
            this.tPatientAccount.MouseHover += new System.EventHandler(this.tPatientAccount_MouseHover);
            // 
            // toolStripMenuItem_0
            // 
            this.toolStripMenuItem_0.BackColor = System.Drawing.Color.Transparent;
            this.toolStripMenuItem_0.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripMenuItem_0.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem_0.Name = "toolStripMenuItem_0";
            this.toolStripMenuItem_0.Size = new System.Drawing.Size(269, 42);
            this.toolStripMenuItem_0.Text = "عه";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(234)))), ((int)(((byte)(252)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1284, 717);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panelappointment);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel5);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.Main_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Main_FormClosed);
            this.Load += new System.EventHandler(this.Main_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Main1_KeyDown);
            this.MouseHover += new System.EventHandler(this.Main_MouseHover);
            this.panelappointment.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		public Main()
		{
			InitializeComponent();
			try
			{
				panel5.BackgroundImage = Image.FromFile(DentistClinic.Properties.Settings.Default.backImage);
			}
			catch
			{
			}
			dc = new ClassDataBase(".\\sqlExpress");
			Codes = new dataClass(".\\sqlExpress");
			menuStrip1.Renderer = new BlueRenderer();
		}

		[DllImport("user32")]
		public static extern long SetWindowPos(IntPtr hwnd, int hWndInsertAfter, int X, int y, int cx, int cy, int wFlagslong);

		[DllImport("user32.dll")]
		public static extern int GetWindowLong(IntPtr hwnd, int nIndex);

		[DllImport("user32.dll")]
		public static extern int SetWindowLong(IntPtr hwnd, int nIndex, int dwNewLong);

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			if (Screen.AllScreens.Length > 1)
			{
				FrmTestMonitor frmTestMonitor = new FrmTestMonitor();
				frmTestMonitor.StartPosition = FormStartPosition.Manual;
				Screen secondaryScreen = GetSecondaryScreen();
				frmTestMonitor.Location = secondaryScreen.WorkingArea.Location;
				frmTestMonitor.Size = new Size(secondaryScreen.WorkingArea.Width, secondaryScreen.WorkingArea.Height);
			}
		}

		public Screen GetSecondaryScreen()
		{
			if (Screen.AllScreens.Length == 1)
			{
				return null;
			}
			Screen[] allScreens = Screen.AllScreens;
			int num = 0;
			Screen screen;
			while (true)
			{
				if (num < allScreens.Length)
				{
					screen = allScreens[num];
					if (!screen.Primary)
					{
						break;
					}
					num++;
					continue;
				}
				return null;
			}
			return screen;
		}

		public void PassValue()
		{
			DataTable dataTable = Codes.Search2("SELECT     isnull(count(dbo.Items.Id),0)\r\nFROM         dbo.Items INNER JOIN\r\n                      dbo.Store ON dbo.Items.Id = dbo.Store.ItemId\r\nwhere dbo.Store.Qnt <= dbo.Items.LimitOrder");
			if (dataTable.Rows.Count > 0)
			{
				label2.Text = dataTable.Rows[0][0].ToString();
			}
			else
			{
				label2.Text = "0";
			}
		}

		public void DisplayButtons()
		{
			try
			{
				DataTable tableText = dc.GetTableText("select ClinicType,NaturalClinic from DentalData ");
				if (Convert.ToBoolean(tableText.Rows[0][0].ToString()))
				{
					RptTaqweem.Visible = true;
				}
				else
				{
					RptTaqweem.Visible = false;
				}
				if (!Convert.ToBoolean(tableText.Rows[0][1].ToString()))
				{
					FrmInoculationBtn.Visible = false;
					FrmPatientInoculationBtn.Visible = false;
				}
			}
			catch
			{
			}
		}

		private void Main1_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
		{
		}

		private void tAppointment_Click(object sender, EventArgs e)
		{
			Appointments appointments = new Appointments();
			appointments.Show();
		}

		private void addEmployeeBtn_Click_1(object sender, EventArgs e)
		{
			EmpData empData = new EmpData();
			empData.Show();
		}

		private void AddPatientBtn_Click_1(object sender, EventArgs e)
		{
			PationtInfo pationtInfo = new PationtInfo(0);
			pationtInfo.Show();
		}

		private void searchPatientBtn_Click_1(object sender, EventArgs e)
		{
			FmSearchPatient fmSearchPatient = new FmSearchPatient();
			fmSearchPatient.Show();
		}

		private void CompanyBtn_Click_1(object sender, EventArgs e)
		{
			Company company = new Company();
			company.Show();
		}

		private void PatintPayBtn_Click_1(object sender, EventArgs e)
		{
			PatientPayAccount patientPayAccount = new PatientPayAccount(0);
			patientPayAccount.Show();
		}

		private void PatientAcountBtn_Click_1(object sender, EventArgs e)
		{
			PatientAccountSecretaryFrm patientAccountSecretaryFrm = new PatientAccountSecretaryFrm();
			patientAccountSecretaryFrm.Show();
		}

		private void XrayBtn_Click_1(object sender, EventArgs e)
		{
			FrmImage frmImage = new FrmImage(0);
			frmImage.Show();
		}

		private void appointmentBtn_Click_2(object sender, EventArgs e)
		{
			Appointments appointments = new Appointments();
			appointments.Show();
		}

		private void editReBackDateBtn_Click_1(object sender, EventArgs e)
		{
			FrmUpdateRebackdate frmUpdateRebackdate = new FrmUpdateRebackdate();
			frmUpdateRebackdate.Show();
		}

		private void PatientListBtn_Click_2(object sender, EventArgs e)
		{
			DoctorReserve doctorReserve = new DoctorReserve();
			doctorReserve.Show();
		}

		private void PackPatientListBtn_Click_1(object sender, EventArgs e)
		{
			DoctorBackReserve doctorBackReserve = new DoctorBackReserve();
			doctorBackReserve.Show();
		}

		private void secretPatientList_Click_2(object sender, EventArgs e)
		{
			SecretaryReserve secretaryReserve = new SecretaryReserve();
			secretaryReserve.Show();
		}

		private void secretRebackPatientList_Click_1(object sender, EventArgs e)
		{
			SecretaryBackReserve secretaryBackReserve = new SecretaryBackReserve();
			secretaryBackReserve.Show();
		}

		private void expensesToolStripMenuItem_Click_1(object sender, EventArgs e)
		{
			FrmExpenses frmExpenses = new FrmExpenses();
			frmExpenses.Show();
		}

		private void revenuesToolStripMenuItem_Click_1(object sender, EventArgs e)
		{
			FrmRevenues frmRevenues = new FrmRevenues();
			frmRevenues.Show();
		}

		private void doctorAcountBtn_Click_2(object sender, EventArgs e)
		{
			DoctorAccount doctorAccount = new DoctorAccount();
			doctorAccount.Show();
		}

		private void PatientAccountRptBtn_Click_1(object sender, EventArgs e)
		{
			FrmPatientAcountbyDateRpt frmPatientAcountbyDateRpt = new FrmPatientAcountbyDateRpt();
			frmPatientAcountbyDateRpt.Show();
		}

		private void AllPatientAccountBtn_Click_1(object sender, EventArgs e)
		{
			frmAllPatientAcount frmAllPatientAcount2 = new frmAllPatientAcount();
			frmAllPatientAcount2.Show();
		}

		private void DoctorAcountRptBtn_Click_1(object sender, EventArgs e)
		{
			FrmDoctorAcountByDate frmDoctorAcountByDate = new FrmDoctorAcountByDate();
			frmDoctorAcountByDate.Show();
		}

		private void DoctorPaymentBtn_Click_1(object sender, EventArgs e)
		{
			FrmDoctorPayment frmDoctorPayment = new FrmDoctorPayment();
			frmDoctorPayment.Show();
		}

		private void MovementOfPatientStatmentBtn_Click_1(object sender, EventArgs e)
		{
			FrmMovementOfPatientStatment frmMovementOfPatientStatment = new FrmMovementOfPatientStatment();
			frmMovementOfPatientStatment.Show();
		}

		private void MovementOfPatByDr_Click_1(object sender, EventArgs e)
		{
			FrmMovementOfPatientByDoctorName frmMovementOfPatientByDoctorName = new FrmMovementOfPatientByDoctorName();
			frmMovementOfPatientByDoctorName.Show();
		}

		private void expensesToolStripMenuItem1_Click_1(object sender, EventArgs e)
		{
			FrmRptExpenses frmRptExpenses = new FrmRptExpenses();
			frmRptExpenses.Show();
		}

		private void revenuesToolStripMenuItem1_Click_1(object sender, EventArgs e)
		{
			frmrptrevenues frmrptrevenues2 = new frmrptrevenues();
			frmrptrevenues2.Show();
		}

		private void dailyClinicToolStripMenuItem_Click_1(object sender, EventArgs e)
		{
			FrmRptStockMove frmRptStockMove = new FrmRptStockMove();
			frmRptStockMove.Show();
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			Brush brush = new LinearGradientBrush(new Rectangle(0, 0, base.Width, base.Height), Color.Gray, Color.LightGray, 45f);
			graphics.FillRectangle(brush, 0, 0, base.Width, base.Height);
		}

		private void tAddPatient_Click(object sender, EventArgs e)
		{
			PationtInfo pationtInfo = new PationtInfo(0);
			pationtInfo.Show();
		}

		private void tPatientPay_Click(object sender, EventArgs e)
		{
			PatientPayAccount patientPayAccount = new PatientPayAccount(0);
			patientPayAccount.Show();
		}

		private void tPatientAccount_Click(object sender, EventArgs e)
		{
			PatientAccountFrm patientAccountFrm = new PatientAccountFrm();
			patientAccountFrm.Show();
		}

		private void TpatientXray_Click(object sender, EventArgs e)
		{
			FrmImage frmImage = new FrmImage(0);
			frmImage.Show();
		}

		private void medicineFrmBtn_Click(object sender, EventArgs e)
		{
			medicineFrm medicineFrm2 = new medicineFrm();
			medicineFrm2.Show();
		}

		private void PrescriptionFrmBtn_Click(object sender, EventArgs e)
		{
			PrescriptionFrm prescriptionFrm = new PrescriptionFrm(0);
			prescriptionFrm.Show();
		}

		private void SupplierBtn_Click(object sender, EventArgs e)
		{
			Supplier supplier = new Supplier();
			supplier.Show();
		}

		private void ItemsFrmBtn_Click(object sender, EventArgs e)
		{
			ItemsFrm itemsFrm = new ItemsFrm();
			itemsFrm.Show();
		}

		private void OldServicesRptFrmBtn_Click(object sender, EventArgs e)
		{
			OldServicesRptFrm oldServicesRptFrm = new OldServicesRptFrm();
			oldServicesRptFrm.Show();
		}

		private void NetDailyClinicRptFrmBtn_Click(object sender, EventArgs e)
		{
			NetDailyClinicRptFrm netDailyClinicRptFrm = new NetDailyClinicRptFrm();
			netDailyClinicRptFrm.Show();
		}

		private void ClinicMonthGraphRptFrmBtn_Click(object sender, EventArgs e)
		{
			ClinicMonthGraphRptFrm clinicMonthGraphRptFrm = new ClinicMonthGraphRptFrm();
			clinicMonthGraphRptFrm.Show();
		}

		private void DailymeasureRotFrmBtn_Click(object sender, EventArgs e)
		{
			DailymeasureRotFrm dailymeasureRotFrm = new DailymeasureRotFrm();
			dailymeasureRotFrm.Show();
		}

		private void vistaButton1_Click_2(object sender, EventArgs e)
		{
			FrmTotalDoctorAccount frmTotalDoctorAccount = new FrmTotalDoctorAccount();
			frmTotalDoctorAccount.Show();
		}

		private void CompanyService_Click(object sender, EventArgs e)
		{
			FrmCompaniesServicesPrices frmCompaniesServicesPrices = new FrmCompaniesServicesPrices();
			frmCompaniesServicesPrices.Show();
		}

		private void vistaButton2_Click(object sender, EventArgs e)
		{
			FrmSplash frmSplash = new FrmSplash();
			frmSplash.Show();
		}

		private void RptTaqweem_Click(object sender, EventArgs e)
		{
			FrmRptTaqweem frmRptTaqweem = new FrmRptTaqweem();
			frmRptTaqweem.Show();
		}

		private void FrmSearchMedicine_Click(object sender, EventArgs e)
		{
			FrmSearchMedicine frmSearchMedicine = new FrmSearchMedicine();
			frmSearchMedicine.Show();
		}

		private void ServicePatientBtn_Click(object sender, EventArgs e)
		{
			FrmServicePatient frmServicePatient = new FrmServicePatient();
			frmServicePatient.Show();
		}

		private void MainComplaintBtn_Click(object sender, EventArgs e)
		{
			FrmMainComplaint frmMainComplaint = new FrmMainComplaint();
			frmMainComplaint.Show();
		}

		private void FrmRptSahbItemBtn_Click(object sender, EventArgs e)
		{
			FrmRptSahbItem frmRptSahbItem = new FrmRptSahbItem();
			frmRptSahbItem.Show();
		}

		private void FrmFilePatientBtn_Click(object sender, EventArgs e)
		{
			FrmFilePatient frmFilePatient = new FrmFilePatient("");
			frmFilePatient.Show();
		}

		private void AppointmentListBtn_Click(object sender, EventArgs e)
		{
		}

		private void tAddPatient_MouseHover(object sender, EventArgs e)
		{
			tAddPatient.BackgroundImage = Resources._4_071;
			tAddPatient.Image = Resources._4_071;
		}

		private void addEmployeeBtn_MouseHover(object sender, EventArgs e)
		{
		}

		private void addEmployeeBtn_MouseLeave(object sender, EventArgs e)
		{
		}

		private void IncomingBillFrmBtn_MouseHover(object sender, EventArgs e)
		{
			IncomingBillFrmBtn.BackgroundImage = Resources.easy_clinic_design_251;
		}

		private void IncomingBillFrmBtn_MouseLeave(object sender, EventArgs e)
		{
			IncomingBillFrmBtn.BackgroundImage = Resources.easy_clinic_design_25;
		}

		private void FrmSupplierAccountsBtn_MouseHover(object sender, EventArgs e)
		{
			FrmSupplierAccountsBtn.BackgroundImage = Resources.easy_clinic_design_371;
		}

		private void FrmSupplierAccountsBtn_MouseLeave(object sender, EventArgs e)
		{
			FrmSupplierAccountsBtn.BackgroundImage = Resources.easy_clinic_design_37;
		}

		private void FormSupplier5Btn_MouseHover(object sender, EventArgs e)
		{
			FormSupplier5Btn.BackgroundImage = Resources.easy_clinic_design_442;
		}

		private void FormSupplier5Btn_MouseLeave(object sender, EventArgs e)
		{
			FormSupplier5Btn.BackgroundImage = Resources.easy_clinic_design_441;
		}

		private void FrmBillIncomeRptBtn_MouseHover(object sender, EventArgs e)
		{
			FrmBillIncomeRptBtn.BackgroundImage = Resources.easy_clinic_design_511;
		}

		private void FrmBillIncomeRptBtn_MouseLeave(object sender, EventArgs e)
		{
			FrmBillIncomeRptBtn.BackgroundImage = Resources.easy_clinic_design_51;
		}

		private void SahbItemsBtn_MouseHover(object sender, EventArgs e)
		{
			SahbItemsBtn.BackgroundImage = Resources.easy_clinic_design_551;
		}

		private void SahbItemsBtn_MouseLeave(object sender, EventArgs e)
		{
			SahbItemsBtn.BackgroundImage = Resources.easy_clinic_design_55;
		}

		private void FrmRptBillByDateBtn_MouseHover(object sender, EventArgs e)
		{
			FrmRptBillByDateBtn.BackgroundImage = Resources.easy_clinic_design_581;
		}

		private void FrmRptBillByDateBtn_MouseLeave(object sender, EventArgs e)
		{
			FrmRptBillByDateBtn.BackgroundImage = Resources.easy_clinic_design_58;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			PationtInfo pationtInfo = new PationtInfo(0);
			pationtInfo.Show();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			PatientPayAccount patientPayAccount = new PatientPayAccount(0);
			patientPayAccount.Show();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			PatientAccountSecretaryFrm patientAccountSecretaryFrm = new PatientAccountSecretaryFrm();
			patientAccountSecretaryFrm.Show();
		}

		private void button5_Click(object sender, EventArgs e)
		{
			FrmImage frmImage = new FrmImage(0);
			frmImage.Show();
		}

		private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
		{
		}

		private void button6_Click(object sender, EventArgs e)
		{
			Appointments appointments = new Appointments();
			appointments.Show();
		}

		private void AddPatient_MouseHover(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				tAddPatient.BackgroundImage = Resources.a91;
			}
			else
			{
				tAddPatient.BackgroundImage = Resources._4_071;
			}
		}

		private void AddPatient_MouseLeave(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				tAddPatient.BackgroundImage = Resources.a9;
			}
			else
			{
				tAddPatient.BackgroundImage = Resources._3_071;
			}
		}

		private void button3_MouseHover(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				tPatientPay.BackgroundImage = Resources.a101;
			}
			else
			{
				tPatientPay.BackgroundImage = Resources._4_06;
			}
		}

		private void tPatientAccount_MouseHover(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				tPatientAccount.BackgroundImage = Resources.a1111;
			}
			else
			{
				tPatientAccount.BackgroundImage = Resources._4_052;
			}
		}

		private void tPatientAccount_MouseLeave(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				tPatientAccount.BackgroundImage = Resources.a111;
			}
			else
			{
				tPatientAccount.BackgroundImage = Resources._3_051;
			}
		}

		private void TpatientXray_MouseHover(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				TpatientXray.BackgroundImage = Resources.a121;
			}
			else
			{
				TpatientXray.BackgroundImage = Resources._4_04;
			}
		}

		private void TpatientXray_MouseLeave(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				TpatientXray.BackgroundImage = Resources.a12;
			}
			else
			{
				TpatientXray.BackgroundImage = Resources._3_04;
			}
		}

		private void button6_MouseHover(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				tAppointment.BackgroundImage = Resources.a131;
			}
			else
			{
				tAppointment.BackgroundImage = Resources._4_03;
			}
		}

		private void button6_MouseLeave(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				tAppointment.BackgroundImage = Resources.a13;
			}
			else
			{
				tAppointment.BackgroundImage = Resources._3_03;
			}
		}

		private void button3_MouseLeave(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				tPatientPay.BackgroundImage = Resources.a10;
			}
			else
			{
				tPatientPay.BackgroundImage = Resources._3_06;
			}
		}

		private void button2_Click_1(object sender, EventArgs e)
		{
			FrmSurgery frmSurgery = new FrmSurgery();
			frmSurgery.Show();
		}

		private void button3_Click_1(object sender, EventArgs e)
		{
			FrmPatientSurgery frmPatientSurgery = new FrmPatientSurgery();
			frmPatientSurgery.Show();
		}

		private void button4_Click_1(object sender, EventArgs e)
		{
			FrmBookingVisits frmBookingVisits = new FrmBookingVisits();
			frmBookingVisits.Show();
		}

		private void button5_Click_1(object sender, EventArgs e)
		{
			FrmSecretaryVisits frmSecretaryVisits = new FrmSecretaryVisits();
			frmSecretaryVisits.Show();
		}

		private void button6_Click_1(object sender, EventArgs e)
		{
			DoctorReserveVisits doctorReserveVisits = new DoctorReserveVisits();
			doctorReserveVisits.Show();
		}

		private void button7_Click(object sender, EventArgs e)
		{
			FrmRptVisits frmRptVisits = new FrmRptVisits();
			frmRptVisits.Show();
		}

		private void Surgery_Click(object sender, EventArgs e)
		{
			FrmSurgery frmSurgery = new FrmSurgery();
			frmSurgery.Show();
		}

		private void PatientSurgery_Click(object sender, EventArgs e)
		{
			FrmPatientSurgery frmPatientSurgery = new FrmPatientSurgery();
			frmPatientSurgery.Show();
		}

		private void BookingVisits_Click(object sender, EventArgs e)
		{
			FrmBookingVisits frmBookingVisits = new FrmBookingVisits();
			frmBookingVisits.Show();
		}

		private void SecretaryVisits_Click(object sender, EventArgs e)
		{
			FrmSecretaryVisits frmSecretaryVisits = new FrmSecretaryVisits();
			frmSecretaryVisits.Show();
		}

		private void DoctorVisits_Click(object sender, EventArgs e)
		{
			DoctorReserveVisits doctorReserveVisits = new DoctorReserveVisits();
			doctorReserveVisits.Show();
		}

		private void RptVisits_Click(object sender, EventArgs e)
		{
			FrmRptVisits frmRptVisits = new FrmRptVisits();
			frmRptVisits.Show();
		}

		private void BtnFrmSell_MouseHover(object sender, EventArgs e)
		{
		}

		private void BtnFrmSell_MouseLeave(object sender, EventArgs e)
		{
			BtnFrmSell.BackgroundImage = Resources.easy_clinic_design2_03;
		}

		private void BtnFrmRptReb7ya_Click(object sender, EventArgs e)
		{
			FrmRptReb7ya frmRptReb7ya = new FrmRptReb7ya();
			frmRptReb7ya.Show();
		}

		private void BtnFrmRptCompanies_Services_Click(object sender, EventArgs e)
		{
			FrmRptCompanies_Services frmRptCompanies_Services = new FrmRptCompanies_Services();
			frmRptCompanies_Services.Show();
		}

		private void BtnFrmRptCompanies_Services_MouseLeave(object sender, EventArgs e)
		{
		}

		private void FrmRptSellByDateBtn_MouseLeave(object sender, EventArgs e)
		{
			FrmRptSellByDateBtn.BackgroundImage = Resources.easy_clinic_design2_01_06;
		}

		private void FrmRptSellByDateBtn_MouseHover(object sender, EventArgs e)
		{
			FrmRptSellByDateBtn.BackgroundImage = Resources.easy_clinic_design_01_061;
		}

		private void PatientAccountUpdateBtn_Click(object sender, EventArgs e)
		{
			PatientPayAccountUpdate patientPayAccountUpdate = new PatientPayAccountUpdate(0);
			patientPayAccountUpdate.Show();
		}

		private void PatientServiceUpdateBtn_Click(object sender, EventArgs e)
		{
			PatientServiceUpdate patientServiceUpdate = new PatientServiceUpdate();
			patientServiceUpdate.Show();
		}

		private void FrmInventoryRptBtn_Click(object sender, EventArgs e)
		{
			FrmInventoryRpt frmInventoryRpt = new FrmInventoryRpt();
			frmInventoryRpt.Show();
		}

		private void FrmLimitOrderRptBtn_MouseLeave(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				FrmLimitOrderRptBtn.BackgroundImage = Resources.a14;
			}
			else
			{
				FrmLimitOrderRptBtn.BackgroundImage = Resources.C3_031;
			}
		}

		private void FrmLimitOrderRptBtn_MouseHover(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				FrmLimitOrderRptBtn.BackgroundImage = Resources.a141;
			}
			else
			{
				FrmLimitOrderRptBtn.BackgroundImage = Resources._3_033;
			}
		}

		private void FrmLimitOrderRptBtn_Click(object sender, EventArgs e)
		{
			FrmLimitOrderRpt frmLimitOrderRpt = new FrmLimitOrderRpt();
			frmLimitOrderRpt.Show();
		}

		private void button3_MouseHover_1(object sender, EventArgs e)
		{
		}

		private void button2_MouseLeave(object sender, EventArgs e)
		{
		}

		private void vistaButton2_MouseHover(object sender, EventArgs e)
		{
		}

		private void toolStripMenuItem1_MouseHover(object sender, EventArgs e)
		{
		}

		private void toolStripMenuItem1_MouseLeave(object sender, EventArgs e)
		{
		}

		private void AddPatientBtn_Click(object sender, EventArgs e)
		{
			PationtInfo pationtInfo = new PationtInfo(0);
			pationtInfo.Show();
		}

		private void searchPatientBtn_Click(object sender, EventArgs e)
		{
			FmSearchPatient fmSearchPatient = new FmSearchPatient();
			fmSearchPatient.Show();
		}

		private void CompanyBtn_Click(object sender, EventArgs e)
		{
			Company company = new Company();
			company.Show();
		}

		private void CompanyService_Click_1(object sender, EventArgs e)
		{
			FrmCompaniesServicesPrices frmCompaniesServicesPrices = new FrmCompaniesServicesPrices();
			frmCompaniesServicesPrices.Show();
		}

		private void PatintPayBtn_Click(object sender, EventArgs e)
		{
			PatientPayAccount patientPayAccount = new PatientPayAccount(0);
			patientPayAccount.Show();
		}

		private void PatientAcountBtn_Click(object sender, EventArgs e)
		{
			PatientAccountSecretaryFrm patientAccountSecretaryFrm = new PatientAccountSecretaryFrm();
			patientAccountSecretaryFrm.Show();
		}

		private void XrayBtn_Click(object sender, EventArgs e)
		{
			FrmImage frmImage = new FrmImage(0);
			frmImage.Show();
		}

		private void ServicePatientBtn_Click_1(object sender, EventArgs e)
		{
			FrmServicePatient frmServicePatient = new FrmServicePatient();
			frmServicePatient.Show();
		}

		private void MainComplaintBtn_Click_1(object sender, EventArgs e)
		{
			FrmMainComplaint frmMainComplaint = new FrmMainComplaint();
			frmMainComplaint.Show();
		}

		private void FrmFilePatientBtn_Click_1(object sender, EventArgs e)
		{
			FrmFilePatient frmFilePatient = new FrmFilePatient("");
			frmFilePatient.Show();
		}

		private void Surgery_Click_1(object sender, EventArgs e)
		{
			FrmSurgery frmSurgery = new FrmSurgery();
			frmSurgery.Show();
		}

		private void PatientAccountUpdateBtn_Click_1(object sender, EventArgs e)
		{
			DataTable tableText = dc.GetTableText("select Status from UserStock where UserId =" + userId);
			if (tableText.Rows.Count <= 0)
			{
				if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("No Stock added for this user");
				}
				else
				{
					MessageBox.Show("لم يتم أضافة خزينة لهذا المستخدم");
				}
			}
			else
			{
				if (tableText.Rows.Count <= 0)
				{
					return;
				}
				int num = 0;
				while (true)
				{
					if (num < tableText.Rows.Count)
					{
						if (Convert.ToBoolean(tableText.Rows[num]["Status"].ToString()))
						{
							break;
						}
						num++;
						continue;
					}
					if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("No Stock added for this user");
					}
					else
					{
						MessageBox.Show("لم يتم أضافة خزينة لهذا المستخدم");
					}
					return;
				}
				PatientPayAccountUpdate patientPayAccountUpdate = new PatientPayAccountUpdate(0);
				patientPayAccountUpdate.Show();
			}
		}

		private void PatientServiceUpdateBtn_Click_1(object sender, EventArgs e)
		{
			PatientServiceUpdate patientServiceUpdate = new PatientServiceUpdate();
			patientServiceUpdate.Show();
		}

		private void appointmentBtn_Click(object sender, EventArgs e)
		{
			Appointments appointments = new Appointments();
			appointments.Show();
		}

		private void editReBackDateBtn_Click(object sender, EventArgs e)
		{
			FrmUpdateRebackdate frmUpdateRebackdate = new FrmUpdateRebackdate();
			frmUpdateRebackdate.Show();
		}

		private void secretPatientList_Click(object sender, EventArgs e)
		{
			SecretaryReserve secretaryReserve = new SecretaryReserve();
			secretaryReserve.Show();
		}

		private void secretRebackPatientList_Click(object sender, EventArgs e)
		{
			SecretaryBackReserve secretaryBackReserve = new SecretaryBackReserve();
			secretaryBackReserve.Show();
		}

		private void BookingVisits_Click_1(object sender, EventArgs e)
		{
			FrmBookingVisits frmBookingVisits = new FrmBookingVisits();
			frmBookingVisits.Show();
		}

		private void SecretaryVisits_Click_1(object sender, EventArgs e)
		{
			FrmSecretaryVisits frmSecretaryVisits = new FrmSecretaryVisits();
			frmSecretaryVisits.Show();
		}

		private void RptVisits_Click_1(object sender, EventArgs e)
		{
			FrmRptVisits frmRptVisits = new FrmRptVisits();
			frmRptVisits.Show();
		}

		private void PatientListBtn_Click(object sender, EventArgs e)
		{
			DoctorReserve doctorReserve = new DoctorReserve();
			doctorReserve.Show();
		}

		private void PackPatientListBtn_Click(object sender, EventArgs e)
		{
			DoctorBackReserve doctorBackReserve = new DoctorBackReserve();
			doctorBackReserve.Show();
		}

		private void medicineFrmBtn_Click_1(object sender, EventArgs e)
		{
			medicineFrm medicineFrm2 = new medicineFrm();
			medicineFrm2.Show();
		}

		private void PrescriptionFrmBtn_Click_1(object sender, EventArgs e)
		{
			PrescriptionFrm prescriptionFrm = new PrescriptionFrm(0);
			prescriptionFrm.Show();
		}

		private void DoctorVisits_Click_1(object sender, EventArgs e)
		{
			DoctorReserveVisits doctorReserveVisits = new DoctorReserveVisits();
			doctorReserveVisits.Show();
		}

		private void PatientSurgery_Click_1(object sender, EventArgs e)
		{
			FrmPatientSurgery frmPatientSurgery = new FrmPatientSurgery();
			frmPatientSurgery.Show();
		}

		private void expensesToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FrmExpenses frmExpenses = new FrmExpenses();
			frmExpenses.Show();
		}

		private void revenuesToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FrmRevenues frmRevenues = new FrmRevenues();
			frmRevenues.Show();
		}

		private void doctorAcountBtn_Click(object sender, EventArgs e)
		{
			DoctorAccount doctorAccount = new DoctorAccount();
			doctorAccount.Show();
		}

		private void PatientAccountRptBtn_Click(object sender, EventArgs e)
		{
			FrmPatientAcountbyDateRpt frmPatientAcountbyDateRpt = new FrmPatientAcountbyDateRpt();
			frmPatientAcountbyDateRpt.Show();
		}

		private void AllPatientAccountBtn_Click(object sender, EventArgs e)
		{
			frmAllPatientAcount frmAllPatientAcount2 = new frmAllPatientAcount();
			frmAllPatientAcount2.Show();
		}

		private void MovementOfPatientStatmentBtn_Click(object sender, EventArgs e)
		{
			FrmMovementOfPatientStatment frmMovementOfPatientStatment = new FrmMovementOfPatientStatment();
			frmMovementOfPatientStatment.Show();
		}

		private void OldServicesRptFrmBtn_Click_1(object sender, EventArgs e)
		{
			OldServicesRptFrm oldServicesRptFrm = new OldServicesRptFrm();
			oldServicesRptFrm.Show();
		}

		private void RptTaqweem_Click_1(object sender, EventArgs e)
		{
			FrmRptTaqweem frmRptTaqweem = new FrmRptTaqweem();
			frmRptTaqweem.Show();
		}

		private void DoctorAcountRptBtn_Click(object sender, EventArgs e)
		{
			FrmDoctorAcountByDate frmDoctorAcountByDate = new FrmDoctorAcountByDate();
			frmDoctorAcountByDate.Show();
		}

		private void DoctorPaymentBtn_Click(object sender, EventArgs e)
		{
			FrmDoctorPayment frmDoctorPayment = new FrmDoctorPayment();
			frmDoctorPayment.Show();
		}

		private void MovementOfPatByDr_Click(object sender, EventArgs e)
		{
			FrmMovementOfPatientByDoctorName frmMovementOfPatientByDoctorName = new FrmMovementOfPatientByDoctorName();
			frmMovementOfPatientByDoctorName.Show();
		}

		private void expensesToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			FrmRptExpenses frmRptExpenses = new FrmRptExpenses();
			frmRptExpenses.Show();
		}

		private void revenuesToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			frmrptrevenues frmrptrevenues2 = new frmrptrevenues();
			frmrptrevenues2.Show();
		}

		private void dailyClinicToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FrmRptStockMove frmRptStockMove = new FrmRptStockMove();
			frmRptStockMove.Show();
		}

		private void NetDailyClinicRptFrmBtn_Click_1(object sender, EventArgs e)
		{
			NetDailyClinicRptFrm netDailyClinicRptFrm = new NetDailyClinicRptFrm();
			netDailyClinicRptFrm.Show();
		}

		private void ClinicMonthGraphRptFrmBtn_Click_1(object sender, EventArgs e)
		{
			ClinicMonthGraphRptFrm clinicMonthGraphRptFrm = new ClinicMonthGraphRptFrm();
			clinicMonthGraphRptFrm.Show();
		}

		private void DailymeasureRotFrmBtn_Click_1(object sender, EventArgs e)
		{
			DailymeasureRotFrm dailymeasureRotFrm = new DailymeasureRotFrm();
			dailymeasureRotFrm.Show();
		}

		private void BtnFrmRptReb7ya_Click_1(object sender, EventArgs e)
		{
			FrmRptReb7ya frmRptReb7ya = new FrmRptReb7ya();
			frmRptReb7ya.Show();
		}

		private void FrmInventoryRptBtn_Click_1(object sender, EventArgs e)
		{
			FrmInventoryRpt frmInventoryRpt = new FrmInventoryRpt();
			frmInventoryRpt.Show();
		}

		private void FrmSearchMedicine_Click_1(object sender, EventArgs e)
		{
			FrmSearchMedicine frmSearchMedicine = new FrmSearchMedicine();
			frmSearchMedicine.Show();
		}

		private void FrmRptSahbItemBtn_Click_1(object sender, EventArgs e)
		{
			FrmRptSahbItem frmRptSahbItem = new FrmRptSahbItem();
			frmRptSahbItem.Show();
		}

		private void BtnFrmRptCompanies_Services_Click_1(object sender, EventArgs e)
		{
			FrmRptCompanies_Services frmRptCompanies_Services = new FrmRptCompanies_Services();
			frmRptCompanies_Services.Show();
		}

		private void addEmployeeBtn_Click(object sender, EventArgs e)
		{
			EmpData empData = new EmpData();
			empData.Show();
		}

		private void PatientAcountBtn_Click_2(object sender, EventArgs e)
		{
			PatientAccountSecretaryFrm patientAccountSecretaryFrm = new PatientAccountSecretaryFrm();
			patientAccountSecretaryFrm.Show();
		}

		private void XrayBtn_Click_2(object sender, EventArgs e)
		{
			FrmImage frmImage = new FrmImage(0);
			frmImage.Show();
		}

		private void AddPatientBtn_Click_2(object sender, EventArgs e)
		{
			PationtInfo pationtInfo = new PationtInfo(0);
			pationtInfo.Show();
		}

		private void searchPatientBtn_Click_2(object sender, EventArgs e)
		{
			FmSearchPatient fmSearchPatient = new FmSearchPatient();
			fmSearchPatient.Show();
		}

		private void CompanyBtn_Click_2(object sender, EventArgs e)
		{
			Company company = new Company();
			company.Show();
		}

		private void CompanyService_Click_2(object sender, EventArgs e)
		{
			FrmCompaniesServicesPrices frmCompaniesServicesPrices = new FrmCompaniesServicesPrices();
			frmCompaniesServicesPrices.Show();
		}

		private void PatintPayBtn_Click_2(object sender, EventArgs e)
		{
			DataTable tableText = dc.GetTableText("select Status from UserStock where UserId =" + userId);
			if (tableText.Rows.Count <= 0)
			{
				if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("No Stock added for this user");
				}
				else
				{
					MessageBox.Show("لم يتم أضافة خزينة لهذا المستخدم");
				}
			}
			else
			{
				if (tableText.Rows.Count <= 0)
				{
					return;
				}
				int num = 0;
				while (true)
				{
					if (num < tableText.Rows.Count)
					{
						if (Convert.ToBoolean(tableText.Rows[num]["Status"].ToString()))
						{
							break;
						}
						num++;
						continue;
					}
					if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("No Stock added for this user");
					}
					else
					{
						MessageBox.Show("لم يتم أضافة خزينة لهذا المستخدم");
					}
					return;
				}
				PatientPayAccount patientPayAccount = new PatientPayAccount(0);
				patientPayAccount.Show();
			}
		}

		private void ServicePatientBtn_Click_2(object sender, EventArgs e)
		{
			FrmServicePatient frmServicePatient = new FrmServicePatient();
			frmServicePatient.Show();
		}

		private void MainComplaintBtn_Click_2(object sender, EventArgs e)
		{
			FrmMainComplaint frmMainComplaint = new FrmMainComplaint();
			frmMainComplaint.Show();
		}

		private void FrmFilePatientBtn_Click_2(object sender, EventArgs e)
		{
			FrmFilePatient frmFilePatient = new FrmFilePatient("");
			frmFilePatient.Show();
		}

		private void ItemsFrmBtn_Click_1(object sender, EventArgs e)
		{
			ItemsFrm itemsFrm = new ItemsFrm();
			itemsFrm.Show();
		}

		private void SupplierBtn_Click_1(object sender, EventArgs e)
		{
			Supplier supplier = new Supplier();
			supplier.Show();
		}

		private void IncomingBillFrmBtn_Click(object sender, EventArgs e)
		{
			IncomingBillFrm incomingBillFrm = new IncomingBillFrm();
			incomingBillFrm.Show();
		}

		private void FrmSupplierAccountsBtn_Click(object sender, EventArgs e)
		{
			FrmSupplierAccounts frmSupplierAccounts = new FrmSupplierAccounts();
			frmSupplierAccounts.Show();
		}

		private void FormSupplier5Btn_Click(object sender, EventArgs e)
		{
			FormSupplier5 formSupplier = new FormSupplier5();
			formSupplier.Show();
		}

		private void FrmBillIncomeRptBtn_Click(object sender, EventArgs e)
		{
			FrmBillIncomeRpt frmBillIncomeRpt = new FrmBillIncomeRpt("0");
			frmBillIncomeRpt.Show();
		}

		private void SahbItemsBtn_Click(object sender, EventArgs e)
		{
			FrmSahbItems frmSahbItems = new FrmSahbItems();
			frmSahbItems.Show();
		}

		private void FrmRptBillByDateBtn_Click(object sender, EventArgs e)
		{
			FrmRptBillByDate frmRptBillByDate = new FrmRptBillByDate();
			frmRptBillByDate.Show();
		}

		private void BtnFrmSell_Click(object sender, EventArgs e)
		{
			FrmSell frmSell = new FrmSell();
			frmSell.Show();
		}

		private void FrmRptSellByDateBtn_Click(object sender, EventArgs e)
		{
			FrmRptSelllByDate frmRptSelllByDate = new FrmRptSelllByDate();
			frmRptSelllByDate.Show();
		}

		private void DentalDataBtn_Click(object sender, EventArgs e)
		{
			DentalData dentalData = new DentalData();
			dentalData.ShowDialog();
			try
			{
				panel5.BackgroundImage = Image.FromFile(DentistClinic.Properties.Settings.Default.backImage);
			}
			catch
			{
			}
			DisplayButtons();
			if (!Convert.ToBoolean(dc.GetTableText("select GeneralClinic from DentalData").Rows[0][0]))
			{
				naturaltherapy.Visible = false;
			}
			else
			{
				naturaltherapy.Visible = true;
			}
			if (Convert.ToBoolean(dc.GetTableText("select Physicaltherapy from DentalData").Rows[0][0]))
			{
				naturaltherapy.Visible = true;
			}
			else
			{
				naturaltherapy.Visible = false;
			}
		}

		private void PermissionBtn_Click(object sender, EventArgs e)
		{
			AllServiceRPT allServiceRPT = new AllServiceRPT();
			allServiceRPT.Show();
		}

		private void FrmPropertiesBtn_Click(object sender, EventArgs e)
		{
			FrmProperties frmProperties = new FrmProperties();
			frmProperties.Show();
		}

		private void btnBackup_Restore_Click(object sender, EventArgs e)
		{
			Form3 form = new Form3();
			form.Show();
		}

		private void FrmInoculationBtn_Click(object sender, EventArgs e)
		{
			FrmInoculation frmInoculation = new FrmInoculation();
			frmInoculation.Show();
		}

		private void FrmPatientInoculationBtn_Click(object sender, EventArgs e)
		{
			FrmPatientInoculation frmPatientInoculation = new FrmPatientInoculation();
			frmPatientInoculation.Show();
		}

		private void FrmRptPatientDebtBtn_Click(object sender, EventArgs e)
		{
			FrmRptPatientDebt frmRptPatientDebt = new FrmRptPatientDebt();
			frmRptPatientDebt.Show();
		}

		private void FrmBillBtn_Click(object sender, EventArgs e)
		{
			FrmBill frmBill = new FrmBill();
			frmBill.Show();
		}

		private void FrmVisitMedicalRepBtn_Click(object sender, EventArgs e)
		{
			FrmVisitMedicalRep frmVisitMedicalRep = new FrmVisitMedicalRep();
			frmVisitMedicalRep.Show();
		}

		private void AppointmentspBtn_Click(object sender, EventArgs e)
		{
			Appointmentsp appointmentsp = new Appointmentsp();
			appointmentsp.Show();
		}

		private void FrmRptSurgeryBtn_Click(object sender, EventArgs e)
		{
			FrmRptSurgery frmRptSurgery = new FrmRptSurgery();
			frmRptSurgery.Show();
		}

		private void CompanyPayBtn_Click(object sender, EventArgs e)
		{
			CompanyPay companyPay = new CompanyPay();
			companyPay.Show();
		}

		private void FrmRptCompanyAcountBtn_Click(object sender, EventArgs e)
		{
			FrmRptCompanyAcount frmRptCompanyAcount = new FrmRptCompanyAcount();
			frmRptCompanyAcount.Show();
		}

		private void FrmRptSpecialBtn_Click(object sender, EventArgs e)
		{
			FrmRptSpecial frmRptSpecial = new FrmRptSpecial();
			frmRptSpecial.Show();
		}

		private void AssistantAccountBtn_Click(object sender, EventArgs e)
		{
			FrmNesbaAssistant frmNesbaAssistant = new FrmNesbaAssistant();
			frmNesbaAssistant.Show();
		}

		private void RptAssistantPaymentBtn_Click(object sender, EventArgs e)
		{
			FrmRptAssistantPayment frmRptAssistantPayment = new FrmRptAssistantPayment();
			frmRptAssistantPayment.Show();
		}

		private void FrmAssistantRptBtn_Click(object sender, EventArgs e)
		{
			FrmAssistantRpt frmAssistantRpt = new FrmAssistantRpt();
			frmAssistantRpt.Show();
		}

		private void RptAssistantPaymentBtn_Click_1(object sender, EventArgs e)
		{
			FrmRptAssistantPayment frmRptAssistantPayment = new FrmRptAssistantPayment();
			frmRptAssistantPayment.Show();
		}

		private void AssistantAcountDate_Click(object sender, EventArgs e)
		{
			FrmAssistantAcountByDate1 frmAssistantAcountByDate = new FrmAssistantAcountByDate1();
			frmAssistantAcountByDate.Show();
		}

		private void RptLoginUserBtn_Click(object sender, EventArgs e)
		{
			FrmLoginUser frmLoginUser = new FrmLoginUser();
			frmLoginUser.Show();
		}

		private void StockFrmBtn_Click(object sender, EventArgs e)
		{
			StockFrm stockFrm = new StockFrm();
			stockFrm.Show();
		}

		private void StockUsersFrmBtn_Click(object sender, EventArgs e)
		{
			StockUsersFrm stockUsersFrm = new StockUsersFrm();
			stockUsersFrm.Show();
		}

		private void Main_Load(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				button6.BackgroundImage = Resources.a13;
			}
			else
			{
				button6.BackgroundImage = Resources._3_0000;
			}
			DataTable dataTable = Codes.Search2("select BeautyLiserClinic from DentalData");
			if (Convert.ToBoolean(dataTable.Rows[0][0]))
			{
				toolStripMenuItem_24.Visible = true;
			}
			else
			{
				toolStripMenuItem_24.Visible = false;
			}
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				PatientBtn.Image = Resources.a11;
				SecretaryPatientBtn.Image = Resources.a2;
				button14.Image = Resources.Apps_Live_Messenger_alt_2_Metro_icon;
				DoctorPatientBtn.Image = Resources.a3;
				AccountBtn.Image = Resources.a4;
				ReportsBtn.Image = Resources.a5;
				EmployeeBtn.Image = Resources.a6;
				IncomingSuppBtn.Image = Resources.a7;
				button1.Image = Resources.a8;
				tAddPatient.BackgroundImage = Resources.a9;
				tPatientPay.BackgroundImage = Resources.a10;
				tPatientAccount.BackgroundImage = Resources.a111;
				TpatientXray.BackgroundImage = Resources.a12;
				tAppointment.BackgroundImage = Resources.a13;
				FrmLimitOrderRptBtn.BackgroundImage = Resources.a14;
				if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
				{
					vistaButton2.Image = Resources.a15;
					vistaButton2.Text = "";
				}
			}else if (DentistClinic.Properties.Settings.Default.Language != "en-GB")
			{
				PatientBtn.Image = Resources.easy_clinic_design_0811;
				SecretaryPatientBtn.Image = Resources.easy_clinic_design_07;
				button14.Image = Resources.Apps_Live_Messenger_alt_2_Metro_icon;
				DoctorPatientBtn.Image = Resources.easy_clinic_design_06;
				AccountBtn.Image = Resources.easy_clinic_design_05;
				ReportsBtn.Image = Resources.easy_clinic_design_04;
				EmployeeBtn.Image = Resources.easy_clinic_design_03;
				IncomingSuppBtn.Image = Resources.easy_clinic_design_024;
				button1.Image = Resources.easy_clinic_design_012;
				tAddPatient.BackgroundImage = Resources._4_07;
				tPatientPay.BackgroundImage = Resources._4_06;
				tPatientAccount.BackgroundImage = Resources._4_05;
				TpatientXray.BackgroundImage = Resources._4_04;
				tAppointment.BackgroundImage = Resources._4_03;
				FrmLimitOrderRptBtn.BackgroundImage = Resources.C2_03;
				if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
				{
					vistaButton2.Image = Resources.a15;
					vistaButton2.Text = "";
				}

			}
			panel3.Visible = false;
			panel4.Location = new Point(0, 175);
			label9.Visible = true;
			DataTable dataTable2 = Codes.Search2("select * from Chat where Date < '" + DateTime.Now.ToString("MM/dd/yyyy") + "'");
			if (dataTable2.Rows.Count > 0)
			{
				Codes.Edit2("truncate Table  Chat");
			}
			DataTable dataTable3 = Codes.Search2("SELECT  dbo.PatientAccount.PatientId, dbo.PatientData.PName,isnull(sum(dbo.PatientAccount.Price - dbo.PatientAccount.PricePay),0) as debt\r\nFROM  dbo.PatientData INNER JOIN\r\ndbo.PatientAccount ON dbo.PatientData.ID = dbo.PatientAccount.PatientId where PatientAccount.Price != 0  group by dbo.PatientAccount.PatientId, dbo.PatientData.PName\r\nhaving sum(dbo.PatientAccount.Price - dbo.PatientAccount.PricePay) > 0");
			label5.Text = dataTable3.Rows.Count.ToString();
			try
			{
				_ = CultureInfo.CurrentCulture.IetfLanguageTag;
				CultureInfo.GetCultureInfoByIetfLanguageTag("en-US");
				CultureInfo cultureInfo = (CultureInfo)CultureInfo.CurrentCulture.Clone();
				cultureInfo.DateTimeFormat.Calendar = new GregorianCalendar();
				cultureInfo.DateTimeFormat.ShortDatePattern = "MM/dd/yyyy";
				cultureInfo.DateTimeFormat.ShortTimePattern = "HH:mm:ss";
				cultureInfo.DateTimeFormat.LongDatePattern = "MM/dd/yyyy";
				cultureInfo.DateTimeFormat.LongTimePattern = "HH:mm:ss";
				Thread.CurrentThread.CurrentCulture = cultureInfo;
				InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(Application.CurrentCulture);
				InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(new CultureInfo("ar-SA"));
			}
			catch
			{
			}
			try
			{
				if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
				{
					label3.Text = "Current DataBase " + DentistClinic.Properties.Settings.Default.DataBaseName;
				}
				else
				{
					label3.Text = "قاعدة البيانات الحالية " + DentistClinic.Properties.Settings.Default.DataBaseName;
				}
			}
			catch
			{
			}
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				label1.Text = "User Name " + usernames;
			}
			else
			{
				label1.Text = "اسم المستخدم " + usernames;
			}
			try
			{
				DataTable tableText = dc.GetTableText("select * from users where userName ='" + usernames + "' and userPassward ='" + passward + "'");
				toolStripMenuItem_32.Visible = Convert.ToBoolean(tableText.Rows[0]["ConnectPatients"].ToString());
				toolStripMenuItem_31.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientConnectRPT"].ToString());
				toolStripMenuItem_29.Visible = Convert.ToBoolean(tableText.Rows[0]["Attend"].ToString());
				toolStripMenuItem_30.Visible = Convert.ToBoolean(tableText.Rows[0]["AttendRPT"].ToString());
				toolStripMenuItem_26.Visible = Convert.ToBoolean(tableText.Rows[0]["PaperDiagnosis"].ToString());
				toolStripMenuItem_28.Visible = Convert.ToBoolean(tableText.Rows[0]["SickLeaveRPT"].ToString());
				toolStripMenuItem_27.Visible = Convert.ToBoolean(tableText.Rows[0]["SickLeave"].ToString());
				toolStripMenuItem_25.Visible = Convert.ToBoolean(tableText.Rows[0]["OfferRpT"].ToString());
				FrmInoculationBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmInoculationBtn"].ToString());
				FrmPatientInoculationBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmPatientInoculationBtn"].ToString());
				RptTaqweem.Visible = Convert.ToBoolean(tableText.Rows[0]["DoctorAccount"].ToString());
				DisplayButtons();
				toolStripMenuItem_21.Visible = Convert.ToBoolean(tableText.Rows[0]["Offers"].ToString());
				toolStripMenuItem_23.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientPayBefore"].ToString());
				toolStripMenuItem_22.Visible = Convert.ToBoolean(tableText.Rows[0]["Stockmoverpt"].ToString());
				button2.Visible = Convert.ToBoolean(tableText.Rows[0]["showAppButton"].ToString());
				userId = tableText.Rows[0]["userId"].ToString();
				addEmployeeBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["AddEmployee"].ToString());
				AddPatientBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["AddPatient"].ToString());
				appointmentBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["Appointment"].ToString());
				PatientListBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["DoctorPatientList"].ToString());
				secretPatientList.Visible = Convert.ToBoolean(tableText.Rows[0]["SecretaryPatientList"].ToString());
				DentalDataBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["DentalData"].ToString());
				doctorAcountBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["doctorAcountBtn"].ToString());
				searchPatientBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["SearchPatient"].ToString());
				CompanyBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["Company"].ToString());
				PatintPayBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientPay"].ToString());
				PatientAcountBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientAccount"].ToString());
				PatientAcountBtn2.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientAccount"].ToString());
				XrayBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientXray"].ToString());
				PermissionBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["Permission"].ToString());
				PatientAccountRptBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["PatAccountRpt"].ToString());
				AllPatientAccountBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["AllPatAccountRpt"].ToString());
				DoctorAcountRptBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["DoctorAccountRpt"].ToString());
				DoctorPaymentBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["DoctorPaymentRpt"].ToString());
				MovementOfPatientStatmentBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["MovOfPatSTrpt"].ToString());
				MovementOfPatByDr.Visible = Convert.ToBoolean(tableText.Rows[0]["MovOfPatStbyDr"].ToString());
				tAddPatient.Visible = Convert.ToBoolean(tableText.Rows[0]["AddPatient"].ToString());
				tPatientAccount.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientAccount"].ToString());
				tPatientPay.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientPay"].ToString());
				expensesToolStripMenuItem.Visible = Convert.ToBoolean(tableText.Rows[0]["Expenses"].ToString());
				revenuesToolStripMenuItem.Visible = Convert.ToBoolean(tableText.Rows[0]["Revenues"].ToString());
				expensesToolStripMenuItem1.Visible = Convert.ToBoolean(tableText.Rows[0]["RptExpenses"].ToString());
				revenuesToolStripMenuItem1.Visible = Convert.ToBoolean(tableText.Rows[0]["RptRevenues"].ToString());
				dailyClinicToolStripMenuItem.Visible = Convert.ToBoolean(tableText.Rows[0]["RptStockMove"].ToString());
				PackPatientListBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["DoctorBackReserve"].ToString());
				secretRebackPatientList.Visible = Convert.ToBoolean(tableText.Rows[0]["SecretaryBackReserve"].ToString());
				editReBackDateBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["UpdateRebackdate"].ToString());
				TpatientXray.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientXray"].ToString());
				tAppointment.Visible = Convert.ToBoolean(tableText.Rows[0]["Appointment"].ToString());
				medicineFrmBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["medicineFrmBtn"].ToString());
				PrescriptionFrmBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["PrescriptionFrmBtn"].ToString());
				ItemsFrmBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["ItemsFrmBtn"].ToString());
				SupplierBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["SupplierBtn"].ToString());
				IncomingBillFrmBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["IncomingBillFrmBtn"].ToString());
				FrmSupplierAccountsBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmSupplierAccountsBtn"].ToString());
				FormSupplier5Btn.Visible = Convert.ToBoolean(tableText.Rows[0]["FormSupplier5Btn"].ToString());
				FrmBillIncomeRptBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmBillIncomeRptBtn"].ToString());
				OldServicesRptFrmBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["OldServicesRptFrmBtn"].ToString());
				NetDailyClinicRptFrmBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["NetDailyClinicRptFrmBtn"].ToString());
				ClinicMonthGraphRptFrmBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["ClinicMonthGraphRptFrmBtn"].ToString());
				DailymeasureRotFrmBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["DailymeasureRotFrmBtn"].ToString());
				MainComplaintBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["MainComplaintBtn"].ToString());
				SahbItemsBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["SahbItemsBtn"].ToString());
				FrmRptSahbItemBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmRptSahbItemBtn"].ToString());
				FrmRptBillByDateBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmRptBillByDateBtn"].ToString());
				FrmFilePatientBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmFilePatientBtn"].ToString());
				FrmPropertiesBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmPropertiesBtn"].ToString());
				PatientAccount.docid = Convert.ToInt32(tableText.Rows[0]["EmpID"].ToString());
				FrmVisit.docid = Convert.ToInt32(tableText.Rows[0]["EmpID"].ToString());
				DoctorReserve.DoctorId = Convert.ToInt32(tableText.Rows[0]["EmpID"].ToString());
				DoctorReserveVisits.DoctorId = Convert.ToInt32(tableText.Rows[0]["EmpID"].ToString());
				DoctorBackReserve.DoctorId = Convert.ToInt32(tableText.Rows[0]["EmpID"].ToString());
				Surgery.Visible = Convert.ToBoolean(tableText.Rows[0]["Surgery"].ToString());
				BookingVisits.Visible = Convert.ToBoolean(tableText.Rows[0]["BookingVisits"].ToString());
				RptVisits.Visible = Convert.ToBoolean(tableText.Rows[0]["RptVisits"].ToString());
				SecretaryVisits.Visible = Convert.ToBoolean(tableText.Rows[0]["SecretaryVisits"].ToString());
				DoctorVisits.Visible = Convert.ToBoolean(tableText.Rows[0]["DoctorVisits"].ToString());
				PatientSurgery.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientSurgery"].ToString());
				BtnFrmRptReb7ya.Visible = Convert.ToBoolean(tableText.Rows[0]["BtnFrmRptReb7ya"].ToString());
				BtnFrmRptCompanies_Services.Visible = Convert.ToBoolean(tableText.Rows[0]["BtnFrmRptCompanies_Services"].ToString());
				BtnFrmSell.Visible = Convert.ToBoolean(tableText.Rows[0]["BtnFrmSell"].ToString());
				FrmRptSellByDateBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmRptSellByDateBtn"].ToString());
				PatientAccountUpdateBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientAccountUpdateBtn"].ToString());
				FrmInventoryRptBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmInventoryRptBtn"].ToString());
				FrmLimitOrderRptBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmLimitOrderRptBtn"].ToString());
				label2.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmLimitOrderRptBtn"].ToString());
				FrmAssistantRptBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmAssistantRptBtn"].ToString());
				FrmSearchMedicine.Visible = Convert.ToBoolean(tableText.Rows[0]["RptFrmSearchMedicine"].ToString());
				AppointmentspBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["AppointmentspBtn"].ToString());
				FrmRptSurgeryBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmRptSurgeryBtn"].ToString());
				CompanyService.Visible = Convert.ToBoolean(tableText.Rows[0]["ServicePatientBtn"].ToString());
				FrmRptPatientDebtBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmRptPatientDebtBtn"].ToString());
				doctorAcountBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["doctorAcountBtn"].ToString());
				FrmVisitMedicalRepBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmVisitMedicalRepBtn"].ToString());
				FrmBillBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmBillBtn"].ToString());
				FrmRptSpecialBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmRptSpecialBtn"].ToString());
				CompanyPayBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["CompanyPayBtn"].ToString());
				FrmRptCompanyAcountBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmRptCompanyAcountBtn"].ToString());
				AssistantAccountBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["AssistantAccountBtn"].ToString());
				AssistantAcountDate.Visible = Convert.ToBoolean(tableText.Rows[0]["AssistantAcountDate"].ToString());
				FrmTarnsbetweenStockBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmTarnsbetweenStockBtn"].ToString());
				StockTransRptFrmBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["StockTransRptFrmBtn"].ToString());
				FrmDeanSupplierBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmDeanSupplierBtn"].ToString());
				RptLoginUserBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["RptLoginUserBtn"].ToString());
				StockFrmBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["StockFrmBtn"].ToString());
				StockUsersFrmBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["StockUsersFrmBtn"].ToString());
				ReserveServiceRptFrmBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["ReserveServiceRptFrmBtn"].ToString());
				FrmEsalBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmEsalBtn"].ToString());
				FrmAnalyzesBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmAnalyzesBtn"].ToString());
				FrmRptRayAnalyzeBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmRptRayAnalyzeBtn"].ToString());
				CategoryBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientServiceUpdateBtn"].ToString());
				panel4.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmChat"].ToString());
				label9.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmChat"].ToString());
				label10.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmChat"].ToString());
				label6.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmRptPatientDebtBtn"].ToString());
				label5.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmRptPatientDebtBtn"].ToString());
				FrmBeforeAndAfterBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["FrmBeforeAndAfterBtn"].ToString());
				DiscountPointsBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["DiscountPointsBtn"].ToString());
				PatientPointRptBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientPointRptBtn"].ToString());
				RptKnowFromBtn.Visible = Convert.ToBoolean(tableText.Rows[0]["RptKnowFromBtn"].ToString());
				toolStripMenuItem4.Visible = Convert.ToBoolean(tableText.Rows[0]["RptPatientDetails"].ToString());
				toolStripMenuItem5.Visible = Convert.ToBoolean(tableText.Rows[0]["ItemsMoveRpt"].ToString());
				toolStripMenuItem6.Visible = Convert.ToBoolean(tableText.Rows[0]["ExpectedBirthDate"].ToString());
				toolStripMenuItem_1.Visible = Convert.ToBoolean(tableText.Rows[0]["ShowAppointments"].ToString());
				toolStripMenuItem_16.Visible = Convert.ToBoolean(tableText.Rows[0]["ShowAppointments"].ToString());
				toolStripMenuItem10.Visible = Convert.ToBoolean(tableText.Rows[0]["EmailCnfgs"].ToString());
				toolStripMenuItem11.Visible = Convert.ToBoolean(tableText.Rows[0]["RptEmails"].ToString());
				toolStripMenuItem12.Visible = Convert.ToBoolean(tableText.Rows[0]["RptEmailConfig"].ToString());
				toolStripMenuItem_3.Visible = Convert.ToBoolean(tableText.Rows[0]["NesbaDoctor"].ToString());
				selectdate.Visible = Convert.ToBoolean(tableText.Rows[0]["SurgeryDate"].ToString());
				Eshar = Convert.ToBoolean(tableText.Rows[0]["SurgeryDateRpt"].ToString());
				toolStripMenuItem_4.Visible = Convert.ToBoolean(tableText.Rows[0]["EmpWorkData"].ToString());
				toolStripMenuItem_15.Visible = Convert.ToBoolean(tableText.Rows[0]["RaysAnalysis"].ToString());
				toolStripMenuItem_17.Visible = Convert.ToBoolean(tableText.Rows[0]["MedicalReport"].ToString());
				toolStripMenuItem_6.Visible = Convert.ToBoolean(tableText.Rows[0]["BarcodePrint"].ToString());
				toolStripMenuItem_5.Visible = Convert.ToBoolean(tableText.Rows[0]["CompanyServices"].ToString());
				toolStripMenuItem_14.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientNotice"].ToString());
				toolStripMenuItem_7.Visible = Convert.ToBoolean(tableText.Rows[0]["RPTPatientNotice"].ToString());
				toolStripMenuItem14.Visible = Convert.ToBoolean(tableText.Rows[0]["Pediatric"].ToString());
				orthopedicalPhysiotherapyToolStripMenuItem.Visible = Convert.ToBoolean(tableText.Rows[0]["Orthopedical"].ToString());
				neurologicalPhysiotherapyToolStripMenuItem.Visible = Convert.ToBoolean(tableText.Rows[0]["Neurological"].ToString());
				toolStripMenuItem_12.Visible = Convert.ToBoolean(tableText.Rows[0]["NaturalTherapy"].ToString());
				toolStripMenuItem_13.Visible = Convert.ToBoolean(tableText.Rows[0]["ReAccountDoctor"].ToString());
				toolStripMenuItem_18.Visible = Convert.ToBoolean(tableText.Rows[0]["ReAccountPatient"].ToString());
				toolStripMenuItem9.Visible = Convert.ToBoolean(tableText.Rows[0]["SMSSetting"].ToString());
				toolStripMenuItem_9.Visible = Convert.ToBoolean(tableText.Rows[0]["PhoneNum"].ToString());
				toolStripMenuItem_10.Visible = Convert.ToBoolean(tableText.Rows[0]["SendSMS"].ToString());
				toolStripMenuItem_11.Visible = Convert.ToBoolean(tableText.Rows[0]["SendReportSetting"].ToString());
				button6.Visible = Convert.ToBoolean(tableText.Rows[0]["AppointmentspBtn"].ToString());
				label14.Visible = Convert.ToBoolean(tableText.Rows[0]["DoctorPatientList"].ToString());
				label13.Visible = Convert.ToBoolean(tableText.Rows[0]["DoctorPatientList"].ToString());
				label15.Visible = Convert.ToBoolean(tableText.Rows[0]["DoctorBackReserve"].ToString());
				label16.Visible = Convert.ToBoolean(tableText.Rows[0]["DoctorBackReserve"].ToString());
				label11.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientSurgery"].ToString());
				label12.Visible = Convert.ToBoolean(tableText.Rows[0]["PatientSurgery"].ToString());
				toolStripMenuItem_20.Visible = Convert.ToBoolean(tableText.Rows[0]["AllServiceReport"].ToString());
				if (!Convert.ToBoolean(dc.GetTableText("select FemaleClinic from DentalData").Rows[0][0]))
				{
					toolStripMenuItem6.Visible = false;
				}
				DataTable dataTable4 = Codes.Search2("select ServiceName from Properties");
				string text = dataTable4.Rows[0][0].ToString();
				if (text == "")
				{
					FrmProperties frmProperties = new FrmProperties();
					frmProperties.ShowDialog();
				}
				DataTable dataTable5 = Codes.Search2("SELECT     isnull(count(dbo.Items.Id),0)\r\nFROM         dbo.Items INNER JOIN\r\n                      dbo.Store ON dbo.Items.Id = dbo.Store.ItemId\r\nwhere dbo.Store.Qnt <= dbo.Items.LimitOrder");
				if (dataTable5.Rows.Count > 0)
				{
					label2.Text = dataTable5.Rows[0][0].ToString();
				}
			}
			catch
			{
			}
			try
			{
				MethodsClass.UserMove("تسجيل دخول");
			}
			catch (Exception ex)
			{
				MessageBox.Show(string.Concat(ex));
			}
			try
			{
				DataTable tableText = Codes.Search2("select userId,userName from users where userId !='" + userId + "'");
				comboBox1.DataSource = tableText;
				comboBox1.ValueMember = "userId";
				comboBox1.DisplayMember = "userName";
			}
			catch
			{
			}
			try
			{
				label10.Text = Codes.Search2("select count(*) from Chat where Seen = 0 and ToUser = '" + userId + "'").Rows[0][0].ToString();
			}
			catch
			{
			}
			try
			{
				label12.Text = Codes.Search2("SELECT     dbo.PatientData.PName, dbo.Empdata.Name, dbo.SurgeryDates.Date, dbo.Surgery.Name AS Expr1, dbo.SurgeryDates.Notes\r\nFROM         dbo.SurgeryDates INNER JOIN\r\n                      dbo.PatientData ON dbo.SurgeryDates.PatientId = dbo.PatientData.ID INNER JOIN\r\n                      dbo.Empdata ON dbo.SurgeryDates.DoctorID = dbo.Empdata.ID INNER JOIN\r\n                      dbo.Surgery ON dbo.SurgeryDates.SurgeryId = dbo.Surgery.ID where dbo.SurgeryDates.Date between '" + DateTime.Now.ToString("MM/dd/yyyy") + "' and '" + DateTime.Now.AddDays(7.0).ToString("MM/dd/yyyy") + "'").Rows.Count.ToString();
			}
			catch
			{
			}
			Process process = new Process();
			int num = Screen.AllScreens.Length;
			if (Screen.AllScreens.Length != num)
			{
				string[] commandLineArgs = Environment.GetCommandLineArgs();
				process.StartInfo.FileName = commandLineArgs[1];
				process.StartInfo.Arguments = commandLineArgs[2];
				num = Convert.ToInt32(commandLineArgs[3]);
				process.Start();
				process.WaitForInputIdle();
				Thread.Sleep(4000);
				int.TryParse(commandLineArgs[3], out num);
				Screen[] allScreens = Screen.AllScreens;
				foreach (Screen screen in allScreens)
				{
					if (!screen.Primary)
					{
						Rectangle workingArea = screen.WorkingArea;
						SetWindowPos(process.MainWindowHandle, 0, workingArea.Left, workingArea.Top, workingArea.Width, workingArea.Height, 0);
					}
				}
			}
			try
			{
				timer2.Enabled = false;
				if (DentistClinic.Properties.Settings.Default.Filename != "filename")
				{
					timer1.Enabled = true;
					ServerConnection serverConnection = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName);
					serverConnection.LoginSecure = false;
					serverConnection.Login = DentistClinic.Properties.Settings.Default.UserName;
					serverConnection.Password = DentistClinic.Properties.Settings.Default.Pass;
					srvSql = new Server(serverConnection);
				}
				BackupDate = Codes.Search2("select BackUpTime from Properties").Rows[0][0].ToString();
			}
			catch
			{
			}
			if (!Convert.ToBoolean(dc.GetTableText("select GeneralClinic from DentalData").Rows[0][0]))
			{
				naturaltherapy.Visible = false;
			}
			else
			{
				naturaltherapy.Visible = true;
			}
			try
			{
				DataTable dataTable6 = Codes.Search2("select ServiceName,ServiceDetect from Properties");
				DataTable tableText = Codes.Search2("SELECT Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID', PatientData.Titel, PatientData.PName,PatientAccount.Bean as 'الخدمة',PatientData.NextvisitTXT,PatientAccount.Price, PatientData.Tel, PatientData.Mob, PatientData.PAddress,PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes,PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy,PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status,NextVisit,Appointments.Accepted,Appointments.detectStartTime,detectEndTime FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID INNER JOIN Empdata INNER JOIN Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID INNER JOIN PatientAccount ON Appointments.ID = PatientAccount.AppointNum WHERE (Appointments.detectDate = '" + DateTime.Now.ToString("MM/dd/yyyy") + "')   and (Appointments.Done='False') and (PatientAccount.Bean ='" + dataTable6.Rows[0][0].ToString() + "' or PatientAccount.Bean ='" + dataTable6.Rows[0][1].ToString() + "') and PatientData.Active = 'True' GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID, PatientData.Titel, PatientData.PName,PatientData.NextvisitTXT, PatientData.Tel, PatientData.Mob, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name,PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever,PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed,PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.Opretive, PatientData.Bleaching,Appointments.Status ,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime,PatientAccount.Bean order by LEFT(Appointments.detectStartTime, 2),substring(Appointments.detectStartTime,4,2) asc");
				label13.Text = tableText.Rows.Count.ToString();
				DataTable dataTable7 = Codes.Search2("select * from Appointments   WHERE (Appointments.packDate ='" + DateTime.Now.ToString("MM/dd/yyyy") + "') AND (Appointments.PackDone = 'false') ");
				label15.Text = dataTable7.Rows.Count.ToString();
			}
			catch
			{
			}
			try
			{
				if (Convert.ToBoolean(dc.GetTableText("select Physicaltherapy from DentalData").Rows[0][0]))
				{
					naturaltherapy.Visible = true;
				}
				else
				{
					naturaltherapy.Visible = false;
				}
			}
			catch
			{
			}
		}

		private void Main_MouseHover(object sender, EventArgs e)
		{
			PassValue();
		}

		private void ReportsBtn_Click(object sender, EventArgs e)
		{
		}

		private void FrmTarnsbetweenStockBtn_Click(object sender, EventArgs e)
		{
			FrmTarnsbetweenStock frmTarnsbetweenStock = new FrmTarnsbetweenStock();
			frmTarnsbetweenStock.Show();
		}

		private void StockTransRptFrmBtn_Click(object sender, EventArgs e)
		{
			StockTransRptFrm stockTransRptFrm = new StockTransRptFrm();
			stockTransRptFrm.Show();
		}

		private void FrmDeanSupplierBtn_Click(object sender, EventArgs e)
		{
			FrmDeanSupplier frmDeanSupplier = new FrmDeanSupplier();
			frmDeanSupplier.Show();
		}

		private void FrmDeanSupplierBtn_Click_1(object sender, EventArgs e)
		{
			FrmDeanSupplier frmDeanSupplier = new FrmDeanSupplier();
			frmDeanSupplier.Show();
		}

		private void ReserveServiceRptFrmBtn_Click(object sender, EventArgs e)
		{
			ReserveServiceRptFrm reserveServiceRptFrm = new ReserveServiceRptFrm();
			reserveServiceRptFrm.Show();
		}

		private void FrmEsalBtn_Click(object sender, EventArgs e)
		{
			FrmEsal frmEsal = new FrmEsal();
			frmEsal.Show();
		}

		private void FrmAnalyzesBtn_Click(object sender, EventArgs e)
		{
			FrmAnalyzes frmAnalyzes = new FrmAnalyzes(0);
			frmAnalyzes.Show();
		}

		private void FrmRptRayAnalyzeBtn_Click(object sender, EventArgs e)
		{
			FrmRptRayAnalyze frmRptRayAnalyze = new FrmRptRayAnalyze();
			frmRptRayAnalyze.Show();
		}

		private void CategoryBtn_Click(object sender, EventArgs e)
		{
			Category category = new Category();
			category.Show();
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			string text = label2.Text;
			string text2 = label10.Text;
			string text3 = label5.Text;
			string text4 = label12.Text;
			try
			{
				DataTable dataTable = Codes.Search2("SELECT     isnull(count(dbo.Items.Id),0)\r\nFROM         dbo.Items INNER JOIN\r\n                      dbo.Store ON dbo.Items.Id = dbo.Store.ItemId\r\nwhere dbo.Store.Qnt <= dbo.Items.LimitOrder");
				if (dataTable.Rows.Count > 0)
				{
					label2.Text = dataTable.Rows[0][0].ToString();
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = Codes.Search2("SELECT  dbo.PatientAccount.PatientId, dbo.PatientData.PName,isnull(sum(dbo.PatientAccount.Price - dbo.PatientAccount.PricePay),0) as debt\r\nFROM  dbo.PatientData INNER JOIN\r\ndbo.PatientAccount ON dbo.PatientData.ID = dbo.PatientAccount.PatientId where PatientAccount.Price != 0  group by dbo.PatientAccount.PatientId, dbo.PatientData.PName\r\nhaving sum(dbo.PatientAccount.Price - dbo.PatientAccount.PricePay) > 0");
				label5.Text = dataTable2.Rows.Count.ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable3 = Codes.Search2("select userId,userName from users where userId !='" + userId + "'");
				if (dataTable3.Rows.Count != count)
				{
					comboBox1.DataSource = dataTable3;
					comboBox1.ValueMember = "userId";
					comboBox1.DisplayMember = "userName";
					count = dataTable3.Rows.Count;
				}
			}
			catch
			{
			}
			try
			{
				label10.Text = Codes.Search2("select count(*) from Chat where Seen = 0 and ToUser = '" + userId + "'").Rows[0][0].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable4 = Codes.Search2("SELECT  dbo.PatientAccount.PatientId, dbo.PatientData.PName,isnull(sum(dbo.PatientAccount.Price - dbo.PatientAccount.PricePay),0) as debt\r\nFROM  dbo.PatientData INNER JOIN\r\ndbo.PatientAccount ON dbo.PatientData.ID = dbo.PatientAccount.PatientId where PatientAccount.Price != 0  group by dbo.PatientAccount.PatientId, dbo.PatientData.PName\r\nhaving sum(dbo.PatientAccount.Price - dbo.PatientAccount.PricePay) > 0");
				label5.Text = dataTable4.Rows.Count.ToString();
			}
			catch
			{
			}
			try
			{
				label12.Text = Codes.Search2("SELECT     dbo.PatientData.PName, dbo.Empdata.Name, dbo.SurgeryDates.Date, dbo.Surgery.Name AS Expr1, dbo.SurgeryDates.Notes\r\nFROM         dbo.SurgeryDates INNER JOIN\r\n                      dbo.PatientData ON dbo.SurgeryDates.PatientId = dbo.PatientData.ID INNER JOIN\r\n                      dbo.Empdata ON dbo.SurgeryDates.DoctorID = dbo.Empdata.ID INNER JOIN\r\n                      dbo.Surgery ON dbo.SurgeryDates.SurgeryId = dbo.Surgery.ID where dbo.SurgeryDates.Date between '" + DateTime.Now.ToString("MM/dd/yyyy") + "' and '" + DateTime.Now.AddDays(7.0).ToString("MM/dd/yyyy") + "'").Rows.Count.ToString();
			}
			catch
			{
			}
			if (text != label2.Text || text2 != label10.Text || text3 != label5.Text || text4 != label12.Text)
			{
				SoundPlayer soundPlayer = new SoundPlayer(Resources.new_notification);
				soundPlayer.Play();
			}
			try
			{
				Codes.Search2("update PatientAccount set ServiceCount = 1 where ServiceCount is null");
			}
			catch
			{
			}
		}

		private void button14_Click(object sender, EventArgs e)
		{
			if (!panel3.Visible)
			{
				panel3.Visible = true;
				panel4.Location = new Point(172, 175);
			}
			else
			{
				panel3.Visible = false;
				panel4.Location = new Point(0, 175);
			}
		}

		public bool IsEnglish(string inputstring)
		{
			Regex regex = new Regex("[A-Za-z0-9 .,-=+(){}\\[\\]\\\\]");
			MatchCollection matchCollection = regex.Matches(inputstring);
			if (matchCollection.Count.Equals(inputstring.Length))
			{
				return true;
			}
			return false;
		}

		private void button3_Click_2(object sender, EventArgs e)
		{
			if (comboBox1.SelectedIndex != -1)
			{
				FrmChat frmChat = new FrmChat(Convert.ToInt32(comboBox1.SelectedValue));
				if (IsEnglish(comboBox1.Text))
				{
					if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
					{
						frmChat.Text = " Chat With " + comboBox1.Text;
					}
					else
					{
						frmChat.Text = comboBox1.Text + " شات مع ";
					}
					frmChat.Show();
				}
				else
				{
					if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
					{
						frmChat.Text = " Chat With " + comboBox1.Text;
					}
					else
					{
						frmChat.Text = " شات مع " + comboBox1.Text;
					}
					frmChat.Show();
				}
			}
			else if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				MessageBox.Show("Please Enter User name");
			}
			else
			{
				MessageBox.Show("من فضلك ادخل اسم المستخدم صحيح");
			}
		}

		private void FrmBeforeAndAfterBtn_Click(object sender, EventArgs e)
		{
			FrmBeforeAndAfter frmBeforeAndAfter = new FrmBeforeAndAfter();
			frmBeforeAndAfter.Show();
		}

		private void label11_Click(object sender, EventArgs e)
		{
		}

		private void toolStripMenuItem4_Click(object sender, EventArgs e)
		{
			FrmDiscountPoints frmDiscountPoints = new FrmDiscountPoints();
			frmDiscountPoints.Show();
		}

		private void PatientPointRptBtn_Click(object sender, EventArgs e)
		{
			FrmPatientPointsRpt frmPatientPointsRpt = new FrmPatientPointsRpt();
			frmPatientPointsRpt.Show();
		}

		private void RptKnowFromBtn_Click(object sender, EventArgs e)
		{
			FrmRptKnowFrom frmRptKnowFrom = new FrmRptKnowFrom();
			frmRptKnowFrom.Show();
		}

		private void toolStripMenuItem4_Click_1(object sender, EventArgs e)
		{
			FrmRptPatientDetails frmRptPatientDetails = new FrmRptPatientDetails();
			frmRptPatientDetails.Show();
		}

		private void toolStripMenuItem5_Click(object sender, EventArgs e)
		{
			ItemsMoveRptFrm itemsMoveRptFrm = new ItemsMoveRptFrm();
			itemsMoveRptFrm.Show();
		}

		private void button2_Click_2(object sender, EventArgs e)
		{
			if (Screen.AllScreens.Length > 1)
			{
				FrmTestMonitor frmTestMonitor = new FrmTestMonitor();
				frmTestMonitor.StartPosition = FormStartPosition.Manual;
				Screen secondaryScreen = GetSecondaryScreen();
				frmTestMonitor.Location = secondaryScreen.WorkingArea.Location;
				frmTestMonitor.Size = new Size(secondaryScreen.WorkingArea.Width, secondaryScreen.WorkingArea.Height);
				frmTestMonitor.Show();
				try
				{
					Process process = new Process();
					int num = Screen.AllScreens.Length;
					if (Screen.AllScreens.Length == num)
					{
						return;
					}
					string[] commandLineArgs = Environment.GetCommandLineArgs();
					process.StartInfo.FileName = commandLineArgs[1];
					process.StartInfo.Arguments = commandLineArgs[2];
					num = Convert.ToInt32(commandLineArgs[3]);
					process.Start();
					process.WaitForInputIdle();
					Thread.Sleep(4000);
					int.TryParse(commandLineArgs[3], out num);
					Screen[] allScreens = Screen.AllScreens;
					for (int i = 0; i < allScreens.Length; i++)
					{
						secondaryScreen = allScreens[i];
						if (!secondaryScreen.Primary)
						{
							Rectangle workingArea = secondaryScreen.WorkingArea;
							SetWindowPos(process.MainWindowHandle, 0, workingArea.Left, workingArea.Top, workingArea.Width, workingArea.Height, 0);
						}
					}
				}
				catch
				{
				}
			}
			else
			{
				MessageBox.Show("The monitor doesn't exist");
			}
		}

		private void toolStripMenuItem6_Click(object sender, EventArgs e)
		{
			frmRptPatientBirth frmRptPatientBirth2 = new frmRptPatientBirth();
			frmRptPatientBirth2.Show();
		}

		private void toolStripMenuItem_1_Click(object sender, EventArgs e)
		{
			frmShowAppointments frmShowAppointments2 = new frmShowAppointments();
			frmShowAppointments2.Show();
		}

		private void toolStripMenuItem_16_Click(object sender, EventArgs e)
		{
			FormNotes formNotes = new FormNotes();
			formNotes.Show();
		}

		private void toolStripMenuItem10_Click(object sender, EventArgs e)
		{
			FrmEmailCnfgs frmEmailCnfgs = new FrmEmailCnfgs();
			frmEmailCnfgs.Show();
		}

		private void toolStripMenuItem11_Click(object sender, EventArgs e)
		{
			FrmRptEmails frmRptEmails = new FrmRptEmails();
			frmRptEmails.Show();
		}

		private void toolStripMenuItem12_Click(object sender, EventArgs e)
		{
			FrmRptEmailConfig frmRptEmailConfig = new FrmRptEmailConfig();
			frmRptEmailConfig.Show();
		}

		private void timerEmail_Tick(object sender, EventArgs e)
		{
			try
			{
				try
				{
					string[] files = Directory.GetFiles(Application.StartupPath + "\\", "*.pdf");
					string[] array = files;
					foreach (string path in array)
					{
						File.Delete(path);
					}
				}
				catch
				{
				}
				DataTable dataTable = Codes.Search2("select Active from EmailCnfgs");
				bool flag = false;
				try
				{
					flag = Convert.ToBoolean(dataTable.Rows[0][0].ToString());
				}
				catch
				{
				}
				if (!flag)
				{
					return;
				}
				DataTable dataTable2 = Codes.Search2("select * from RptEmails");
				for (int j = 0; j < dataTable2.Rows.Count; j++)
				{
					DataTable dataTable3 = Codes.Search2("select * from RptsForEmail");
					for (int k = 0; k < dataTable3.Rows.Count; k++)
					{
						DataTable dataTable4 = Codes.Search2("select * from RptEmailConfig where EmailID = '" + dataTable2.Rows[j][0].ToString() + "' and RptID = '" + dataTable3.Rows[k][0].ToString() + "'");
						if (dataTable4.Rows.Count <= 0)
						{
							continue;
						}
						DataTable dataTable5 = new DataTable();
						dataTable5 = ((!(dataTable4.Rows[0][4].ToString() == "يوم")) ? Codes.Search2(string.Concat("select * from RptSent where EmailID = '", dataTable4.Rows[0][1].ToString(), "' and RptID = '", dataTable4.Rows[0][2].ToString(), "' and Date = '", DateTime.Today, "'")) : Codes.Search2(string.Concat("select * from RptSent where EmailID = '", dataTable4.Rows[0][1].ToString(), "' and RptID = '", dataTable4.Rows[0][2].ToString(), "' and Date = '", DateTime.Today, "'")));
						if (dataTable5.Rows.Count != 0)
						{
							continue;
						}
						new DataTable();
						Codes.Search2("select * from RptSent where EmailID = '" + dataTable4.Rows[0][1].ToString() + "' and RptID = '" + dataTable4.Rows[0][2].ToString() + "'");
						if (!(DateTime.Now.ToLocalTime() == Convert.ToDateTime(dataTable4.Rows[0][5].ToString()).ToLocalTime()))
						{
							continue;
						}
						if (dataTable4.Rows[0][4].ToString() == "يوم")
						{
							if (dataTable3.Rows[k][1].ToString() == "DoctorAcount")
							{
								DataTable dataTable6 = Codes.Search2("SELECT     ID, Name\r\nFROM         Empdata\r\nWHERE     (Designation = N'Doctor')");
								for (int l = 0; l < dataTable6.Rows.Count; l++)
								{
									SendEmails(dataTable4.Rows[0][1].ToString(), dataTable4.Rows[0][2].ToString(), DateTime.Today, DateTime.Today, dataTable6.Rows[l][0].ToString(), dataTable6.Rows[l][1].ToString());
								}
							}
							else
							{
								SendEmails(dataTable4.Rows[0][1].ToString(), dataTable4.Rows[0][2].ToString(), DateTime.Today, DateTime.Today, "", "");
							}
						}
						else if (dataTable3.Rows[k][1].ToString() == "DoctorAcount")
						{
							DataTable dataTable6 = Codes.Search2("SELECT     ID, Name\r\nFROM         Empdata\r\nWHERE     (Designation = N'Doctor')");
							for (int l = 0; l < dataTable6.Rows.Count; l++)
							{
								SendEmails(dataTable4.Rows[0][1].ToString(), dataTable4.Rows[0][2].ToString(), DateTime.Today, DateTime.Today, dataTable6.Rows[l][0].ToString(), dataTable6.Rows[l][1].ToString());
							}
						}
						else
						{
							SendEmails(dataTable4.Rows[0][1].ToString(), dataTable4.Rows[0][2].ToString(), DateTime.Today, DateTime.Today, "", "");
						}
					}
				}
			}
			catch
			{
			}
		}

		private void SendEmails(string emailID, string rptID, DateTime lastDate, DateTime dateToBegin, string ID, string name)
		{
			try
			{
				DataTable dataTable = Codes.Search2("select RptName,RptNameAr from RptsForEmail where ID = '" + rptID + "'");
				string text = dataTable.Rows[0][0].ToString();
				string fileName = Application.StartupPath + "\\Report.pdf";
				switch (text)
				{
				case "Patients":
				{
					string text2 = "حسابات المرضى " + dateToBegin.ToString("dd-MM-yyyy") + " إلى " + lastDate.ToString("dd-MM-yyyy");
					fileName = Application.StartupPath + "\\" + text2 + ".pdf";
					new frmAllPatientAcount(dateToBegin, lastDate, fileName);
					break;
				}
				case "DailyClinic":
				{
					string text2 = "يومية العيادة خلال الفترة من " + dateToBegin.ToString("dd-MM-yyyy") + " إلى " + lastDate.ToString("dd-MM-yyyy");
					fileName = Application.StartupPath + "\\" + text2 + ".pdf";
					new FrmRptStockMove(dateToBegin, lastDate, fileName);
					break;
				}
				case "NetDailyClinic":
				{
					string text2 = "صافي يومية العيادة خلال الفترة من " + dateToBegin.ToString("dd-MM-yyyy") + " إلى " + lastDate.ToString("dd-MM-yyyy");
					fileName = Application.StartupPath + "\\" + text2 + ".pdf";
					new NetDailyClinicRptFrm(dateToBegin, lastDate, fileName);
					break;
				}
				case "Profitability":
				{
					string text2 = "الربحية خلال الفترة من " + dateToBegin.ToString("dd-MM-yyyy") + " إلى " + lastDate.ToString("dd-MM-yyyy");
					fileName = Application.StartupPath + "\\" + text2 + ".pdf";
					new FrmRptReb7ya(dateToBegin, lastDate, fileName);
					break;
				}
				case "UserMove":
				{
					string text2 = "دخول مستخدم خلال الفترة من " + dateToBegin.ToString("dd-MM-yyyy") + " إلى " + lastDate.ToString("dd-MM-yyyy");
					fileName = Application.StartupPath + "\\" + text2 + ".pdf";
					new FrmLoginUser(dateToBegin, lastDate, fileName);
					break;
				}
				case "DoctorAcount":
				{
					string text2 = " حساب طبيب " + name + " خلال الفترة من " + dateToBegin.ToString("dd-MM-yyyy") + " إلى " + lastDate.ToString("dd-MM-yyyy");
					fileName = Application.StartupPath + "\\" + text2 + ".pdf";
					new FrmDoctorAcountByDate(dateToBegin, lastDate, fileName, ID);
					break;
				}
				}
				using (WebClient webClient = new WebClient())
				{
					using (webClient.OpenRead("http://www.google.com"))
					{
						DataTable dataTable2 = Codes.Search2("select * from EmailCnfgs");
						MailMessage mailMessage = new MailMessage();
						mailMessage.From = new MailAddress(dataTable2.Rows[0][1].ToString(), "Easy Clinic System");
						MailMessage mailMessage2 = mailMessage;
						DataTable dataTable3 = Codes.Search2("select Email from RptEmails where ID= '" + emailID + "'");
						mailMessage2.To.Add(dataTable3.Rows[0][0].ToString());
						mailMessage2.Subject = dataTable.Rows[0][1].ToString();
						mailMessage2.IsBodyHtml = false;
						mailMessage2.Body = dataTable.Rows[0][1].ToString();
						Attachment item = new Attachment(fileName);
						mailMessage2.Attachments.Add(item);
						SmtpClient smtpClient = new SmtpClient(dataTable2.Rows[0][2].ToString());
						smtpClient.EnableSsl = Convert.ToBoolean(dataTable2.Rows[0][5].ToString());
						smtpClient.Credentials = new NetworkCredential(dataTable2.Rows[0][3].ToString(), dataClass.Decrypt(dataTable2.Rows[0][4].ToString()));
						SmtpClient smtpClient2 = smtpClient;
						if (dataTable2.Rows[0][6].ToString() != null)
						{
							smtpClient2.Port = Convert.ToInt32(dataTable2.Rows[0][6].ToString());
						}
						smtpClient2.Send(mailMessage2);
						mailMessage2.Dispose();
						Codes.Add2("insert into RptSent (EmailID, RptID, Date) Values ('" + emailID + "', '" + rptID + "', '" + lastDate.ToString("MM/dd/yyyy") + "')");
						TrayIcon.Visible = true;
						TrayIcon.ShowBalloonTip(100);
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}

		private void toolStripMenuItem_3_Click(object sender, EventArgs e)
		{
			FrmNesbaDoctor frmNesbaDoctor = new FrmNesbaDoctor();
			frmNesbaDoctor.Show();
		}

		private void toolStripMenuItem8_Click(object sender, EventArgs e)
		{
			FrmSurgeryDate frmSurgeryDate = new FrmSurgeryDate();
			frmSurgeryDate.Show();
		}

		private void label11_Click_1(object sender, EventArgs e)
		{
			if (Eshar)
			{
				FrmSurgeryNoRpt frmSurgeryNoRpt = new FrmSurgeryNoRpt();
				frmSurgeryNoRpt.Show();
			}
		}

		private void Main_Activated(object sender, EventArgs e)
		{
			try
			{
				panel5.BackgroundImage = Image.FromFile(DentistClinic.Properties.Settings.Default.backImage);
			}
			catch
			{
			}
		}

		private void toolStripMenuItem_4_Click(object sender, EventArgs e)
		{
			FrmEmpWorkDataRpt frmEmpWorkDataRpt = new FrmEmpWorkDataRpt();
			frmEmpWorkDataRpt.Show();
		}

		private void toolStripMenuItem_15_Click(object sender, EventArgs e)
		{
			RayAnalyze rayAnalyze = new RayAnalyze();
			rayAnalyze.Show();
		}

		private void toolStripMenuItem_17_Click(object sender, EventArgs e)
		{
			FrmMedicalReport frmMedicalReport = new FrmMedicalReport();
			frmMedicalReport.Show();
		}

		private void toolStripMenuItem_5_Click(object sender, EventArgs e)
		{
			RPTCompanyServices rPTCompanyServices = new RPTCompanyServices();
			rPTCompanyServices.Show();
		}

		private void button4_Click_2(object sender, EventArgs e)
		{
			FrmTechnicalSupport frmTechnicalSupport = new FrmTechnicalSupport();
			frmTechnicalSupport.Show();
		}

		private void toolStripMenuItem_6_Click(object sender, EventArgs e)
		{
			FrmBarCode1 frmBarCode = new FrmBarCode1();
			frmBarCode.Show();
		}

		private void Main_FormClosed(object sender, FormClosedEventArgs e)
		{
			if (!RestoreDB)
			{
				MethodsClass.UserMove("تسجيل خروج");
			}
		}

		private void EmployeeBtn_Click(object sender, EventArgs e)
		{
		}

		private void toolStripMenuItem_14_Click(object sender, EventArgs e)
		{
			FrmPatientNotice frmPatientNotice = new FrmPatientNotice();
			frmPatientNotice.Show();
		}

		private void toolStripMenuItem_7_Click(object sender, EventArgs e)
		{
			RptPatientNotice rptPatientNotice = new RptPatientNotice();
			rptPatientNotice.Show();
		}

		private void toolStripMenuItem9_Click(object sender, EventArgs e)
		{
			FrmSMSConfig frmSMSConfig = new FrmSMSConfig();
			frmSMSConfig.Show();
		}

		private void toolStripMenuItem_9_Click(object sender, EventArgs e)
		{
			FrmRptMobiles frmRptMobiles = new FrmRptMobiles();
			frmRptMobiles.Show();
		}

		private void toolStripMenuItem_10_Click(object sender, EventArgs e)
		{
			FrmClientSMS frmClientSMS = new FrmClientSMS();
			frmClientSMS.Show();
		}

		private void toolStripMenuItem_11_Click(object sender, EventArgs e)
		{
			FrmRptMobileConfig frmRptMobileConfig = new FrmRptMobileConfig();
			frmRptMobileConfig.Show();
		}

		public void timerMobile_Tick(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("select API, UserName, Password, SenderName, Active from SMS");
				bool flag = false;
				try
				{
					flag = Convert.ToBoolean(dataTable.Rows[0][4].ToString());
				}
				catch
				{
				}
				if (!flag)
				{
					return;
				}
				API = dataTable.Rows[0][0].ToString();
				Username = dataTable.Rows[0][1].ToString();
				Password = dataClass.Decrypt(dataTable.Rows[0][2].ToString());
				SenderName = dataTable.Rows[0][3].ToString();
				DataTable dataTable2 = Codes.Search2("select * from RptMobiles");
				for (int i = 0; i < dataTable2.Rows.Count; i++)
				{
					Msg = "";
					DataTable dataTable3 = Codes.Search2("select * from RptsForMobile");
					DataTable dataTable4 = new DataTable();
					dataTable4.Columns.Add("MobileID", typeof(int));
					dataTable4.Columns.Add("RptID", typeof(int));
					dataTable4.Columns.Add("Date", typeof(DateTime));
					for (int j = 0; j < dataTable3.Rows.Count; j++)
					{
						DataTable dataTable5 = Codes.Search2("select * from RptMobileConfig where MobileID = '" + dataTable2.Rows[i][0].ToString() + "' and RptID = '" + dataTable3.Rows[j][0].ToString() + "'");
						if (dataTable5.Rows.Count <= 0)
						{
							continue;
						}
						DataTable dataTable6 = new DataTable();
						dataTable6 = ((!(dataTable5.Rows[0][4].ToString() == "يوم")) ? Codes.Search2("select * from RptSent where MobileID = '" + dataTable5.Rows[0][1].ToString() + "' and RptID = '" + dataTable5.Rows[0][2].ToString() + "' and Date > '" + DateTime.Today.AddMonths(-1 * Convert.ToInt32(dataTable5.Rows[0][3].ToString())).ToString("MM/dd/yyyy") + "'") : Codes.Search2("select * from RptSent where MobileID = '" + dataTable5.Rows[0][1].ToString() + "' and RptID = '" + dataTable5.Rows[0][2].ToString() + "' and Date > '" + DateTime.Today.AddDays(-1.0 * Convert.ToDouble(dataTable5.Rows[0][3].ToString())).ToString("MM/dd/yyyy") + "'"));
						if (dataTable6.Rows.Count != 0)
						{
							continue;
						}
						DataTable dataTable7 = new DataTable();
						Codes.Search2("select * from RptSent where MobileID = '" + dataTable5.Rows[0][1].ToString() + "' and RptID = '" + dataTable5.Rows[0][2].ToString() + "'");
						dataTable7 = ((!(dataTable5.Rows[0][4].ToString() == "يوم")) ? Codes.Search2("select * from RptSent where MobileID = '" + dataTable5.Rows[0][1].ToString() + "' and RptID = '" + dataTable5.Rows[0][2].ToString() + "' and Date = '" + DateTime.Today.AddMonths(-1 * Convert.ToInt32(dataTable5.Rows[0][3].ToString())).ToString("MM/dd/yyyy") + "'") : Codes.Search2("select * from RptSent where MobileID = '" + dataTable5.Rows[0][1].ToString() + "' and RptID = '" + dataTable5.Rows[0][2].ToString() + "' and Date = '" + DateTime.Today.AddDays(-1.0 * Convert.ToDouble(dataTable5.Rows[0][3].ToString())).ToString("MM/dd/yyyy") + "'"));
						if (dataTable7.Rows.Count > 0 || dataTable7.Rows.Count == 0)
						{
							if (DateTime.Now.ToLocalTime() >= Convert.ToDateTime(dataTable5.Rows[0][5].ToString()).ToLocalTime())
							{
								if (dataTable5.Rows[0][4].ToString() == "يوم")
								{
									SendMobiles(dataTable5.Rows[0][1].ToString(), dataTable5.Rows[0][2].ToString(), DateTime.Today, DateTime.Today.AddDays(-1.0 * Convert.ToDouble(dataTable5.Rows[0][3].ToString())));
								}
								else
								{
									SendMobiles(dataTable5.Rows[0][1].ToString(), dataTable5.Rows[0][2].ToString(), DateTime.Today, DateTime.Today.AddMonths(-1 * Convert.ToInt32(dataTable5.Rows[0][3].ToString())));
								}
								dataTable4.Rows.Add(dataTable5.Rows[0][1].ToString(), dataTable5.Rows[0][2].ToString(), DateTime.Today);
							}
						}
						else
						{
							DataTable dataTable8 = Codes.Search2("select top 1 date from RptSent where MobileID = '" + dataTable5.Rows[0][1].ToString() + "' and RptID = '" + dataTable5.Rows[0][2].ToString() + "' order by date desc");
							DateTime dateToBegin = Convert.ToDateTime(dataTable8.Rows[0][0].ToString());
							DateTime dateTime = ((!(dataTable5.Rows[0][4].ToString() == "يوم")) ? dateToBegin.AddMonths(Convert.ToInt32(dataTable5.Rows[0][3].ToString())) : dateToBegin.AddDays(Convert.ToDouble(dataTable5.Rows[0][3].ToString())));
							SendMobiles(dataTable5.Rows[0][1].ToString(), dataTable5.Rows[0][2].ToString(), dateTime, dateToBegin);
							dataTable4.Rows.Add(dataTable5.Rows[0][1].ToString(), dataTable5.Rows[0][2].ToString(), dateTime);
						}
					}
					if (!(Msg != ""))
					{
						continue;
					}
					using (WebClient webClient = new WebClient())
					{
						using (webClient.OpenRead("http://www.google.com"))
						{
							string requestUriString = SendSms.Send(Username, Password, dataTable2.Rows[i][1].ToString(), Msg, SenderName, API);
							HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(requestUriString);
							using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
							{
								if (httpWebResponse.StatusCode == HttpStatusCode.OK)
								{
									using (httpWebResponse.GetResponseStream())
									{
									}
								}
							}
							for (int k = 0; k < dataTable4.Rows.Count; k++)
							{
								Codes.Add2("insert into RptSent (MobileID, RptID, Date) Values ('" + dataTable4.Rows[k][0].ToString() + "', '" + dataTable4.Rows[k][1].ToString() + "', '" + Convert.ToDateTime(dataTable4.Rows[k][2].ToString()).ToString("MM/dd/yyyy") + "')");
							}
						}
					}
				}
			}
			catch
			{
				Thread.Sleep(60000);
			}
		}

		private void SendMobiles(string MobileID, string rptID, DateTime lastDate, DateTime dateToBegin)
		{
			try
			{
				DataTable dataTable = Codes.Search2("select RptName,RptNameAr from RptsForMobile where ID = '" + rptID + "'");
				string text = dataTable.Rows[0][0].ToString();
				if (Msg != "")
				{
					Msg += "\n";
				}
				if (text == "NetDailyClincRpt")
				{
					decimal num = 0m;
					decimal num2 = 0m;
					decimal num3 = 0m;
					DataTable dataTable2 = Codes.Search2(string.Concat("SELECT isnull(sum(Price),0) as Expenses FROM  StokeMove where (type='حذف كشف' or type='حساب طبيب' or type='مصروفات' or type='فاتورة مشتريات' or type='مدفوعات للمورد' or type='حذف إيرادات أخرى' or type='حذف خدمات و مدفوعات مريض' or type = 'حساب مساعد' or type='تحويل الى خزينة' or type='حذف أشعة') and date = '", DateTime.Now, "'"));
					DataTable dataTable3 = Codes.Search2(string.Concat("select isnull(sum(price),0) as Revenues  from StokeMove where (type != 'حذف كشف' and type!='حساب طبيب' and type!='مصروفات' and type!='فاتورة مشتريات' and type!='مدفوعات للمورد' and type!='حذف إيرادات أخرى' and type!='حذف خدمات و مدفوعات مريض' and type != 'تحويل الى خزينة' and type !='حذف أشعة' and date = '", DateTime.Now, "')"));
					try
					{
						num2 = Convert.ToDecimal(dataTable2.Rows[0][0]);
					}
					catch
					{
					}
					try
					{
						num3 = Convert.ToDecimal(dataTable3.Rows[0][0]);
					}
					catch
					{
					}
					num = num3 - num2;
					Msg = Msg + "إجمالي يومية العيادة: " + Math.Round(num, 2);
				}
			}
			catch
			{
			}
		}

		private void Main_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (RestoreDB || Exit || ForceRestart)
			{
				return;
			}
			switch ((!(DentistClinic.Properties.Settings.Default.Language == "en-GB")) ? MessageBox.Show("يفضل عمل نسخة من قاعدة البيانات قبل الاغلاق", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk) : MessageBox.Show("It is preferable to make a copy of the database before closing", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Asterisk))
			{
			case DialogResult.Yes:
				try
				{
					ServerConnection serverConnection = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName);
					serverConnection.LoginSecure = false;
					serverConnection.Login = DentistClinic.Properties.Settings.Default.UserName;
					serverConnection.Password = DentistClinic.Properties.Settings.Default.Pass;
					serverConnection.DatabaseName = DentistClinic.Properties.Settings.Default.DataBaseName;
					srvSql = new Server(serverConnection);
					if (srvSql != null)
					{
						if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
						{
							DentistClinic.Properties.Settings.Default.Filename = folderBrowserDialog1.SelectedPath;
							DentistClinic.Properties.Settings.Default.Save();
							Backup backup = new Backup();
							backup.BackupSetDescription = "ArchiveDataBase:" + DateTime.Now.ToShortDateString();
							backup.BackupSetName = "Archive";
							backup.Action = BackupActionType.Database;
							backup.Database = DentistClinic.Properties.Settings.Default.DataBaseName;
							string name = DentistClinic.Properties.Settings.Default.Filename + "\\Backup" + DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year + "   " + DateTime.Now.Hour + "-" + DateTime.Now.Minute + "-" + DateTime.Now.Second + ".bak";
							BackupDeviceItem item = new BackupDeviceItem(name, DeviceType.File);
							ServerConnection serverConnection2 = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName, DentistClinic.Properties.Settings.Default.UserName, DentistClinic.Properties.Settings.Default.Pass);
							Server server = new Server(serverConnection2);
							_ = server.Databases[DentistClinic.Properties.Settings.Default.DataBaseName];
							backup.Initialize = true;
							backup.Checksum = true;
							backup.ContinueAfterError = true;
							backup.Devices.Add(item);
							backup.Incremental = false;
							backup.ExpirationDate = DateTime.Now.AddDays(3.0);
							backup.LogTruncation = BackupTruncateLogType.Truncate;
							backup.FormatMedia = false;
							backup.SqlBackup(srvSql);
							MessageBox.Show("Bakup of Database " + DentistClinic.Properties.Settings.Default.DataBaseName + " successfully created", "Server", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else
					{
						MessageBox.Show("A connection to a SQL server was not established.", "Not Connected to Server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
				catch
				{
				}
				break;
			case DialogResult.Cancel:
				e.Cancel = true;
				Exit = true;
				break;
			}
		}

		private void timer2_Tick(object sender, EventArgs e)
		{
			string text = DateTime.Now.ToString("hh:mm");
			try
			{
				if (text == Convert.ToDateTime(BackupDate).ToString("hh:mm"))
				{
					if (srvSql != null)
					{
						Backup backup = new Backup();
						backup.BackupSetDescription = "ArchiveDataBase:" + DateTime.Now.ToShortDateString();
						backup.BackupSetName = "Archive";
						backup.Action = BackupActionType.Database;
						backup.Database = DentistClinic.Properties.Settings.Default.DataBaseName;
						string name = DentistClinic.Properties.Settings.Default.Filename + "\\Backup" + DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year + "   " + DateTime.Now.Hour + "-" + DateTime.Now.Minute + ".bak";
						BackupDeviceItem item = new BackupDeviceItem(name, DeviceType.File);
						ServerConnection serverConnection = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName, DentistClinic.Properties.Settings.Default.UserName, DentistClinic.Properties.Settings.Default.Pass);
						Server server = new Server(serverConnection);
						_ = server.Databases[DentistClinic.Properties.Settings.Default.DataBaseName];
						backup.Initialize = true;
						backup.Checksum = true;
						backup.ContinueAfterError = true;
						backup.Devices.Add(item);
						backup.Incremental = false;
						backup.ExpirationDate = DateTime.Now.AddDays(3.0);
						backup.LogTruncation = BackupTruncateLogType.Truncate;
						backup.FormatMedia = false;
						backup.SqlBackup(srvSql);
					}
					else
					{
						MessageBox.Show("A connection to a SQL server was not established.", "Not Connected to Server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
					timer2.Stop();
					timer2.Enabled = false;
				}
			}
			catch
			{
			}
		}

		private void toolStripMenuItem14_Click(object sender, EventArgs e)
		{
			pediatricfrm pediatricfrm2 = new pediatricfrm("");
			pediatricfrm2.Show();
		}

		private void orthopedicalPhysiotherapyToolStripMenuItem_Click(object sender, EventArgs e)
		{
			OrthopedicalFrm orthopedicalFrm = new OrthopedicalFrm("");
			orthopedicalFrm.Show();
		}

		private void neurologicalPhysiotherapyToolStripMenuItem_Click(object sender, EventArgs e)
		{
			gender gender2 = new gender("");
			gender2.Show();
		}

		private void button1_Click(object sender, EventArgs e)
		{
		}

		private void toolStripMenuItem_12_Click(object sender, EventArgs e)
		{
			NaturalTherapy naturalTherapy = new NaturalTherapy();
			naturalTherapy.Show();
		}

		private void naturaltherapy_Click(object sender, EventArgs e)
		{
		}

		private void panel5_Paint(object sender, PaintEventArgs e)
		{
		}

		private void toolStripMenuItem_13_Click(object sender, EventArgs e)
		{
			GForm1 gForm = new GForm1();
			gForm.Show();
		}

		private void toolStripMenuItem_18_Click(object sender, EventArgs e)
		{
			GForm0 gForm = new GForm0();
			gForm.Show();
		}

		private void button5_Click_2(object sender, EventArgs e)
		{
			FrmCallUs frmCallUs = new FrmCallUs();
			frmCallUs.Show();
		}

		private void button6_Click_2(object sender, EventArgs e)
		{
			Appointmentsp appointmentsp = new Appointmentsp();
			appointmentsp.Show();
		}

		private void button6_MouseHover_1(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				button6.BackgroundImage = Resources.a131;
			}
			else
			{
				button6.BackgroundImage = Resources._4_0000;
			}
		}

		private void button6_MouseLeave_1(object sender, EventArgs e)
		{
			if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
			{
				button6.BackgroundImage = Resources.a13;
			}
			else
			{
				button6.BackgroundImage = Resources._3_0000;
			}
		}

		private void toolStripMenuItem_19_Click(object sender, EventArgs e)
		{
			Form2 form = new Form2("ChangeDataBase");
			form.ShowDialog();
			ForceRestart = true;
		}

		private void label14_Click(object sender, EventArgs e)
		{
		}

		private void label13_Click(object sender, EventArgs e)
		{
			FrmPatientStatmentRPT frmPatientStatmentRPT = new FrmPatientStatmentRPT();
			frmPatientStatmentRPT.Show();
		}

		private void label16_Click(object sender, EventArgs e)
		{
			FrmPatientRebackStatementRPT frmPatientRebackStatementRPT = new FrmPatientRebackStatementRPT();
			frmPatientRebackStatementRPT.Show();
		}

		private void label15_Click(object sender, EventArgs e)
		{
			FrmPatientRebackStatementRPT frmPatientRebackStatementRPT = new FrmPatientRebackStatementRPT();
			frmPatientRebackStatementRPT.Show();
		}

		private void label14_Click_1(object sender, EventArgs e)
		{
			FrmPatientStatmentRPT frmPatientStatmentRPT = new FrmPatientStatmentRPT();
			frmPatientStatmentRPT.Show();
		}

		private void toolStripMenuItem_20_Click(object sender, EventArgs e)
		{
			FrmRptServiceAll frmRptServiceAll = new FrmRptServiceAll();
			frmRptServiceAll.Show();
		}

		private void toolStripMenuItem_21_Click(object sender, EventArgs e)
		{
			FrmSeviceOffers frmSeviceOffers = new FrmSeviceOffers();
			frmSeviceOffers.Show();
		}

		private void toolStripMenuItem_22_Click(object sender, EventArgs e)
		{
			FrmRptStockMoveNew frmRptStockMoveNew = new FrmRptStockMoveNew();
			frmRptStockMoveNew.Show();
		}

		private void toolStripMenuItem_23_Click(object sender, EventArgs e)
		{
			FrmPatientAccounts frmPatientAccounts = new FrmPatientAccounts();
			frmPatientAccounts.Show();
		}

		private void toolStripMenuItem_24_Click(object sender, EventArgs e)
		{
			BeautyClinicRpt beautyClinicRpt = new BeautyClinicRpt();
			beautyClinicRpt.Show();
		}

		private void toolStripMenuItem_25_Click(object sender, EventArgs e)
		{
			FrmOfferRept frmOfferRept = new FrmOfferRept();
			frmOfferRept.Show();
		}

		private void toolStripMenuItem_26_Click(object sender, EventArgs e)
		{
			FrmPaperDiagnostics frmPaperDiagnostics = new FrmPaperDiagnostics();
			frmPaperDiagnostics.Show();
		}

		private void toolStripMenuItem7_Click(object sender, EventArgs e)
		{
		}

		private void toolStripMenuItem_27_Click(object sender, EventArgs e)
		{
			FrmSickLeave frmSickLeave = new FrmSickLeave();
			frmSickLeave.Show();
		}

		private void toolStripMenuItem_28_Click(object sender, EventArgs e)
		{
			FrmSickLeaveRpt frmSickLeaveRpt = new FrmSickLeaveRpt();
			frmSickLeaveRpt.Show();
		}

		private void toolStripMenuItem_29_Click(object sender, EventArgs e)
		{
			FrmAttend frmAttend = new FrmAttend();
			frmAttend.Show();
		}

		private void toolStripMenuItem_30_Click(object sender, EventArgs e)
		{
			FrmAttendRpt frmAttendRpt = new FrmAttendRpt();
			frmAttendRpt.Show();
		}

		private void toolStripMenuItem_31_Click(object sender, EventArgs e)
		{
			PatientConnectRPT patientConnectRPT = new PatientConnectRPT();
			patientConnectRPT.Show();
		}

		private void toolStripMenuItem_32_Click(object sender, EventArgs e)
		{
			UseServiceRptFrm useServiceRptFrm = new UseServiceRptFrm();
			useServiceRptFrm.Show();
		}

		private void PatientBtn_Click(object sender, EventArgs e)
		{

		}

		private void DoctorPatientBtn_Click(object sender, EventArgs e)
		{

		}

		private void SecretaryPatientBtn_Click(object sender, EventArgs e)
		{

		}

		private void toolStripMenuItem2_Click(object sender, EventArgs e)
		{

		}
	}
}
