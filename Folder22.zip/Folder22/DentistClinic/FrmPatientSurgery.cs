using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using FloatTextBox;

namespace DentistClinic
{
	public class FrmPatientSurgery : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private ComboBox comboBox1;

		private NumericUpDown numericUpDown1;

		private ComboBox comboBox2;

		private ComboBox comboBox4;

		private ComboBox comboBox3;

		private TextBox textBox3;

		private TextBox textBox2;

		private TextBox textBox1;

		private ComboBox comboBox7;

		private ComboBox comboBox5;

		private ComboBox comboBox6;

		private GroupBox groupBox2;

		private GroupBox groupBox3;

		private TextBox textBox4;

		private GroupBox groupBox4;

		private Button button1;

		private Button button2;

		private NumericUpDown numericUpDown2;

		private ComboBox comboBox8;

		private DataGridView dataGridView1;

		private DataGridView dataGridView2;

		private Button button3;

		private NumericUpDown numericUpDown3;

		private ComboBox comboBox9;

		private NumericUpDown numericUpDown4;

		private NumericUpDown numericUpDown6;

		private NumericUpDown numericUpDown5;

		private NumericUpDown numericUpDown8;

		private NumericUpDown numericUpDown7;

		private NumericUpDown numericUpDown9;

		private TextBox textBox5;

		private DateTimePicker dateTimePicker1;

		private TextBox textBox6;

		private Button button5;

		private Button button4;

		private Button button6;

		private FloatText numericUpDown10;

		private Button button7;

		private DataGridViewTextBoxColumn ItemName;

		private DataGridViewTextBoxColumn Price;

		private DataGridViewTextBoxColumn Qnt;

		private DataGridViewTextBoxColumn Total;

		private DataGridViewTextBoxColumn PatientID;

		private DataGridViewTextBoxColumn Expense;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;

		private ClassDataBase dc;

		private int ID;

		private bool x = true;

		private decimal discount = 0m;

		private decimal Account = 0m;

		private string operation;

		private GUI gui = new GUI();

		private string companyId = "0";

		private GeneralMethods MethodsClass = new GeneralMethods();

		private dataClass codes = new dataClass(".\\sqlExpress");

		private bool Nesba = false;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmPatientSurgery));
			groupBox1 = new System.Windows.Forms.GroupBox();
			numericUpDown10 = new FloatTextBox.FloatText();
			textBox6 = new System.Windows.Forms.TextBox();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			textBox5 = new System.Windows.Forms.TextBox();
			numericUpDown9 = new System.Windows.Forms.NumericUpDown();
			numericUpDown8 = new System.Windows.Forms.NumericUpDown();
			numericUpDown7 = new System.Windows.Forms.NumericUpDown();
			numericUpDown6 = new System.Windows.Forms.NumericUpDown();
			numericUpDown5 = new System.Windows.Forms.NumericUpDown();
			textBox4 = new System.Windows.Forms.TextBox();
			groupBox3 = new System.Windows.Forms.GroupBox();
			dataGridView2 = new System.Windows.Forms.DataGridView();
			Expense = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			button3 = new System.Windows.Forms.Button();
			numericUpDown3 = new System.Windows.Forms.NumericUpDown();
			comboBox9 = new System.Windows.Forms.ComboBox();
			comboBox4 = new System.Windows.Forms.ComboBox();
			comboBox5 = new System.Windows.Forms.ComboBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			numericUpDown4 = new System.Windows.Forms.NumericUpDown();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			ItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Qnt = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
			PatientID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			numericUpDown2 = new System.Windows.Forms.NumericUpDown();
			button2 = new System.Windows.Forms.Button();
			comboBox8 = new System.Windows.Forms.ComboBox();
			textBox3 = new System.Windows.Forms.TextBox();
			textBox2 = new System.Windows.Forms.TextBox();
			textBox1 = new System.Windows.Forms.TextBox();
			comboBox7 = new System.Windows.Forms.ComboBox();
			comboBox6 = new System.Windows.Forms.ComboBox();
			comboBox3 = new System.Windows.Forms.ComboBox();
			numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			comboBox2 = new System.Windows.Forms.ComboBox();
			comboBox1 = new System.Windows.Forms.ComboBox();
			groupBox4 = new System.Windows.Forms.GroupBox();
			button7 = new System.Windows.Forms.Button();
			button6 = new System.Windows.Forms.Button();
			button5 = new System.Windows.Forms.Button();
			button4 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label7 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label8 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label9 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label10 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label11 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label12 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label13 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label14 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label15 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label16 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label17 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label18 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label19 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label20 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label21 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label22 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label23 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label24 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label25 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label26 = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown9).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown8).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown7).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown6).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown5).BeginInit();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown3).BeginInit();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown4).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
			groupBox4.SuspendLayout();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "label5");
			label.Name = "label5";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label1");
			label2.Name = "label1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label2");
			label3.Name = "label2";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label3");
			label4.Name = "label3";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label4");
			label5.Name = "label4";
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "label6");
			label6.Name = "label6";
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "label7");
			label7.Name = "label7";
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "label8");
			label8.Name = "label8";
			label9.AccessibleDescription = null;
			label9.AccessibleName = null;
			resources.ApplyResources(label9, "label9");
			label9.Name = "label9";
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "label10");
			label10.Name = "label10";
			label11.AccessibleDescription = null;
			label11.AccessibleName = null;
			resources.ApplyResources(label11, "label11");
			label11.Name = "label11";
			label12.AccessibleDescription = null;
			label12.AccessibleName = null;
			resources.ApplyResources(label12, "label12");
			label12.Name = "label12";
			label13.AccessibleDescription = null;
			label13.AccessibleName = null;
			resources.ApplyResources(label13, "label13");
			label13.Name = "label13";
			label14.AccessibleDescription = null;
			label14.AccessibleName = null;
			resources.ApplyResources(label14, "label14");
			label14.Name = "label14";
			label15.AccessibleDescription = null;
			label15.AccessibleName = null;
			resources.ApplyResources(label15, "label15");
			label15.Name = "label15";
			label16.AccessibleDescription = null;
			label16.AccessibleName = null;
			resources.ApplyResources(label16, "label16");
			label16.Name = "label16";
			label17.AccessibleDescription = null;
			label17.AccessibleName = null;
			resources.ApplyResources(label17, "label17");
			label17.Name = "label17";
			label18.AccessibleDescription = null;
			label18.AccessibleName = null;
			resources.ApplyResources(label18, "label18");
			label18.Name = "label18";
			label19.AccessibleDescription = null;
			label19.AccessibleName = null;
			resources.ApplyResources(label19, "label19");
			label19.Name = "label19";
			label20.AccessibleDescription = null;
			label20.AccessibleName = null;
			resources.ApplyResources(label20, "label20");
			label20.Name = "label20";
			label21.AccessibleDescription = null;
			label21.AccessibleName = null;
			resources.ApplyResources(label21, "label21");
			label21.Name = "label21";
			label22.AccessibleDescription = null;
			label22.AccessibleName = null;
			resources.ApplyResources(label22, "label22");
			label22.Name = "label22";
			label23.AccessibleDescription = null;
			label23.AccessibleName = null;
			resources.ApplyResources(label23, "label23");
			label23.Name = "label23";
			label24.AccessibleDescription = null;
			label24.AccessibleName = null;
			resources.ApplyResources(label24, "label24");
			label24.Name = "label24";
			label25.AccessibleDescription = null;
			label25.AccessibleName = null;
			resources.ApplyResources(label25, "label25");
			label25.Name = "label25";
			label26.AccessibleDescription = null;
			label26.AccessibleName = null;
			resources.ApplyResources(label26, "label26");
			label26.Name = "label26";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(numericUpDown10);
			groupBox1.Controls.Add(label26);
			groupBox1.Controls.Add(textBox6);
			groupBox1.Controls.Add(dateTimePicker1);
			groupBox1.Controls.Add(label25);
			groupBox1.Controls.Add(textBox5);
			groupBox1.Controls.Add(label);
			groupBox1.Controls.Add(numericUpDown9);
			groupBox1.Controls.Add(label24);
			groupBox1.Controls.Add(label22);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(numericUpDown8);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(numericUpDown7);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(numericUpDown6);
			groupBox1.Controls.Add(label23);
			groupBox1.Controls.Add(label19);
			groupBox1.Controls.Add(label7);
			groupBox1.Controls.Add(numericUpDown5);
			groupBox1.Controls.Add(label8);
			groupBox1.Controls.Add(label18);
			groupBox1.Controls.Add(label9);
			groupBox1.Controls.Add(textBox4);
			groupBox1.Controls.Add(label10);
			groupBox1.Controls.Add(groupBox3);
			groupBox1.Controls.Add(label21);
			groupBox1.Controls.Add(comboBox4);
			groupBox1.Controls.Add(label11);
			groupBox1.Controls.Add(comboBox5);
			groupBox1.Controls.Add(label5);
			groupBox1.Controls.Add(groupBox2);
			groupBox1.Controls.Add(label20);
			groupBox1.Controls.Add(textBox3);
			groupBox1.Controls.Add(label6);
			groupBox1.Controls.Add(textBox2);
			groupBox1.Controls.Add(label12);
			groupBox1.Controls.Add(textBox1);
			groupBox1.Controls.Add(comboBox7);
			groupBox1.Controls.Add(comboBox6);
			groupBox1.Controls.Add(comboBox3);
			groupBox1.Controls.Add(numericUpDown1);
			groupBox1.Controls.Add(comboBox2);
			groupBox1.Controls.Add(comboBox1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			numericUpDown10.AccessibleDescription = null;
			numericUpDown10.AccessibleName = null;
			resources.ApplyResources(numericUpDown10, "numericUpDown10");
			numericUpDown10.BackgroundImage = null;
			numericUpDown10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			numericUpDown10.Font = null;
			numericUpDown10.Name = "numericUpDown10";
			numericUpDown10.TextChanged += new System.EventHandler(numericUpDown10_TextChanged);
			textBox6.AccessibleDescription = null;
			textBox6.AccessibleName = null;
			resources.ApplyResources(textBox6, "textBox6");
			textBox6.BackgroundImage = null;
			textBox6.Font = null;
			textBox6.Name = "textBox6";
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.CustomFormat = null;
			dateTimePicker1.Font = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			dateTimePicker1.Name = "dateTimePicker1";
			textBox5.AccessibleDescription = null;
			textBox5.AccessibleName = null;
			resources.ApplyResources(textBox5, "textBox5");
			textBox5.BackgroundImage = null;
			textBox5.Font = null;
			textBox5.Name = "textBox5";
			numericUpDown9.AccessibleDescription = null;
			numericUpDown9.AccessibleName = null;
			resources.ApplyResources(numericUpDown9, "numericUpDown9");
			numericUpDown9.BackColor = System.Drawing.Color.White;
			numericUpDown9.DecimalPlaces = 2;
			numericUpDown9.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			numericUpDown9.Name = "numericUpDown9";
			numericUpDown9.ValueChanged += new System.EventHandler(numericUpDown1_ValueChanged);
			numericUpDown8.AccessibleDescription = null;
			numericUpDown8.AccessibleName = null;
			resources.ApplyResources(numericUpDown8, "numericUpDown8");
			numericUpDown8.BackColor = System.Drawing.Color.White;
			numericUpDown8.DecimalPlaces = 2;
			numericUpDown8.Font = null;
			numericUpDown8.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			numericUpDown8.Name = "numericUpDown8";
			numericUpDown8.ValueChanged += new System.EventHandler(numericUpDown1_ValueChanged);
			numericUpDown7.AccessibleDescription = null;
			numericUpDown7.AccessibleName = null;
			resources.ApplyResources(numericUpDown7, "numericUpDown7");
			numericUpDown7.BackColor = System.Drawing.Color.White;
			numericUpDown7.DecimalPlaces = 2;
			numericUpDown7.Font = null;
			numericUpDown7.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			numericUpDown7.Name = "numericUpDown7";
			numericUpDown7.ValueChanged += new System.EventHandler(numericUpDown1_ValueChanged);
			numericUpDown6.AccessibleDescription = null;
			numericUpDown6.AccessibleName = null;
			resources.ApplyResources(numericUpDown6, "numericUpDown6");
			numericUpDown6.BackColor = System.Drawing.Color.White;
			numericUpDown6.DecimalPlaces = 2;
			numericUpDown6.Font = null;
			numericUpDown6.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			numericUpDown6.Name = "numericUpDown6";
			numericUpDown5.AccessibleDescription = null;
			numericUpDown5.AccessibleName = null;
			resources.ApplyResources(numericUpDown5, "numericUpDown5");
			numericUpDown5.BackColor = System.Drawing.Color.White;
			numericUpDown5.DecimalPlaces = 2;
			numericUpDown5.Font = null;
			numericUpDown5.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			numericUpDown5.Name = "numericUpDown5";
			textBox4.AccessibleDescription = null;
			textBox4.AccessibleName = null;
			resources.ApplyResources(textBox4, "textBox4");
			textBox4.BackColor = System.Drawing.Color.White;
			textBox4.BackgroundImage = null;
			textBox4.Font = null;
			textBox4.Name = "textBox4";
			textBox4.ReadOnly = true;
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(dataGridView2);
			groupBox3.Controls.Add(button3);
			groupBox3.Controls.Add(numericUpDown3);
			groupBox3.Controls.Add(label15);
			groupBox3.Controls.Add(label16);
			groupBox3.Controls.Add(comboBox9);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			dataGridView2.AccessibleDescription = null;
			dataGridView2.AccessibleName = null;
			dataGridView2.AllowUserToAddRows = false;
			resources.ApplyResources(dataGridView2, "dataGridView2");
			dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView2.BackgroundImage = null;
			dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView2.Columns.AddRange(Expense, dataGridViewTextBoxColumn1);
			dataGridView2.Font = null;
			dataGridView2.Name = "dataGridView2";
			dataGridView2.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(dataGridView2_RowsAdded);
			dataGridView2.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(dataGridView2_RowsRemoved);
			resources.ApplyResources(Expense, "Expense");
			Expense.Name = "Expense";
			Expense.ReadOnly = true;
			resources.ApplyResources(dataGridViewTextBoxColumn1, "dataGridViewTextBoxColumn1");
			dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			dataGridViewTextBoxColumn1.ReadOnly = true;
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackgroundImage = null;
			button3.Font = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			numericUpDown3.AccessibleDescription = null;
			numericUpDown3.AccessibleName = null;
			resources.ApplyResources(numericUpDown3, "numericUpDown3");
			numericUpDown3.DecimalPlaces = 2;
			numericUpDown3.Font = null;
			numericUpDown3.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			numericUpDown3.Name = "numericUpDown3";
			comboBox9.AccessibleDescription = null;
			comboBox9.AccessibleName = null;
			resources.ApplyResources(comboBox9, "comboBox9");
			comboBox9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox9.BackgroundImage = null;
			comboBox9.Font = null;
			comboBox9.FormattingEnabled = true;
			comboBox9.Name = "comboBox9";
			comboBox4.AccessibleDescription = null;
			comboBox4.AccessibleName = null;
			resources.ApplyResources(comboBox4, "comboBox4");
			comboBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox4.BackgroundImage = null;
			comboBox4.Font = null;
			comboBox4.FormattingEnabled = true;
			comboBox4.Name = "comboBox4";
			comboBox5.AccessibleDescription = null;
			comboBox5.AccessibleName = null;
			resources.ApplyResources(comboBox5, "comboBox5");
			comboBox5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox5.BackgroundImage = null;
			comboBox5.Font = null;
			comboBox5.FormattingEnabled = true;
			comboBox5.Name = "comboBox5";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(numericUpDown4);
			groupBox2.Controls.Add(dataGridView1);
			groupBox2.Controls.Add(numericUpDown2);
			groupBox2.Controls.Add(button2);
			groupBox2.Controls.Add(label17);
			groupBox2.Controls.Add(comboBox8);
			groupBox2.Controls.Add(label14);
			groupBox2.Controls.Add(label13);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			numericUpDown4.AccessibleDescription = null;
			numericUpDown4.AccessibleName = null;
			resources.ApplyResources(numericUpDown4, "numericUpDown4");
			numericUpDown4.DecimalPlaces = 2;
			numericUpDown4.Font = null;
			numericUpDown4.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			numericUpDown4.Name = "numericUpDown4";
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(ItemName, Price, Qnt, Total, PatientID);
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(dataGridView1_RowsAdded);
			dataGridView1.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(dataGridView1_RowsRemoved);
			resources.ApplyResources(ItemName, "ItemName");
			ItemName.Name = "ItemName";
			ItemName.ReadOnly = true;
			resources.ApplyResources(Price, "Price");
			Price.Name = "Price";
			Price.ReadOnly = true;
			resources.ApplyResources(Qnt, "Qnt");
			Qnt.Name = "Qnt";
			Qnt.ReadOnly = true;
			resources.ApplyResources(Total, "Total");
			Total.Name = "Total";
			Total.ReadOnly = true;
			resources.ApplyResources(PatientID, "PatientID");
			PatientID.Name = "PatientID";
			numericUpDown2.AccessibleDescription = null;
			numericUpDown2.AccessibleName = null;
			resources.ApplyResources(numericUpDown2, "numericUpDown2");
			numericUpDown2.DecimalPlaces = 2;
			numericUpDown2.Font = null;
			numericUpDown2.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			numericUpDown2.Name = "numericUpDown2";
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			comboBox8.AccessibleDescription = null;
			comboBox8.AccessibleName = null;
			resources.ApplyResources(comboBox8, "comboBox8");
			comboBox8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox8.BackgroundImage = null;
			comboBox8.Font = null;
			comboBox8.FormattingEnabled = true;
			comboBox8.Name = "comboBox8";
			comboBox8.SelectedIndexChanged += new System.EventHandler(comboBox8_SelectedIndexChanged);
			textBox3.AccessibleDescription = null;
			textBox3.AccessibleName = null;
			resources.ApplyResources(textBox3, "textBox3");
			textBox3.BackgroundImage = null;
			textBox3.Font = null;
			textBox3.Name = "textBox3";
			textBox2.AccessibleDescription = null;
			textBox2.AccessibleName = null;
			resources.ApplyResources(textBox2, "textBox2");
			textBox2.BackgroundImage = null;
			textBox2.Font = null;
			textBox2.Name = "textBox2";
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Font = null;
			textBox1.Name = "textBox1";
			comboBox7.AccessibleDescription = null;
			comboBox7.AccessibleName = null;
			resources.ApplyResources(comboBox7, "comboBox7");
			comboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox7.BackgroundImage = null;
			comboBox7.Font = null;
			comboBox7.FormattingEnabled = true;
			comboBox7.Name = "comboBox7";
			comboBox6.AccessibleDescription = null;
			comboBox6.AccessibleName = null;
			resources.ApplyResources(comboBox6, "comboBox6");
			comboBox6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox6.BackgroundImage = null;
			comboBox6.Font = null;
			comboBox6.FormattingEnabled = true;
			comboBox6.Name = "comboBox6";
			comboBox3.AccessibleDescription = null;
			comboBox3.AccessibleName = null;
			resources.ApplyResources(comboBox3, "comboBox3");
			comboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox3.BackgroundImage = null;
			comboBox3.Font = null;
			comboBox3.FormattingEnabled = true;
			comboBox3.Name = "comboBox3";
			numericUpDown1.AccessibleDescription = null;
			numericUpDown1.AccessibleName = null;
			resources.ApplyResources(numericUpDown1, "numericUpDown1");
			numericUpDown1.DecimalPlaces = 2;
			numericUpDown1.Font = null;
			numericUpDown1.Maximum = new decimal(new int[4] { -727379969, 232, 0, 0 });
			numericUpDown1.Name = "numericUpDown1";
			numericUpDown1.ValueChanged += new System.EventHandler(numericUpDown1_ValueChanged);
			comboBox2.AccessibleDescription = null;
			comboBox2.AccessibleName = null;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.BackgroundImage = null;
			comboBox2.Font = null;
			comboBox2.FormattingEnabled = true;
			comboBox2.Name = "comboBox2";
			comboBox2.SelectedIndexChanged += new System.EventHandler(comboBox2_SelectedIndexChanged);
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.Font = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Name = "comboBox1";
			comboBox1.SelectedIndexChanged += new System.EventHandler(comboBox1_SelectedIndexChanged);
			comboBox1.TextChanged += new System.EventHandler(comboBox1_TextChanged);
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(button7);
			groupBox4.Controls.Add(button6);
			groupBox4.Controls.Add(button5);
			groupBox4.Controls.Add(button4);
			groupBox4.Controls.Add(button1);
			groupBox4.Font = null;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			button7.AccessibleDescription = null;
			button7.AccessibleName = null;
			resources.ApplyResources(button7, "button7");
			button7.BackgroundImage = null;
			button7.Font = null;
			button7.Name = "button7";
			button7.UseVisualStyleBackColor = true;
			button7.Click += new System.EventHandler(button7_Click);
			button6.AccessibleDescription = null;
			button6.AccessibleName = null;
			resources.ApplyResources(button6, "button6");
			button6.BackgroundImage = null;
			button6.Font = null;
			button6.Name = "button6";
			button6.UseVisualStyleBackColor = true;
			button6.Click += new System.EventHandler(button6_Click);
			button5.AccessibleDescription = null;
			button5.AccessibleName = null;
			resources.ApplyResources(button5, "button5");
			button5.BackgroundImage = null;
			button5.Font = null;
			button5.Name = "button5";
			button5.UseVisualStyleBackColor = true;
			button5.Click += new System.EventHandler(button5_Click);
			button4.AccessibleDescription = null;
			button4.AccessibleName = null;
			resources.ApplyResources(button4, "button4");
			button4.BackgroundImage = null;
			button4.Font = null;
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = true;
			button4.Click += new System.EventHandler(button4_Click);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox4);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FrmPatientSurgery";
			base.Load += new System.EventHandler(FrmPatientSurgery_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown9).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown8).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown7).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown6).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown5).EndInit();
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown3).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown4).EndInit();
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
			groupBox4.ResumeLayout(false);
			ResumeLayout(false);
		}

		public FrmPatientSurgery()
		{
			InitializeComponent();
		}

		private void FrmPatientSurgery_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select isnull(max(id),0)+1 from dbo.PatientSurgery");
				textBox4.Text = dataTable.Rows[0][0].ToString();
				try
				{
					if (Convert.ToBoolean(codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString()))
					{
						DataTable dataTable2 = codes.Search2("SELECT     ID, PName FROM         PatientData where Active = 'True' order by PName");
						comboBox1.DataSource = dataTable2;
						comboBox1.DisplayMember = dataTable2.Columns[1].ToString();
						comboBox1.ValueMember = dataTable2.Columns[0].ToString();
					}
					else
					{
						DataTable dt = dc.Select("SelectAllPatient");
						gui.loadComboBox(comboBox1, dt);
					}
				}
				catch
				{
				}
				DataTable dataSource = codes.Search2("select ID, Name from Surgery");
				comboBox2.DataSource = dataSource;
				comboBox2.DisplayMember = "Name";
				comboBox2.ValueMember = "ID";
				comboBox2.SelectedIndex = -1;
				DataTable dataSource2 = codes.Search2("select distinct AnesthesiaType from PatientSurgery");
				comboBox3.DataSource = dataSource2;
				comboBox3.DisplayMember = "AnesthesiaType";
				comboBox3.ValueMember = "AnesthesiaType";
				DataTable dataSource3 = codes.Search2("select distinct Anesthetist from PatientSurgery");
				comboBox4.DataSource = dataSource3;
				comboBox4.DisplayMember = "Anesthetist";
				comboBox4.ValueMember = "Anesthetist";
				DataTable dataSource4 = codes.Search2("SELECT ID, Name FROM Empdata WHERE (Designation = N'Doctor')");
				comboBox6.DataSource = dataSource4;
				comboBox6.DisplayMember = "Name";
				comboBox6.ValueMember = "ID";
				comboBox6.SelectedIndex = -1;
				DataTable dataSource5 = codes.Search2("select distinct AssistantDoctor from PatientSurgery");
				comboBox5.DataSource = dataSource5;
				comboBox5.DisplayMember = "AssistantDoctor";
				comboBox5.ValueMember = "AssistantDoctor";
				DataTable dataSource6 = codes.Search2("select distinct Nurse from PatientSurgery");
				comboBox7.DataSource = dataSource6;
				comboBox7.DisplayMember = "Nurse";
				comboBox7.ValueMember = "Nurse";
				DataTable dataSource7 = codes.Search2("select ID, Name from Items");
				comboBox8.DataSource = dataSource7;
				comboBox8.DisplayMember = "Name";
				comboBox8.ValueMember = "ID";
				comboBox8.SelectedIndex = -1;
				DataTable dataSource8 = codes.Search2("select distinct Expense from SurgeryExpenses");
				comboBox9.DataSource = dataSource8;
				comboBox9.DisplayMember = "Expense";
				comboBox9.ValueMember = "Expense";
				comboBox9.Text = "";
				button7.Enabled = Convert.ToBoolean(codes.Search2("select * from users where userId = '" + Main.userId + "'").Rows[0]["FrmPropertiesBtn"].ToString());
				button5.Enabled = Convert.ToBoolean(codes.Search2("select updateSurgery from users where userId = '" + Main.userId + "'").Rows[0][0].ToString());
				x = Convert.ToBoolean(codes.Search2("select CalSurgery from Properties").Rows[0][0].ToString());
				numericUpDown1.Enabled = UsersClass.ChangeServicePrice;
				numericUpDown4.Enabled = UsersClass.ChangeServicePrice;
			}
			catch
			{
			}
		}

		private void Clear()
		{
			DataTable dataTable = codes.Search2("select isnull(max(id),0)+1 from dbo.PatientSurgery");
			textBox4.Text = dataTable.Rows[0][0].ToString();
			textBox1.Text = "";
			textBox3.Text = "";
			textBox4.Text = "";
			comboBox1.SelectedIndex = 0;
			comboBox2.SelectedIndex = 0;
			comboBox3.SelectedIndex = 0;
			comboBox4.SelectedIndex = 0;
			comboBox5.SelectedIndex = 0;
			comboBox6.SelectedIndex = 0;
			comboBox7.SelectedIndex = 0;
			comboBox8.SelectedIndex = 0;
			comboBox9.SelectedIndex = 0;
			dataGridView1.Rows.Clear();
			dataGridView2.Rows.Clear();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (comboBox1.SelectedIndex == -1)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("please Enter Patient name");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم المريض");
				}
				return;
			}
			if (comboBox2.SelectedIndex == -1)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("please Enter Surgery name");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم العملية");
				}
				return;
			}
			if (comboBox6.SelectedIndex == -1)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("please Enter Surgery Doctor");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم طبيب العملية");
				}
				return;
			}
			try
			{
				string text = codes.Search2(string.Concat("insert into PatientSurgery (PatientID, SurgeryID, SurgeryCost, AnesthesiaType, Anesthetist, Doctor, AssistantDoctor, Nurse, Findings, Complications, Procedures, TotalItems, TotalExpenses, TotalCost,Date,Diagnosis,Notes,HotelServices)  Values ('", comboBox1.SelectedValue, "', '", comboBox2.SelectedValue, "', '", numericUpDown1.Value, "', '", comboBox3.Text, "', '", comboBox4.Text, "', '", comboBox6.SelectedValue, "', '", comboBox5.Text, "', '", comboBox7.Text, "', '", textBox1.Text, "', '", textBox2.Text, "', '", textBox3.Text, "', '", numericUpDown7.Value, "', '", numericUpDown8.Value, "', '", numericUpDown9.Value, "','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "','", textBox5.Text, "','", textBox6.Text, "', '", numericUpDown10.Text, "');select @@identity")).Rows[0][0].ToString();
				string value = codes.Search("select isnull(sum(Madeen),0) -  isnull(sum(Daen),0) from Company5 where CompanyId = '" + companyId + "'").Rows[0][0].ToString();
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					codes.Add2("insert into SurgeryItems (SurgeryID, ItemID, Qnt, Price, total) Values ('" + text + "', '" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[1].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[3].Value.ToString() + "')");
					codes.Add2("insert into SahbItem(TypeSahb,ItemId,Qty,Date,Notes) values('سحب عمليات','" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','عملية رقم'+'" + textBox4.Text + "')");
					decimal num = 0m;
					try
					{
						DataTable dataTable = codes.Search2("select Qnt from store where ItemID='" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "'");
						num = Convert.ToDecimal(dataTable.Rows[0][0].ToString());
					}
					catch
					{
					}
					decimal num2 = 0m;
					try
					{
						DataTable dataTable2 = codes.Search2("select BuyPrice from store where ItemID='" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "'");
						num2 = Convert.ToDecimal(dataTable2.Rows[0][0].ToString());
					}
					catch
					{
					}
					decimal num3 = 0m;
					try
					{
						DataTable dataTable3 = codes.Search2("select SalePrice from Items where ID='" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "'");
						num3 = Convert.ToDecimal(dataTable3.Rows[0][0].ToString());
					}
					catch
					{
					}
					codes.Add2("INSERT INTO ItemsMove\r\n                      (ItemId, StoreId, IncomeQnt, IncomePrice, OutcomeQnt, OutcomePrice, LastQnt, LastIncomePrice, LastOutComePrice, Bayan, MoveDate, UserId, Time,Type)\r\n                       VALUES ('" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "',0,0,0,'" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[1].Value.ToString() + "','" + num + "','" + num2 + "','" + num3 + "','سحب عمليات إجراء عملية " + comboBox2.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Main.userId + "','" + dateTimePicker1.Value.ToShortTimeString() + "','خروج')");
					codes.Edit2("update store set Qnt = Qnt - " + dataGridView1.Rows[i].Cells[2].Value.ToString() + " where ItemID = '" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "'");
				}
				for (int i = 0; i < dataGridView2.Rows.Count; i++)
				{
					codes.Add2("insert into SurgeryExpenses (SurgeryID, Expense, ExpenseValue) values ('" + text + "','" + dataGridView2.Rows[i].Cells[0].Value.ToString() + "', '" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "')");
				}
				string value2 = codes.Search2(string.Concat("insert into PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay, BeanDate) Values ('", comboBox1.SelectedValue, "', '", comboBox6.SelectedValue, "', 'إجراء عملية ", comboBox2.Text, "', '", numericUpDown9.Value, "', 0, '", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "', 0, '", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "');select @@identity")).Rows[0][0].ToString();
				if (Account != 0m)
				{
					codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + Account + "','" + (Convert.ToDouble(value) + Convert.ToDouble(Account)) + "','إجراء عملية " + comboBox2.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(value2) + "')");
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Have Been Saved");
				}
				else
				{
					MessageBox.Show("تم حفظ البيانات بنجاح");
				}
				MethodsClass.UserMove("أضافة عملية لمريض");
				frmRptPatientSurgery frmRptPatientSurgery2 = new frmRptPatientSurgery(Convert.ToInt32(comboBox1.SelectedValue.ToString()), Convert.ToInt32(text));
				frmRptPatientSurgery2.Show();
				clear();
			}
			catch
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Error Happend While Saving");
				}
				else
				{
					MessageBox.Show("حدث خطأ أثناء حفظ البيانات");
				}
			}
		}

		private void numericUpDown1_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				if (!x)
				{
					numericUpDown9.Value = numericUpDown8.Value + numericUpDown7.Value + numericUpDown1.Value + Convert.ToDecimal(numericUpDown10.Text);
				}
				else
				{
					numericUpDown9.Value = numericUpDown8.Value + numericUpDown1.Value + Convert.ToDecimal(numericUpDown10.Text);
				}
			}
			catch
			{
			}
		}

		private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
		{
			companyId = "0";
			numericUpDown1.Value = 0m;
			try
			{
				companyId = codes.Search2("select company from PatientData where  PName = '" + comboBox1.Text + "'").Rows[0][0].ToString();
			}
			catch
			{
			}
			try
			{
				numericUpDown1.Value = Convert.ToDecimal(codes.Search2(string.Concat("select Price from Surgery where ID = '", comboBox2.SelectedValue, "'")).Rows[0][0].ToString());
				if (Nesba)
				{
					Account = numericUpDown1.Value * discount / 100m;
				}
				else
				{
					Account = discount;
				}
				numericUpDown1.Value -= Account;
			}
			catch
			{
			}
		}

		private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				numericUpDown4.Value = Convert.ToDecimal(codes.Search2(string.Concat("select SalePrice from Items where ID = '", comboBox8.SelectedValue, "'")).Rows[0][0].ToString());
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				if (comboBox8.SelectedIndex == -1)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("please Enter Item name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الصنف");
					}
					return;
				}
				DataTable dataTable = codes.Search2("select Qnt from store where ItemId = '" + comboBox8.SelectedValue.ToString() + "'");
				decimal num = Convert.ToDecimal(dataTable.Rows[0][0].ToString());
				if (numericUpDown2.Value > num)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("The required quantity is greater than the quantity in the store");
					}
					else
					{
						MessageBox.Show("الكمية المطلوبة أكبر من الكمية الموجودة فى المخزن");
					}
					return;
				}
				if (dataGridView1.Rows.Count == 0)
				{
					if (numericUpDown2.Value > num)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("The required quantity is greater than the quantity in the store");
						}
						else
						{
							MessageBox.Show("الكمية المطلوبة أكبر من الكمية الموجودة فى المخزن");
						}
						return;
					}
					dataGridView1.Rows.Add(comboBox8.Text, numericUpDown4.Value, numericUpDown2.Value, numericUpDown4.Value * numericUpDown2.Value, comboBox8.SelectedValue);
					comboBox8.SelectedIndex = -1;
					numericUpDown4.Value = 0m;
					numericUpDown2.Value = 0m;
					return;
				}
				int num2 = 0;
				while (true)
				{
					if (num2 >= dataGridView1.Rows.Count)
					{
						return;
					}
					string text = comboBox8.Text;
					string value = dataGridView1.Rows[num2].Cells[0].Value.ToString();
					if (text.Equals(value))
					{
						if (!(numericUpDown2.Value + Convert.ToDecimal(dataGridView1.Rows[num2].Cells[2].Value.ToString()) > num))
						{
							dataGridView1.Rows[num2].Cells[2].Value = Convert.ToDecimal(dataGridView1.Rows[num2].Cells[2].Value.ToString()) + numericUpDown2.Value;
							dataGridView1.Rows[num2].Cells[3].Value = numericUpDown4.Value * numericUpDown2.Value + Convert.ToDecimal(dataGridView1.Rows[num2].Cells[3].Value.ToString());
							numericUpDown5.Value = Convert.ToDecimal(dataGridView1.Rows[num2].Cells[1].Value.ToString()) + numericUpDown5.Value;
							comboBox8.SelectedIndex = -1;
							numericUpDown4.Value = 0m;
							numericUpDown2.Value = 0m;
							return;
						}
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("The required quantity is greater than the quantity in the store");
						}
						else
						{
							MessageBox.Show("الكمية المطلوبة أكبر من الكمية الموجودة فى المخزن");
						}
					}
					else if (num2 == dataGridView1.Rows.Count - 1)
					{
						break;
					}
					num2++;
				}
				dataGridView1.Rows.Add(comboBox8.Text, numericUpDown4.Value, numericUpDown2.Value, numericUpDown4.Value * numericUpDown2.Value, comboBox8.SelectedValue);
				comboBox8.SelectedIndex = -1;
				numericUpDown4.Value = 0m;
				numericUpDown2.Value = 0m;
			}
			catch
			{
			}
		}

		private void dataGridView1_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
			try
			{
				decimal value = 0m;
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					value += Convert.ToDecimal(dataGridView1.Rows[i].Cells[3].Value.ToString());
				}
				numericUpDown5.Value = value;
				numericUpDown7.Value = value;
			}
			catch
			{
			}
		}

		private void dataGridView1_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
		{
			try
			{
				decimal value = 0m;
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					value += Convert.ToDecimal(dataGridView1.Rows[i].Cells[3].Value.ToString());
				}
				numericUpDown5.Value = value;
				numericUpDown7.Value = value;
			}
			catch
			{
			}
		}

		private void dataGridView2_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
		{
			try
			{
				decimal value = 0m;
				for (int i = 0; i < dataGridView2.Rows.Count; i++)
				{
					value += Convert.ToDecimal(dataGridView2.Rows[i].Cells[1].Value.ToString());
				}
				numericUpDown6.Value = value;
				numericUpDown8.Value = value;
			}
			catch
			{
			}
		}

		private void dataGridView2_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
			try
			{
				decimal value = 0m;
				for (int i = 0; i < dataGridView2.Rows.Count; i++)
				{
					value += Convert.ToDecimal(dataGridView2.Rows[i].Cells[1].Value.ToString());
				}
				numericUpDown6.Value = value;
				numericUpDown8.Value = value;
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				if (comboBox9.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Expense");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المصروف");
					}
					return;
				}
				if (dataGridView2.Rows.Count == 0)
				{
					dataGridView2.Rows.Add(comboBox9.Text, numericUpDown3.Value);
					comboBox9.Text = "";
					numericUpDown3.Value = 0m;
					return;
				}
				int num = 0;
				while (true)
				{
					if (num >= dataGridView2.Rows.Count)
					{
						return;
					}
					string text = comboBox9.Text;
					string value = dataGridView2.Rows[num].Cells[0].Value.ToString();
					if (!text.Equals(value))
					{
						if (num == dataGridView2.Rows.Count - 1)
						{
							break;
						}
						num++;
						continue;
					}
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Entered This Expense Before");
					}
					else
					{
						MessageBox.Show("هذا المصروف تم ادخاله من قبل");
					}
					comboBox9.Text = "";
					numericUpDown3.Value = 0m;
					return;
				}
				dataGridView2.Rows.Add(comboBox9.Text, numericUpDown3.Value);
				comboBox9.Text = "";
				numericUpDown3.Value = 0m;
			}
			catch
			{
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				if (Settings.Default.Language == "en-GB")
				{
					dataTable = codes.Search2("select * from PatientSurgery where ID =  '" + codes.SearchText("Search with Surgery Number") + "'");
					MessageBox.Show("please Enter Surgery Doctor");
				}
				else
				{
					dataTable = codes.Search2("select * from PatientSurgery where ID =  '" + codes.SearchText("بحث برقم العملية") + "'");
				}
				if (dataTable.Rows.Count <= 0)
				{
					return;
				}
				companyId = "0";
				button1.Enabled = false;
				button4.Enabled = true;
				textBox4.Text = dataTable.Rows[0][0].ToString();
				dateTimePicker1.Value = Convert.ToDateTime(dataTable.Rows[0][15].ToString());
				comboBox1.SelectedValue = Convert.ToInt32(dataTable.Rows[0]["PatientID"].ToString());
				textBox5.Text = dataTable.Rows[0]["Diagnosis"].ToString();
				comboBox2.SelectedValue = Convert.ToInt32(dataTable.Rows[0]["SurgeryID"].ToString());
				operation = comboBox2.Text;
				numericUpDown1.Value = Convert.ToDecimal(dataTable.Rows[0]["SurgeryCost"].ToString());
				comboBox3.Text = dataTable.Rows[0]["AnesthesiaType"].ToString();
				comboBox4.Text = dataTable.Rows[0]["Anesthetist"].ToString();
				comboBox6.SelectedValue = Convert.ToInt32(dataTable.Rows[0]["Doctor"].ToString());
				comboBox5.Text = dataTable.Rows[0]["AssistantDoctor"].ToString();
				comboBox7.Text = dataTable.Rows[0]["Nurse"].ToString();
				textBox1.Text = dataTable.Rows[0]["Findings"].ToString();
				textBox2.Text = dataTable.Rows[0]["Complications"].ToString();
				textBox3.Text = dataTable.Rows[0]["Procedures"].ToString();
				textBox6.Text = dataTable.Rows[0]["Notes"].ToString();
				numericUpDown10.Text = dataTable.Rows[0]["HotelServices"].ToString();
				numericUpDown7.Value = Convert.ToDecimal(dataTable.Rows[0]["TotalItems"].ToString());
				numericUpDown8.Value = Convert.ToDecimal(dataTable.Rows[0]["TotalExpenses"].ToString());
				numericUpDown9.Value = Convert.ToDecimal(dataTable.Rows[0]["TotalCost"].ToString());
				decimal value = 0m;
				decimal value2 = 0m;
				DataTable dataTable2 = codes.Search2("SELECT dbo.Items.Name, dbo.SurgeryItems.Price, dbo.SurgeryItems.Qnt, dbo.SurgeryItems.Total,dbo.SurgeryItems.ItemID FROM dbo.Items INNER JOIN dbo.SurgeryItems ON dbo.Items.Id = dbo.SurgeryItems.ItemID where dbo.SurgeryItems.SurgeryID = '" + textBox4.Text + "'");
				if (dataTable2.Rows.Count > 0)
				{
					for (int i = 0; i < dataTable2.Rows.Count; i++)
					{
						dataGridView1.Rows.Add();
						dataGridView1.Rows[i].Cells[0].Value = dataTable2.Rows[i][0].ToString();
						dataGridView1.Rows[i].Cells[1].Value = Convert.ToDecimal(dataTable2.Rows[i][1].ToString());
						dataGridView1.Rows[i].Cells[2].Value = Convert.ToDecimal(dataTable2.Rows[i][2].ToString());
						dataGridView1.Rows[i].Cells[4].Value = Convert.ToInt32(dataTable2.Rows[i][4].ToString());
						dataGridView1.Rows[i].Cells[3].Value = Convert.ToDecimal(dataTable2.Rows[i][3].ToString());
						value += Convert.ToDecimal(dataGridView1.Rows[i].Cells[3].Value);
					}
					numericUpDown5.Value = value;
				}
				else
				{
					dataGridView1.Rows.Clear();
				}
				DataTable dataTable3 = codes.Search2("SELECT Expense,ExpenseValue FROM SurgeryExpenses where SurgeryID = '" + textBox4.Text + "'");
				if (dataTable3.Rows.Count > 0)
				{
					for (int i = 0; i < dataTable3.Rows.Count; i++)
					{
						dataGridView2.Rows.Add();
						dataGridView2.Rows[i].Cells[0].Value = dataTable3.Rows[i][0].ToString();
						dataGridView2.Rows[i].Cells[1].Value = Convert.ToDecimal(dataTable3.Rows[i][1].ToString());
						value2 += Convert.ToDecimal(dataGridView2.Rows[i].Cells[1].Value);
					}
					numericUpDown6.Value = value2;
				}
				else
				{
					dataGridView2.Rows.Clear();
				}
			}
			catch
			{
			}
		}

		private void clear()
		{
			companyId = "0";
			button1.Enabled = true;
			button4.Enabled = false;
			DataTable dataTable = codes.Search2("select isnull(max(id),0)+1 from dbo.PatientSurgery");
			textBox4.Text = dataTable.Rows[0][0].ToString();
			dateTimePicker1.Value = DateTime.Now;
			textBox5.Text = "";
			numericUpDown1.Value = 0m;
			comboBox3.Text = "";
			comboBox4.Text = "";
			comboBox6.SelectedIndex = -1;
			comboBox5.Text = "";
			comboBox7.Text = "";
			textBox1.Text = "";
			textBox2.Text = "";
			textBox3.Text = "";
			textBox6.Text = "";
			numericUpDown7.Value = 0m;
			numericUpDown8.Value = 0m;
			numericUpDown9.Value = 0m;
			comboBox8.SelectedIndex = -1;
			numericUpDown4.Value = 0m;
			numericUpDown2.Value = 0m;
			dataGridView1.DataSource = null;
			dataGridView1.Rows.Clear();
			numericUpDown5.Value = 0m;
			comboBox9.Text = "";
			numericUpDown3.Value = 0m;
			dataGridView2.DataSource = null;
			dataGridView2.Rows.Clear();
			numericUpDown6.Value = 0m;
			numericUpDown10.Text = "0";
		}

		private void button6_Click(object sender, EventArgs e)
		{
			clear();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			if (comboBox1.SelectedIndex == -1)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("please Enter Patient name");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم المريض");
				}
				return;
			}
			if (comboBox2.SelectedIndex == -1)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("please Enter Surgery name");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم العملية");
				}
				return;
			}
			if (comboBox6.SelectedIndex == -1)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("please Enter Surgery Doctor");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم طبيب العملية");
				}
				return;
			}
			try
			{
				DataTable dataTable = codes.Search2("select PatientID,SurgeryID,Date from PatientSurgery where ID = '" + textBox4.Text + "'");
				string text = dataTable.Rows[0][0].ToString();
				string text2 = dataTable.Rows[0][1].ToString();
				string text3 = Convert.ToDateTime(dataTable.Rows[0][2].ToString()).ToString("MM/dd/yyyy");
				DataTable dataTable2 = codes.Search2("select Name from Surgery where ID = '" + text2 + "'");
				dataTable2.Rows[0][0].ToString();
				DataTable dataTable3 = codes.Search2("select ItemID,Qnt,Price from SurgeryItems where SurgeryID = '" + textBox4.Text + "'");
				if (dataTable3.Rows.Count > 0)
				{
					for (int i = 0; i < dataTable3.Rows.Count; i++)
					{
						decimal num = 0m;
						try
						{
							DataTable dataTable4 = codes.Search2("select Qnt from store where ItemID='" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "'");
							num = Convert.ToDecimal(dataTable4.Rows[0][0].ToString());
						}
						catch
						{
						}
						decimal num2 = 0m;
						try
						{
							DataTable dataTable5 = codes.Search2("select BuyPrice from store where ItemID='" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "'");
							num2 = Convert.ToDecimal(dataTable5.Rows[0][0].ToString());
						}
						catch
						{
						}
						decimal num3 = 0m;
						try
						{
							DataTable dataTable6 = codes.Search2("select SalePrice from Items where ID='" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "'");
							num3 = Convert.ToDecimal(dataTable6.Rows[0][0].ToString());
						}
						catch
						{
						}
						codes.Add2("INSERT INTO ItemsMove\r\n                      (ItemId, StoreId, IncomeQnt, IncomePrice, OutcomeQnt, OutcomePrice, LastQnt, LastIncomePrice, LastOutComePrice, Bayan, MoveDate, UserId, Time,Type)\r\n                       VALUES ('" + dataTable3.Rows[i][0].ToString() + "',0,'" + dataTable3.Rows[i][1].ToString() + "','" + dataTable3.Rows[i][2].ToString() + "',0,'" + num3 + "','" + num + "','" + num2 + "','" + num3 + "','سحب عمليات إجراء عملية " + comboBox2.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Main.userId + "','" + dateTimePicker1.Value.ToShortTimeString() + "','دخول')");
						codes.Edit2("update store set Qnt = Qnt + " + dataTable3.Rows[i][1].ToString() + " where ItemID = " + dataTable3.Rows[i][0].ToString());
					}
				}
				codes.Edit2(string.Concat("update PatientSurgery set PatientID = '", comboBox1.SelectedValue, "',SurgeryID = '", comboBox2.SelectedValue, "' ,SurgeryCost = '", numericUpDown1.Value, "', AnesthesiaType = '", comboBox3.Text, "',Anesthetist = '", comboBox4.Text, "',Doctor = '", comboBox6.SelectedValue, "',AssistantDoctor = '", comboBox5.Text, "',Nurse = '", comboBox7.Text, "' ,Findings = '", textBox1.Text, "',Complications = '", textBox2.Text, "',Procedures = '", textBox3.Text, "',TotalItems = '", numericUpDown7.Value, "',TotalExpenses = '", numericUpDown8.Value, "',TotalCost = '", numericUpDown9.Value, "',Date = '", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "',Diagnosis = '", textBox5.Text, "',Notes = '", textBox6.Text, "',HotelServices = '", numericUpDown10.Text, "' where ID = '", textBox4.Text, "'"));
				codes.Delete2("delete from SurgeryItems where SurgeryID = '" + textBox4.Text + "'");
				codes.Delete2("delete from SahbItem where Notes = 'عملية رقم'+'" + textBox4.Text + "'");
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					decimal num = 0m;
					try
					{
						DataTable dataTable4 = codes.Search2("select Qnt from store where ItemID='" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "'");
						num = Convert.ToDecimal(dataTable4.Rows[0][0].ToString());
					}
					catch
					{
					}
					decimal num2 = 0m;
					try
					{
						DataTable dataTable5 = codes.Search2("select BuyPrice from store where ItemID='" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "'");
						num2 = Convert.ToDecimal(dataTable5.Rows[0][0].ToString());
					}
					catch
					{
					}
					decimal num3 = 0m;
					try
					{
						DataTable dataTable6 = codes.Search2("select SalePrice from Items where ID='" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "'");
						num3 = Convert.ToDecimal(dataTable6.Rows[0][0].ToString());
					}
					catch
					{
					}
					codes.Add2("INSERT INTO ItemsMove\r\n                      (ItemId, StoreId, IncomeQnt, IncomePrice, OutcomeQnt, OutcomePrice, LastQnt, LastIncomePrice, LastOutComePrice, Bayan, MoveDate, UserId, Time,Type)\r\n                       VALUES ('" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "',0,0,0,'" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[1].Value.ToString() + "','" + num + "','" + num2 + "','" + num3 + "','سحب عمليات إجراء عملية " + comboBox2.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Main.userId + "','" + dateTimePicker1.Value.ToShortTimeString() + "','خروج')");
					codes.Add2("insert into SurgeryItems (SurgeryID, ItemID, Qnt, Price, total) Values ('" + textBox4.Text + "', '" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[1].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[3].Value.ToString() + "')");
					codes.Add2("insert into SahbItem(TypeSahb,ItemId,Qty,Date,Notes) values('سحب عمليات','" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','عملية رقم'+'" + textBox4.Text + "')");
					codes.Edit2("update store set Qnt = Qnt - " + dataGridView1.Rows[i].Cells[2].Value.ToString() + " where ItemID = '" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "'");
				}
				codes.Delete2("delete from SurgeryExpenses where SurgeryID = '" + textBox4.Text + "'");
				for (int i = 0; i < dataGridView2.Rows.Count; i++)
				{
					codes.Add2("insert into SurgeryExpenses (SurgeryID, Expense, ExpenseValue) values ('" + textBox4.Text + "','" + dataGridView2.Rows[i].Cells[0].Value.ToString() + "', '" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "')");
				}
				codes.Edit2(string.Concat("update PatientAccount set PatientId = '", comboBox1.SelectedValue, "',DoctorID = '", comboBox6.SelectedValue, "' ,Bean = 'إجراء عملية ", comboBox2.Text, "' ,Price = '", numericUpDown9.Value, "' ,Date = '", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "' where PatientId = '", text, "' and Bean ='إجراء عملية ", operation, "' and Date = '", text3, "'"));
				try
				{
					string text4 = codes.Search2("select ID from PatientAccount where PatientId = '" + text + "' and Bean ='إجراء عملية " + operation + "' and Date = '" + text3 + "'").Rows[0][0].ToString();
					DataTable dataTable7 = codes.Search2("select ID,Madeen from Company5 where PatientAccountId = '" + text4 + "'");
					if (dataTable7.Rows.Count > 0)
					{
						string text5 = dataTable7.Rows[0][0].ToString();
						string value = dataTable7.Rows[0][1].ToString();
						string text6 = (Convert.ToDecimal(Account) - Convert.ToDecimal(value)).ToString();
						codes.Edit2("update Company5 set Madeen = '" + Account + "',Date = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' where ID = '" + text5 + "'");
						codes.Edit2("update Company5 set CompanyId = '" + companyId + "',Raseed = Raseed+ " + text6 + " where ID >= '" + text5 + "' ");
					}
					else
					{
						string value2 = codes.Search("select isnull(sum(Madeen),0) -  isnull(sum(Daen),0) from Company5 where CompanyId = '" + companyId + "'").Rows[0][0].ToString();
						if (Account != 0m)
						{
							codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + Account + "','" + (Convert.ToDouble(value2) + Convert.ToDouble(Account)) + "','إجراء عملية " + comboBox2.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(text4) + "')");
						}
					}
				}
				catch
				{
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Have Been Updated");
				}
				else
				{
					MessageBox.Show("تم تعديل البيانات بنجاح");
				}
				MethodsClass.UserMove("تعديل عملية لمريض");
				frmRptPatientSurgery frmRptPatientSurgery2 = new frmRptPatientSurgery(Convert.ToInt32(comboBox1.SelectedValue.ToString()), Convert.ToInt32(textBox4.Text));
				frmRptPatientSurgery2.Show();
				clear();
			}
			catch
			{
			}
		}

		private void numericUpDown10_TextChanged(object sender, EventArgs e)
		{
			try
			{
				if (numericUpDown10.Text == "")
				{
					numericUpDown10.Text = "0";
				}
				if (!x)
				{
					numericUpDown9.Value = numericUpDown8.Value + numericUpDown7.Value + numericUpDown1.Value + Convert.ToDecimal(numericUpDown10.Text);
				}
				else
				{
					numericUpDown9.Value = numericUpDown8.Value + numericUpDown1.Value + Convert.ToDecimal(numericUpDown10.Text);
				}
			}
			catch
			{
			}
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			companyId = "0";
			numericUpDown1.Value = 0m;
			try
			{
				companyId = codes.Search2("select company from PatientData where  PName = '" + comboBox1.Text + "'").Rows[0][0].ToString();
			}
			catch
			{
			}
			try
			{
				discount = Convert.ToDecimal(codes.Search2("SELECT dbo.Company.DisOp FROM dbo.PatientData INNER JOIN dbo.Company ON dbo.PatientData.company = dbo.Company.ID where PatientData.PName = '" + comboBox1.Text + "'").Rows[0][0].ToString());
			}
			catch
			{
			}
			try
			{
				Nesba = Convert.ToBoolean(codes.Search2("SELECT dbo.Company.Nesba FROM dbo.PatientData INNER JOIN dbo.Company ON dbo.PatientData.company = dbo.Company.ID where PatientData.PName = '" + comboBox1.Text + "'").Rows[0][0].ToString());
			}
			catch
			{
			}
			try
			{
				DataTable dataSource = codes.Search2("select ID, Name from Surgery");
				comboBox2.DataSource = dataSource;
				comboBox2.DisplayMember = "Name";
				comboBox2.ValueMember = "ID";
			}
			catch
			{
			}
			comboBox2_SelectedIndexChanged(sender, e);
		}

		private void comboBox1_TextChanged(object sender, EventArgs e)
		{
		}

		private void button7_Click(object sender, EventArgs e)
		{
			try
			{
				FrmProperties frmProperties = new FrmProperties();
				frmProperties.ShowDialog();
				button5.Enabled = Convert.ToBoolean(codes.Search2("select updateSurgery from users where userId = '" + Main.userId + "'").Rows[0][0].ToString());
				x = Convert.ToBoolean(codes.Search2("select CalSurgery from Properties").Rows[0][0].ToString());
				numericUpDown10_TextChanged(sender, e);
			}
			catch
			{
			}
		}
	}
}
