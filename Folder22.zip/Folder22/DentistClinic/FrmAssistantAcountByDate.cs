using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmAssistantAcountByDate : ReportBaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private DateTimePicker date2;

		private DateTimePicker date1;

		private Label label3;

		private ComboBox doctorcomboBox;

		private Label label2;

		private Label label1;

		private GroupBox groupBox2;

		private Button ViewRptBtn;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlSelectCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlInsertCommand2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlSelectCommand3;

		private SqlConnection sqlConnection3;

		private SqlCommand sqlInsertCommand3;

		private SqlDataAdapter sqlDataAdapter3;

		private SqlCommand sqlSelectCommand4;

		private SqlConnection sqlConnection4;

		private SqlCommand sqlInsertCommand4;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter4;

		private CrystalReportViewer crystalReportViewer1;

		private Label l3;

		private Label l2;

		private Label l1;

		private Label l5;

		private Label l4;

		private ClassDataBase dc;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GUI gui = new GUI();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmAssistantAcountByDate));
			groupBox1 = new System.Windows.Forms.GroupBox();
			l5 = new System.Windows.Forms.Label();
			l4 = new System.Windows.Forms.Label();
			l3 = new System.Windows.Forms.Label();
			l2 = new System.Windows.Forms.Label();
			l1 = new System.Windows.Forms.Label();
			date2 = new System.Windows.Forms.DateTimePicker();
			date1 = new System.Windows.Forms.DateTimePicker();
			ViewRptBtn = new System.Windows.Forms.Button();
			label3 = new System.Windows.Forms.Label();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			dataSet11 = new DataSet1();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlConnection3 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlConnection4 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter4 = new System.Data.SqlClient.SqlDataAdapter();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			groupBox1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(l5);
			groupBox1.Controls.Add(l4);
			groupBox1.Controls.Add(l3);
			groupBox1.Controls.Add(l2);
			groupBox1.Controls.Add(l1);
			groupBox1.Controls.Add(date2);
			groupBox1.Controls.Add(date1);
			groupBox1.Controls.Add(ViewRptBtn);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(doctorcomboBox);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(label1);
			groupBox1.Location = new System.Drawing.Point(9, 8);
			groupBox1.Name = "groupBox1";
			groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox1.Size = new System.Drawing.Size(806, 80);
			groupBox1.TabIndex = 0;
			groupBox1.TabStop = false;
			groupBox1.Enter += new System.EventHandler(groupBox1_Enter);
			l5.AutoSize = true;
			l5.Location = new System.Drawing.Point(120, 61);
			l5.Name = "l5";
			l5.Size = new System.Drawing.Size(0, 13);
			l5.TabIndex = 9;
			l5.Visible = false;
			l4.AutoSize = true;
			l4.Location = new System.Drawing.Point(82, 20);
			l4.Name = "l4";
			l4.Size = new System.Drawing.Size(0, 13);
			l4.TabIndex = 8;
			l4.Visible = false;
			l3.AutoSize = true;
			l3.Location = new System.Drawing.Point(24, 18);
			l3.Name = "l3";
			l3.Size = new System.Drawing.Size(0, 13);
			l3.TabIndex = 7;
			l3.Visible = false;
			l2.AutoSize = true;
			l2.Location = new System.Drawing.Point(158, 35);
			l2.Name = "l2";
			l2.Size = new System.Drawing.Size(0, 13);
			l2.TabIndex = 6;
			l2.Visible = false;
			l1.AutoSize = true;
			l1.Location = new System.Drawing.Point(92, 20);
			l1.Name = "l1";
			l1.Size = new System.Drawing.Size(0, 13);
			l1.TabIndex = 5;
			l1.Visible = false;
			date2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			date2.CustomFormat = "dd/MM/yyyy";
			date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date2.Location = new System.Drawing.Point(324, 44);
			date2.Name = "date2";
			date2.RightToLeftLayout = true;
			date2.Size = new System.Drawing.Size(153, 20);
			date2.TabIndex = 3;
			date1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			date1.CustomFormat = "dd/MM/yyyy";
			date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date1.Location = new System.Drawing.Point(517, 44);
			date1.Name = "date1";
			date1.RightToLeftLayout = true;
			date1.Size = new System.Drawing.Size(159, 20);
			date1.TabIndex = 2;
			ViewRptBtn.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
			ViewRptBtn.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			ViewRptBtn.Location = new System.Drawing.Point(203, 13);
			ViewRptBtn.Name = "ViewRptBtn";
			ViewRptBtn.Size = new System.Drawing.Size(115, 51);
			ViewRptBtn.TabIndex = 4;
			ViewRptBtn.Text = "عرض التقرير";
			ViewRptBtn.UseVisualStyleBackColor = false;
			ViewRptBtn.Click += new System.EventHandler(ViewRptBtn_Click);
			label3.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			label3.AutoSize = true;
			label3.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label3.Location = new System.Drawing.Point(483, 44);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(28, 19);
			label3.TabIndex = 0;
			label3.Text = "الي";
			doctorcomboBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Location = new System.Drawing.Point(324, 13);
			doctorcomboBox.Name = "doctorcomboBox";
			doctorcomboBox.Size = new System.Drawing.Size(352, 21);
			doctorcomboBox.TabIndex = 1;
			label2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			label2.AutoSize = true;
			label2.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label2.Location = new System.Drawing.Point(682, 44);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(25, 19);
			label2.TabIndex = 0;
			label2.Text = "من";
			label1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			label1.AutoSize = true;
			label1.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label1.Location = new System.Drawing.Point(682, 12);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(113, 19);
			label1.TabIndex = 0;
			label1.Text = "اختر اسم المساعد";
			groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Location = new System.Drawing.Point(9, 94);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(806, 418);
			groupBox2.TabIndex = 0;
			groupBox2.TabStop = false;
			crystalReportViewer1.ActiveViewIndex = -1;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
			crystalReportViewer1.Location = new System.Drawing.Point(3, 16);
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.Size = new System.Drawing.Size(800, 399);
			crystalReportViewer1.TabIndex = 0;
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlSelectCommand1.CommandText = "SELECT        PatientAccount.*\r\nFROM            PatientAccount";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = "INSERT INTO [PatientAccount] ([PatientId], [DoctorID], [Bean], [Price], [Pay], [Date], [PricePay]) VALUES (@PatientId, @DoctorID, @Bean, @Price, @Pay, @Date, @PricePay)";
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@PatientId", System.Data.SqlDbType.Int, 0, "PatientId"),
				new System.Data.SqlClient.SqlParameter("@DoctorID", System.Data.SqlDbType.Int, 0, "DoctorID"),
				new System.Data.SqlClient.SqlParameter("@Bean", System.Data.SqlDbType.NVarChar, 0, "Bean"),
				new System.Data.SqlClient.SqlParameter("@Price", System.Data.SqlDbType.Money, 0, "Price"),
				new System.Data.SqlClient.SqlParameter("@Pay", System.Data.SqlDbType.Bit, 0, "Pay"),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
				new System.Data.SqlClient.SqlParameter("@PricePay", System.Data.SqlDbType.Money, 0, "PricePay")
			});
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientAccount", new System.Data.Common.DataColumnMapping[8]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("PatientId", "PatientId"),
					new System.Data.Common.DataColumnMapping("DoctorID", "DoctorID"),
					new System.Data.Common.DataColumnMapping("Bean", "Bean"),
					new System.Data.Common.DataColumnMapping("Price", "Price"),
					new System.Data.Common.DataColumnMapping("Pay", "Pay"),
					new System.Data.Common.DataColumnMapping("Date", "Date"),
					new System.Data.Common.DataColumnMapping("PricePay", "PricePay")
				})
			});
			sqlSelectCommand2.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlSelectCommand2.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.CommandText = resources.GetString("sqlInsertCommand2.CommandText");
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[34]
			{
				new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
				new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
				new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
				new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
				new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
				new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
				new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
				new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
				new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
				new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
				new System.Data.SqlClient.SqlParameter("@pain", System.Data.SqlDbType.Bit, 0, "pain"),
				new System.Data.SqlClient.SqlParameter("@Caries", System.Data.SqlDbType.Bit, 0, "Caries"),
				new System.Data.SqlClient.SqlParameter("@RoutineVisit", System.Data.SqlDbType.Bit, 0, "RoutineVisit"),
				new System.Data.SqlClient.SqlParameter("@Swelling", System.Data.SqlDbType.Bit, 0, "Swelling"),
				new System.Data.SqlClient.SqlParameter("@Esthetics", System.Data.SqlDbType.Bit, 0, "Esthetics"),
				new System.Data.SqlClient.SqlParameter("@Others", System.Data.SqlDbType.NVarChar, 0, "Others"),
				new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
				new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
				new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
				new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
				new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
				new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
				new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
				new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
				new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
				new System.Data.SqlClient.SqlParameter("@DrugSensitivity", System.Data.SqlDbType.Bit, 0, "DrugSensitivity"),
				new System.Data.SqlClient.SqlParameter("@PulpTherapy", System.Data.SqlDbType.Bit, 0, "PulpTherapy"),
				new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
				new System.Data.SqlClient.SqlParameter("@FlourideTherapy", System.Data.SqlDbType.Bit, 0, "FlourideTherapy"),
				new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers")
			});
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[35]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("pain", "pain"),
					new System.Data.Common.DataColumnMapping("Caries", "Caries"),
					new System.Data.Common.DataColumnMapping("RoutineVisit", "RoutineVisit"),
					new System.Data.Common.DataColumnMapping("Swelling", "Swelling"),
					new System.Data.Common.DataColumnMapping("Esthetics", "Esthetics"),
					new System.Data.Common.DataColumnMapping("Others", "Others"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("DrugSensitivity", "DrugSensitivity"),
					new System.Data.Common.DataColumnMapping("PulpTherapy", "PulpTherapy"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("FlourideTherapy", "FlourideTherapy"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers")
				})
			});
			sqlSelectCommand3.CommandText = "SELECT        Empdata.*\r\nFROM            Empdata";
			sqlSelectCommand3.Connection = sqlConnection3;
			sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection3.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand3.CommandText = "INSERT INTO [Empdata] ([Designation], [Name], [Address], [Tel], [Mob], [Email], [Salary], [Percentage]) VALUES (@Designation, @Name, @Address, @Tel, @Mob, @Email, @Salary, @Percentage)";
			sqlInsertCommand3.Connection = sqlConnection3;
			sqlInsertCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[8]
			{
				new System.Data.SqlClient.SqlParameter("@Designation", System.Data.SqlDbType.NVarChar, 0, "Designation"),
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 0, "Address"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@Salary", System.Data.SqlDbType.Money, 0, "Salary"),
				new System.Data.SqlClient.SqlParameter("@Percentage", System.Data.SqlDbType.NVarChar, 0, "Percentage")
			});
			sqlDataAdapter3.InsertCommand = sqlInsertCommand3;
			sqlDataAdapter3.SelectCommand = sqlSelectCommand3;
			sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Empdata", new System.Data.Common.DataColumnMapping[9]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Designation", "Designation"),
					new System.Data.Common.DataColumnMapping("Name", "Name"),
					new System.Data.Common.DataColumnMapping("Address", "Address"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("Salary", "Salary"),
					new System.Data.Common.DataColumnMapping("Percentage", "Percentage")
				})
			});
			sqlSelectCommand4.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand4.Connection = sqlConnection4;
			sqlConnection4.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection4.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand4.CommandText = resources.GetString("sqlInsertCommand4.CommandText");
			sqlInsertCommand4.Connection = sqlConnection4;
			sqlInsertCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection4;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection4;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter4.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter4.InsertCommand = sqlInsertCommand4;
			sqlDataAdapter4.SelectCommand = sqlSelectCommand4;
			sqlDataAdapter4.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[8]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo")
				})
			});
			sqlDataAdapter4.UpdateCommand = sqlUpdateCommand1;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			base.ClientSize = new System.Drawing.Size(823, 521);
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox2);
			base.Location = new System.Drawing.Point(0, 0);
			base.Name = "FrmAssistantAcountByDate";
			Text = "تقرير حساب مساعد";
			base.Load += new System.EventHandler(FrmDoctorAcountByDate_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(FrmDoctorAcountByDate_KeyDown);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}

		public FrmAssistantAcountByDate()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		private void FrmDoctorAcountByDate_Load(object sender, EventArgs e)
		{
			DataTable dataTable = new DataTable();
			try
			{
				dataTable = codes.Search2("SELECT ID, Name FROM Empdata WHERE (Designation = N'Assistant')");
				gui.loadComboBox(doctorcomboBox, dataTable);
			}
			catch
			{
			}
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = dc.GetTableText("select * from Empdata where Name='" + doctorcomboBox.Text + "'");
				if (tableText.Rows.Count > 0)
				{
					DataTable tableText2 = dc.GetTableText("select * from PatientAccount where Assistant='" + doctorcomboBox.Text + "'and Date Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "'");
					if (tableText2.Rows.Count > 0)
					{
						sqlConnection1.ConnectionString = dc.ConnectionStr;
						sqlConnection2.ConnectionString = dc.ConnectionStr;
						sqlConnection3.ConnectionString = dc.ConnectionStr;
						sqlConnection4.ConnectionString = dc.ConnectionStr;
						dataSet11.Clear();
						sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
						sqlDataAdapter1.SelectCommand.CommandText = "select * from PatientAccount where Assistant='" + doctorcomboBox.Text + "'and Date Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "'";
						string value = date2.Value.Subtract(date1.Value).Days.ToString();
						DataTable tableText3 = dc.GetTableText("select Salary,isnull(Percentage,0) from Empdata where ID = " + doctorcomboBox.SelectedValue.ToString());
						int value2 = Convert.ToInt32(value) + 1;
						l1.Text = (Convert.ToDecimal(tableText3.Rows[0][0].ToString()) / 30m * Convert.ToDecimal(value2)).ToString();
						l2.Text = tableText3.Rows[0][1].ToString();
						if (l2.Text == "")
						{
							l2.Text = "0.00";
						}
						DataTable dataTable = new DataTable();
						dataTable = dc.GetTableText("select isnull(sum(Price),0) from PatientAccount where Assistant = '" + doctorcomboBox.Text + "'  and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "'");
						l5.Text = dataTable.Rows[0][0].ToString();
						string value3 = (Convert.ToDecimal(l5.Text) * Convert.ToDecimal(l2.Text) / 100m + Convert.ToDecimal(l1.Text)).ToString();
						sqlDataAdapter1.Fill(dataSet11);
						sqlDataAdapter2.Fill(dataSet11);
						sqlDataAdapter3.Fill(dataSet11);
						sqlDataAdapter4.Fill(dataSet11);
						((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value, date2.Value);
						AssistantAcountbyDateRpt assistantAcountbyDateRpt = new AssistantAcountbyDateRpt();
						assistantAcountbyDateRpt.SetDataSource(dataSet11);
						assistantAcountbyDateRpt.SetParameterValue("TotalSalary", Convert.ToDecimal(l1.Text));
						assistantAcountbyDateRpt.SetParameterValue("TotalPercentage", l2.Text);
						assistantAcountbyDateRpt.SetParameterValue("TotalService", l5.Text);
						assistantAcountbyDateRpt.SetParameterValue("Total", Convert.ToDecimal(value3));
						crystalReportViewer1.ReportSource = assistantAcountbyDateRpt;
					}
					else
					{
						crystalReportViewer1.ReportSource = null;
						MessageBox.Show("لا يوجد بيانات لهذا المساعد");
					}
				}
				else
				{
					crystalReportViewer1.ReportSource = null;
					MessageBox.Show("من فضلك تأكد من اسم المساعد");
				}
			}
			catch
			{
			}
		}

		private void groupBox1_Enter(object sender, EventArgs e)
		{
		}

		private void FrmDoctorAcountByDate_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}
	}
}
