using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Windows.Forms;

namespace DentistClinic
{
	public class AppointEsalRptFrm : ReportBaseForm
	{
		private DataSet1 data;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private Panel panel1;

		private CrystalReportViewer crystalReportViewer1;

		public AppointEsalRptFrm(DataSet1 ds)
		{
			InitializeComponent();
			data = ds;
		}

		private void AppointEsalRptFrm_Load(object sender, EventArgs e)
		{
			DataTable dataTable = Codes.Search2("select chTxtUnderPres,TxtUnderPres from Properties");
			string text = "";
			text = ((!Convert.ToBoolean(dataTable.Rows[0]["chTxtUnderPres"].ToString())) ? "" : dataTable.Rows[0]["TxtUnderPres"].ToString());
			DataTable dataTable2 = Codes.Search2("select EsalPrinter from Properties");
			string text2 = dataTable2.Rows[0][0].ToString();
			try
			{
				if (text2 == "A5")
				{
					ReportDocument reportDocument = new ReportDocument();
					reportDocument.Load(Application.StartupPath + "\\Reports\\AppointEsalRpt.rpt");
					try
					{
						reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
					}
					catch
					{
					}
					try
					{
						TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
						textObject.Text = text;
					}
					catch
					{
					}
					reportDocument.SetDataSource(data);
					crystalReportViewer1.ReportSource = reportDocument;
				}
				else if (text2 == "Reset")
				{
					ReportDocument reportDocument = new ReportDocument();
					reportDocument.Load(Application.StartupPath + "\\Reports\\AppointEsalReset.rpt");
					try
					{
						reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
					}
					catch
					{
					}
					try
					{
						TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
						textObject.Text = text;
					}
					catch
					{
					}
					reportDocument.SetDataSource(data);
					crystalReportViewer1.ReportSource = reportDocument;
				}
				else
				{
					ReportDocument reportDocument = new ReportDocument();
					reportDocument.Load(Application.StartupPath + "\\Reports\\AppointEsalRpt1.rpt");
					try
					{
						reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
					}
					catch
					{
					}
					try
					{
						TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
						textObject.Text = text;
					}
					catch
					{
					}
					reportDocument.SetDataSource(data);
					crystalReportViewer1.ReportSource = reportDocument;
				}
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			panel1 = new System.Windows.Forms.Panel();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			panel1.SuspendLayout();
			SuspendLayout();
			panel1.BackColor = System.Drawing.Color.Transparent;
			panel1.Controls.Add(crystalReportViewer1);
			panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(724, 562);
			panel1.TabIndex = 0;
			crystalReportViewer1.ActiveViewIndex = -1;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
			crystalReportViewer1.Location = new System.Drawing.Point(0, 0);
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.Size = new System.Drawing.Size(724, 562);
			crystalReportViewer1.TabIndex = 0;
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(724, 562);
			base.Controls.Add(panel1);
			base.Location = new System.Drawing.Point(0, 0);
			base.Name = "AppointEsalRptFrm";
			Text = "الكشف";
			base.Load += new System.EventHandler(AppointEsalRptFrm_Load);
			panel1.ResumeLayout(false);
			ResumeLayout(false);
		}
	}
}
