using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class DentalData : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private Label label6;

		private Label label5;

		private Label label4;

		private Label label3;

		private Label label2;

		private Label label1;

		private TextBox DentalSiteText;

		private TextBox DentalEmailText;

		private TextBox DentalMobileText;

		private TextBox DentalphoneTxt;

		private TextBox DentalNameText;

		private PictureBox pictureBox1;

		private Button DentalLogoBtn;

		private Button editBtn;

		private GroupBox groupBox2;

		private DataGridView dataGridView1;

		private GroupBox groupBox3;

		private Label label7;

		private TextBox WorkDatatEXT;

		private Label label8;

		private Button button1;

		private OpenFileDialog openFileDialog1;

		private CheckBox checkBoxClinic;

		private CheckBox checkBoxEye;

		private CheckBox checkBoxNatural;

		private CheckBox checkBoxFemale;

		private FontDialog fontDialog1;

		private ColorDialog colorDialog1;

		private Button button2;

		private Button button3;

		private RichTextBox DentaladdressText;

		private TextBox textBox1;

		private Label label9;

		private CheckBox checkBoxGeneral;

		private CheckBox checkBoxHeart;

		private CheckBox Physicaltherapy;

		private CheckBox BeautyLiserClinic;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private ClassDataBase dc;

		private byte[] Logo;

		private int ID;

		private GUI gui = new GUI();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BeautyLiserClinic = new System.Windows.Forms.CheckBox();
            this.Physicaltherapy = new System.Windows.Forms.CheckBox();
            this.checkBoxHeart = new System.Windows.Forms.CheckBox();
            this.checkBoxGeneral = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.DentaladdressText = new System.Windows.Forms.RichTextBox();
            this.DentalLogoBtn = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.checkBoxNatural = new System.Windows.Forms.CheckBox();
            this.checkBoxFemale = new System.Windows.Forms.CheckBox();
            this.checkBoxEye = new System.Windows.Forms.CheckBox();
            this.checkBoxClinic = new System.Windows.Forms.CheckBox();
            this.WorkDatatEXT = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.DentalSiteText = new System.Windows.Forms.TextBox();
            this.DentalEmailText = new System.Windows.Forms.TextBox();
            this.DentalMobileText = new System.Windows.Forms.TextBox();
            this.DentalphoneTxt = new System.Windows.Forms.TextBox();
            this.DentalNameText = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.editBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.BeautyLiserClinic);
            this.groupBox1.Controls.Add(this.Physicaltherapy);
            this.groupBox1.Controls.Add(this.checkBoxHeart);
            this.groupBox1.Controls.Add(this.checkBoxGeneral);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.DentaladdressText);
            this.groupBox1.Controls.Add(this.DentalLogoBtn);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.checkBoxNatural);
            this.groupBox1.Controls.Add(this.checkBoxFemale);
            this.groupBox1.Controls.Add(this.checkBoxEye);
            this.groupBox1.Controls.Add(this.checkBoxClinic);
            this.groupBox1.Controls.Add(this.WorkDatatEXT);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.DentalSiteText);
            this.groupBox1.Controls.Add(this.DentalEmailText);
            this.groupBox1.Controls.Add(this.DentalMobileText);
            this.groupBox1.Controls.Add(this.DentalphoneTxt);
            this.groupBox1.Controls.Add(this.DentalNameText);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(694, 335);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // BeautyLiserClinic
            // 
            this.BeautyLiserClinic.AutoSize = true;
            this.BeautyLiserClinic.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.BeautyLiserClinic.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.BeautyLiserClinic.Location = new System.Drawing.Point(214, 241);
            this.BeautyLiserClinic.Name = "BeautyLiserClinic";
            this.BeautyLiserClinic.Size = new System.Drawing.Size(108, 20);
            this.BeautyLiserClinic.TabIndex = 23;
            this.BeautyLiserClinic.Text = "عيادة تجميل وليزر";
            this.BeautyLiserClinic.UseVisualStyleBackColor = true;
            this.BeautyLiserClinic.CheckedChanged += new System.EventHandler(this.BeautyLiserClinic_CheckedChanged);
            // 
            // Physicaltherapy
            // 
            this.Physicaltherapy.AutoSize = true;
            this.Physicaltherapy.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.Physicaltherapy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Physicaltherapy.Location = new System.Drawing.Point(205, 221);
            this.Physicaltherapy.Name = "Physicaltherapy";
            this.Physicaltherapy.Size = new System.Drawing.Size(117, 20);
            this.Physicaltherapy.TabIndex = 22;
            this.Physicaltherapy.Text = "عيادة العلاج الطبيعي";
            this.Physicaltherapy.UseVisualStyleBackColor = true;
            this.Physicaltherapy.CheckedChanged += new System.EventHandler(this.Physicaltherapy_CheckedChanged);
            // 
            // checkBoxHeart
            // 
            this.checkBoxHeart.AutoSize = true;
            this.checkBoxHeart.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.checkBoxHeart.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.checkBoxHeart.Location = new System.Drawing.Point(248, 203);
            this.checkBoxHeart.Name = "checkBoxHeart";
            this.checkBoxHeart.Size = new System.Drawing.Size(74, 20);
            this.checkBoxHeart.TabIndex = 21;
            this.checkBoxHeart.Text = "عيادة القلب";
            this.checkBoxHeart.UseVisualStyleBackColor = true;
            this.checkBoxHeart.CheckedChanged += new System.EventHandler(this.checkBoxHeart_CheckedChanged);
            // 
            // checkBoxGeneral
            // 
            this.checkBoxGeneral.AutoSize = true;
            this.checkBoxGeneral.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.checkBoxGeneral.Location = new System.Drawing.Point(249, 185);
            this.checkBoxGeneral.Name = "checkBoxGeneral";
            this.checkBoxGeneral.Size = new System.Drawing.Size(73, 20);
            this.checkBoxGeneral.TabIndex = 20;
            this.checkBoxGeneral.Text = "عيادة عامة";
            this.checkBoxGeneral.UseVisualStyleBackColor = true;
            this.checkBoxGeneral.CheckedChanged += new System.EventHandler(this.checkBoxGeneral_CheckedChanged);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(340, 58);
            this.textBox1.Name = "textBox1";
            this.textBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox1.Size = new System.Drawing.Size(244, 20);
            this.textBox1.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(587, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 16);
            this.label9.TabIndex = 18;
            this.label9.Text = "اسم العيادة انجليزى :";
            // 
            // DentaladdressText
            // 
            this.DentaladdressText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DentaladdressText.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.DentaladdressText.ForeColor = System.Drawing.Color.Black;
            this.DentaladdressText.Location = new System.Drawing.Point(340, 87);
            this.DentaladdressText.Name = "DentaladdressText";
            this.DentaladdressText.Size = new System.Drawing.Size(244, 32);
            this.DentaladdressText.TabIndex = 17;
            this.DentaladdressText.Text = "";
            this.DentaladdressText.SelectionChanged += new System.EventHandler(this.DentaladdressText_SelectionChanged);
            // 
            // DentalLogoBtn
            // 
            this.DentalLogoBtn.BackColor = System.Drawing.Color.Transparent;
            this.DentalLogoBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DentalLogoBtn.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.DentalLogoBtn.Location = new System.Drawing.Point(42, 167);
            this.DentalLogoBtn.Name = "DentalLogoBtn";
            this.DentalLogoBtn.Size = new System.Drawing.Size(113, 32);
            this.DentalLogoBtn.TabIndex = 7;
            this.DentalLogoBtn.Text = "الشعار";
            this.DentalLogoBtn.UseVisualStyleBackColor = false;
            this.DentalLogoBtn.Click += new System.EventHandler(this.DentalLogoBtn_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.Color.Red;
            this.button3.Location = new System.Drawing.Point(215, 74);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(59, 29);
            this.button3.TabIndex = 16;
            this.button3.Text = "اللون";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(15, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 131);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.Blue;
            this.button2.Location = new System.Drawing.Point(275, 74);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(59, 29);
            this.button2.TabIndex = 15;
            this.button2.Text = "الخط";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // checkBoxNatural
            // 
            this.checkBoxNatural.AutoSize = true;
            this.checkBoxNatural.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.checkBoxNatural.Location = new System.Drawing.Point(246, 165);
            this.checkBoxNatural.Name = "checkBoxNatural";
            this.checkBoxNatural.Size = new System.Drawing.Size(76, 20);
            this.checkBoxNatural.TabIndex = 14;
            this.checkBoxNatural.Text = "عيادة أطفال";
            this.checkBoxNatural.UseVisualStyleBackColor = true;
            this.checkBoxNatural.CheckedChanged += new System.EventHandler(this.checkBoxNatural_CheckedChanged);
            // 
            // checkBoxFemale
            // 
            this.checkBoxFemale.AutoSize = true;
            this.checkBoxFemale.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.checkBoxFemale.Location = new System.Drawing.Point(217, 145);
            this.checkBoxFemale.Name = "checkBoxFemale";
            this.checkBoxFemale.Size = new System.Drawing.Size(105, 20);
            this.checkBoxFemale.TabIndex = 13;
            this.checkBoxFemale.Text = "عيادة نساء وتوليد";
            this.checkBoxFemale.UseVisualStyleBackColor = true;
            this.checkBoxFemale.CheckedChanged += new System.EventHandler(this.checkBoxFemale_CheckedChanged);
            // 
            // checkBoxEye
            // 
            this.checkBoxEye.AutoSize = true;
            this.checkBoxEye.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.checkBoxEye.Location = new System.Drawing.Point(245, 125);
            this.checkBoxEye.Name = "checkBoxEye";
            this.checkBoxEye.Size = new System.Drawing.Size(77, 20);
            this.checkBoxEye.TabIndex = 12;
            this.checkBoxEye.Text = "عيادة عيون";
            this.checkBoxEye.UseVisualStyleBackColor = true;
            this.checkBoxEye.CheckedChanged += new System.EventHandler(this.checkBoxEye_CheckedChanged);
            // 
            // checkBoxClinic
            // 
            this.checkBoxClinic.AutoSize = true;
            this.checkBoxClinic.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.checkBoxClinic.Location = new System.Drawing.Point(244, 105);
            this.checkBoxClinic.Name = "checkBoxClinic";
            this.checkBoxClinic.Size = new System.Drawing.Size(78, 20);
            this.checkBoxClinic.TabIndex = 11;
            this.checkBoxClinic.Text = "عيادة أسنان";
            this.checkBoxClinic.UseVisualStyleBackColor = true;
            this.checkBoxClinic.CheckedChanged += new System.EventHandler(this.checkBoxClinic_CheckedChanged);
            // 
            // WorkDatatEXT
            // 
            this.WorkDatatEXT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.WorkDatatEXT.Location = new System.Drawing.Point(100, 263);
            this.WorkDatatEXT.Multiline = true;
            this.WorkDatatEXT.Name = "WorkDatatEXT";
            this.WorkDatatEXT.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.WorkDatatEXT.Size = new System.Drawing.Size(484, 64);
            this.WorkDatatEXT.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(587, 266);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 16);
            this.label8.TabIndex = 9;
            this.label8.Text = "مواعيد العمل :";
            // 
            // DentalSiteText
            // 
            this.DentalSiteText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DentalSiteText.Location = new System.Drawing.Point(340, 229);
            this.DentalSiteText.Name = "DentalSiteText";
            this.DentalSiteText.Size = new System.Drawing.Size(244, 20);
            this.DentalSiteText.TabIndex = 6;
            // 
            // DentalEmailText
            // 
            this.DentalEmailText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DentalEmailText.Location = new System.Drawing.Point(340, 132);
            this.DentalEmailText.Name = "DentalEmailText";
            this.DentalEmailText.Size = new System.Drawing.Size(244, 20);
            this.DentalEmailText.TabIndex = 3;
            this.DentalEmailText.Validating += new System.ComponentModel.CancelEventHandler(this.DentalEmailText_Validating);
            // 
            // DentalMobileText
            // 
            this.DentalMobileText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DentalMobileText.Location = new System.Drawing.Point(340, 197);
            this.DentalMobileText.Name = "DentalMobileText";
            this.DentalMobileText.Size = new System.Drawing.Size(244, 20);
            this.DentalMobileText.TabIndex = 5;
            this.DentalMobileText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DentalMobileText_KeyPress);
            // 
            // DentalphoneTxt
            // 
            this.DentalphoneTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DentalphoneTxt.Location = new System.Drawing.Point(340, 164);
            this.DentalphoneTxt.Name = "DentalphoneTxt";
            this.DentalphoneTxt.Size = new System.Drawing.Size(244, 20);
            this.DentalphoneTxt.TabIndex = 4;
            this.DentalphoneTxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DentalphoneTxt_KeyPress);
            // 
            // DentalNameText
            // 
            this.DentalNameText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DentalNameText.Location = new System.Drawing.Point(340, 30);
            this.DentalNameText.Name = "DentalNameText";
            this.DentalNameText.Size = new System.Drawing.Size(244, 20);
            this.DentalNameText.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(587, 232);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "الموقع الإلكتروني : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(587, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "البريد الإلكتروني :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(587, 201);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "الموبايل :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(587, 167);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "التليفون :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(587, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "العنوان :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(587, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "اسم العيادة عربى :";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.dataGridView1);
            this.groupBox2.Location = new System.Drawing.Point(12, 385);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(694, 141);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 16);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(688, 122);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Location = new System.Drawing.Point(223, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(235, 35);
            this.groupBox3.TabIndex = 81;
            this.groupBox3.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(67, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 18);
            this.label7.TabIndex = 0;
            this.label7.Text = "بيانات العيادة";
            // 
            // editBtn
            // 
            this.editBtn.BackColor = System.Drawing.Color.Transparent;
            this.editBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.editBtn.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.editBtn.Location = new System.Drawing.Point(272, 354);
            this.editBtn.Name = "editBtn";
            this.editBtn.Size = new System.Drawing.Size(113, 32);
            this.editBtn.TabIndex = 11;
            this.editBtn.Text = "حفظ";
            this.editBtn.UseVisualStyleBackColor = false;
            this.editBtn.Click += new System.EventHandler(this.editBtn_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(526, 354);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(177, 32);
            this.button1.TabIndex = 82;
            this.button1.Text = "صورة خلفية البرنامج";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "image type |*.png;*.jpg;*.jpeg;*.bmb;*.gif";
            // 
            // DentalData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(715, 396);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.editBtn);
            this.Controls.Add(this.groupBox1);
            this.Name = "DentalData";
            this.Text = "بيانات العيادة";
            this.Load += new System.EventHandler(this.DentalData_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

		}

		public DentalData()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		public void searchData()
		{
			try
			{
				DataTable tableText = dc.GetTableText("select * from DentalData");
				dataGridView1.DataSource = tableText;
				DataGrid();
			}
			catch
			{
			}
		}

		public void DataGrid()
		{
			dataGridView1.Columns["ID"].Visible = false;
			dataGridView1.Columns["DentalName"].HeaderText = "اسم العيادة";
			dataGridView1.Columns["DentalName"].Width = 200;
			dataGridView1.Columns["DAddress"].HeaderText = "عنوان العيادة";
			dataGridView1.Columns["DAddress"].Width = 250;
			dataGridView1.Columns["DTel"].HeaderText = "التليفون";
			dataGridView1.Columns["DMobile"].HeaderText = "الموبايل";
			dataGridView1.Columns["DEmail"].HeaderText = "البريد الإلكتروني";
			dataGridView1.Columns["DEmail"].Width = 200;
			dataGridView1.Columns["DSite"].HeaderText = "الموقع الإلكتروني";
			dataGridView1.Columns["DSite"].Width = 200;
			dataGridView1.Columns["DLogo"].Visible = false;
		}

		private byte[] GetImage(string path)
		{
			FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read);
			BinaryReader binaryReader = new BinaryReader(fileStream);
			byte[] result = binaryReader.ReadBytes(Convert.ToInt32(fileStream.Length));
			binaryReader.Close();
			fileStream.Close();
			return result;
		}

		private void DentalLogoBtn_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = openFileDialog1.ShowDialog();
			if (dialogResult != DialogResult.Cancel)
			{
				Logo = GetImage(openFileDialog1.FileName);
				pictureBox1.BackgroundImage = Image.FromFile(openFileDialog1.FileName);
			}
		}

		public void ClearData()
		{
			DentaladdressText.Text = "";
			DentalSiteText.Text = "";
			DentalphoneTxt.Text = "";
			DentalNameText.Text = "";
			DentalMobileText.Text = "";
			DentalEmailText.Text = "";
			pictureBox1.BackgroundImage = null;
		}

		private void addBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = dc.GetTableText("select * from DentalData where DentalName='" + DentalNameText.Text + "'");
				string[] fields = new string[7] { "DentalName", "DAddress", "DTel", "DMobile", "DEmail", "DSite", "DLogo" };
				if (DentalNameText.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Clinic Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم العيادة");
					}
				}
				else if (DentaladdressText.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Clinic Address");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل عنوان العيادة");
					}
				}
				else if (tableText.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Been Enter This Clinic Before", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("اسم العيادة مسجل من قبل", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else if (pictureBox1.BackgroundImage == null)
				{
					Logo = new byte[0];
					if (dc.Insert("addDentalData", fields, DentalNameText.Text, DentaladdressText.Text, DentalphoneTxt.Text, DentalMobileText.Text, DentalEmailText.Text, DentalSiteText.Text, Logo))
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Save Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						ClearData();
					}
				}
				else if (dc.Insert("addDentalData", fields, DentalNameText.Text, DentaladdressText.Text, DentalphoneTxt.Text, DentalMobileText.Text, DentalEmailText.Text, DentalSiteText.Text, Logo))
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Save Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					ClearData();
				}
			}
			catch
			{
			}
		}

		private void DentalEmailText_Validating(object sender, CancelEventArgs e)
		{
			Regex regex = new Regex("^[a-zA-Z][\\w\\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z][a-zA-Z\\.]*[a-zA-Z]$");
			if (DentalEmailText.Text.Length > 0 && !regex.IsMatch(DentalEmailText.Text))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Correct Email");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل بريد الكتروني صحيح");
				}
				DentalEmailText.Text = "";
			}
		}

		private void DentalphoneTxt_KeyPress(object sender, KeyPressEventArgs e)
		{
		}

		private void DentalMobileText_KeyPress(object sender, KeyPressEventArgs e)
		{
		}

		private void searchBtn_Click(object sender, EventArgs e)
		{
			searchData();
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				ID = Convert.ToInt32(dataGridView1.CurrentRow.Cells["ID"].Value.ToString());
				DentalNameText.Text = dataGridView1.CurrentRow.Cells["DentalName"].Value.ToString();
				DentaladdressText.Text = dataGridView1.CurrentRow.Cells["DAddress"].Value.ToString();
				DentalphoneTxt.Text = dataGridView1.CurrentRow.Cells["DTel"].Value.ToString();
				DentalMobileText.Text = dataGridView1.CurrentRow.Cells["DMobile"].Value.ToString();
				DentalEmailText.Text = dataGridView1.CurrentRow.Cells["DEmail"].Value.ToString();
				DentalSiteText.Text = dataGridView1.CurrentRow.Cells["DSite"].Value.ToString();
				WorkDatatEXT.Text = dataGridView1.CurrentRow.Cells["WorkData"].Value.ToString();
				try
				{
					SqlBytes sqlBytes = new SqlBytes((byte[])dataGridView1.CurrentRow.Cells["DLogo"].Value);
					Logo = (byte[])dataGridView1.CurrentRow.Cells["DLogo"].Value;
					pictureBox1.BackgroundImage = Image.FromStream(sqlBytes.Stream);
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void DentalData_Load(object sender, EventArgs e)
		{
			searchData();
			DataTable tableText = dc.GetTableText("select * from DentalData");
			try
			{
				ID = Convert.ToInt32(tableText.Rows[0][0].ToString());
				DentalNameText.Text = tableText.Rows[0][1].ToString();
				DentaladdressText.Rtf = tableText.Rows[0][2].ToString();
				DentalphoneTxt.Text = tableText.Rows[0][3].ToString();
				DentalMobileText.Text = tableText.Rows[0][4].ToString();
				DentalEmailText.Text = tableText.Rows[0][5].ToString();
				DentalSiteText.Text = tableText.Rows[0][6].ToString();
				WorkDatatEXT.Text = tableText.Rows[0][8].ToString();
				checkBoxClinic.Checked = Convert.ToBoolean(tableText.Rows[0][10].ToString());
				checkBoxEye.Checked = Convert.ToBoolean(tableText.Rows[0][11].ToString());
				checkBoxFemale.Checked = Convert.ToBoolean(tableText.Rows[0][12].ToString());
				checkBoxNatural.Checked = Convert.ToBoolean(tableText.Rows[0][13].ToString());
				checkBoxGeneral.Checked = Convert.ToBoolean(tableText.Rows[0][15].ToString());
				checkBoxHeart.Checked = Convert.ToBoolean(tableText.Rows[0]["HeartClinic"].ToString());
				Physicaltherapy.Checked = Convert.ToBoolean(tableText.Rows[0]["Physicaltherapy"].ToString());
				BeautyLiserClinic.Checked = Convert.ToBoolean(tableText.Rows[0]["BeautyLiserClinic"].ToString());
				textBox1.Text = tableText.Rows[0][14].ToString();
				try
				{
					SqlBytes sqlBytes = new SqlBytes((byte[])tableText.Rows[0][7]);
					Logo = (byte[])tableText.Rows[0][7];
					pictureBox1.BackgroundImage = Image.FromStream(sqlBytes.Stream);
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void editBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (!BeautyLiserClinic.Checked && !checkBoxClinic.Checked && !checkBoxEye.Checked && !checkBoxFemale.Checked && !checkBoxNatural.Checked && !checkBoxGeneral.Checked && !checkBoxHeart.Checked && !Physicaltherapy.Checked)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Clinic Type");
					}
					else
					{
						MessageBox.Show("من فضلك اختار نوع العيادة");
					}
					return;
				}
				DataTable tableText = dc.GetTableText("select * from DentalData where DentalName='" + DentalNameText.Text + "'and ID<>'" + ID + "'");
				string[] fields = new string[18]
				{
					"ID", "DentalName", "DAddress", "DTel", "DMobile", "DEmail", "DSite", "DLogo", "WorkData", "ClinicType",
					"EyeClinic", "FemaleClinic", "NaturalClinic", "EnName", "GeneralClinic", "HeartClinic", "Physicaltherapy", "BeautyLiserClinic"
				};
				if (DentalNameText.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Clinic Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم العيادة");
					}
				}
				else if (DentaladdressText.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Clinic Address");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل العنوان");
					}
				}
				else if (tableText.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Been Enter This Clinic Before", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("هذا الإسم مسجل من قبل", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else if (dc.Update("updateDentalData", fields, ID, DentalNameText.Text, DentaladdressText.Rtf, DentalphoneTxt.Text, DentalMobileText.Text, DentalEmailText.Text, DentalSiteText.Text, Logo, WorkDatatEXT.Text, checkBoxClinic.Checked, checkBoxEye.Checked, checkBoxFemale.Checked, checkBoxNatural.Checked, textBox1.Text, checkBoxGeneral.Checked, checkBoxHeart.Checked, Physicaltherapy.Checked, BeautyLiserClinic.Checked))
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Save Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					MethodsClass.UserMove("تعديل بيانات العيادة");
					searchData();
				}
			}
			catch
			{
			}
		}

		private void DeleteBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DialogResult dialogResult = MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
				if (dialogResult != DialogResult.OK)
				{
					return;
				}
				string[] fields = new string[1] { "ID" };
				if (dc.Delete("deleteDentalData", fields, ID))
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Deleted Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					ClearData();
					searchData();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("An Error Occurred During The Deletion Process ", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				Settings.Default.backImage = openFileDialog1.FileName;
				Settings.Default.Save();
			}
		}

		private void checkBoxClinic_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBoxClinic.Checked)
				{
					BeautyLiserClinic.Checked = false;
					checkBoxEye.Checked = false;
					checkBoxFemale.Checked = false;
					checkBoxNatural.Checked = false;
					checkBoxGeneral.Checked = false;
					Physicaltherapy.Checked = false;
				}
			}
			catch
			{
			}
		}

		private void checkBoxEye_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBoxEye.Checked)
				{
					BeautyLiserClinic.Checked = false;
					checkBoxClinic.Checked = false;
					Physicaltherapy.Checked = false;
					checkBoxFemale.Checked = false;
					checkBoxNatural.Checked = false;
					checkBoxGeneral.Checked = false;
				}
			}
			catch
			{
			}
		}

		private void checkBoxFemale_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBoxFemale.Checked)
				{
					BeautyLiserClinic.Checked = false;
					Physicaltherapy.Checked = false;
					checkBoxClinic.Checked = false;
					checkBoxEye.Checked = false;
					checkBoxNatural.Checked = false;
					checkBoxGeneral.Checked = false;
				}
			}
			catch
			{
			}
		}

		private void checkBoxNatural_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBoxNatural.Checked)
				{
					BeautyLiserClinic.Checked = false;
					Physicaltherapy.Checked = false;
					checkBoxClinic.Checked = false;
					checkBoxEye.Checked = false;
					checkBoxFemale.Checked = false;
					checkBoxGeneral.Checked = false;
					checkBoxNatural.Checked = true;
				}
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = fontDialog1.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				DentaladdressText.SelectionFont = fontDialog1.Font;
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = colorDialog1.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				DentaladdressText.SelectionColor = colorDialog1.Color;
			}
		}

		private void DentaladdressText_SelectionChanged(object sender, EventArgs e)
		{
		}

		private void checkBoxGeneral_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBoxGeneral.Checked)
			{
				BeautyLiserClinic.Checked = false;
				Physicaltherapy.Checked = false;
				checkBoxClinic.Checked = false;
				checkBoxEye.Checked = false;
				checkBoxFemale.Checked = false;
				checkBoxNatural.Checked = false;
				checkBoxHeart.Checked = false;
			}
		}

		private void checkBoxHeart_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBoxHeart.Checked)
			{
				BeautyLiserClinic.Checked = false;
				Physicaltherapy.Checked = false;
				checkBoxClinic.Checked = false;
				checkBoxEye.Checked = false;
				checkBoxFemale.Checked = false;
				checkBoxNatural.Checked = false;
				checkBoxGeneral.Checked = false;
			}
		}

		private void groupBox1_Enter(object sender, EventArgs e)
		{
		}

		private void Physicaltherapy_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (Physicaltherapy.Checked)
				{
					BeautyLiserClinic.Checked = false;
					checkBoxHeart.Checked = false;
					checkBoxEye.Checked = false;
					checkBoxFemale.Checked = false;
					checkBoxNatural.Checked = false;
					checkBoxGeneral.Checked = false;
					checkBoxClinic.Checked = false;
				}
			}
			catch
			{
			}
		}

		private void BeautyLiserClinic_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (BeautyLiserClinic.Checked)
				{
					Physicaltherapy.Checked = false;
					checkBoxHeart.Checked = false;
					checkBoxEye.Checked = false;
					checkBoxFemale.Checked = false;
					checkBoxNatural.Checked = false;
					checkBoxGeneral.Checked = false;
					checkBoxClinic.Checked = false;
				}
			}
			catch
			{
			}
		}
	}
}
