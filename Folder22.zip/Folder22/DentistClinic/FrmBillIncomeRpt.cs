using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmBillIncomeRpt : ReportBaseForm
	{
		private string Bill;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private Panel panel1;

		private CrystalReportViewer crystalReportViewer1;

		private GroupBox groupBox1;

		private Button button1;

		private TextBox textBox1;

		private Label label1;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlSelectCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlInsertCommand2;

		private SqlCommand sqlUpdateCommand2;

		private SqlCommand sqlDeleteCommand2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlSelectCommand3;

		private SqlConnection sqlConnection3;

		private SqlCommand sqlInsertCommand3;

		private SqlCommand sqlUpdateCommand3;

		private SqlCommand sqlDeleteCommand3;

		private SqlDataAdapter sqlDataAdapter3;

		public FrmBillIncomeRpt(string BillNo)
		{
			InitializeComponent();
			Bill = BillNo;
		}

		private void FrmBillIncomeRpt_Load(object sender, EventArgs e)
		{
			if (Bill != "0")
			{
				dataSet11.Clear();
				groupBox1.Visible = false;
				try
				{
					sqlConnection1.ConnectionString = Codes.ConnectionStr;
					sqlConnection2.ConnectionString = Codes.ConnectionStr;
					sqlConnection3.ConnectionString = Codes.ConnectionStr;
					sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
					sqlDataAdapter1.SelectCommand.CommandText = "select * from IncomingBill where BillNo='" + Bill + "'";
					sqlDataAdapter2.Fill(dataSet11);
					sqlDataAdapter1.Fill(dataSet11);
					sqlDataAdapter3.Fill(dataSet11);
					IncomingBillRpt incomingBillRpt = new IncomingBillRpt();
					incomingBillRpt.SetDataSource(dataSet11);
					crystalReportViewer1.ReportSource = incomingBillRpt;
				}
				catch
				{
				}
			}
			else
			{
				groupBox1.Visible = true;
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				dataSet11.Clear();
				sqlConnection1.ConnectionString = Codes.ConnectionStr;
				sqlConnection2.ConnectionString = Codes.ConnectionStr;
				sqlConnection3.ConnectionString = Codes.ConnectionStr;
				sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter1.SelectCommand.CommandText = "select * from IncomingBill where BillNo='" + textBox1.Text + "'";
				sqlDataAdapter2.Fill(dataSet11);
				sqlDataAdapter1.Fill(dataSet11);
				sqlDataAdapter3.Fill(dataSet11);
				IncomingBillRpt incomingBillRpt = new IncomingBillRpt();
				incomingBillRpt.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = incomingBillRpt;
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmBillIncomeRpt));
			panel1 = new System.Windows.Forms.Panel();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			groupBox1 = new System.Windows.Forms.GroupBox();
			button1 = new System.Windows.Forms.Button();
			textBox1 = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			dataSet11 = new DataSet1();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlConnection3 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
			panel1.SuspendLayout();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			panel1.AccessibleDescription = null;
			panel1.AccessibleName = null;
			resources.ApplyResources(panel1, "panel1");
			panel1.BackColor = System.Drawing.Color.Transparent;
			panel1.BackgroundImage = null;
			panel1.Controls.Add(crystalReportViewer1);
			panel1.Controls.Add(groupBox1);
			panel1.Font = null;
			panel1.Name = "panel1";
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(button1);
			groupBox1.Controls.Add(textBox1);
			groupBox1.Controls.Add(label1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Font = null;
			textBox1.Name = "textBox1";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlSelectCommand1.CommandText = "SELECT        IncomingBill.*\r\nFROM            IncomingBill";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[14]
			{
				new System.Data.SqlClient.SqlParameter("@BillNo", System.Data.SqlDbType.Int, 0, "BillNo"),
				new System.Data.SqlClient.SqlParameter("@SupplierId", System.Data.SqlDbType.Int, 0, "SupplierId"),
				new System.Data.SqlClient.SqlParameter("@BillDate", System.Data.SqlDbType.DateTime, 0, "BillDate"),
				new System.Data.SqlClient.SqlParameter("@ItemId", System.Data.SqlDbType.Int, 0, "ItemId"),
				new System.Data.SqlClient.SqlParameter("@Qnt", System.Data.SqlDbType.Money, 0, "Qnt"),
				new System.Data.SqlClient.SqlParameter("@UnitPrice", System.Data.SqlDbType.Money, 0, "UnitPrice"),
				new System.Data.SqlClient.SqlParameter("@SanfDiscount", System.Data.SqlDbType.Money, 0, "SanfDiscount"),
				new System.Data.SqlClient.SqlParameter("@TotalPrice", System.Data.SqlDbType.Money, 0, "TotalPrice"),
				new System.Data.SqlClient.SqlParameter("@BillTotalBeforeDiscount", System.Data.SqlDbType.Money, 0, "BillTotalBeforeDiscount"),
				new System.Data.SqlClient.SqlParameter("@DiscountPer", System.Data.SqlDbType.Money, 0, "DiscountPer"),
				new System.Data.SqlClient.SqlParameter("@DiscountAmount", System.Data.SqlDbType.Money, 0, "DiscountAmount"),
				new System.Data.SqlClient.SqlParameter("@BillTotAfterDiscount", System.Data.SqlDbType.Money, 0, "BillTotAfterDiscount"),
				new System.Data.SqlClient.SqlParameter("@Pay", System.Data.SqlDbType.Money, 0, "Pay"),
				new System.Data.SqlClient.SqlParameter("@Backey", System.Data.SqlDbType.Money, 0, "Backey")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[44]
			{
				new System.Data.SqlClient.SqlParameter("@BillNo", System.Data.SqlDbType.Int, 0, "BillNo"),
				new System.Data.SqlClient.SqlParameter("@SupplierId", System.Data.SqlDbType.Int, 0, "SupplierId"),
				new System.Data.SqlClient.SqlParameter("@BillDate", System.Data.SqlDbType.DateTime, 0, "BillDate"),
				new System.Data.SqlClient.SqlParameter("@ItemId", System.Data.SqlDbType.Int, 0, "ItemId"),
				new System.Data.SqlClient.SqlParameter("@Qnt", System.Data.SqlDbType.Money, 0, "Qnt"),
				new System.Data.SqlClient.SqlParameter("@UnitPrice", System.Data.SqlDbType.Money, 0, "UnitPrice"),
				new System.Data.SqlClient.SqlParameter("@SanfDiscount", System.Data.SqlDbType.Money, 0, "SanfDiscount"),
				new System.Data.SqlClient.SqlParameter("@TotalPrice", System.Data.SqlDbType.Money, 0, "TotalPrice"),
				new System.Data.SqlClient.SqlParameter("@BillTotalBeforeDiscount", System.Data.SqlDbType.Money, 0, "BillTotalBeforeDiscount"),
				new System.Data.SqlClient.SqlParameter("@DiscountPer", System.Data.SqlDbType.Money, 0, "DiscountPer"),
				new System.Data.SqlClient.SqlParameter("@DiscountAmount", System.Data.SqlDbType.Money, 0, "DiscountAmount"),
				new System.Data.SqlClient.SqlParameter("@BillTotAfterDiscount", System.Data.SqlDbType.Money, 0, "BillTotAfterDiscount"),
				new System.Data.SqlClient.SqlParameter("@Pay", System.Data.SqlDbType.Money, 0, "Pay"),
				new System.Data.SqlClient.SqlParameter("@Backey", System.Data.SqlDbType.Money, 0, "Backey"),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Qnt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Qnt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Qnt", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Qnt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_UnitPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "UnitPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_UnitPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "UnitPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SanfDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SanfDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SanfDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SanfDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_TotalPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "TotalPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_TotalPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "TotalPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillTotalBeforeDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillTotalBeforeDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillTotalBeforeDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillTotalBeforeDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountPer", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountPer", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountPer", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountPer", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountAmount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountAmount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountAmount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountAmount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillTotAfterDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillTotAfterDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillTotAfterDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillTotAfterDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Pay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Pay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Pay", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Pay", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Backey", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Backey", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Backey", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Backey", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[29]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Qnt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Qnt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Qnt", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Qnt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_UnitPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "UnitPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_UnitPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "UnitPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SanfDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SanfDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SanfDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SanfDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_TotalPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "TotalPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_TotalPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "TotalPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillTotalBeforeDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillTotalBeforeDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillTotalBeforeDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillTotalBeforeDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountPer", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountPer", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountPer", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountPer", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountAmount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountAmount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountAmount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountAmount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillTotAfterDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillTotAfterDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillTotAfterDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillTotAfterDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Pay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Pay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Pay", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Pay", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Backey", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Backey", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Backey", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Backey", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "IncomingBill", new System.Data.Common.DataColumnMapping[15]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("BillNo", "BillNo"),
					new System.Data.Common.DataColumnMapping("SupplierId", "SupplierId"),
					new System.Data.Common.DataColumnMapping("BillDate", "BillDate"),
					new System.Data.Common.DataColumnMapping("ItemId", "ItemId"),
					new System.Data.Common.DataColumnMapping("Qnt", "Qnt"),
					new System.Data.Common.DataColumnMapping("UnitPrice", "UnitPrice"),
					new System.Data.Common.DataColumnMapping("SanfDiscount", "SanfDiscount"),
					new System.Data.Common.DataColumnMapping("TotalPrice", "TotalPrice"),
					new System.Data.Common.DataColumnMapping("BillTotalBeforeDiscount", "BillTotalBeforeDiscount"),
					new System.Data.Common.DataColumnMapping("DiscountPer", "DiscountPer"),
					new System.Data.Common.DataColumnMapping("DiscountAmount", "DiscountAmount"),
					new System.Data.Common.DataColumnMapping("BillTotAfterDiscount", "BillTotAfterDiscount"),
					new System.Data.Common.DataColumnMapping("Pay", "Pay"),
					new System.Data.Common.DataColumnMapping("Backey", "Backey")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			sqlSelectCommand2.CommandText = "SELECT        Supplier.*\r\nFROM            Supplier";
			sqlSelectCommand2.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.CommandText = resources.GetString("sqlInsertCommand2.CommandText");
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[5]
			{
				new System.Data.SqlClient.SqlParameter("@SupName", System.Data.SqlDbType.NVarChar, 0, "SupName"),
				new System.Data.SqlClient.SqlParameter("@SupAddress", System.Data.SqlDbType.NVarChar, 0, "SupAddress"),
				new System.Data.SqlClient.SqlParameter("@NationalId", System.Data.SqlDbType.NVarChar, 0, "NationalId"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mobile", System.Data.SqlDbType.NVarChar, 0, "Mobile")
			});
			sqlUpdateCommand2.CommandText = resources.GetString("sqlUpdateCommand2.CommandText");
			sqlUpdateCommand2.Connection = sqlConnection2;
			sqlUpdateCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[17]
			{
				new System.Data.SqlClient.SqlParameter("@SupName", System.Data.SqlDbType.NVarChar, 0, "SupName"),
				new System.Data.SqlClient.SqlParameter("@SupAddress", System.Data.SqlDbType.NVarChar, 0, "SupAddress"),
				new System.Data.SqlClient.SqlParameter("@NationalId", System.Data.SqlDbType.NVarChar, 0, "NationalId"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mobile", System.Data.SqlDbType.NVarChar, 0, "Mobile"),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NationalId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NationalId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NationalId", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NationalId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@SupplierID", System.Data.SqlDbType.Int, 4, "SupplierID")
			});
			sqlDeleteCommand2.CommandText = resources.GetString("sqlDeleteCommand2.CommandText");
			sqlDeleteCommand2.Connection = sqlConnection2;
			sqlDeleteCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[11]
			{
				new System.Data.SqlClient.SqlParameter("@Original_SupplierID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NationalId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NationalId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NationalId", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NationalId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mobile", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter2.DeleteCommand = sqlDeleteCommand2;
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Supplier", new System.Data.Common.DataColumnMapping[6]
				{
					new System.Data.Common.DataColumnMapping("SupplierID", "SupplierID"),
					new System.Data.Common.DataColumnMapping("SupName", "SupName"),
					new System.Data.Common.DataColumnMapping("SupAddress", "SupAddress"),
					new System.Data.Common.DataColumnMapping("NationalId", "NationalId"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mobile", "Mobile")
				})
			});
			sqlDataAdapter2.UpdateCommand = sqlUpdateCommand2;
			sqlSelectCommand3.CommandText = "SELECT        Items.*\r\nFROM            Items";
			sqlSelectCommand3.Connection = sqlConnection3;
			sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection3.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand3.CommandText = "INSERT INTO [Items] ([Name], [SalePrice]) VALUES (@Name, @SalePrice);\r\nSELECT Id, Name, SalePrice FROM Items WHERE (Id = SCOPE_IDENTITY())";
			sqlInsertCommand3.Connection = sqlConnection3;
			sqlInsertCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@SalePrice", System.Data.SqlDbType.Money, 0, "SalePrice")
			});
			sqlUpdateCommand3.CommandText = resources.GetString("sqlUpdateCommand3.CommandText");
			sqlUpdateCommand3.Connection = sqlConnection3;
			sqlUpdateCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[8]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@SalePrice", System.Data.SqlDbType.Money, 0, "SalePrice"),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Name", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Name", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Name", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Name", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SalePrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SalePrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SalePrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SalePrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDeleteCommand3.CommandText = resources.GetString("sqlDeleteCommand3.CommandText");
			sqlDeleteCommand3.Connection = sqlConnection3;
			sqlDeleteCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[5]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Name", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Name", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Name", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Name", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SalePrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SalePrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SalePrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SalePrice", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter3.DeleteCommand = sqlDeleteCommand3;
			sqlDataAdapter3.InsertCommand = sqlInsertCommand3;
			sqlDataAdapter3.SelectCommand = sqlSelectCommand3;
			sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Items", new System.Data.Common.DataColumnMapping[3]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("Name", "Name"),
					new System.Data.Common.DataColumnMapping("SalePrice", "SalePrice")
				})
			});
			sqlDataAdapter3.UpdateCommand = sqlUpdateCommand3;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(panel1);
			Font = null;
			base.Name = "FrmBillIncomeRpt";
			base.Load += new System.EventHandler(FrmBillIncomeRpt_Load);
			panel1.ResumeLayout(false);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}
	}
}
