using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Properties;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FormSupplier5 : ReportBaseForm
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private GroupBox groupBox1;

		private Button button3;

		private Label label1;

		private DateTimePicker dateTimePicker2;

		private DateTimePicker dateTimePicker1;

		private ComboBox comboBox1;

		private Label label3;

		private Label label2;

		private CrystalReportViewer crystalReportViewer1;

		private DataSet1 data1;

		private Label label4;

		private Button button1;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlSelectCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlInsertCommand2;

		private SqlCommand sqlUpdateCommand2;

		private SqlCommand sqlDeleteCommand2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlSelectCommand3;

		private SqlConnection sqlConnection3;

		private SqlCommand sqlInsertCommand3;

		private SqlCommand sqlUpdateCommand3;

		private SqlCommand sqlDeleteCommand3;

		private SqlDataAdapter sqlDataAdapter3;

		private SqlCommand sqlSelectCommand4;

		private SqlConnection sqlConnection4;

		private SqlDataAdapter sqlDataAdapter4;

		private SqlCommand sqlInsertCommand;

		public FormSupplier5()
		{
			InitializeComponent();
		}

		private void FormSupplier5_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search("select * from Supplier");
				comboBox1.DataSource = dataTable;
				comboBox1.DisplayMember = dataTable.Columns[1].ToString();
				comboBox1.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				Codes.Edit2("update ReportData set Date1 = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' ,Date2 =  '" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "' where ID = " + 1);
				if (comboBox1.Text != "" && comboBox1.SelectedValue != null)
				{
					data1.Clear();
					DataTable dataTable = new DataTable();
					dataTable = Codes.Search2("select * from Supplier5 where SupplierID =" + comboBox1.SelectedValue.ToString() + " and [Date] between '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' and '" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "'");
					if (dataTable.Rows.Count > 0)
					{
						sqlConnection1.ConnectionString = Codes.ConnectionStr;
						sqlConnection2.ConnectionString = Codes.ConnectionStr;
						sqlConnection3.ConnectionString = Codes.ConnectionStr;
						sqlConnection4.ConnectionString = Codes.ConnectionStr;
						sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
						sqlDataAdapter1.SelectCommand.CommandText = "select * from Supplier5 where SupplierID =" + comboBox1.SelectedValue.ToString() + " and [Date] between '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' and '" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "'";
						sqlDataAdapter1.Fill(data1);
						sqlDataAdapter2.Fill(data1);
						sqlDataAdapter3.Fill(data1);
						sqlDataAdapter4.Fill(data1);
						lRPTSupplier5 lRPTSupplier = new lRPTSupplier5();
						lRPTSupplier.SetDataSource(data1);
						crystalReportViewer1.ReportSource = lRPTSupplier;
					}
					else
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("There is no Supplier account in this period", "Error");
						}
						else
						{
							MessageBox.Show("لا يوجد حساب للمورد فى هذه الفترة", "خطأ");
						}
						crystalReportViewer1.ReportSource = null;
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Supplier Name", "Error");
				}
				else
				{
					MessageBox.Show("ادخل اسم المورد", "خطأ");
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Close();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FormSupplier5));
			groupBox1 = new System.Windows.Forms.GroupBox();
			button3 = new System.Windows.Forms.Button();
			label1 = new System.Windows.Forms.Label();
			dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			comboBox1 = new System.Windows.Forms.ComboBox();
			label3 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			data1 = new DataSet1();
			label4 = new System.Windows.Forms.Label();
			button1 = new System.Windows.Forms.Button();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlConnection3 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlConnection4 = new System.Data.SqlClient.SqlConnection();
			sqlDataAdapter4 = new System.Data.SqlClient.SqlDataAdapter();
			sqlInsertCommand = new System.Data.SqlClient.SqlCommand();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)data1).BeginInit();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(button3);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(dateTimePicker2);
			groupBox1.Controls.Add(dateTimePicker1);
			groupBox1.Controls.Add(comboBox1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(label2);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackColor = System.Drawing.Color.Gainsboro;
			button3.BackgroundImage = null;
			button3.Font = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = false;
			button3.Click += new System.EventHandler(button3_Click);
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.ForeColor = System.Drawing.Color.Black;
			label1.Name = "label1";
			dateTimePicker2.AccessibleDescription = null;
			dateTimePicker2.AccessibleName = null;
			resources.ApplyResources(dateTimePicker2, "dateTimePicker2");
			dateTimePicker2.BackgroundImage = null;
			dateTimePicker2.CalendarFont = null;
			dateTimePicker2.Font = null;
			dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker2.Name = "dateTimePicker2";
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.Font = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.DisplayMember = "ID";
			comboBox1.Font = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Name = "comboBox1";
			comboBox1.ValueMember = "ID";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Font = null;
			label3.ForeColor = System.Drawing.Color.Black;
			label3.Name = "label3";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Font = null;
			label2.ForeColor = System.Drawing.Color.Black;
			label2.Name = "label2";
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			data1.DataSetName = "Data";
			data1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.BackColor = System.Drawing.Color.DimGray;
			label4.ForeColor = System.Drawing.Color.White;
			label4.Name = "label4";
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.White;
			button1.BackgroundImage = null;
			button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
			button1.Font = null;
			button1.ForeColor = System.Drawing.Color.Black;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			sqlSelectCommand1.CommandText = "SELECT     Supplier5.*\r\nFROM         Supplier5";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[6]
			{
				new System.Data.SqlClient.SqlParameter("@SupplierId", System.Data.SqlDbType.Int, 0, "SupplierId"),
				new System.Data.SqlClient.SqlParameter("@Daen", System.Data.SqlDbType.Money, 0, "Daen"),
				new System.Data.SqlClient.SqlParameter("@Madeen", System.Data.SqlDbType.Money, 0, "Madeen"),
				new System.Data.SqlClient.SqlParameter("@Raseed", System.Data.SqlDbType.Money, 0, "Raseed"),
				new System.Data.SqlClient.SqlParameter("@Bayan", System.Data.SqlDbType.NVarChar, 0, "Bayan"),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[18]
			{
				new System.Data.SqlClient.SqlParameter("@SupplierId", System.Data.SqlDbType.Int, 0, "SupplierId"),
				new System.Data.SqlClient.SqlParameter("@Daen", System.Data.SqlDbType.Money, 0, "Daen"),
				new System.Data.SqlClient.SqlParameter("@Madeen", System.Data.SqlDbType.Money, 0, "Madeen"),
				new System.Data.SqlClient.SqlParameter("@Raseed", System.Data.SqlDbType.Money, 0, "Raseed"),
				new System.Data.SqlClient.SqlParameter("@Bayan", System.Data.SqlDbType.NVarChar, 0, "Bayan"),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Daen", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Daen", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Daen", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Daen", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Madeen", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Madeen", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Madeen", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Madeen", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Raseed", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Raseed", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Raseed", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Raseed", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Date", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Date", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Date", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Date", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[11]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Daen", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Daen", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Daen", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Daen", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Madeen", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Madeen", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Madeen", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Madeen", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Raseed", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Raseed", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Raseed", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Raseed", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Date", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Date", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Date", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Date", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Supplier5", new System.Data.Common.DataColumnMapping[7]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("SupplierId", "SupplierId"),
					new System.Data.Common.DataColumnMapping("Daen", "Daen"),
					new System.Data.Common.DataColumnMapping("Madeen", "Madeen"),
					new System.Data.Common.DataColumnMapping("Raseed", "Raseed"),
					new System.Data.Common.DataColumnMapping("Bayan", "Bayan"),
					new System.Data.Common.DataColumnMapping("Date", "Date")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			sqlSelectCommand2.CommandText = "SELECT     Supplier.*\r\nFROM         Supplier";
			sqlSelectCommand2.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.CommandText = resources.GetString("sqlInsertCommand2.CommandText");
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[5]
			{
				new System.Data.SqlClient.SqlParameter("@SupName", System.Data.SqlDbType.NVarChar, 0, "SupName"),
				new System.Data.SqlClient.SqlParameter("@SupAddress", System.Data.SqlDbType.NVarChar, 0, "SupAddress"),
				new System.Data.SqlClient.SqlParameter("@NationalId", System.Data.SqlDbType.NVarChar, 0, "NationalId"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mobile", System.Data.SqlDbType.NVarChar, 0, "Mobile")
			});
			sqlUpdateCommand2.CommandText = resources.GetString("sqlUpdateCommand2.CommandText");
			sqlUpdateCommand2.Connection = sqlConnection2;
			sqlUpdateCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[17]
			{
				new System.Data.SqlClient.SqlParameter("@SupName", System.Data.SqlDbType.NVarChar, 0, "SupName"),
				new System.Data.SqlClient.SqlParameter("@SupAddress", System.Data.SqlDbType.NVarChar, 0, "SupAddress"),
				new System.Data.SqlClient.SqlParameter("@NationalId", System.Data.SqlDbType.NVarChar, 0, "NationalId"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mobile", System.Data.SqlDbType.NVarChar, 0, "Mobile"),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NationalId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NationalId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NationalId", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NationalId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@SupplierID", System.Data.SqlDbType.Int, 4, "SupplierID")
			});
			sqlDeleteCommand2.CommandText = resources.GetString("sqlDeleteCommand2.CommandText");
			sqlDeleteCommand2.Connection = sqlConnection2;
			sqlDeleteCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[11]
			{
				new System.Data.SqlClient.SqlParameter("@Original_SupplierID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NationalId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NationalId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NationalId", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NationalId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mobile", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter2.DeleteCommand = sqlDeleteCommand2;
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Supplier", new System.Data.Common.DataColumnMapping[6]
				{
					new System.Data.Common.DataColumnMapping("SupplierID", "SupplierID"),
					new System.Data.Common.DataColumnMapping("SupName", "SupName"),
					new System.Data.Common.DataColumnMapping("SupAddress", "SupAddress"),
					new System.Data.Common.DataColumnMapping("NationalId", "NationalId"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mobile", "Mobile")
				})
			});
			sqlDataAdapter2.UpdateCommand = sqlUpdateCommand2;
			sqlSelectCommand3.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand3.Connection = sqlConnection3;
			sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection3.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand3.CommandText = resources.GetString("sqlInsertCommand3.CommandText");
			sqlInsertCommand3.Connection = sqlConnection3;
			sqlInsertCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[8]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData")
			});
			sqlUpdateCommand3.CommandText = resources.GetString("sqlUpdateCommand3.CommandText");
			sqlUpdateCommand3.Connection = sqlConnection3;
			sqlUpdateCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[22]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand3.CommandText = resources.GetString("sqlDeleteCommand3.CommandText");
			sqlDeleteCommand3.Connection = sqlConnection3;
			sqlDeleteCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter3.DeleteCommand = sqlDeleteCommand3;
			sqlDataAdapter3.InsertCommand = sqlInsertCommand3;
			sqlDataAdapter3.SelectCommand = sqlSelectCommand3;
			sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[9]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData")
				})
			});
			sqlDataAdapter3.UpdateCommand = sqlUpdateCommand3;
			sqlSelectCommand4.CommandText = "SELECT        ReportData.*\r\nFROM            ReportData";
			sqlSelectCommand4.Connection = sqlConnection4;
			sqlConnection4.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection4.FireInfoMessageEventOnUserErrors = false;
			sqlDataAdapter4.InsertCommand = sqlInsertCommand;
			sqlDataAdapter4.SelectCommand = sqlSelectCommand4;
			sqlDataAdapter4.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "ReportData", new System.Data.Common.DataColumnMapping[4]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Name", "Name"),
					new System.Data.Common.DataColumnMapping("Date1", "Date1"),
					new System.Data.Common.DataColumnMapping("Date2", "Date2")
				})
			});
			sqlInsertCommand.CommandText = "INSERT INTO [ReportData] ([Name], [Date1], [Date2]) VALUES (@Name, @Date1, @Date2)";
			sqlInsertCommand.Connection = sqlConnection4;
			sqlInsertCommand.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[3]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Date1", System.Data.SqlDbType.DateTime, 0, "Date1"),
				new System.Data.SqlClient.SqlParameter("@Date2", System.Data.SqlDbType.DateTime, 0, "Date2")
			});
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightGray;
			BackgroundImage = null;
			base.Controls.Add(groupBox1);
			base.Controls.Add(crystalReportViewer1);
			base.Controls.Add(label4);
			base.Controls.Add(button1);
			Font = null;
			base.Name = "FormSupplier5";
			base.Load += new System.EventHandler(FormSupplier5_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)data1).EndInit();
			ResumeLayout(false);
		}
	}
}
