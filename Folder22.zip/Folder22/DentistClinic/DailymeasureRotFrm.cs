using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Properties;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class DailymeasureRotFrm : ReportBaseForm
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private GroupBox groupBox2;

		private CrystalReportViewer crystalReportViewer1;

		private GroupBox groupBox1;

		private DateTimePicker date2;

		private Button ViewRptBtn;

		private DateTimePicker date1;

		private Label label3;

		private Label label2;

		private DataSet1 dataSet11;

		public DailymeasureRotFrm()
		{
			InitializeComponent();
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			try
			{
				dataSet11.Clear();
				decimal num = 0m;
				DataTable dataTable = new DataTable();
				dataTable.Columns.Add("Accounts");
				DataTable dataTable2 = Codes.Search2("SELECT     isnull(sum(Price),0) as account, date FROM  StokeMove where type<>'رصيد اول المدة'  and Date between'" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "'  group by date");
				decimal num2 = decimal.MaxValue;
				decimal num3 = decimal.MinValue;
				foreach (DataRow row in dataTable2.Rows)
				{
					decimal num4 = DataRowExtensions.Field<decimal>(row, "account");
					if (num4 > 0m)
					{
						dataTable.Rows.Add(num4);
						num += num4;
						num2 = Math.Min(num2, num4);
						num3 = Math.Max(num3, num4);
					}
				}
				decimal num5 = num / (decimal)dataTable.Rows.Count;
				((DataTable)(object)dataSet11.DailyReportMeasure).Rows.Add(dataTable.Rows.Count, num3, num2, num5);
				((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value, date2.Value);
				DailymeasureRpt dailymeasureRpt = new DailymeasureRpt();
				dailymeasureRpt.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = dailymeasureRpt;
			}
			catch
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("No Data");
				}
				else
				{
					MessageBox.Show("لا يوجد بيانات");
				}
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.date2 = new System.Windows.Forms.DateTimePicker();
            this.ViewRptBtn = new System.Windows.Forms.Button();
            this.date1 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataSet11 = new DataSet1();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.crystalReportViewer1);
            this.groupBox2.Location = new System.Drawing.Point(6, 60);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(702, 461);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crystalReportViewer1.Location = new System.Drawing.Point(3, 16);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.SelectionFormula = "";
            this.crystalReportViewer1.Size = new System.Drawing.Size(696, 442);
            this.crystalReportViewer1.TabIndex = 0;
            this.crystalReportViewer1.ViewTimeSelectionFormula = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.date2);
            this.groupBox1.Controls.Add(this.ViewRptBtn);
            this.groupBox1.Controls.Add(this.date1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(6, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(699, 52);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // date2
            // 
            this.date2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.date2.CustomFormat = "dd/MM/yyyy";
            this.date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date2.Location = new System.Drawing.Point(293, 16);
            this.date2.Name = "date2";
            this.date2.RightToLeftLayout = true;
            this.date2.Size = new System.Drawing.Size(156, 20);
            this.date2.TabIndex = 8;
            // 
            // ViewRptBtn
            // 
            this.ViewRptBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.ViewRptBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ViewRptBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.ViewRptBtn.Location = new System.Drawing.Point(172, 10);
            this.ViewRptBtn.Name = "ViewRptBtn";
            this.ViewRptBtn.Size = new System.Drawing.Size(115, 33);
            this.ViewRptBtn.TabIndex = 9;
            this.ViewRptBtn.Text = "عرض التقرير";
            this.ViewRptBtn.UseVisualStyleBackColor = false;
            this.ViewRptBtn.Click += new System.EventHandler(this.ViewRptBtn_Click);
            // 
            // date1
            // 
            this.date1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.date1.CustomFormat = "dd/MM/yyyy";
            this.date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date1.Location = new System.Drawing.Point(489, 16);
            this.date1.Name = "date1";
            this.date1.RightToLeftLayout = true;
            this.date1.Size = new System.Drawing.Size(156, 20);
            this.date1.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(455, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "الي";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(651, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 18);
            this.label2.TabIndex = 6;
            this.label2.Text = "من";
            // 
            // dataSet11
            // 
            this.dataSet11.DataSetName = "DataSet1";
            this.dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // DailymeasureRotFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(715, 525);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "DailymeasureRotFrm";
            this.Text = "مقارنة التقرير اليومي";
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).EndInit();
            this.ResumeLayout(false);

		}
	}
}
