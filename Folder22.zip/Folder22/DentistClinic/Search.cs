namespace DentistClinic
{
	internal class Search
	{
		public static string text;
	}
}
