using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Properties;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmEsal : ReportBaseForm
	{
		private IContainer components = null;

		private CrystalReportViewer crystalReportViewer1;

		private GroupBox groupBox1;

		private Button button1;

		private NumericUpDown numericUpDown1;

		private Label label1;

		private RadioButton radioButton2;

		private RadioButton radioButton1;

		private GroupBox groupBox2;

		private DataSet1 dataSet11;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlDeleteCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand2;

		private SqlCommand sqlSelectCommand1;

		private SqlCommand sqlUpdateCommand1;

		private RadioButton radioButton3;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlCommand3;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private bool ClinicTeath;

		public static bool x = true;

		public static bool y = true;

		public static bool xx = true;

		public static string EsalNo = "";

		private double OldPay = 0.0;

		private double Rest = 0.0;

		private double Pay = 0.0;

		private double totalPrice = 0.0;

		private DataTable dt;

		private double PayPrice = 0.0;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmEsal));
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			groupBox1 = new System.Windows.Forms.GroupBox();
			radioButton3 = new System.Windows.Forms.RadioButton();
			button1 = new System.Windows.Forms.Button();
			numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			label1 = new System.Windows.Forms.Label();
			radioButton2 = new System.Windows.Forms.RadioButton();
			radioButton1 = new System.Windows.Forms.RadioButton();
			groupBox2 = new System.Windows.Forms.GroupBox();
			dataSet11 = new DataSet1();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlCommand3 = new System.Data.SqlClient.SqlCommand();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(radioButton3);
			groupBox1.Controls.Add(button1);
			groupBox1.Controls.Add(numericUpDown1);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(radioButton2);
			groupBox1.Controls.Add(radioButton1);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			resources.ApplyResources(radioButton3, "radioButton3");
			radioButton3.Name = "radioButton3";
			radioButton3.UseVisualStyleBackColor = true;
			resources.ApplyResources(button1, "button1");
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			resources.ApplyResources(numericUpDown1, "numericUpDown1");
			numericUpDown1.Maximum = new decimal(new int[4] { -727379969, 232, 0, 0 });
			numericUpDown1.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			numericUpDown1.Name = "numericUpDown1";
			numericUpDown1.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			resources.ApplyResources(radioButton2, "radioButton2");
			radioButton2.Name = "radioButton2";
			radioButton2.UseVisualStyleBackColor = true;
			resources.ApplyResources(radioButton1, "radioButton1");
			radioButton1.Checked = true;
			radioButton1.Name = "radioButton1";
			radioButton1.TabStop = true;
			radioButton1.UseVisualStyleBackColor = true;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[9]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.CommandText = resources.GetString("sqlInsertCommand2.CommandText");
			sqlInsertCommand2.Connection = sqlConnection1;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[8]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData")
			});
			sqlSelectCommand1.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[22]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDataAdapter2.InsertCommand = sqlCommand2;
			sqlDataAdapter2.SelectCommand = sqlCommand3;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[51]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
					new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
					new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
					new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
					new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
					new System.Data.Common.DataColumnMapping("Implant", "Implant"),
					new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
					new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers"),
					new System.Data.Common.DataColumnMapping("DoctoreName", "DoctoreName"),
					new System.Data.Common.DataColumnMapping("NextVisit", "NextVisit"),
					new System.Data.Common.DataColumnMapping("Accept", "Accept"),
					new System.Data.Common.DataColumnMapping("Taqweem", "Taqweem"),
					new System.Data.Common.DataColumnMapping("Photo", "Photo"),
					new System.Data.Common.DataColumnMapping("BloodType", "BloodType"),
					new System.Data.Common.DataColumnMapping("Active", "Active"),
					new System.Data.Common.DataColumnMapping("FileNo", "FileNo"),
					new System.Data.Common.DataColumnMapping("Patient", "Patient"),
					new System.Data.Common.DataColumnMapping("Facebook", "Facebook"),
					new System.Data.Common.DataColumnMapping("Adv", "Adv"),
					new System.Data.Common.DataColumnMapping("FormerPatient", "FormerPatient"),
					new System.Data.Common.DataColumnMapping("Discount", "Discount"),
					new System.Data.Common.DataColumnMapping("Without", "Without"),
					new System.Data.Common.DataColumnMapping("Doctor", "Doctor"),
					new System.Data.Common.DataColumnMapping("DoctorId", "DoctorId")
				})
			});
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlCommand2.CommandText = resources.GetString("sqlCommand2.CommandText");
			sqlCommand2.Connection = sqlConnection2;
			sqlCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[50]
			{
				new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
				new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
				new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
				new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
				new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
				new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
				new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
				new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
				new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
				new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
				new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
				new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
				new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
				new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
				new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
				new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
				new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
				new System.Data.SqlClient.SqlParameter("@Lactating", System.Data.SqlDbType.Bit, 0, "Lactating"),
				new System.Data.SqlClient.SqlParameter("@Pregnant", System.Data.SqlDbType.Bit, 0, "Pregnant"),
				new System.Data.SqlClient.SqlParameter("@HepatitisB", System.Data.SqlDbType.Bit, 0, "HepatitisB"),
				new System.Data.SqlClient.SqlParameter("@Hepatitisc", System.Data.SqlDbType.Bit, 0, "Hepatitisc"),
				new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
				new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
				new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
				new System.Data.SqlClient.SqlParameter("@Endodontics", System.Data.SqlDbType.Bit, 0, "Endodontics"),
				new System.Data.SqlClient.SqlParameter("@Fixed", System.Data.SqlDbType.Bit, 0, "Fixed"),
				new System.Data.SqlClient.SqlParameter("@Implant", System.Data.SqlDbType.Bit, 0, "Implant"),
				new System.Data.SqlClient.SqlParameter("@Opretive", System.Data.SqlDbType.Bit, 0, "Opretive"),
				new System.Data.SqlClient.SqlParameter("@Bleaching", System.Data.SqlDbType.Bit, 0, "Bleaching"),
				new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers"),
				new System.Data.SqlClient.SqlParameter("@DoctoreName", System.Data.SqlDbType.NVarChar, 0, "DoctoreName"),
				new System.Data.SqlClient.SqlParameter("@NextVisit", System.Data.SqlDbType.NVarChar, 0, "NextVisit"),
				new System.Data.SqlClient.SqlParameter("@Accept", System.Data.SqlDbType.Bit, 0, "Accept"),
				new System.Data.SqlClient.SqlParameter("@Taqweem", System.Data.SqlDbType.Bit, 0, "Taqweem"),
				new System.Data.SqlClient.SqlParameter("@Photo", System.Data.SqlDbType.Image, 0, "Photo"),
				new System.Data.SqlClient.SqlParameter("@BloodType", System.Data.SqlDbType.NVarChar, 0, "BloodType"),
				new System.Data.SqlClient.SqlParameter("@Active", System.Data.SqlDbType.Bit, 0, "Active"),
				new System.Data.SqlClient.SqlParameter("@FileNo", System.Data.SqlDbType.Int, 0, "FileNo"),
				new System.Data.SqlClient.SqlParameter("@Patient", System.Data.SqlDbType.Bit, 0, "Patient"),
				new System.Data.SqlClient.SqlParameter("@Facebook", System.Data.SqlDbType.Bit, 0, "Facebook"),
				new System.Data.SqlClient.SqlParameter("@Adv", System.Data.SqlDbType.Bit, 0, "Adv"),
				new System.Data.SqlClient.SqlParameter("@FormerPatient", System.Data.SqlDbType.NVarChar, 0, "FormerPatient"),
				new System.Data.SqlClient.SqlParameter("@Discount", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Discount", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Without", System.Data.SqlDbType.Bit, 0, "Without"),
				new System.Data.SqlClient.SqlParameter("@Doctor", System.Data.SqlDbType.Bit, 0, "Doctor"),
				new System.Data.SqlClient.SqlParameter("@DoctorId", System.Data.SqlDbType.NVarChar, 0, "DoctorId")
			});
			sqlCommand3.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlCommand3.Connection = sqlConnection2;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.Name = "FrmEsal";
			base.Load += new System.EventHandler(FrmEsal_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}

		public FrmEsal()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			dataSet11.Clear();
			OldPay = 0.0;
			Rest = 0.0;
			Pay = 0.0;
			totalPrice = 0.0;
			PayPrice = 0.0;
			DataTable dataTable = Codes.Search2("select chTxtUnderPres,TxtUnderPres from Properties");
			string text = "";
			text = ((!Convert.ToBoolean(dataTable.Rows[0]["chTxtUnderPres"].ToString())) ? "" : dataTable.Rows[0]["TxtUnderPres"].ToString());
			if (radioButton1.Checked)
			{
				try
				{
					ClinicTeath = Convert.ToBoolean(Codes.Search2("select ClinicType from DentalData").Rows[0][0].ToString());
					dt = Codes.Search2("SELECT     dbo.Esal.Patient, dbo.Esal.Date, dbo.Esal.Bean, dbo.Esal.Price, dbo.Esal.Pay, dbo.Esal.Teeth, dbo.Esal.Company, dbo.Esal.Username, dbo.Esal.EsalNo, \r\n                      dbo.Esal.PatientAcountId, dbo.Esal.Assistant, dbo.PatientAccount.PatientId,dbo.Esal.Id,dbo.PatientAccount.Dariba ,dbo.PatientAccount.PriceBeforeDariba, PatientAccount.DoctorID\r\nFROM         dbo.Esal INNER JOIN\r\n                      dbo.PatientAccount ON dbo.Esal.PatientAcountId = dbo.PatientAccount.ID where dbo.Esal.EsalNo = '" + numericUpDown1.Value + "'");
					if (dt.Rows.Count == 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("No Data");
						}
						else
						{
							MessageBox.Show("لا يوجد ايصالات بهذا الرقم");
						}
						return;
					}
					DataTable dataTable2 = Codes.Search2("select isnull(sum(Price),0),isnull(sum(PricePay),0) from PatientAccount where PatientId = '" + dt.Rows[0]["PatientId"].ToString() + "' and Pay = 'False'");
					for (int i = 0; i < dt.Rows.Count; i++)
					{
						totalPrice += Convert.ToDouble(dt.Rows[i][3]);
						Pay += Convert.ToDouble(dt.Rows[i][4]);
						DataTable dataTable3 = Codes.Search2("select isnull(sum(Pay),0) from Esal where PatientAcountId = '" + dt.Rows[i]["PatientAcountId"].ToString() + "' and Id < '" + dt.Rows[i]["Id"].ToString() + "'");
						if (dataTable3.Rows.Count > 0)
						{
							OldPay += Convert.ToDouble(dataTable3.Rows[0][0]);
						}
					}
					Rest = Convert.ToDouble(totalPrice) - OldPay - Pay;
					for (int i = 0; i < dt.Rows.Count; i++)
					{
						PayPrice = 0.0;
						if (dt.Rows[i]["Price"].ToString() == dt.Rows[i]["Pay"].ToString())
						{
							PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString()) + Convert.ToDouble(dt.Rows[i]["Pay"].ToString());
						}
						else
						{
							PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString());
						}
						((DataTable)(object)dataSet11.Statment).Rows.Add(dt.Rows[i][0].ToString(), Convert.ToDateTime(dt.Rows[i][1].ToString()), dt.Rows[i][2].ToString(), Convert.ToDouble(totalPrice).ToString(), dt.Rows[i][3].ToString(), Convert.ToString(Pay), dt.Rows[i][5].ToString(), dt.Rows[i][6].ToString(), dt.Rows[i][7].ToString(), dt.Rows[i][8].ToString(), Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString(), Convert.ToDouble(dt.Rows[i]["Price"].ToString()) / Convert.ToDouble(Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString()), 0, Codes.Search2("select Name from Empdata where ID='" + dt.Rows[i]["DoctorID"].ToString() + "'").Rows[0][0].ToString());
						string text2 = dt.Rows[i][2].ToString();
						if (text2 == "سحب كميات اصناف")
						{
							DataTable dataTable4 = Codes.Search2("SELECT     dbo.Items.Name, dbo.Sahb_details.Qty, dbo.Sahb_details.Price\r\nFROM         dbo.Sahb INNER JOIN\r\n                      dbo.Sahb_details ON dbo.Sahb.ID = dbo.Sahb_details.SahbId INNER JOIN\r\n                      dbo.Items ON dbo.Sahb_details.ItemId = dbo.Items.Id where Sahb.PatientAccountId = '" + dt.Rows[i][9].ToString() + "'");
							for (int j = 0; j < dataTable4.Rows.Count; j++)
							{
								((DataTable)(object)dataSet11.SahbItemEsal).Rows.Add(dataTable4.Rows[j][0].ToString(), dataTable4.Rows[j][1].ToString(), dataTable4.Rows[j][2].ToString(), 0);
							}
						}
					}
					if (ClinicTeath)
					{
						sqlConnection1.ConnectionString = Codes.ConnectionStr;
						sqlDataAdapter1.Fill(dataSet11);
						sqlConnection2.ConnectionString = Codes.ConnectionStr;
						sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
						sqlDataAdapter2.SelectCommand.CommandText = "select * from PatientData where ID ='" + dt.Rows[0]["PatientId"].ToString() + "'";
						sqlDataAdapter2.Fill(dataSet11);
						DataTable dataTable5 = Codes.Search2("select EsalPrinter from Properties");
						switch (dataTable5.Rows[0][0].ToString())
						{
						case "A5":
						{
							ReportDocument reportDocument = new ReportDocument();
							reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptA5.rpt");
							try
							{
								reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
								textObject.Text = text;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
								textObject.Text = OldPay.ToString();
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
								textObject.Text = Rest.ToString();
							}
							catch
							{
							}
							reportDocument.SetDataSource(dataSet11);
							crystalReportViewer1.ReportSource = reportDocument;
							break;
						}
						case "Reset":
						{
							ReportDocument reportDocument = new ReportDocument();
							reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptReset.rpt");
							try
							{
								reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
								textObject.Text = text;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
								textObject.Text = OldPay.ToString();
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
								textObject.Text = Rest.ToString();
							}
							catch
							{
							}
							reportDocument.SetDataSource(dataSet11);
							crystalReportViewer1.ReportSource = reportDocument;
							break;
						}
						case "1/2 A4":
						{
							((DataTable)(object)dataSet11.Statment).Rows.Clear();
							OldPay = 0.0;
							double num = 0.0;
							for (int i = 0; i < dt.Rows.Count; i++)
							{
								DataTable dataTable3 = Codes.Search2("select isnull(sum(Pay),0) from Esal where PatientAcountId = '" + dt.Rows[i]["PatientAcountId"].ToString() + "' and Id < '" + dt.Rows[i]["Id"].ToString() + "'");
								OldPay = Convert.ToDouble(dataTable3.Rows[0][0]);
								DataTable dataTable6 = Codes.Search2("SELECT dbo.PatientAccount.Bean FROM  dbo.CompanyService INNER JOIN\r\n                      dbo.PatientAccount ON dbo.CompanyService.Service COLLATE SQL_Latin1_General_CP1_CI_AS = dbo.PatientAccount.Bean where dbo.PatientAccount.ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'");
								if (dataTable6.Rows.Count > 0)
								{
									num += Convert.ToDouble(dt.Rows[i]["PriceBeforeDariba"].ToString());
									PayPrice = 0.0;
									if (dt.Rows[i]["Price"].ToString() == dt.Rows[i]["Pay"].ToString())
									{
										PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString()) + Convert.ToDouble(dt.Rows[i]["Pay"].ToString());
									}
									else
									{
										PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString());
									}
									((DataTable)(object)dataSet11.Statment).Rows.Add(dt.Rows[i][0].ToString(), Convert.ToDateTime(dt.Rows[i][1].ToString()), dt.Rows[i][2].ToString(), Convert.ToDouble(num).ToString(), OldPay, Convert.ToDouble(Pay), dt.Rows[i][5].ToString(), dt.Rows[i][6].ToString(), dt.Rows[i][7].ToString(), dt.Rows[i][8].ToString(), Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString(), Convert.ToDouble(dt.Rows[i]["PriceBeforeDariba"].ToString()) / Convert.ToDouble(Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString()), Convert.ToDouble(dt.Rows[i]["PriceBeforeDariba"].ToString()) * Convert.ToDouble(dt.Rows[i]["Dariba"].ToString()) / 100.0, Codes.Search2("select Name from Empdata where ID='" + dt.Rows[i]["DoctorID"].ToString() + "'").Rows[0][0].ToString());
								}
								else
								{
									num += Convert.ToDouble(dt.Rows[i]["Price"].ToString());
									PayPrice = 0.0;
									if (dt.Rows[i]["Price"].ToString() == dt.Rows[i]["Pay"].ToString())
									{
										PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString()) + Convert.ToDouble(dt.Rows[i]["Pay"].ToString());
									}
									else
									{
										PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString());
									}
									((DataTable)(object)dataSet11.Statment).Rows.Add(dt.Rows[i][0].ToString(), Convert.ToDateTime(dt.Rows[i][1].ToString()), dt.Rows[i][2].ToString(), Convert.ToDouble(num).ToString(), OldPay, Convert.ToDouble(Pay), dt.Rows[i][5].ToString(), dt.Rows[i][6].ToString(), dt.Rows[i][7].ToString(), dt.Rows[i][8].ToString(), Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString(), Convert.ToDouble(dt.Rows[i]["Price"].ToString()) / Convert.ToDouble(Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString()), 0, Codes.Search2("select Name from Empdata where ID='" + dt.Rows[i]["DoctorID"].ToString() + "'").Rows[0][0].ToString());
								}
							}
							sqlConnection2.ConnectionString = Codes.ConnectionStr;
							sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
							sqlDataAdapter2.SelectCommand.CommandText = "select * from PatientData where ID ='" + dt.Rows[0]["PatientId"].ToString() + "'";
							sqlDataAdapter2.Fill(dataSet11);
							ReportDocument reportDocument = new ReportDocument();
							reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt_HalfA4.rpt");
							try
							{
								reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
								textObject.Text = text;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
								textObject.Text = OldPay.ToString();
							}
							catch
							{
							}
							reportDocument.SetDataSource(dataSet11);
							try
							{
								DataTable dataTable7 = Codes.Search2("select Name from Empdata where ID='" + dt.Rows[0]["DoctorID"].ToString() + "' ");
								reportDocument.SetParameterValue("DoctorName", dataTable7.Rows[0][0].ToString());
							}
							catch
							{
							}
							crystalReportViewer1.ReportSource = reportDocument;
							break;
						}
						default:
						{
							ReportDocument reportDocument = new ReportDocument();
							reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt.rpt");
							try
							{
								reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
								textObject.Text = text;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
								textObject.Text = OldPay.ToString();
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
								textObject.Text = Rest.ToString();
							}
							catch
							{
							}
							reportDocument.SetDataSource(dataSet11);
							reportDocument.SetParameterValue("Assistant", dt.Rows[0][10].ToString());
							crystalReportViewer1.ReportSource = reportDocument;
							break;
						}
						}
					}
					else
					{
						sqlConnection1.ConnectionString = Codes.ConnectionStr;
						sqlDataAdapter1.Fill(dataSet11);
						sqlConnection2.ConnectionString = Codes.ConnectionStr;
						sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
						sqlDataAdapter2.SelectCommand.CommandText = "select * from PatientData where ID ='" + dt.Rows[0]["PatientId"].ToString() + "'";
						sqlDataAdapter2.Fill(dataSet11);
						DataTable dataTable5 = Codes.Search2("select EsalPrinter from Properties");
						switch (dataTable5.Rows[0][0].ToString())
						{
						case "A5":
						{
							ReportDocument reportDocument = new ReportDocument();
							reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptA5.rpt");
							try
							{
								reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
								textObject.Text = text;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
								textObject.Text = OldPay.ToString();
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
								textObject.Text = Rest.ToString();
							}
							catch
							{
							}
							reportDocument.SetDataSource(dataSet11);
							crystalReportViewer1.ReportSource = reportDocument;
							break;
						}
						case "Reset":
						{
							ReportDocument reportDocument = new ReportDocument();
							reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1Reset.rpt");
							try
							{
								reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
								textObject.Text = text;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
								textObject.Text = OldPay.ToString();
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
								textObject.Text = Rest.ToString();
							}
							catch
							{
							}
							reportDocument.SetDataSource(dataSet11);
							crystalReportViewer1.ReportSource = reportDocument;
							break;
						}
						case "1/2 A4":
						{
							((DataTable)(object)dataSet11.Statment).Rows.Clear();
							OldPay = 0.0;
							double num = 0.0;
							for (int i = 0; i < dt.Rows.Count; i++)
							{
								DataTable dataTable3 = Codes.Search2("select isnull(sum(Pay),0) from Esal where PatientAcountId = '" + dt.Rows[i]["PatientAcountId"].ToString() + "' and Id < '" + dt.Rows[i]["Id"].ToString() + "'");
								OldPay = Convert.ToDouble(dataTable3.Rows[0][0]);
								DataTable dataTable6 = Codes.Search2("SELECT dbo.PatientAccount.Bean FROM  dbo.CompanyService INNER JOIN\r\n                      dbo.PatientAccount ON dbo.CompanyService.Service COLLATE SQL_Latin1_General_CP1_CI_AS = dbo.PatientAccount.Bean where dbo.PatientAccount.ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'");
								if (dataTable6.Rows.Count > 0)
								{
									num += Convert.ToDouble(dt.Rows[i]["PriceBeforeDariba"].ToString());
									PayPrice = 0.0;
									if (dt.Rows[i]["Price"].ToString() == dt.Rows[i]["Pay"].ToString())
									{
										PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString()) + Convert.ToDouble(dt.Rows[i]["Pay"].ToString());
									}
									else
									{
										PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString());
									}
									((DataTable)(object)dataSet11.Statment).Rows.Add(dt.Rows[i][0].ToString(), Convert.ToDateTime(dt.Rows[i][1].ToString()), dt.Rows[i][2].ToString(), Convert.ToDouble(num).ToString(), OldPay, Convert.ToDouble(Pay), dt.Rows[i][5].ToString(), dt.Rows[i][6].ToString(), dt.Rows[i][7].ToString(), dt.Rows[i][8].ToString(), Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString(), Convert.ToDouble(dt.Rows[i]["PriceBeforeDariba"].ToString()) / Convert.ToDouble(Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString()), Convert.ToDouble(dt.Rows[i]["PriceBeforeDariba"].ToString()) * Convert.ToDouble(dt.Rows[i]["Dariba"].ToString()) / 100.0, Codes.Search2("select Name from Empdata where ID='" + dt.Rows[i]["DoctorID"].ToString() + "'").Rows[0][0].ToString());
								}
								else
								{
									num += Convert.ToDouble(dt.Rows[i]["Price"].ToString());
									PayPrice = 0.0;
									if (dt.Rows[i]["Price"].ToString() == dt.Rows[i]["Pay"].ToString())
									{
										PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString()) + Convert.ToDouble(dt.Rows[i]["Pay"].ToString());
									}
									else
									{
										PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString());
									}
									((DataTable)(object)dataSet11.Statment).Rows.Add(dt.Rows[i][0].ToString(), Convert.ToDateTime(dt.Rows[i][1].ToString()), dt.Rows[i][2].ToString(), Convert.ToDouble(num).ToString(), OldPay, Convert.ToDouble(Pay), dt.Rows[i][5].ToString(), dt.Rows[i][6].ToString(), dt.Rows[i][7].ToString(), dt.Rows[i][8].ToString(), Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString(), Convert.ToDouble(dt.Rows[i]["Price"].ToString()) / Convert.ToDouble(Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString()), 0, Codes.Search2("select Name from Empdata where ID='" + dt.Rows[i]["DoctorID"].ToString() + "'").Rows[0][0].ToString());
								}
							}
							sqlConnection2.ConnectionString = Codes.ConnectionStr;
							sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
							sqlDataAdapter2.SelectCommand.CommandText = "select * from PatientData where ID ='" + dt.Rows[0]["PatientId"].ToString() + "'";
							sqlDataAdapter2.Fill(dataSet11);
							ReportDocument reportDocument = new ReportDocument();
							reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt_HalfA4.rpt");
							try
							{
								reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
								textObject.Text = text;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
								textObject.Text = OldPay.ToString();
							}
							catch
							{
							}
							reportDocument.SetDataSource(dataSet11);
							try
							{
								DataTable dataTable7 = Codes.Search2("select Name from Empdata where ID='" + dt.Rows[0]["DoctorID"].ToString() + "' ");
								reportDocument.SetParameterValue("DoctorName", dataTable7.Rows[0][0].ToString());
							}
							catch
							{
							}
							crystalReportViewer1.ReportSource = reportDocument;
							break;
						}
						default:
						{
							ReportDocument reportDocument = new ReportDocument();
							reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1.rpt");
							try
							{
								reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
								textObject.Text = text;
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
								textObject.Text = OldPay.ToString();
							}
							catch
							{
							}
							try
							{
								TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
								textObject.Text = Rest.ToString();
							}
							catch
							{
							}
							reportDocument.SetDataSource(dataSet11);
							reportDocument.SetParameterValue("Assistant", dt.Rows[0][10].ToString());
							crystalReportViewer1.ReportSource = reportDocument;
							break;
						}
						}
					}
				}
				catch
				{
				}
			}
			if (radioButton2.Checked)
			{
				try
				{
					sqlConnection1.ConnectionString = Codes.ConnectionStr;
					sqlDataAdapter1.Fill(dataSet11);
					DataTable dataTable4 = Codes.Search2("SELECT Code, Patient, Doctor, Date, TimeFrom, TimeTo, Company, UserName, Pay FROM dbo.AppointEsal where Code = '" + numericUpDown1.Value + "'");
					if (dataTable4.Rows.Count == 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("No Data");
						}
						else
						{
							MessageBox.Show("لا يوجد ايصالات بهذا الرقم");
						}
						return;
					}
					((DataTable)(object)dataSet11.AppointmentEsal).Rows.Add(dataTable4.Rows[0][0].ToString(), dataTable4.Rows[0][1].ToString(), dataTable4.Rows[0][2].ToString(), dataTable4.Rows[0][3].ToString(), dataTable4.Rows[0][4].ToString(), dataTable4.Rows[0][5].ToString(), dataTable4.Rows[0][6].ToString(), dataTable4.Rows[0][7].ToString(), dataTable4.Rows[0][8].ToString());
					DataTable dataTable8 = Codes.Search2("select EsalPrinter from Properties");
					string text3 = dataTable8.Rows[0][0].ToString();
					sqlConnection2.ConnectionString = Codes.ConnectionStr;
					sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
					sqlDataAdapter2.SelectCommand.CommandText = "select * from PatientData where PName ='" + dataTable4.Rows[0][1].ToString() + "'";
					sqlDataAdapter2.Fill(dataSet11);
					if (text3 == "A5")
					{
						ReportDocument reportDocument = new ReportDocument();
						reportDocument.Load(Application.StartupPath + "\\Reports\\AppointEsalRpt.rpt");
						try
						{
							reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
						}
						catch
						{
						}
						try
						{
							TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
							textObject.Text = text;
						}
						catch
						{
						}
						reportDocument.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = reportDocument;
					}
					else if (text3 == "Reset")
					{
						ReportDocument reportDocument = new ReportDocument();
						reportDocument.Load(Application.StartupPath + "\\Reports\\AppointEsalReset.rpt");
						try
						{
							reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
						}
						catch
						{
						}
						try
						{
							TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
							textObject.Text = text;
						}
						catch
						{
						}
						reportDocument.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = reportDocument;
					}
					else
					{
						ReportDocument reportDocument = new ReportDocument();
						reportDocument.Load(Application.StartupPath + "\\Reports\\AppointEsalRpt1.rpt");
						try
						{
							reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
						}
						catch
						{
						}
						try
						{
							TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
							textObject.Text = text;
						}
						catch
						{
						}
						reportDocument.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = reportDocument;
					}
				}
				catch
				{
				}
			}
			if (!radioButton3.Checked)
			{
				return;
			}
			try
			{
				sqlConnection1.ConnectionString = Codes.ConnectionStr;
				sqlDataAdapter1.Fill(dataSet11);
				DataTable dataTable4 = Codes.Search2("SELECT     dbo.Company5.EsalNum, dbo.Company5.Date, dbo.Company.Name, dbo.Stock.Name AS Expr1, dbo.Company5.Username, dbo.Company5.Daen, \r\n                      dbo.Company5.Raseed\r\nFROM         dbo.Company5 INNER JOIN\r\n                      dbo.Company ON dbo.Company5.CompanyId = dbo.Company.ID INNER JOIN\r\n                      dbo.Stock ON dbo.Company5.StockId = dbo.Stock.ID where Company5.EsalNum = '" + numericUpDown1.Value + "'");
				if (dataTable4.Rows.Count == 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("No Data");
					}
					else
					{
						MessageBox.Show("لا يوجد ايصالات بهذا الرقم");
					}
					return;
				}
				((DataTable)(object)dataSet11.CompanyPayEsalRpt).Rows.Add(dataTable4.Rows[0][0].ToString(), Convert.ToDateTime(dataTable4.Rows[0][1].ToString()), dataTable4.Rows[0][2].ToString(), dataTable4.Rows[0][3].ToString(), dataTable4.Rows[0][4].ToString(), dataTable4.Rows[0][5].ToString(), dataTable4.Rows[0][6].ToString());
				DataTable dataTable8 = Codes.Search2("select SizePrinter from Properties");
				string text3 = dataTable8.Rows[0][0].ToString();
				if (text3 == "A5")
				{
					CompanyPayEsalRpt companyPayEsalRpt = new CompanyPayEsalRpt();
					companyPayEsalRpt.SetDataSource(dataSet11);
					try
					{
						companyPayEsalRpt.PrintOptions.PrinterName = UsersClass.BillPrinter;
					}
					catch
					{
					}
					crystalReportViewer1.ReportSource = companyPayEsalRpt;
				}
				else
				{
					CompanyPayEsalRpt1 companyPayEsalRpt2 = new CompanyPayEsalRpt1();
					companyPayEsalRpt2.SetDataSource(dataSet11);
					try
					{
						companyPayEsalRpt2.PrintOptions.PrinterName = UsersClass.BillPrinter;
					}
					catch
					{
					}
					crystalReportViewer1.ReportSource = companyPayEsalRpt2;
				}
			}
			catch
			{
			}
		}

		private void FrmEsal_Load(object sender, EventArgs e)
		{
			DataTable dataTable = Codes.Search2("select chTxtUnderPres,TxtUnderPres from Properties");
			string text = "";
			text = ((!Convert.ToBoolean(dataTable.Rows[0]["chTxtUnderPres"].ToString())) ? "" : dataTable.Rows[0]["TxtUnderPres"].ToString());
			if (xx)
			{
				return;
			}
			dataSet11.Clear();
			groupBox1.Visible = false;
			OldPay = 0.0;
			Rest = 0.0;
			Pay = 0.0;
			totalPrice = 0.0;
			PayPrice = 0.0;
			if (y)
			{
				try
				{
					ClinicTeath = Convert.ToBoolean(Codes.Search2("select ClinicType from DentalData").Rows[0][0].ToString());
					dt = Codes.Search2("SELECT     dbo.Esal.Patient, dbo.Esal.Date, dbo.Esal.Bean, dbo.Esal.Price, dbo.Esal.Pay, dbo.Esal.Teeth, dbo.Esal.Company, dbo.Esal.Username, dbo.Esal.EsalNo, \r\n                      dbo.Esal.PatientAcountId, dbo.Esal.Assistant, dbo.PatientAccount.PatientId,dbo.Esal.Id ,dbo.PatientAccount.Dariba ,dbo.PatientAccount.PriceBeforeDariba,PatientAccount.DoctorID\r\nFROM         dbo.Esal INNER JOIN\r\n                      dbo.PatientAccount ON dbo.Esal.PatientAcountId = dbo.PatientAccount.ID where dbo.Esal.EsalNo ='" + EsalNo + "'");
					if (dt.Rows.Count == 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("No Data");
						}
						else
						{
							MessageBox.Show("لا يوجد ايصالات بهذا الرقم");
						}
						return;
					}
					DataTable dataTable2 = Codes.Search2("select isnull(sum(Price),0),isnull(sum(PricePay),0) from PatientAccount where PatientId = '" + dt.Rows[0]["PatientId"].ToString() + "'");
					for (int i = 0; i < dt.Rows.Count; i++)
					{
						totalPrice += Convert.ToDouble(dt.Rows[i][3]);
						Pay += Convert.ToDouble(dt.Rows[i][4]);
						DataTable dataTable3 = Codes.Search2("select isnull(sum(Pay),0) from Esal where PatientAcountId = '" + dt.Rows[i]["PatientAcountId"].ToString() + "' and Id < '" + dt.Rows[i]["Id"].ToString() + "'");
						if (dataTable3.Rows.Count > 0)
						{
							OldPay += Convert.ToDouble(dataTable3.Rows[0][0]);
						}
					}
					Rest = Convert.ToDouble(totalPrice) - OldPay - Pay;
					if (dt.Rows.Count > 0)
					{
						for (int i = 0; i < dt.Rows.Count; i++)
						{
							string text2 = dt.Rows[i][2].ToString();
							((DataTable)(object)dataSet11.Statment).Rows.Add(dt.Rows[i][0].ToString(), Convert.ToDateTime(dt.Rows[i][1].ToString()), dt.Rows[i][2].ToString(), Convert.ToDouble(totalPrice).ToString(), dt.Rows[i][3].ToString(), Pay.ToString(), dt.Rows[i][5].ToString(), dt.Rows[i][6].ToString(), dt.Rows[i][7].ToString(), dt.Rows[i][8].ToString(), Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString(), Convert.ToDouble(dt.Rows[i]["Price"].ToString()) / Convert.ToDouble(Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString()), 0, Codes.Search2("select Name from Empdata where ID='" + dt.Rows[i]["DoctorID"].ToString() + "'").Rows[0][0].ToString());
							if (text2 == "سحب كميات اصناف")
							{
								DataTable dataTable4 = Codes.Search2("SELECT     dbo.Items.Name, dbo.Sahb_details.Qty, dbo.Sahb_details.Price\r\nFROM         dbo.Sahb INNER JOIN\r\n                      dbo.Sahb_details ON dbo.Sahb.ID = dbo.Sahb_details.SahbId INNER JOIN\r\n                      dbo.Items ON dbo.Sahb_details.ItemId = dbo.Items.Id where Sahb.PatientAccountId = '" + dt.Rows[i][9].ToString() + "'");
								for (int j = 0; j < dataTable4.Rows.Count; j++)
								{
									((DataTable)(object)dataSet11.SahbItemEsal).Rows.Add(dataTable4.Rows[j][0].ToString(), dataTable4.Rows[j][1].ToString(), dataTable4.Rows[j][2].ToString(), 0);
								}
							}
						}
						if (ClinicTeath)
						{
							sqlConnection1.ConnectionString = Codes.ConnectionStr;
							sqlDataAdapter1.Fill(dataSet11);
							DataTable dataTable5 = Codes.Search2("select EsalPrinter from Properties");
							switch (dataTable5.Rows[0][0].ToString())
							{
							case "A5":
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptA5.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = OldPay.ToString();
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = Rest.ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(dataSet11);
								crystalReportViewer1.ReportSource = reportDocument;
								break;
							}
							case "Reset":
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptReset.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = OldPay.ToString();
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = Rest.ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(dataSet11);
								crystalReportViewer1.ReportSource = reportDocument;
								break;
							}
							case "1/2 A4":
							{
								((DataTable)(object)dataSet11.Statment).Rows.Clear();
								OldPay = 0.0;
								double num = 0.0;
								for (int i = 0; i < dt.Rows.Count; i++)
								{
									DataTable dataTable3 = Codes.Search2("select isnull(sum(Pay),0) from Esal where PatientAcountId = '" + dt.Rows[i]["PatientAcountId"].ToString() + "' and Id < '" + dt.Rows[i]["Id"].ToString() + "'");
									OldPay = Convert.ToDouble(dataTable3.Rows[0][0]);
									DataTable dataTable7 = Codes.Search2("SELECT dbo.PatientAccount.Bean FROM  dbo.CompanyService INNER JOIN\r\n                      dbo.PatientAccount ON dbo.CompanyService.Service COLLATE SQL_Latin1_General_CP1_CI_AS = dbo.PatientAccount.Bean where dbo.PatientAccount.ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'");
									if (dataTable7.Rows.Count > 0)
									{
										num += Convert.ToDouble(dt.Rows[i]["PriceBeforeDariba"].ToString());
										PayPrice = 0.0;
										if (dt.Rows[i]["Price"].ToString() == dt.Rows[i]["Pay"].ToString())
										{
											PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString()) + Convert.ToDouble(dt.Rows[i]["Pay"].ToString());
										}
										else
										{
											PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString());
										}
										((DataTable)(object)dataSet11.Statment).Rows.Add(dt.Rows[i][0].ToString(), Convert.ToDateTime(dt.Rows[i][1].ToString()), dt.Rows[i][2].ToString(), Convert.ToDouble(num).ToString(), OldPay, Convert.ToDouble(Pay), dt.Rows[i][5].ToString(), dt.Rows[i][6].ToString(), dt.Rows[i][7].ToString(), dt.Rows[i][8].ToString(), Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString(), Convert.ToDouble(dt.Rows[i]["PriceBeforeDariba"].ToString()) / Convert.ToDouble(Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString()), Convert.ToDouble(dt.Rows[i]["PriceBeforeDariba"].ToString()) * Convert.ToDouble(dt.Rows[i]["Dariba"].ToString()) / 100.0, Codes.Search2("select Name from Empdata where ID='" + dt.Rows[i]["DoctorID"].ToString() + "'").Rows[0][0].ToString());
									}
									else
									{
										num += Convert.ToDouble(dt.Rows[i]["Price"].ToString());
										PayPrice = 0.0;
										if (dt.Rows[i]["Price"].ToString() == dt.Rows[i]["Pay"].ToString())
										{
											PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString()) + Convert.ToDouble(dt.Rows[i]["Pay"].ToString());
										}
										else
										{
											PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString());
										}
										((DataTable)(object)dataSet11.Statment).Rows.Add(dt.Rows[i][0].ToString(), Convert.ToDateTime(dt.Rows[i][1].ToString()), dt.Rows[i][2].ToString(), Convert.ToDouble(num).ToString(), OldPay, Convert.ToDouble(Pay), dt.Rows[i][5].ToString(), dt.Rows[i][6].ToString(), dt.Rows[i][7].ToString(), dt.Rows[i][8].ToString(), Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString(), Convert.ToDouble(dt.Rows[i]["Price"].ToString()) / Convert.ToDouble(Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString()), 0, Codes.Search2("select Name from Empdata where ID='" + dt.Rows[i]["DoctorID"].ToString() + "'").Rows[0][0].ToString());
									}
								}
								sqlConnection2.ConnectionString = Codes.ConnectionStr;
								sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
								sqlDataAdapter2.SelectCommand.CommandText = "select * from PatientData where ID ='" + dt.Rows[0]["PatientId"].ToString() + "'";
								sqlDataAdapter2.Fill(dataSet11);
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt_HalfA4.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = OldPay.ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(dataSet11);
								try
								{
									DataTable dataTable6 = Codes.Search2("select Name from Empdata where ID='" + dt.Rows[0]["DoctorID"].ToString() + "' ");
									reportDocument.SetParameterValue("DoctorName", dataTable6.Rows[0][0].ToString());
								}
								catch
								{
								}
								crystalReportViewer1.ReportSource = reportDocument;
								break;
							}
							default:
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = OldPay.ToString();
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = Rest.ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(dataSet11);
								try
								{
									DataTable dataTable6 = Codes.Search2("select Name from Empdata where ID='" + dt.Rows[0]["DoctorID"].ToString() + "' ");
									reportDocument.SetParameterValue("DoctorName", dataTable6.Rows[0][0].ToString());
								}
								catch
								{
								}
								reportDocument.SetParameterValue("Assistant", dt.Rows[0][10].ToString());
								crystalReportViewer1.ReportSource = reportDocument;
								break;
							}
							}
						}
						else
						{
							sqlConnection1.ConnectionString = Codes.ConnectionStr;
							sqlDataAdapter1.Fill(dataSet11);
							DataTable dataTable5 = Codes.Search2("select EsalPrinter from Properties");
							switch (dataTable5.Rows[0][0].ToString())
							{
							case "A5":
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptA5.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = OldPay.ToString();
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = Rest.ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(dataSet11);
								crystalReportViewer1.ReportSource = reportDocument;
								break;
							}
							case "Reset":
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1Reset.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = OldPay.ToString();
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = Rest.ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(dataSet11);
								crystalReportViewer1.ReportSource = reportDocument;
								break;
							}
							case "1/2 A4":
							{
								((DataTable)(object)dataSet11.Statment).Rows.Clear();
								OldPay = 0.0;
								double num = 0.0;
								for (int i = 0; i < dt.Rows.Count; i++)
								{
									DataTable dataTable3 = Codes.Search2("select isnull(sum(Pay),0) from Esal where PatientAcountId = '" + dt.Rows[i]["PatientAcountId"].ToString() + "' and Id < '" + dt.Rows[i]["Id"].ToString() + "'");
									OldPay = Convert.ToDouble(dataTable3.Rows[0][0]);
									DataTable dataTable7 = Codes.Search2("SELECT dbo.PatientAccount.Bean FROM  dbo.CompanyService INNER JOIN\r\n                      dbo.PatientAccount ON dbo.CompanyService.Service COLLATE SQL_Latin1_General_CP1_CI_AS = dbo.PatientAccount.Bean where dbo.PatientAccount.ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'");
									if (dataTable7.Rows.Count > 0)
									{
										num += Convert.ToDouble(dt.Rows[i]["PriceBeforeDariba"].ToString());
										PayPrice = 0.0;
										if (dt.Rows[i]["Price"].ToString() == dt.Rows[i]["Pay"].ToString())
										{
											PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString()) + Convert.ToDouble(dt.Rows[i]["Pay"].ToString());
										}
										else
										{
											PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString());
										}
										((DataTable)(object)dataSet11.Statment).Rows.Add(dt.Rows[i][0].ToString(), Convert.ToDateTime(dt.Rows[i][1].ToString()), dt.Rows[i][2].ToString(), Convert.ToDouble(num).ToString(), OldPay, Convert.ToDouble(Pay), dt.Rows[i][5].ToString(), dt.Rows[i][6].ToString(), dt.Rows[i][7].ToString(), dt.Rows[i][8].ToString(), Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString(), Convert.ToDouble(dt.Rows[i]["PriceBeforeDariba"].ToString()) / Convert.ToDouble(Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString()), Convert.ToDouble(dt.Rows[i]["PriceBeforeDariba"].ToString()) * Convert.ToDouble(dt.Rows[i]["Dariba"].ToString()) / 100.0, Codes.Search2("select Name from Empdata where ID='" + dt.Rows[i]["DoctorID"].ToString() + "'").Rows[0][0].ToString());
									}
									else
									{
										num += Convert.ToDouble(dt.Rows[i]["Price"].ToString());
										PayPrice = 0.0;
										if (dt.Rows[i]["Price"].ToString() == dt.Rows[i]["Pay"].ToString())
										{
											PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString()) + Convert.ToDouble(dt.Rows[i]["Pay"].ToString());
										}
										else
										{
											PayPrice = Convert.ToDouble(dataTable2.Rows[0][1].ToString());
										}
										((DataTable)(object)dataSet11.Statment).Rows.Add(dt.Rows[i][0].ToString(), Convert.ToDateTime(dt.Rows[i][1].ToString()), dt.Rows[i][2].ToString(), Convert.ToDouble(num).ToString(), OldPay, Convert.ToDouble(Pay), dt.Rows[i][5].ToString(), dt.Rows[i][6].ToString(), dt.Rows[i][7].ToString(), dt.Rows[i][8].ToString(), Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString(), Convert.ToDouble(dt.Rows[i]["Price"].ToString()) / Convert.ToDouble(Codes.Search2("select ServiceCount from PatientAccount where ID='" + dt.Rows[i]["PatientAcountId"].ToString() + "'").Rows[0][0].ToString()), 0, Codes.Search2("select Name from Empdata where ID='" + dt.Rows[i]["DoctorID"].ToString() + "'").Rows[0][0].ToString());
									}
								}
								sqlConnection2.ConnectionString = Codes.ConnectionStr;
								sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
								sqlDataAdapter2.SelectCommand.CommandText = "select * from PatientData where ID ='" + dt.Rows[0]["PatientId"].ToString() + "'";
								sqlDataAdapter2.Fill(dataSet11);
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt_HalfA4.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = OldPay.ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(dataSet11);
								try
								{
									DataTable dataTable6 = Codes.Search2("select Name from Empdata where ID='" + dt.Rows[0]["DoctorID"].ToString() + "' ");
									reportDocument.SetParameterValue("DoctorName", dataTable6.Rows[0][0].ToString());
								}
								catch
								{
								}
								crystalReportViewer1.ReportSource = reportDocument;
								break;
							}
							default:
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = OldPay.ToString();
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = Rest.ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(dataSet11);
								reportDocument.SetParameterValue("Assistant", dt.Rows[0][10].ToString());
								crystalReportViewer1.ReportSource = reportDocument;
								break;
							}
							}
						}
					}
					xx = true;
				}
				catch
				{
				}
				return;
			}
			try
			{
				sqlConnection1.ConnectionString = Codes.ConnectionStr;
				sqlDataAdapter1.Fill(dataSet11);
				DataTable dataTable4 = Codes.Search2("SELECT Code, Patient, Doctor, Date, TimeFrom, TimeTo, Company, UserName, Pay FROM dbo.AppointEsal where Code = '" + EsalNo + "'");
				if (dataTable4.Rows.Count > 0)
				{
					((DataTable)(object)dataSet11.AppointmentEsal).Rows.Add(dataTable4.Rows[0][0].ToString(), dataTable4.Rows[0][1].ToString(), dataTable4.Rows[0][2].ToString(), Convert.ToDateTime(dataTable4.Rows[0][3].ToString()), dataTable4.Rows[0][4].ToString(), dataTable4.Rows[0][5].ToString(), dataTable4.Rows[0][6].ToString(), dataTable4.Rows[0][7].ToString(), dataTable4.Rows[0][8].ToString());
					DataTable dataTable8 = Codes.Search2("select EsalPrinter from Properties");
					string text3 = dataTable8.Rows[0][0].ToString();
					if (text3 == "A5")
					{
						ReportDocument reportDocument = new ReportDocument();
						reportDocument.Load(Application.StartupPath + "\\Reports\\AppointEsalRpt.rpt");
						try
						{
							reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
						}
						catch
						{
						}
						try
						{
							TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
							textObject.Text = text;
						}
						catch
						{
						}
						reportDocument.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = reportDocument;
					}
					else if (text3 == "Reset")
					{
						ReportDocument reportDocument = new ReportDocument();
						reportDocument.Load(Application.StartupPath + "\\Reports\\AppointEsalReset.rpt");
						try
						{
							TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
							textObject.Text = text;
						}
						catch
						{
						}
						reportDocument.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = reportDocument;
					}
					else
					{
						ReportDocument reportDocument = new ReportDocument();
						reportDocument.Load(Application.StartupPath + "\\Reports\\AppointEsalRpt1.rpt");
						try
						{
							reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
						}
						catch
						{
						}
						try
						{
							TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
							textObject.Text = text;
						}
						catch
						{
						}
						reportDocument.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = reportDocument;
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("No Data");
				}
				else
				{
					MessageBox.Show("لا يوجد ايصالات بهذا الرقم");
				}
			}
			catch
			{
			}
		}
	}
}
