using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmPatientNotice : Form
	{
		private IContainer components = null;

		private GroupBox groupBox4;

		private ComboBox search_pName;

		private Label label10;

		private DateTimePicker DateTo;

		private Label label1;

		private DateTimePicker DateFrom;

		private Label label8;

		private Label label9;

		private ComboBox Search_type;

		private Button searchbtn;

		private GroupBox groupBox1;

		private Button deletebtn;

		private Button updatebtn;

		private ComboBox PatientName;

		private Button addbtn;

		private Label label4;

		private ComboBox note_type;

		private Label label3;

		private DateTimePicker dateTimePicker1;

		private Label label2;

		private TextBox Bayan;

		private TextBox Money;

		private Label label5;

		private Label label7;

		private GroupBox groupBox3;

		private DataGridView dataGridView1;

		private DataGridView dataGridServices;

		private GroupBox groupBox2;

		private DataGridViewTextBoxColumn ID;

		private DataGridViewTextBoxColumn Service;

		private DataGridViewTextBoxColumn ServicePrice;

		private DataGridViewTextBoxColumn Count;

		private DataGridViewTextBoxColumn Price;

		private DataGridViewTextBoxColumn OldPaid;

		private DataGridViewTextBoxColumn Paid;

		private DataGridViewTextBoxColumn DoctorId;

		private DataGridViewTextBoxColumn Date;

		private DataGridViewTextBoxColumn TotalPaid;

		private ClassDataBase Query;

		private dataClass sql;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private decimal oldPay = 0m;

		private decimal OldMoney = 0m;

		private double total;

		private ClassDataBase dc = new ClassDataBase(".\\sqlExpress");

		private GUI gui = new GUI();

		private int service_num = 0;

		private GeneralMethods MethodsClass = new GeneralMethods();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmPatientNotice));
			groupBox4 = new System.Windows.Forms.GroupBox();
			search_pName = new System.Windows.Forms.ComboBox();
			label10 = new System.Windows.Forms.Label();
			DateTo = new System.Windows.Forms.DateTimePicker();
			label1 = new System.Windows.Forms.Label();
			DateFrom = new System.Windows.Forms.DateTimePicker();
			label8 = new System.Windows.Forms.Label();
			label9 = new System.Windows.Forms.Label();
			Search_type = new System.Windows.Forms.ComboBox();
			searchbtn = new System.Windows.Forms.Button();
			groupBox1 = new System.Windows.Forms.GroupBox();
			deletebtn = new System.Windows.Forms.Button();
			updatebtn = new System.Windows.Forms.Button();
			PatientName = new System.Windows.Forms.ComboBox();
			addbtn = new System.Windows.Forms.Button();
			label4 = new System.Windows.Forms.Label();
			note_type = new System.Windows.Forms.ComboBox();
			label3 = new System.Windows.Forms.Label();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label2 = new System.Windows.Forms.Label();
			Bayan = new System.Windows.Forms.TextBox();
			Money = new System.Windows.Forms.TextBox();
			label5 = new System.Windows.Forms.Label();
			label7 = new System.Windows.Forms.Label();
			groupBox3 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			dataGridServices = new System.Windows.Forms.DataGridView();
			ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Service = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ServicePrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Count = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
			OldPaid = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Paid = new System.Windows.Forms.DataGridViewTextBoxColumn();
			DoctorId = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
			TotalPaid = new System.Windows.Forms.DataGridViewTextBoxColumn();
			groupBox2 = new System.Windows.Forms.GroupBox();
			groupBox4.SuspendLayout();
			groupBox1.SuspendLayout();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataGridServices).BeginInit();
			groupBox2.SuspendLayout();
			SuspendLayout();
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(search_pName);
			groupBox4.Controls.Add(label10);
			groupBox4.Controls.Add(DateTo);
			groupBox4.Controls.Add(label1);
			groupBox4.Controls.Add(DateFrom);
			groupBox4.Controls.Add(label8);
			groupBox4.Controls.Add(label9);
			groupBox4.Controls.Add(Search_type);
			groupBox4.Controls.Add(searchbtn);
			groupBox4.Font = null;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			search_pName.AccessibleDescription = null;
			search_pName.AccessibleName = null;
			resources.ApplyResources(search_pName, "search_pName");
			search_pName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			search_pName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			search_pName.BackgroundImage = null;
			search_pName.FormattingEnabled = true;
			search_pName.Name = "search_pName";
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "label10");
			label10.ForeColor = System.Drawing.Color.Black;
			label10.Name = "label10";
			DateTo.AccessibleDescription = null;
			DateTo.AccessibleName = null;
			resources.ApplyResources(DateTo, "DateTo");
			DateTo.BackgroundImage = null;
			DateTo.CalendarFont = null;
			DateTo.CustomFormat = null;
			DateTo.Name = "DateTo";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.ForeColor = System.Drawing.Color.Black;
			label1.Name = "label1";
			DateFrom.AccessibleDescription = null;
			DateFrom.AccessibleName = null;
			resources.ApplyResources(DateFrom, "DateFrom");
			DateFrom.BackgroundImage = null;
			DateFrom.CalendarFont = null;
			DateFrom.CustomFormat = null;
			DateFrom.Name = "DateFrom";
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "label8");
			label8.Font = null;
			label8.ForeColor = System.Drawing.Color.Black;
			label8.Name = "label8";
			label9.AccessibleDescription = null;
			label9.AccessibleName = null;
			resources.ApplyResources(label9, "label9");
			label9.ForeColor = System.Drawing.Color.Black;
			label9.Name = "label9";
			Search_type.AccessibleDescription = null;
			Search_type.AccessibleName = null;
			resources.ApplyResources(Search_type, "Search_type");
			Search_type.BackgroundImage = null;
			Search_type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			Search_type.FormattingEnabled = true;
			Search_type.Items.AddRange(new object[3]
			{
				resources.GetString("Search_type.Items"),
				resources.GetString("Search_type.Items1"),
				resources.GetString("Search_type.Items2")
			});
			Search_type.Name = "Search_type";
			searchbtn.AccessibleDescription = null;
			searchbtn.AccessibleName = null;
			resources.ApplyResources(searchbtn, "searchbtn");
			searchbtn.BackgroundImage = null;
			searchbtn.Font = null;
			searchbtn.Name = "searchbtn";
			searchbtn.UseVisualStyleBackColor = true;
			searchbtn.Click += new System.EventHandler(searchbtn_Click);
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(deletebtn);
			groupBox1.Controls.Add(updatebtn);
			groupBox1.Controls.Add(PatientName);
			groupBox1.Controls.Add(addbtn);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(note_type);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(dateTimePicker1);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(Bayan);
			groupBox1.Controls.Add(Money);
			groupBox1.Controls.Add(label5);
			groupBox1.Controls.Add(label7);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			deletebtn.AccessibleDescription = null;
			deletebtn.AccessibleName = null;
			resources.ApplyResources(deletebtn, "deletebtn");
			deletebtn.BackgroundImage = null;
			deletebtn.Name = "deletebtn";
			deletebtn.UseVisualStyleBackColor = true;
			deletebtn.Click += new System.EventHandler(deletebtn_Click);
			updatebtn.AccessibleDescription = null;
			updatebtn.AccessibleName = null;
			resources.ApplyResources(updatebtn, "updatebtn");
			updatebtn.BackgroundImage = null;
			updatebtn.Name = "updatebtn";
			updatebtn.UseVisualStyleBackColor = true;
			updatebtn.Click += new System.EventHandler(updatebtn_Click);
			PatientName.AccessibleDescription = null;
			PatientName.AccessibleName = null;
			resources.ApplyResources(PatientName, "PatientName");
			PatientName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			PatientName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientName.BackgroundImage = null;
			PatientName.FormattingEnabled = true;
			PatientName.Name = "PatientName";
			PatientName.SelectedIndexChanged += new System.EventHandler(PatientName_SelectedIndexChanged);
			addbtn.AccessibleDescription = null;
			addbtn.AccessibleName = null;
			resources.ApplyResources(addbtn, "addbtn");
			addbtn.BackgroundImage = null;
			addbtn.Name = "addbtn";
			addbtn.UseVisualStyleBackColor = true;
			addbtn.Click += new System.EventHandler(addbtn_Click);
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.ForeColor = System.Drawing.Color.Black;
			label4.Name = "label4";
			note_type.AccessibleDescription = null;
			note_type.AccessibleName = null;
			resources.ApplyResources(note_type, "note_type");
			note_type.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			note_type.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			note_type.BackgroundImage = null;
			note_type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			note_type.FormattingEnabled = true;
			note_type.Items.AddRange(new object[2]
			{
				resources.GetString("note_type.Items"),
				resources.GetString("note_type.Items1")
			});
			note_type.Name = "note_type";
			note_type.SelectedIndexChanged += new System.EventHandler(note_type_SelectedIndexChanged);
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.ForeColor = System.Drawing.Color.Black;
			label3.Name = "label3";
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.CustomFormat = null;
			dateTimePicker1.Name = "dateTimePicker1";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.ForeColor = System.Drawing.Color.Black;
			label2.Name = "label2";
			Bayan.AccessibleDescription = null;
			Bayan.AccessibleName = null;
			resources.ApplyResources(Bayan, "Bayan");
			Bayan.BackgroundImage = null;
			Bayan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			Bayan.Name = "Bayan";
			Money.AccessibleDescription = null;
			Money.AccessibleName = null;
			resources.ApplyResources(Money, "Money");
			Money.BackgroundImage = null;
			Money.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			Money.Name = "Money";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label5");
			label5.ForeColor = System.Drawing.Color.Black;
			label5.Name = "label5";
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "label7");
			label7.ForeColor = System.Drawing.Color.Black;
			label7.Name = "label7";
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(dataGridView1);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			dataGridServices.AccessibleDescription = null;
			dataGridServices.AccessibleName = null;
			dataGridServices.AllowUserToAddRows = false;
			dataGridServices.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridServices, "dataGridServices");
			dataGridServices.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridServices.BackgroundImage = null;
			dataGridServices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridServices.Columns.AddRange(ID, Service, ServicePrice, Count, Price, OldPaid, Paid, DoctorId, Date, TotalPaid);
			dataGridServices.Font = null;
			dataGridServices.Name = "dataGridServices";
			dataGridServices.ReadOnly = true;
			dataGridServices.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridServices_RowHeaderMouseDoubleClick);
			resources.ApplyResources(ID, "ID");
			ID.Name = "ID";
			ID.ReadOnly = true;
			resources.ApplyResources(Service, "Service");
			Service.Name = "Service";
			Service.ReadOnly = true;
			resources.ApplyResources(ServicePrice, "ServicePrice");
			ServicePrice.Name = "ServicePrice";
			ServicePrice.ReadOnly = true;
			resources.ApplyResources(Count, "Count");
			Count.Name = "Count";
			Count.ReadOnly = true;
			resources.ApplyResources(Price, "Price");
			Price.Name = "Price";
			Price.ReadOnly = true;
			resources.ApplyResources(OldPaid, "OldPaid");
			OldPaid.Name = "OldPaid";
			OldPaid.ReadOnly = true;
			resources.ApplyResources(Paid, "Paid");
			Paid.Name = "Paid";
			Paid.ReadOnly = true;
			resources.ApplyResources(DoctorId, "DoctorId");
			DoctorId.Name = "DoctorId";
			DoctorId.ReadOnly = true;
			resources.ApplyResources(Date, "Date");
			Date.Name = "Date";
			Date.ReadOnly = true;
			resources.ApplyResources(TotalPaid, "TotalPaid");
			TotalPaid.Name = "TotalPaid";
			TotalPaid.ReadOnly = true;
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(dataGridServices);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox4);
			base.Controls.Add(groupBox2);
			Font = null;
			base.Name = "FrmPatientNotice";
			base.Load += new System.EventHandler(FrmPatientNotice_Load);
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			((System.ComponentModel.ISupportInitialize)dataGridServices).EndInit();
			groupBox2.ResumeLayout(false);
			ResumeLayout(false);
		}

		public FrmPatientNotice()
		{
			InitializeComponent();
			Query = new ClassDataBase(".\\sqlExpress");
			sql = new dataClass(".\\sqlExpress");
		}

		private void FrmPatientNotice_Load(object sender, EventArgs e)
		{
			try
			{
				try
				{
					DataTable dataTable = new DataTable();
					if (Convert.ToBoolean(Codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString()))
					{
						dataTable = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True' order by PName");
						PatientName.DataSource = dataTable;
						PatientName.DisplayMember = dataTable.Columns[1].ToString();
						PatientName.ValueMember = dataTable.Columns[0].ToString();
					}
					else
					{
						dataTable = dc.Select("SelectAllPatient");
						gui.loadComboBox(PatientName, dataTable);
					}
				}
				catch
				{
				}
				if (Settings.Default.Language == "en-GB")
				{
					PatientName.Text = "<-Choose->";
				}
				else
				{
					PatientName.Text = "<-اختر->";
				}
				DataTable tableText = Query.GetTableText("select ID,PName from PatientData");
				search_pName.DataSource = tableText;
				search_pName.DisplayMember = tableText.Columns[1].ToString();
				search_pName.ValueMember = tableText.Columns[0].ToString();
				if (Settings.Default.Language == "en-GB")
				{
					search_pName.Text = "All";
				}
				else
				{
					search_pName.Text = "الكل";
				}
				fillDataGride();
			}
			catch
			{
			}
		}

		private void addbtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (PatientName.SelectedItem != null && PatientName.Text != "<-اختر->")
				{
					if (Convert.ToDouble(Money.Text) > 0.0)
					{
						if (note_type.SelectedItem != null)
						{
							DataTable tableText = Query.GetTableText("SELECT dbo.Empdata.ID FROM dbo.PatientData INNER JOIN dbo.Empdata ON dbo.PatientData.DoctoreName = dbo.Empdata.Name ");
							int num = Convert.ToInt32(tableText.Rows[0]["ID"].ToString());
							if (note_type.SelectedIndex == 0)
							{
								if (Bayan.Text == "")
								{
									MessageBox.Show("من فضلك أختر الخدمة");
								}
								else
								{
									service_num = Convert.ToInt32(dataGridServices.CurrentRow.Cells["ID"].Value.ToString());
									sql.Add(string.Concat("insert into PatientNotice (PatientID,Amount,OPDate,ChooseDate,NoteType,Note,PAccount_ID) values (", PatientName.SelectedValue, ",", Convert.ToDecimal(Money.Text), ",'", DateTime.Now.ToString("MM/dd/yyyy"), "','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "','", note_type.Text, "','", Bayan.Text, "',", service_num, ")"));
									sql.Edit2("Update PatientAccount set PricePay=PricePay+ " + Convert.ToDecimal(Money.Text) + " where ID=" + Convert.ToInt32(dataGridServices.CurrentRow.Cells["ID"].Value.ToString()));
									sql.Add2("insert into Esal (EsalNo, PatientAcountId, Date,Pay, Patient, Bean, Price, Username) values(" + 0 + "," + service_num + ",'" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "'," + Convert.ToDecimal(Money.Text) + ",'" + PatientName.Text + "','إشعار خصم علي خدمة'+ ' '+'" + dataGridServices.CurrentRow.Cells[1].Value.ToString() + "','" + dataGridServices.CurrentRow.Cells[4].Value.ToString() + "','" + Main.usernames + "')");
									MethodsClass.UserMove("أضافة إشعار خصم لمريض");
								}
							}
							else
							{
								service_num = Convert.ToInt32(sql.Search2("insert into PatientAccount (PatientId,DoctorID,Bean,Price,Pay,Date,PricePay,BeanDate) values (" + Convert.ToInt32(PatientName.SelectedValue.ToString()) + "," + num + ",'إشعار أضافة'," + Convert.ToDecimal(Money.Text) + ",'false','" + DateTime.Now.ToString("MM/dd/yyyy") + "'," + 0 + ",'" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "');select @@identity").Rows[0][0].ToString());
								sql.Add(string.Concat("insert into PatientNotice (PatientID,Amount,OPDate,ChooseDate,NoteType,Note,PAccount_ID) values (", PatientName.SelectedValue, ",", Convert.ToDecimal(Money.Text), ",'", DateTime.Now.ToString("MM/dd/yyyy"), "','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "','", note_type.Text, "','", Bayan.Text, "',", service_num, ")"));
								MethodsClass.UserMove("أضافة إشعار أضافة لمريض");
							}
							fillDataGride();
							clear();
						}
						else
						{
							MessageBox.Show("من فضلك أختر نوع الاشعار");
						}
					}
					else
					{
						MessageBox.Show("من فضلك ادخل المبلغ");
					}
				}
				else
				{
					MessageBox.Show("من فضلك اختر اسم العميل");
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			dataGridServices.Rows.Clear();
			DataTable dataTable = new DataTable();
			dataTable.Rows.Clear();
			service_num = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString());
			PatientName.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
			Money.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
			OldMoney = Convert.ToDecimal(dataGridView1.CurrentRow.Cells[3].Value.ToString());
			dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[5].Value.ToString());
			note_type.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
			Bayan.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
			addbtn.Enabled = false;
			PatientName.Enabled = false;
			updatebtn.Visible = true;
			deletebtn.Visible = true;
			dataTable = Query.GetTableText("SELECT PatientAccount.* FROM PatientNotice INNER JOIN PatientAccount ON dbo.PatientNotice.PAccount_ID = dbo.PatientAccount.ID where PatientNotice.PAccount_ID = " + service_num);
			dataGridServices.Rows.Add(dataTable.Rows[0]["ID"].ToString(), dataTable.Rows[0]["Bean"].ToString(), Convert.ToDouble(dataTable.Rows[0]["Price"].ToString()) / Convert.ToDouble(dataTable.Rows[0]["ServiceCount"].ToString()), Convert.ToDouble(dataTable.Rows[0]["ServiceCount"].ToString()), Convert.ToDouble(dataTable.Rows[0]["Price"].ToString()), Convert.ToDouble(dataTable.Rows[0]["PricePay"].ToString()), 0, dataTable.Rows[0]["DoctorID"].ToString(), dataTable.Rows[0]["Date"].ToString());
		}

		public void fillDataGride()
		{
			if (Settings.Default.Language == "en-GB")
			{
				sql.FillDataGrid2(dataGridView1, "SELECT PatientNotice.ID,PAccount_ID, PatientData.PName AS [Patient Name], PatientNotice.Amount AS [Amount], PatientNotice.OPDate As [Operation Date],PatientNotice.ChooseDate As [Notification Date],PatientNotice.NoteType AS [Notification Type] ,PatientNotice.Note AS [Notes]  FROM PatientData INNER JOIN PatientNotice ON PatientData.ID = PatientNotice.PatientID");
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].Visible = false;
			}
			else
			{
				sql.FillDataGrid2(dataGridView1, "SELECT PatientNotice.ID,PAccount_ID, PatientData.PName AS [أسم المريض], PatientNotice.Amount AS [المبلغ], PatientNotice.OPDate As [تاريخ العملية],PatientNotice.ChooseDate As [تاريخ الإشعار],PatientNotice.NoteType AS [نوع الإشعار] ,PatientNotice.Note AS [ملاحظات]  FROM PatientData INNER JOIN PatientNotice ON PatientData.ID = PatientNotice.PatientID");
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].Visible = false;
			}
		}

		private void updatebtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (Convert.ToDouble(Money.Text) > 0.0)
				{
					if (note_type.SelectedItem != null)
					{
						if (note_type.SelectedIndex == 0)
						{
							sql.Edit("Update PatientNotice set Amount=" + Convert.ToDecimal(Money.Text) + ",OPDate=" + DateTime.Now.ToString("MM/dd/yyyy") + ",ChooseDate='" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "',NoteType='" + note_type.Text + "',Note='" + Bayan.Text + "', PAccount_ID='" + Convert.ToInt32(dataGridServices.CurrentRow.Cells["ID"].Value.ToString()) + "'where ID=" + Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString()));
							sql.Edit2("Update PatientAccount set PricePay =PricePay+" + (-1m * OldMoney + Convert.ToDecimal(Money.Text)) + " where ID=" + Convert.ToInt32(dataGridServices.CurrentRow.Cells["ID"].Value.ToString()));
							sql.Edit2("Update Esal set Pay =Pay+" + (-1m * OldMoney + Convert.ToDecimal(Money.Text)) + " where PatientAcountId=" + Convert.ToInt32(dataGridServices.CurrentRow.Cells["ID"].Value.ToString()) + " and EsalNo=" + 0);
							MethodsClass.UserMove("تعديل إشعار خصم");
						}
						else
						{
							sql.Edit("Update PatientNotice set Amount=" + Convert.ToDecimal(Money.Text) + ",OPDate=" + DateTime.Now.ToString("MM/dd/yyyy") + ",ChooseDate='" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "',NoteType='" + note_type.Text + "',Note='" + Bayan.Text + "'where ID=" + Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString()));
							sql.Edit2("Update PatientAccount set Bean='إشعار إضافة',Price=" + Convert.ToDecimal(Money.Text) + ",Date=" + DateTime.Now.ToString("MM/dd/yyyy") + ",BeanDate=" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + " where ID=" + Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString()));
							MethodsClass.UserMove("تعديل إشعار أضافة");
						}
						fillDataGride();
						clear();
					}
					else
					{
						MessageBox.Show(" من فضلك أختر نوع الاشعار ");
					}
				}
				else
				{
					MessageBox.Show("من فضلك ادخل المبلغ");
				}
			}
			catch
			{
			}
		}

		private void deletebtn_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				sql.Delete2("delete from PatientNotice where ID=" + Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString()));
				if (note_type.SelectedIndex == 0)
				{
					sql.Edit2("Update PatientAccount set PricePay=PricePay-" + Convert.ToDecimal(Money.Text) + " where ID=" + Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString()));
					sql.Delete2("delete from Esal where PatientAcountId=" + Convert.ToInt32(dataGridServices.CurrentRow.Cells["ID"].Value.ToString()) + " and EsalNo=" + 0);
					MethodsClass.UserMove("حذف إشعار خصم");
				}
				else
				{
					sql.Delete2("delete from PatientAccount where ID=" + Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString()));
					MethodsClass.UserMove("حذف إشعار أضافة");
				}
				MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else
			{
				MessageBox.Show("خطأ أثناء حذف البيانات ", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			fillDataGride();
			clear();
		}

		public void clear()
		{
			PatientName.Text = "<-اختر->";
			Money.Text = "0";
			Bayan.Text = "";
			note_type.Text = "";
			updatebtn.Visible = false;
			deletebtn.Visible = false;
			PatientName.Enabled = true;
			search_pName.Text = "الكل";
			addbtn.Enabled = true;
			dataGridServices.Rows.Clear();
		}

		private void searchbtn_Click(object sender, EventArgs e)
		{
			if (search_pName.Text == "الكل")
			{
				if (Search_type.SelectedIndex == 0 || Search_type.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						sql.FillDataGrid2(dataGridView1, "SELECT PatientNotice.ID,PAccount_ID, PatientData.PName AS [Patient Name], PatientNotice.Amount AS [Amount], PatientNotice.OPDate As [Operation Date],PatientNotice.ChooseDate As [Notification Date],PatientNotice.NoteType AS [Notification Type] ,PatientNotice.Note AS [Notes]  FROM PatientData INNER JOIN PatientNotice ON PatientData.ID = PatientNotice.PatientID where PatientNotice.ChooseDate between '" + DateFrom.Value.ToString("MM/dd/yyyy") + "' and '" + DateTo.Value.ToString("MM/dd/yyyy") + "'");
						dataGridView1.Columns[0].Visible = false;
						dataGridView1.Columns[1].Visible = false;
					}
					else
					{
						sql.FillDataGrid2(dataGridView1, " SELECT PatientNotice.ID,PAccount_ID,PatientData.PName AS [أسم المريض], PatientNotice.Amount AS [المبلغ], PatientNotice.OPDate As [تاريخ العملية],PatientNotice.ChooseDate As [تاريخ الإشعار],PatientNotice.NoteType AS [نوع الإشعار] ,PatientNotice.Note AS [ملاحظات]  FROM PatientData INNER JOIN PatientNotice ON PatientData.ID = PatientNotice.PatientID where PatientNotice.ChooseDate between '" + DateFrom.Value.ToString("MM/dd/yyyy") + "' and '" + DateTo.Value.ToString("MM/dd/yyyy") + "'");
						dataGridView1.Columns[0].Visible = false;
						dataGridView1.Columns[1].Visible = false;
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					sql.FillDataGrid2(dataGridView1, "SELECT PatientNotice.ID,PAccount_ID, PatientData.PName AS [Patient Name], PatientNotice.Amount AS [Amount], PatientNotice.OPDate As [Operation Date],PatientNotice.ChooseDate As [Notification Date],PatientNotice.NoteType AS [Notification Type] ,PatientNotice.Note AS [Notes]  FROM PatientData INNER JOIN PatientNotice ON PatientData.ID = PatientNotice.PatientID where PatientNotice.ChooseDate between '" + DateFrom.Value.ToString("MM/dd/yyyy") + "' and '" + DateTo.Value.ToString("MM/dd/yyyy") + "'and NoteType='" + Search_type.Text + "'");
					dataGridView1.Columns[0].Visible = false;
					dataGridView1.Columns[1].Visible = false;
				}
				else
				{
					sql.FillDataGrid2(dataGridView1, "SELECT PatientNotice.ID,PAccount_ID,PatientData.PName AS [أسم المريض], PatientNotice.Amount AS [المبلغ], PatientNotice.OPDate As [تاريخ العملية],PatientNotice.ChooseDate As [تاريخ الإشعار],PatientNotice.NoteType AS [نوع الإشعار] ,PatientNotice.Note AS [ملاحظات]  FROM PatientData INNER JOIN PatientNotice ON PatientData.ID = PatientNotice.PatientID where PatientNotice.ChooseDate between '" + DateFrom.Value.ToString("MM/dd/yyyy") + "' and '" + DateTo.Value.ToString("MM/dd/yyyy") + "'and NoteType='" + Search_type.Text + "'");
					dataGridView1.Columns[0].Visible = false;
					dataGridView1.Columns[1].Visible = false;
				}
			}
			else if (Search_type.SelectedIndex == 0 || Search_type.Text == "")
			{
				if (Settings.Default.Language == "en-GB")
				{
					sql.FillDataGrid2(dataGridView1, string.Concat("SELECT PatientNotice.ID,PAccount_ID, PatientData.PName AS [Patient Name], PatientNotice.Amount AS [Amount], PatientNotice.OPDate As [Operation Date],PatientNotice.ChooseDate As [Notification Date],PatientNotice.NoteType AS [Notification Type] ,PatientNotice.Note AS [Notes]  FROM PatientData INNER JOIN PatientNotice ON PatientData.ID = PatientNotice.PatientID where PatientID='", search_pName.SelectedValue, "'and PatientNotice.ChooseDate between '", DateFrom.Value.ToString("MM/dd/yyyy"), "' and '", DateTo.Value.ToString("MM/dd/yyyy"), "'"));
					dataGridView1.Columns[0].Visible = false;
					dataGridView1.Columns[1].Visible = false;
				}
				else
				{
					sql.FillDataGrid2(dataGridView1, string.Concat("SELECT PatientNotice.ID,PAccount_ID,PatientData.PName AS [أسم المريض], PatientNotice.Amount AS [المبلغ], PatientNotice.OPDate As [تاريخ العملية],PatientNotice.ChooseDate As [تاريخ الإشعار],PatientNotice.NoteType AS [نوع الإشعار] ,PatientNotice.Note AS [ملاحظات]  FROM PatientData INNER JOIN PatientNotice ON PatientData.ID = PatientNotice.PatientID where PatientID='", search_pName.SelectedValue, "'and PatientNotice.ChooseDate between '", DateFrom.Value.ToString("MM/dd/yyyy"), "' and '", DateTo.Value.ToString("MM/dd/yyyy"), "'"));
					dataGridView1.Columns[0].Visible = false;
					dataGridView1.Columns[1].Visible = false;
				}
			}
			else if (Settings.Default.Language == "en-GB")
			{
				sql.FillDataGrid2(dataGridView1, string.Concat("SELECT PatientNotice.ID,PAccount_ID, PatientData.PName AS [Patient Name], PatientNotice.Amount AS [Amount], PatientNotice.OPDate As [Operation Date],PatientNotice.ChooseDate As [Notification Date],PatientNotice.NoteType AS [Notification Type] ,PatientNotice.Note AS [Notes]  FROM PatientData INNER JOIN PatientNotice ON PatientData.ID = PatientNotice.PatientID where PatientID='", search_pName.SelectedValue, "'and PatientNotice.ChooseDate between '", DateFrom.Value.ToString("MM/dd/yyyy"), "' and '", DateTo.Value.ToString("MM/dd/yyyy"), "'and NoteType='", Search_type.Text, "'"));
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].Visible = false;
			}
			else
			{
				sql.FillDataGrid2(dataGridView1, string.Concat("SELECT PatientNotice.ID,PAccount_ID,PatientData.PName AS [أسم المريض], PatientNotice.Amount AS [المبلغ], PatientNotice.OPDate As [تاريخ العملية],PatientNotice.ChooseDate As [تاريخ الإشعار],PatientNotice.NoteType AS [نوع الإشعار] ,PatientNotice.Note AS [ملاحظات]  FROM PatientData INNER JOIN PatientNotice ON PatientData.ID = PatientNotice.PatientID where PatientID='", search_pName.SelectedValue, "'and PatientNotice.ChooseDate between '", DateFrom.Value.ToString("MM/dd/yyyy"), "' and '", DateTo.Value.ToString("MM/dd/yyyy"), "'and NoteType='", Search_type.Text, "'"));
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].Visible = false;
			}
		}

		public void PatientName_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				if (note_type.SelectedIndex == 0)
				{
					dataGridServices.Rows.Clear();
					DataTable dataTable = new DataTable();
					dataTable = Query.GetTableText(string.Concat("select * from PatientAccount where PatientId = '", PatientName.SelectedValue, "' and Pay = 'False'"));
					for (int i = 0; i < dataTable.Rows.Count; i++)
					{
						dataGridServices.Rows.Add(dataTable.Rows[i]["ID"].ToString(), dataTable.Rows[i]["Bean"].ToString(), Convert.ToDouble(dataTable.Rows[i]["Price"].ToString()) / Convert.ToDouble(dataTable.Rows[i]["ServiceCount"].ToString()), Convert.ToDouble(dataTable.Rows[i]["ServiceCount"].ToString()), Convert.ToDouble(dataTable.Rows[i]["Price"].ToString()), Convert.ToDouble(dataTable.Rows[i]["PricePay"].ToString()), 0, dataTable.Rows[i]["DoctorID"].ToString(), dataTable.Rows[i]["Date"].ToString());
					}
				}
			}
			catch
			{
			}
		}

		private void dataGridServices_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			Bayan.Text = "خصم علي خدمة " + dataGridServices.CurrentRow.Cells[1].Value.ToString();
		}

		private void note_type_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (note_type.SelectedIndex == 1)
			{
				Bayan.Text = "إشعار أضافة";
			}
			else
			{
				Bayan.Text = "إشعار خصم";
			}
		}
	}
}
