using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmPatientRebackStatementRPT : ReportBaseForm
	{
		private ClassDataBase dc;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private GroupBox groupBox1;

		private CrystalReportViewer crystalReportViewer1;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlSelectCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlInsertCommand2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlSelectCommand3;

		private SqlConnection sqlConnection3;

		private SqlCommand sqlInsertCommand3;

		private SqlDataAdapter sqlDataAdapter3;

		private SqlCommand sqlSelectCommand4;

		private SqlConnection sqlConnection4;

		private SqlCommand sqlInsertCommand4;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter4;

		private DataSet1 dataSet12;

		private DataSet1 dataSet13;

		public FrmPatientRebackStatementRPT()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		private void FrmMovementOfPatientStatment_Load(object sender, EventArgs e)
		{
			try
			{
				dataSet11.Clear();
				DataTable dataTable = new DataTable();
				dataTable = dc.GetTableText("select * from Appointments where packDate ='" + DateTime.Now.ToString("MM/dd/yyyy") + "' AND (Appointments.PackDone = 'false')");
				if (dataTable.Rows.Count > 0)
				{
					sqlConnection1.ConnectionString = dc.ConnectionStr;
					sqlConnection2.ConnectionString = dc.ConnectionStr;
					sqlConnection3.ConnectionString = dc.ConnectionStr;
					sqlConnection4.ConnectionString = dc.ConnectionStr;
					sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
					sqlDataAdapter1.SelectCommand.CommandText = "select * from Appointments where packDate ='" + DateTime.Now.ToString("MM/dd/yyyy") + "' AND (Appointments.PackDone = 'false')";
					sqlDataAdapter1.Fill(dataSet11);
					sqlDataAdapter2.Fill(dataSet11);
					sqlDataAdapter3.Fill(dataSet11);
					sqlDataAdapter4.Fill(dataSet11);
					RPTPatientRebackStatement rPTPatientRebackStatement = new RPTPatientRebackStatement();
					rPTPatientRebackStatement.SetDataSource(dataSet11);
					crystalReportViewer1.ReportSource = rPTPatientRebackStatement;
				}
				else
				{
					crystalReportViewer1.ReportSource = null;
					MessageBox.Show("لا يوجد بيانات ");
				}
			}
			catch
			{
			}
		}

		private void FrmMovementOfPatientStatment_KeyDown(object sender, KeyEventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmPatientRebackStatementRPT));
			groupBox1 = new System.Windows.Forms.GroupBox();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlConnection3 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlConnection4 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter4 = new System.Data.SqlClient.SqlDataAdapter();
			dataSet11 = new DataSet1();
			dataSet12 = new DataSet1();
			dataSet13 = new DataSet1();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataSet12).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataSet13).BeginInit();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(crystalReportViewer1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			sqlSelectCommand1.CommandText = "SELECT        Appointments.*\r\nFROM            Appointments";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[11]
			{
				new System.Data.SqlClient.SqlParameter("@AppointNum", System.Data.SqlDbType.NVarChar, 0, "AppointNum"),
				new System.Data.SqlClient.SqlParameter("@PatuentID", System.Data.SqlDbType.Int, 0, "PatuentID"),
				new System.Data.SqlClient.SqlParameter("@DoctorID", System.Data.SqlDbType.Int, 0, "DoctorID"),
				new System.Data.SqlClient.SqlParameter("@detectDate", System.Data.SqlDbType.DateTime, 0, "detectDate"),
				new System.Data.SqlClient.SqlParameter("@detectStartTime", System.Data.SqlDbType.NVarChar, 0, "detectStartTime"),
				new System.Data.SqlClient.SqlParameter("@detectEndTime", System.Data.SqlDbType.NVarChar, 0, "detectEndTime"),
				new System.Data.SqlClient.SqlParameter("@packDate", System.Data.SqlDbType.DateTime, 0, "packDate"),
				new System.Data.SqlClient.SqlParameter("@ExpDate", System.Data.SqlDbType.DateTime, 0, "ExpDate"),
				new System.Data.SqlClient.SqlParameter("@ChairNum", System.Data.SqlDbType.NVarChar, 0, "ChairNum"),
				new System.Data.SqlClient.SqlParameter("@Price", System.Data.SqlDbType.Money, 0, "Price"),
				new System.Data.SqlClient.SqlParameter("@Done", System.Data.SqlDbType.Bit, 0, "Done")
			});
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Appointments", new System.Data.Common.DataColumnMapping[12]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("AppointNum", "AppointNum"),
					new System.Data.Common.DataColumnMapping("PatuentID", "PatuentID"),
					new System.Data.Common.DataColumnMapping("DoctorID", "DoctorID"),
					new System.Data.Common.DataColumnMapping("detectDate", "detectDate"),
					new System.Data.Common.DataColumnMapping("detectStartTime", "detectStartTime"),
					new System.Data.Common.DataColumnMapping("detectEndTime", "detectEndTime"),
					new System.Data.Common.DataColumnMapping("packDate", "packDate"),
					new System.Data.Common.DataColumnMapping("ExpDate", "ExpDate"),
					new System.Data.Common.DataColumnMapping("ChairNum", "ChairNum"),
					new System.Data.Common.DataColumnMapping("Price", "Price"),
					new System.Data.Common.DataColumnMapping("Done", "Done")
				})
			});
			sqlSelectCommand2.CommandText = "SELECT        Empdata.*\r\nFROM            Empdata";
			sqlSelectCommand2.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.CommandText = "INSERT INTO [Empdata] ([Designation], [Name], [Address], [Tel], [Mob], [Email], [Salary], [Percentage]) VALUES (@Designation, @Name, @Address, @Tel, @Mob, @Email, @Salary, @Percentage)";
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[8]
			{
				new System.Data.SqlClient.SqlParameter("@Designation", System.Data.SqlDbType.NVarChar, 0, "Designation"),
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 0, "Address"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@Salary", System.Data.SqlDbType.Money, 0, "Salary"),
				new System.Data.SqlClient.SqlParameter("@Percentage", System.Data.SqlDbType.NVarChar, 0, "Percentage")
			});
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Empdata", new System.Data.Common.DataColumnMapping[9]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Designation", "Designation"),
					new System.Data.Common.DataColumnMapping("Name", "Name"),
					new System.Data.Common.DataColumnMapping("Address", "Address"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("Salary", "Salary"),
					new System.Data.Common.DataColumnMapping("Percentage", "Percentage")
				})
			});
			sqlSelectCommand3.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlSelectCommand3.Connection = sqlConnection3;
			sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection3.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand3.CommandText = resources.GetString("sqlInsertCommand3.CommandText");
			sqlInsertCommand3.Connection = sqlConnection3;
			sqlInsertCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[34]
			{
				new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
				new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
				new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
				new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
				new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
				new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
				new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
				new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
				new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
				new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
				new System.Data.SqlClient.SqlParameter("@pain", System.Data.SqlDbType.Bit, 0, "pain"),
				new System.Data.SqlClient.SqlParameter("@Caries", System.Data.SqlDbType.Bit, 0, "Caries"),
				new System.Data.SqlClient.SqlParameter("@RoutineVisit", System.Data.SqlDbType.Bit, 0, "RoutineVisit"),
				new System.Data.SqlClient.SqlParameter("@Swelling", System.Data.SqlDbType.Bit, 0, "Swelling"),
				new System.Data.SqlClient.SqlParameter("@Esthetics", System.Data.SqlDbType.Bit, 0, "Esthetics"),
				new System.Data.SqlClient.SqlParameter("@Others", System.Data.SqlDbType.NVarChar, 0, "Others"),
				new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
				new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
				new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
				new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
				new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
				new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
				new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
				new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
				new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
				new System.Data.SqlClient.SqlParameter("@DrugSensitivity", System.Data.SqlDbType.Bit, 0, "DrugSensitivity"),
				new System.Data.SqlClient.SqlParameter("@PulpTherapy", System.Data.SqlDbType.Bit, 0, "PulpTherapy"),
				new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
				new System.Data.SqlClient.SqlParameter("@FlourideTherapy", System.Data.SqlDbType.Bit, 0, "FlourideTherapy"),
				new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers")
			});
			sqlDataAdapter3.InsertCommand = sqlInsertCommand3;
			sqlDataAdapter3.SelectCommand = sqlSelectCommand3;
			sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[35]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("pain", "pain"),
					new System.Data.Common.DataColumnMapping("Caries", "Caries"),
					new System.Data.Common.DataColumnMapping("RoutineVisit", "RoutineVisit"),
					new System.Data.Common.DataColumnMapping("Swelling", "Swelling"),
					new System.Data.Common.DataColumnMapping("Esthetics", "Esthetics"),
					new System.Data.Common.DataColumnMapping("Others", "Others"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("DrugSensitivity", "DrugSensitivity"),
					new System.Data.Common.DataColumnMapping("PulpTherapy", "PulpTherapy"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("FlourideTherapy", "FlourideTherapy"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers")
				})
			});
			sqlSelectCommand4.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand4.Connection = sqlConnection4;
			sqlConnection4.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection4.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand4.CommandText = resources.GetString("sqlInsertCommand4.CommandText");
			sqlInsertCommand4.Connection = sqlConnection4;
			sqlInsertCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection4;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection4;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter4.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter4.InsertCommand = sqlInsertCommand4;
			sqlDataAdapter4.SelectCommand = sqlSelectCommand4;
			sqlDataAdapter4.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[8]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo")
				})
			});
			sqlDataAdapter4.UpdateCommand = sqlUpdateCommand1;
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			dataSet12.DataSetName = "DataSet1";
			dataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			dataSet13.DataSetName = "DataSet1";
			dataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(groupBox1);
			Font = null;
			base.Icon = null;
			base.Name = "FrmPatientRebackStatementRPT";
			Text = "إعادة كشوفات اليوم";
			base.Load += new System.EventHandler(FrmMovementOfPatientStatment_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(FrmMovementOfPatientStatment_KeyDown);
			groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			((System.ComponentModel.ISupportInitialize)dataSet12).EndInit();
			((System.ComponentModel.ISupportInitialize)dataSet13).EndInit();
			ResumeLayout(false);
		}
	}
}
