using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmAttend : BaseForm
	{
		private dataClass codes;

		private int patientId;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private int id;

		private ClassDataBase dc = new ClassDataBase(".\\sqlExpress");

		private GUI gui = new GUI();

		private IContainer components = null;

		private GroupBox groupBox1;

		private Label label2;

		private Label label1;

		private ComboBox PatientCom;

		private DateTimePicker dateTimePicker1;

		private Button button2;

		private Label label6;

		private TextBox NotsText;

		private Button button3;

		private Button EditBtn;

		private Button button1;

		private DataGridView dataGridView1;

		public FrmAttend()
		{
			InitializeComponent();
			codes = new dataClass(".\\sqlExpress");
		}

		public void LoadPatient()
		{
			try
			{
				DataTable dataTable = new DataTable();
				if (Convert.ToBoolean(codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString()))
				{
					dataTable = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True' order by PName");
					PatientCom.DataSource = dataTable;
					PatientCom.DisplayMember = dataTable.Columns[1].ToString();
					PatientCom.ValueMember = dataTable.Columns[0].ToString();
				}
				else
				{
					dataTable = dc.Select("SelectAllPatient");
					gui.loadComboBox(PatientCom, dataTable);
				}
			}
			catch
			{
			}
		}

		private void PrescriptionFrm_Load(object sender, EventArgs e)
		{
			try
			{
				LoadPatient();
				DataTable dataTable = new DataTable();
				dataTable = ((!(Settings.Default.Language == "en-GB")) ? codes.Search2("select Attend.ID,Attend.PatientID,PatientData.PName As 'أسم المريض' ,Attend.Date As 'التاريخ',Attend.Reason As 'سبب الحضور' from Attend inner join PatientData on PatientData.ID=Attend.PatientID") : codes.Search2("select Attend.ID,Attend.PatientID,PatientData.PName As 'Patient Name' ,Attend.Date As 'Date',Attend.Reason As 'Attend Cause' from Attend inner join PatientData on PatientData.ID=Attend.PatientID"));
				dataGridView1.DataSource = dataTable;
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].Visible = false;
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				if (PatientCom.SelectedItem == null || PatientCom.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Valid Patient Name");
					}
					else
					{
						MessageBox.Show(" من فضلك اختر اسم مريض صحيح");
					}
					return;
				}
				if (NotsText.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Reason");
					}
					else
					{
						MessageBox.Show(" من فضلك أدخل سبب الحضور");
					}
					return;
				}
				codes.Add2("INSERT INTO Attend  (PatientID,Date,Reason)VALUES ('" + PatientCom.SelectedValue.ToString() + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + NotsText.Text + "')");
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Have Been Saved");
				}
				else
				{
					MessageBox.Show("تم حفظ البيانات بنجاح");
				}
				MethodsClass.UserMove("أضافة شهادة حضور");
				FrmAttendRpt frmAttendRpt = new FrmAttendRpt(Convert.ToInt32(codes.Search2("select max(ID) from Attend").Rows[0][0]), Convert.ToInt32(PatientCom.SelectedValue.ToString()));
				frmAttendRpt.ShowDialog();
				clear();
			}
			catch
			{
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				codes.Delete2("delete from Attend where ID =  '" + id + "'");
				codes.Add2("INSERT INTO Attend  (PatientID,Date,Reason)VALUES ('" + PatientCom.SelectedValue.ToString() + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + NotsText.Text + "')");
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Have Been Saved");
				}
				else
				{
					MessageBox.Show("تم تعديل البيانات بنجاح");
				}
				MethodsClass.UserMove("تعديل شهادة حضور");
				FrmAttendRpt frmAttendRpt = new FrmAttendRpt(Convert.ToInt32(codes.Search2("select max(ID) from Attend").Rows[0][0]), Convert.ToInt32(PatientCom.SelectedValue.ToString()));
				frmAttendRpt.ShowDialog();
				clear();
			}
			catch
			{
			}
		}

		private void clear()
		{
			dateTimePicker1.Value = DateTime.Now;
			PatientCom.SelectedIndex = -1;
			NotsText.Text = "";
			dataGridView1.DataSource = null;
			dataGridView1.Rows.Clear();
			EditBtn.Enabled = false;
			button1.Enabled = false;
			button2.Enabled = true;
			DataTable dataTable = new DataTable();
			dataTable = ((!(Settings.Default.Language == "en-GB")) ? codes.Search2("select Attend.ID,Attend.PatientID,PatientData.PName As 'أسم المريض' ,Attend.Date As 'التاريخ',Attend.Reason As 'سبب الحضور' from Attend inner join PatientData on PatientData.ID=Attend.PatientID") : codes.Search2("select Attend.ID,Attend.PatientID,PatientData.PName As 'Patient Name' ,Attend.Date As 'Date',Attend.Reason As 'Attend Cause' from Attend inner join PatientData on PatientData.ID=Attend.PatientID"));
			dataGridView1.DataSource = dataTable;
			dataGridView1.Columns[0].Visible = false;
			dataGridView1.Columns[1].Visible = false;
			dataGridView1.Columns[2].Width = 200;
			dataGridView1.Columns[4].Width = 200;
		}

		private void button3_Click(object sender, EventArgs e)
		{
			clear();
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
				PatientCom.SelectedValue = dataGridView1.CurrentRow.Cells[1].Value.ToString();
				dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[3].Value);
				NotsText.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
				EditBtn.Enabled = true;
				button1.Enabled = true;
				button2.Enabled = false;
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				codes.Delete("delete from Attend where ID =  '" + id + "'");
				MethodsClass.UserMove("حذف شهادة حضور");
				clear();
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmAttend));
			groupBox1 = new System.Windows.Forms.GroupBox();
			label6 = new System.Windows.Forms.Label();
			PatientCom = new System.Windows.Forms.ComboBox();
			NotsText = new System.Windows.Forms.TextBox();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			button2 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			EditBtn = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(label6);
			groupBox1.Controls.Add(PatientCom);
			groupBox1.Controls.Add(NotsText);
			groupBox1.Controls.Add(dateTimePicker1);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(label1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "label6");
			label6.ForeColor = System.Drawing.Color.WhiteSmoke;
			label6.Name = "label6";
			PatientCom.AccessibleDescription = null;
			PatientCom.AccessibleName = null;
			resources.ApplyResources(PatientCom, "PatientCom");
			PatientCom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			PatientCom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientCom.BackgroundImage = null;
			PatientCom.Font = null;
			PatientCom.FormattingEnabled = true;
			PatientCom.Name = "PatientCom";
			NotsText.AccessibleDescription = null;
			NotsText.AccessibleName = null;
			resources.ApplyResources(NotsText, "NotsText");
			NotsText.BackgroundImage = null;
			NotsText.Font = null;
			NotsText.Name = "NotsText";
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.Font = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.ForeColor = System.Drawing.Color.WhiteSmoke;
			label2.Name = "label2";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.ForeColor = System.Drawing.Color.WhiteSmoke;
			label1.Name = "label1";
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackColor = System.Drawing.Color.Gainsboro;
			button2.BackgroundImage = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = false;
			button2.Click += new System.EventHandler(button2_Click);
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackColor = System.Drawing.Color.Gainsboro;
			button3.BackgroundImage = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = false;
			button3.Click += new System.EventHandler(button3_Click);
			EditBtn.AccessibleDescription = null;
			EditBtn.AccessibleName = null;
			resources.ApplyResources(EditBtn, "EditBtn");
			EditBtn.BackColor = System.Drawing.Color.Gainsboro;
			EditBtn.BackgroundImage = null;
			EditBtn.Name = "EditBtn";
			EditBtn.UseVisualStyleBackColor = false;
			EditBtn.Click += new System.EventHandler(EditBtn_Click);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.BackgroundImage = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(dataGridView1);
			base.Controls.Add(button1);
			base.Controls.Add(button3);
			base.Controls.Add(EditBtn);
			base.Controls.Add(button2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FrmAttend";
			base.Load += new System.EventHandler(PrescriptionFrm_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
		}
	}
}
