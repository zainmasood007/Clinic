using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace DentistClinic
{
	public class fmusers : BaseForm
	{
		private IContainer components = null;

		private ListBox userslistbox;

		private GroupBox groupBox3;

		private TextBox usernameTextBox;

		private TextBox userPasswardTextBox;

		private Label label1;

		private Label label2;

		private GroupBox groupBox2;

		private CheckBox DentalDataCh;

		private CheckBox AddEmployeeCh;

		private CheckBox AddPatientCh;

		private CheckBox AppointmentCh;

		private GroupBox groupBox1;

		private CheckBox PatAccountRpt;

		private Label label3;

		private ComboBox EmpCombo;

		private Button NewUserBtn;

		private Button DeleteUserBtn;

		private Button UpdateUserBtn;

		private Button AddUserBtn;

		private CheckBox AllPatientAccountRptCh;

		private CheckBox PatientXray;

		private CheckBox DoctorAccountCh;

		private CheckBox SearchPatientCh;

		private CheckBox CompanyCh;

		private CheckBox PatientAccountCh;

		private CheckBox PatientPayCh;

		private CheckBox DoctorPaymentRptCh;

		private CheckBox DoctorAccountRptCh;

		private CheckBox MovepatStByDrRptCh;

		private CheckBox MovementOfPatStRptCh;

		private CheckBox PermissionCh;

		private GroupBox groupBox4;

		private GroupBox groupBox8;

		private GroupBox groupBox5;

		private GroupBox groupBox6;

		private CheckBox EditReBackDatech;

		private CheckBox RptDailyclinicch;

		private CheckBox RptRevenuesch;

		private CheckBox RptExpensesCh;

		private GroupBox groupBox10;

		private CheckBox Expensesch;

		private CheckBox RevenuesCh;

		private CheckBox medicineFrmBtn;

		private CheckBox PrescriptionFrmBtn;

		private GroupBox groupBox11;

		private CheckBox FrmSupplierAccountsBtn;

		private CheckBox FormSupplier5Btn;

		private CheckBox ItemsFrmBtn;

		private CheckBox IncomingBillFrmBtn;

		private CheckBox SupplierBtn;

		private CheckBox FrmBillIncomeRptBtn;

		private CheckBox OldServicesRptFrmBtn;

		private CheckBox ClinicMonthGraphRptFrmBtn;

		private CheckBox NetDailyClinicRptFrmBtn;

		private CheckBox DailymeasureRotFrmBtn;

		private CheckBox RptFrmSearchMedicine;

		private CheckBox ServicePatientBtn;

		private CheckBox MainComplaintBtn;

		private CheckBox SahbItemsBtn;

		private CheckBox FrmRptBillByDateBtn;

		private CheckBox FrmRptSahbItemBtn;

		private CheckBox FrmFilePatientBtn;

		private CheckBox FrmPropertiesBtn;

		private CheckBox btnBackup_Restore;

		private CheckBox Surgery;

		private CheckBox RptVisits;

		private CheckBox BookingVisits;

		private CheckBox BtnFrmRptCompanies_Services;

		private CheckBox BtnFrmRptReb7ya;

		private CheckBox BtnFrmSell;

		private CheckBox FrmRptSellByDateBtn;

		private CheckBox PatientAccountUpdateBtn;

		private CheckBox PatientServiceUpdateBtn;

		private CheckBox FrmInventoryRptBtn;

		private CheckBox FrmLimitOrderRptBtn;

		private GroupBox groupBox9;

		private CheckBox FrmInoculationBtn;

		private CheckBox PatientSurgery;

		private CheckBox DoctorVisits;

		private CheckBox SecretaryVisits;

		private CheckBox ChangeServicePrice;

		private CheckBox DoctorReBackAppointmentch;

		private CheckBox ReBackAppointmentListch;

		private CheckBox DoctorPatientListCh;

		private CheckBox SecretarPatientListCh;

		private CheckBox FrmPatientInoculationBtn;

		private CheckBox FrmAssistantRptBtn;

		private CheckBox FrmRptPatientDebtBtn;

		private CheckBox doctorAcountBtn;

		private CheckBox FrmBillBtn;

		private CheckBox FrmVisitMedicalRepBtn;

		private CheckBox AppointmentspBtn;

		private CheckBox FrmRptSurgeryBtn;

		private CheckBox CompanyPayBtn;

		private CheckBox FrmRptCompanyAcountBtn;

		private CheckBox FrmRptSpecialBtn;

		private CheckBox AssistantAccountBtn;

		private CheckBox RptAssistantPaymentBtn;

		private CheckBox AssistantAcountDate;

		private CheckBox RptLoginUserBtn;

		private CheckBox StockFrmBtn;

		private CheckBox StockUsersFrmBtn;

		private CheckBox FrmTarnsbetweenStockBtn;

		private CheckBox StockTransRptFrmBtn;

		private CheckBox FrmDeanSupplierBtn;

		private CheckBox updateSurgery;

		private ClassDataBase dc;

		private int userId;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			userslistbox = new System.Windows.Forms.ListBox();
			groupBox3 = new System.Windows.Forms.GroupBox();
			NewUserBtn = new System.Windows.Forms.Button();
			EmpCombo = new System.Windows.Forms.ComboBox();
			label3 = new System.Windows.Forms.Label();
			usernameTextBox = new System.Windows.Forms.TextBox();
			userPasswardTextBox = new System.Windows.Forms.TextBox();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			btnBackup_Restore = new System.Windows.Forms.CheckBox();
			groupBox10 = new System.Windows.Forms.GroupBox();
			updateSurgery = new System.Windows.Forms.CheckBox();
			FrmDeanSupplierBtn = new System.Windows.Forms.CheckBox();
			FrmTarnsbetweenStockBtn = new System.Windows.Forms.CheckBox();
			StockUsersFrmBtn = new System.Windows.Forms.CheckBox();
			StockFrmBtn = new System.Windows.Forms.CheckBox();
			AssistantAccountBtn = new System.Windows.Forms.CheckBox();
			CompanyPayBtn = new System.Windows.Forms.CheckBox();
			Expensesch = new System.Windows.Forms.CheckBox();
			DoctorAccountCh = new System.Windows.Forms.CheckBox();
			RevenuesCh = new System.Windows.Forms.CheckBox();
			FrmPropertiesBtn = new System.Windows.Forms.CheckBox();
			groupBox11 = new System.Windows.Forms.GroupBox();
			FrmLimitOrderRptBtn = new System.Windows.Forms.CheckBox();
			FrmRptSellByDateBtn = new System.Windows.Forms.CheckBox();
			ServicePatientBtn = new System.Windows.Forms.CheckBox();
			BtnFrmSell = new System.Windows.Forms.CheckBox();
			FrmRptBillByDateBtn = new System.Windows.Forms.CheckBox();
			SahbItemsBtn = new System.Windows.Forms.CheckBox();
			FrmBillIncomeRptBtn = new System.Windows.Forms.CheckBox();
			FrmSupplierAccountsBtn = new System.Windows.Forms.CheckBox();
			FormSupplier5Btn = new System.Windows.Forms.CheckBox();
			ItemsFrmBtn = new System.Windows.Forms.CheckBox();
			IncomingBillFrmBtn = new System.Windows.Forms.CheckBox();
			SupplierBtn = new System.Windows.Forms.CheckBox();
			PermissionCh = new System.Windows.Forms.CheckBox();
			groupBox8 = new System.Windows.Forms.GroupBox();
			FrmRptSpecialBtn = new System.Windows.Forms.CheckBox();
			FrmPatientInoculationBtn = new System.Windows.Forms.CheckBox();
			DoctorPatientListCh = new System.Windows.Forms.CheckBox();
			PrescriptionFrmBtn = new System.Windows.Forms.CheckBox();
			medicineFrmBtn = new System.Windows.Forms.CheckBox();
			DoctorReBackAppointmentch = new System.Windows.Forms.CheckBox();
			PatientSurgery = new System.Windows.Forms.CheckBox();
			DoctorVisits = new System.Windows.Forms.CheckBox();
			DentalDataCh = new System.Windows.Forms.CheckBox();
			groupBox5 = new System.Windows.Forms.GroupBox();
			AddEmployeeCh = new System.Windows.Forms.CheckBox();
			groupBox9 = new System.Windows.Forms.GroupBox();
			AppointmentspBtn = new System.Windows.Forms.CheckBox();
			FrmVisitMedicalRepBtn = new System.Windows.Forms.CheckBox();
			AppointmentCh = new System.Windows.Forms.CheckBox();
			RptVisits = new System.Windows.Forms.CheckBox();
			EditReBackDatech = new System.Windows.Forms.CheckBox();
			BookingVisits = new System.Windows.Forms.CheckBox();
			ChangeServicePrice = new System.Windows.Forms.CheckBox();
			FrmInoculationBtn = new System.Windows.Forms.CheckBox();
			SecretarPatientListCh = new System.Windows.Forms.CheckBox();
			ReBackAppointmentListch = new System.Windows.Forms.CheckBox();
			SecretaryVisits = new System.Windows.Forms.CheckBox();
			groupBox6 = new System.Windows.Forms.GroupBox();
			StockTransRptFrmBtn = new System.Windows.Forms.CheckBox();
			RptLoginUserBtn = new System.Windows.Forms.CheckBox();
			RptAssistantPaymentBtn = new System.Windows.Forms.CheckBox();
			AssistantAcountDate = new System.Windows.Forms.CheckBox();
			FrmRptCompanyAcountBtn = new System.Windows.Forms.CheckBox();
			FrmRptSurgeryBtn = new System.Windows.Forms.CheckBox();
			FrmBillBtn = new System.Windows.Forms.CheckBox();
			doctorAcountBtn = new System.Windows.Forms.CheckBox();
			FrmRptPatientDebtBtn = new System.Windows.Forms.CheckBox();
			FrmAssistantRptBtn = new System.Windows.Forms.CheckBox();
			FrmInventoryRptBtn = new System.Windows.Forms.CheckBox();
			BtnFrmRptCompanies_Services = new System.Windows.Forms.CheckBox();
			BtnFrmRptReb7ya = new System.Windows.Forms.CheckBox();
			FrmRptSahbItemBtn = new System.Windows.Forms.CheckBox();
			RptFrmSearchMedicine = new System.Windows.Forms.CheckBox();
			DailymeasureRotFrmBtn = new System.Windows.Forms.CheckBox();
			ClinicMonthGraphRptFrmBtn = new System.Windows.Forms.CheckBox();
			NetDailyClinicRptFrmBtn = new System.Windows.Forms.CheckBox();
			OldServicesRptFrmBtn = new System.Windows.Forms.CheckBox();
			RptDailyclinicch = new System.Windows.Forms.CheckBox();
			RptRevenuesch = new System.Windows.Forms.CheckBox();
			RptExpensesCh = new System.Windows.Forms.CheckBox();
			PatAccountRpt = new System.Windows.Forms.CheckBox();
			DoctorPaymentRptCh = new System.Windows.Forms.CheckBox();
			MovementOfPatStRptCh = new System.Windows.Forms.CheckBox();
			DoctorAccountRptCh = new System.Windows.Forms.CheckBox();
			MovepatStByDrRptCh = new System.Windows.Forms.CheckBox();
			AllPatientAccountRptCh = new System.Windows.Forms.CheckBox();
			groupBox4 = new System.Windows.Forms.GroupBox();
			PatientServiceUpdateBtn = new System.Windows.Forms.CheckBox();
			PatientAccountUpdateBtn = new System.Windows.Forms.CheckBox();
			Surgery = new System.Windows.Forms.CheckBox();
			FrmFilePatientBtn = new System.Windows.Forms.CheckBox();
			MainComplaintBtn = new System.Windows.Forms.CheckBox();
			AddPatientCh = new System.Windows.Forms.CheckBox();
			SearchPatientCh = new System.Windows.Forms.CheckBox();
			CompanyCh = new System.Windows.Forms.CheckBox();
			PatientPayCh = new System.Windows.Forms.CheckBox();
			PatientAccountCh = new System.Windows.Forms.CheckBox();
			PatientXray = new System.Windows.Forms.CheckBox();
			groupBox1 = new System.Windows.Forms.GroupBox();
			DeleteUserBtn = new System.Windows.Forms.Button();
			UpdateUserBtn = new System.Windows.Forms.Button();
			AddUserBtn = new System.Windows.Forms.Button();
			groupBox3.SuspendLayout();
			groupBox2.SuspendLayout();
			groupBox10.SuspendLayout();
			groupBox11.SuspendLayout();
			groupBox8.SuspendLayout();
			groupBox5.SuspendLayout();
			groupBox9.SuspendLayout();
			groupBox6.SuspendLayout();
			groupBox4.SuspendLayout();
			groupBox1.SuspendLayout();
			SuspendLayout();
			userslistbox.BackColor = System.Drawing.Color.LightSteelBlue;
			userslistbox.Cursor = System.Windows.Forms.Cursors.Hand;
			userslistbox.Font = new System.Drawing.Font("Tahoma", 10f);
			userslistbox.FormattingEnabled = true;
			userslistbox.ItemHeight = 16;
			userslistbox.Location = new System.Drawing.Point(7, 15);
			userslistbox.Name = "userslistbox";
			userslistbox.Size = new System.Drawing.Size(200, 564);
			userslistbox.TabIndex = 9;
			userslistbox.SelectedIndexChanged += new System.EventHandler(userslistbox_SelectedIndexChanged);
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.Controls.Add(NewUserBtn);
			groupBox3.Controls.Add(EmpCombo);
			groupBox3.Controls.Add(label3);
			groupBox3.Controls.Add(usernameTextBox);
			groupBox3.Controls.Add(userPasswardTextBox);
			groupBox3.Controls.Add(label2);
			groupBox3.Controls.Add(label1);
			groupBox3.Location = new System.Drawing.Point(215, 0);
			groupBox3.Name = "groupBox3";
			groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox3.Size = new System.Drawing.Size(808, 100);
			groupBox3.TabIndex = 0;
			groupBox3.TabStop = false;
			NewUserBtn.BackColor = System.Drawing.Color.Transparent;
			NewUserBtn.Font = new System.Drawing.Font("Arial", 10f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			NewUserBtn.Location = new System.Drawing.Point(192, 61);
			NewUserBtn.Name = "NewUserBtn";
			NewUserBtn.Size = new System.Drawing.Size(154, 32);
			NewUserBtn.TabIndex = 5;
			NewUserBtn.Text = "مستخدم جديد";
			NewUserBtn.UseVisualStyleBackColor = false;
			NewUserBtn.Click += new System.EventHandler(NewUserBtn_Click);
			EmpCombo.Font = new System.Drawing.Font("Arial", 9.75f);
			EmpCombo.FormattingEnabled = true;
			EmpCombo.Location = new System.Drawing.Point(353, 15);
			EmpCombo.Name = "EmpCombo";
			EmpCombo.Size = new System.Drawing.Size(286, 24);
			EmpCombo.TabIndex = 1;
			label3.AutoSize = true;
			label3.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label3.Location = new System.Drawing.Point(641, 16);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(114, 19);
			label3.TabIndex = 3;
			label3.Text = "اختر اسم موظف :";
			usernameTextBox.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			usernameTextBox.Location = new System.Drawing.Point(419, 43);
			usernameTextBox.Name = "usernameTextBox";
			usernameTextBox.Size = new System.Drawing.Size(220, 22);
			usernameTextBox.TabIndex = 2;
			userPasswardTextBox.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			userPasswardTextBox.Location = new System.Drawing.Point(419, 71);
			userPasswardTextBox.Name = "userPasswardTextBox";
			userPasswardTextBox.Size = new System.Drawing.Size(220, 22);
			userPasswardTextBox.TabIndex = 3;
			label2.AutoSize = true;
			label2.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label2.Location = new System.Drawing.Point(641, 44);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(97, 19);
			label2.TabIndex = 0;
			label2.Text = "اسم المستخدم :";
			label1.AutoSize = true;
			label1.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label1.Location = new System.Drawing.Point(641, 72);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(88, 19);
			label1.TabIndex = 0;
			label1.Text = "كلمة المرور :";
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(btnBackup_Restore);
			groupBox2.Controls.Add(groupBox10);
			groupBox2.Controls.Add(FrmPropertiesBtn);
			groupBox2.Controls.Add(groupBox11);
			groupBox2.Controls.Add(PermissionCh);
			groupBox2.Controls.Add(groupBox8);
			groupBox2.Controls.Add(DentalDataCh);
			groupBox2.Controls.Add(groupBox5);
			groupBox2.Controls.Add(groupBox9);
			groupBox2.Controls.Add(groupBox6);
			groupBox2.Controls.Add(groupBox4);
			groupBox2.Location = new System.Drawing.Point(215, 98);
			groupBox2.Name = "groupBox2";
			groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox2.Size = new System.Drawing.Size(938, 481);
			groupBox2.TabIndex = 1;
			groupBox2.TabStop = false;
			btnBackup_Restore.AutoSize = true;
			btnBackup_Restore.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnBackup_Restore.Location = new System.Drawing.Point(382, 220);
			btnBackup_Restore.Name = "btnBackup_Restore";
			btnBackup_Restore.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			btnBackup_Restore.Size = new System.Drawing.Size(145, 23);
			btnBackup_Restore.TabIndex = 13;
			btnBackup_Restore.Text = "عمل نسخة احتياطية";
			btnBackup_Restore.UseVisualStyleBackColor = true;
			groupBox10.Controls.Add(updateSurgery);
			groupBox10.Controls.Add(FrmDeanSupplierBtn);
			groupBox10.Controls.Add(FrmTarnsbetweenStockBtn);
			groupBox10.Controls.Add(StockUsersFrmBtn);
			groupBox10.Controls.Add(StockFrmBtn);
			groupBox10.Controls.Add(AssistantAccountBtn);
			groupBox10.Controls.Add(CompanyPayBtn);
			groupBox10.Controls.Add(doctorAcountBtn);
			groupBox10.Controls.Add(Expensesch);
			groupBox10.Controls.Add(RevenuesCh);
			groupBox10.Location = new System.Drawing.Point(9, 143);
			groupBox10.Name = "groupBox10";
			groupBox10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox10.Size = new System.Drawing.Size(366, 96);
			groupBox10.TabIndex = 8;
			groupBox10.TabStop = false;
			updateSurgery.AutoSize = true;
			updateSurgery.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			updateSurgery.Location = new System.Drawing.Point(45, 71);
			updateSurgery.Name = "updateSurgery";
			updateSurgery.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			updateSurgery.Size = new System.Drawing.Size(151, 23);
			updateSurgery.TabIndex = 20;
			updateSurgery.Text = "تعديل عمليات مرضى";
			updateSurgery.UseVisualStyleBackColor = true;
			FrmDeanSupplierBtn.AutoSize = true;
			FrmDeanSupplierBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmDeanSupplierBtn.Location = new System.Drawing.Point(194, 71);
			FrmDeanSupplierBtn.Name = "FrmDeanSupplierBtn";
			FrmDeanSupplierBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmDeanSupplierBtn.Size = new System.Drawing.Size(161, 23);
			FrmDeanSupplierBtn.TabIndex = 19;
			FrmDeanSupplierBtn.Text = "رصيد أول المدة للمورد";
			FrmDeanSupplierBtn.UseVisualStyleBackColor = true;
			FrmTarnsbetweenStockBtn.AutoSize = true;
			FrmTarnsbetweenStockBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmTarnsbetweenStockBtn.Location = new System.Drawing.Point(22, 50);
			FrmTarnsbetweenStockBtn.Name = "FrmTarnsbetweenStockBtn";
			FrmTarnsbetweenStockBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmTarnsbetweenStockBtn.Size = new System.Drawing.Size(174, 23);
			FrmTarnsbetweenStockBtn.TabIndex = 18;
			FrmTarnsbetweenStockBtn.Text = "التحويل من خزينة لأخرى";
			FrmTarnsbetweenStockBtn.UseVisualStyleBackColor = true;
			StockUsersFrmBtn.AutoSize = true;
			StockUsersFrmBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			StockUsersFrmBtn.Location = new System.Drawing.Point(200, 50);
			StockUsersFrmBtn.Name = "StockUsersFrmBtn";
			StockUsersFrmBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			StockUsersFrmBtn.Size = new System.Drawing.Size(155, 23);
			StockUsersFrmBtn.TabIndex = 17;
			StockUsersFrmBtn.Text = "اضافة خزينة لمستخدم";
			StockUsersFrmBtn.UseVisualStyleBackColor = true;
			StockFrmBtn.AutoSize = true;
			StockFrmBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			StockFrmBtn.Location = new System.Drawing.Point(34, 30);
			StockFrmBtn.Name = "StockFrmBtn";
			StockFrmBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			StockFrmBtn.Size = new System.Drawing.Size(73, 23);
			StockFrmBtn.TabIndex = 16;
			StockFrmBtn.Text = "الخزائن";
			StockFrmBtn.UseVisualStyleBackColor = true;
			AssistantAccountBtn.AutoSize = true;
			AssistantAccountBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			AssistantAccountBtn.Location = new System.Drawing.Point(113, 31);
			AssistantAccountBtn.Name = "AssistantAccountBtn";
			AssistantAccountBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			AssistantAccountBtn.Size = new System.Drawing.Size(139, 23);
			AssistantAccountBtn.TabIndex = 15;
			AssistantAccountBtn.Text = "حسابات المساعدين";
			AssistantAccountBtn.UseVisualStyleBackColor = true;
			CompanyPayBtn.AutoSize = true;
			CompanyPayBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			CompanyPayBtn.Location = new System.Drawing.Point(254, 31);
			CompanyPayBtn.Name = "CompanyPayBtn";
			CompanyPayBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			CompanyPayBtn.Size = new System.Drawing.Size(101, 23);
			CompanyPayBtn.TabIndex = 14;
			CompanyPayBtn.Text = "حساب شركة";
			CompanyPayBtn.UseVisualStyleBackColor = true;
			Expensesch.AutoSize = true;
			Expensesch.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Expensesch.Location = new System.Drawing.Point(260, 10);
			Expensesch.Name = "Expensesch";
			Expensesch.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			Expensesch.Size = new System.Drawing.Size(95, 23);
			Expensesch.TabIndex = 10;
			Expensesch.Text = "المصروفات";
			Expensesch.UseVisualStyleBackColor = true;
			DoctorAccountCh.AutoSize = true;
			DoctorAccountCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			DoctorAccountCh.Location = new System.Drawing.Point(576, 112);
			DoctorAccountCh.Name = "DoctorAccountCh";
			DoctorAccountCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			DoctorAccountCh.Size = new System.Drawing.Size(145, 23);
			DoctorAccountCh.TabIndex = 12;
			DoctorAccountCh.Text = "تقرير مرضى التقويم";
			DoctorAccountCh.UseVisualStyleBackColor = true;
			RevenuesCh.AutoSize = true;
			RevenuesCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			RevenuesCh.Location = new System.Drawing.Point(171, 9);
			RevenuesCh.Name = "RevenuesCh";
			RevenuesCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			RevenuesCh.Size = new System.Drawing.Size(83, 23);
			RevenuesCh.TabIndex = 11;
			RevenuesCh.Text = "الإيرادات";
			RevenuesCh.UseVisualStyleBackColor = true;
			FrmPropertiesBtn.AutoSize = true;
			FrmPropertiesBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmPropertiesBtn.Location = new System.Drawing.Point(529, 220);
			FrmPropertiesBtn.Name = "FrmPropertiesBtn";
			FrmPropertiesBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmPropertiesBtn.Size = new System.Drawing.Size(111, 23);
			FrmPropertiesBtn.TabIndex = 12;
			FrmPropertiesBtn.Text = "خصائص عامة";
			FrmPropertiesBtn.UseVisualStyleBackColor = true;
			groupBox11.BackColor = System.Drawing.Color.Transparent;
			groupBox11.Controls.Add(FrmLimitOrderRptBtn);
			groupBox11.Controls.Add(FrmRptSellByDateBtn);
			groupBox11.Controls.Add(ServicePatientBtn);
			groupBox11.Controls.Add(BtnFrmSell);
			groupBox11.Controls.Add(FrmRptBillByDateBtn);
			groupBox11.Controls.Add(SahbItemsBtn);
			groupBox11.Controls.Add(FrmBillIncomeRptBtn);
			groupBox11.Controls.Add(FrmSupplierAccountsBtn);
			groupBox11.Controls.Add(FormSupplier5Btn);
			groupBox11.Controls.Add(ItemsFrmBtn);
			groupBox11.Controls.Add(IncomingBillFrmBtn);
			groupBox11.Controls.Add(SupplierBtn);
			groupBox11.Location = new System.Drawing.Point(9, 402);
			groupBox11.Name = "groupBox11";
			groupBox11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox11.Size = new System.Drawing.Size(921, 71);
			groupBox11.TabIndex = 15;
			groupBox11.TabStop = false;
			FrmLimitOrderRptBtn.AutoSize = true;
			FrmLimitOrderRptBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmLimitOrderRptBtn.Location = new System.Drawing.Point(113, 16);
			FrmLimitOrderRptBtn.Name = "FrmLimitOrderRptBtn";
			FrmLimitOrderRptBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmLimitOrderRptBtn.Size = new System.Drawing.Size(180, 23);
			FrmLimitOrderRptBtn.TabIndex = 13;
			FrmLimitOrderRptBtn.Text = "أصناف وصلت للحد الأدنى";
			FrmLimitOrderRptBtn.UseVisualStyleBackColor = true;
			FrmRptSellByDateBtn.AutoSize = true;
			FrmRptSellByDateBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmRptSellByDateBtn.Location = new System.Drawing.Point(445, 45);
			FrmRptSellByDateBtn.Name = "FrmRptSellByDateBtn";
			FrmRptSellByDateBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmRptSellByDateBtn.Size = new System.Drawing.Size(167, 23);
			FrmRptSellByDateBtn.TabIndex = 19;
			FrmRptSellByDateBtn.Text = "تقرير مبيعات خلال فترة";
			FrmRptSellByDateBtn.UseVisualStyleBackColor = true;
			ServicePatientBtn.AutoSize = true;
			ServicePatientBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			ServicePatientBtn.Location = new System.Drawing.Point(86, 42);
			ServicePatientBtn.Name = "ServicePatientBtn";
			ServicePatientBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			ServicePatientBtn.Size = new System.Drawing.Size(120, 23);
			ServicePatientBtn.TabIndex = 20;
			ServicePatientBtn.Text = "خدمات المرضى";
			ServicePatientBtn.UseVisualStyleBackColor = true;
			ServicePatientBtn.Visible = false;
			BtnFrmSell.AutoSize = true;
			BtnFrmSell.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			BtnFrmSell.Location = new System.Drawing.Point(618, 42);
			BtnFrmSell.Name = "BtnFrmSell";
			BtnFrmSell.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			BtnFrmSell.Size = new System.Drawing.Size(110, 23);
			BtnFrmSell.TabIndex = 18;
			BtnFrmSell.Text = "فاتورة مبيعات";
			BtnFrmSell.UseVisualStyleBackColor = true;
			FrmRptBillByDateBtn.AutoSize = true;
			FrmRptBillByDateBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmRptBillByDateBtn.Location = new System.Drawing.Point(736, 42);
			FrmRptBillByDateBtn.Name = "FrmRptBillByDateBtn";
			FrmRptBillByDateBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmRptBillByDateBtn.Size = new System.Drawing.Size(178, 23);
			FrmRptBillByDateBtn.TabIndex = 17;
			FrmRptBillByDateBtn.Text = "تقرير مشتريات خلال فترة";
			FrmRptBillByDateBtn.UseVisualStyleBackColor = true;
			SahbItemsBtn.AutoSize = true;
			SahbItemsBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			SahbItemsBtn.Location = new System.Drawing.Point(212, 42);
			SahbItemsBtn.Name = "SahbItemsBtn";
			SahbItemsBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			SahbItemsBtn.Size = new System.Drawing.Size(108, 23);
			SahbItemsBtn.TabIndex = 16;
			SahbItemsBtn.Text = "سحب للكميات";
			SahbItemsBtn.UseVisualStyleBackColor = true;
			FrmBillIncomeRptBtn.AutoSize = true;
			FrmBillIncomeRptBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmBillIncomeRptBtn.Location = new System.Drawing.Point(301, 16);
			FrmBillIncomeRptBtn.Name = "FrmBillIncomeRptBtn";
			FrmBillIncomeRptBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmBillIncomeRptBtn.Size = new System.Drawing.Size(157, 23);
			FrmBillIncomeRptBtn.TabIndex = 15;
			FrmBillIncomeRptBtn.Text = "تقرير فاتورة مشتريات";
			FrmBillIncomeRptBtn.UseVisualStyleBackColor = true;
			FrmSupplierAccountsBtn.AutoSize = true;
			FrmSupplierAccountsBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmSupplierAccountsBtn.Location = new System.Drawing.Point(699, 16);
			FrmSupplierAccountsBtn.Name = "FrmSupplierAccountsBtn";
			FrmSupplierAccountsBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmSupplierAccountsBtn.Size = new System.Drawing.Size(130, 23);
			FrmSupplierAccountsBtn.TabIndex = 13;
			FrmSupplierAccountsBtn.Text = "حسابات الموردين";
			FrmSupplierAccountsBtn.UseVisualStyleBackColor = true;
			FormSupplier5Btn.AutoSize = true;
			FormSupplier5Btn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FormSupplier5Btn.Location = new System.Drawing.Point(554, 16);
			FormSupplier5Btn.Name = "FormSupplier5Btn";
			FormSupplier5Btn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FormSupplier5Btn.Size = new System.Drawing.Size(132, 23);
			FormSupplier5Btn.TabIndex = 14;
			FormSupplier5Btn.Text = "كشف حساب مورد";
			FormSupplier5Btn.UseVisualStyleBackColor = true;
			ItemsFrmBtn.AutoSize = true;
			ItemsFrmBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			ItemsFrmBtn.Location = new System.Drawing.Point(835, 16);
			ItemsFrmBtn.Name = "ItemsFrmBtn";
			ItemsFrmBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			ItemsFrmBtn.Size = new System.Drawing.Size(79, 23);
			ItemsFrmBtn.TabIndex = 10;
			ItemsFrmBtn.Text = "الأصناف";
			ItemsFrmBtn.UseVisualStyleBackColor = true;
			IncomingBillFrmBtn.AutoSize = true;
			IncomingBillFrmBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			IncomingBillFrmBtn.Location = new System.Drawing.Point(321, 44);
			IncomingBillFrmBtn.Name = "IncomingBillFrmBtn";
			IncomingBillFrmBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			IncomingBillFrmBtn.Size = new System.Drawing.Size(121, 23);
			IncomingBillFrmBtn.TabIndex = 12;
			IncomingBillFrmBtn.Text = "فاتورة مشتريات";
			IncomingBillFrmBtn.UseVisualStyleBackColor = true;
			SupplierBtn.AutoSize = true;
			SupplierBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			SupplierBtn.Location = new System.Drawing.Point(464, 16);
			SupplierBtn.Name = "SupplierBtn";
			SupplierBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			SupplierBtn.Size = new System.Drawing.Size(79, 23);
			SupplierBtn.TabIndex = 11;
			SupplierBtn.Text = "الموردين";
			SupplierBtn.UseVisualStyleBackColor = true;
			PermissionCh.AutoSize = true;
			PermissionCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PermissionCh.Location = new System.Drawing.Point(642, 220);
			PermissionCh.Name = "PermissionCh";
			PermissionCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			PermissionCh.Size = new System.Drawing.Size(171, 23);
			PermissionCh.TabIndex = 10;
			PermissionCh.Text = "المستخدمين والصلاحيات";
			PermissionCh.UseVisualStyleBackColor = true;
			groupBox8.Controls.Add(FrmRptSpecialBtn);
			groupBox8.Controls.Add(FrmPatientInoculationBtn);
			groupBox8.Controls.Add(DoctorPatientListCh);
			groupBox8.Controls.Add(PrescriptionFrmBtn);
			groupBox8.Controls.Add(medicineFrmBtn);
			groupBox8.Controls.Add(DoctorReBackAppointmentch);
			groupBox8.Controls.Add(PatientSurgery);
			groupBox8.Controls.Add(DoctorVisits);
			groupBox8.Location = new System.Drawing.Point(381, 142);
			groupBox8.Name = "groupBox8";
			groupBox8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox8.Size = new System.Drawing.Size(549, 72);
			groupBox8.TabIndex = 7;
			groupBox8.TabStop = false;
			groupBox8.Text = "الطبيب";
			FrmRptSpecialBtn.AutoSize = true;
			FrmRptSpecialBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmRptSpecialBtn.Location = new System.Drawing.Point(17, 14);
			FrmRptSpecialBtn.Name = "FrmRptSpecialBtn";
			FrmRptSpecialBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmRptSpecialBtn.Size = new System.Drawing.Size(114, 23);
			FrmRptSpecialBtn.TabIndex = 28;
			FrmRptSpecialBtn.Text = "خطابات تحويل";
			FrmRptSpecialBtn.UseVisualStyleBackColor = true;
			FrmPatientInoculationBtn.AutoSize = true;
			FrmPatientInoculationBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmPatientInoculationBtn.Location = new System.Drawing.Point(17, 38);
			FrmPatientInoculationBtn.Name = "FrmPatientInoculationBtn";
			FrmPatientInoculationBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmPatientInoculationBtn.Size = new System.Drawing.Size(129, 23);
			FrmPatientInoculationBtn.TabIndex = 31;
			FrmPatientInoculationBtn.Text = "تطعيمات للمريض";
			FrmPatientInoculationBtn.UseVisualStyleBackColor = true;
			DoctorPatientListCh.AutoSize = true;
			DoctorPatientListCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			DoctorPatientListCh.Location = new System.Drawing.Point(394, 14);
			DoctorPatientListCh.Name = "DoctorPatientListCh";
			DoctorPatientListCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			DoctorPatientListCh.Size = new System.Drawing.Size(146, 23);
			DoctorPatientListCh.TabIndex = 20;
			DoctorPatientListCh.Text = "قائمة الكشف للطبيب";
			DoctorPatientListCh.UseVisualStyleBackColor = true;
			PrescriptionFrmBtn.AutoSize = true;
			PrescriptionFrmBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PrescriptionFrmBtn.Location = new System.Drawing.Point(304, 14);
			PrescriptionFrmBtn.Name = "PrescriptionFrmBtn";
			PrescriptionFrmBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			PrescriptionFrmBtn.Size = new System.Drawing.Size(84, 23);
			PrescriptionFrmBtn.TabIndex = 14;
			PrescriptionFrmBtn.Text = "الروشتات";
			PrescriptionFrmBtn.UseVisualStyleBackColor = true;
			medicineFrmBtn.AutoSize = true;
			medicineFrmBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			medicineFrmBtn.Location = new System.Drawing.Point(289, 38);
			medicineFrmBtn.Name = "medicineFrmBtn";
			medicineFrmBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			medicineFrmBtn.Size = new System.Drawing.Size(67, 23);
			medicineFrmBtn.TabIndex = 13;
			medicineFrmBtn.Text = "الأدوية";
			medicineFrmBtn.UseVisualStyleBackColor = true;
			DoctorReBackAppointmentch.AutoSize = true;
			DoctorReBackAppointmentch.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			DoctorReBackAppointmentch.Location = new System.Drawing.Point(358, 38);
			DoctorReBackAppointmentch.Name = "DoctorReBackAppointmentch";
			DoctorReBackAppointmentch.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			DoctorReBackAppointmentch.Size = new System.Drawing.Size(182, 23);
			DoctorReBackAppointmentch.TabIndex = 22;
			DoctorReBackAppointmentch.Text = "قائمة إعادة الكشف للطبيب";
			DoctorReBackAppointmentch.UseVisualStyleBackColor = true;
			PatientSurgery.AutoSize = true;
			PatientSurgery.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PatientSurgery.Location = new System.Drawing.Point(166, 38);
			PatientSurgery.Name = "PatientSurgery";
			PatientSurgery.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			PatientSurgery.Size = new System.Drawing.Size(123, 23);
			PatientSurgery.TabIndex = 29;
			PatientSurgery.Text = "عمليات المرضى";
			PatientSurgery.UseVisualStyleBackColor = true;
			DoctorVisits.AutoSize = true;
			DoctorVisits.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			DoctorVisits.Location = new System.Drawing.Point(130, 14);
			DoctorVisits.Name = "DoctorVisits";
			DoctorVisits.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			DoctorVisits.Size = new System.Drawing.Size(159, 23);
			DoctorVisits.TabIndex = 28;
			DoctorVisits.Text = "قائمة الزيارات للطبيب";
			DoctorVisits.UseVisualStyleBackColor = true;
			DentalDataCh.AutoSize = true;
			DentalDataCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			DentalDataCh.Location = new System.Drawing.Point(816, 220);
			DentalDataCh.Name = "DentalDataCh";
			DentalDataCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			DentalDataCh.Size = new System.Drawing.Size(108, 23);
			DentalDataCh.TabIndex = 11;
			DentalDataCh.Text = "بيانات العيادة";
			DentalDataCh.UseVisualStyleBackColor = true;
			groupBox5.Controls.Add(AddEmployeeCh);
			groupBox5.Location = new System.Drawing.Point(765, 11);
			groupBox5.Name = "groupBox5";
			groupBox5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox5.Size = new System.Drawing.Size(166, 49);
			groupBox5.TabIndex = 4;
			groupBox5.TabStop = false;
			groupBox5.Text = "الموظفين";
			AddEmployeeCh.AutoSize = true;
			AddEmployeeCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			AddEmployeeCh.Location = new System.Drawing.Point(51, 20);
			AddEmployeeCh.Name = "AddEmployeeCh";
			AddEmployeeCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			AddEmployeeCh.Size = new System.Drawing.Size(106, 23);
			AddEmployeeCh.TabIndex = 13;
			AddEmployeeCh.Text = "إضافة موظف";
			AddEmployeeCh.UseVisualStyleBackColor = true;
			groupBox9.Controls.Add(AppointmentspBtn);
			groupBox9.Controls.Add(FrmVisitMedicalRepBtn);
			groupBox9.Controls.Add(AppointmentCh);
			groupBox9.Controls.Add(RptVisits);
			groupBox9.Controls.Add(EditReBackDatech);
			groupBox9.Controls.Add(BookingVisits);
			groupBox9.Controls.Add(ChangeServicePrice);
			groupBox9.Controls.Add(FrmInoculationBtn);
			groupBox9.Controls.Add(SecretarPatientListCh);
			groupBox9.Controls.Add(ReBackAppointmentListch);
			groupBox9.Controls.Add(SecretaryVisits);
			groupBox9.Location = new System.Drawing.Point(8, 74);
			groupBox9.Name = "groupBox9";
			groupBox9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox9.Size = new System.Drawing.Size(922, 68);
			groupBox9.TabIndex = 6;
			groupBox9.TabStop = false;
			groupBox9.Text = "السكرتيرة";
			AppointmentspBtn.AutoSize = true;
			AppointmentspBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			AppointmentspBtn.Location = new System.Drawing.Point(156, 40);
			AppointmentspBtn.Name = "AppointmentspBtn";
			AppointmentspBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			AppointmentspBtn.Size = new System.Drawing.Size(108, 23);
			AppointmentspBtn.TabIndex = 29;
			AppointmentspBtn.Text = "الحجز السريع";
			AppointmentspBtn.UseVisualStyleBackColor = true;
			FrmVisitMedicalRepBtn.AutoSize = true;
			FrmVisitMedicalRepBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmVisitMedicalRepBtn.Location = new System.Drawing.Point(281, 40);
			FrmVisitMedicalRepBtn.Name = "FrmVisitMedicalRepBtn";
			FrmVisitMedicalRepBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmVisitMedicalRepBtn.Size = new System.Drawing.Size(159, 23);
			FrmVisitMedicalRepBtn.TabIndex = 28;
			FrmVisitMedicalRepBtn.Text = "زيارات الميديكال ريب";
			FrmVisitMedicalRepBtn.UseVisualStyleBackColor = true;
			AppointmentCh.AutoSize = true;
			AppointmentCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			AppointmentCh.Location = new System.Drawing.Point(779, 16);
			AppointmentCh.Name = "AppointmentCh";
			AppointmentCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			AppointmentCh.Size = new System.Drawing.Size(135, 23);
			AppointmentCh.TabIndex = 22;
			AppointmentCh.Text = "حجز كشف لمريض";
			AppointmentCh.UseVisualStyleBackColor = true;
			RptVisits.AutoSize = true;
			RptVisits.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			RptVisits.Location = new System.Drawing.Point(569, 40);
			RptVisits.Name = "RptVisits";
			RptVisits.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			RptVisits.Size = new System.Drawing.Size(157, 23);
			RptVisits.TabIndex = 27;
			RptVisits.Text = "تقرير متابعة الزيارات";
			RptVisits.UseVisualStyleBackColor = true;
			EditReBackDatech.AutoSize = true;
			EditReBackDatech.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			EditReBackDatech.Location = new System.Drawing.Point(597, 16);
			EditReBackDatech.Name = "EditReBackDatech";
			EditReBackDatech.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			EditReBackDatech.Size = new System.Drawing.Size(177, 23);
			EditReBackDatech.TabIndex = 23;
			EditReBackDatech.Text = "تعديل تاريخ إعادة الكشف";
			EditReBackDatech.UseVisualStyleBackColor = true;
			BookingVisits.AutoSize = true;
			BookingVisits.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			BookingVisits.Location = new System.Drawing.Point(68, 16);
			BookingVisits.Name = "BookingVisits";
			BookingVisits.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			BookingVisits.Size = new System.Drawing.Size(137, 23);
			BookingVisits.TabIndex = 25;
			BookingVisits.Text = "حجز زيارة لمريض";
			BookingVisits.UseVisualStyleBackColor = true;
			ChangeServicePrice.AutoSize = true;
			ChangeServicePrice.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			ChangeServicePrice.Location = new System.Drawing.Point(19, 40);
			ChangeServicePrice.Name = "ChangeServicePrice";
			ChangeServicePrice.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			ChangeServicePrice.Size = new System.Drawing.Size(131, 23);
			ChangeServicePrice.TabIndex = 24;
			ChangeServicePrice.Text = "تغيير سعر الخدمة";
			ChangeServicePrice.UseVisualStyleBackColor = true;
			FrmInoculationBtn.AutoSize = true;
			FrmInoculationBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmInoculationBtn.Location = new System.Drawing.Point(446, 40);
			FrmInoculationBtn.Name = "FrmInoculationBtn";
			FrmInoculationBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmInoculationBtn.Size = new System.Drawing.Size(120, 23);
			FrmInoculationBtn.TabIndex = 30;
			FrmInoculationBtn.Text = "إضافة تطعيمات";
			FrmInoculationBtn.UseVisualStyleBackColor = true;
			SecretarPatientListCh.AutoSize = true;
			SecretarPatientListCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			SecretarPatientListCh.Location = new System.Drawing.Point(422, 16);
			SecretarPatientListCh.Name = "SecretarPatientListCh";
			SecretarPatientListCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			SecretarPatientListCh.Size = new System.Drawing.Size(169, 23);
			SecretarPatientListCh.TabIndex = 21;
			SecretarPatientListCh.Text = "قائمة الكشف للسكرتارية";
			SecretarPatientListCh.UseVisualStyleBackColor = true;
			ReBackAppointmentListch.AutoSize = true;
			ReBackAppointmentListch.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			ReBackAppointmentListch.Location = new System.Drawing.Point(211, 16);
			ReBackAppointmentListch.Name = "ReBackAppointmentListch";
			ReBackAppointmentListch.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			ReBackAppointmentListch.Size = new System.Drawing.Size(205, 23);
			ReBackAppointmentListch.TabIndex = 23;
			ReBackAppointmentListch.Text = "قائمة إعادة الكشف للسكرتارية";
			ReBackAppointmentListch.UseVisualStyleBackColor = true;
			SecretaryVisits.AutoSize = true;
			SecretaryVisits.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			SecretaryVisits.Location = new System.Drawing.Point(731, 40);
			SecretaryVisits.Name = "SecretaryVisits";
			SecretaryVisits.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			SecretaryVisits.Size = new System.Drawing.Size(182, 23);
			SecretaryVisits.TabIndex = 26;
			SecretaryVisits.Text = "قائمة الزيارات للسكرتارية";
			SecretaryVisits.UseVisualStyleBackColor = true;
			groupBox6.Controls.Add(StockTransRptFrmBtn);
			groupBox6.Controls.Add(RptLoginUserBtn);
			groupBox6.Controls.Add(RptAssistantPaymentBtn);
			groupBox6.Controls.Add(AssistantAcountDate);
			groupBox6.Controls.Add(FrmRptCompanyAcountBtn);
			groupBox6.Controls.Add(FrmRptSurgeryBtn);
			groupBox6.Controls.Add(FrmBillBtn);
			groupBox6.Controls.Add(DoctorAccountCh);
			groupBox6.Controls.Add(FrmRptPatientDebtBtn);
			groupBox6.Controls.Add(MovepatStByDrRptCh);
			groupBox6.Controls.Add(FrmAssistantRptBtn);
			groupBox6.Controls.Add(FrmInventoryRptBtn);
			groupBox6.Controls.Add(BtnFrmRptCompanies_Services);
			groupBox6.Controls.Add(BtnFrmRptReb7ya);
			groupBox6.Controls.Add(FrmRptSahbItemBtn);
			groupBox6.Controls.Add(RptFrmSearchMedicine);
			groupBox6.Controls.Add(DailymeasureRotFrmBtn);
			groupBox6.Controls.Add(ClinicMonthGraphRptFrmBtn);
			groupBox6.Controls.Add(NetDailyClinicRptFrmBtn);
			groupBox6.Controls.Add(OldServicesRptFrmBtn);
			groupBox6.Controls.Add(RptDailyclinicch);
			groupBox6.Controls.Add(RptRevenuesch);
			groupBox6.Controls.Add(RptExpensesCh);
			groupBox6.Controls.Add(PatAccountRpt);
			groupBox6.Controls.Add(DoctorPaymentRptCh);
			groupBox6.Controls.Add(MovementOfPatStRptCh);
			groupBox6.Controls.Add(DoctorAccountRptCh);
			groupBox6.Controls.Add(AllPatientAccountRptCh);
			groupBox6.Location = new System.Drawing.Point(8, 243);
			groupBox6.Name = "groupBox6";
			groupBox6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox6.Size = new System.Drawing.Size(922, 159);
			groupBox6.TabIndex = 2;
			groupBox6.TabStop = false;
			groupBox6.Text = "التقارير";
			StockTransRptFrmBtn.AutoSize = true;
			StockTransRptFrmBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			StockTransRptFrmBtn.Location = new System.Drawing.Point(404, 134);
			StockTransRptFrmBtn.Name = "StockTransRptFrmBtn";
			StockTransRptFrmBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			StockTransRptFrmBtn.Size = new System.Drawing.Size(153, 23);
			StockTransRptFrmBtn.TabIndex = 31;
			StockTransRptFrmBtn.Text = "تقرير تحويلات خزائن";
			StockTransRptFrmBtn.UseVisualStyleBackColor = true;
			RptLoginUserBtn.AutoSize = true;
			RptLoginUserBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			RptLoginUserBtn.Location = new System.Drawing.Point(578, 134);
			RptLoginUserBtn.Name = "RptLoginUserBtn";
			RptLoginUserBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			RptLoginUserBtn.Size = new System.Drawing.Size(143, 23);
			RptLoginUserBtn.TabIndex = 30;
			RptLoginUserBtn.Text = "تقرير دخول مستخدم";
			RptLoginUserBtn.UseVisualStyleBackColor = true;
			RptAssistantPaymentBtn.AutoSize = true;
			RptAssistantPaymentBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			RptAssistantPaymentBtn.Location = new System.Drawing.Point(27, 134);
			RptAssistantPaymentBtn.Name = "RptAssistantPaymentBtn";
			RptAssistantPaymentBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			RptAssistantPaymentBtn.Size = new System.Drawing.Size(157, 23);
			RptAssistantPaymentBtn.TabIndex = 29;
			RptAssistantPaymentBtn.Text = "تقرير مدفوعات مساعد";
			RptAssistantPaymentBtn.UseVisualStyleBackColor = true;
			RptAssistantPaymentBtn.Visible = false;
			AssistantAcountDate.AutoSize = true;
			AssistantAcountDate.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			AssistantAcountDate.Location = new System.Drawing.Point(772, 134);
			AssistantAcountDate.Name = "AssistantAcountDate";
			AssistantAcountDate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			AssistantAcountDate.Size = new System.Drawing.Size(142, 23);
			AssistantAcountDate.TabIndex = 28;
			AssistantAcountDate.Text = "تقرير حساب مساعد";
			AssistantAcountDate.UseVisualStyleBackColor = true;
			FrmRptCompanyAcountBtn.AutoSize = true;
			FrmRptCompanyAcountBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmRptCompanyAcountBtn.Location = new System.Drawing.Point(47, 112);
			FrmRptCompanyAcountBtn.Name = "FrmRptCompanyAcountBtn";
			FrmRptCompanyAcountBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmRptCompanyAcountBtn.Size = new System.Drawing.Size(137, 23);
			FrmRptCompanyAcountBtn.TabIndex = 27;
			FrmRptCompanyAcountBtn.Text = "تقرير حساب شركة";
			FrmRptCompanyAcountBtn.UseVisualStyleBackColor = true;
			FrmRptSurgeryBtn.AutoSize = true;
			FrmRptSurgeryBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmRptSurgeryBtn.Location = new System.Drawing.Point(185, 112);
			FrmRptSurgeryBtn.Name = "FrmRptSurgeryBtn";
			FrmRptSurgeryBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmRptSurgeryBtn.Size = new System.Drawing.Size(158, 23);
			FrmRptSurgeryBtn.TabIndex = 26;
			FrmRptSurgeryBtn.Text = "تقرير اجمالى العمليات";
			FrmRptSurgeryBtn.UseVisualStyleBackColor = true;
			FrmBillBtn.AutoSize = true;
			FrmBillBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmBillBtn.Location = new System.Drawing.Point(48, 18);
			FrmBillBtn.Name = "FrmBillBtn";
			FrmBillBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmBillBtn.Size = new System.Drawing.Size(72, 23);
			FrmBillBtn.TabIndex = 25;
			FrmBillBtn.Text = "الفواتير";
			FrmBillBtn.UseVisualStyleBackColor = true;
			doctorAcountBtn.AutoSize = true;
			doctorAcountBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			doctorAcountBtn.Location = new System.Drawing.Point(34, 10);
			doctorAcountBtn.Name = "doctorAcountBtn";
			doctorAcountBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			doctorAcountBtn.Size = new System.Drawing.Size(120, 23);
			doctorAcountBtn.TabIndex = 24;
			doctorAcountBtn.Text = "حسابات الأطباء";
			doctorAcountBtn.UseVisualStyleBackColor = true;
			FrmRptPatientDebtBtn.AutoSize = true;
			FrmRptPatientDebtBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmRptPatientDebtBtn.Location = new System.Drawing.Point(15, 89);
			FrmRptPatientDebtBtn.Name = "FrmRptPatientDebtBtn";
			FrmRptPatientDebtBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmRptPatientDebtBtn.Size = new System.Drawing.Size(169, 23);
			FrmRptPatientDebtBtn.TabIndex = 23;
			FrmRptPatientDebtBtn.Text = "تقرير مديونيات المرضى";
			FrmRptPatientDebtBtn.UseVisualStyleBackColor = true;
			FrmAssistantRptBtn.AutoSize = true;
			FrmAssistantRptBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmAssistantRptBtn.Location = new System.Drawing.Point(389, 112);
			FrmAssistantRptBtn.Name = "FrmAssistantRptBtn";
			FrmAssistantRptBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmAssistantRptBtn.Size = new System.Drawing.Size(168, 23);
			FrmAssistantRptBtn.TabIndex = 22;
			FrmAssistantRptBtn.Text = "تقرير خدمات المساعدين";
			FrmAssistantRptBtn.UseVisualStyleBackColor = true;
			FrmInventoryRptBtn.AutoSize = true;
			FrmInventoryRptBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmInventoryRptBtn.Location = new System.Drawing.Point(781, 112);
			FrmInventoryRptBtn.Name = "FrmInventoryRptBtn";
			FrmInventoryRptBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmInventoryRptBtn.Size = new System.Drawing.Size(133, 23);
			FrmInventoryRptBtn.TabIndex = 21;
			FrmInventoryRptBtn.Text = "تقرير جرد للمخزن";
			FrmInventoryRptBtn.UseVisualStyleBackColor = true;
			BtnFrmRptCompanies_Services.AutoSize = true;
			BtnFrmRptCompanies_Services.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			BtnFrmRptCompanies_Services.Location = new System.Drawing.Point(34, 66);
			BtnFrmRptCompanies_Services.Name = "BtnFrmRptCompanies_Services";
			BtnFrmRptCompanies_Services.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			BtnFrmRptCompanies_Services.Size = new System.Drawing.Size(150, 23);
			BtnFrmRptCompanies_Services.TabIndex = 20;
			BtnFrmRptCompanies_Services.Text = "تقرير خدمات شركات";
			BtnFrmRptCompanies_Services.UseVisualStyleBackColor = true;
			BtnFrmRptReb7ya.AutoSize = true;
			BtnFrmRptReb7ya.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			BtnFrmRptReb7ya.Location = new System.Drawing.Point(236, 89);
			BtnFrmRptReb7ya.Name = "BtnFrmRptReb7ya";
			BtnFrmRptReb7ya.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			BtnFrmRptReb7ya.Size = new System.Drawing.Size(107, 23);
			BtnFrmRptReb7ya.TabIndex = 19;
			BtnFrmRptReb7ya.Text = "تقرير الربحية";
			BtnFrmRptReb7ya.UseVisualStyleBackColor = true;
			FrmRptSahbItemBtn.AutoSize = true;
			FrmRptSahbItemBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmRptSahbItemBtn.Location = new System.Drawing.Point(365, 19);
			FrmRptSahbItemBtn.Name = "FrmRptSahbItemBtn";
			FrmRptSahbItemBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmRptSahbItemBtn.Size = new System.Drawing.Size(192, 23);
			FrmRptSahbItemBtn.TabIndex = 18;
			FrmRptSahbItemBtn.Text = "تقرير سحب كميات الاصناف";
			FrmRptSahbItemBtn.UseVisualStyleBackColor = true;
			RptFrmSearchMedicine.AutoSize = true;
			RptFrmSearchMedicine.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			RptFrmSearchMedicine.Location = new System.Drawing.Point(138, 40);
			RptFrmSearchMedicine.Name = "RptFrmSearchMedicine";
			RptFrmSearchMedicine.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			RptFrmSearchMedicine.Size = new System.Drawing.Size(205, 23);
			RptFrmSearchMedicine.TabIndex = 17;
			RptFrmSearchMedicine.Text = "تقرير عدد الدواء فى الروشتات";
			RptFrmSearchMedicine.UseVisualStyleBackColor = true;
			DailymeasureRotFrmBtn.AutoSize = true;
			DailymeasureRotFrmBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			DailymeasureRotFrmBtn.Location = new System.Drawing.Point(568, 42);
			DailymeasureRotFrmBtn.Name = "DailymeasureRotFrmBtn";
			DailymeasureRotFrmBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			DailymeasureRotFrmBtn.Size = new System.Drawing.Size(153, 23);
			DailymeasureRotFrmBtn.TabIndex = 16;
			DailymeasureRotFrmBtn.Text = "مقارنة التقرير اليومي";
			DailymeasureRotFrmBtn.UseVisualStyleBackColor = true;
			ClinicMonthGraphRptFrmBtn.AutoSize = true;
			ClinicMonthGraphRptFrmBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			ClinicMonthGraphRptFrmBtn.Location = new System.Drawing.Point(603, 66);
			ClinicMonthGraphRptFrmBtn.Name = "ClinicMonthGraphRptFrmBtn";
			ClinicMonthGraphRptFrmBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			ClinicMonthGraphRptFrmBtn.Size = new System.Drawing.Size(118, 23);
			ClinicMonthGraphRptFrmBtn.TabIndex = 15;
			ClinicMonthGraphRptFrmBtn.Text = "التقرير الشهري";
			ClinicMonthGraphRptFrmBtn.UseVisualStyleBackColor = true;
			NetDailyClinicRptFrmBtn.AutoSize = true;
			NetDailyClinicRptFrmBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			NetDailyClinicRptFrmBtn.Location = new System.Drawing.Point(738, 66);
			NetDailyClinicRptFrmBtn.Name = "NetDailyClinicRptFrmBtn";
			NetDailyClinicRptFrmBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			NetDailyClinicRptFrmBtn.Size = new System.Drawing.Size(177, 23);
			NetDailyClinicRptFrmBtn.TabIndex = 14;
			NetDailyClinicRptFrmBtn.Text = "تقرير صافي يومية العيادة";
			NetDailyClinicRptFrmBtn.UseVisualStyleBackColor = true;
			OldServicesRptFrmBtn.AutoSize = true;
			OldServicesRptFrmBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			OldServicesRptFrmBtn.Location = new System.Drawing.Point(198, 66);
			OldServicesRptFrmBtn.Name = "OldServicesRptFrmBtn";
			OldServicesRptFrmBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			OldServicesRptFrmBtn.Size = new System.Drawing.Size(145, 23);
			OldServicesRptFrmBtn.TabIndex = 13;
			OldServicesRptFrmBtn.Text = "تقرير خدمات مريض";
			OldServicesRptFrmBtn.UseVisualStyleBackColor = true;
			RptDailyclinicch.AutoSize = true;
			RptDailyclinicch.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			RptDailyclinicch.Location = new System.Drawing.Point(583, 89);
			RptDailyclinicch.Name = "RptDailyclinicch";
			RptDailyclinicch.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			RptDailyclinicch.Size = new System.Drawing.Size(138, 23);
			RptDailyclinicch.TabIndex = 12;
			RptDailyclinicch.Text = "تقرير يومية العيادة";
			RptDailyclinicch.UseVisualStyleBackColor = true;
			RptRevenuesch.AutoSize = true;
			RptRevenuesch.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			RptRevenuesch.Location = new System.Drawing.Point(474, 89);
			RptRevenuesch.Name = "RptRevenuesch";
			RptRevenuesch.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			RptRevenuesch.Size = new System.Drawing.Size(83, 23);
			RptRevenuesch.TabIndex = 11;
			RptRevenuesch.Text = "الإيرادات";
			RptRevenuesch.UseVisualStyleBackColor = true;
			RptExpensesCh.AutoSize = true;
			RptExpensesCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			RptExpensesCh.Location = new System.Drawing.Point(820, 89);
			RptExpensesCh.Name = "RptExpensesCh";
			RptExpensesCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			RptExpensesCh.Size = new System.Drawing.Size(95, 23);
			RptExpensesCh.TabIndex = 10;
			RptExpensesCh.Text = "المصروفات";
			RptExpensesCh.UseVisualStyleBackColor = true;
			PatAccountRpt.AutoSize = true;
			PatAccountRpt.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PatAccountRpt.Location = new System.Drawing.Point(773, 19);
			PatAccountRpt.Name = "PatAccountRpt";
			PatAccountRpt.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			PatAccountRpt.Size = new System.Drawing.Size(142, 23);
			PatAccountRpt.TabIndex = 4;
			PatAccountRpt.Text = "تقرير حساب مريض";
			PatAccountRpt.UseVisualStyleBackColor = true;
			DoctorPaymentRptCh.AutoSize = true;
			DoctorPaymentRptCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			DoctorPaymentRptCh.Location = new System.Drawing.Point(405, 66);
			DoctorPaymentRptCh.Name = "DoctorPaymentRptCh";
			DoctorPaymentRptCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			DoctorPaymentRptCh.Size = new System.Drawing.Size(152, 23);
			DoctorPaymentRptCh.TabIndex = 9;
			DoctorPaymentRptCh.Text = "تقرير مدفوعات طبيب";
			DoctorPaymentRptCh.UseVisualStyleBackColor = true;
			MovementOfPatStRptCh.AutoSize = true;
			MovementOfPatStRptCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			MovementOfPatStRptCh.Location = new System.Drawing.Point(580, 18);
			MovementOfPatStRptCh.Name = "MovementOfPatStRptCh";
			MovementOfPatStRptCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			MovementOfPatStRptCh.Size = new System.Drawing.Size(141, 23);
			MovementOfPatStRptCh.TabIndex = 5;
			MovementOfPatStRptCh.Text = "كشف حساب مريض";
			MovementOfPatStRptCh.UseVisualStyleBackColor = true;
			DoctorAccountRptCh.AutoSize = true;
			DoctorAccountRptCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			DoctorAccountRptCh.Location = new System.Drawing.Point(420, 43);
			DoctorAccountRptCh.Name = "DoctorAccountRptCh";
			DoctorAccountRptCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			DoctorAccountRptCh.Size = new System.Drawing.Size(137, 23);
			DoctorAccountRptCh.TabIndex = 8;
			DoctorAccountRptCh.Text = "تقرير حساب طبيب";
			DoctorAccountRptCh.UseVisualStyleBackColor = true;
			MovepatStByDrRptCh.AutoSize = true;
			MovepatStByDrRptCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			MovepatStByDrRptCh.Location = new System.Drawing.Point(195, 11);
			MovepatStByDrRptCh.Name = "MovepatStByDrRptCh";
			MovepatStByDrRptCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			MovepatStByDrRptCh.Size = new System.Drawing.Size(147, 23);
			MovepatStByDrRptCh.TabIndex = 6;
			MovepatStByDrRptCh.Text = "تقرير كشوفات طبيب";
			MovepatStByDrRptCh.UseVisualStyleBackColor = true;
			AllPatientAccountRptCh.AutoSize = true;
			AllPatientAccountRptCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			AllPatientAccountRptCh.Location = new System.Drawing.Point(731, 43);
			AllPatientAccountRptCh.Name = "AllPatientAccountRptCh";
			AllPatientAccountRptCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			AllPatientAccountRptCh.Size = new System.Drawing.Size(184, 23);
			AllPatientAccountRptCh.TabIndex = 7;
			AllPatientAccountRptCh.Text = "تقرير حسابات كل المرضى";
			AllPatientAccountRptCh.UseVisualStyleBackColor = true;
			groupBox4.Controls.Add(PatientServiceUpdateBtn);
			groupBox4.Controls.Add(PatientAccountUpdateBtn);
			groupBox4.Controls.Add(Surgery);
			groupBox4.Controls.Add(FrmFilePatientBtn);
			groupBox4.Controls.Add(MainComplaintBtn);
			groupBox4.Controls.Add(AddPatientCh);
			groupBox4.Controls.Add(SearchPatientCh);
			groupBox4.Controls.Add(CompanyCh);
			groupBox4.Controls.Add(PatientPayCh);
			groupBox4.Controls.Add(PatientAccountCh);
			groupBox4.Controls.Add(PatientXray);
			groupBox4.Location = new System.Drawing.Point(-15, 7);
			groupBox4.Name = "groupBox4";
			groupBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox4.Size = new System.Drawing.Size(774, 67);
			groupBox4.TabIndex = 5;
			groupBox4.TabStop = false;
			groupBox4.Text = "المرضى";
			PatientServiceUpdateBtn.AutoSize = true;
			PatientServiceUpdateBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PatientServiceUpdateBtn.Location = new System.Drawing.Point(233, 38);
			PatientServiceUpdateBtn.Name = "PatientServiceUpdateBtn";
			PatientServiceUpdateBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			PatientServiceUpdateBtn.Size = new System.Drawing.Size(157, 23);
			PatientServiceUpdateBtn.TabIndex = 25;
			PatientServiceUpdateBtn.Text = "تعديل خدمات المرضى";
			PatientServiceUpdateBtn.UseVisualStyleBackColor = true;
			PatientAccountUpdateBtn.AutoSize = true;
			PatientAccountUpdateBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PatientAccountUpdateBtn.Location = new System.Drawing.Point(51, 38);
			PatientAccountUpdateBtn.Name = "PatientAccountUpdateBtn";
			PatientAccountUpdateBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			PatientAccountUpdateBtn.Size = new System.Drawing.Size(169, 23);
			PatientAccountUpdateBtn.TabIndex = 24;
			PatientAccountUpdateBtn.Text = "تعديل مدفوعات المرضى";
			PatientAccountUpdateBtn.UseVisualStyleBackColor = true;
			Surgery.AutoSize = true;
			Surgery.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Surgery.Location = new System.Drawing.Point(396, 38);
			Surgery.Name = "Surgery";
			Surgery.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			Surgery.Size = new System.Drawing.Size(111, 23);
			Surgery.TabIndex = 23;
			Surgery.Text = "قائمة العمليات";
			Surgery.UseVisualStyleBackColor = true;
			FrmFilePatientBtn.AutoSize = true;
			FrmFilePatientBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FrmFilePatientBtn.Location = new System.Drawing.Point(660, 38);
			FrmFilePatientBtn.Name = "FrmFilePatientBtn";
			FrmFilePatientBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			FrmFilePatientBtn.Size = new System.Drawing.Size(103, 23);
			FrmFilePatientBtn.TabIndex = 22;
			FrmFilePatientBtn.Text = "ملف المريض";
			FrmFilePatientBtn.UseVisualStyleBackColor = true;
			MainComplaintBtn.AutoSize = true;
			MainComplaintBtn.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			MainComplaintBtn.Location = new System.Drawing.Point(48, 12);
			MainComplaintBtn.Name = "MainComplaintBtn";
			MainComplaintBtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			MainComplaintBtn.Size = new System.Drawing.Size(126, 23);
			MainComplaintBtn.TabIndex = 21;
			MainComplaintBtn.Text = "الشكوى الرئيسية";
			MainComplaintBtn.UseVisualStyleBackColor = true;
			AddPatientCh.AutoSize = true;
			AddPatientCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			AddPatientCh.Location = new System.Drawing.Point(659, 12);
			AddPatientCh.Name = "AddPatientCh";
			AddPatientCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			AddPatientCh.Size = new System.Drawing.Size(106, 23);
			AddPatientCh.TabIndex = 14;
			AddPatientCh.Text = "إضافة مريض";
			AddPatientCh.UseVisualStyleBackColor = true;
			SearchPatientCh.AutoSize = true;
			SearchPatientCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			SearchPatientCh.Location = new System.Drawing.Point(520, 12);
			SearchPatientCh.Name = "SearchPatientCh";
			SearchPatientCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			SearchPatientCh.Size = new System.Drawing.Size(128, 23);
			SearchPatientCh.TabIndex = 15;
			SearchPatientCh.Text = "البحث عن مريض";
			SearchPatientCh.UseVisualStyleBackColor = true;
			CompanyCh.AutoSize = true;
			CompanyCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			CompanyCh.Location = new System.Drawing.Point(428, 12);
			CompanyCh.Name = "CompanyCh";
			CompanyCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			CompanyCh.Size = new System.Drawing.Size(79, 23);
			CompanyCh.TabIndex = 16;
			CompanyCh.Text = "الشركات";
			CompanyCh.UseVisualStyleBackColor = true;
			PatientPayCh.AutoSize = true;
			PatientPayCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PatientPayCh.Location = new System.Drawing.Point(289, 12);
			PatientPayCh.Name = "PatientPayCh";
			PatientPayCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			PatientPayCh.Size = new System.Drawing.Size(132, 23);
			PatientPayCh.TabIndex = 17;
			PatientPayCh.Text = "مدفوعات المرضي";
			PatientPayCh.UseVisualStyleBackColor = true;
			PatientAccountCh.AutoSize = true;
			PatientAccountCh.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PatientAccountCh.Location = new System.Drawing.Point(182, 12);
			PatientAccountCh.Name = "PatientAccountCh";
			PatientAccountCh.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			PatientAccountCh.Size = new System.Drawing.Size(94, 23);
			PatientAccountCh.TabIndex = 18;
			PatientAccountCh.Text = "كشف سريع";
			PatientAccountCh.UseVisualStyleBackColor = true;
			PatientXray.AutoSize = true;
			PatientXray.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PatientXray.Location = new System.Drawing.Point(509, 38);
			PatientXray.Name = "PatientXray";
			PatientXray.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			PatientXray.Size = new System.Drawing.Size(139, 23);
			PatientXray.TabIndex = 19;
			PatientXray.Text = "أشعة إكس للمرضى";
			PatientXray.UseVisualStyleBackColor = true;
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(DeleteUserBtn);
			groupBox1.Controls.Add(UpdateUserBtn);
			groupBox1.Controls.Add(AddUserBtn);
			groupBox1.Location = new System.Drawing.Point(463, 580);
			groupBox1.Name = "groupBox1";
			groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox1.Size = new System.Drawing.Size(439, 53);
			groupBox1.TabIndex = 8;
			groupBox1.TabStop = false;
			DeleteUserBtn.BackColor = System.Drawing.Color.Transparent;
			DeleteUserBtn.Font = new System.Drawing.Font("Arial", 10f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			DeleteUserBtn.Location = new System.Drawing.Point(10, 15);
			DeleteUserBtn.Name = "DeleteUserBtn";
			DeleteUserBtn.Size = new System.Drawing.Size(131, 32);
			DeleteUserBtn.TabIndex = 6;
			DeleteUserBtn.Text = "حذف مستخدم";
			DeleteUserBtn.UseVisualStyleBackColor = false;
			DeleteUserBtn.Click += new System.EventHandler(DeleteUserBtn_Click);
			UpdateUserBtn.BackColor = System.Drawing.Color.Transparent;
			UpdateUserBtn.Font = new System.Drawing.Font("Arial", 10f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			UpdateUserBtn.Location = new System.Drawing.Point(154, 15);
			UpdateUserBtn.Name = "UpdateUserBtn";
			UpdateUserBtn.Size = new System.Drawing.Size(131, 32);
			UpdateUserBtn.TabIndex = 7;
			UpdateUserBtn.Text = "تعديل مستخدم";
			UpdateUserBtn.UseVisualStyleBackColor = false;
			UpdateUserBtn.Click += new System.EventHandler(UpdateUserBtn_Click);
			AddUserBtn.BackColor = System.Drawing.Color.Transparent;
			AddUserBtn.Font = new System.Drawing.Font("Arial", 10f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			AddUserBtn.Location = new System.Drawing.Point(296, 15);
			AddUserBtn.Name = "AddUserBtn";
			AddUserBtn.Size = new System.Drawing.Size(131, 32);
			AddUserBtn.TabIndex = 8;
			AddUserBtn.Text = "إضافة مستخدم";
			AddUserBtn.UseVisualStyleBackColor = false;
			AddUserBtn.Click += new System.EventHandler(AddUserBtn_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.SlateGray;
			base.ClientSize = new System.Drawing.Size(1161, 639);
			base.Controls.Add(userslistbox);
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.Name = "fmusers";
			Text = "                                                                                                                                                                                  ";
			base.Load += new System.EventHandler(fmusers_Load);
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox10.ResumeLayout(false);
			groupBox10.PerformLayout();
			groupBox11.ResumeLayout(false);
			groupBox11.PerformLayout();
			groupBox8.ResumeLayout(false);
			groupBox8.PerformLayout();
			groupBox5.ResumeLayout(false);
			groupBox5.PerformLayout();
			groupBox9.ResumeLayout(false);
			groupBox9.PerformLayout();
			groupBox6.ResumeLayout(false);
			groupBox6.PerformLayout();
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			groupBox1.ResumeLayout(false);
			ResumeLayout(false);
		}

		public fmusers()
		{
			try
			{
				InitializeComponent();
				dc = new ClassDataBase(".\\sqlExpress");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "حدث خطأ");
			}
		}

		public void refreshlistbox()
		{
			try
			{
				DataTable tableText = dc.GetTableText("select userName from users");
				userslistbox.DataSource = tableText;
				userslistbox.DisplayMember = tableText.Columns["UserName"].ToString();
				userslistbox.ValueMember = tableText.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void adduser_Click(object sender, EventArgs e)
		{
		}

		private void fmusers_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = dc.GetTableText("select * from Empdata");
				EmpCombo.DataSource = tableText;
				EmpCombo.DisplayMember = tableText.Columns["Name"].ToString();
				EmpCombo.ValueMember = tableText.Columns["ID"].ToString();
			}
			catch
			{
			}
			refreshlistbox();
		}

		private void userslistbox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				if (userslistbox.SelectedItem != null)
				{
					DataTable tableText = dc.GetTableText("select * from users where userName='" + userslistbox.SelectedValue.ToString() + "'");
					userId = Convert.ToInt32(tableText.Rows[0]["userId"].ToString());
					usernameTextBox.Text = tableText.Rows[0]["userName"].ToString();
					userPasswardTextBox.Text = tableText.Rows[0]["userPassward"].ToString();
					AddEmployeeCh.Checked = Convert.ToBoolean(tableText.Rows[0]["AddEmployee"].ToString());
					AddPatientCh.Checked = Convert.ToBoolean(tableText.Rows[0]["AddPatient"].ToString());
					AppointmentCh.Checked = Convert.ToBoolean(tableText.Rows[0]["Appointment"].ToString());
					DoctorPatientListCh.Checked = Convert.ToBoolean(tableText.Rows[0]["DoctorPatientList"].ToString());
					SecretarPatientListCh.Checked = Convert.ToBoolean(tableText.Rows[0]["SecretaryPatientList"].ToString());
					DentalDataCh.Checked = Convert.ToBoolean(tableText.Rows[0]["DentalData"].ToString());
					DoctorAccountCh.Checked = Convert.ToBoolean(tableText.Rows[0]["DoctorAccount"].ToString());
					SearchPatientCh.Checked = Convert.ToBoolean(tableText.Rows[0]["SearchPatient"].ToString());
					CompanyCh.Checked = Convert.ToBoolean(tableText.Rows[0]["Company"].ToString());
					PatientPayCh.Checked = Convert.ToBoolean(tableText.Rows[0]["PatientPay"].ToString());
					PatientAccountCh.Checked = Convert.ToBoolean(tableText.Rows[0]["PatientAccount"].ToString());
					PatientXray.Checked = Convert.ToBoolean(tableText.Rows[0]["PatientXray"].ToString());
					PermissionCh.Checked = Convert.ToBoolean(tableText.Rows[0]["Permission"].ToString());
					PatAccountRpt.Checked = Convert.ToBoolean(tableText.Rows[0]["PatAccountRpt"].ToString());
					AllPatientAccountRptCh.Checked = Convert.ToBoolean(tableText.Rows[0]["AllPatAccountRpt"].ToString());
					DoctorAccountRptCh.Checked = Convert.ToBoolean(tableText.Rows[0]["DoctorAccountRpt"].ToString());
					DoctorPaymentRptCh.Checked = Convert.ToBoolean(tableText.Rows[0]["DoctorPaymentRpt"].ToString());
					MovementOfPatStRptCh.Checked = Convert.ToBoolean(tableText.Rows[0]["MovOfPatSTrpt"].ToString());
					MovepatStByDrRptCh.Checked = Convert.ToBoolean(tableText.Rows[0]["MovOfPatStbyDr"].ToString());
					RptFrmSearchMedicine.Checked = Convert.ToBoolean(tableText.Rows[0]["RptFrmSearchMedicine"].ToString());
					Expensesch.Checked = Convert.ToBoolean(tableText.Rows[0]["Expenses"].ToString());
					RevenuesCh.Checked = Convert.ToBoolean(tableText.Rows[0]["Revenues"].ToString());
					RptExpensesCh.Checked = Convert.ToBoolean(tableText.Rows[0]["RptExpenses"].ToString());
					RptRevenuesch.Checked = Convert.ToBoolean(tableText.Rows[0]["RptRevenues"].ToString());
					RptDailyclinicch.Checked = Convert.ToBoolean(tableText.Rows[0]["RptStockMove"].ToString());
					DoctorReBackAppointmentch.Checked = Convert.ToBoolean(tableText.Rows[0]["DoctorBackReserve"].ToString());
					ReBackAppointmentListch.Checked = Convert.ToBoolean(tableText.Rows[0]["SecretaryBackReserve"].ToString());
					EditReBackDatech.Checked = Convert.ToBoolean(tableText.Rows[0]["UpdateRebackdate"].ToString());
					medicineFrmBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["medicineFrmBtn"].ToString());
					PrescriptionFrmBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["PrescriptionFrmBtn"].ToString());
					ItemsFrmBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["ItemsFrmBtn"].ToString());
					SupplierBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["SupplierBtn"].ToString());
					IncomingBillFrmBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["IncomingBillFrmBtn"].ToString());
					FrmSupplierAccountsBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmSupplierAccountsBtn"].ToString());
					FormSupplier5Btn.Checked = Convert.ToBoolean(tableText.Rows[0]["FormSupplier5Btn"].ToString());
					FrmBillIncomeRptBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmBillIncomeRptBtn"].ToString());
					OldServicesRptFrmBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["OldServicesRptFrmBtn"].ToString());
					NetDailyClinicRptFrmBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["NetDailyClinicRptFrmBtn"].ToString());
					ClinicMonthGraphRptFrmBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["ClinicMonthGraphRptFrmBtn"].ToString());
					DailymeasureRotFrmBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["DailymeasureRotFrmBtn"].ToString());
					ServicePatientBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["ServicePatientBtn"].ToString());
					MainComplaintBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["MainComplaintBtn"].ToString());
					SahbItemsBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["SahbItemsBtn"].ToString());
					FrmRptSahbItemBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmRptSahbItemBtn"].ToString());
					FrmRptBillByDateBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmRptBillByDateBtn"].ToString());
					FrmFilePatientBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmFilePatientBtn"].ToString());
					FrmPropertiesBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmPropertiesBtn"].ToString());
					ChangeServicePrice.Checked = Convert.ToBoolean(tableText.Rows[0]["ChangeServicePrice"].ToString());
					btnBackup_Restore.Checked = Convert.ToBoolean(tableText.Rows[0]["btnBackup_Restore"].ToString());
					Surgery.Checked = Convert.ToBoolean(tableText.Rows[0]["Surgery"].ToString());
					BookingVisits.Checked = Convert.ToBoolean(tableText.Rows[0]["BookingVisits"].ToString());
					RptVisits.Checked = Convert.ToBoolean(tableText.Rows[0]["RptVisits"].ToString());
					SecretaryVisits.Checked = Convert.ToBoolean(tableText.Rows[0]["SecretaryVisits"].ToString());
					DoctorVisits.Checked = Convert.ToBoolean(tableText.Rows[0]["DoctorVisits"].ToString());
					PatientSurgery.Checked = Convert.ToBoolean(tableText.Rows[0]["PatientSurgery"].ToString());
					BtnFrmRptReb7ya.Checked = Convert.ToBoolean(tableText.Rows[0]["BtnFrmRptReb7ya"].ToString());
					BtnFrmRptCompanies_Services.Checked = Convert.ToBoolean(tableText.Rows[0]["BtnFrmRptCompanies_Services"].ToString());
					BtnFrmSell.Checked = Convert.ToBoolean(tableText.Rows[0]["BtnFrmSell"].ToString());
					FrmRptSellByDateBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmRptSellByDateBtn"].ToString());
					PatientAccountUpdateBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["PatientAccountUpdateBtn"].ToString());
					PatientServiceUpdateBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["PatientServiceUpdateBtn"].ToString());
					FrmInventoryRptBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmInventoryRptBtn"].ToString());
					FrmLimitOrderRptBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmLimitOrderRptBtn"].ToString());
					FrmInoculationBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmInoculationBtn"].ToString());
					FrmPatientInoculationBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmPatientInoculationBtn"].ToString());
					FrmAssistantRptBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmAssistantRptBtn"].ToString());
					FrmRptPatientDebtBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmRptPatientDebtBtn"].ToString());
					doctorAcountBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["doctorAcountBtn"].ToString());
					FrmBillBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmBillBtn"].ToString());
					FrmVisitMedicalRepBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmVisitMedicalRepBtn"].ToString());
					AppointmentspBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["AppointmentspBtn"].ToString());
					FrmRptSurgeryBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmRptSurgeryBtn"].ToString());
					FrmRptSpecialBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmRptSpecialBtn"].ToString());
					CompanyPayBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["CompanyPayBtn"].ToString());
					FrmRptCompanyAcountBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmRptCompanyAcountBtn"].ToString());
					AssistantAccountBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["AssistantAccountBtn"].ToString());
					AssistantAcountDate.Checked = Convert.ToBoolean(tableText.Rows[0]["AssistantAcountDate"].ToString());
					RptAssistantPaymentBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["RptAssistantPaymentBtn"].ToString());
					RptLoginUserBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["RptLoginUserBtn"].ToString());
					StockFrmBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["StockFrmBtn"].ToString());
					StockUsersFrmBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["StockUsersFrmBtn"].ToString());
					FrmTarnsbetweenStockBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmTarnsbetweenStockBtn"].ToString());
					StockTransRptFrmBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["StockTransRptFrmBtn"].ToString());
					FrmDeanSupplierBtn.Checked = Convert.ToBoolean(tableText.Rows[0]["FrmDeanSupplierBtn"].ToString());
					updateSurgery.Checked = Convert.ToBoolean(tableText.Rows[0]["updateSurgery"].ToString());
					if (tableText.Rows[0]["userId"].ToString() == "1")
					{
						NetDailyClinicRptFrmBtn.Enabled = false;
						ClinicMonthGraphRptFrmBtn.Enabled = false;
						AddEmployeeCh.Enabled = false;
						AddPatientCh.Enabled = false;
						AppointmentCh.Enabled = false;
						DoctorPatientListCh.Enabled = false;
						SecretarPatientListCh.Enabled = false;
						DentalDataCh.Enabled = false;
						DoctorAccountCh.Enabled = false;
						SearchPatientCh.Enabled = false;
						CompanyCh.Enabled = false;
						PatientPayCh.Enabled = false;
						PatientAccountCh.Enabled = false;
						PatientXray.Enabled = false;
						PermissionCh.Enabled = false;
						PatAccountRpt.Enabled = false;
						AllPatientAccountRptCh.Enabled = false;
						DoctorAccountRptCh.Enabled = false;
						DoctorPaymentRptCh.Enabled = false;
						MovementOfPatStRptCh.Enabled = false;
						MovepatStByDrRptCh.Enabled = false;
						OldServicesRptFrmBtn.Enabled = false;
						Expensesch.Enabled = false;
						RevenuesCh.Enabled = false;
						RptExpensesCh.Enabled = false;
						RptRevenuesch.Enabled = false;
						RptDailyclinicch.Enabled = false;
						DoctorReBackAppointmentch.Enabled = false;
						ReBackAppointmentListch.Enabled = false;
						EditReBackDatech.Enabled = false;
						medicineFrmBtn.Enabled = false;
						PrescriptionFrmBtn.Enabled = false;
						ItemsFrmBtn.Enabled = false;
						SupplierBtn.Enabled = false;
						IncomingBillFrmBtn.Enabled = false;
						FrmSupplierAccountsBtn.Enabled = false;
						FormSupplier5Btn.Enabled = false;
						FrmBillIncomeRptBtn.Enabled = false;
						DailymeasureRotFrmBtn.Enabled = false;
						RptFrmSearchMedicine.Enabled = false;
						ServicePatientBtn.Enabled = false;
						MainComplaintBtn.Enabled = false;
						SahbItemsBtn.Enabled = false;
						FrmRptSahbItemBtn.Enabled = false;
						FrmRptBillByDateBtn.Enabled = false;
						FrmFilePatientBtn.Enabled = false;
						FrmPropertiesBtn.Enabled = false;
						ChangeServicePrice.Enabled = false;
						btnBackup_Restore.Enabled = false;
						Surgery.Enabled = false;
						BookingVisits.Enabled = false;
						RptVisits.Enabled = false;
						SecretaryVisits.Enabled = false;
						DoctorVisits.Enabled = false;
						PatientSurgery.Enabled = false;
						BtnFrmRptReb7ya.Enabled = false;
						BtnFrmRptCompanies_Services.Enabled = false;
						BtnFrmSell.Enabled = false;
						FrmRptSellByDateBtn.Enabled = false;
						PatientAccountUpdateBtn.Enabled = false;
						PatientServiceUpdateBtn.Enabled = false;
						FrmInventoryRptBtn.Enabled = false;
						FrmLimitOrderRptBtn.Enabled = false;
						FrmInoculationBtn.Enabled = false;
						FrmPatientInoculationBtn.Enabled = false;
						FrmAssistantRptBtn.Enabled = false;
						FrmRptPatientDebtBtn.Enabled = false;
						doctorAcountBtn.Enabled = false;
						FrmBillBtn.Enabled = false;
						FrmVisitMedicalRepBtn.Enabled = false;
						AppointmentspBtn.Enabled = false;
						FrmRptSurgeryBtn.Enabled = false;
						FrmRptSpecialBtn.Enabled = false;
						CompanyPayBtn.Enabled = false;
						FrmRptCompanyAcountBtn.Enabled = false;
						AssistantAccountBtn.Enabled = false;
						AssistantAcountDate.Enabled = false;
						RptAssistantPaymentBtn.Enabled = false;
						RptLoginUserBtn.Enabled = false;
						StockFrmBtn.Enabled = false;
						StockUsersFrmBtn.Enabled = false;
						FrmTarnsbetweenStockBtn.Enabled = false;
						StockTransRptFrmBtn.Enabled = false;
						FrmDeanSupplierBtn.Enabled = false;
						updateSurgery.Enabled = false;
					}
					else
					{
						NetDailyClinicRptFrmBtn.Enabled = true;
						ClinicMonthGraphRptFrmBtn.Enabled = true;
						AddEmployeeCh.Enabled = true;
						AddPatientCh.Enabled = true;
						AppointmentCh.Enabled = true;
						DoctorPatientListCh.Enabled = true;
						SecretarPatientListCh.Enabled = true;
						DentalDataCh.Enabled = true;
						DoctorAccountCh.Enabled = true;
						SearchPatientCh.Enabled = true;
						CompanyCh.Enabled = true;
						PatientPayCh.Enabled = true;
						PatientAccountCh.Enabled = true;
						PatientXray.Enabled = true;
						PermissionCh.Enabled = true;
						PatAccountRpt.Enabled = true;
						AllPatientAccountRptCh.Enabled = true;
						DoctorAccountRptCh.Enabled = true;
						DoctorPaymentRptCh.Enabled = true;
						MovementOfPatStRptCh.Enabled = true;
						MovepatStByDrRptCh.Enabled = true;
						Expensesch.Enabled = true;
						RevenuesCh.Enabled = true;
						RptExpensesCh.Enabled = true;
						RptRevenuesch.Enabled = true;
						RptDailyclinicch.Enabled = true;
						DoctorReBackAppointmentch.Enabled = true;
						ReBackAppointmentListch.Enabled = true;
						EditReBackDatech.Enabled = true;
						OldServicesRptFrmBtn.Enabled = true;
						medicineFrmBtn.Enabled = true;
						PrescriptionFrmBtn.Enabled = true;
						ItemsFrmBtn.Enabled = true;
						SupplierBtn.Enabled = true;
						IncomingBillFrmBtn.Enabled = true;
						FrmSupplierAccountsBtn.Enabled = true;
						FormSupplier5Btn.Enabled = true;
						FrmBillIncomeRptBtn.Enabled = true;
						DailymeasureRotFrmBtn.Enabled = true;
						RptFrmSearchMedicine.Enabled = true;
						ServicePatientBtn.Enabled = true;
						MainComplaintBtn.Enabled = true;
						SahbItemsBtn.Enabled = true;
						FrmRptSahbItemBtn.Enabled = true;
						FrmRptBillByDateBtn.Enabled = true;
						FrmFilePatientBtn.Enabled = true;
						FrmPropertiesBtn.Enabled = true;
						ChangeServicePrice.Enabled = true;
						btnBackup_Restore.Enabled = true;
						Surgery.Enabled = true;
						BookingVisits.Enabled = true;
						RptVisits.Enabled = true;
						SecretaryVisits.Enabled = true;
						DoctorVisits.Enabled = true;
						PatientSurgery.Enabled = true;
						BtnFrmRptReb7ya.Enabled = true;
						BtnFrmRptCompanies_Services.Enabled = true;
						BtnFrmSell.Enabled = true;
						FrmRptSellByDateBtn.Enabled = true;
						PatientAccountUpdateBtn.Enabled = true;
						PatientServiceUpdateBtn.Enabled = true;
						FrmInventoryRptBtn.Enabled = true;
						FrmLimitOrderRptBtn.Enabled = true;
						FrmInoculationBtn.Enabled = true;
						FrmPatientInoculationBtn.Enabled = true;
						FrmAssistantRptBtn.Enabled = true;
						FrmRptPatientDebtBtn.Enabled = true;
						doctorAcountBtn.Enabled = true;
						FrmBillBtn.Enabled = true;
						FrmVisitMedicalRepBtn.Enabled = true;
						AppointmentspBtn.Enabled = true;
						FrmRptSurgeryBtn.Enabled = true;
						FrmRptSpecialBtn.Enabled = true;
						CompanyPayBtn.Enabled = true;
						FrmRptCompanyAcountBtn.Enabled = true;
						AssistantAccountBtn.Enabled = true;
						AssistantAcountDate.Enabled = true;
						RptAssistantPaymentBtn.Enabled = true;
						RptLoginUserBtn.Enabled = true;
						StockFrmBtn.Enabled = true;
						StockUsersFrmBtn.Enabled = true;
						FrmTarnsbetweenStockBtn.Enabled = true;
						StockTransRptFrmBtn.Enabled = true;
						FrmDeanSupplierBtn.Enabled = true;
						updateSurgery.Enabled = true;
					}
				}
			}
			catch
			{
			}
		}

		private void AddUserBtn_Click(object sender, EventArgs e)
		{
			try
			{
				string[] fields = new string[88]
				{
					"EmpID", "userName", "userPassward", "AddEmployee", "AddPatient", "Appointment", "DoctorPatientList", "SecretaryPatientList", "DentalData", "DoctorAccount",
					"SearchPatient", "Company", "PatientPay", "PatientAccount", "PatientXray", "Permission", "PatAccountRpt", "ALLPatAccountRpt", "DoctorAccountRpt", "DoctorPaymentRpt",
					"MovOfPatSTrpt", "MovOfPatStbyDr", "Expenses", "Revenues", "RptExpenses", "RptRevenues", "RptStockMove", "DoctorBackReserve", "SecretaryBackReserve", "UpdateRebackdate",
					"medicineFrmBtn", "PrescriptionFrmBtn", "ItemsFrmBtn", "SupplierBtn", "IncomingBillFrmBtn", "FrmSupplierAccountsBtn", "FormSupplier5Btn", "FrmBillIncomeRptBtn", "OldServicesRptFrmBtn", "NetDailyClinicRptFrmBtn",
					"ClinicMonthGraphRptFrmBtn", "DailymeasureRotFrmBtn", "RptFrmSearchMedicine", "ServicePatientBtn", "MainComplaintBtn", "SahbItemsBtn", "FrmRptSahbItemBtn", "FrmRptBillByDateBtn", "FrmFilePatientBtn", "FrmPropertiesBtn",
					"ChangeServicePrice", "btnBackup_Restore", "Surgery", "BookingVisits", "RptVisits", "SecretaryVisits", "DoctorVisits", "PatientSurgery", "BtnFrmRptReb7ya", "BtnFrmRptCompanies_Services",
					"BtnFrmSell", "FrmRptSellByDateBtn", "PatientAccountUpdateBtn", "PatientServiceUpdateBtn", "FrmInventoryRptBtn", "FrmLimitOrderRptBtn", "FrmInoculationBtn", "FrmPatientInoculationBtn", "FrmAssistantRptBtn", "FrmRptPatientDebtBtn",
					"doctorAcountBtn", "FrmBillBtn", "FrmVisitMedicalRepBtn", "AppointmentspBtn", "FrmRptSurgeryBtn", "FrmRptSpecialBtn", "CompanyPayBtn", "FrmRptCompanyAcountBtn", "AssistantAccountBtn", "AssistantAcountDate",
					"RptAssistantPaymentBtn", "RptLoginUserBtn", "StockFrmBtn", "StockUsersFrmBtn", "FrmTarnsbetweenStockBtn", "StockTransRptFrmBtn", "FrmDeanSupplierBtn", "updateSurgery"
				};
				DataTable tableText = dc.GetTableText("select * from Empdata where Name='" + EmpCombo.Text + "'");
				if (tableText.Rows.Count > 0)
				{
					DataTable tableText2 = dc.GetTableText("select * from users where userName ='" + usernameTextBox.Text + "'");
					if (tableText2.Rows.Count == 0)
					{
						if (usernameTextBox.Text == "" || usernameTextBox.Text == string.Empty)
						{
							MessageBox.Show("من فضلك ادخل اسم المستخدم");
						}
						else if (userPasswardTextBox.Text == "" || userPasswardTextBox.Text == string.Empty)
						{
							MessageBox.Show("من فضلك ادخل كلمة المرور");
						}
						else if (dc.Insert("addUsers", fields, Convert.ToInt32(EmpCombo.SelectedValue.ToString()), usernameTextBox.Text, userPasswardTextBox.Text, AddEmployeeCh.Checked ? true : false, AddPatientCh.Checked ? true : false, AppointmentCh.Checked ? true : false, DoctorPatientListCh.Checked ? true : false, SecretarPatientListCh.Checked ? true : false, DentalDataCh.Checked ? true : false, DoctorAccountCh.Checked ? true : false, SearchPatientCh.Checked ? true : false, CompanyCh.Checked ? true : false, PatientPayCh.Checked ? true : false, PatientAccountCh.Checked ? true : false, PatientXray.Checked ? true : false, PermissionCh.Checked ? true : false, PatAccountRpt.Checked ? true : false, AllPatientAccountRptCh.Checked ? true : false, DoctorAccountRptCh.Checked ? true : false, DoctorPaymentRptCh.Checked ? true : false, MovementOfPatStRptCh.Checked ? true : false, MovepatStByDrRptCh.Checked ? true : false, Expensesch.Checked ? true : false, RevenuesCh.Checked ? true : false, RptExpensesCh.Checked ? true : false, RptRevenuesch.Checked ? true : false, RptDailyclinicch.Checked ? true : false, DoctorReBackAppointmentch.Checked ? true : false, ReBackAppointmentListch.Checked ? true : false, EditReBackDatech.Checked ? true : false, medicineFrmBtn.Checked ? true : false, PrescriptionFrmBtn.Checked ? true : false, ItemsFrmBtn.Checked ? true : false, SupplierBtn.Checked ? true : false, IncomingBillFrmBtn.Checked ? true : false, FrmSupplierAccountsBtn.Checked ? true : false, FormSupplier5Btn.Checked ? true : false, FrmBillIncomeRptBtn.Checked ? true : false, OldServicesRptFrmBtn.Checked ? true : false, NetDailyClinicRptFrmBtn.Checked ? true : false, ClinicMonthGraphRptFrmBtn.Checked ? true : false, DailymeasureRotFrmBtn.Checked ? true : false, RptFrmSearchMedicine.Checked ? true : false, ServicePatientBtn.Checked ? true : false, MainComplaintBtn.Checked ? true : false, SahbItemsBtn.Checked ? true : false, FrmRptSahbItemBtn.Checked ? true : false, FrmRptBillByDateBtn.Checked ? true : false, FrmFilePatientBtn.Checked ? true : false, FrmPropertiesBtn.Checked ? true : false, ChangeServicePrice.Checked ? true : false, btnBackup_Restore.Checked ? true : false, Surgery.Checked, BookingVisits.Checked, RptVisits.Checked, SecretaryVisits.Checked, DoctorVisits.Checked, PatientSurgery.Checked, BtnFrmRptReb7ya.Checked, BtnFrmRptCompanies_Services.Checked, BtnFrmSell.Checked, FrmRptSellByDateBtn.Checked, PatientAccountUpdateBtn.Checked, PatientServiceUpdateBtn.Checked, FrmInventoryRptBtn.Checked, FrmLimitOrderRptBtn.Checked, FrmInoculationBtn.Checked, FrmPatientInoculationBtn.Checked, FrmAssistantRptBtn.Checked, FrmRptPatientDebtBtn.Checked, doctorAcountBtn.Checked, FrmBillBtn.Checked, FrmVisitMedicalRepBtn.Checked, AppointmentspBtn.Checked, FrmRptSurgeryBtn.Checked, FrmRptSpecialBtn.Checked, CompanyPayBtn.Checked, FrmRptCompanyAcountBtn.Checked, AssistantAccountBtn.Checked, AssistantAcountDate.Checked, RptAssistantPaymentBtn.Checked, RptLoginUserBtn.Checked, StockFrmBtn.Checked, StockUsersFrmBtn.Checked, FrmTarnsbetweenStockBtn.Checked, StockTransRptFrmBtn.Checked, FrmDeanSupplierBtn.Checked, updateSurgery.Checked))
						{
							MessageBox.Show("تم حفظ البيانات بنجاح");
							refreshlistbox();
							NewUserBtn_Click(sender, e);
						}
						else
						{
							MessageBox.Show("حدث خطأ أثناء حفظ البيانات");
						}
					}
					else if (tableText2.Rows.Count > 0)
					{
						MessageBox.Show("هذا الإسم مسجل من قبل");
					}
				}
				else
				{
					MessageBox.Show("من فضلك اختر اسم موظف صحيح");
				}
			}
			catch
			{
			}
		}

		private void UpdateUserBtn_Click(object sender, EventArgs e)
		{
			try
			{
				string[] fields = new string[89]
				{
					"userId", "EmpID", "userName", "userPassward", "AddEmployee", "AddPatient", "Appointment", "DoctorPatientList", "SecretaryPatientList", "DentalData",
					"DoctorAccount", "SearchPatient", "Company", "PatientPay", "PatientAccount", "PatientXray", "Permission", "PatAccountRpt", "ALLPatAccountRpt", "DoctorAccountRpt",
					"DoctorPaymentRpt", "MovOfPatSTrpt", "MovOfPatStbyDr", "Expenses", "Revenues", "RptExpenses", "RptRevenues", "RptStockMove", "DoctorBackReserve", "SecretaryBackReserve",
					"UpdateRebackdate", "medicineFrmBtn", "PrescriptionFrmBtn", "ItemsFrmBtn", "SupplierBtn", "IncomingBillFrmBtn", "FrmSupplierAccountsBtn", "FormSupplier5Btn", "FrmBillIncomeRptBtn", "OldServicesRptFrmBtn",
					"NetDailyClinicRptFrmBtn", "ClinicMonthGraphRptFrmBtn", "DailymeasureRotFrmBtn", "RptFrmSearchMedicine", "ServicePatientBtn", "MainComplaintBtn", "SahbItemsBtn", "FrmRptSahbItemBtn", "FrmRptBillByDateBtn", "FrmFilePatientBtn",
					"FrmPropertiesBtn", "ChangeServicePrice", "btnBackup_Restore", "Surgery", "BookingVisits", "RptVisits", "SecretaryVisits", "DoctorVisits", "PatientSurgery", "BtnFrmRptReb7ya",
					"BtnFrmRptCompanies_Services", "BtnFrmSell", "FrmRptSellByDateBtn", "PatientAccountUpdateBtn", "PatientServiceUpdateBtn", "FrmInventoryRptBtn", "FrmLimitOrderRptBtn", "FrmInoculationBtn", "FrmPatientInoculationBtn", "FrmAssistantRptBtn",
					"FrmRptPatientDebtBtn", "doctorAcountBtn", "FrmBillBtn", "FrmVisitMedicalRepBtn", "AppointmentspBtn", "FrmRptSurgeryBtn", "FrmRptSpecialBtn", "CompanyPayBtn", "FrmRptCompanyAcountBtn", "AssistantAccountBtn",
					"AssistantAcountDate", "RptAssistantPaymentBtn", "RptLoginUserBtn", "StockFrmBtn", "StockUsersFrmBtn", "FrmTarnsbetweenStockBtn", "StockTransRptFrmBtn", "FrmDeanSupplierBtn", "updateSurgery"
				};
				DataTable tableText = dc.GetTableText("select * from users where userName ='" + usernameTextBox.Text + "' and userId <>'" + userId + "'");
				if (tableText.Rows.Count == 0)
				{
					if (dc.Update("updateuser", fields, userId, Convert.ToInt32(EmpCombo.SelectedValue.ToString()), usernameTextBox.Text, userPasswardTextBox.Text, AddEmployeeCh.Checked ? true : false, AddPatientCh.Checked ? true : false, AppointmentCh.Checked ? true : false, DoctorPatientListCh.Checked ? true : false, SecretarPatientListCh.Checked ? true : false, DentalDataCh.Checked ? true : false, DoctorAccountCh.Checked ? true : false, SearchPatientCh.Checked ? true : false, CompanyCh.Checked ? true : false, PatientPayCh.Checked ? true : false, PatientAccountCh.Checked ? true : false, PatientXray.Checked ? true : false, PermissionCh.Checked ? true : false, PatAccountRpt.Checked ? true : false, AllPatientAccountRptCh.Checked ? true : false, DoctorAccountRptCh.Checked ? true : false, DoctorPaymentRptCh.Checked ? true : false, MovementOfPatStRptCh.Checked ? true : false, MovepatStByDrRptCh.Checked ? true : false, Expensesch.Checked ? true : false, RevenuesCh.Checked ? true : false, RptExpensesCh.Checked ? true : false, RptRevenuesch.Checked ? true : false, RptDailyclinicch.Checked ? true : false, DoctorReBackAppointmentch.Checked ? true : false, ReBackAppointmentListch.Checked ? true : false, EditReBackDatech.Checked ? true : false, medicineFrmBtn.Checked ? true : false, PrescriptionFrmBtn.Checked ? true : false, ItemsFrmBtn.Checked ? true : false, SupplierBtn.Checked ? true : false, IncomingBillFrmBtn.Checked ? true : false, FrmSupplierAccountsBtn.Checked ? true : false, FormSupplier5Btn.Checked ? true : false, FrmBillIncomeRptBtn.Checked ? true : false, OldServicesRptFrmBtn.Checked ? true : false, NetDailyClinicRptFrmBtn.Checked ? true : false, ClinicMonthGraphRptFrmBtn.Checked ? true : false, DailymeasureRotFrmBtn.Checked ? true : false, RptFrmSearchMedicine.Checked ? true : false, ServicePatientBtn.Checked ? true : false, MainComplaintBtn.Checked ? true : false, SahbItemsBtn.Checked ? true : false, FrmRptSahbItemBtn.Checked ? true : false, FrmRptBillByDateBtn.Checked ? true : false, FrmFilePatientBtn.Checked ? true : false, FrmPropertiesBtn.Checked ? true : false, ChangeServicePrice.Checked ? true : false, btnBackup_Restore.Checked ? true : false, Surgery.Checked, BookingVisits.Checked, RptVisits.Checked, SecretaryVisits.Checked, DoctorVisits.Checked, PatientSurgery.Checked, BtnFrmRptReb7ya.Checked, BtnFrmRptCompanies_Services.Checked, BtnFrmSell.Checked, FrmRptSellByDateBtn.Checked, PatientAccountUpdateBtn.Checked, PatientServiceUpdateBtn.Checked, FrmInventoryRptBtn.Checked, FrmLimitOrderRptBtn.Checked, FrmInoculationBtn.Checked, FrmPatientInoculationBtn.Checked, FrmAssistantRptBtn.Checked, FrmRptPatientDebtBtn.Checked, doctorAcountBtn.Checked, FrmBillBtn.Checked, FrmVisitMedicalRepBtn.Checked, AppointmentspBtn.Checked, FrmRptSurgeryBtn.Checked, FrmRptSpecialBtn.Checked, CompanyPayBtn.Checked, FrmRptCompanyAcountBtn.Checked, AssistantAccountBtn.Checked, AssistantAcountDate.Checked, RptAssistantPaymentBtn.Checked, RptLoginUserBtn.Checked, StockFrmBtn.Checked, StockUsersFrmBtn.Checked, FrmTarnsbetweenStockBtn.Checked, StockTransRptFrmBtn.Checked, FrmDeanSupplierBtn.Checked, updateSurgery.Checked))
					{
						MessageBox.Show("تم تعديل البيانات بنجاح");
						refreshlistbox();
						NewUserBtn_Click(sender, e);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء تعديل البيانات");
					}
				}
				else if (tableText.Rows.Count > 0)
				{
					MessageBox.Show("لايمكنك التعديل بهذا الاسم");
				}
			}
			catch
			{
			}
		}

		private void DeleteUserBtn_Click(object sender, EventArgs e)
		{
			try
			{
				string[] fields = new string[1] { "userId" };
				if (userId == 1)
				{
					MessageBox.Show("لا تملك صلاحية حذف هذا المستخدم", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					return;
				}
				DialogResult dialogResult = MessageBox.Show("هل انت متأكد من حذف هذا المستخدم ؟", "", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
				if (dialogResult == DialogResult.OK)
				{
					if (dc.Delete("deleteuser", fields, userId))
					{
						MessageBox.Show("تم حذف المستخدم");
						refreshlistbox();
						NewUserBtn_Click(sender, e);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء الحذف");
					}
				}
				else
				{
					MessageBox.Show("تم إلغاء عملية الحذف");
				}
			}
			catch
			{
			}
		}

		private void NewUserBtn_Click(object sender, EventArgs e)
		{
			usernameTextBox.Text = "";
			userPasswardTextBox.Text = "";
			NetDailyClinicRptFrmBtn.Checked = false;
			ClinicMonthGraphRptFrmBtn.Checked = false;
			AddEmployeeCh.Checked = false;
			AddPatientCh.Checked = false;
			AppointmentCh.Checked = false;
			DoctorPatientListCh.Checked = false;
			SecretarPatientListCh.Checked = false;
			DentalDataCh.Checked = false;
			DoctorAccountCh.Checked = false;
			SearchPatientCh.Checked = false;
			CompanyCh.Checked = false;
			PatientPayCh.Checked = false;
			PatientAccountCh.Checked = false;
			PatientXray.Checked = false;
			PermissionCh.Checked = false;
			PatAccountRpt.Checked = false;
			AllPatientAccountRptCh.Checked = false;
			DoctorAccountRptCh.Checked = false;
			DoctorPaymentRptCh.Checked = false;
			MovementOfPatStRptCh.Checked = false;
			MovepatStByDrRptCh.Checked = false;
			Expensesch.Checked = false;
			RevenuesCh.Checked = false;
			RptExpensesCh.Checked = false;
			RptRevenuesch.Checked = false;
			RptDailyclinicch.Checked = false;
			DoctorReBackAppointmentch.Checked = false;
			ReBackAppointmentListch.Checked = false;
			EditReBackDatech.Checked = false;
			OldServicesRptFrmBtn.Checked = false;
			medicineFrmBtn.Checked = false;
			PrescriptionFrmBtn.Checked = false;
			ItemsFrmBtn.Checked = false;
			SupplierBtn.Checked = false;
			IncomingBillFrmBtn.Checked = false;
			FrmSupplierAccountsBtn.Checked = false;
			FormSupplier5Btn.Checked = false;
			FrmBillIncomeRptBtn.Checked = false;
			DailymeasureRotFrmBtn.Checked = false;
			RptFrmSearchMedicine.Checked = false;
			ServicePatientBtn.Checked = false;
			MainComplaintBtn.Checked = false;
			SahbItemsBtn.Checked = false;
			FrmRptSahbItemBtn.Checked = false;
			FrmRptBillByDateBtn.Checked = false;
			FrmFilePatientBtn.Checked = false;
			FrmPropertiesBtn.Checked = false;
			ChangeServicePrice.Checked = false;
			btnBackup_Restore.Checked = false;
			Surgery.Checked = false;
			BookingVisits.Checked = false;
			RptVisits.Checked = false;
			SecretaryVisits.Checked = false;
			DoctorVisits.Checked = false;
			PatientSurgery.Checked = false;
			BtnFrmRptReb7ya.Checked = false;
			BtnFrmRptCompanies_Services.Checked = false;
			BtnFrmSell.Checked = false;
			FrmRptSellByDateBtn.Checked = false;
			PatientAccountUpdateBtn.Checked = false;
			PatientServiceUpdateBtn.Checked = false;
			FrmInventoryRptBtn.Checked = false;
			FrmLimitOrderRptBtn.Checked = false;
			FrmInoculationBtn.Checked = false;
			FrmPatientInoculationBtn.Checked = false;
			FrmAssistantRptBtn.Checked = false;
			FrmRptPatientDebtBtn.Checked = false;
			FrmBillBtn.Checked = false;
			FrmVisitMedicalRepBtn.Checked = false;
			AppointmentspBtn.Checked = false;
			FrmRptSurgeryBtn.Checked = false;
			FrmRptSpecialBtn.Checked = false;
			CompanyPayBtn.Checked = false;
			FrmRptCompanyAcountBtn.Checked = false;
			doctorAcountBtn.Checked = false;
			AssistantAccountBtn.Checked = false;
			AssistantAcountDate.Checked = false;
			RptAssistantPaymentBtn.Checked = false;
			RptLoginUserBtn.Checked = false;
			StockFrmBtn.Checked = false;
			StockUsersFrmBtn.Checked = false;
			FrmTarnsbetweenStockBtn.Checked = false;
			StockTransRptFrmBtn.Checked = false;
			FrmDeanSupplierBtn.Checked = false;
			updateSurgery.Checked = false;
			medicineFrmBtn.Enabled = true;
			PrescriptionFrmBtn.Enabled = true;
			ItemsFrmBtn.Enabled = true;
			SupplierBtn.Enabled = true;
			IncomingBillFrmBtn.Enabled = true;
			FrmSupplierAccountsBtn.Enabled = true;
			FormSupplier5Btn.Enabled = true;
			FrmBillIncomeRptBtn.Enabled = true;
			AddEmployeeCh.Enabled = true;
			AddPatientCh.Enabled = true;
			AppointmentCh.Enabled = true;
			DoctorPatientListCh.Enabled = true;
			SecretarPatientListCh.Enabled = true;
			DentalDataCh.Enabled = true;
			DoctorAccountCh.Enabled = true;
			SearchPatientCh.Enabled = true;
			CompanyCh.Enabled = true;
			PatientPayCh.Enabled = true;
			PatientAccountCh.Enabled = true;
			PatientXray.Enabled = true;
			PermissionCh.Enabled = true;
			PatAccountRpt.Enabled = true;
			AllPatientAccountRptCh.Enabled = true;
			DoctorAccountRptCh.Enabled = true;
			DoctorPaymentRptCh.Enabled = true;
			MovementOfPatStRptCh.Enabled = true;
			MovepatStByDrRptCh.Enabled = true;
			NetDailyClinicRptFrmBtn.Enabled = true;
			ClinicMonthGraphRptFrmBtn.Enabled = true;
			Expensesch.Enabled = true;
			RevenuesCh.Enabled = true;
			RptExpensesCh.Enabled = true;
			RptRevenuesch.Enabled = true;
			RptDailyclinicch.Enabled = true;
			DoctorReBackAppointmentch.Enabled = true;
			ReBackAppointmentListch.Enabled = true;
			EditReBackDatech.Enabled = true;
			OldServicesRptFrmBtn.Enabled = true;
			DailymeasureRotFrmBtn.Enabled = true;
			RptFrmSearchMedicine.Enabled = true;
			ServicePatientBtn.Enabled = true;
			MainComplaintBtn.Enabled = true;
			SahbItemsBtn.Enabled = true;
			FrmRptSahbItemBtn.Enabled = true;
			FrmRptBillByDateBtn.Enabled = true;
			FrmFilePatientBtn.Enabled = true;
			FrmPropertiesBtn.Enabled = true;
			ChangeServicePrice.Enabled = true;
			btnBackup_Restore.Enabled = true;
			Surgery.Enabled = true;
			BookingVisits.Enabled = true;
			RptVisits.Enabled = true;
			SecretaryVisits.Enabled = true;
			DoctorVisits.Enabled = true;
			PatientSurgery.Enabled = true;
			BtnFrmRptReb7ya.Enabled = true;
			BtnFrmRptCompanies_Services.Enabled = true;
			BtnFrmSell.Enabled = true;
			FrmRptSellByDateBtn.Enabled = true;
			PatientAccountUpdateBtn.Enabled = true;
			PatientServiceUpdateBtn.Enabled = true;
			FrmInventoryRptBtn.Enabled = true;
			FrmLimitOrderRptBtn.Enabled = true;
			FrmInoculationBtn.Enabled = true;
			FrmPatientInoculationBtn.Enabled = true;
			FrmAssistantRptBtn.Enabled = true;
			FrmRptPatientDebtBtn.Enabled = true;
			FrmBillBtn.Enabled = true;
			FrmVisitMedicalRepBtn.Enabled = true;
			AppointmentspBtn.Enabled = true;
			FrmRptSurgeryBtn.Enabled = true;
			FrmRptSpecialBtn.Enabled = true;
			CompanyPayBtn.Enabled = true;
			FrmRptCompanyAcountBtn.Enabled = true;
			doctorAcountBtn.Enabled = true;
			AssistantAccountBtn.Enabled = true;
			AssistantAcountDate.Enabled = true;
			RptAssistantPaymentBtn.Enabled = true;
			RptLoginUserBtn.Enabled = true;
			StockFrmBtn.Enabled = true;
			StockUsersFrmBtn.Enabled = true;
			FrmTarnsbetweenStockBtn.Enabled = true;
			StockTransRptFrmBtn.Enabled = true;
			FrmDeanSupplierBtn.Enabled = true;
			updateSurgery.Enabled = true;
		}
	}
}
