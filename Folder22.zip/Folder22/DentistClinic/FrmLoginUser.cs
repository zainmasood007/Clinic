// DentistClinic.FrmLoginUser
using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;
using DentistClinic;
using DentistClinic.Properties;
using DentistClinic.Reports;

public class FrmLoginUser : ReportBaseForm
{
	private IContainer components = null;

	private GroupBox groupBox3;

	private DateTimePicker dateTimePicker1;

	private DateTimePicker dateTimePicker2;

	private Button button1;

	private Label label4;

	private ComboBox comboBox1;

	private Label label5;

	private Label label6;

	private GroupBox groupBox1;

	private DateTimePicker date2;

	private DateTimePicker date1;

	private Button ViewRptBtn;

	private Label label3;

	private ComboBox ItemcomboBox;

	private Label label2;

	private Label label1;

	private GroupBox groupBox2;

	private CrystalReportViewer crystalReportViewer1;

	private DataSet1 dataSet11;

	private SqlCommand sqlSelectCommand1;

	private SqlConnection sqlConnection1;

	private SqlCommand sqlInsertCommand1;

	private SqlCommand sqlUpdateCommand1;

	private SqlCommand sqlDeleteCommand1;

	private SqlDataAdapter sqlDataAdapter1;

	private SqlCommand sqlSelectCommand2;

	private SqlConnection sqlConnection2;

	private SqlCommand sqlInsertCommand2;

	private SqlCommand sqlUpdateCommand2;

	private SqlCommand sqlDeleteCommand2;

	private SqlDataAdapter sqlDataAdapter2;

	private SqlCommand sqlSelectCommand3;

	private SqlConnection sqlConnection3;

	private SqlCommand sqlInsertCommand3;

	private SqlCommand sqlUpdateCommand3;

	private SqlCommand sqlDeleteCommand3;

	private SqlDataAdapter sqlDataAdapter3;

	private dataClass Codes = new dataClass(".\\sqlExpress");

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLoginUser));
		groupBox3 = new System.Windows.Forms.GroupBox();
		dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
		dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
		button1 = new System.Windows.Forms.Button();
		label4 = new System.Windows.Forms.Label();
		comboBox1 = new System.Windows.Forms.ComboBox();
		label5 = new System.Windows.Forms.Label();
		label6 = new System.Windows.Forms.Label();
		groupBox1 = new System.Windows.Forms.GroupBox();
		date2 = new System.Windows.Forms.DateTimePicker();
		date1 = new System.Windows.Forms.DateTimePicker();
		ViewRptBtn = new System.Windows.Forms.Button();
		label3 = new System.Windows.Forms.Label();
		ItemcomboBox = new System.Windows.Forms.ComboBox();
		label2 = new System.Windows.Forms.Label();
		label1 = new System.Windows.Forms.Label();
		groupBox2 = new System.Windows.Forms.GroupBox();
		crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
		dataSet11 = new DataSet1();
		sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
		sqlConnection1 = new System.Data.SqlClient.SqlConnection();
		sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
		sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
		sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
		sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
		sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
		sqlConnection2 = new System.Data.SqlClient.SqlConnection();
		sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
		sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
		sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
		sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
		sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
		sqlConnection3 = new System.Data.SqlClient.SqlConnection();
		sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
		sqlUpdateCommand3 = new System.Data.SqlClient.SqlCommand();
		sqlDeleteCommand3 = new System.Data.SqlClient.SqlCommand();
		sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
		groupBox3.SuspendLayout();
		groupBox1.SuspendLayout();
		groupBox2.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
		SuspendLayout();
		resources.ApplyResources(groupBox3, "groupBox3");
		groupBox3.BackColor = System.Drawing.Color.Transparent;
		groupBox3.Controls.Add(dateTimePicker1);
		groupBox3.Controls.Add(dateTimePicker2);
		groupBox3.Controls.Add(button1);
		groupBox3.Controls.Add(label4);
		groupBox3.Controls.Add(comboBox1);
		groupBox3.Controls.Add(label5);
		groupBox3.Controls.Add(label6);
		groupBox3.Name = "groupBox3";
		groupBox3.TabStop = false;
		resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
		dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
		dateTimePicker1.Name = "dateTimePicker1";
		resources.ApplyResources(dateTimePicker2, "dateTimePicker2");
		dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
		dateTimePicker2.Name = "dateTimePicker2";
		resources.ApplyResources(button1, "button1");
		button1.BackColor = System.Drawing.Color.Gainsboro;
		button1.Name = "button1";
		button1.UseVisualStyleBackColor = false;
		button1.Click += new System.EventHandler(button1_Click);
		resources.ApplyResources(label4, "label4");
		label4.Name = "label4";
		resources.ApplyResources(comboBox1, "comboBox1");
		comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
		comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
		comboBox1.FormattingEnabled = true;
		comboBox1.Name = "comboBox1";
		resources.ApplyResources(label5, "label5");
		label5.Name = "label5";
		resources.ApplyResources(label6, "label6");
		label6.Name = "label6";
		resources.ApplyResources(groupBox1, "groupBox1");
		groupBox1.BackColor = System.Drawing.Color.Transparent;
		groupBox1.Controls.Add(date2);
		groupBox1.Controls.Add(date1);
		groupBox1.Controls.Add(ViewRptBtn);
		groupBox1.Controls.Add(label3);
		groupBox1.Controls.Add(ItemcomboBox);
		groupBox1.Controls.Add(label2);
		groupBox1.Controls.Add(label1);
		groupBox1.Name = "groupBox1";
		groupBox1.TabStop = false;
		resources.ApplyResources(date2, "date2");
		date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
		date2.Name = "date2";
		resources.ApplyResources(date1, "date1");
		date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
		date1.Name = "date1";
		resources.ApplyResources(ViewRptBtn, "ViewRptBtn");
		ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
		ViewRptBtn.Name = "ViewRptBtn";
		ViewRptBtn.UseVisualStyleBackColor = false;
		resources.ApplyResources(label3, "label3");
		label3.Name = "label3";
		resources.ApplyResources(ItemcomboBox, "ItemcomboBox");
		ItemcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
		ItemcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
		ItemcomboBox.FormattingEnabled = true;
		ItemcomboBox.Name = "ItemcomboBox";
		resources.ApplyResources(label2, "label2");
		label2.Name = "label2";
		resources.ApplyResources(label1, "label1");
		label1.Name = "label1";
		resources.ApplyResources(groupBox2, "groupBox2");
		groupBox2.BackColor = System.Drawing.Color.Transparent;
		groupBox2.Controls.Add(crystalReportViewer1);
		groupBox2.Name = "groupBox2";
		groupBox2.TabStop = false;
		crystalReportViewer1.ActiveViewIndex = -1;
		crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
		resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
		crystalReportViewer1.Name = "crystalReportViewer1";
		crystalReportViewer1.SelectionFormula = "";
		crystalReportViewer1.ViewTimeSelectionFormula = "";
		dataSet11.DataSetName = "DataSet1";
		dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
		sqlSelectCommand1.CommandText = "SELECT        LoginUsers.*\r\nFROM            LoginUsers";
		sqlSelectCommand1.Connection = sqlConnection1;
		sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
		sqlConnection1.FireInfoMessageEventOnUserErrors = false;
		sqlInsertCommand1.CommandText = "INSERT INTO [LoginUsers] ([userId], [Date]) VALUES (@userId, @Date);\r\nSELECT ID, userId, Date FROM LoginUsers WHERE (ID = SCOPE_IDENTITY())";
		sqlInsertCommand1.Connection = sqlConnection1;
		sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
		{
			new System.Data.SqlClient.SqlParameter("@userId", System.Data.SqlDbType.Int, 0, "userId"),
			new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date")
		});
		sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
		sqlUpdateCommand1.Connection = sqlConnection1;
		sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[8]
		{
			new System.Data.SqlClient.SqlParameter("@userId", System.Data.SqlDbType.Int, 0, "userId"),
			new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
			new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_userId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "userId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_userId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userId", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Date", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Date", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Date", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Date", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
		});
		sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
		sqlDeleteCommand1.Connection = sqlConnection1;
		sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[5]
		{
			new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_userId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "userId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_userId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userId", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Date", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Date", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Date", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Date", System.Data.DataRowVersion.Original, null)
		});
		sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
		sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
		sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
		sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
		{
			new System.Data.Common.DataTableMapping("Table", "LoginUsers", new System.Data.Common.DataColumnMapping[3]
			{
				new System.Data.Common.DataColumnMapping("ID", "ID"),
				new System.Data.Common.DataColumnMapping("userId", "userId"),
				new System.Data.Common.DataColumnMapping("Date", "Date")
			})
		});
		sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
		sqlSelectCommand2.CommandText = "SELECT        users.*\r\nFROM            users";
		sqlSelectCommand2.Connection = sqlConnection2;
		sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
		sqlConnection2.FireInfoMessageEventOnUserErrors = false;
		sqlInsertCommand2.CommandText = resources.GetString("sqlInsertCommand2.CommandText");
		sqlInsertCommand2.Connection = sqlConnection2;
		sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[81]
		{
			new System.Data.SqlClient.SqlParameter("@EmpID", System.Data.SqlDbType.Int, 0, "EmpID"),
			new System.Data.SqlClient.SqlParameter("@userName", System.Data.SqlDbType.NVarChar, 0, "userName"),
			new System.Data.SqlClient.SqlParameter("@userPassward", System.Data.SqlDbType.NVarChar, 0, "userPassward"),
			new System.Data.SqlClient.SqlParameter("@AddEmployee", System.Data.SqlDbType.Bit, 0, "AddEmployee"),
			new System.Data.SqlClient.SqlParameter("@AddPatient", System.Data.SqlDbType.Bit, 0, "AddPatient"),
			new System.Data.SqlClient.SqlParameter("@Appointment", System.Data.SqlDbType.Bit, 0, "Appointment"),
			new System.Data.SqlClient.SqlParameter("@DoctorPatientList", System.Data.SqlDbType.Bit, 0, "DoctorPatientList"),
			new System.Data.SqlClient.SqlParameter("@SecretaryPatientList", System.Data.SqlDbType.Bit, 0, "SecretaryPatientList"),
			new System.Data.SqlClient.SqlParameter("@DentalData", System.Data.SqlDbType.Bit, 0, "DentalData"),
			new System.Data.SqlClient.SqlParameter("@DoctorAccount", System.Data.SqlDbType.Bit, 0, "DoctorAccount"),
			new System.Data.SqlClient.SqlParameter("@SearchPatient", System.Data.SqlDbType.Bit, 0, "SearchPatient"),
			new System.Data.SqlClient.SqlParameter("@Company", System.Data.SqlDbType.Bit, 0, "Company"),
			new System.Data.SqlClient.SqlParameter("@PatientPay", System.Data.SqlDbType.Bit, 0, "PatientPay"),
			new System.Data.SqlClient.SqlParameter("@PatientAccount", System.Data.SqlDbType.Bit, 0, "PatientAccount"),
			new System.Data.SqlClient.SqlParameter("@PatientXray", System.Data.SqlDbType.Bit, 0, "PatientXray"),
			new System.Data.SqlClient.SqlParameter("@Permission", System.Data.SqlDbType.Bit, 0, "Permission"),
			new System.Data.SqlClient.SqlParameter("@PatAccountRpt", System.Data.SqlDbType.Bit, 0, "PatAccountRpt"),
			new System.Data.SqlClient.SqlParameter("@ALLPatAccountRpt", System.Data.SqlDbType.Bit, 0, "ALLPatAccountRpt"),
			new System.Data.SqlClient.SqlParameter("@DoctorAccountRpt", System.Data.SqlDbType.Bit, 0, "DoctorAccountRpt"),
			new System.Data.SqlClient.SqlParameter("@DoctorPaymentRpt", System.Data.SqlDbType.Bit, 0, "DoctorPaymentRpt"),
			new System.Data.SqlClient.SqlParameter("@MovOfPatSTrpt", System.Data.SqlDbType.Bit, 0, "MovOfPatSTrpt"),
			new System.Data.SqlClient.SqlParameter("@MovOfPatStbyDr", System.Data.SqlDbType.Bit, 0, "MovOfPatStbyDr"),
			new System.Data.SqlClient.SqlParameter("@Expenses", System.Data.SqlDbType.Bit, 0, "Expenses"),
			new System.Data.SqlClient.SqlParameter("@Revenues", System.Data.SqlDbType.Bit, 0, "Revenues"),
			new System.Data.SqlClient.SqlParameter("@RptExpenses", System.Data.SqlDbType.Bit, 0, "RptExpenses"),
			new System.Data.SqlClient.SqlParameter("@RptRevenues", System.Data.SqlDbType.Bit, 0, "RptRevenues"),
			new System.Data.SqlClient.SqlParameter("@RptStockMove", System.Data.SqlDbType.Bit, 0, "RptStockMove"),
			new System.Data.SqlClient.SqlParameter("@DoctorBackReserve", System.Data.SqlDbType.Bit, 0, "DoctorBackReserve"),
			new System.Data.SqlClient.SqlParameter("@SecretaryBackReserve", System.Data.SqlDbType.Bit, 0, "SecretaryBackReserve"),
			new System.Data.SqlClient.SqlParameter("@UpdateRebackdate", System.Data.SqlDbType.Bit, 0, "UpdateRebackdate"),
			new System.Data.SqlClient.SqlParameter("@medicineFrmBtn", System.Data.SqlDbType.Bit, 0, "medicineFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@PrescriptionFrmBtn", System.Data.SqlDbType.Bit, 0, "PrescriptionFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@ItemsFrmBtn", System.Data.SqlDbType.Bit, 0, "ItemsFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@SupplierBtn", System.Data.SqlDbType.Bit, 0, "SupplierBtn"),
			new System.Data.SqlClient.SqlParameter("@IncomingBillFrmBtn", System.Data.SqlDbType.Bit, 0, "IncomingBillFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmSupplierAccountsBtn", System.Data.SqlDbType.Bit, 0, "FrmSupplierAccountsBtn"),
			new System.Data.SqlClient.SqlParameter("@FormSupplier5Btn", System.Data.SqlDbType.Bit, 0, "FormSupplier5Btn"),
			new System.Data.SqlClient.SqlParameter("@FrmBillIncomeRptBtn", System.Data.SqlDbType.Bit, 0, "FrmBillIncomeRptBtn"),
			new System.Data.SqlClient.SqlParameter("@OldServicesRptFrmBtn", System.Data.SqlDbType.Bit, 0, "OldServicesRptFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@NetDailyClinicRptFrmBtn", System.Data.SqlDbType.Bit, 0, "NetDailyClinicRptFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@ClinicMonthGraphRptFrmBtn", System.Data.SqlDbType.Bit, 0, "ClinicMonthGraphRptFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@DailymeasureRotFrmBtn", System.Data.SqlDbType.Bit, 0, "DailymeasureRotFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@RptFrmSearchMedicine", System.Data.SqlDbType.Bit, 0, "RptFrmSearchMedicine"),
			new System.Data.SqlClient.SqlParameter("@ServicePatientBtn", System.Data.SqlDbType.Bit, 0, "ServicePatientBtn"),
			new System.Data.SqlClient.SqlParameter("@MainComplaintBtn", System.Data.SqlDbType.Bit, 0, "MainComplaintBtn"),
			new System.Data.SqlClient.SqlParameter("@SahbItemsBtn", System.Data.SqlDbType.Bit, 0, "SahbItemsBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmRptSahbItemBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSahbItemBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmRptBillByDateBtn", System.Data.SqlDbType.Bit, 0, "FrmRptBillByDateBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmFilePatientBtn", System.Data.SqlDbType.Bit, 0, "FrmFilePatientBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmPropertiesBtn", System.Data.SqlDbType.Bit, 0, "FrmPropertiesBtn"),
			new System.Data.SqlClient.SqlParameter("@ChangeServicePrice", System.Data.SqlDbType.Bit, 0, "ChangeServicePrice"),
			new System.Data.SqlClient.SqlParameter("@btnBackup_Restore", System.Data.SqlDbType.Bit, 0, "btnBackup_Restore"),
			new System.Data.SqlClient.SqlParameter("@Surgery", System.Data.SqlDbType.Bit, 0, "Surgery"),
			new System.Data.SqlClient.SqlParameter("@BookingVisits", System.Data.SqlDbType.Bit, 0, "BookingVisits"),
			new System.Data.SqlClient.SqlParameter("@RptVisits", System.Data.SqlDbType.Bit, 0, "RptVisits"),
			new System.Data.SqlClient.SqlParameter("@SecretaryVisits", System.Data.SqlDbType.Bit, 0, "SecretaryVisits"),
			new System.Data.SqlClient.SqlParameter("@DoctorVisits", System.Data.SqlDbType.Bit, 0, "DoctorVisits"),
			new System.Data.SqlClient.SqlParameter("@PatientSurgery", System.Data.SqlDbType.Bit, 0, "PatientSurgery"),
			new System.Data.SqlClient.SqlParameter("@BtnFrmRptReb7ya", System.Data.SqlDbType.Bit, 0, "BtnFrmRptReb7ya"),
			new System.Data.SqlClient.SqlParameter("@BtnFrmRptCompanies_Services", System.Data.SqlDbType.Bit, 0, "BtnFrmRptCompanies_Services"),
			new System.Data.SqlClient.SqlParameter("@BtnFrmSell", System.Data.SqlDbType.Bit, 0, "BtnFrmSell"),
			new System.Data.SqlClient.SqlParameter("@FrmRptSellByDateBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSellByDateBtn"),
			new System.Data.SqlClient.SqlParameter("@PatientAccountUpdateBtn", System.Data.SqlDbType.Bit, 0, "PatientAccountUpdateBtn"),
			new System.Data.SqlClient.SqlParameter("@PatientServiceUpdateBtn", System.Data.SqlDbType.Bit, 0, "PatientServiceUpdateBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmInventoryRptBtn", System.Data.SqlDbType.Bit, 0, "FrmInventoryRptBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmLimitOrderRptBtn", System.Data.SqlDbType.Bit, 0, "FrmLimitOrderRptBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmInoculationBtn", System.Data.SqlDbType.Bit, 0, "FrmInoculationBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmPatientInoculationBtn", System.Data.SqlDbType.Bit, 0, "FrmPatientInoculationBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmAssistantRptBtn", System.Data.SqlDbType.Bit, 0, "FrmAssistantRptBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmRptPatientDebtBtn", System.Data.SqlDbType.Bit, 0, "FrmRptPatientDebtBtn"),
			new System.Data.SqlClient.SqlParameter("@doctorAcountBtn", System.Data.SqlDbType.Bit, 0, "doctorAcountBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmBillBtn", System.Data.SqlDbType.Bit, 0, "FrmBillBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmVisitMedicalRepBtn", System.Data.SqlDbType.Bit, 0, "FrmVisitMedicalRepBtn"),
			new System.Data.SqlClient.SqlParameter("@AppointmentspBtn", System.Data.SqlDbType.Bit, 0, "AppointmentspBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmRptSurgeryBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSurgeryBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmRptSpecialBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSpecialBtn"),
			new System.Data.SqlClient.SqlParameter("@CompanyPayBtn", System.Data.SqlDbType.Bit, 0, "CompanyPayBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmRptCompanyAcountBtn", System.Data.SqlDbType.Bit, 0, "FrmRptCompanyAcountBtn"),
			new System.Data.SqlClient.SqlParameter("@AssistantAccountBtn", System.Data.SqlDbType.Bit, 0, "AssistantAccountBtn"),
			new System.Data.SqlClient.SqlParameter("@AssistantAcountDate", System.Data.SqlDbType.Bit, 0, "AssistantAcountDate"),
			new System.Data.SqlClient.SqlParameter("@RptAssistantPaymentBtn", System.Data.SqlDbType.Bit, 0, "RptAssistantPaymentBtn")
		});
		sqlUpdateCommand2.CommandText = resources.GetString("sqlUpdateCommand2.CommandText");
		sqlUpdateCommand2.Connection = sqlConnection2;
		sqlUpdateCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[245]
		{
			new System.Data.SqlClient.SqlParameter("@EmpID", System.Data.SqlDbType.Int, 0, "EmpID"),
			new System.Data.SqlClient.SqlParameter("@userName", System.Data.SqlDbType.NVarChar, 0, "userName"),
			new System.Data.SqlClient.SqlParameter("@userPassward", System.Data.SqlDbType.NVarChar, 0, "userPassward"),
			new System.Data.SqlClient.SqlParameter("@AddEmployee", System.Data.SqlDbType.Bit, 0, "AddEmployee"),
			new System.Data.SqlClient.SqlParameter("@AddPatient", System.Data.SqlDbType.Bit, 0, "AddPatient"),
			new System.Data.SqlClient.SqlParameter("@Appointment", System.Data.SqlDbType.Bit, 0, "Appointment"),
			new System.Data.SqlClient.SqlParameter("@DoctorPatientList", System.Data.SqlDbType.Bit, 0, "DoctorPatientList"),
			new System.Data.SqlClient.SqlParameter("@SecretaryPatientList", System.Data.SqlDbType.Bit, 0, "SecretaryPatientList"),
			new System.Data.SqlClient.SqlParameter("@DentalData", System.Data.SqlDbType.Bit, 0, "DentalData"),
			new System.Data.SqlClient.SqlParameter("@DoctorAccount", System.Data.SqlDbType.Bit, 0, "DoctorAccount"),
			new System.Data.SqlClient.SqlParameter("@SearchPatient", System.Data.SqlDbType.Bit, 0, "SearchPatient"),
			new System.Data.SqlClient.SqlParameter("@Company", System.Data.SqlDbType.Bit, 0, "Company"),
			new System.Data.SqlClient.SqlParameter("@PatientPay", System.Data.SqlDbType.Bit, 0, "PatientPay"),
			new System.Data.SqlClient.SqlParameter("@PatientAccount", System.Data.SqlDbType.Bit, 0, "PatientAccount"),
			new System.Data.SqlClient.SqlParameter("@PatientXray", System.Data.SqlDbType.Bit, 0, "PatientXray"),
			new System.Data.SqlClient.SqlParameter("@Permission", System.Data.SqlDbType.Bit, 0, "Permission"),
			new System.Data.SqlClient.SqlParameter("@PatAccountRpt", System.Data.SqlDbType.Bit, 0, "PatAccountRpt"),
			new System.Data.SqlClient.SqlParameter("@ALLPatAccountRpt", System.Data.SqlDbType.Bit, 0, "ALLPatAccountRpt"),
			new System.Data.SqlClient.SqlParameter("@DoctorAccountRpt", System.Data.SqlDbType.Bit, 0, "DoctorAccountRpt"),
			new System.Data.SqlClient.SqlParameter("@DoctorPaymentRpt", System.Data.SqlDbType.Bit, 0, "DoctorPaymentRpt"),
			new System.Data.SqlClient.SqlParameter("@MovOfPatSTrpt", System.Data.SqlDbType.Bit, 0, "MovOfPatSTrpt"),
			new System.Data.SqlClient.SqlParameter("@MovOfPatStbyDr", System.Data.SqlDbType.Bit, 0, "MovOfPatStbyDr"),
			new System.Data.SqlClient.SqlParameter("@Expenses", System.Data.SqlDbType.Bit, 0, "Expenses"),
			new System.Data.SqlClient.SqlParameter("@Revenues", System.Data.SqlDbType.Bit, 0, "Revenues"),
			new System.Data.SqlClient.SqlParameter("@RptExpenses", System.Data.SqlDbType.Bit, 0, "RptExpenses"),
			new System.Data.SqlClient.SqlParameter("@RptRevenues", System.Data.SqlDbType.Bit, 0, "RptRevenues"),
			new System.Data.SqlClient.SqlParameter("@RptStockMove", System.Data.SqlDbType.Bit, 0, "RptStockMove"),
			new System.Data.SqlClient.SqlParameter("@DoctorBackReserve", System.Data.SqlDbType.Bit, 0, "DoctorBackReserve"),
			new System.Data.SqlClient.SqlParameter("@SecretaryBackReserve", System.Data.SqlDbType.Bit, 0, "SecretaryBackReserve"),
			new System.Data.SqlClient.SqlParameter("@UpdateRebackdate", System.Data.SqlDbType.Bit, 0, "UpdateRebackdate"),
			new System.Data.SqlClient.SqlParameter("@medicineFrmBtn", System.Data.SqlDbType.Bit, 0, "medicineFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@PrescriptionFrmBtn", System.Data.SqlDbType.Bit, 0, "PrescriptionFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@ItemsFrmBtn", System.Data.SqlDbType.Bit, 0, "ItemsFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@SupplierBtn", System.Data.SqlDbType.Bit, 0, "SupplierBtn"),
			new System.Data.SqlClient.SqlParameter("@IncomingBillFrmBtn", System.Data.SqlDbType.Bit, 0, "IncomingBillFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmSupplierAccountsBtn", System.Data.SqlDbType.Bit, 0, "FrmSupplierAccountsBtn"),
			new System.Data.SqlClient.SqlParameter("@FormSupplier5Btn", System.Data.SqlDbType.Bit, 0, "FormSupplier5Btn"),
			new System.Data.SqlClient.SqlParameter("@FrmBillIncomeRptBtn", System.Data.SqlDbType.Bit, 0, "FrmBillIncomeRptBtn"),
			new System.Data.SqlClient.SqlParameter("@OldServicesRptFrmBtn", System.Data.SqlDbType.Bit, 0, "OldServicesRptFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@NetDailyClinicRptFrmBtn", System.Data.SqlDbType.Bit, 0, "NetDailyClinicRptFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@ClinicMonthGraphRptFrmBtn", System.Data.SqlDbType.Bit, 0, "ClinicMonthGraphRptFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@DailymeasureRotFrmBtn", System.Data.SqlDbType.Bit, 0, "DailymeasureRotFrmBtn"),
			new System.Data.SqlClient.SqlParameter("@RptFrmSearchMedicine", System.Data.SqlDbType.Bit, 0, "RptFrmSearchMedicine"),
			new System.Data.SqlClient.SqlParameter("@ServicePatientBtn", System.Data.SqlDbType.Bit, 0, "ServicePatientBtn"),
			new System.Data.SqlClient.SqlParameter("@MainComplaintBtn", System.Data.SqlDbType.Bit, 0, "MainComplaintBtn"),
			new System.Data.SqlClient.SqlParameter("@SahbItemsBtn", System.Data.SqlDbType.Bit, 0, "SahbItemsBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmRptSahbItemBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSahbItemBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmRptBillByDateBtn", System.Data.SqlDbType.Bit, 0, "FrmRptBillByDateBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmFilePatientBtn", System.Data.SqlDbType.Bit, 0, "FrmFilePatientBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmPropertiesBtn", System.Data.SqlDbType.Bit, 0, "FrmPropertiesBtn"),
			new System.Data.SqlClient.SqlParameter("@ChangeServicePrice", System.Data.SqlDbType.Bit, 0, "ChangeServicePrice"),
			new System.Data.SqlClient.SqlParameter("@btnBackup_Restore", System.Data.SqlDbType.Bit, 0, "btnBackup_Restore"),
			new System.Data.SqlClient.SqlParameter("@Surgery", System.Data.SqlDbType.Bit, 0, "Surgery"),
			new System.Data.SqlClient.SqlParameter("@BookingVisits", System.Data.SqlDbType.Bit, 0, "BookingVisits"),
			new System.Data.SqlClient.SqlParameter("@RptVisits", System.Data.SqlDbType.Bit, 0, "RptVisits"),
			new System.Data.SqlClient.SqlParameter("@SecretaryVisits", System.Data.SqlDbType.Bit, 0, "SecretaryVisits"),
			new System.Data.SqlClient.SqlParameter("@DoctorVisits", System.Data.SqlDbType.Bit, 0, "DoctorVisits"),
			new System.Data.SqlClient.SqlParameter("@PatientSurgery", System.Data.SqlDbType.Bit, 0, "PatientSurgery"),
			new System.Data.SqlClient.SqlParameter("@BtnFrmRptReb7ya", System.Data.SqlDbType.Bit, 0, "BtnFrmRptReb7ya"),
			new System.Data.SqlClient.SqlParameter("@BtnFrmRptCompanies_Services", System.Data.SqlDbType.Bit, 0, "BtnFrmRptCompanies_Services"),
			new System.Data.SqlClient.SqlParameter("@BtnFrmSell", System.Data.SqlDbType.Bit, 0, "BtnFrmSell"),
			new System.Data.SqlClient.SqlParameter("@FrmRptSellByDateBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSellByDateBtn"),
			new System.Data.SqlClient.SqlParameter("@PatientAccountUpdateBtn", System.Data.SqlDbType.Bit, 0, "PatientAccountUpdateBtn"),
			new System.Data.SqlClient.SqlParameter("@PatientServiceUpdateBtn", System.Data.SqlDbType.Bit, 0, "PatientServiceUpdateBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmInventoryRptBtn", System.Data.SqlDbType.Bit, 0, "FrmInventoryRptBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmLimitOrderRptBtn", System.Data.SqlDbType.Bit, 0, "FrmLimitOrderRptBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmInoculationBtn", System.Data.SqlDbType.Bit, 0, "FrmInoculationBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmPatientInoculationBtn", System.Data.SqlDbType.Bit, 0, "FrmPatientInoculationBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmAssistantRptBtn", System.Data.SqlDbType.Bit, 0, "FrmAssistantRptBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmRptPatientDebtBtn", System.Data.SqlDbType.Bit, 0, "FrmRptPatientDebtBtn"),
			new System.Data.SqlClient.SqlParameter("@doctorAcountBtn", System.Data.SqlDbType.Bit, 0, "doctorAcountBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmBillBtn", System.Data.SqlDbType.Bit, 0, "FrmBillBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmVisitMedicalRepBtn", System.Data.SqlDbType.Bit, 0, "FrmVisitMedicalRepBtn"),
			new System.Data.SqlClient.SqlParameter("@AppointmentspBtn", System.Data.SqlDbType.Bit, 0, "AppointmentspBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmRptSurgeryBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSurgeryBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmRptSpecialBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSpecialBtn"),
			new System.Data.SqlClient.SqlParameter("@CompanyPayBtn", System.Data.SqlDbType.Bit, 0, "CompanyPayBtn"),
			new System.Data.SqlClient.SqlParameter("@FrmRptCompanyAcountBtn", System.Data.SqlDbType.Bit, 0, "FrmRptCompanyAcountBtn"),
			new System.Data.SqlClient.SqlParameter("@AssistantAccountBtn", System.Data.SqlDbType.Bit, 0, "AssistantAccountBtn"),
			new System.Data.SqlClient.SqlParameter("@AssistantAcountDate", System.Data.SqlDbType.Bit, 0, "AssistantAcountDate"),
			new System.Data.SqlClient.SqlParameter("@RptAssistantPaymentBtn", System.Data.SqlDbType.Bit, 0, "RptAssistantPaymentBtn"),
			new System.Data.SqlClient.SqlParameter("@Original_userId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userId", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_EmpID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EmpID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_EmpID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EmpID", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_userName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "userName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_userName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userName", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_userPassward", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "userPassward", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_userPassward", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userPassward", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_AddEmployee", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AddEmployee", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_AddEmployee", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AddEmployee", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_AddPatient", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AddPatient", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_AddPatient", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AddPatient", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Appointment", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Appointment", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Appointment", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Appointment", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DoctorPatientList", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorPatientList", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DoctorPatientList", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorPatientList", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_SecretaryPatientList", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SecretaryPatientList", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_SecretaryPatientList", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SecretaryPatientList", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DentalData", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalData", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DentalData", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalData", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DoctorAccount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorAccount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DoctorAccount", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorAccount", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_SearchPatient", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SearchPatient", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_SearchPatient", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SearchPatient", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Company", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Company", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Company", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Company", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatientPay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientPay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatientPay", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientPay", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatientAccount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientAccount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatientAccount", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientAccount", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatientXray", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientXray", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatientXray", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientXray", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Permission", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Permission", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Permission", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Permission", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatAccountRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatAccountRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatAccountRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatAccountRpt", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_ALLPatAccountRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ALLPatAccountRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_ALLPatAccountRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ALLPatAccountRpt", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DoctorAccountRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorAccountRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DoctorAccountRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorAccountRpt", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DoctorPaymentRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorPaymentRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DoctorPaymentRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorPaymentRpt", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_MovOfPatSTrpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MovOfPatSTrpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_MovOfPatSTrpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MovOfPatSTrpt", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_MovOfPatStbyDr", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MovOfPatStbyDr", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_MovOfPatStbyDr", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MovOfPatStbyDr", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Expenses", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Expenses", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Expenses", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Expenses", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Revenues", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Revenues", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Revenues", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Revenues", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_RptExpenses", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptExpenses", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_RptExpenses", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptExpenses", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_RptRevenues", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptRevenues", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_RptRevenues", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptRevenues", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_RptStockMove", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptStockMove", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_RptStockMove", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptStockMove", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DoctorBackReserve", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorBackReserve", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DoctorBackReserve", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorBackReserve", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_SecretaryBackReserve", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SecretaryBackReserve", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_SecretaryBackReserve", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SecretaryBackReserve", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_UpdateRebackdate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "UpdateRebackdate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_UpdateRebackdate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "UpdateRebackdate", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_medicineFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "medicineFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_medicineFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "medicineFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PrescriptionFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PrescriptionFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PrescriptionFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PrescriptionFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_ItemsFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemsFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_ItemsFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemsFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_SupplierBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_SupplierBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_IncomingBillFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "IncomingBillFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_IncomingBillFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "IncomingBillFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmSupplierAccountsBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmSupplierAccountsBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmSupplierAccountsBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmSupplierAccountsBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FormSupplier5Btn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FormSupplier5Btn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FormSupplier5Btn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FormSupplier5Btn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmBillIncomeRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmBillIncomeRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmBillIncomeRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmBillIncomeRptBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_OldServicesRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "OldServicesRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_OldServicesRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "OldServicesRptFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_NetDailyClinicRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NetDailyClinicRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_NetDailyClinicRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NetDailyClinicRptFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_ClinicMonthGraphRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicMonthGraphRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_ClinicMonthGraphRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicMonthGraphRptFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DailymeasureRotFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DailymeasureRotFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DailymeasureRotFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DailymeasureRotFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_RptFrmSearchMedicine", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptFrmSearchMedicine", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_RptFrmSearchMedicine", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptFrmSearchMedicine", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_ServicePatientBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ServicePatientBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_ServicePatientBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ServicePatientBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_MainComplaintBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MainComplaintBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_MainComplaintBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MainComplaintBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_SahbItemsBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SahbItemsBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_SahbItemsBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SahbItemsBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSahbItemBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSahbItemBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptSahbItemBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSahbItemBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptBillByDateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptBillByDateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptBillByDateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptBillByDateBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmFilePatientBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmFilePatientBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmFilePatientBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmFilePatientBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmPropertiesBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmPropertiesBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmPropertiesBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmPropertiesBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_ChangeServicePrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ChangeServicePrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_ChangeServicePrice", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ChangeServicePrice", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_btnBackup_Restore", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "btnBackup_Restore", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_btnBackup_Restore", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "btnBackup_Restore", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Surgery", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Surgery", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Surgery", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Surgery", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_BookingVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BookingVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_BookingVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BookingVisits", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_RptVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_RptVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptVisits", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_SecretaryVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SecretaryVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_SecretaryVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SecretaryVisits", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DoctorVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DoctorVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorVisits", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatientSurgery", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientSurgery", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatientSurgery", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientSurgery", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_BtnFrmRptReb7ya", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BtnFrmRptReb7ya", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_BtnFrmRptReb7ya", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BtnFrmRptReb7ya", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_BtnFrmRptCompanies_Services", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BtnFrmRptCompanies_Services", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_BtnFrmRptCompanies_Services", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BtnFrmRptCompanies_Services", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_BtnFrmSell", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BtnFrmSell", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_BtnFrmSell", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BtnFrmSell", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSellByDateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSellByDateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptSellByDateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSellByDateBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatientAccountUpdateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientAccountUpdateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatientAccountUpdateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientAccountUpdateBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatientServiceUpdateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientServiceUpdateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatientServiceUpdateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientServiceUpdateBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmInventoryRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmInventoryRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmInventoryRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmInventoryRptBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmLimitOrderRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmLimitOrderRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmLimitOrderRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmLimitOrderRptBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmInoculationBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmInoculationBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmInoculationBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmInoculationBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmPatientInoculationBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmPatientInoculationBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmPatientInoculationBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmPatientInoculationBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmAssistantRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmAssistantRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmAssistantRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmAssistantRptBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptPatientDebtBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptPatientDebtBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptPatientDebtBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptPatientDebtBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_doctorAcountBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "doctorAcountBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_doctorAcountBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "doctorAcountBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmBillBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmBillBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmBillBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmBillBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmVisitMedicalRepBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmVisitMedicalRepBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmVisitMedicalRepBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmVisitMedicalRepBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_AppointmentspBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AppointmentspBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_AppointmentspBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AppointmentspBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSurgeryBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSurgeryBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptSurgeryBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSurgeryBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSpecialBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSpecialBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptSpecialBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSpecialBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_CompanyPayBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "CompanyPayBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_CompanyPayBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "CompanyPayBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptCompanyAcountBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptCompanyAcountBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptCompanyAcountBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptCompanyAcountBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_AssistantAccountBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AssistantAccountBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_AssistantAccountBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AssistantAccountBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_AssistantAcountDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AssistantAcountDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_AssistantAcountDate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AssistantAcountDate", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_RptAssistantPaymentBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptAssistantPaymentBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_RptAssistantPaymentBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptAssistantPaymentBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@userId", System.Data.SqlDbType.Int, 4, "userId")
		});
		sqlDeleteCommand2.CommandText = resources.GetString("sqlDeleteCommand2.CommandText");
		sqlDeleteCommand2.Connection = sqlConnection2;
		sqlDeleteCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[163]
		{
			new System.Data.SqlClient.SqlParameter("@Original_userId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userId", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_EmpID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EmpID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_EmpID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EmpID", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_userName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "userName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_userName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userName", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_userPassward", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "userPassward", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_userPassward", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userPassward", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_AddEmployee", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AddEmployee", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_AddEmployee", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AddEmployee", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_AddPatient", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AddPatient", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_AddPatient", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AddPatient", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Appointment", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Appointment", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Appointment", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Appointment", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DoctorPatientList", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorPatientList", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DoctorPatientList", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorPatientList", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_SecretaryPatientList", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SecretaryPatientList", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_SecretaryPatientList", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SecretaryPatientList", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DentalData", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalData", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DentalData", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalData", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DoctorAccount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorAccount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DoctorAccount", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorAccount", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_SearchPatient", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SearchPatient", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_SearchPatient", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SearchPatient", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Company", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Company", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Company", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Company", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatientPay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientPay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatientPay", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientPay", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatientAccount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientAccount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatientAccount", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientAccount", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatientXray", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientXray", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatientXray", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientXray", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Permission", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Permission", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Permission", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Permission", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatAccountRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatAccountRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatAccountRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatAccountRpt", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_ALLPatAccountRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ALLPatAccountRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_ALLPatAccountRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ALLPatAccountRpt", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DoctorAccountRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorAccountRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DoctorAccountRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorAccountRpt", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DoctorPaymentRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorPaymentRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DoctorPaymentRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorPaymentRpt", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_MovOfPatSTrpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MovOfPatSTrpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_MovOfPatSTrpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MovOfPatSTrpt", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_MovOfPatStbyDr", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MovOfPatStbyDr", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_MovOfPatStbyDr", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MovOfPatStbyDr", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Expenses", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Expenses", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Expenses", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Expenses", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Revenues", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Revenues", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Revenues", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Revenues", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_RptExpenses", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptExpenses", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_RptExpenses", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptExpenses", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_RptRevenues", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptRevenues", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_RptRevenues", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptRevenues", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_RptStockMove", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptStockMove", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_RptStockMove", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptStockMove", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DoctorBackReserve", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorBackReserve", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DoctorBackReserve", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorBackReserve", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_SecretaryBackReserve", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SecretaryBackReserve", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_SecretaryBackReserve", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SecretaryBackReserve", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_UpdateRebackdate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "UpdateRebackdate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_UpdateRebackdate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "UpdateRebackdate", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_medicineFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "medicineFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_medicineFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "medicineFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PrescriptionFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PrescriptionFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PrescriptionFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PrescriptionFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_ItemsFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemsFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_ItemsFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemsFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_SupplierBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_SupplierBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_IncomingBillFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "IncomingBillFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_IncomingBillFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "IncomingBillFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmSupplierAccountsBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmSupplierAccountsBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmSupplierAccountsBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmSupplierAccountsBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FormSupplier5Btn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FormSupplier5Btn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FormSupplier5Btn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FormSupplier5Btn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmBillIncomeRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmBillIncomeRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmBillIncomeRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmBillIncomeRptBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_OldServicesRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "OldServicesRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_OldServicesRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "OldServicesRptFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_NetDailyClinicRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NetDailyClinicRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_NetDailyClinicRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NetDailyClinicRptFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_ClinicMonthGraphRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicMonthGraphRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_ClinicMonthGraphRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicMonthGraphRptFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DailymeasureRotFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DailymeasureRotFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DailymeasureRotFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DailymeasureRotFrmBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_RptFrmSearchMedicine", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptFrmSearchMedicine", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_RptFrmSearchMedicine", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptFrmSearchMedicine", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_ServicePatientBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ServicePatientBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_ServicePatientBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ServicePatientBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_MainComplaintBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MainComplaintBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_MainComplaintBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MainComplaintBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_SahbItemsBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SahbItemsBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_SahbItemsBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SahbItemsBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSahbItemBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSahbItemBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptSahbItemBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSahbItemBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptBillByDateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptBillByDateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptBillByDateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptBillByDateBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmFilePatientBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmFilePatientBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmFilePatientBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmFilePatientBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmPropertiesBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmPropertiesBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmPropertiesBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmPropertiesBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_ChangeServicePrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ChangeServicePrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_ChangeServicePrice", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ChangeServicePrice", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_btnBackup_Restore", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "btnBackup_Restore", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_btnBackup_Restore", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "btnBackup_Restore", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Surgery", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Surgery", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Surgery", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Surgery", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_BookingVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BookingVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_BookingVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BookingVisits", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_RptVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_RptVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptVisits", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_SecretaryVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SecretaryVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_SecretaryVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SecretaryVisits", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DoctorVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DoctorVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorVisits", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatientSurgery", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientSurgery", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatientSurgery", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientSurgery", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_BtnFrmRptReb7ya", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BtnFrmRptReb7ya", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_BtnFrmRptReb7ya", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BtnFrmRptReb7ya", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_BtnFrmRptCompanies_Services", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BtnFrmRptCompanies_Services", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_BtnFrmRptCompanies_Services", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BtnFrmRptCompanies_Services", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_BtnFrmSell", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BtnFrmSell", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_BtnFrmSell", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BtnFrmSell", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSellByDateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSellByDateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptSellByDateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSellByDateBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatientAccountUpdateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientAccountUpdateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatientAccountUpdateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientAccountUpdateBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_PatientServiceUpdateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientServiceUpdateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_PatientServiceUpdateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientServiceUpdateBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmInventoryRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmInventoryRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmInventoryRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmInventoryRptBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmLimitOrderRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmLimitOrderRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmLimitOrderRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmLimitOrderRptBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmInoculationBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmInoculationBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmInoculationBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmInoculationBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmPatientInoculationBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmPatientInoculationBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmPatientInoculationBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmPatientInoculationBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmAssistantRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmAssistantRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmAssistantRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmAssistantRptBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptPatientDebtBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptPatientDebtBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptPatientDebtBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptPatientDebtBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_doctorAcountBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "doctorAcountBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_doctorAcountBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "doctorAcountBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmBillBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmBillBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmBillBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmBillBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmVisitMedicalRepBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmVisitMedicalRepBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmVisitMedicalRepBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmVisitMedicalRepBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_AppointmentspBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AppointmentspBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_AppointmentspBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AppointmentspBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSurgeryBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSurgeryBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptSurgeryBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSurgeryBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSpecialBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSpecialBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptSpecialBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSpecialBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_CompanyPayBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "CompanyPayBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_CompanyPayBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "CompanyPayBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptCompanyAcountBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptCompanyAcountBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FrmRptCompanyAcountBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptCompanyAcountBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_AssistantAccountBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AssistantAccountBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_AssistantAccountBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AssistantAccountBtn", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_AssistantAcountDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AssistantAcountDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_AssistantAcountDate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AssistantAcountDate", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_RptAssistantPaymentBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptAssistantPaymentBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_RptAssistantPaymentBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptAssistantPaymentBtn", System.Data.DataRowVersion.Original, null)
		});
		sqlDataAdapter2.DeleteCommand = sqlDeleteCommand2;
		sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
		sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
		sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
		{
			new System.Data.Common.DataTableMapping("Table", "users", new System.Data.Common.DataColumnMapping[82]
			{
				new System.Data.Common.DataColumnMapping("userId", "userId"),
				new System.Data.Common.DataColumnMapping("EmpID", "EmpID"),
				new System.Data.Common.DataColumnMapping("userName", "userName"),
				new System.Data.Common.DataColumnMapping("userPassward", "userPassward"),
				new System.Data.Common.DataColumnMapping("AddEmployee", "AddEmployee"),
				new System.Data.Common.DataColumnMapping("AddPatient", "AddPatient"),
				new System.Data.Common.DataColumnMapping("Appointment", "Appointment"),
				new System.Data.Common.DataColumnMapping("DoctorPatientList", "DoctorPatientList"),
				new System.Data.Common.DataColumnMapping("SecretaryPatientList", "SecretaryPatientList"),
				new System.Data.Common.DataColumnMapping("DentalData", "DentalData"),
				new System.Data.Common.DataColumnMapping("DoctorAccount", "DoctorAccount"),
				new System.Data.Common.DataColumnMapping("SearchPatient", "SearchPatient"),
				new System.Data.Common.DataColumnMapping("Company", "Company"),
				new System.Data.Common.DataColumnMapping("PatientPay", "PatientPay"),
				new System.Data.Common.DataColumnMapping("PatientAccount", "PatientAccount"),
				new System.Data.Common.DataColumnMapping("PatientXray", "PatientXray"),
				new System.Data.Common.DataColumnMapping("Permission", "Permission"),
				new System.Data.Common.DataColumnMapping("PatAccountRpt", "PatAccountRpt"),
				new System.Data.Common.DataColumnMapping("ALLPatAccountRpt", "ALLPatAccountRpt"),
				new System.Data.Common.DataColumnMapping("DoctorAccountRpt", "DoctorAccountRpt"),
				new System.Data.Common.DataColumnMapping("DoctorPaymentRpt", "DoctorPaymentRpt"),
				new System.Data.Common.DataColumnMapping("MovOfPatSTrpt", "MovOfPatSTrpt"),
				new System.Data.Common.DataColumnMapping("MovOfPatStbyDr", "MovOfPatStbyDr"),
				new System.Data.Common.DataColumnMapping("Expenses", "Expenses"),
				new System.Data.Common.DataColumnMapping("Revenues", "Revenues"),
				new System.Data.Common.DataColumnMapping("RptExpenses", "RptExpenses"),
				new System.Data.Common.DataColumnMapping("RptRevenues", "RptRevenues"),
				new System.Data.Common.DataColumnMapping("RptStockMove", "RptStockMove"),
				new System.Data.Common.DataColumnMapping("DoctorBackReserve", "DoctorBackReserve"),
				new System.Data.Common.DataColumnMapping("SecretaryBackReserve", "SecretaryBackReserve"),
				new System.Data.Common.DataColumnMapping("UpdateRebackdate", "UpdateRebackdate"),
				new System.Data.Common.DataColumnMapping("medicineFrmBtn", "medicineFrmBtn"),
				new System.Data.Common.DataColumnMapping("PrescriptionFrmBtn", "PrescriptionFrmBtn"),
				new System.Data.Common.DataColumnMapping("ItemsFrmBtn", "ItemsFrmBtn"),
				new System.Data.Common.DataColumnMapping("SupplierBtn", "SupplierBtn"),
				new System.Data.Common.DataColumnMapping("IncomingBillFrmBtn", "IncomingBillFrmBtn"),
				new System.Data.Common.DataColumnMapping("FrmSupplierAccountsBtn", "FrmSupplierAccountsBtn"),
				new System.Data.Common.DataColumnMapping("FormSupplier5Btn", "FormSupplier5Btn"),
				new System.Data.Common.DataColumnMapping("FrmBillIncomeRptBtn", "FrmBillIncomeRptBtn"),
				new System.Data.Common.DataColumnMapping("OldServicesRptFrmBtn", "OldServicesRptFrmBtn"),
				new System.Data.Common.DataColumnMapping("NetDailyClinicRptFrmBtn", "NetDailyClinicRptFrmBtn"),
				new System.Data.Common.DataColumnMapping("ClinicMonthGraphRptFrmBtn", "ClinicMonthGraphRptFrmBtn"),
				new System.Data.Common.DataColumnMapping("DailymeasureRotFrmBtn", "DailymeasureRotFrmBtn"),
				new System.Data.Common.DataColumnMapping("RptFrmSearchMedicine", "RptFrmSearchMedicine"),
				new System.Data.Common.DataColumnMapping("ServicePatientBtn", "ServicePatientBtn"),
				new System.Data.Common.DataColumnMapping("MainComplaintBtn", "MainComplaintBtn"),
				new System.Data.Common.DataColumnMapping("SahbItemsBtn", "SahbItemsBtn"),
				new System.Data.Common.DataColumnMapping("FrmRptSahbItemBtn", "FrmRptSahbItemBtn"),
				new System.Data.Common.DataColumnMapping("FrmRptBillByDateBtn", "FrmRptBillByDateBtn"),
				new System.Data.Common.DataColumnMapping("FrmFilePatientBtn", "FrmFilePatientBtn"),
				new System.Data.Common.DataColumnMapping("FrmPropertiesBtn", "FrmPropertiesBtn"),
				new System.Data.Common.DataColumnMapping("ChangeServicePrice", "ChangeServicePrice"),
				new System.Data.Common.DataColumnMapping("btnBackup_Restore", "btnBackup_Restore"),
				new System.Data.Common.DataColumnMapping("Surgery", "Surgery"),
				new System.Data.Common.DataColumnMapping("BookingVisits", "BookingVisits"),
				new System.Data.Common.DataColumnMapping("RptVisits", "RptVisits"),
				new System.Data.Common.DataColumnMapping("SecretaryVisits", "SecretaryVisits"),
				new System.Data.Common.DataColumnMapping("DoctorVisits", "DoctorVisits"),
				new System.Data.Common.DataColumnMapping("PatientSurgery", "PatientSurgery"),
				new System.Data.Common.DataColumnMapping("BtnFrmRptReb7ya", "BtnFrmRptReb7ya"),
				new System.Data.Common.DataColumnMapping("BtnFrmRptCompanies_Services", "BtnFrmRptCompanies_Services"),
				new System.Data.Common.DataColumnMapping("BtnFrmSell", "BtnFrmSell"),
				new System.Data.Common.DataColumnMapping("FrmRptSellByDateBtn", "FrmRptSellByDateBtn"),
				new System.Data.Common.DataColumnMapping("PatientAccountUpdateBtn", "PatientAccountUpdateBtn"),
				new System.Data.Common.DataColumnMapping("PatientServiceUpdateBtn", "PatientServiceUpdateBtn"),
				new System.Data.Common.DataColumnMapping("FrmInventoryRptBtn", "FrmInventoryRptBtn"),
				new System.Data.Common.DataColumnMapping("FrmLimitOrderRptBtn", "FrmLimitOrderRptBtn"),
				new System.Data.Common.DataColumnMapping("FrmInoculationBtn", "FrmInoculationBtn"),
				new System.Data.Common.DataColumnMapping("FrmPatientInoculationBtn", "FrmPatientInoculationBtn"),
				new System.Data.Common.DataColumnMapping("FrmAssistantRptBtn", "FrmAssistantRptBtn"),
				new System.Data.Common.DataColumnMapping("FrmRptPatientDebtBtn", "FrmRptPatientDebtBtn"),
				new System.Data.Common.DataColumnMapping("doctorAcountBtn", "doctorAcountBtn"),
				new System.Data.Common.DataColumnMapping("FrmBillBtn", "FrmBillBtn"),
				new System.Data.Common.DataColumnMapping("FrmVisitMedicalRepBtn", "FrmVisitMedicalRepBtn"),
				new System.Data.Common.DataColumnMapping("AppointmentspBtn", "AppointmentspBtn"),
				new System.Data.Common.DataColumnMapping("FrmRptSurgeryBtn", "FrmRptSurgeryBtn"),
				new System.Data.Common.DataColumnMapping("FrmRptSpecialBtn", "FrmRptSpecialBtn"),
				new System.Data.Common.DataColumnMapping("CompanyPayBtn", "CompanyPayBtn"),
				new System.Data.Common.DataColumnMapping("FrmRptCompanyAcountBtn", "FrmRptCompanyAcountBtn"),
				new System.Data.Common.DataColumnMapping("AssistantAccountBtn", "AssistantAccountBtn"),
				new System.Data.Common.DataColumnMapping("AssistantAcountDate", "AssistantAcountDate"),
				new System.Data.Common.DataColumnMapping("RptAssistantPaymentBtn", "RptAssistantPaymentBtn")
			})
		});
		sqlDataAdapter2.UpdateCommand = sqlUpdateCommand2;
		sqlSelectCommand3.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
		sqlSelectCommand3.Connection = sqlConnection3;
		sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
		sqlConnection3.FireInfoMessageEventOnUserErrors = false;
		sqlInsertCommand3.CommandText = resources.GetString("sqlInsertCommand3.CommandText");
		sqlInsertCommand3.Connection = sqlConnection3;
		sqlInsertCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[15]
		{
			new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
			new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
			new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
			new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
			new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
			new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
			new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
			new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
			new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
			new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
			new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
			new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
			new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
			new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
			new System.Data.SqlClient.SqlParameter("@GeneralClinic", System.Data.SqlDbType.Bit, 0, "GeneralClinic")
		});
		sqlUpdateCommand3.CommandText = resources.GetString("sqlUpdateCommand3.CommandText");
		sqlUpdateCommand3.Connection = sqlConnection3;
		sqlUpdateCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[37]
		{
			new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
			new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
			new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
			new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
			new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
			new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
			new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
			new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
			new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
			new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
			new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
			new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
			new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
			new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
			new System.Data.SqlClient.SqlParameter("@GeneralClinic", System.Data.SqlDbType.Bit, 0, "GeneralClinic"),
			new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_GeneralClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_GeneralClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
		});
		sqlDeleteCommand3.CommandText = resources.GetString("sqlDeleteCommand3.CommandText");
		sqlDeleteCommand3.Connection = sqlConnection3;
		sqlDeleteCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
		{
			new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
			new System.Data.SqlClient.SqlParameter("@IsNull_GeneralClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
			new System.Data.SqlClient.SqlParameter("@Original_GeneralClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, null)
		});
		sqlDataAdapter3.DeleteCommand = sqlDeleteCommand3;
		sqlDataAdapter3.InsertCommand = sqlInsertCommand3;
		sqlDataAdapter3.SelectCommand = sqlSelectCommand3;
		sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
		{
			new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[16]
			{
				new System.Data.Common.DataColumnMapping("ID", "ID"),
				new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
				new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
				new System.Data.Common.DataColumnMapping("DTel", "DTel"),
				new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
				new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
				new System.Data.Common.DataColumnMapping("DSite", "DSite"),
				new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
				new System.Data.Common.DataColumnMapping("WorkData", "WorkData"),
				new System.Data.Common.DataColumnMapping("Powred", "Powred"),
				new System.Data.Common.DataColumnMapping("ClinicType", "ClinicType"),
				new System.Data.Common.DataColumnMapping("EyeClinic", "EyeClinic"),
				new System.Data.Common.DataColumnMapping("FemaleClinic", "FemaleClinic"),
				new System.Data.Common.DataColumnMapping("NaturalClinic", "NaturalClinic"),
				new System.Data.Common.DataColumnMapping("EnName", "EnName"),
				new System.Data.Common.DataColumnMapping("GeneralClinic", "GeneralClinic")
			})
		});
		sqlDataAdapter3.UpdateCommand = sqlUpdateCommand3;
		resources.ApplyResources(this, "$this");
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.Controls.Add(groupBox3);
		base.Controls.Add(groupBox1);
		base.Controls.Add(groupBox2);
		base.Name = "FrmLoginUser";
		base.Load += new System.EventHandler(FrmLoginUser_Load);
		groupBox3.ResumeLayout(false);
		groupBox3.PerformLayout();
		groupBox1.ResumeLayout(false);
		groupBox1.PerformLayout();
		groupBox2.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
		ResumeLayout(false);
	}

	public FrmLoginUser()
	{
		InitializeComponent();
	}

	public FrmLoginUser(DateTime d1, DateTime d2, string FileName)
	{
		InitializeComponent();
		sqlConnection1.ConnectionString = Codes.ConnectionStr;
		sqlConnection2.ConnectionString = Codes.ConnectionStr;
		sqlConnection3.ConnectionString = Codes.ConnectionStr;
		sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
		sqlDataAdapter1.SelectCommand.CommandText = string.Concat("select * from LoginUsers where Date between '", d1.ToString("MM/dd/yyyy"), "' and '", d2, "'");
		sqlDataAdapter1.Fill(dataSet11);
		sqlDataAdapter2.Fill(dataSet11);
		sqlDataAdapter3.Fill(dataSet11);
		dataSet11.ReportData.Rows.Add(1, "", d1.ToString("MM/dd/yyyy"), d2.ToString("MM/dd/yyyy"));
		RptLoginUser rpt = new RptLoginUser();
		rpt.SetDataSource(dataSet11);
		DiskFileDestinationOptions CrDiskFileDestinationOptions = new DiskFileDestinationOptions();
		PdfRtfWordFormatOptions CrFormatTypeOptions = new PdfRtfWordFormatOptions();
		CrDiskFileDestinationOptions.DiskFileName = FileName;
		ExportOptions CrExportOptions = rpt.ExportOptions;
		CrExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
		CrExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
		CrExportOptions.DestinationOptions = CrDiskFileDestinationOptions;
		CrExportOptions.FormatOptions = CrFormatTypeOptions;
		rpt.Export();
	}

	private void FrmLoginUser_Load(object sender, EventArgs e)
	{
		try
		{
			DataTable dt = Codes.Search2("select userId,userName from users");
			DataRow row = dt.NewRow();
			if (Settings.Default.Language == "en-GB")
			{
				row["userName"] = "All";
			}
			else
			{
				row["userName"] = "الكل";
			}
			dt.Rows.InsertAt(row, 0);
			comboBox1.DataSource = dt;
			comboBox1.ValueMember = "userId";
			comboBox1.DisplayMember = "userName";
		}
		catch
		{
		}
	}

	private void button1_Click(object sender, EventArgs e)
	{
		try
		{
			dataSet11.Clear();
			if (comboBox1.SelectedIndex == -1)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please choose User Name");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم المستخدم");
				}
			}
			else if (comboBox1.SelectedIndex == 0)
			{
				sqlConnection1.ConnectionString = Codes.ConnectionStr;
				sqlConnection2.ConnectionString = Codes.ConnectionStr;
				sqlConnection3.ConnectionString = Codes.ConnectionStr;
				sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter1.SelectCommand.CommandText = string.Concat("select * from LoginUsers where Date between '", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "' and '", dateTimePicker2.Value, "'");
				sqlDataAdapter1.Fill(dataSet11);
				sqlDataAdapter2.Fill(dataSet11);
				sqlDataAdapter3.Fill(dataSet11);
				dataSet11.ReportData.Rows.Add(1, "", dateTimePicker1.Value.ToString("MM/dd/yyyy"), dateTimePicker2.Value.ToString("MM/dd/yyyy"));
				RptLoginUser rpt = new RptLoginUser();
				rpt.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = rpt;
			}
			else
			{
				sqlConnection1.ConnectionString = Codes.ConnectionStr;
				sqlConnection2.ConnectionString = Codes.ConnectionStr;
				sqlConnection3.ConnectionString = Codes.ConnectionStr;
				sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter1.SelectCommand.CommandText = string.Concat("select * from LoginUsers where userId = '", comboBox1.SelectedValue.ToString(), "' and Date between '", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "' and '", dateTimePicker2.Value, "'");
				sqlDataAdapter1.Fill(dataSet11);
				sqlDataAdapter2.Fill(dataSet11);
				sqlDataAdapter3.Fill(dataSet11);
				dataSet11.ReportData.Rows.Add(1, "", dateTimePicker1.Value.ToString("MM/dd/yyyy"), dateTimePicker2.Value.ToString("MM/dd/yyyy"));
				RptLoginUser rpt = new RptLoginUser();
				rpt.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = rpt;
			}
		}
		catch
		{
		}
	}
}
