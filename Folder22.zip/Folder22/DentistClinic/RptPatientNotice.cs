using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class RptPatientNotice : Form
	{
		private ClassDataBase Query;

		private dataClass sql;

		private IContainer components = null;

		private GroupBox groupBox2;

		private CrystalReportViewer crystalReportViewer1;

		private GroupBox groupBox4;

		private ComboBox search_pName;

		private Label label10;

		private DateTimePicker DateTo;

		private Label label1;

		private DateTimePicker DateFrom;

		private Label label8;

		private Label label9;

		private ComboBox Search_type;

		private Button ViewRptBtn;

		private SqlCommand sqlSelectCommand4;

		private SqlConnection sqlConnection4;

		private SqlCommand sqlInsertCommand4;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter4;

		private DataSet1 dataSet11;

		private SqlConnection sqlConnection1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlCommand1;

		private SqlCommand sqlCommand2;

		private SqlCommand sqlCommand3;

		private SqlCommand sqlCommand4;

		public RptPatientNotice()
		{
			InitializeComponent();
			Query = new ClassDataBase(".\\sqlExpress");
			sql = new dataClass(".\\sqlExpress");
		}

		private void RptPatientNotice_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = Query.GetTableText("select ID,PName from PatientData order by PName");
				search_pName.DataSource = tableText;
				search_pName.DisplayMember = tableText.Columns[1].ToString();
				search_pName.ValueMember = tableText.Columns[0].ToString();
				search_pName.SelectedIndex = 0;
				Search_type.SelectedIndex = 0;
			}
			catch
			{
			}
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = Query.GetTableText(string.Concat("select * FROM PatientNotice where PatientID=", search_pName.SelectedValue, " and ChooseDate Between'", DateFrom.Value.ToString("MM/dd/yyyy"), "' and'", DateTo.Value.ToString("MM/dd/yyyy"), "'"));
				if (tableText.Rows.Count > 0)
				{
					sqlConnection1.ConnectionString = Query.ConnectionStr;
					sqlConnection4.ConnectionString = Query.ConnectionStr;
					dataSet11.Clear();
					if (Search_type.SelectedIndex != 0)
					{
						sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
						sqlDataAdapter1.SelectCommand.CommandText = string.Concat("select * FROM PatientNotice where PatientID=", search_pName.SelectedValue, " and NoteType='", Search_type.Text, "' and ChooseDate Between'", DateFrom.Value.ToString("MM/dd/yyyy"), "' and'", DateTo.Value.ToString("MM/dd/yyyy"), "'");
					}
					else
					{
						sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
						sqlDataAdapter1.SelectCommand.CommandText = string.Concat("select * FROM PatientNotice where PatientID=", search_pName.SelectedValue, " and ChooseDate Between'", DateFrom.Value.ToString("MM/dd/yyyy"), "' and'", DateTo.Value.ToString("MM/dd/yyyy"), "'");
					}
					sqlDataAdapter4.Fill(dataSet11);
					sqlDataAdapter1.Fill(dataSet11);
					((DataTable)(object)dataSet11.ReportData).Rows.Add(Convert.ToInt32(search_pName.SelectedValue.ToString()), search_pName.Text, DateFrom.Value, DateTo.Value);
					PatientNoticeRpt patientNoticeRpt = new PatientNoticeRpt();
					patientNoticeRpt.SetDataSource(dataSet11);
					crystalReportViewer1.ReportSource = patientNoticeRpt;
				}
				else
				{
					crystalReportViewer1.ReportSource = null;
					MessageBox.Show("لا يوجد بيانات لهذا المريض");
				}
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.RptPatientNotice));
			groupBox2 = new System.Windows.Forms.GroupBox();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			groupBox4 = new System.Windows.Forms.GroupBox();
			ViewRptBtn = new System.Windows.Forms.Button();
			search_pName = new System.Windows.Forms.ComboBox();
			label10 = new System.Windows.Forms.Label();
			DateTo = new System.Windows.Forms.DateTimePicker();
			label1 = new System.Windows.Forms.Label();
			DateFrom = new System.Windows.Forms.DateTimePicker();
			label8 = new System.Windows.Forms.Label();
			label9 = new System.Windows.Forms.Label();
			Search_type = new System.Windows.Forms.ComboBox();
			sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlConnection4 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter4 = new System.Data.SqlClient.SqlDataAdapter();
			dataSet11 = new DataSet1();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlCommand4 = new System.Data.SqlClient.SqlCommand();
			groupBox2.SuspendLayout();
			groupBox4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(ViewRptBtn);
			groupBox4.Controls.Add(search_pName);
			groupBox4.Controls.Add(label10);
			groupBox4.Controls.Add(DateTo);
			groupBox4.Controls.Add(label1);
			groupBox4.Controls.Add(DateFrom);
			groupBox4.Controls.Add(label8);
			groupBox4.Controls.Add(label9);
			groupBox4.Controls.Add(Search_type);
			groupBox4.Font = null;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			ViewRptBtn.AccessibleDescription = null;
			ViewRptBtn.AccessibleName = null;
			resources.ApplyResources(ViewRptBtn, "ViewRptBtn");
			ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
			ViewRptBtn.BackgroundImage = null;
			ViewRptBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			ViewRptBtn.Name = "ViewRptBtn";
			ViewRptBtn.UseVisualStyleBackColor = false;
			ViewRptBtn.Click += new System.EventHandler(ViewRptBtn_Click);
			search_pName.AccessibleDescription = null;
			search_pName.AccessibleName = null;
			resources.ApplyResources(search_pName, "search_pName");
			search_pName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			search_pName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			search_pName.BackgroundImage = null;
			search_pName.FormattingEnabled = true;
			search_pName.Name = "search_pName";
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "label10");
			label10.ForeColor = System.Drawing.Color.Black;
			label10.Name = "label10";
			DateTo.AccessibleDescription = null;
			DateTo.AccessibleName = null;
			resources.ApplyResources(DateTo, "DateTo");
			DateTo.BackgroundImage = null;
			DateTo.CalendarFont = null;
			DateTo.CustomFormat = null;
			DateTo.Name = "DateTo";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.ForeColor = System.Drawing.Color.Black;
			label1.Name = "label1";
			DateFrom.AccessibleDescription = null;
			DateFrom.AccessibleName = null;
			resources.ApplyResources(DateFrom, "DateFrom");
			DateFrom.BackgroundImage = null;
			DateFrom.CalendarFont = null;
			DateFrom.CustomFormat = null;
			DateFrom.Name = "DateFrom";
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "label8");
			label8.ForeColor = System.Drawing.Color.Black;
			label8.Name = "label8";
			label9.AccessibleDescription = null;
			label9.AccessibleName = null;
			resources.ApplyResources(label9, "label9");
			label9.ForeColor = System.Drawing.Color.Black;
			label9.Name = "label9";
			Search_type.AccessibleDescription = null;
			Search_type.AccessibleName = null;
			resources.ApplyResources(Search_type, "Search_type");
			Search_type.BackgroundImage = null;
			Search_type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			Search_type.FormattingEnabled = true;
			Search_type.Items.AddRange(new object[3]
			{
				resources.GetString("Search_type.Items"),
				resources.GetString("Search_type.Items1"),
				resources.GetString("Search_type.Items2")
			});
			Search_type.Name = "Search_type";
			sqlSelectCommand4.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand4.Connection = sqlConnection4;
			sqlConnection4.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection4.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand4.CommandText = resources.GetString("sqlInsertCommand4.CommandText");
			sqlInsertCommand4.Connection = sqlConnection4;
			sqlInsertCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[16]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
				new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
				new System.Data.SqlClient.SqlParameter("@GeneralClinic", System.Data.SqlDbType.Bit, 0, "GeneralClinic"),
				new System.Data.SqlClient.SqlParameter("@HeartClinic", System.Data.SqlDbType.Bit, 0, "HeartClinic")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection4;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[40]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
				new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
				new System.Data.SqlClient.SqlParameter("@GeneralClinic", System.Data.SqlDbType.Bit, 0, "GeneralClinic"),
				new System.Data.SqlClient.SqlParameter("@HeartClinic", System.Data.SqlDbType.Bit, 0, "HeartClinic"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_GeneralClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_GeneralClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_HeartClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "HeartClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_HeartClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "HeartClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection4;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[23]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_GeneralClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_GeneralClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_HeartClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "HeartClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_HeartClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "HeartClinic", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter4.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter4.InsertCommand = sqlInsertCommand4;
			sqlDataAdapter4.SelectCommand = sqlSelectCommand4;
			sqlDataAdapter4.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[17]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData"),
					new System.Data.Common.DataColumnMapping("Powred", "Powred"),
					new System.Data.Common.DataColumnMapping("ClinicType", "ClinicType"),
					new System.Data.Common.DataColumnMapping("EyeClinic", "EyeClinic"),
					new System.Data.Common.DataColumnMapping("FemaleClinic", "FemaleClinic"),
					new System.Data.Common.DataColumnMapping("NaturalClinic", "NaturalClinic"),
					new System.Data.Common.DataColumnMapping("EnName", "EnName"),
					new System.Data.Common.DataColumnMapping("GeneralClinic", "GeneralClinic"),
					new System.Data.Common.DataColumnMapping("HeartClinic", "HeartClinic")
				})
			});
			sqlDataAdapter4.UpdateCommand = sqlUpdateCommand1;
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlDataAdapter1.DeleteCommand = sqlCommand1;
			sqlDataAdapter1.InsertCommand = sqlCommand2;
			sqlDataAdapter1.SelectCommand = sqlCommand3;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientNotice", new System.Data.Common.DataColumnMapping[8]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("PatientID", "PatientID"),
					new System.Data.Common.DataColumnMapping("Amount", "Amount"),
					new System.Data.Common.DataColumnMapping("OPDate", "OPDate"),
					new System.Data.Common.DataColumnMapping("ChooseDate", "ChooseDate"),
					new System.Data.Common.DataColumnMapping("NoteType", "NoteType"),
					new System.Data.Common.DataColumnMapping("Note", "Note"),
					new System.Data.Common.DataColumnMapping("PAccount_ID", "PAccount_ID")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlCommand4;
			sqlCommand1.CommandText = resources.GetString("sqlCommand1.CommandText");
			sqlCommand1.Connection = sqlConnection1;
			sqlCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[8]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_Amount", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Amount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_OPDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "OPDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_OPDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "OPDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_ChooseDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ChooseDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PAccount_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PAccount_ID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PAccount_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PAccount_ID", System.Data.DataRowVersion.Original, null)
			});
			sqlCommand2.CommandText = resources.GetString("sqlCommand2.CommandText");
			sqlCommand2.Connection = sqlConnection1;
			sqlCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@PatientID", System.Data.SqlDbType.Int, 0, "PatientID"),
				new System.Data.SqlClient.SqlParameter("@Amount", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Amount", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@OPDate", System.Data.SqlDbType.DateTime, 0, "OPDate"),
				new System.Data.SqlClient.SqlParameter("@ChooseDate", System.Data.SqlDbType.DateTime, 0, "ChooseDate"),
				new System.Data.SqlClient.SqlParameter("@NoteType", System.Data.SqlDbType.NVarChar, 0, "NoteType"),
				new System.Data.SqlClient.SqlParameter("@Note", System.Data.SqlDbType.NVarChar, 0, "Note"),
				new System.Data.SqlClient.SqlParameter("@PAccount_ID", System.Data.SqlDbType.Int, 0, "PAccount_ID")
			});
			sqlCommand3.CommandText = "SELECT        PatientNotice.*\r\nFROM            PatientNotice";
			sqlCommand3.Connection = sqlConnection1;
			sqlCommand4.CommandText = resources.GetString("sqlCommand4.CommandText");
			sqlCommand4.Connection = sqlConnection1;
			sqlCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[16]
			{
				new System.Data.SqlClient.SqlParameter("@PatientID", System.Data.SqlDbType.Int, 0, "PatientID"),
				new System.Data.SqlClient.SqlParameter("@Amount", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Amount", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@OPDate", System.Data.SqlDbType.DateTime, 0, "OPDate"),
				new System.Data.SqlClient.SqlParameter("@ChooseDate", System.Data.SqlDbType.DateTime, 0, "ChooseDate"),
				new System.Data.SqlClient.SqlParameter("@NoteType", System.Data.SqlDbType.NVarChar, 0, "NoteType"),
				new System.Data.SqlClient.SqlParameter("@Note", System.Data.SqlDbType.NVarChar, 0, "Note"),
				new System.Data.SqlClient.SqlParameter("@PAccount_ID", System.Data.SqlDbType.Int, 0, "PAccount_ID"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_Amount", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Amount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_OPDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "OPDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_OPDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "OPDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_ChooseDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ChooseDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PAccount_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PAccount_ID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PAccount_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PAccount_ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(groupBox4);
			base.Controls.Add(groupBox2);
			Font = null;
			base.Name = "RptPatientNotice";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.Load += new System.EventHandler(RptPatientNotice_Load);
			groupBox2.ResumeLayout(false);
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}
	}
}
