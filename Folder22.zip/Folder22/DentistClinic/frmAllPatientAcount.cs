using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class frmAllPatientAcount : BaseForm
	{
		private ClassDataBase dc = new ClassDataBase(".\\sqlExpress");

		private IContainer components = null;

		private GroupBox groupBox1;

		private DateTimePicker date2;

		private DateTimePicker date1;

		private Label label3;

		private Label label2;

		private Button ViewRptBtn;

		private GroupBox groupBox2;

		private CrystalReportViewer crystalReportViewer1;

		private DataSet1 dataSet11;

		public frmAllPatientAcount()
		{
			InitializeComponent();
		}

		public frmAllPatientAcount(DateTime d1, DateTime d2, string FileName)
		{
			try
			{
				InitializeComponent();
				DataTable dataTable = new DataTable
				{
					Columns = { "PName", "TotalAmount", "Pay", "RemaningAmount" }
				};
				DataTable tableText = dc.GetTableText("select * from  PatientData where PatientData.Active = 'True'");
				for (int i = 0; i < tableText.Rows.Count; i++)
				{
					try
					{
						DataTable tableText2 = dc.GetTableText("select sum(Price) from PatientAccount where PatientId='" + Convert.ToInt32(tableText.Rows[i][0].ToString()) + "'and Date Between'" + d1.ToString("MM/dd/yyyy") + "'and'" + d2.ToString("MM/dd/yyyy") + "'");
						double num = Convert.ToDouble(tableText2.Rows[0][0].ToString());
						DataTable tableText3 = dc.GetTableText("select sum(PricePay) from PatientAccount where PatientId='" + Convert.ToInt32(tableText.Rows[i][0].ToString()) + "'and Date Between'" + d1.ToString("MM/dd/yyyy") + "'and'" + d2.ToString("MM/dd/yyyy") + "'");
						double num2 = Convert.ToDouble(tableText3.Rows[0][0].ToString());
						double num3 = num - num2;
						dataTable.Rows.Add(tableText.Rows[i][2].ToString(), num.ToString(), num2.ToString(), num3.ToString());
					}
					catch
					{
					}
				}
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					((DataTable)(object)dataSet11.DataTable1).Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString());
				}
				((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", d1, d2);
				AllPatientAccountRpt allPatientAccountRpt = new AllPatientAccountRpt();
				allPatientAccountRpt.SetDataSource(dataSet11);
				DiskFileDestinationOptions diskFileDestinationOptions = new DiskFileDestinationOptions();
				PdfRtfWordFormatOptions formatOptions = new PdfRtfWordFormatOptions();
				diskFileDestinationOptions.DiskFileName = FileName;
				ExportOptions exportOptions = allPatientAccountRpt.ExportOptions;
				exportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				exportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
				exportOptions.DestinationOptions = diskFileDestinationOptions;
				exportOptions.FormatOptions = formatOptions;
				allPatientAccountRpt.Export();
			}
			catch
			{
			}
		}

		private void frmAllPatientAcount_Load(object sender, EventArgs e)
		{
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			try
			{
				dataSet11.Clear();
				DataTable dataTable = new DataTable();
				dataTable.Columns.Add("PName");
				dataTable.Columns.Add("TotalAmount");
				dataTable.Columns.Add("Pay");
				dataTable.Columns.Add("RemaningAmount");
				DataTable tableText = dc.GetTableText("select * from  PatientData where PatientData.Active = 'True'");
				for (int i = 0; i < tableText.Rows.Count; i++)
				{
					try
					{
						DataTable tableText2 = dc.GetTableText("select sum(Price) from PatientAccount where PatientId='" + Convert.ToInt32(tableText.Rows[i][0].ToString()) + "'  and Bean<>'خدمة ثابتة' and Date Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "'");
						double num = Convert.ToDouble(tableText2.Rows[0][0].ToString());
						DataTable tableText3 = dc.GetTableText("select sum(PricePay) from PatientAccount where PatientId='" + Convert.ToInt32(tableText.Rows[i][0].ToString()) + "'  and Bean<>'خدمة ثابتة' and Date Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "'");
						double num2 = Convert.ToDouble(tableText3.Rows[0][0].ToString());
						double num3 = num - num2;
						dataTable.Rows.Add(tableText.Rows[i][2].ToString(), num.ToString(), num2.ToString(), num3.ToString());
					}
					catch
					{
					}
				}
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					((DataTable)(object)dataSet11.DataTable1).Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString());
				}
				((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value.ToString("MM/dd/yyyy"), date2.Value.ToString("MM/dd/yyyy"));
				AllPatientAccountRpt allPatientAccountRpt = new AllPatientAccountRpt();
				allPatientAccountRpt.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = allPatientAccountRpt;
			}
			catch
			{
			}
		}

		private void frmAllPatientAcount_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.frmAllPatientAcount));
			groupBox1 = new System.Windows.Forms.GroupBox();
			date2 = new System.Windows.Forms.DateTimePicker();
			date1 = new System.Windows.Forms.DateTimePicker();
			ViewRptBtn = new System.Windows.Forms.Button();
			label3 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			dataSet11 = new DataSet1();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(date2);
			groupBox1.Controls.Add(date1);
			groupBox1.Controls.Add(ViewRptBtn);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(label2);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			date2.AccessibleDescription = null;
			date2.AccessibleName = null;
			resources.ApplyResources(date2, "date2");
			date2.BackgroundImage = null;
			date2.CalendarFont = null;
			date2.Font = null;
			date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date2.Name = "date2";
			date1.AccessibleDescription = null;
			date1.AccessibleName = null;
			resources.ApplyResources(date1, "date1");
			date1.BackgroundImage = null;
			date1.CalendarFont = null;
			date1.Font = null;
			date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date1.Name = "date1";
			ViewRptBtn.AccessibleDescription = null;
			ViewRptBtn.AccessibleName = null;
			resources.ApplyResources(ViewRptBtn, "ViewRptBtn");
			ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
			ViewRptBtn.BackgroundImage = null;
			ViewRptBtn.Name = "ViewRptBtn";
			ViewRptBtn.UseVisualStyleBackColor = false;
			ViewRptBtn.Click += new System.EventHandler(ViewRptBtn_Click);
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "frmAllPatientAcount";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.Load += new System.EventHandler(frmAllPatientAcount_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(frmAllPatientAcount_KeyDown);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}
	}
}
