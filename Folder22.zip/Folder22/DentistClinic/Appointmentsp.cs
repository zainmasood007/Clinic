using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class Appointmentsp : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox4;

		private TextBox priceTextBox;

		private TextBox ChairTextBox;

		private Button saveBtn;

		private ComboBox doctorcomboBox;

		private TextBox apptextBox;

		private MaskedTextBox FromTextBox;

		private MaskedTextBox TOTextBox;

		private DateTimePicker regdateTimePicker1;

		private DateTimePicker appdateTimePicker1;

		private DateTimePicker recalldateTimePicker2;

		private Label label1;

		private GroupBox groupBox2;

		private Label label3;

		private DataSet1 dataSet11;

		private ComboBox StatusCom;

		private Panel StatusPanel;

		private CheckBox checkBox2;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private GroupBox groupBox6;

		private Label label6;

		private ComboBox comboBox2;

		private CheckBox checkBox3;

		private Button button2;

		private GroupBox groupBox7;

		private Button button3;

		private ComboBox commentTextBox;

		private GroupBox groupBox8;

		private DataGridView dataGridView2;

		private TextBox textBox4;

		private TextBox textBox5;

		private GroupBox groupBox3;

		private CheckBox checkBox11;

		private TextBox nameTextBox;

		private TextBox textBox66;

		private TextBox textBox2;

		private Label label15;

		private GroupBox groupBox1;

		private ComboBox sexComboBox;

		private TextBox addressTextBox;

		private Button button1;

		private ComboBox companycomboBox;

		private Label label69;

		private ComboBox comboBox7;

		private TextBox txtFileNo;

		private TextBox IDtextBox;

		private ComboBox comboCategory;

		private Panel PaidPanel;

		private TextBox EsalNoTxt;

		private Label label45;

		private Label label17;

		private TextBox Dariba;

		private Label label18;

		private TextBox AfterDariba;

		private Label label20;

		private TextBox textBox7;

		private Label label21;

		private TextBox textBox6;

		private Label label22;

		private CheckBox checkBox12;

		private Label label19;

		private Label label105;

		private TextBox textBoxDiscount;

		private TextBox textBox1;

		private Label label23;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Column2;

		private DataGridViewTextBoxColumn Column3;

		private DataGridViewTextBoxColumn Column4;

		private SqlConnection sqlConnection2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlCommand2;

		private SqlCommand sqlCommand3;

		private int appid;

		private int PatientID;

		private bool clinic;

		private decimal Total;

		private string PId;

		private string CompanyPrice;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private ClassDataBase dc;

		public static decimal TotalPrice;

		private GUI gui = new GUI();

		private double oldpric = 0.0;

		private dataClass codes;

		private string Patient = "";

		private bool b = true;
		private Label label10;
		private Label label9;
		private Label label7;
		private Label label4;
		private Label label;
		private Label label8;
		private Label label2;
		private Label label5;
		private Label label14;
		private Label label13;
		private Label label11;
		private Label label12;
		private Label label16;
		private string companyId = "";

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Appointmentsp));
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label105 = new System.Windows.Forms.Label();
            this.textBoxDiscount = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.PaidPanel = new System.Windows.Forms.Panel();
            this.EsalNoTxt = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.StatusPanel = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.StatusCom = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.recalldateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.regdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.appdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.ChairTextBox = new System.Windows.Forms.TextBox();
            this.TOTextBox = new System.Windows.Forms.MaskedTextBox();
            this.FromTextBox = new System.Windows.Forms.MaskedTextBox();
            this.apptextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.doctorcomboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.saveBtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataSet11 = new DataSet1();
            this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
            this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.Dariba = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.AfterDariba = new System.Windows.Forms.TextBox();
            this.comboCategory = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.commentTextBox = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.txtFileNo = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.companycomboBox = new System.Windows.Forms.ComboBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.sexComboBox = new System.Windows.Forms.ComboBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.IDtextBox = new System.Windows.Forms.TextBox();
            this.sqlConnection2 = new System.Data.SqlClient.SqlConnection();
            this.sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
            this.sqlCommand2 = new System.Data.SqlClient.SqlCommand();
            this.sqlCommand3 = new System.Data.SqlClient.SqlCommand();
            this.groupBox4.SuspendLayout();
            this.PaidPanel.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.label105);
            this.groupBox4.Controls.Add(this.textBoxDiscount);
            this.groupBox4.Controls.Add(this.textBox7);
            this.groupBox4.Controls.Add(this.textBox6);
            this.groupBox4.Controls.Add(this.PaidPanel);
            this.groupBox4.Controls.Add(this.label69);
            this.groupBox4.Controls.Add(this.comboBox7);
            this.groupBox4.Controls.Add(this.checkBox3);
            this.groupBox4.Controls.Add(this.comboBox2);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.checkBox2);
            this.groupBox4.Controls.Add(this.StatusPanel);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.StatusCom);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.recalldateTimePicker2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.priceTextBox);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label);
            this.groupBox4.Controls.Add(this.regdateTimePicker1);
            this.groupBox4.Controls.Add(this.appdateTimePicker1);
            this.groupBox4.Controls.Add(this.ChairTextBox);
            this.groupBox4.Controls.Add(this.TOTextBox);
            this.groupBox4.Controls.Add(this.FromTextBox);
            this.groupBox4.Controls.Add(this.apptextBox);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.doctorcomboBox);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Font = new System.Drawing.Font("Arial", 11.25F);
            this.groupBox4.ForeColor = System.Drawing.Color.Black;
            this.groupBox4.Location = new System.Drawing.Point(12, 158);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox4.Size = new System.Drawing.Size(759, 256);
            this.groupBox4.TabIndex = 76;
            this.groupBox4.TabStop = false;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.BackColor = System.Drawing.Color.Transparent;
            this.label105.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label105.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label105.Location = new System.Drawing.Point(298, 165);
            this.label105.Name = "label105";
            this.label105.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label105.Size = new System.Drawing.Size(40, 16);
            this.label105.TabIndex = 164;
            this.label105.Text = "الخصم:";
            // 
            // textBoxDiscount
            // 
            this.textBoxDiscount.Enabled = false;
            this.textBoxDiscount.Font = new System.Drawing.Font("Arial", 8.25F);
            this.textBoxDiscount.Location = new System.Drawing.Point(209, 162);
            this.textBoxDiscount.Name = "textBoxDiscount";
            this.textBoxDiscount.Size = new System.Drawing.Size(81, 20);
            this.textBoxDiscount.TabIndex = 163;
            this.textBoxDiscount.Text = "0";
            this.textBoxDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label20.ForeColor = System.Drawing.Color.Firebrick;
            this.label20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label20.Location = new System.Drawing.Point(107, 165);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(72, 16);
            this.label20.TabIndex = 144;
            this.label20.Text = "السعر النهائي:";
            // 
            // textBox7
            // 
            this.textBox7.Enabled = false;
            this.textBox7.Font = new System.Drawing.Font("Arial", 11.25F);
            this.textBox7.Location = new System.Drawing.Point(24, 159);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(80, 25);
            this.textBox7.TabIndex = 142;
            this.textBox7.Text = "0";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label21.Location = new System.Drawing.Point(18, 135);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(21, 14);
            this.label21.TabIndex = 143;
            this.label21.Text = "%";
            // 
            // textBox6
            // 
            this.textBox6.Enabled = false;
            this.textBox6.Font = new System.Drawing.Font("Arial", 11.25F);
            this.textBox6.Location = new System.Drawing.Point(41, 128);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(63, 25);
            this.textBox6.TabIndex = 141;
            this.textBox6.Text = "0";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label22.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label22.Location = new System.Drawing.Point(104, 135);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(51, 16);
            this.label22.TabIndex = 140;
            this.label22.Text = "الضريبة :";
            // 
            // PaidPanel
            // 
            this.PaidPanel.BackColor = System.Drawing.Color.Transparent;
            this.PaidPanel.Controls.Add(this.EsalNoTxt);
            this.PaidPanel.Controls.Add(this.label45);
            this.PaidPanel.Location = new System.Drawing.Point(6, 217);
            this.PaidPanel.Name = "PaidPanel";
            this.PaidPanel.Size = new System.Drawing.Size(217, 27);
            this.PaidPanel.TabIndex = 131;
            this.PaidPanel.Visible = false;
            // 
            // EsalNoTxt
            // 
            this.EsalNoTxt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.EsalNoTxt.Enabled = false;
            this.EsalNoTxt.Location = new System.Drawing.Point(5, 1);
            this.EsalNoTxt.Name = "EsalNoTxt";
            this.EsalNoTxt.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.EsalNoTxt.Size = new System.Drawing.Size(146, 25);
            this.EsalNoTxt.TabIndex = 147;
            this.EsalNoTxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.EsalNoTxt_KeyPress);
            // 
            // label45
            // 
            this.label45.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Transparent;
            this.label45.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label45.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label45.Location = new System.Drawing.Point(156, 6);
            this.label45.Name = "label45";
            this.label45.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label45.Size = new System.Drawing.Size(59, 16);
            this.label45.TabIndex = 146;
            this.label45.Text = "رقم الايصال";
            // 
            // label69
            // 
            this.label69.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.Transparent;
            this.label69.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label69.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label69.Location = new System.Drawing.Point(672, 193);
            this.label69.Name = "label69";
            this.label69.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label69.Size = new System.Drawing.Size(68, 16);
            this.label69.TabIndex = 130;
            this.label69.Text = "اسم الخزينة :";
            this.label69.Visible = false;
            // 
            // comboBox7
            // 
            this.comboBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox7.Font = new System.Drawing.Font("Arial", 9.75F);
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(415, 190);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboBox7.Size = new System.Drawing.Size(251, 24);
            this.comboBox7.TabIndex = 129;
            this.comboBox7.Visible = false;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.checkBox3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.checkBox3.Location = new System.Drawing.Point(225, 219);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(65, 22);
            this.checkBox3.TabIndex = 33;
            this.checkBox3.Text = "تم الدفع";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.Font = new System.Drawing.Font("Arial", 9.75F);
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "الفترة الصباحية",
            "الفترة المسائية"});
            this.comboBox2.Location = new System.Drawing.Point(415, 160);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(251, 24);
            this.comboBox2.TabIndex = 32;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(669, 163);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 16);
            this.label10.TabIndex = 31;
            this.label10.Text = "الفترة :";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.checkBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.checkBox2.Location = new System.Drawing.Point(294, 219);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(81, 22);
            this.checkBox2.TabIndex = 30;
            this.checkBox2.Text = "تم الموافقة";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // StatusPanel
            // 
            this.StatusPanel.BackColor = System.Drawing.Color.LightCoral;
            this.StatusPanel.Location = new System.Drawing.Point(55, 190);
            this.StatusPanel.Name = "StatusPanel";
            this.StatusPanel.Size = new System.Drawing.Size(43, 22);
            this.StatusPanel.TabIndex = 27;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(292, 193);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 16);
            this.label9.TabIndex = 25;
            this.label9.Text = "الحالة :";
            // 
            // StatusCom
            // 
            this.StatusCom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.StatusCom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.StatusCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StatusCom.Font = new System.Drawing.Font("Arial", 9.75F);
            this.StatusCom.FormattingEnabled = true;
            this.StatusCom.Items.AddRange(new object[] {
            "لم يؤكد",
            "تم التأكيد",
            "تم تعديله",
            "تم إلغاؤه",
            "تم الكشف"});
            this.StatusCom.Location = new System.Drawing.Point(104, 190);
            this.StatusCom.Name = "StatusCom";
            this.StatusCom.Size = new System.Drawing.Size(186, 24);
            this.StatusCom.TabIndex = 26;
            this.StatusCom.SelectedIndexChanged += new System.EventHandler(this.StatusCom_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(294, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "تاريخ انتهاء الحجز :";
            // 
            // recalldateTimePicker2
            // 
            this.recalldateTimePicker2.CustomFormat = "dd/MM/yyyy";
            this.recalldateTimePicker2.Font = new System.Drawing.Font("Arial", 11.25F);
            this.recalldateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.recalldateTimePicker2.Location = new System.Drawing.Point(39, 36);
            this.recalldateTimePicker2.Name = "recalldateTimePicker2";
            this.recalldateTimePicker2.RightToLeftLayout = true;
            this.recalldateTimePicker2.Size = new System.Drawing.Size(251, 25);
            this.recalldateTimePicker2.TabIndex = 5;
            this.recalldateTimePicker2.ValueChanged += new System.EventHandler(this.recalldateTimePicker2_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(292, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 24;
            this.label1.Text = "المبلغ :";
            // 
            // priceTextBox
            // 
            this.priceTextBox.Font = new System.Drawing.Font("Arial", 11.25F);
            this.priceTextBox.Location = new System.Drawing.Point(161, 131);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(129, 25);
            this.priceTextBox.TabIndex = 8;
            this.priceTextBox.Text = "0";
            this.priceTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.priceTextBox.TextChanged += new System.EventHandler(this.priceTextBox_TextChanged);
            this.priceTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.priceTextBox_KeyPress);
            this.priceTextBox.Leave += new System.EventHandler(this.priceTextBox_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(294, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "تاريخ أعادة الكشف :";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label.Location = new System.Drawing.Point(294, 105);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(68, 16);
            this.label.TabIndex = 0;
            this.label.Text = "رقم الكرسي :";
            // 
            // regdateTimePicker1
            // 
            this.regdateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.regdateTimePicker1.Font = new System.Drawing.Font("Arial", 11.25F);
            this.regdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.regdateTimePicker1.Location = new System.Drawing.Point(39, 68);
            this.regdateTimePicker1.Name = "regdateTimePicker1";
            this.regdateTimePicker1.RightToLeftLayout = true;
            this.regdateTimePicker1.Size = new System.Drawing.Size(251, 25);
            this.regdateTimePicker1.TabIndex = 6;
            // 
            // appdateTimePicker1
            // 
            this.appdateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.appdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.appdateTimePicker1.Location = new System.Drawing.Point(415, 92);
            this.appdateTimePicker1.Name = "appdateTimePicker1";
            this.appdateTimePicker1.RightToLeftLayout = true;
            this.appdateTimePicker1.Size = new System.Drawing.Size(251, 25);
            this.appdateTimePicker1.TabIndex = 2;
            this.appdateTimePicker1.ValueChanged += new System.EventHandler(this.appdateTimePicker1_ValueChanged);
            // 
            // ChairTextBox
            // 
            this.ChairTextBox.Font = new System.Drawing.Font("Arial", 11.25F);
            this.ChairTextBox.Location = new System.Drawing.Point(39, 100);
            this.ChairTextBox.Name = "ChairTextBox";
            this.ChairTextBox.Size = new System.Drawing.Size(251, 25);
            this.ChairTextBox.TabIndex = 7;
            this.ChairTextBox.TextChanged += new System.EventHandler(this.ChairTextBox_TextChanged);
            // 
            // TOTextBox
            // 
            this.TOTextBox.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold);
            this.TOTextBox.Location = new System.Drawing.Point(415, 125);
            this.TOTextBox.Mask = "00:00";
            this.TOTextBox.Name = "TOTextBox";
            this.TOTextBox.Size = new System.Drawing.Size(90, 29);
            this.TOTextBox.TabIndex = 4;
            this.TOTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TOTextBox.ValidatingType = typeof(System.DateTime);
            // 
            // FromTextBox
            // 
            this.FromTextBox.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold);
            this.FromTextBox.Location = new System.Drawing.Point(576, 125);
            this.FromTextBox.Mask = "00:00";
            this.FromTextBox.Name = "FromTextBox";
            this.FromTextBox.Size = new System.Drawing.Size(90, 29);
            this.FromTextBox.TabIndex = 3;
            this.FromTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.FromTextBox.ValidatingType = typeof(System.DateTime);
            // 
            // apptextBox
            // 
            this.apptextBox.BackColor = System.Drawing.Color.White;
            this.apptextBox.ForeColor = System.Drawing.Color.Maroon;
            this.apptextBox.Location = new System.Drawing.Point(555, 30);
            this.apptextBox.Name = "apptextBox";
            this.apptextBox.ReadOnly = true;
            this.apptextBox.Size = new System.Drawing.Size(111, 25);
            this.apptextBox.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F);
            this.label8.ForeColor = System.Drawing.Color.Firebrick;
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(669, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 16);
            this.label8.TabIndex = 17;
            this.label8.Text = "رقم الحجز :";
            // 
            // doctorcomboBox
            // 
            this.doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.doctorcomboBox.Font = new System.Drawing.Font("Arial", 9.75F);
            this.doctorcomboBox.FormattingEnabled = true;
            this.doctorcomboBox.Location = new System.Drawing.Point(415, 60);
            this.doctorcomboBox.Name = "doctorcomboBox";
            this.doctorcomboBox.Size = new System.Drawing.Size(251, 24);
            this.doctorcomboBox.TabIndex = 1;
            this.doctorcomboBox.SelectedValueChanged += new System.EventHandler(this.doctorcomboBox_SelectedValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(669, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "اسم الطبيب :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(67, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "حجز كشف لمريض";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(669, 132);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "من :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label6.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(3, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(148, 18);
            this.label6.TabIndex = 0;
            this.label6.Text = "مطلوب موافقة لهذا المريض";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gainsboro;
            this.button2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.button2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button2.Location = new System.Drawing.Point(397, 46);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(35, 31);
            this.button2.TabIndex = 81;
            this.button2.Text = "..";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Arial", 11.25F);
            this.textBox4.Location = new System.Drawing.Point(435, 76);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(251, 25);
            this.textBox4.TabIndex = 83;
            this.textBox4.Text = "0";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            this.textBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox4_KeyPress);
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.saveBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.saveBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.saveBtn.Location = new System.Drawing.Point(319, 635);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(128, 37);
            this.saveBtn.TabIndex = 34;
            this.saveBtn.Text = "إضافة";
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(322, 152);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(235, 35);
            this.groupBox2.TabIndex = 80;
            this.groupBox2.TabStop = false;
            // 
            // dataSet11
            // 
            this.dataSet11.DataSetName = "DataSet1";
            this.dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sqlSelectCommand1
            // 
            this.sqlSelectCommand1.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
            this.sqlSelectCommand1.Connection = this.sqlConnection1;
            // 
            // sqlConnection1
            // 
            this.sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrat" +
    "ed Security=True;Connect Timeout=30;User Instance=True";
            this.sqlConnection1.FireInfoMessageEventOnUserErrors = false;
            // 
            // sqlInsertCommand1
            // 
            this.sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
            this.sqlInsertCommand1.Connection = this.sqlConnection1;
            this.sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
            new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
            new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
            new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
            new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
            new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
            new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
            new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData")});
            // 
            // sqlUpdateCommand1
            // 
            this.sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
            this.sqlUpdateCommand1.Connection = this.sqlConnection1;
            this.sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
            new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
            new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
            new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
            new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
            new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
            new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
            new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
            new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ID", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DentalName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")});
            // 
            // sqlDeleteCommand1
            // 
            this.sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
            this.sqlDeleteCommand1.Connection = this.sqlConnection1;
            this.sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ID", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DentalName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, null)});
            // 
            // sqlDataAdapter1
            // 
            this.sqlDataAdapter1.DeleteCommand = this.sqlDeleteCommand1;
            this.sqlDataAdapter1.InsertCommand = this.sqlInsertCommand1;
            this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
            this.sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("ID", "ID"),
                        new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
                        new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
                        new System.Data.Common.DataColumnMapping("DTel", "DTel"),
                        new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
                        new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
                        new System.Data.Common.DataColumnMapping("DSite", "DSite"),
                        new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
                        new System.Data.Common.DataColumnMapping("WorkData", "WorkData")})});
            this.sqlDataAdapter1.UpdateCommand = this.sqlUpdateCommand1;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Transparent;
            this.groupBox6.Controls.Add(this.label6);
            this.groupBox6.Location = new System.Drawing.Point(67, 150);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(235, 35);
            this.groupBox6.TabIndex = 81;
            this.groupBox6.TabStop = false;
            this.groupBox6.Visible = false;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Transparent;
            this.groupBox7.Controls.Add(this.textBox1);
            this.groupBox7.Controls.Add(this.Dariba);
            this.groupBox7.Controls.Add(this.AfterDariba);
            this.groupBox7.Controls.Add(this.comboCategory);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Controls.Add(this.textBox5);
            this.groupBox7.Controls.Add(this.label13);
            this.groupBox7.Controls.Add(this.button2);
            this.groupBox7.Controls.Add(this.textBox4);
            this.groupBox7.Controls.Add(this.button3);
            this.groupBox7.Controls.Add(this.label11);
            this.groupBox7.Controls.Add(this.commentTextBox);
            this.groupBox7.Controls.Add(this.label12);
            this.groupBox7.Location = new System.Drawing.Point(12, 420);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox7.Size = new System.Drawing.Size(756, 209);
            this.groupBox7.TabIndex = 82;
            this.groupBox7.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Arial", 11.25F);
            this.textBox1.Location = new System.Drawing.Point(435, 110);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(63, 25);
            this.textBox1.TabIndex = 167;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label23.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label23.Location = new System.Drawing.Point(505, 113);
            this.label23.Name = "label23";
            this.label23.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label23.Size = new System.Drawing.Size(40, 16);
            this.label23.TabIndex = 166;
            this.label23.Text = "الخصم:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label19.Location = new System.Drawing.Point(684, 141);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 16);
            this.label19.TabIndex = 145;
            this.label19.Text = "السعر النهائي:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label17.Location = new System.Drawing.Point(599, 114);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(21, 14);
            this.label17.TabIndex = 99;
            this.label17.Text = "%";
            // 
            // Dariba
            // 
            this.Dariba.Enabled = false;
            this.Dariba.Font = new System.Drawing.Font("Arial", 11.25F);
            this.Dariba.Location = new System.Drawing.Point(622, 107);
            this.Dariba.Name = "Dariba";
            this.Dariba.ReadOnly = true;
            this.Dariba.Size = new System.Drawing.Size(63, 25);
            this.Dariba.TabIndex = 98;
            this.Dariba.Text = "0";
            this.Dariba.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label18.Location = new System.Drawing.Point(684, 114);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(51, 16);
            this.label18.TabIndex = 97;
            this.label18.Text = "الضريبة :";
            // 
            // AfterDariba
            // 
            this.AfterDariba.Enabled = false;
            this.AfterDariba.Font = new System.Drawing.Font("Arial", 11.25F);
            this.AfterDariba.Location = new System.Drawing.Point(566, 137);
            this.AfterDariba.Name = "AfterDariba";
            this.AfterDariba.ReadOnly = true;
            this.AfterDariba.Size = new System.Drawing.Size(117, 25);
            this.AfterDariba.TabIndex = 96;
            this.AfterDariba.Text = "0";
            this.AfterDariba.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboCategory
            // 
            this.comboCategory.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboCategory.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboCategory.Font = new System.Drawing.Font("Arial", 9.75F);
            this.comboCategory.FormattingEnabled = true;
            this.comboCategory.Location = new System.Drawing.Point(435, 17);
            this.comboCategory.Name = "comboCategory";
            this.comboCategory.Size = new System.Drawing.Size(251, 24);
            this.comboCategory.TabIndex = 89;
            this.comboCategory.SelectedIndexChanged += new System.EventHandler(this.comboCategory_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(690, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 16);
            this.label14.TabIndex = 88;
            this.label14.Text = "الفئة :";
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.Transparent;
            this.groupBox8.Controls.Add(this.dataGridView2);
            this.groupBox8.Location = new System.Drawing.Point(15, 9);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox8.Size = new System.Drawing.Size(369, 106);
            this.groupBox8.TabIndex = 84;
            this.groupBox8.TabStop = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 16);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(363, 87);
            this.dataGridView2.TabIndex = 0;
            this.dataGridView2.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dataGridView2_RowsRemoved);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "الخدمة";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "السعر";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "الضريبة";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "السعر النهائي";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Arial", 9.75F);
            this.textBox5.Location = new System.Drawing.Point(53, 119);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(214, 22);
            this.textBox5.TabIndex = 85;
            this.textBox5.Text = "0";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label13.Location = new System.Drawing.Point(280, 121);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 16);
            this.label13.TabIndex = 84;
            this.label13.Text = "اجمالى الخدمات :";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gainsboro;
            this.button3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.button3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button3.Location = new System.Drawing.Point(521, 169);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(108, 34);
            this.button3.TabIndex = 82;
            this.button3.Text = "إضافة خدمة ";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(692, 80);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 16);
            this.label11.TabIndex = 45;
            this.label11.Text = "السعر :";
            // 
            // commentTextBox
            // 
            this.commentTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.commentTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.commentTextBox.Font = new System.Drawing.Font("Arial", 9.75F);
            this.commentTextBox.FormattingEnabled = true;
            this.commentTextBox.Location = new System.Drawing.Point(435, 47);
            this.commentTextBox.Name = "commentTextBox";
            this.commentTextBox.Size = new System.Drawing.Size(251, 24);
            this.commentTextBox.TabIndex = 44;
            this.commentTextBox.SelectedIndexChanged += new System.EventHandler(this.commentTextBox_SelectedIndexChanged);
            this.commentTextBox.Click += new System.EventHandler(this.commentTextBox_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label12.Location = new System.Drawing.Point(689, 53);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 16);
            this.label12.TabIndex = 43;
            this.label12.Text = "الخدمة :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label15.Location = new System.Drawing.Point(51, 11);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 18);
            this.label15.TabIndex = 93;
            this.label15.Text = "بيانات المريض";
            this.label15.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Location = new System.Drawing.Point(289, -6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(192, 35);
            this.groupBox1.TabIndex = 93;
            this.groupBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.checkBox12);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.txtFileNo);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.companycomboBox);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.addressTextBox);
            this.groupBox3.Controls.Add(this.sexComboBox);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.textBox66);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.nameTextBox);
            this.groupBox3.Controls.Add(this.checkBox11);
            this.groupBox3.Controls.Add(this.IDtextBox);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Font = new System.Drawing.Font("Arial Narrow", 9F);
            this.groupBox3.Location = new System.Drawing.Point(12, 11);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox3.Size = new System.Drawing.Size(759, 135);
            this.groupBox3.TabIndex = 79;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "بيانات المريض";
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Checked = true;
            this.checkBox12.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.checkBox12.Location = new System.Drawing.Point(270, 106);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(88, 20);
            this.checkBox12.TabIndex = 142;
            this.checkBox12.Text = "خاضع للضريبة";
            this.checkBox12.UseVisualStyleBackColor = true;
            this.checkBox12.CheckedChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // txtFileNo
            // 
            this.txtFileNo.ForeColor = System.Drawing.Color.Maroon;
            this.txtFileNo.Location = new System.Drawing.Point(564, 20);
            this.txtFileNo.Name = "txtFileNo";
            this.txtFileNo.ReadOnly = true;
            this.txtFileNo.Size = new System.Drawing.Size(111, 21);
            this.txtFileNo.TabIndex = 102;
            this.txtFileNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFileNo_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(48, 51);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(25, 16);
            this.label16.TabIndex = 101;
            this.label16.Text = "سنة";
            // 
            // button1
            // 
            this.button1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button1.Location = new System.Drawing.Point(382, 101);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(36, 25);
            this.button1.TabIndex = 100;
            this.button1.Text = "....";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // companycomboBox
            // 
            this.companycomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.companycomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.companycomboBox.Font = new System.Drawing.Font("Arial Narrow", 9.75F);
            this.companycomboBox.FormattingEnabled = true;
            this.companycomboBox.Location = new System.Drawing.Point(424, 101);
            this.companycomboBox.Name = "companycomboBox";
            this.companycomboBox.Size = new System.Drawing.Size(251, 24);
            this.companycomboBox.TabIndex = 99;
            this.companycomboBox.SelectedIndexChanged += new System.EventHandler(this.companycomboBox_SelectedIndexChanged);
            // 
            // addressTextBox
            // 
            this.addressTextBox.Font = new System.Drawing.Font("Arial", 9.75F);
            this.addressTextBox.Location = new System.Drawing.Point(46, 76);
            this.addressTextBox.Multiline = true;
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(315, 22);
            this.addressTextBox.TabIndex = 96;
            // 
            // sexComboBox
            // 
            this.sexComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sexComboBox.Font = new System.Drawing.Font("Arial", 9.75F);
            this.sexComboBox.FormattingEnabled = true;
            this.sexComboBox.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.sexComboBox.Location = new System.Drawing.Point(234, 48);
            this.sexComboBox.Name = "sexComboBox";
            this.sexComboBox.Size = new System.Drawing.Size(127, 24);
            this.sexComboBox.TabIndex = 94;
            // 
            // textBox66
            // 
            this.textBox66.Font = new System.Drawing.Font("Arial", 9.75F);
            this.textBox66.Location = new System.Drawing.Point(524, 73);
            this.textBox66.Multiline = true;
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(151, 22);
            this.textBox66.TabIndex = 92;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Arial", 9.75F);
            this.textBox2.Location = new System.Drawing.Point(78, 48);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(91, 22);
            this.textBox2.TabIndex = 90;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Font = new System.Drawing.Font("Arial", 9.75F);
            this.nameTextBox.Location = new System.Drawing.Point(424, 45);
            this.nameTextBox.Multiline = true;
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(251, 22);
            this.nameTextBox.TabIndex = 88;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Checked = true;
            this.checkBox11.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.checkBox11.Location = new System.Drawing.Point(509, 22);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(44, 20);
            this.checkBox11.TabIndex = 87;
            this.checkBox11.Text = "نشط";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // IDtextBox
            // 
            this.IDtextBox.ForeColor = System.Drawing.Color.Maroon;
            this.IDtextBox.Location = new System.Drawing.Point(250, 24);
            this.IDtextBox.Name = "IDtextBox";
            this.IDtextBox.ReadOnly = true;
            this.IDtextBox.Size = new System.Drawing.Size(111, 21);
            this.IDtextBox.TabIndex = 86;
            this.IDtextBox.Visible = false;
            // 
            // sqlConnection2
            // 
            this.sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrat" +
    "ed Security=True;Connect Timeout=30;User Instance=True";
            this.sqlConnection2.FireInfoMessageEventOnUserErrors = false;
            // 
            // sqlDataAdapter2
            // 
            this.sqlDataAdapter2.InsertCommand = this.sqlCommand2;
            this.sqlDataAdapter2.SelectCommand = this.sqlCommand3;
            this.sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("ID", "ID"),
                        new System.Data.Common.DataColumnMapping("Titel", "Titel"),
                        new System.Data.Common.DataColumnMapping("PName", "PName"),
                        new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
                        new System.Data.Common.DataColumnMapping("City", "City"),
                        new System.Data.Common.DataColumnMapping("Tel", "Tel"),
                        new System.Data.Common.DataColumnMapping("Mob", "Mob"),
                        new System.Data.Common.DataColumnMapping("Email", "Email"),
                        new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
                        new System.Data.Common.DataColumnMapping("Sex", "Sex"),
                        new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
                        new System.Data.Common.DataColumnMapping("Statue", "Statue"),
                        new System.Data.Common.DataColumnMapping("company", "company"),
                        new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
                        new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
                        new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
                        new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
                        new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
                        new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
                        new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
                        new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
                        new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
                        new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
                        new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
                        new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
                        new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
                        new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
                        new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
                        new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
                        new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
                        new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
                        new System.Data.Common.DataColumnMapping("Implant", "Implant"),
                        new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
                        new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
                        new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers"),
                        new System.Data.Common.DataColumnMapping("DoctoreName", "DoctoreName"),
                        new System.Data.Common.DataColumnMapping("NextVisit", "NextVisit"),
                        new System.Data.Common.DataColumnMapping("Accept", "Accept"),
                        new System.Data.Common.DataColumnMapping("Taqweem", "Taqweem"),
                        new System.Data.Common.DataColumnMapping("Photo", "Photo"),
                        new System.Data.Common.DataColumnMapping("BloodType", "BloodType"),
                        new System.Data.Common.DataColumnMapping("Active", "Active"),
                        new System.Data.Common.DataColumnMapping("FileNo", "FileNo"),
                        new System.Data.Common.DataColumnMapping("Patient", "Patient"),
                        new System.Data.Common.DataColumnMapping("Facebook", "Facebook"),
                        new System.Data.Common.DataColumnMapping("Adv", "Adv"),
                        new System.Data.Common.DataColumnMapping("FormerPatient", "FormerPatient"),
                        new System.Data.Common.DataColumnMapping("Discount", "Discount"),
                        new System.Data.Common.DataColumnMapping("Without", "Without"),
                        new System.Data.Common.DataColumnMapping("Doctor", "Doctor"),
                        new System.Data.Common.DataColumnMapping("DoctorId", "DoctorId"),
                        new System.Data.Common.DataColumnMapping("nationalID", "nationalID"),
                        new System.Data.Common.DataColumnMapping("Dariba", "Dariba"),
                        new System.Data.Common.DataColumnMapping("NextvisitTXT", "NextvisitTXT")})});
            // 
            // sqlCommand2
            // 
            this.sqlCommand2.CommandText = resources.GetString("sqlCommand2.CommandText");
            this.sqlCommand2.Connection = this.sqlConnection2;
            this.sqlCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
            new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
            new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
            new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
            new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
            new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
            new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
            new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
            new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
            new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
            new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
            new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
            new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
            new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
            new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
            new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
            new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
            new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
            new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
            new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
            new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
            new System.Data.SqlClient.SqlParameter("@Lactating", System.Data.SqlDbType.Bit, 0, "Lactating"),
            new System.Data.SqlClient.SqlParameter("@Pregnant", System.Data.SqlDbType.Bit, 0, "Pregnant"),
            new System.Data.SqlClient.SqlParameter("@HepatitisB", System.Data.SqlDbType.Bit, 0, "HepatitisB"),
            new System.Data.SqlClient.SqlParameter("@Hepatitisc", System.Data.SqlDbType.Bit, 0, "Hepatitisc"),
            new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
            new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
            new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
            new System.Data.SqlClient.SqlParameter("@Endodontics", System.Data.SqlDbType.Bit, 0, "Endodontics"),
            new System.Data.SqlClient.SqlParameter("@Fixed", System.Data.SqlDbType.Bit, 0, "Fixed"),
            new System.Data.SqlClient.SqlParameter("@Implant", System.Data.SqlDbType.Bit, 0, "Implant"),
            new System.Data.SqlClient.SqlParameter("@Opretive", System.Data.SqlDbType.Bit, 0, "Opretive"),
            new System.Data.SqlClient.SqlParameter("@Bleaching", System.Data.SqlDbType.Bit, 0, "Bleaching"),
            new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers"),
            new System.Data.SqlClient.SqlParameter("@DoctoreName", System.Data.SqlDbType.NVarChar, 0, "DoctoreName"),
            new System.Data.SqlClient.SqlParameter("@NextVisit", System.Data.SqlDbType.NVarChar, 0, "NextVisit"),
            new System.Data.SqlClient.SqlParameter("@Accept", System.Data.SqlDbType.Bit, 0, "Accept"),
            new System.Data.SqlClient.SqlParameter("@Taqweem", System.Data.SqlDbType.Bit, 0, "Taqweem"),
            new System.Data.SqlClient.SqlParameter("@Photo", System.Data.SqlDbType.Image, 0, "Photo"),
            new System.Data.SqlClient.SqlParameter("@BloodType", System.Data.SqlDbType.NVarChar, 0, "BloodType"),
            new System.Data.SqlClient.SqlParameter("@Active", System.Data.SqlDbType.Bit, 0, "Active"),
            new System.Data.SqlClient.SqlParameter("@FileNo", System.Data.SqlDbType.Int, 0, "FileNo"),
            new System.Data.SqlClient.SqlParameter("@Patient", System.Data.SqlDbType.Bit, 0, "Patient"),
            new System.Data.SqlClient.SqlParameter("@Facebook", System.Data.SqlDbType.Bit, 0, "Facebook"),
            new System.Data.SqlClient.SqlParameter("@Adv", System.Data.SqlDbType.Bit, 0, "Adv"),
            new System.Data.SqlClient.SqlParameter("@FormerPatient", System.Data.SqlDbType.NVarChar, 0, "FormerPatient"),
            new System.Data.SqlClient.SqlParameter("@Discount", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, ((byte)(18)), ((byte)(2)), "Discount", System.Data.DataRowVersion.Current, null),
            new System.Data.SqlClient.SqlParameter("@Without", System.Data.SqlDbType.Bit, 0, "Without"),
            new System.Data.SqlClient.SqlParameter("@Doctor", System.Data.SqlDbType.Bit, 0, "Doctor"),
            new System.Data.SqlClient.SqlParameter("@DoctorId", System.Data.SqlDbType.NVarChar, 0, "DoctorId"),
            new System.Data.SqlClient.SqlParameter("@nationalID", System.Data.SqlDbType.VarChar, 0, "nationalID"),
            new System.Data.SqlClient.SqlParameter("@Dariba", System.Data.SqlDbType.Bit, 0, "Dariba"),
            new System.Data.SqlClient.SqlParameter("@NextvisitTXT", System.Data.SqlDbType.NVarChar, 0, "NextvisitTXT")});
            // 
            // sqlCommand3
            // 
            this.sqlCommand3.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
            this.sqlCommand3.Connection = this.sqlConnection2;
            // 
            // Appointmentsp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(783, 686);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.saveBtn);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox4);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "Appointmentsp";
            this.Text = "الحجز السريع";
            this.Load += new System.EventHandler(this.Appointments_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Appointments_KeyDown);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.PaidPanel.ResumeLayout(false);
            this.PaidPanel.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

		}

		public Appointmentsp()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
		}

		private void AppointCount()
		{
			DataTable dataTable = codes.Search2(string.Concat("select AppointCount, BacksCount from Empdata where ID='", doctorcomboBox.SelectedValue, "'"));
			int num = Convert.ToInt32(dataTable.Rows[0][0].ToString());
			int num2 = Convert.ToInt32(dataTable.Rows[0][1].ToString());
			DataTable dataTable2 = codes.Search2(string.Concat("select count(ID) from Appointments where DoctorID='", doctorcomboBox.SelectedValue, "' and detectDate='", appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "'"));
			int num3 = Convert.ToInt32(dataTable2.Rows[0][0].ToString());
			if (num3 < num)
			{
				DataTable dataTable3 = codes.Search2(string.Concat("select count(ID) from Appointments where DoctorID='", doctorcomboBox.SelectedValue, "' and packDate='", recalldateTimePicker2.Value.ToString("MM/dd/yyyy"), "'"));
				int num4 = Convert.ToInt32(dataTable3.Rows[0][0].ToString());
				if (num4 >= num2)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Doctor Backs reached the maximum limit");
					}
					else
					{
						MessageBox.Show("عدد حالات اعادة الكشف لهذا الطبيب وصلت الحد الأقصى");
					}
					b = false;
				}
				else
				{
					b = true;
				}
			}
			else
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Doctor Appointments reached the maximum limit");
				}
				else
				{
					MessageBox.Show("عدد الكشوفات لهذا الطبيب وصلت الحد الأقصى");
				}
				b = false;
			}
		}

		private void Appointments_Load(object sender, EventArgs e)
		{
			try
			{
				try
				{
					if (Convert.ToBoolean(codes.Search2("select HideService from users where userId='" + Main.userId + "'").Rows[0][0].ToString()))
					{
						groupBox7.Visible = false;
					}
				}
				catch
				{
				}
				try
				{
					if (Convert.ToBoolean(codes.Search2("select AvoidPay1 from Properties").Rows[0][0].ToString()))
					{
						checkBox3.Enabled = false;
					}
				}
				catch
				{
				}
				if (UsersClass.AutoEsal)
				{
					EsalNoTxt.Text = codes.Search2("select isnull(max(Code)+1,1) from AppointEsal").Rows[0][0].ToString();
					EsalNoTxt.Enabled = false;
				}
				else
				{
					EsalNoTxt.Text = "";
					EsalNoTxt.Enabled = true;
				}
			}
			catch
			{
			}
			try
			{
				txtFileNo.ReadOnly = Convert.ToBoolean(codes.Search2("select AutoFileNo from Properties").Rows[0][0]);
			}
			catch
			{
			}
			if (txtFileNo.ReadOnly)
			{
				txtFileNo.Text = codes.Search2("select isnull(max(FileNo)+ 1,1) from PatientData").Rows[0][0].ToString();
			}
			try
			{
				DataTable dataTable = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				comboBox7.DataSource = null;
				comboBox7.DataSource = dataTable;
				comboBox7.DisplayMember = dataTable.Columns[1].ToString();
				comboBox7.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				IDtextBox.Text = codes.Search2("select Max(ID)+1 from PatientData").Rows[0][0].ToString();
			}
			catch
			{
			}
			try
			{
				loaddata();
				StatusCom.SelectedIndex = 0;
				comboBox2.SelectedIndex = 0;
				sexComboBox.SelectedIndex = 0;
			}
			catch
			{
			}
			try
			{
				priceTextBox.Text = "0";
				try
				{
					groupBox6.Visible = false;
				}
				catch
				{
					groupBox6.Visible = false;
				}
			}
			catch
			{
			}
			DataTable tableText = dc.GetTableText("select * from Company");
			gui.loadComboBox(companycomboBox, tableText);
			companycomboBox.SelectedItem = companycomboBox.Items[0];
			try
			{
				DataTable dataTable2 = codes.Search2("select * from users where userName = '" + Main.usernames + "'");
				button2.Visible = Convert.ToBoolean(dataTable2.Rows[0]["Company"].ToString());
				button1.Visible = Convert.ToBoolean(dataTable2.Rows[0]["Company"].ToString());
			}
			catch
			{
			}
			try
			{
				DataTable dataTable3 = codes.Search2("SELECT distinct dbo.Categories.ID, dbo.Categories.Name\r\nFROM         dbo.CompanyService INNER JOIN\r\n                      dbo.Categories ON dbo.CompanyService.CompanyID = dbo.Categories.ID");
				comboCategory.DataSource = dataTable3;
				comboCategory.DisplayMember = dataTable3.Columns[1].ToString();
				comboCategory.ValueMember = dataTable3.Columns[0].ToString();
			}
			catch
			{
			}
			priceTextBox.Enabled = UsersClass.ChangeServicePrice;
			textBox4.Enabled = UsersClass.ChangeServicePrice;
			commentTextBox_SelectedIndexChanged(sender, e);
			companycomboBox_SelectedIndexChanged(sender, e);
			string text = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
			DataTable dataTable4 = codes.Search2("SELECT dbo.CompanyService.Price , dbo.CompanyService.Dariba FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + companycomboBox.Text + "' and Service = '" + text + "' ");
			if (dataTable4.Rows.Count != 0)
			{
				textBox6.Text = dataTable4.Rows[0][1].ToString();
			}
		}

		private void loaddata()
		{
			try
			{
				DataTable dataTable = codes.Search2("select ServiceName from Properties where ServiceName IS NOT NULL");
				if (dataTable.Rows.Count > 0)
				{
					dataTable.Rows[0][0].ToString();
					DataTable dataTable2 = new DataTable();
					string[] fields = new string[1] { "Date" };
					dataTable2 = dc.Select("SelectAllAppointmentBydate", fields, appdateTimePicker1.Value.ToString("MM/dd/yyyy"));
					if (dataTable2.Rows.Count > 0)
					{
						apptextBox.Text = (dataTable2.Rows.Count + 1).ToString();
					}
					else
					{
						apptextBox.Text = "1";
					}
					try
					{
						dataTable2 = dc.Select("SelectAllDoctor");
						gui.loadComboBox(doctorcomboBox, dataTable2);
					}
					catch
					{
					}
				}
				else
				{
					MessageBox.Show(" من فضلك ادخل خدمة الحجز من شاشة خصائص عامة");
					Close();
					FrmProperties frmProperties = new FrmProperties();
					frmProperties.ShowDialog();
				}
			}
			catch
			{
			}
		}

		private void clear()
		{
			FromTextBox.Text = "00:00";
			TOTextBox.Text = "00:00";
			ChairTextBox.Text = "";
			priceTextBox.Text = "0";
			appdateTimePicker1.Value = DateTime.Now;
			recalldateTimePicker2.Value = DateTime.Now;
			regdateTimePicker1.Value = DateTime.Now;
			saveBtn.Enabled = true;
			checkBox2.Checked = false;
			checkBox3.Checked = false;
			loaddata();
			checkBox3.Visible = true;
			dataGridView2.Rows.Clear();
		}

		private void priceTextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && priceTextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك أدخل أرقام فقط");
				}
				e.Handled = true;
			}
			catch
			{
			}
		}

		private void priceTextBox_Leave(object sender, EventArgs e)
		{
			try
			{
				if (priceTextBox.Text == "")
				{
					priceTextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				int num = Convert.ToInt32(codes.Search2("select count(id) from Appointments").Rows[0][0].ToString());
				if (num >= 20)
				{
					MessageBox.Show("انتهت المدة المحددة لتشغيل البرنامج إذا أردت النسخة الكاملة الرجاء الإتصال بالشركة", "تحذير", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else if (txtFileNo.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("please Enter patient Code");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل كود المريض");
					}
				}
				else if (b)
				{
					if (doctorcomboBox.SelectedItem != null)
					{
						dataSet11.Clear();
						sqlConnection1.ConnectionString = dc.ConnectionStr;
						sqlDataAdapter1.Fill(dataSet11);
						if (nameTextBox.Text != "")
						{
							DataTable dataTable = codes.Search2("select * from PatientData where PName='" + nameTextBox.Text + "' or FileNo = '" + txtFileNo.Text + "'");
							if (dataTable.Rows.Count > 0)
							{
								if (Settings.Default.Language == "en-GB")
								{
									MessageBox.Show("You Have Save This Patient Before", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								}
								else
								{
									MessageBox.Show("هذا المريض مسجل مسبقا", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								}
								txtFileNo.Text = codes.Search2("select isnull(max(FileNo)+ 1,1) from PatientData").Rows[0][0].ToString();
							}
							if (companycomboBox.SelectedItem != null)
							{
								if (textBox2.Text != "")
								{
									if (!checkBox3.Checked)
									{
										goto IL_02c8;
									}
									if (!(EsalNoTxt.Text == ""))
									{
										DataTable dataTable2 = codes.Search2("select Code from AppointEsal where Code ='" + EsalNoTxt.Text + "'");
										if (dataTable2.Rows.Count > 0)
										{
											MessageBox.Show("رقم الايصال مسجل من قبل");
											EsalNoTxt.Text = codes.Search2("select isnull(max(Code)+1,1) from AppointEsal").Rows[0][0].ToString();
										}
										goto IL_02c8;
									}
									MessageBox.Show("من فضلك ادخل رقم الايصال");
								}
								else if (Settings.Default.Language == "en-GB")
								{
									MessageBox.Show("please Enter patient Age", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								}
								else
								{
									MessageBox.Show("من فضلك ادخل السن", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								}
							}
							else if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("please Enter Company name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							else
							{
								MessageBox.Show("من فضلك ادخل اسم الشركة", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
						}
						else if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("please Enter patient name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("من فضلك ادخل اسم المريض", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("please Enter Doctor name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم الطبيب", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Doctor Appointments or backs reached the maximum limit");
				}
				else
				{
					MessageBox.Show("عدد الكشوفات او إعادة الكشف لهذا الطبيب وصلت الحد الأقصى");
				}
				goto end_IL_0001;
				IL_02c8:
				DateTime dateTime = new DateTime(DateTime.Now.Year - Convert.ToInt32(textBox2.Text), 1, 1);
				codes.Add2("insert into PatientData (PName, PAddress,Mob,BirthDate,Sex,company,Active,FileNo,DoctoreName,Dariba) values('" + nameTextBox.Text + "','" + addressTextBox.Text + "','" + textBox66.Text + "','" + dateTime.ToString("MM/dd/yyyy") + "','" + sexComboBox.Text + "','" + companycomboBox.SelectedValue.ToString() + "','" + checkBox11.Checked + "','" + txtFileNo.Text + "','" + doctorcomboBox.Text + "','" + checkBox12.Checked + "')");
				try
				{
					PId = codes.Search2("select Max(ID) from PatientData").Rows[0][0].ToString();
				}
				catch
				{
				}
				string[] fields = new string[15]
				{
					"AppointNum", "PatuentID", "DoctorID", "detectDate", "detectStartTime", "detectEndTime", "packDate", "ExpDate", "ChairNum", "Price",
					"Status", "Accepted", "Period", "Dariba", "PriceBeforeDariba"
				};
				bool flag = false;
				if (comboBox2.SelectedIndex == 1)
				{
					flag = true;
				}
				bool flag2 = dc.Insert("AddAppointment", fields, apptextBox.Text, Convert.ToInt32(PId), Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), appdateTimePicker1.Value.ToString("MM/dd/yyyy"), FromTextBox.Text, TOTextBox.Text, recalldateTimePicker2.Value.ToString("MM/dd/yyyy"), regdateTimePicker1.Value.ToString("MM/dd/yyyy"), ChairTextBox.Text, textBox7.Text, StatusCom.Text, checkBox2.Checked, flag, textBox6.Text, priceTextBox.Text);
				string text = codes.Search2("select max(id) from Appointments").Rows[0][0].ToString();
				if (flag2)
				{
					string[] fields2 = new string[11]
					{
						"PatientId", "DoctorID", "Bean", "Price", "Date", "PricePay", "BeanDate", "AppointNum", "Dariba", "PriceBeforeDariba",
						"Assistant"
					};
					for (int i = 0; i < dataGridView2.Rows.Count; i++)
					{
						codes.Add2("insert into ReserveService (Bean, Price, AppointNum,Dariba, PriceBeforeDariba) values('" + dataGridView2.Rows[i].Cells[0].Value.ToString() + "','" + Convert.ToDecimal(dataGridView2.Rows[i].Cells[3].Value.ToString()) + "','" + text + "','" + Convert.ToDecimal(dataGridView2.Rows[i].Cells[2].Value.ToString()) + "','" + Convert.ToDecimal(dataGridView2.Rows[i].Cells[1].Value.ToString()) + "')");
					}
					DataTable dataTable3 = codes.Search2("select ServiceName from Properties ");
					string text2 = dataTable3.Rows[0][0].ToString();
					string text3 = EsalNoTxt.Text;
					if (checkBox3.Checked)
					{
						DataTable dataTable4 = new DataTable();
						dataTable4 = dc.GetTableText("select * from Stock  where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
						double num2 = Convert.ToDouble(dataTable4.Rows[0][1].ToString());
						string[] fields3 = new string[11]
						{
							"PatientId", "DoctorID", "Bean", "Price", "Date", "PricePay", "BeanDate", "AppointNum", "Dariba", "PriceBeforeDariba",
							"Assistant"
						};
						dc.Insert("AddPatientAccountApp1", fields3, Convert.ToInt32(PId), Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), text2, textBox7.Text, appdateTimePicker1.Value.ToString("MM/dd/yyyy"), priceTextBox.Text, appdateTimePicker1.Value.ToString("MM/dd/yyyy"), text, textBox6.Text, priceTextBox.Text, "");
						DataTable dataTable5 = codes.Search2("select max(ID) from PatientAccount");
						codes.Add2("insert into AccountDetails (PatientId, DoctorId, Date, Bean, Price, PricePay, PatientAcountId, StockId) values('" + Convert.ToInt32(PId) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + text2 + "','" + textBox7.Text + "','" + textBox7.Text + "','" + Convert.ToInt32(dataTable5.Rows[0][0].ToString()) + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
						string text4 = "0";
						if (checkBox3.Checked)
						{
							text4 = textBox7.Text;
						}
						companyId = comboCategory.SelectedValue.ToString();
						string value = codes.Search("select isnull(sum(Madeen),0) -  isnull(sum(Daen),0) from Company5 where CompanyId = '" + companyId + "'").Rows[0][0].ToString();
						codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + CompanyPrice + "','" + (Convert.ToDouble(value) + Convert.ToDouble(CompanyPrice)) + "','" + text2 + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(dataTable5.Rows[0][0].ToString()) + "')");
						codes.Add2("insert into AppointEsal (Code, Doctor, Patient, Date, Company, TimeFrom, TimeTo,UserName, Price, Pay, PatientAcountId) values ('" + text3 + "','" + doctorcomboBox.Text + "','" + nameTextBox.Text + "', '" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "', '" + companycomboBox.Text + "','" + FromTextBox.Text + "', '" + TOTextBox.Text + "' , '" + Main.usernames + "', '" + textBox7.Text + "','" + text4 + "','" + Convert.ToInt32(dataTable5.Rows[0][0].ToString()) + "')");
						double num3 = Convert.ToDouble(priceTextBox.Text);
						double num4 = num2 + num3;
						codes.Edit2("update Stock Set Value= '" + num4.ToString() + "' where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
						codes.Edit2("update PatientData set Accept='False' where ID='" + PId + "'");
						codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('كشف' ," + Convert.ToDecimal(textBox7.Text) + ",'" + nameTextBox.Text + " إيصال حجز رقم: " + EsalNoTxt.Text + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
						if (StatusCom.Text == "تم التأكيد" || StatusCom.Text == "Confirmed")
						{
							string text5 = codes.Search2("select max(id) from Appointments").Rows[0][0].ToString();
							codes.Edit2(string.Concat("update Appointments set AcceptDate ='", DateTime.Now, "' where id = '", text5, "'"));
						}
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Save Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove(" أضافة حجز سريع");
						((DataTable)(object)dataSet11.AppointmentEsal).Rows.Add(text3, nameTextBox.Text, doctorcomboBox.Text, appdateTimePicker1.Value, FromTextBox.Text, TOTextBox.Text, companycomboBox.Text, Main.usernames, textBox7.Text);
						sqlConnection2.ConnectionString = codes.ConnectionStr;
						sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
						sqlDataAdapter2.SelectCommand.CommandText = "select * from PatientData where PName ='" + nameTextBox.Text + "'";
						sqlDataAdapter2.Fill(dataSet11);
						if (Convert.ToBoolean(codes.Search2("select ShowEsal from Properties").Rows[0][0]))
						{
							AppointEsalRptFrm appointEsalRptFrm = new AppointEsalRptFrm(dataSet11);
							appointEsalRptFrm.ShowDialog();
						}
						loaddata();
						clear();
						Close();
					}
					else
					{
						dc.Insert("AddPatientAccountApp", fields2, Convert.ToInt32(PId), Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), text2, textBox7.Text, appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "0", appdateTimePicker1.Value.ToString("MM/dd/yyyy"), text, textBox6.Text, priceTextBox.Text, "");
						codes.Edit2("update PatientData set Accept='False' where ID='" + PId + "'");
						if (StatusCom.Text == "تم التأكيد" || StatusCom.Text == "Confirmed")
						{
							string text5 = codes.Search2("select max(id) from Appointments").Rows[0][0].ToString();
							codes.Edit2(string.Concat("update Appointments set AcceptDate ='", DateTime.Now, "' where id = '", text5, "'"));
						}
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Save Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove(" أضافة حجز سريع");
						loaddata();
						clear();
						Close();
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				end_IL_0001:;
			}
			catch
			{
			}
		}

		private void appdateTimePicker1_ValueChanged(object sender, EventArgs e)
		{
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
		}

		private void DeletBtn_Click(object sender, EventArgs e)
		{
		}

		private void Appointments_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void StatusCom_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (StatusCom.SelectedIndex == 0)
			{
				StatusPanel.BackColor = Color.FromArgb(143, 213, 245);
			}
			else if (StatusCom.SelectedIndex == 1)
			{
				StatusPanel.BackColor = Color.YellowGreen;
			}
			else if (StatusCom.SelectedIndex == 2)
			{
				StatusPanel.BackColor = Color.Transparent;
			}
			else if (StatusCom.SelectedIndex == 3)
			{
				StatusPanel.BackColor = Color.FromArgb(230, 119, 96);
			}
			else if (StatusCom.SelectedIndex == 4)
			{
				StatusPanel.BackColor = Color.BlueViolet;
			}
		}

		private void groupBox5_Enter(object sender, EventArgs e)
		{
		}

		private void doctorcomboBox_SelectedValueChanged(object sender, EventArgs e)
		{
			try
			{
				AppointCount();
			}
			catch
			{
			}
		}

		private void recalldateTimePicker2_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				AppointCount();
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			if (companycomboBox.SelectedItem != null && companycomboBox.Text != "")
			{
				FrmCompaniesServicesPrices frmCompaniesServicesPrices = new FrmCompaniesServicesPrices();
				frmCompaniesServicesPrices.ShowDialog();
				try
				{
					DataTable dataTable = codes.Search2("SELECT distinct dbo.Categories.ID, dbo.Categories.Name\r\nFROM         dbo.CompanyService INNER JOIN\r\n                      dbo.Categories ON dbo.CompanyService.CompanyID = dbo.Categories.ID");
					comboCategory.DataSource = dataTable;
					comboCategory.ValueMember = dataTable.Columns[0].ToString();
					comboCategory.DisplayMember = dataTable.Columns[1].ToString();
				}
				catch
				{
				}
				try
				{
					string text = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
					DataTable dataTable2 = codes.Search2("select distinct(Service) from CompanyService where Service != '" + text + "' and CompanyID = '" + companycomboBox.SelectedValue.ToString() + "'");
					commentTextBox.DataSource = null;
					commentTextBox.DataSource = dataTable2;
					commentTextBox.DisplayMember = dataTable2.Columns[0].ToString();
				}
				catch
				{
				}
			}
			else
			{
				MessageBox.Show("من فضلك اختر اسم الشركة", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}

		private void textBox4_TextChanged(object sender, EventArgs e)
		{
			if (textBox4.Text == "")
			{
				commentTextBox_SelectedIndexChanged(sender, e);
			}
			else
			{
				AfterDariba.Text = Convert.ToString(Math.Round(Convert.ToDecimal(textBox4.Text) + Convert.ToDecimal(textBox4.Text) * Convert.ToDecimal(Dariba.Text) / 100m, 2));
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("SELECT     dbo.Appointments.DoctorID, dbo.Appointments.detectDate, dbo.Appointments.detectStartTime, dbo.Appointments.detectEndTime, dbo.ReserveService.Bean\r\nFROM         dbo.Appointments INNER JOIN\r\n                      dbo.ReserveService ON dbo.Appointments.ID = dbo.ReserveService.AppointNum where dbo.Appointments.detectDate = '" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "' and  dbo.Appointments.detectStartTime = '" + FromTextBox.Text + "' and dbo.Appointments.detectEndTime = '" + TOTextBox.Text + "' and dbo.ReserveService.Bean ='" + commentTextBox.Text + "' and dbo.Appointments.DoctorID ='" + doctorcomboBox.SelectedIndex + "'");
				if (doctorcomboBox.SelectedItem == null)
				{
					MessageBox.Show("من فضلك اختر اسم الطبيب", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					return;
				}
				if (companycomboBox.SelectedItem == null)
				{
					MessageBox.Show("من فضلك ادخل اسم الشركة");
					return;
				}
				if (commentTextBox.Text == "" || commentTextBox.SelectedItem == null)
				{
					MessageBox.Show("من فضلك ادخل اسم الخدمة");
					return;
				}
				if (dataTable.Rows.Count > 0)
				{
					MessageBox.Show("تم عمل حجز لهذه الخدمة من قبل");
					return;
				}
				if (textBox4.Text == "0")
				{
					MessageBox.Show("من فضلك ادخل سعر الخدمة");
					return;
				}
				if (dataGridView2.Rows.Count == 0)
				{
					dataGridView2.Rows.Add(commentTextBox.Text, textBox4.Text, Dariba.Text, AfterDariba.Text);
					Total = Convert.ToDecimal(textBox5.Text);
					Total += Convert.ToDecimal(AfterDariba.Text);
					textBox5.Text = Total.ToString();
					commentTextBox.Text = "";
					textBox4.Text = "0";
					return;
				}
				int num = 0;
				while (true)
				{
					if (num < dataGridView2.Rows.Count)
					{
						string text = commentTextBox.Text;
						string value = dataGridView2.Rows[num].Cells[0].Value.ToString();
						if (!text.Equals(value))
						{
							if (num == dataGridView2.Rows.Count - 1)
							{
								break;
							}
							num++;
							continue;
						}
						MessageBox.Show("هذا الخدمة تم ادخاله من قبل");
						commentTextBox.Text = "";
						textBox4.Text = "0";
						return;
					}
					return;
				}
				dataGridView2.Rows.Add(commentTextBox.Text, textBox4.Text, Dariba.Text, AfterDariba.Text);
				Total = Convert.ToDecimal(textBox5.Text);
				Total += Convert.ToDecimal(AfterDariba.Text);
				textBox5.Text = Total.ToString();
				commentTextBox.Text = "";
				textBox4.Text = "0";
			}
			catch
			{
			}
		}

		private void dataGridView2_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
			try
			{
				Total = 0m;
				if (dataGridView2.Rows.Count > 0)
				{
					for (int i = 0; i < dataGridView2.Rows.Count; i++)
					{
						Total += Convert.ToDecimal(dataGridView2.Rows[i].Cells[1].Value.ToString());
						textBox5.Text = Total.ToString();
					}
				}
				else
				{
					textBox5.Text = Total.ToString();
				}
			}
			catch
			{
			}
		}

		private void commentTextBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			decimal num = 0m;
			decimal num2 = 0m;
			try
			{
				DataTable dataTable = codes.Search2("SELECT     Name, ID, Status, Discount\r\nFROM         dbo.Company where Name='" + companycomboBox.Text + "'");
				string text = dataTable.Rows[0][2].ToString();
				DataTable dataTable2 = codes.Search2(string.Concat("select Price,Dariba  from CompanyService where Service='", commentTextBox.Text, "' and CompanyID = '", comboCategory.SelectedValue, "'"));
				if (dataTable2.Rows.Count > 0)
				{
					if (text == "1")
					{
						CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(dataTable.Rows[0][3]) / 100.0).ToString();
						textBox4.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text == "2")
					{
						string value = codes.Search2("SELECT Discount FROM DiscountCategory where Category = '" + comboCategory.Text + "'").Rows[0][0].ToString();
						CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(value) / 100.0).ToString();
						textBox4.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text == "3")
					{
						string value = codes.Search2("SELECT     Discount\r\nFROM         dbo.DiscountService where Service = '" + commentTextBox.Text + "'").Rows[0][0].ToString();
						CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(value) / 100.0).ToString();
						textBox4.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text == "4")
					{
						textBox4.Text = dataTable2.Rows[0][0].ToString();
						CompanyPrice = "0";
					}
				}
				else
				{
					textBox4.Text = "0";
				}
				if (!checkBox12.Checked || dataTable2.Rows.Count == 0)
				{
					AfterDariba.Text = "0";
					Dariba.Text = "0";
					num = Math.Round(Convert.ToDecimal(textBox4.Text) + Convert.ToDecimal(textBox4.Text) * Convert.ToDecimal(Dariba.Text) / 100m, 2);
				}
				else
				{
					Dariba.Text = dataTable2.Rows[0][1].ToString();
					num = Math.Round(Convert.ToDecimal(textBox4.Text) + Convert.ToDecimal(textBox4.Text) * Convert.ToDecimal(Dariba.Text) / 100m, 2);
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable3 = codes.Search2(string.Concat("select DiscountNesba,DiscountValue from CompanyService where Service='", commentTextBox.Text, "' and CompanyID = '", comboCategory.SelectedValue, "'"));
				if (dataTable3.Rows.Count > 0)
				{
					if (Convert.ToDecimal(dataTable3.Rows[0][0].ToString()) != 0m)
					{
						num2 = Math.Round(num - num * Convert.ToDecimal(dataTable3.Rows[0][0].ToString()) / 100m);
						if (Settings.Default.Language == "en-GB")
						{
							label23.Text = "Discount%";
						}
						else
						{
							label23.Text = "نسبة الخصم";
						}
						textBox1.Text = dataTable3.Rows[0][0].ToString();
						AfterDariba.Text = num2.ToString();
					}
					else if (Convert.ToDecimal(dataTable3.Rows[0][1].ToString()) != 0m)
					{
						num2 = Math.Round(num - Convert.ToDecimal(dataTable3.Rows[0][1].ToString()));
						if (Settings.Default.Language == "en-GB")
						{
							label23.Text = "Discount";
						}
						else
						{
							label23.Text = "قيمة الخصم";
						}
						textBox1.Text = dataTable3.Rows[0][1].ToString();
						AfterDariba.Text = num2.ToString();
					}
					else
					{
						if (Settings.Default.Language == "en-GB")
						{
							label23.Text = "Discount";
						}
						else
						{
							label23.Text = "الخصم";
						}
						textBox1.Text = "0";
						AfterDariba.Text = num.ToString();
					}
				}
				else
				{
					if (Settings.Default.Language == "en-GB")
					{
						label23.Text = "Discount";
					}
					else
					{
						label23.Text = "الخصم";
					}
					textBox1.Text = "0";
					AfterDariba.Text = num.ToString();
				}
			}
			catch
			{
			}
		}

		private void commentTextBox_Click(object sender, EventArgs e)
		{
		}

		private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && priceTextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك أدخل أرقام فقط");
				}
				e.Handled = true;
			}
			catch
			{
			}
		}

		private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
		{
		}

		private void companycomboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			decimal num = 0m;
			decimal num2 = 0m;
			string text = "";
			try
			{
				DataTable dataTable = codes.Search2("select ServiceName from Properties ");
				text = dataTable.Rows[0][0].ToString();
			}
			catch
			{
			}
			DataTable dataTable2 = codes.Search2("select Price from CompanyService where Service='" + text + "'");
			priceTextBox.Text = dataTable2.Rows[0][0].ToString();
			try
			{
				string text2 = "0";
				DataTable dataTable3 = codes.Search2("SELECT dbo.Company.Name,dbo.Company.ID,dbo.Company.Status,dbo.Company.Discount,dbo.Company.Nesba from Company where Company.Name='" + companycomboBox.Text + "'");
				text2 = ((dataTable3.Rows.Count <= 0) ? "0" : dataTable3.Rows[0][2].ToString());
				if (dataTable2.Rows.Count > 0)
				{
					if (text2 == "1")
					{
						if (Convert.ToBoolean(dataTable3.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(dataTable3.Rows[0][3]) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = Convert.ToDouble(dataTable3.Rows[0][3]).ToString();
						}
						priceTextBox.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text2 == "2")
					{
						string text3 = codes.Search2("SELECT distinct isnull(dbo.DiscountCategory.Discount,0)\r\nFROM         dbo.CompanyService INNER JOIN\r\n                      dbo.Categories ON dbo.CompanyService.CompanyID = dbo.Categories.ID INNER JOIN\r\n                      dbo.DiscountCategory ON dbo.Categories.Name = dbo.DiscountCategory.Category where CompanyService.Service = '" + text + "'").Rows[0][0].ToString();
						if (Convert.ToBoolean(dataTable3.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(text3) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = text3;
						}
						priceTextBox.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text2 == "3")
					{
						string text3 = codes.Search2("SELECT     isnull(Discount,0)\r\nFROM         dbo.DiscountService where Service = '" + text + "'").Rows[0][0].ToString();
						if (Convert.ToBoolean(dataTable3.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(text3) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = text3;
						}
						priceTextBox.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text2 == "4")
					{
						priceTextBox.Text = dataTable2.Rows[0][0].ToString();
						CompanyPrice = "0";
					}
				}
				else
				{
					priceTextBox.Text = "0";
				}
			}
			catch
			{
			}
			textBox4.Text = "0";
			commentTextBox.DataSource = null;
			commentTextBox_SelectedIndexChanged(sender, e);
			string text4 = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
			DataTable dataTable4 = codes.Search2("SELECT dbo.CompanyService.Price , dbo.CompanyService.Dariba FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + companycomboBox.Text + "' and Service = '" + text4 + "' ");
			if (dataTable4.Rows.Count != 0)
			{
				textBox6.Text = dataTable4.Rows[0][1].ToString();
				num = Math.Round(Convert.ToDecimal(priceTextBox.Text) + Convert.ToDecimal(priceTextBox.Text) * Convert.ToDecimal(textBox6.Text) / 100m, 2);
			}
			else
			{
				textBox6.Text = "0";
				num = Convert.ToDecimal(priceTextBox.Text);
			}
			try
			{
				DataTable dataTable5 = codes.Search2("select dbo.CompanyService.DiscountNesba,dbo.CompanyService.DiscountValue FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + companycomboBox.Text + "' and Service = '" + text + "' ");
				if (dataTable5.Rows.Count > 0)
				{
					if (Convert.ToDecimal(dataTable5.Rows[0][0].ToString()) != 0m)
					{
						num2 = Math.Round(num - num * Convert.ToDecimal(dataTable5.Rows[0][0].ToString()) / 100m);
						if (Settings.Default.Language == "en-GB")
						{
							label105.Text = "Discount%";
						}
						else
						{
							label105.Text = "نسبة الخصم";
						}
						textBoxDiscount.Text = dataTable5.Rows[0][0].ToString();
						textBox7.Text = num2.ToString();
					}
					else if (Convert.ToDecimal(dataTable5.Rows[0][1].ToString()) != 0m)
					{
						num2 = Math.Round(num - Convert.ToDecimal(dataTable5.Rows[0][1].ToString()));
						if (Settings.Default.Language == "en-GB")
						{
							label105.Text = "Discount";
						}
						else
						{
							label105.Text = "قيمة الخصم";
						}
						textBoxDiscount.Text = dataTable5.Rows[0][1].ToString();
						textBox7.Text = num2.ToString();
					}
					else
					{
						if (Settings.Default.Language == "en-GB")
						{
							label105.Text = "Discount";
						}
						else
						{
							label105.Text = "الخصم";
						}
						textBoxDiscount.Text = "0";
						textBox7.Text = num.ToString();
					}
				}
				else
				{
					if (Settings.Default.Language == "en-GB")
					{
						label105.Text = "Discount";
					}
					else
					{
						label105.Text = "الخصم";
					}
					textBoxDiscount.Text = "0";
					textBox7.Text = num.ToString();
				}
			}
			catch
			{
			}
		}

		private void checkBox3_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox3.Checked)
			{
				DataTable dataTable = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				if (dataTable.Rows.Count > 0)
				{
					label69.Visible = true;
					comboBox7.Visible = true;
					PaidPanel.Visible = true;
					return;
				}
				checkBox3.Checked = false;
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please add Treasury validity");
				}
				else
				{
					MessageBox.Show("من فضلك اضف صلاحية للخزينة");
				}
			}
			else
			{
				label69.Visible = false;
				comboBox7.Visible = false;
				PaidPanel.Visible = false;
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Company company = new Company();
			company.ShowDialog();
			try
			{
				DataTable tableText = dc.GetTableText("select * from Company");
				gui.loadComboBox(companycomboBox, tableText);
				companycomboBox.SelectedItem = companycomboBox.Items[0];
			}
			catch
			{
			}
		}

		private void txtFileNo_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
			{
				e.Handled = true;
			}
		}

		private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				commentTextBox.DataSource = null;
				string text = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
				string text2 = codes.Search2("select ServiceDetect from Properties").Rows[0][0].ToString();
				DataTable dataTable = codes.Search2(string.Concat("select Service from CompanyService where CompanyID = '", comboCategory.SelectedValue, "' and Service != '", text, "' and Service != '", text2, "'"));
				commentTextBox.DataSource = dataTable;
				commentTextBox.DisplayMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void checkBox2_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void EsalNoTxt_KeyPress(object sender, KeyPressEventArgs e)
		{
			if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
			{
				if (e.KeyChar == '.' && EsalNoTxt.Text.Contains("."))
				{
					e.Handled = true;
				}
			}
			else
			{
				e.Handled = true;
				MessageBox.Show("من فضلك أدخل رقم الإيصال بالارقام");
			}
		}

		private void checkBox12_CheckedChanged(object sender, EventArgs e)
		{
			if (!checkBox12.Checked)
			{
				textBox6.Text = "0";
				DataTable dataTable = codes.Search2("select ServiceName from Properties");
				string text = dataTable.Rows[0][0].ToString();
				Dariba.Text = "0";
				decimal num = Convert.ToDecimal(priceTextBox.Text);
				decimal num2 = 0m;
				try
				{
					DataTable dataTable2 = codes.Search2("select dbo.CompanyService.DiscountNesba,dbo.CompanyService.DiscountValue FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + companycomboBox.Text + "' and Service = '" + text + "' ");
					if (Convert.ToDecimal(dataTable2.Rows[0][0].ToString()) != 0m)
					{
						num2 = Math.Round(num - num * Convert.ToDecimal(dataTable2.Rows[0][0].ToString()) / 100m);
						if (Settings.Default.Language == "en-GB")
						{
							label105.Text = "Discount%";
						}
						else
						{
							label105.Text = "نسبة الخصم";
						}
						textBoxDiscount.Text = dataTable2.Rows[0][0].ToString();
						textBox7.Text = num2.ToString();
					}
					else if (Convert.ToDecimal(dataTable2.Rows[0][1].ToString()) != 0m)
					{
						num2 = Math.Round(num - Convert.ToDecimal(dataTable2.Rows[0][1].ToString()));
						if (Settings.Default.Language == "en-GB")
						{
							label105.Text = "Discount";
						}
						else
						{
							label105.Text = "قيمة الخصم";
						}
						textBoxDiscount.Text = dataTable2.Rows[0][1].ToString();
						textBox7.Text = num2.ToString();
					}
					else
					{
						if (Settings.Default.Language == "en-GB")
						{
							label105.Text = "Discount";
						}
						else
						{
							label105.Text = "الخصم";
						}
						textBoxDiscount.Text = "0";
						textBox7.Text = num.ToString();
					}
				}
				catch
				{
				}
			}
			else
			{
				string text2 = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
				DataTable dataTable3 = codes.Search2("SELECT dbo.CompanyService.Price , dbo.CompanyService.Dariba FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + companycomboBox.Text + "' and Service = '" + text2 + "' ");
				if (dataTable3.Rows.Count != 0)
				{
					priceTextBox.Text = dataTable3.Rows[0][0].ToString();
					textBox6.Text = dataTable3.Rows[0][1].ToString();
					textBox7.Text = Convert.ToString(Math.Round(Convert.ToDecimal(priceTextBox.Text) + Convert.ToDecimal(priceTextBox.Text) * Convert.ToDecimal(textBox6.Text) / 100m, 2));
				}
				priceTextBox_TextChanged(sender, e);
			}
		}

		private void priceTextBox_TextChanged(object sender, EventArgs e)
		{
			decimal num = 0m;
			decimal num2 = 0m;
			DataTable dataTable = codes.Search2("select ServiceName from Properties");
			string text = dataTable.Rows[0][0].ToString();
			if (priceTextBox.Text == "")
			{
				DataTable dataTable2 = codes.Search2("SELECT dbo.CompanyService.Price , dbo.CompanyService.Dariba FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + companycomboBox.Text + "' and Service = '" + text + "' ");
				if (dataTable2.Rows.Count != 0)
				{
					priceTextBox.Text = dataTable2.Rows[0][0].ToString();
				}
			}
			else
			{
				num = Math.Round(Convert.ToDecimal(priceTextBox.Text) + Convert.ToDecimal(priceTextBox.Text) * Convert.ToDecimal(textBox6.Text) / 100m, 2);
			}
			try
			{
				DataTable dataTable3 = codes.Search2("select dbo.CompanyService.DiscountNesba,dbo.CompanyService.DiscountValue FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + companycomboBox.Text + "' and Service = '" + text + "' ");
				if (dataTable3.Rows.Count > 0)
				{
					if (Convert.ToDecimal(dataTable3.Rows[0][0].ToString()) != 0m)
					{
						num2 = Math.Round(num - num * Convert.ToDecimal(dataTable3.Rows[0][0].ToString()) / 100m);
						if (Settings.Default.Language == "en-GB")
						{
							label105.Text = "Discount%";
						}
						else
						{
							label105.Text = "نسبة الخصم";
						}
						textBoxDiscount.Text = dataTable3.Rows[0][0].ToString();
						textBox7.Text = num2.ToString();
					}
					else if (Convert.ToDecimal(dataTable3.Rows[0][1].ToString()) != 0m)
					{
						num2 = Math.Round(num - Convert.ToDecimal(dataTable3.Rows[0][1].ToString()));
						if (Settings.Default.Language == "en-GB")
						{
							label105.Text = "Discount";
						}
						else
						{
							label105.Text = "قيمة الخصم";
						}
						textBoxDiscount.Text = dataTable3.Rows[0][1].ToString();
						textBox7.Text = num2.ToString();
					}
					else
					{
						if (Settings.Default.Language == "en-GB")
						{
							label105.Text = "Discount";
						}
						else
						{
							label105.Text = "الخصم";
						}
						textBoxDiscount.Text = "0";
						textBox7.Text = num.ToString();
					}
				}
				else
				{
					if (Settings.Default.Language == "en-GB")
					{
						label105.Text = "Discount";
					}
					else
					{
						label105.Text = "الخصم";
					}
					textBoxDiscount.Text = "0";
					textBox7.Text = num.ToString();
				}
			}
			catch
			{
			}
		}

		private void ChairTextBox_TextChanged(object sender, EventArgs e)
		{
		}
	}
}
