using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmCompaniesServicesPrices : BaseForm
	{
		private dataClass codes = new dataClass(".\\sqlExpress");

		private string id;

		private string company;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private string SName = "";

		private IContainer components = null;

		private GroupBox groupBox1;

		private Label label1;

		private NumericUpDown numericUpDown1;

		private Label label3;

		private ComboBox comboBox2;

		private Label label2;

		private ComboBox comboBox1;

		private GroupBox groupBox2;

		private Button button3;

		private Button button2;

		private Button button1;

		private GroupBox groupBox3;

		private Button button4;

		private ComboBox comboBox3;

		private GroupBox groupBox4;

		private DataGridView dataGridView1;

		private Button button5;

		private Button button6;

		private Label label4;

		private Label label5;

		private TextBox Dariba;

		private TextBox Discount;

		private Label label6;

		private RadioButton Value;

		private RadioButton Nesba;

		public FrmCompaniesServicesPrices()
		{
			InitializeComponent();
		}

		public FrmCompaniesServicesPrices(string Company1)
		{
			InitializeComponent();
			company = Company1;
		}

		private void loadData()
		{
			try
			{
				DataTable dataTable = codes.Search2("select distinct(Service) from CompanyService");
				comboBox2.DataSource = dataTable;
				comboBox2.DisplayMember = dataTable.Columns[0].ToString();
				comboBox2.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select id,name from Categories");
				comboBox1.DataSource = dataTable;
				comboBox1.ValueMember = "id";
				comboBox1.DisplayMember = "name";
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select id,name from Categories");
				comboBox3.DataSource = dataTable;
				comboBox3.ValueMember = "id";
				comboBox3.DisplayMember = "name";
			}
			catch
			{
			}
			try
			{
				FillDataGrid();
			}
			catch
			{
			}
		}

		private void FrmCompaniesServicesPrices_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select distinct(Service) from CompanyService");
				comboBox2.DataSource = dataTable;
				comboBox2.DisplayMember = dataTable.Columns[0].ToString();
				comboBox2.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select id,name from Categories");
				comboBox1.DataSource = dataTable;
				comboBox1.ValueMember = "id";
				comboBox1.DisplayMember = "name";
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select id,name from Categories");
				comboBox3.DataSource = dataTable;
				comboBox3.ValueMember = "id";
				comboBox3.DisplayMember = "name";
			}
			catch
			{
			}
			try
			{
				button5.Enabled = Convert.ToBoolean(codes.Search2("select PatientServiceUpdateBtn from users where userId = '" + Main.userId + "'").Rows[0][0].ToString());
			}
			catch
			{
			}
			try
			{
				FillDataGrid();
			}
			catch
			{
			}
		}

		private void FillDataGrid()
		{
			if (company != null)
			{
				comboBox1.Text = company;
				comboBox1.Enabled = false;
				DataTable dataTable = new DataTable();
				dataTable = ((!(Settings.Default.Language == "en-GB")) ? codes.Search2("SELECT        CompanyService.ID, Categories.Name [اسم الفئة], CompanyService.Service [الخدمة], CompanyService.Price [السعر] ,CompanyService.Dariba [الضريبة], CompanyService.DiscountNesba [نسبه الخصم],CompanyService.DiscountValue [قيمة الخصم]\r\nFROM            Categories INNER JOIN\r\n                         CompanyService ON Categories.ID = CompanyService.CompanyID where Categories.Name = '" + comboBox1.Text + "'") : codes.Search2("SELECT        CompanyService.ID, Categories.Name [Category Name], CompanyService.Service [Service Name], CompanyService.Price [Price] ,CompanyService.Dariba [Dariba], CompanyService.DiscountNesba [DiscountNesba],CompanyService.DiscountValue [DiscountValue]\r\nFROM            Categories INNER JOIN\r\n                         CompanyService ON Categories.ID = CompanyService.CompanyID where Categories.Name = '" + comboBox1.Text + "'"));
				dataGridView1.DataSource = dataTable;
				dataGridView1.Columns[0].Visible = false;
			}
			else
			{
				DataTable dataTable = new DataTable();
				dataTable = ((!(Settings.Default.Language == "en-GB")) ? codes.Search2("SELECT        CompanyService.ID, Categories.Name [اسم الفئة], CompanyService.Service [الخدمة], CompanyService.Price [السعر] ,CompanyService.Dariba [الضريبة], CompanyService.DiscountNesba [نسبه الخصم],CompanyService.DiscountValue [قيمة الخصم]\r\nFROM            Categories INNER JOIN\r\n                         CompanyService ON Categories.ID = CompanyService.CompanyID") : codes.Search2("SELECT        CompanyService.ID, Categories.Name [Category Name], CompanyService.Service [Service Name], CompanyService.Price [Price],CompanyService.Dariba [Dariba], CompanyService.DiscountNesba [DiscountNesba],CompanyService.DiscountValue [DiscountValue]\r\nFROM            Categories INNER JOIN\r\n                         CompanyService ON Categories.ID = CompanyService.CompanyID where Categories.Name = '" + comboBox1.Text + "'"));
				dataGridView1.DataSource = dataTable;
				dataGridView1.Columns[0].Visible = false;
			}
		}

		private void button4_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = ((!(Settings.Default.Language == "en-GB")) ? codes.Search2(string.Concat("SELECT        CompanyService.ID, Categories.Name [اسم الفئة], CompanyService.Service [الخدمة], CompanyService.Price [السعر] ,CompanyService.Dariba [الضريبة], CompanyService.DiscountNesba [نسبه الخصم],CompanyService.DiscountValue [قيمة الخصم]\r\nFROM            Categories INNER JOIN\r\n                         CompanyService ON Categories.ID = CompanyService.CompanyID where Categories.ID='", comboBox3.SelectedValue, "'")) : codes.Search2(string.Concat("SELECT        CompanyService.ID, Categories.Name [Category Name], CompanyService.Service [Service Name], CompanyService.Price [Price] ,CompanyService.Dariba [Dariba], CompanyService.DiscountNesba [DiscountNesba],CompanyService.DiscountValue [DiscountValue]\r\nFROM            Categories INNER JOIN\r\n                         CompanyService ON Categories.ID = CompanyService.CompanyID where Categories.ID='", comboBox3.SelectedValue, "'")));
				dataGridView1.DataSource = dataTable;
				dataGridView1.Columns[0].Visible = false;
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (comboBox2.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Service Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الخدمة");
					}
				}
				else if (comboBox1.SelectedIndex == -1)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Category Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الفئة");
					}
				}
				else if (numericUpDown1.Value >= 0m)
				{
					DataTable dataTable = codes.Search2("select id from CompanyService where CompanyService.Service ='" + comboBox2.Text + "'");
					if (dataTable.Rows.Count > 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Have Save This Service Before");
						}
						else
						{
							MessageBox.Show("تم تسجيل هذه الخدمة من قبل");
						}
						return;
					}
					try
					{
						string text = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
						if (text != "")
						{
							string text2 = codes.Search2("select ServiceDetect from Properties").Rows[0][0].ToString();
							if (comboBox2.Text == text || comboBox2.Text == text2)
							{
								MessageBox.Show("لايمكن الاضافة لان الخدمة مسجلة بخدمة الحجز");
								return;
							}
						}
					}
					catch
					{
					}
					if (Nesba.Checked)
					{
						codes.Add(string.Concat("insert into CompanyService (CompanyID, Service, Price,Dariba,DiscountNesba,DiscountValue) Values ('", comboBox1.SelectedValue, "', '", comboBox2.Text, "', '", numericUpDown1.Value, "',", Convert.ToDecimal(Dariba.Text), ",", Convert.ToDecimal(Discount.Text), ",0)"));
					}
					else
					{
						codes.Add(string.Concat("insert into CompanyService (CompanyID, Service, Price,Dariba,DiscountNesba,DiscountValue) Values ('", comboBox1.SelectedValue, "', '", comboBox2.Text, "', '", numericUpDown1.Value, "',", Convert.ToDecimal(Dariba.Text), " ,0,", Convert.ToDecimal(Discount.Text), ")"));
					}
					numericUpDown1.Value = 0m;
					Dariba.Text = "0";
					Discount.Text = "0";
					FillDataGrid();
					MethodsClass.UserMove("أضافة خدمة الي فئة");
					try
					{
						DataTable dataTable2 = codes.Search2("select distinct(Service) from CompanyService");
						comboBox2.DataSource = dataTable2;
						comboBox2.DisplayMember = dataTable2.Columns[0].ToString();
						comboBox2.ValueMember = dataTable2.Columns[0].ToString();
					}
					catch
					{
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Price");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل السعر");
				}
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				if (comboBox2.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Service Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الخدمة");
					}
				}
				else if (numericUpDown1.Value >= 0m)
				{
					DataTable dataTable = codes.Search2("select id from CompanyService where CompanyService.Service ='" + comboBox2.Text + "' and CompanyService.ID <> '" + id + "'");
					if (dataTable.Rows.Count > 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Have Save This Service Before");
						}
						else
						{
							MessageBox.Show("هذا البيان مسجل من قبل");
						}
						return;
					}
					if (Nesba.Checked)
					{
						codes.Edit(string.Concat("update CompanyService set CompanyID ='", comboBox1.SelectedValue, "', Service ='", comboBox2.Text, "', Price ='", numericUpDown1.Value, "', Dariba=", Convert.ToDecimal(Dariba.Text), " , DiscountNesba=", Convert.ToDecimal(Discount.Text), ",DiscountValue =0 where ID='", id, "'"));
					}
					else
					{
						codes.Edit(string.Concat("update CompanyService set CompanyID ='", comboBox1.SelectedValue, "', Service ='", comboBox2.Text, "', Price ='", numericUpDown1.Value, "', Dariba=", Convert.ToDecimal(Dariba.Text), " , DiscountNesba=0,DiscountValue=", Convert.ToDecimal(Discount.Text), " where ID='", id, "'"));
					}
					codes.Edit2("update DiscountService set Service='" + comboBox2.Text + "' where Service='" + SName + "'");
					MethodsClass.UserMove("تعديل خدمة");
					numericUpDown1.Value = 0m;
					Dariba.Text = "0";
					Discount.Text = "0";
					button2.Visible = false;
					button3.Visible = false;
					button1.Visible = true;
					FillDataGrid();
					comboBox1.Enabled = true;
					comboBox2.Enabled = true;
					try
					{
						DataTable dataTable2 = codes.Search2("select distinct(Service) from CompanyService");
						comboBox2.DataSource = dataTable2;
						comboBox2.DisplayMember = dataTable2.Columns[0].ToString();
						comboBox2.ValueMember = dataTable2.Columns[0].ToString();
					}
					catch
					{
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Price");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل السعر");
				}
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				string text = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
				string text2 = codes.Search2("select ServiceDetect from Properties").Rows[0][0].ToString();
				string text3 = codes.Search2("select Service from CompanyService where id='" + id + "'").Rows[0][0].ToString();
				if (text3 == text || text3 == text2)
				{
					MessageBox.Show("لايمكن حذف لان الخدمة مسجلة بخدمة الحجز");
					return;
				}
				codes.Delete("delete from CompanyService where id='" + id + "'");
				MethodsClass.UserMove("حذف خدمة");
				numericUpDown1.Value = 0m;
				Dariba.Text = "0";
				button2.Visible = false;
				button3.Visible = false;
				button1.Visible = true;
				FillDataGrid();
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				try
				{
					string text = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
					string text2 = codes.Search2("select ServiceDetect from Properties").Rows[0][0].ToString();
					if (dataGridView1.CurrentRow.Cells[2].Value.ToString() == text || dataGridView1.CurrentRow.Cells[2].Value.ToString() == text2)
					{
						comboBox1.Enabled = false;
						comboBox2.Enabled = false;
					}
					else
					{
						comboBox1.Enabled = true;
						comboBox2.Enabled = true;
					}
				}
				catch
				{
				}
				button2.Visible = true;
				button3.Visible = true;
				button1.Visible = false;
				id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
				comboBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
				comboBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
				SName = comboBox2.Text;
				numericUpDown1.Value = Convert.ToDecimal(dataGridView1.CurrentRow.Cells[3].Value.ToString());
				Dariba.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
				if (Convert.ToDecimal(dataGridView1.CurrentRow.Cells[5].Value.ToString()) != 0m)
				{
					Nesba.Checked = true;
					Discount.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
				}
				else
				{
					Value.Checked = true;
					Discount.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
				}
			}
			catch
			{
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			Category category = new Category();
			category.ShowDialog();
			loadData();
		}

		private void groupBox3_Enter(object sender, EventArgs e)
		{
		}

		private void button6_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = ((!(Settings.Default.Language == "en-GB")) ? codes.Search2("SELECT        CompanyService.ID, Categories.Name [اسم الفئة], CompanyService.Service [الخدمة], CompanyService.Price [السعر]\r\nFROM            Categories INNER JOIN\r\n                         CompanyService ON Categories.ID = CompanyService.CompanyID where CompanyService.Service = '" + codes.SearchService("اسم الخدمة") + "'") : codes.Search2("SELECT CompanyService.ID, Categories.Name [Category Name], CompanyService.Service [Service Name], CompanyService.Price [Price]\r\nFROM            Categories INNER JOIN\r\n                         CompanyService ON Categories.ID = CompanyService.CompanyID where CompanyService.Service = '" + codes.SearchService("Service Name") + "'"));
				dataGridView1.DataSource = dataTable;
				dataGridView1.Columns[0].Visible = false;
			}
			catch
			{
			}
		}

		private void Discount_TextChanged(object sender, EventArgs e)
		{
			if (Discount.Text == "")
			{
				Discount.Text = "0";
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmCompaniesServicesPrices));
			groupBox1 = new System.Windows.Forms.GroupBox();
			Value = new System.Windows.Forms.RadioButton();
			Nesba = new System.Windows.Forms.RadioButton();
			Discount = new System.Windows.Forms.TextBox();
			label6 = new System.Windows.Forms.Label();
			label5 = new System.Windows.Forms.Label();
			Dariba = new System.Windows.Forms.TextBox();
			label4 = new System.Windows.Forms.Label();
			button5 = new System.Windows.Forms.Button();
			numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			label3 = new System.Windows.Forms.Label();
			comboBox2 = new System.Windows.Forms.ComboBox();
			label1 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			comboBox1 = new System.Windows.Forms.ComboBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			button6 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			groupBox3 = new System.Windows.Forms.GroupBox();
			button4 = new System.Windows.Forms.Button();
			comboBox3 = new System.Windows.Forms.ComboBox();
			groupBox4 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
			groupBox2.SuspendLayout();
			groupBox3.SuspendLayout();
			groupBox4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(Value);
			groupBox1.Controls.Add(Nesba);
			groupBox1.Controls.Add(Discount);
			groupBox1.Controls.Add(label6);
			groupBox1.Controls.Add(label5);
			groupBox1.Controls.Add(Dariba);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(button5);
			groupBox1.Controls.Add(numericUpDown1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(comboBox2);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(comboBox1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			Value.AccessibleDescription = null;
			Value.AccessibleName = null;
			resources.ApplyResources(Value, "Value");
			Value.BackgroundImage = null;
			Value.Font = null;
			Value.Name = "Value";
			Value.UseVisualStyleBackColor = true;
			Nesba.AccessibleDescription = null;
			Nesba.AccessibleName = null;
			resources.ApplyResources(Nesba, "Nesba");
			Nesba.BackgroundImage = null;
			Nesba.Checked = true;
			Nesba.Font = null;
			Nesba.Name = "Nesba";
			Nesba.TabStop = true;
			Nesba.UseVisualStyleBackColor = true;
			Discount.AccessibleDescription = null;
			Discount.AccessibleName = null;
			resources.ApplyResources(Discount, "Discount");
			Discount.BackgroundImage = null;
			Discount.Font = null;
			Discount.Name = "Discount";
			Discount.TextChanged += new System.EventHandler(Discount_TextChanged);
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "label6");
			label6.Font = null;
			label6.Name = "label6";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label5");
			label5.Name = "label5";
			Dariba.AccessibleDescription = null;
			Dariba.AccessibleName = null;
			resources.ApplyResources(Dariba, "Dariba");
			Dariba.BackgroundImage = null;
			Dariba.Font = null;
			Dariba.Name = "Dariba";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Font = null;
			label4.Name = "label4";
			button5.AccessibleDescription = null;
			button5.AccessibleName = null;
			resources.ApplyResources(button5, "button5");
			button5.BackgroundImage = null;
			button5.Font = null;
			button5.Name = "button5";
			button5.UseVisualStyleBackColor = true;
			button5.Click += new System.EventHandler(button5_Click);
			numericUpDown1.AccessibleDescription = null;
			numericUpDown1.AccessibleName = null;
			resources.ApplyResources(numericUpDown1, "numericUpDown1");
			numericUpDown1.DecimalPlaces = 2;
			numericUpDown1.Font = null;
			numericUpDown1.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			numericUpDown1.Name = "numericUpDown1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Font = null;
			label3.Name = "label3";
			comboBox2.AccessibleDescription = null;
			comboBox2.AccessibleName = null;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.BackgroundImage = null;
			comboBox2.Font = null;
			comboBox2.FormattingEnabled = true;
			comboBox2.Name = "comboBox2";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.Name = "label1";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Font = null;
			label2.Name = "label2";
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.Font = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Name = "comboBox1";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(button6);
			groupBox2.Controls.Add(button3);
			groupBox2.Controls.Add(button2);
			groupBox2.Controls.Add(button1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			button6.AccessibleDescription = null;
			button6.AccessibleName = null;
			resources.ApplyResources(button6, "button6");
			button6.BackgroundImage = null;
			button6.Font = null;
			button6.Name = "button6";
			button6.UseVisualStyleBackColor = true;
			button6.Click += new System.EventHandler(button6_Click);
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackgroundImage = null;
			button3.Font = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(button4);
			groupBox3.Controls.Add(comboBox3);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			groupBox3.Enter += new System.EventHandler(groupBox3_Enter);
			button4.AccessibleDescription = null;
			button4.AccessibleName = null;
			resources.ApplyResources(button4, "button4");
			button4.BackgroundImage = null;
			button4.Font = null;
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = true;
			button4.Click += new System.EventHandler(button4_Click);
			comboBox3.AccessibleDescription = null;
			comboBox3.AccessibleName = null;
			resources.ApplyResources(comboBox3, "comboBox3");
			comboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox3.BackgroundImage = null;
			comboBox3.Font = null;
			comboBox3.FormattingEnabled = true;
			comboBox3.Name = "comboBox3";
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(dataGridView1);
			groupBox4.Font = null;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox4);
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FrmCompaniesServicesPrices";
			base.Load += new System.EventHandler(FrmCompaniesServicesPrices_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox3.ResumeLayout(false);
			groupBox4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
		}
	}
}
