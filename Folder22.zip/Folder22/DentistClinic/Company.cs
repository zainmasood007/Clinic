using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using FloatTextBox;

namespace DentistClinic
{
	public class Company : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private TextBox NotestextBox;

		private Label label2;

		private Label label1;

		private TextBox NametextBox;

		private Button searchBtn;

		private Button saveBtn;

		private Button DeleteBtn;

		private Button EditBtn;

		private GroupBox groupBox2;

		private GroupBox groupBox3;

		private DataGridView dataGridView1;

		private GroupBox groupBox4;

		private Label label3;

		private RadioButton radioButton3;

		private RadioButton radioButton2;

		private RadioButton radioButton1;

		private RadioButton radioButton4;

		private Label label4;

		private FloatText discountPerFloatText;

		private ComboBox comboBox2;

		private Label label5;

		private Label label6;

		private Panel panel1;

		private Panel panel2;

		private ComboBox comboBox1;

		private GroupBox groupBox5;

		private GroupBox groupBox6;

		private DataGridView dataGridView2;

		private Button button1;

		private Panel panel3;

		private FloatText floatText1;

		private Label label7;

		private Button button2;

		private FloatText floatText2;

		private Label label8;

		private FloatText floatText3;

		private Label label9;

		private Panel panel4;

		private RadioButton radioButton5;

		private RadioButton radioButton7;

		private ClassDataBase dc;

		private int ID;

		private bool check = true;

		private int status;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		private GUI gui = new GUI();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.NametextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.NotestextBox = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.discountPerFloatText = new FloatTextBox.FloatText();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.searchBtn = new System.Windows.Forms.Button();
            this.saveBtn = new System.Windows.Forms.Button();
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.EditBtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.floatText3 = new FloatTextBox.FloatText();
            this.floatText2 = new FloatTextBox.FloatText();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.floatText1 = new FloatTextBox.FloatText();
            this.label7 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.NametextBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.NotestextBox);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 11.25F);
            this.groupBox1.Location = new System.Drawing.Point(4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(629, 105);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // NametextBox
            // 
            this.NametextBox.Location = new System.Drawing.Point(50, 30);
            this.NametextBox.Name = "NametextBox";
            this.NametextBox.Size = new System.Drawing.Size(438, 25);
            this.NametextBox.TabIndex = 1;
            this.NametextBox.TextChanged += new System.EventHandler(this.NametextBox_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(492, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 18);
            this.label2.TabIndex = 0;
            this.label2.Text = "ملاحظات :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(492, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "اسم الشركة :";
            // 
            // NotestextBox
            // 
            this.NotestextBox.Location = new System.Drawing.Point(50, 59);
            this.NotestextBox.MaxLength = 10000000;
            this.NotestextBox.Multiline = true;
            this.NotestextBox.Name = "NotestextBox";
            this.NotestextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.NotestextBox.Size = new System.Drawing.Size(438, 37);
            this.NotestextBox.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Location = new System.Drawing.Point(133, 99);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(268, 36);
            this.panel2.TabIndex = 58;
            this.panel2.Visible = false;
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(6, 6);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboBox1.Size = new System.Drawing.Size(191, 21);
            this.comboBox1.TabIndex = 56;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(195, 7);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label6.Size = new System.Drawing.Size(61, 18);
            this.label6.TabIndex = 53;
            this.label6.Text = "اسم الفئة :";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Location = new System.Drawing.Point(136, 100);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(263, 36);
            this.panel1.TabIndex = 57;
            this.panel1.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Constantia", 11F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(179, 9);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label5.Size = new System.Drawing.Size(82, 18);
            this.label5.TabIndex = 55;
            this.label5.Text = " اسم الخدمة:";
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(6, 6);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboBox2.Size = new System.Drawing.Size(173, 21);
            this.comboBox2.TabIndex = 56;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(532, 105);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label4.Size = new System.Drawing.Size(45, 18);
            this.label4.TabIndex = 52;
            this.label4.Text = " خصم :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label4.Visible = false;
            // 
            // discountPerFloatText
            // 
            this.discountPerFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.discountPerFloatText.Location = new System.Drawing.Point(415, 105);
            this.discountPerFloatText.Name = "discountPerFloatText";
            this.discountPerFloatText.Size = new System.Drawing.Size(111, 20);
            this.discountPerFloatText.TabIndex = 51;
            this.discountPerFloatText.Text = "0";
            this.discountPerFloatText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.discountPerFloatText.Visible = false;
            this.discountPerFloatText.TextChanged += new System.EventHandler(this.discountPerFloatText_TextChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Checked = true;
            this.radioButton4.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.radioButton4.Location = new System.Drawing.Point(79, 5);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton4.Size = new System.Drawing.Size(79, 22);
            this.radioButton4.TabIndex = 6;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "بدون خصم";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.radioButton3.Location = new System.Drawing.Point(181, 5);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton3.Size = new System.Drawing.Size(124, 22);
            this.radioButton3.TabIndex = 5;
            this.radioButton3.Text = " خصم على الخدمات";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.radioButton2.Location = new System.Drawing.Point(341, 5);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton2.Size = new System.Drawing.Size(114, 22);
            this.radioButton2.TabIndex = 4;
            this.radioButton2.Text = " خصم على الفئات";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.radioButton1.Location = new System.Drawing.Point(485, 6);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton1.Size = new System.Drawing.Size(79, 22);
            this.radioButton1.TabIndex = 3;
            this.radioButton1.Text = "خصم عامة";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // searchBtn
            // 
            this.searchBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.searchBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.searchBtn.Location = new System.Drawing.Point(251, 15);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(112, 33);
            this.searchBtn.TabIndex = 4;
            this.searchBtn.Text = "بحث";
            this.searchBtn.UseVisualStyleBackColor = false;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.saveBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.saveBtn.Location = new System.Drawing.Point(487, 15);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(112, 33);
            this.saveBtn.TabIndex = 3;
            this.saveBtn.Text = "حفظ";
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.DeleteBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.DeleteBtn.Location = new System.Drawing.Point(133, 15);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(112, 33);
            this.DeleteBtn.TabIndex = 6;
            this.DeleteBtn.Text = "حذف";
            this.DeleteBtn.UseVisualStyleBackColor = false;
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // EditBtn
            // 
            this.EditBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.EditBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.EditBtn.Location = new System.Drawing.Point(369, 15);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(112, 33);
            this.EditBtn.TabIndex = 5;
            this.EditBtn.Text = "تعديل";
            this.EditBtn.UseVisualStyleBackColor = false;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.saveBtn);
            this.groupBox2.Controls.Add(this.EditBtn);
            this.groupBox2.Controls.Add(this.searchBtn);
            this.groupBox2.Controls.Add(this.DeleteBtn);
            this.groupBox2.Location = new System.Drawing.Point(10, 373);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(616, 58);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gainsboro;
            this.button2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(15, 15);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 33);
            this.button2.TabIndex = 7;
            this.button2.Text = "رجوع";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.dataGridView1);
            this.groupBox3.Font = new System.Drawing.Font("Arial", 9.75F);
            this.groupBox3.Location = new System.Drawing.Point(4, 432);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox3.Size = new System.Drawing.Size(626, 145);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(620, 124);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Location = new System.Drawing.Point(198, -5);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(235, 35);
            this.groupBox4.TabIndex = 81;
            this.groupBox4.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(67, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "الشركات";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.Controls.Add(this.panel4);
            this.groupBox5.Controls.Add(this.floatText3);
            this.groupBox5.Controls.Add(this.floatText2);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.floatText1);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.panel2);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.panel3);
            this.groupBox5.Controls.Add(this.panel1);
            this.groupBox5.Controls.Add(this.discountPerFloatText);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Location = new System.Drawing.Point(4, 109);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(629, 138);
            this.groupBox5.TabIndex = 82;
            this.groupBox5.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.radioButton5);
            this.panel4.Controls.Add(this.radioButton7);
            this.panel4.Location = new System.Drawing.Point(407, 10);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(195, 30);
            this.panel4.TabIndex = 67;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Checked = true;
            this.radioButton5.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.radioButton5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioButton5.Location = new System.Drawing.Point(102, 3);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton5.Size = new System.Drawing.Size(78, 22);
            this.radioButton5.TabIndex = 6;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "نسبة خصم";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.radioButton7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioButton7.Location = new System.Drawing.Point(2, 4);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.radioButton7.Size = new System.Drawing.Size(76, 22);
            this.radioButton7.TabIndex = 3;
            this.radioButton7.Text = "قيمة خصم";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // floatText3
            // 
            this.floatText3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.floatText3.Location = new System.Drawing.Point(21, 76);
            this.floatText3.Name = "floatText3";
            this.floatText3.Size = new System.Drawing.Size(111, 20);
            this.floatText3.TabIndex = 66;
            this.floatText3.Text = "0";
            this.floatText3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.floatText3.Visible = false;
            this.floatText3.TextChanged += new System.EventHandler(this.floatText3_TextChanged);
            // 
            // floatText2
            // 
            this.floatText2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.floatText2.Location = new System.Drawing.Point(220, 75);
            this.floatText2.Name = "floatText2";
            this.floatText2.Size = new System.Drawing.Size(111, 20);
            this.floatText2.TabIndex = 64;
            this.floatText2.Text = "0";
            this.floatText2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.floatText2.Visible = false;
            this.floatText2.TextChanged += new System.EventHandler(this.floatText2_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(337, 76);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label8.Size = new System.Drawing.Size(39, 18);
            this.label8.TabIndex = 63;
            this.label8.Text = "الأشعة";
            this.label8.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(138, 77);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label9.Size = new System.Drawing.Size(47, 18);
            this.label9.TabIndex = 65;
            this.label9.Text = "التحاليل";
            this.label9.Visible = false;
            // 
            // floatText1
            // 
            this.floatText1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.floatText1.Location = new System.Drawing.Point(415, 74);
            this.floatText1.Name = "floatText1";
            this.floatText1.Size = new System.Drawing.Size(111, 20);
            this.floatText1.TabIndex = 62;
            this.floatText1.Text = "0";
            this.floatText1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.floatText1.Visible = false;
            this.floatText1.TextChanged += new System.EventHandler(this.floatText1_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(532, 74);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label7.Size = new System.Drawing.Size(49, 18);
            this.label7.TabIndex = 61;
            this.label7.Text = "العمليات";
            this.label7.Visible = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gainsboro;
            this.button1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(31, 102);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(65, 29);
            this.button1.TabIndex = 60;
            this.button1.Text = "إضافة";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioButton4);
            this.panel3.Controls.Add(this.radioButton3);
            this.panel3.Controls.Add(this.radioButton1);
            this.panel3.Controls.Add(this.radioButton2);
            this.panel3.Location = new System.Drawing.Point(23, 41);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(579, 30);
            this.panel3.TabIndex = 59;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Transparent;
            this.groupBox6.Controls.Add(this.dataGridView2);
            this.groupBox6.Font = new System.Drawing.Font("Arial", 9.75F);
            this.groupBox6.Location = new System.Drawing.Point(3, 249);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox6.Size = new System.Drawing.Size(630, 123);
            this.groupBox6.TabIndex = 83;
            this.groupBox6.TabStop = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 18);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(624, 102);
            this.dataGridView2.TabIndex = 0;
            // 
            // Company
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(638, 583);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Company";
            this.Text = "الشركات";
            this.Load += new System.EventHandler(this.Company_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

		}

		public Company()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		public void RefreshData()
		{
			try
			{
				string[] fields = new string[1] { "Name" };
				DataTable dataTable = new DataTable();
				dataTable = ((!(Settings.Default.Language == "en-GB")) ? dc.Select("selectCompanyByName", fields, codes.SearchText("اسم الشركة")) : dc.Select("selectCompanyByName", fields, codes.SearchText("Company Name")));
				gui.loadDataGrid(dataGridView1, dataTable);
			}
			catch
			{
			}
		}

		private void searchBtn_Click(object sender, EventArgs e)
		{
			RefreshData();
		}

		public void Clear()
		{
			NametextBox.Text = "";
			NotestextBox.Text = "";
			EditBtn.Enabled = false;
			saveBtn.Enabled = true;
			DeleteBtn.Enabled = false;
			discountPerFloatText.Text = "0";
			radioButton4.Checked = true;
		}

		public void DataGrid()
		{
			try
			{
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns[0].Visible = false;
					dataGridView1.Columns[1].HeaderText = "Company Name";
					dataGridView1.Columns[1].Width = 242;
					dataGridView1.Columns[2].Width = 300;
					dataGridView1.Columns[2].HeaderText = "Notes";
				}
				else
				{
					dataGridView1.Columns[0].Visible = false;
					dataGridView1.Columns[1].HeaderText = "اسم الشركة";
					dataGridView1.Columns[1].Width = 242;
					dataGridView1.Columns[2].Width = 300;
					dataGridView1.Columns[2].HeaderText = "ملاحظات";
				}
				dataGridView1.Columns[3].Visible = false;
				dataGridView1.Columns[4].Visible = false;
				dataGridView1.Columns[5].Visible = false;
				dataGridView1.Columns[6].Visible = false;
				dataGridView1.Columns[7].Visible = false;
				dataGridView1.Columns[8].Visible = false;
			}
			catch
			{
			}
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (NametextBox.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Company Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الشركة");
					}
					return;
				}
				DataTable tableText = dc.GetTableText("select * from Company where Name='" + NametextBox.Text + "'");
				if (tableText.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This Company Before");
					}
					else
					{
						MessageBox.Show("اسم الشركة مسجل من قبل");
					}
					return;
				}
				if ((radioButton2.Checked || radioButton3.Checked) && dataGridView2.Rows.Count == 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Data");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل البيانات");
					}
					return;
				}
				string[] fields = new string[8] { "Name", "Notes", "Status", "Discount", "DisOp", "DisRay", "DisAnalyze", "Nesba" };
				int num = 1;
				string value = "0";
				string value2 = "0";
				string value3 = "0";
				string text = codes.Search2("select isnull(Max(ID)+1,1) from Company").Rows[0][0].ToString();
				if (text == "2")
				{
					text = "4";
				}
				if (radioButton1.Checked)
				{
					num = 1;
					value = discountPerFloatText.Text;
					value2 = discountPerFloatText.Text;
					value3 = discountPerFloatText.Text;
				}
				if (radioButton2.Checked)
				{
					num = 2;
					for (int i = 0; i < dataGridView2.Rows.Count; i++)
					{
						codes.Add2("insert into DiscountCategory (CompanyId, Category, Discount) values('" + text + "','" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "','" + dataGridView2.Rows[i].Cells[2].Value.ToString() + "')");
					}
					value = floatText1.Text;
					value2 = floatText2.Text;
					value3 = floatText3.Text;
				}
				if (radioButton3.Checked)
				{
					num = 3;
					for (int i = 0; i < dataGridView2.Rows.Count; i++)
					{
						codes.Add2("insert into DiscountService (CompanyId, Service, Discount) values('" + text + "','" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "','" + dataGridView2.Rows[i].Cells[2].Value.ToString() + "')");
					}
					value = floatText1.Text;
					value2 = floatText2.Text;
					value3 = floatText3.Text;
				}
				if (radioButton4.Checked)
				{
					num = 4;
					value = "0";
					value2 = "0";
					value3 = "0";
				}
				if (dc.Insert("Addcompany", fields, NametextBox.Text, NotestextBox.Text, num, discountPerFloatText.Text, Convert.ToDecimal(value), Convert.ToDecimal(value2), Convert.ToDecimal(value3), radioButton5.Checked))
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					MethodsClass.UserMove("أضافة شركة");
					AllData();
					Clear();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			catch
			{
			}
		}

		private void NametextBox_TextChanged(object sender, EventArgs e)
		{
			string text = NametextBox.Text;
			if (text.StartsWith(" "))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("It IS Not Allowed To Use Space In The Beginning", "Notes");
				}
				else
				{
					MessageBox.Show("لا يمكن ترك فراغ في بداية الإسم", "تنبيه");
				}
				NametextBox.Text = "";
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					if (NametextBox.Text == "")
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please enter Company Name");
						}
						else
						{
							MessageBox.Show("من فضلك ادخل اسم الشركة");
						}
						return;
					}
					DataTable tableText = dc.GetTableText("select * from Company where Name='" + NametextBox.Text + "'and ID <>'" + ID + "'");
					if (tableText.Rows.Count > 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Have Save This Company Before");
						}
						else
						{
							MessageBox.Show("اسم الشركة مسجل من قبل");
						}
						AllData();
						return;
					}
					if ((radioButton2.Checked || radioButton3.Checked) && dataGridView2.Rows.Count == 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please enter Data");
						}
						else
						{
							MessageBox.Show("من فضلك ادخل البيانات");
						}
						return;
					}
					string[] fields = new string[9] { "ID", "Name", "Notes", "Status", "Discount", "DisOp", "DisRay", "DisAnalyze", "Nesba" };
					int num = 1;
					string value = "0";
					if (radioButton1.Checked)
					{
						num = 1;
						value = discountPerFloatText.Text;
						_ = discountPerFloatText.Text;
						_ = discountPerFloatText.Text;
					}
					if (radioButton2.Checked)
					{
						num = 2;
						if (status == 2)
						{
							codes.Delete2("delete from DiscountCategory where CompanyId = '" + ID + "'");
							for (int i = 0; i < dataGridView2.Rows.Count; i++)
							{
								codes.Add2("insert into DiscountCategory (CompanyId, Category, Discount) values('" + ID + "','" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "','" + dataGridView2.Rows[i].Cells[2].Value.ToString() + "')");
							}
						}
						else
						{
							codes.Delete2("delete from DiscountService where CompanyId = '" + ID + "'");
							for (int i = 0; i < dataGridView2.Rows.Count; i++)
							{
								codes.Add2("insert into DiscountCategory (CompanyId, Category, Discount) values('" + ID + "','" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "','" + dataGridView2.Rows[i].Cells[2].Value.ToString() + "')");
							}
						}
						value = floatText1.Text;
						_ = floatText2.Text;
						_ = floatText3.Text;
					}
					if (radioButton3.Checked)
					{
						num = 3;
						if (status == 2)
						{
							codes.Delete2("delete from DiscountCategory where CompanyId = '" + ID + "'");
							for (int i = 0; i < dataGridView2.Rows.Count; i++)
							{
								codes.Add2("insert into DiscountService (CompanyId, Service, Discount) values('" + ID + "','" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "','" + dataGridView2.Rows[i].Cells[2].Value.ToString() + "')");
							}
						}
						else
						{
							codes.Delete2("delete from DiscountService where CompanyId = '" + ID + "'");
							for (int i = 0; i < dataGridView2.Rows.Count; i++)
							{
								codes.Add2("insert into DiscountService (CompanyId, Service, Discount) values('" + ID + "','" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "','" + dataGridView2.Rows[i].Cells[2].Value.ToString() + "')");
							}
						}
						value = floatText1.Text;
						_ = floatText2.Text;
						_ = floatText3.Text;
					}
					if (radioButton4.Checked)
					{
						num = 4;
						value = "0";
						codes.Delete2("delete from DiscountService where CompanyId = '" + ID + "'");
						codes.Delete2("delete from DiscountCategory where CompanyId = '" + ID + "'");
					}
					if (dc.Insert("updatecompany", fields, ID, NametextBox.Text, NotestextBox.Text, num, discountPerFloatText.Text, Convert.ToDecimal(value), Convert.ToDecimal(floatText2.Text), Convert.ToDecimal(floatText3.Text), radioButton5.Checked))
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Updated Successfully", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم تعديل البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove("تعديل شركة");
						Clear();
						AllData();
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Error Happend While Updating", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء تعديل البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Select Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اختر البيانات أولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void DeleteBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					DialogResult dialogResult = DialogResult.None;
					dialogResult = ((!(Settings.Default.Language == "en-GB")) ? MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) : MessageBox.Show("Are You Sure You Want To Delete This Company?", "", MessageBoxButtons.OKCancel, MessageBoxIcon.Question));
					if (dialogResult != DialogResult.OK)
					{
						return;
					}
					if (status == 2)
					{
						codes.Delete2("delete from DiscountCategory where CompanyId = '" + ID + "'");
					}
					else
					{
						codes.Delete2("delete from DiscountService where CompanyId = '" + ID + "'");
					}
					string[] fields = new string[1] { "ID" };
					if (dc.Delete("deleteCompany", fields, Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString())))
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Company Deleted Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove("حذف شركة");
						Clear();
						AllData();
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("An Error Occurred During The Deletion Process ", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Select Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اختر البيانات أولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			EditBtn.Enabled = true;
			saveBtn.Enabled = false;
			DeleteBtn.Enabled = true;
			dataGridView2.DataSource = null;
			dataGridView2.Rows.Clear();
			ID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
			NametextBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
			NotestextBox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
			status = Convert.ToInt32(dataGridView1.CurrentRow.Cells[3].Value.ToString());
			if (status == 1)
			{
				radioButton1.Checked = true;
				discountPerFloatText.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
			}
			if (status == 2)
			{
				radioButton2.Checked = true;
				DataTable dataTable = codes.Search2("select CompanyId, Category, Discount from DiscountCategory where CompanyId = '" + ID + "'");
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					dataGridView2.Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString());
				}
			}
			if (status == 3)
			{
				radioButton3.Checked = true;
				DataTable dataTable = codes.Search2("select CompanyId, Service, Discount from DiscountService where CompanyId = '" + ID + "'");
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					dataGridView2.Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString());
				}
			}
			if (status == 4)
			{
				radioButton4.Checked = true;
			}
			floatText1.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
			floatText2.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
			floatText3.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
			radioButton5.Checked = Convert.ToBoolean(dataGridView1.CurrentRow.Cells[8].Value.ToString());
		}

		public void AllData()
		{
			try
			{
				DataTable tableText = dc.GetTableText("select * from Company");
				dataGridView1.DataSource = tableText;
			}
			catch
			{
			}
			DataGrid();
		}

		private void Company_Load(object sender, EventArgs e)
		{
			AllData();
			Clear();
			EditBtn.Enabled = false;
			saveBtn.Enabled = true;
			DeleteBtn.Enabled = false;
			try
			{
				DataTable tableText = dc.GetTableText("select distinct(Service) from CompanyService");
				comboBox2.DataSource = tableText;
				comboBox2.DisplayMember = tableText.Columns[0].ToString();
				comboBox2.ValueMember = tableText.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable tableText = dc.GetTableText("select id,name from Categories");
				comboBox1.DataSource = tableText;
				comboBox1.ValueMember = "id";
				comboBox1.DisplayMember = "name";
			}
			catch
			{
			}
		}

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{
			label4.Visible = true;
			discountPerFloatText.Visible = true;
			discountPerFloatText.Text = "0";
			panel1.Visible = false;
			panel2.Visible = false;
			button1.Visible = false;
			dataGridView2.Rows.Clear();
			dataGridView2.Columns.Clear();
			panel3.Enabled = true;
			label7.Visible = false;
			label8.Visible = false;
			label9.Visible = false;
			floatText1.Visible = false;
			floatText2.Visible = false;
			floatText3.Visible = false;
			floatText1.Text = "0";
			floatText2.Text = "0";
			floatText3.Text = "0";
			if (Settings.Default.Language == "en-GB")
			{
				MessageBox.Show("Discount :");
			}
			else
			{
				label4.Text = "نسبة خصم :";
			}
		}

		private void radioButton2_CheckedChanged(object sender, EventArgs e)
		{
			dataGridView2.Columns.Clear();
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView2.Columns.Add("Column1", "ID");
				dataGridView2.Columns.Add("Column2", "Category Name");
				dataGridView2.Columns.Add("Column3", "Discount");
				dataGridView2.Columns[0].Visible = false;
			}
			else
			{
				dataGridView2.Columns.Add("Column1", "ID");
				dataGridView2.Columns.Add("Column2", "اسم الفئة");
				dataGridView2.Columns.Add("Column3", "الخصم");
				dataGridView2.Columns[0].Visible = false;
			}
			label4.Visible = true;
			discountPerFloatText.Visible = true;
			discountPerFloatText.Text = "0";
			panel1.Visible = false;
			panel2.Visible = true;
			button1.Visible = true;
			label7.Visible = true;
			label8.Visible = true;
			label9.Visible = true;
			floatText1.Visible = true;
			floatText2.Visible = true;
			floatText3.Visible = true;
			floatText1.Text = "0";
			floatText2.Text = "0";
			floatText3.Text = "0";
			if (Settings.Default.Language == "en-GB")
			{
				label4.Text = "Discount on Category :";
			}
			else
			{
				label4.Text = "خصم للفئة :";
			}
		}

		private void radioButton3_CheckedChanged(object sender, EventArgs e)
		{
			dataGridView2.Columns.Clear();
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView2.Columns.Add("Column1", "ID");
				dataGridView2.Columns.Add("Column2", "Service Name");
				dataGridView2.Columns.Add("Column3", "Discount");
				dataGridView2.Columns[0].Visible = false;
			}
			else
			{
				dataGridView2.Columns.Add("Column1", "ID");
				dataGridView2.Columns.Add("Column2", "اسم الخدمة");
				dataGridView2.Columns.Add("Column3", "نسبة الخصم");
				dataGridView2.Columns[0].Visible = false;
			}
			label4.Visible = true;
			discountPerFloatText.Visible = true;
			discountPerFloatText.Text = "0";
			panel1.Visible = true;
			panel2.Visible = false;
			button1.Visible = true;
			label7.Visible = true;
			label8.Visible = true;
			label9.Visible = true;
			floatText1.Visible = true;
			floatText2.Visible = true;
			floatText3.Visible = true;
			floatText1.Text = "0";
			floatText2.Text = "0";
			floatText3.Text = "0";
			if (Settings.Default.Language == "en-GB")
			{
				label4.Text = "Discount on Service :";
			}
			else
			{
				label4.Text = "خصم للخدمة :";
			}
		}

		private void radioButton4_CheckedChanged(object sender, EventArgs e)
		{
			label4.Visible = false;
			discountPerFloatText.Visible = false;
			discountPerFloatText.Text = "0";
			panel1.Visible = false;
			panel2.Visible = false;
			button1.Visible = false;
			dataGridView2.Rows.Clear();
			dataGridView2.Columns.Clear();
			panel3.Enabled = true;
			label7.Visible = false;
			label8.Visible = false;
			label9.Visible = false;
			floatText1.Visible = false;
			floatText2.Visible = false;
			floatText3.Visible = false;
			floatText1.Text = "0";
			floatText2.Text = "0";
			floatText3.Text = "0";
			if (Settings.Default.Language == "en-GB")
			{
				label4.Text = "Discount :";
			}
			else
			{
				label4.Text = "خصم :";
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			int i;
			if (radioButton2.Checked)
			{
				if (dataGridView2.Rows.Count == 0)
				{
					dataGridView2.Rows.Add(0, comboBox1.Text, discountPerFloatText.Text, comboBox1.SelectedValue.ToString());
					discountPerFloatText.Text = "0";
				}
				else
				{
					for (i = 0; i < dataGridView2.Rows.Count; i++)
					{
						if (dataGridView2.Rows[i].Cells[1].Value.ToString() == comboBox1.Text)
						{
							if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("You Have Save This Category Before");
							}
							else
							{
								MessageBox.Show("هذه الفئة مسجل من قبل");
							}
							return;
						}
					}
					dataGridView2.Rows.Add(0, comboBox1.Text, discountPerFloatText.Text, comboBox1.SelectedValue.ToString());
					discountPerFloatText.Text = "0";
				}
			}
			if (!radioButton3.Checked)
			{
				return;
			}
			if (dataGridView2.Rows.Count == 0)
			{
				dataGridView2.Rows.Add(0, comboBox2.Text, discountPerFloatText.Text, comboBox2.SelectedValue.ToString());
				discountPerFloatText.Text = "0";
				return;
			}
			i = 0;
			while (true)
			{
				if (i < dataGridView2.Rows.Count)
				{
					if (dataGridView2.Rows[i].Cells[1].Value.ToString() == comboBox2.Text)
					{
						break;
					}
					i++;
					continue;
				}
				dataGridView2.Rows.Add(0, comboBox2.Text, discountPerFloatText.Text, comboBox2.SelectedValue.ToString());
				discountPerFloatText.Text = "0";
				return;
			}
			if (Settings.Default.Language == "en-GB")
			{
				MessageBox.Show("You Have Save This Service Before");
			}
			else
			{
				MessageBox.Show("هذه الخدمة مسجل من قبل");
			}
		}

		private void discountPerFloatText_TextChanged(object sender, EventArgs e)
		{
			if (discountPerFloatText.Text == "")
			{
				discountPerFloatText.Text = "0";
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			AllData();
			Clear();
		}

		private void floatText1_TextChanged(object sender, EventArgs e)
		{
			if (Convert.ToDecimal(floatText1.Text) > 100m)
			{
				floatText1.Text = "0";
			}
		}

		private void floatText2_TextChanged(object sender, EventArgs e)
		{
			if (Convert.ToDecimal(floatText2.Text) > 100m)
			{
				floatText2.Text = "0";
			}
		}

		private void floatText3_TextChanged(object sender, EventArgs e)
		{
			if (Convert.ToDecimal(floatText3.Text) > 100m)
			{
				floatText3.Text = "0";
			}
		}
	}
}
