using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using FatoumDataGrid;
using NationalIdText;

namespace DentistClinic
{
	public class Supplier : BaseForm
	{
		private IContainer components = null;

		private Button AddBtn;

		private Button DeleteBtn;

		private TextBox MobileText;

		private TextBox SuppphoneTxt;

		private TextBox addressText;

		private GroupBox groupBox1;

		private TextBox NameText;

		private Label label5;

		private Label label4;

		private Label label3;

		private Label label2;

		private Label label1;

		private Button EditBtn;

		private Button SearchBtn;

		private Button backBtn;

		private global::NationalIdText.NationalIdText NationatIdText;

		private Panel panel1;

		private FatouDataGrid dataGridView1;

		private GroupBox groupBox3;

		private ClassDataBase cr;

		private int SupplierID;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		private GUI gui = new GUI();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.Supplier));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			AddBtn = new System.Windows.Forms.Button();
			DeleteBtn = new System.Windows.Forms.Button();
			MobileText = new System.Windows.Forms.TextBox();
			SuppphoneTxt = new System.Windows.Forms.TextBox();
			addressText = new System.Windows.Forms.TextBox();
			groupBox1 = new System.Windows.Forms.GroupBox();
			NameText = new System.Windows.Forms.TextBox();
			label5 = new System.Windows.Forms.Label();
			label4 = new System.Windows.Forms.Label();
			label3 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			EditBtn = new System.Windows.Forms.Button();
			SearchBtn = new System.Windows.Forms.Button();
			backBtn = new System.Windows.Forms.Button();
			NationatIdText = new global::NationalIdText.NationalIdText();
			panel1 = new System.Windows.Forms.Panel();
			dataGridView1 = new FatoumDataGrid.FatouDataGrid();
			groupBox3 = new System.Windows.Forms.GroupBox();
			panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			AddBtn.AccessibleDescription = null;
			AddBtn.AccessibleName = null;
			resources.ApplyResources(AddBtn, "AddBtn");
			AddBtn.BackColor = System.Drawing.Color.LightGray;
			AddBtn.BackgroundImage = null;
			AddBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			AddBtn.Name = "AddBtn";
			AddBtn.UseVisualStyleBackColor = false;
			AddBtn.Click += new System.EventHandler(AddBtn_Click);
			DeleteBtn.AccessibleDescription = null;
			DeleteBtn.AccessibleName = null;
			resources.ApplyResources(DeleteBtn, "DeleteBtn");
			DeleteBtn.BackColor = System.Drawing.Color.LightGray;
			DeleteBtn.BackgroundImage = null;
			DeleteBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			DeleteBtn.Name = "DeleteBtn";
			DeleteBtn.UseVisualStyleBackColor = false;
			DeleteBtn.Click += new System.EventHandler(DeleteBtn_Click);
			MobileText.AccessibleDescription = null;
			MobileText.AccessibleName = null;
			resources.ApplyResources(MobileText, "MobileText");
			MobileText.BackgroundImage = null;
			MobileText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			MobileText.Font = null;
			MobileText.Name = "MobileText";
			MobileText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(CompMobileText_KeyPress);
			SuppphoneTxt.AccessibleDescription = null;
			SuppphoneTxt.AccessibleName = null;
			resources.ApplyResources(SuppphoneTxt, "SuppphoneTxt");
			SuppphoneTxt.BackgroundImage = null;
			SuppphoneTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			SuppphoneTxt.Font = null;
			SuppphoneTxt.Name = "SuppphoneTxt";
			SuppphoneTxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(CompphoneTxt_KeyPress);
			addressText.AccessibleDescription = null;
			addressText.AccessibleName = null;
			resources.ApplyResources(addressText, "addressText");
			addressText.BackgroundImage = null;
			addressText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			addressText.Font = null;
			addressText.Name = "addressText";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			NameText.AccessibleDescription = null;
			NameText.AccessibleName = null;
			resources.ApplyResources(NameText, "NameText");
			NameText.BackgroundImage = null;
			NameText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			NameText.Font = null;
			NameText.Name = "NameText";
			NameText.TextChanged += new System.EventHandler(CompNameText_TextChanged);
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label5");
			label5.BackColor = System.Drawing.Color.Transparent;
			label5.Name = "label5";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.BackColor = System.Drawing.Color.Transparent;
			label4.Name = "label4";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.BackColor = System.Drawing.Color.Transparent;
			label3.Name = "label3";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.BackColor = System.Drawing.Color.Transparent;
			label2.Name = "label2";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.BackColor = System.Drawing.Color.Transparent;
			label1.Name = "label1";
			EditBtn.AccessibleDescription = null;
			EditBtn.AccessibleName = null;
			resources.ApplyResources(EditBtn, "EditBtn");
			EditBtn.BackColor = System.Drawing.Color.LightGray;
			EditBtn.BackgroundImage = null;
			EditBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			EditBtn.Name = "EditBtn";
			EditBtn.UseVisualStyleBackColor = false;
			EditBtn.Click += new System.EventHandler(EditBtn_Click);
			SearchBtn.AccessibleDescription = null;
			SearchBtn.AccessibleName = null;
			resources.ApplyResources(SearchBtn, "SearchBtn");
			SearchBtn.BackColor = System.Drawing.Color.LightGray;
			SearchBtn.BackgroundImage = null;
			SearchBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			SearchBtn.Name = "SearchBtn";
			SearchBtn.UseVisualStyleBackColor = false;
			SearchBtn.Click += new System.EventHandler(SearchBtn_Click);
			backBtn.AccessibleDescription = null;
			backBtn.AccessibleName = null;
			resources.ApplyResources(backBtn, "backBtn");
			backBtn.BackColor = System.Drawing.Color.LightGray;
			backBtn.BackgroundImage = null;
			backBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			backBtn.Name = "backBtn";
			backBtn.UseVisualStyleBackColor = false;
			backBtn.Click += new System.EventHandler(backBtn_Click);
			NationatIdText.AccessibleDescription = null;
			NationatIdText.AccessibleName = null;
			resources.ApplyResources(NationatIdText, "NationatIdText");
			NationatIdText.BackgroundImage = null;
			NationatIdText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			NationatIdText.Font = null;
			NationatIdText.Name = "NationatIdText";
			panel1.AccessibleDescription = null;
			panel1.AccessibleName = null;
			resources.ApplyResources(panel1, "panel1");
			panel1.BackColor = System.Drawing.Color.Transparent;
			panel1.BackgroundImage = null;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(dataGridView1);
			panel1.Controls.Add(groupBox3);
			panel1.Controls.Add(NationatIdText);
			panel1.Controls.Add(SuppphoneTxt);
			panel1.Controls.Add(AddBtn);
			panel1.Controls.Add(MobileText);
			panel1.Controls.Add(DeleteBtn);
			panel1.Controls.Add(label1);
			panel1.Controls.Add(EditBtn);
			panel1.Controls.Add(label2);
			panel1.Controls.Add(SearchBtn);
			panel1.Controls.Add(groupBox1);
			panel1.Controls.Add(backBtn);
			panel1.Controls.Add(addressText);
			panel1.Controls.Add(label3);
			panel1.Controls.Add(NameText);
			panel1.Controls.Add(label4);
			panel1.Controls.Add(label5);
			panel1.Font = null;
			panel1.Name = "panel1";
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			dataGridViewCellStyle.BackColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(218, 230, 252);
			dataGridView1.BackgroundImage = null;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold);
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = System.Drawing.Color.AliceBlue;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
			dataGridView1.RowTemplate.Height = 26;
			dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseClick);
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			base.AcceptButton = AddBtn;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(panel1);
			Font = null;
			base.Name = "Supplier";
			base.Load += new System.EventHandler(Supplier_Load);
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
		}

		public Supplier()
		{
			InitializeComponent();
			cr = new ClassDataBase(".\\sqlExpress");
		}

		public void searchData()
		{
			try
			{
				DataTable tableText = cr.GetTableText("select * from Supplier");
				dataGridView1.DataSource = tableText;
				DataGrid();
			}
			catch
			{
			}
		}

		public void DataGrid()
		{
			dataGridView1.Columns[0].Visible = false;
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView1.Columns[1].HeaderText = "Supplier Name";
				dataGridView1.Columns[2].HeaderText = "Address";
				dataGridView1.Columns[4].HeaderText = "Phone";
				dataGridView1.Columns[5].HeaderText = "Mobile";
			}
			else
			{
				dataGridView1.Columns[1].HeaderText = "اسم المورد";
				dataGridView1.Columns[2].HeaderText = "العنوان";
				dataGridView1.Columns[4].HeaderText = "التليفون";
				dataGridView1.Columns[5].HeaderText = "الموبايل";
			}
			dataGridView1.Columns[1].Width = 200;
			dataGridView1.Columns[2].Width = 250;
			dataGridView1.Columns[3].Visible = false;
		}

		public void ClearData()
		{
			addressText.Text = "";
			SuppphoneTxt.Text = "";
			NameText.Text = "";
			MobileText.Text = "";
			NationatIdText.Text = "";
			EditBtn.Enabled = false;
			DeleteBtn.Enabled = false;
		}

		private void AddBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = cr.GetTableText("select * from Supplier where SupName='" + NameText.Text + "'");
				string[] fields = new string[5] { "SupName", "SupAddress", "NationalId", "Tel", "Mobile" };
				if (NameText.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Supplier Name", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المورد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else if (tableText.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This Name Before", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("هذا الإسم مسجل من قبل", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else if (cr.Insert("addSupplier", fields, NameText.Text, addressText.Text, NationatIdText.Text, SuppphoneTxt.Text, MobileText.Text))
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Saved Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					MethodsClass.UserMove(" أضافة مورد جديد");
					ClearData();
					searchData();
				}
			}
			catch
			{
			}
		}

		private void Supplier_Load(object sender, EventArgs e)
		{
			searchData();
			DeleteBtn.Enabled = false;
			EditBtn.Enabled = false;
		}

		private void SearchBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = cr.GetTableText("select * from Supplier where SupName like  '%" + codes.SearchText("") + "%'");
				gui.loadDataGrid(dataGridView1, tableText);
			}
			catch
			{
			}
		}

		private void backBtn_Click(object sender, EventArgs e)
		{
			ClearData();
			AddBtn.Enabled = true;
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.CurrentRow.Cells[0].Value.ToString() == null)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("اختر البيانات اولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					return;
				}
				DataTable tableText = cr.GetTableText("select * from Supplier where SupName='" + NameText.Text + "'and SupplierID<>'" + SupplierID + "'");
				string[] fields = new string[6] { "SupplierID", "SupName", "SupAddress", "NationalId", "Tel", "Mobile" };
				if (NameText.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Supplier Name", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المورد", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else if (tableText.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This Name Before", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("هذا الإسم مسجل من قبل", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else if (cr.Update("updateSupplier", fields, SupplierID, NameText.Text, addressText.Text, NationatIdText.Text, SuppphoneTxt.Text, MobileText.Text))
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Saved Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					MethodsClass.UserMove(" تعديل بيانات مورد ");
					ClearData();
					searchData();
					AddBtn.Enabled = true;
				}
			}
			catch
			{
			}
		}

		private void DeleteBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.CurrentRow.Cells[0].Value.ToString() == null)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Select Data For Delete");
					}
					else
					{
						MessageBox.Show("ادخل البيانات للحذف");
					}
					return;
				}
				DialogResult dialogResult = DialogResult.None;
				dialogResult = ((!(Settings.Default.Language == "en-GB")) ? MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) : MessageBox.Show("Are You Sure You Want To Delete This Data?", "", MessageBoxButtons.OKCancel, MessageBoxIcon.Question));
				if (dialogResult != DialogResult.OK)
				{
					return;
				}
				string[] fields = new string[1] { "SupplierID" };
				if (cr.Delete("deleteSupplier", fields, SupplierID))
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Deleted Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					MethodsClass.UserMove(" حذف بيانات مورد");
					ClearData();
					searchData();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("An Error Occurred During The Deletion Process ", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void CompNameText_TextChanged(object sender, EventArgs e)
		{
			try
			{
				string text = NameText.Text;
				if (text.StartsWith(" "))
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("It IS Not Allowed To Use Space In The Beginning", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("لا يمكن ترك فراغ في بداية الإسم", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					NameText.Text = "";
				}
			}
			catch
			{
			}
		}

		private void CompphoneTxt_KeyPress(object sender, KeyPressEventArgs e)
		{
			char keyChar = e.KeyChar;
			if (!char.IsDigit(keyChar) && keyChar != '\b')
			{
				e.Handled = true;
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل ارقام فقط");
				}
			}
		}

		private void CompMobileText_KeyPress(object sender, KeyPressEventArgs e)
		{
			char keyChar = e.KeyChar;
			if (!char.IsDigit(keyChar) && keyChar != '\b')
			{
				e.Handled = true;
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل ارقام فقط");
				}
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count == 1)
				{
					DeleteBtn.Enabled = true;
					EditBtn.Enabled = true;
					AddBtn.Enabled = false;
					SupplierID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
					NameText.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
					addressText.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
					SuppphoneTxt.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
					MobileText.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
					NationatIdText.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اختر البيانات اولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}
	}
}
