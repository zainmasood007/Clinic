using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using VistaButtonTest;

namespace DentistClinic
{
	public class FmPioneers : Form
	{
		private IContainer components = null;

		private VistaButton vistaButton1;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			vistaButton1 = new VistaButtonTest.VistaButton();
			SuspendLayout();
			vistaButton1.BackColor = System.Drawing.Color.Transparent;
			vistaButton1.BaseColor = System.Drawing.Color.Transparent;
			vistaButton1.ButtonColor = System.Drawing.Color.Transparent;
			vistaButton1.ButtonText = "X";
			vistaButton1.Cursor = System.Windows.Forms.Cursors.Hand;
			vistaButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			vistaButton1.ForeColor = System.Drawing.Color.Red;
			vistaButton1.Location = new System.Drawing.Point(413, 12);
			vistaButton1.Name = "vistaButton1";
			vistaButton1.Size = new System.Drawing.Size(26, 27);
			vistaButton1.TabIndex = 0;
			vistaButton1.Click += new System.EventHandler(vistaButton1_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
//			BackgroundImage = DentistClinic.Properties.Resources.DentalClinicsplash;
			BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			base.ClientSize = new System.Drawing.Size(451, 445);
			base.Controls.Add(vistaButton1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "FmPioneers";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "FmPioneers";
			ResumeLayout(false);
		}

		public FmPioneers()
		{
			InitializeComponent();
		}

		private void vistaButton1_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
