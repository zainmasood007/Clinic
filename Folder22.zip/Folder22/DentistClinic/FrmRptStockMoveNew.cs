using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmRptStockMoveNew : ReportBaseForm
	{
		private IContainer components = null;

		private CrystalReportViewer crystalReportViewer1;

		private GroupBox groupBox1;

		private Button ViewRptBtn;

		private DateTimePicker date2;

		private DateTimePicker date1;

		private Label label3;

		private Label label2;

		private DataGridView dataGridView1;

		private Label label4;

		private ComboBox StockCom;

		private DataSet1 dataSet11;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlDeleteCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlSelectCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlCommand3;

		private SqlConnection sqlConnection3;

		private SqlDataAdapter sqlDataAdapter3;

		private SqlCommand sqlCommand1;

		private SqlCommand sqlCommand4;

		private SqlCommand sqlCommand5;

		private SqlConnection sqlConnection4;

		private SqlDataAdapter sqlDataAdapter4;

		private SqlCommand sqlCommand6;

		private SqlCommand sqlCommand7;

		private SqlCommand sqlCommand8;

		private SqlCommand sqlCommand11;

		private SqlCommand sqlCommand14;

		private SqlCommand sqlDeleteCommand;

		private SqlCommand sqlUpdateCommand;

		private ClassDataBase dc;

		private double pay;

		private double take;

		private decimal balance;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmRptStockMoveNew));
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			groupBox1 = new System.Windows.Forms.GroupBox();
			label4 = new System.Windows.Forms.Label();
			StockCom = new System.Windows.Forms.ComboBox();
			ViewRptBtn = new System.Windows.Forms.Button();
			date2 = new System.Windows.Forms.DateTimePicker();
			date1 = new System.Windows.Forms.DateTimePicker();
			label3 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			dataSet11 = new DataSet1();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlConnection3 = new System.Data.SqlClient.SqlConnection();
			sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlCommand5 = new System.Data.SqlClient.SqlCommand();
			sqlConnection4 = new System.Data.SqlClient.SqlConnection();
			sqlDataAdapter4 = new System.Data.SqlClient.SqlDataAdapter();
			sqlDeleteCommand = new System.Data.SqlClient.SqlCommand();
			sqlCommand6 = new System.Data.SqlClient.SqlCommand();
			sqlCommand7 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand = new System.Data.SqlClient.SqlCommand();
			sqlCommand8 = new System.Data.SqlClient.SqlCommand();
			sqlCommand11 = new System.Data.SqlClient.SqlCommand();
			sqlCommand14 = new System.Data.SqlClient.SqlCommand();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(StockCom);
			groupBox1.Controls.Add(ViewRptBtn);
			groupBox1.Controls.Add(date2);
			groupBox1.Controls.Add(date1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(label2);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Name = "label4";
			StockCom.AccessibleDescription = null;
			StockCom.AccessibleName = null;
			resources.ApplyResources(StockCom, "StockCom");
			StockCom.BackgroundImage = null;
			StockCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			StockCom.Font = null;
			StockCom.FormattingEnabled = true;
			StockCom.Name = "StockCom";
			ViewRptBtn.AccessibleDescription = null;
			ViewRptBtn.AccessibleName = null;
			resources.ApplyResources(ViewRptBtn, "ViewRptBtn");
			ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
			ViewRptBtn.BackgroundImage = null;
			ViewRptBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			ViewRptBtn.Name = "ViewRptBtn";
			ViewRptBtn.UseVisualStyleBackColor = false;
			ViewRptBtn.Click += new System.EventHandler(ViewRptBtn_Click);
			date2.AccessibleDescription = null;
			date2.AccessibleName = null;
			resources.ApplyResources(date2, "date2");
			date2.BackgroundImage = null;
			date2.CalendarFont = null;
			date2.Font = null;
			date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date2.Name = "date2";
			date2.ValueChanged += new System.EventHandler(date2_ValueChanged);
			date1.AccessibleDescription = null;
			date1.AccessibleName = null;
			resources.ApplyResources(date1, "date1");
			date1.BackgroundImage = null;
			date1.CalendarFont = null;
			date1.Font = null;
			date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date1.Name = "date1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[8]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Car.mdf;Integrated Security=True;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo")
			});
			sqlSelectCommand1.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDataAdapter2.InsertCommand = sqlCommand2;
			sqlDataAdapter2.SelectCommand = sqlCommand3;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientAccount", new System.Data.Common.DataColumnMapping[24]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("PatientId", "PatientId"),
					new System.Data.Common.DataColumnMapping("DoctorID", "DoctorID"),
					new System.Data.Common.DataColumnMapping("Bean", "Bean"),
					new System.Data.Common.DataColumnMapping("Price", "Price"),
					new System.Data.Common.DataColumnMapping("Pay", "Pay"),
					new System.Data.Common.DataColumnMapping("Date", "Date"),
					new System.Data.Common.DataColumnMapping("PricePay", "PricePay"),
					new System.Data.Common.DataColumnMapping("BeanDate", "BeanDate"),
					new System.Data.Common.DataColumnMapping("TeathId", "TeathId"),
					new System.Data.Common.DataColumnMapping("Appears", "Appears"),
					new System.Data.Common.DataColumnMapping("VisitID", "VisitID"),
					new System.Data.Common.DataColumnMapping("AppointNum", "AppointNum"),
					new System.Data.Common.DataColumnMapping("Assistant", "Assistant"),
					new System.Data.Common.DataColumnMapping("StockId", "StockId"),
					new System.Data.Common.DataColumnMapping("RayId", "RayId"),
					new System.Data.Common.DataColumnMapping("AnalyzeId", "AnalyzeId"),
					new System.Data.Common.DataColumnMapping("DiscountValue", "DiscountValue"),
					new System.Data.Common.DataColumnMapping("ServiceCount", "ServiceCount"),
					new System.Data.Common.DataColumnMapping("Dariba", "Dariba"),
					new System.Data.Common.DataColumnMapping("PriceBeforeDariba", "PriceBeforeDariba"),
					new System.Data.Common.DataColumnMapping("EnterDiscount", "EnterDiscount"),
					new System.Data.Common.DataColumnMapping("EnterDiscountValue", "EnterDiscountValue"),
					new System.Data.Common.DataColumnMapping("wieght", "wieght")
				})
			});
			sqlCommand2.CommandText = resources.GetString("sqlCommand2.CommandText");
			sqlCommand2.Connection = sqlConnection2;
			sqlCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[23]
			{
				new System.Data.SqlClient.SqlParameter("@PatientId", System.Data.SqlDbType.Int, 0, "PatientId"),
				new System.Data.SqlClient.SqlParameter("@DoctorID", System.Data.SqlDbType.Int, 0, "DoctorID"),
				new System.Data.SqlClient.SqlParameter("@Bean", System.Data.SqlDbType.NVarChar, 0, "Bean"),
				new System.Data.SqlClient.SqlParameter("@Price", System.Data.SqlDbType.Money, 0, "Price"),
				new System.Data.SqlClient.SqlParameter("@Pay", System.Data.SqlDbType.Bit, 0, "Pay"),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
				new System.Data.SqlClient.SqlParameter("@PricePay", System.Data.SqlDbType.Money, 0, "PricePay"),
				new System.Data.SqlClient.SqlParameter("@BeanDate", System.Data.SqlDbType.DateTime, 0, "BeanDate"),
				new System.Data.SqlClient.SqlParameter("@TeathId", System.Data.SqlDbType.Int, 0, "TeathId"),
				new System.Data.SqlClient.SqlParameter("@Appears", System.Data.SqlDbType.Bit, 0, "Appears"),
				new System.Data.SqlClient.SqlParameter("@VisitID", System.Data.SqlDbType.Int, 0, "VisitID"),
				new System.Data.SqlClient.SqlParameter("@AppointNum", System.Data.SqlDbType.Int, 0, "AppointNum"),
				new System.Data.SqlClient.SqlParameter("@Assistant", System.Data.SqlDbType.NVarChar, 0, "Assistant"),
				new System.Data.SqlClient.SqlParameter("@StockId", System.Data.SqlDbType.Int, 0, "StockId"),
				new System.Data.SqlClient.SqlParameter("@RayId", System.Data.SqlDbType.Int, 0, "RayId"),
				new System.Data.SqlClient.SqlParameter("@AnalyzeId", System.Data.SqlDbType.Int, 0, "AnalyzeId"),
				new System.Data.SqlClient.SqlParameter("@DiscountValue", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "DiscountValue", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@ServiceCount", System.Data.SqlDbType.Int, 0, "ServiceCount"),
				new System.Data.SqlClient.SqlParameter("@Dariba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Dariba", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@PriceBeforeDariba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "PriceBeforeDariba", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@EnterDiscount", System.Data.SqlDbType.NVarChar, 0, "EnterDiscount"),
				new System.Data.SqlClient.SqlParameter("@EnterDiscountValue", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "EnterDiscountValue", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@wieght", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 0, "wieght", System.Data.DataRowVersion.Current, null)
			});
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlCommand3.CommandText = "SELECT        PatientAccount.*\r\nFROM            PatientAccount";
			sqlCommand3.Connection = sqlConnection2;
			sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection3.FireInfoMessageEventOnUserErrors = false;
			sqlDataAdapter3.InsertCommand = sqlCommand1;
			sqlDataAdapter3.SelectCommand = sqlCommand4;
			sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[54]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
					new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
					new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
					new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
					new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
					new System.Data.Common.DataColumnMapping("Implant", "Implant"),
					new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
					new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers"),
					new System.Data.Common.DataColumnMapping("DoctoreName", "DoctoreName"),
					new System.Data.Common.DataColumnMapping("NextVisit", "NextVisit"),
					new System.Data.Common.DataColumnMapping("Accept", "Accept"),
					new System.Data.Common.DataColumnMapping("Taqweem", "Taqweem"),
					new System.Data.Common.DataColumnMapping("Photo", "Photo"),
					new System.Data.Common.DataColumnMapping("BloodType", "BloodType"),
					new System.Data.Common.DataColumnMapping("Active", "Active"),
					new System.Data.Common.DataColumnMapping("FileNo", "FileNo"),
					new System.Data.Common.DataColumnMapping("Patient", "Patient"),
					new System.Data.Common.DataColumnMapping("Facebook", "Facebook"),
					new System.Data.Common.DataColumnMapping("Adv", "Adv"),
					new System.Data.Common.DataColumnMapping("FormerPatient", "FormerPatient"),
					new System.Data.Common.DataColumnMapping("Discount", "Discount"),
					new System.Data.Common.DataColumnMapping("Without", "Without"),
					new System.Data.Common.DataColumnMapping("Doctor", "Doctor"),
					new System.Data.Common.DataColumnMapping("DoctorId", "DoctorId"),
					new System.Data.Common.DataColumnMapping("nationalID", "nationalID"),
					new System.Data.Common.DataColumnMapping("Dariba", "Dariba"),
					new System.Data.Common.DataColumnMapping("NextvisitTXT", "NextvisitTXT")
				})
			});
			sqlCommand1.CommandText = resources.GetString("sqlCommand1.CommandText");
			sqlCommand1.Connection = sqlConnection3;
			sqlCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[53]
			{
				new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
				new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
				new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
				new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
				new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
				new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
				new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
				new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
				new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
				new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
				new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
				new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
				new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
				new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
				new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
				new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
				new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
				new System.Data.SqlClient.SqlParameter("@Lactating", System.Data.SqlDbType.Bit, 0, "Lactating"),
				new System.Data.SqlClient.SqlParameter("@Pregnant", System.Data.SqlDbType.Bit, 0, "Pregnant"),
				new System.Data.SqlClient.SqlParameter("@HepatitisB", System.Data.SqlDbType.Bit, 0, "HepatitisB"),
				new System.Data.SqlClient.SqlParameter("@Hepatitisc", System.Data.SqlDbType.Bit, 0, "Hepatitisc"),
				new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
				new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
				new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
				new System.Data.SqlClient.SqlParameter("@Endodontics", System.Data.SqlDbType.Bit, 0, "Endodontics"),
				new System.Data.SqlClient.SqlParameter("@Fixed", System.Data.SqlDbType.Bit, 0, "Fixed"),
				new System.Data.SqlClient.SqlParameter("@Implant", System.Data.SqlDbType.Bit, 0, "Implant"),
				new System.Data.SqlClient.SqlParameter("@Opretive", System.Data.SqlDbType.Bit, 0, "Opretive"),
				new System.Data.SqlClient.SqlParameter("@Bleaching", System.Data.SqlDbType.Bit, 0, "Bleaching"),
				new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers"),
				new System.Data.SqlClient.SqlParameter("@DoctoreName", System.Data.SqlDbType.NVarChar, 0, "DoctoreName"),
				new System.Data.SqlClient.SqlParameter("@NextVisit", System.Data.SqlDbType.NVarChar, 0, "NextVisit"),
				new System.Data.SqlClient.SqlParameter("@Accept", System.Data.SqlDbType.Bit, 0, "Accept"),
				new System.Data.SqlClient.SqlParameter("@Taqweem", System.Data.SqlDbType.Bit, 0, "Taqweem"),
				new System.Data.SqlClient.SqlParameter("@Photo", System.Data.SqlDbType.Image, 0, "Photo"),
				new System.Data.SqlClient.SqlParameter("@BloodType", System.Data.SqlDbType.NVarChar, 0, "BloodType"),
				new System.Data.SqlClient.SqlParameter("@Active", System.Data.SqlDbType.Bit, 0, "Active"),
				new System.Data.SqlClient.SqlParameter("@FileNo", System.Data.SqlDbType.Int, 0, "FileNo"),
				new System.Data.SqlClient.SqlParameter("@Patient", System.Data.SqlDbType.Bit, 0, "Patient"),
				new System.Data.SqlClient.SqlParameter("@Facebook", System.Data.SqlDbType.Bit, 0, "Facebook"),
				new System.Data.SqlClient.SqlParameter("@Adv", System.Data.SqlDbType.Bit, 0, "Adv"),
				new System.Data.SqlClient.SqlParameter("@FormerPatient", System.Data.SqlDbType.NVarChar, 0, "FormerPatient"),
				new System.Data.SqlClient.SqlParameter("@Discount", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Discount", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Without", System.Data.SqlDbType.Bit, 0, "Without"),
				new System.Data.SqlClient.SqlParameter("@Doctor", System.Data.SqlDbType.Bit, 0, "Doctor"),
				new System.Data.SqlClient.SqlParameter("@DoctorId", System.Data.SqlDbType.NVarChar, 0, "DoctorId"),
				new System.Data.SqlClient.SqlParameter("@nationalID", System.Data.SqlDbType.VarChar, 0, "nationalID"),
				new System.Data.SqlClient.SqlParameter("@Dariba", System.Data.SqlDbType.Bit, 0, "Dariba"),
				new System.Data.SqlClient.SqlParameter("@NextvisitTXT", System.Data.SqlDbType.NVarChar, 0, "NextvisitTXT")
			});
			sqlCommand4.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlCommand4.Connection = sqlConnection3;
			sqlCommand5.CommandText = resources.GetString("sqlCommand5.CommandText");
			sqlCommand5.Connection = sqlConnection1;
			sqlCommand5.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo")
			});
			sqlConnection4.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection4.FireInfoMessageEventOnUserErrors = false;
			sqlDataAdapter4.DeleteCommand = sqlDeleteCommand;
			sqlDataAdapter4.InsertCommand = sqlCommand6;
			sqlDataAdapter4.SelectCommand = sqlCommand7;
			sqlDataAdapter4.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "CompanyService", new System.Data.Common.DataColumnMapping[7]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("CompanyID", "CompanyID"),
					new System.Data.Common.DataColumnMapping("Service", "Service"),
					new System.Data.Common.DataColumnMapping("Price", "Price"),
					new System.Data.Common.DataColumnMapping("Dariba", "Dariba"),
					new System.Data.Common.DataColumnMapping("DiscountNesba", "DiscountNesba"),
					new System.Data.Common.DataColumnMapping("DiscountValue", "DiscountValue")
				})
			});
			sqlDataAdapter4.UpdateCommand = sqlUpdateCommand;
			sqlDeleteCommand.CommandText = resources.GetString("sqlDeleteCommand.CommandText");
			sqlDeleteCommand.Connection = sqlConnection4;
			sqlDeleteCommand.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[11]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_CompanyID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "CompanyID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_CompanyID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "CompanyID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Price", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Price", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Price", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Price", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Dariba", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Dariba", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Dariba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Dariba", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountNesba", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountNesba", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountNesba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "DiscountNesba", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountValue", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountValue", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountValue", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "DiscountValue", System.Data.DataRowVersion.Original, null)
			});
			sqlCommand6.CommandText = resources.GetString("sqlCommand6.CommandText");
			sqlCommand6.Connection = sqlConnection4;
			sqlCommand6.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[6]
			{
				new System.Data.SqlClient.SqlParameter("@CompanyID", System.Data.SqlDbType.Int, 0, "CompanyID"),
				new System.Data.SqlClient.SqlParameter("@Service", System.Data.SqlDbType.NVarChar, 0, "Service"),
				new System.Data.SqlClient.SqlParameter("@Price", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Price", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Dariba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Dariba", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@DiscountNesba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "DiscountNesba", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@DiscountValue", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "DiscountValue", System.Data.DataRowVersion.Current, null)
			});
			sqlCommand7.CommandText = "SELECT        CompanyService.*\r\nFROM            CompanyService";
			sqlCommand7.Connection = sqlConnection4;
			sqlUpdateCommand.CommandText = resources.GetString("sqlUpdateCommand.CommandText");
			sqlUpdateCommand.Connection = sqlConnection4;
			sqlUpdateCommand.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[18]
			{
				new System.Data.SqlClient.SqlParameter("@CompanyID", System.Data.SqlDbType.Int, 0, "CompanyID"),
				new System.Data.SqlClient.SqlParameter("@Service", System.Data.SqlDbType.NVarChar, 0, "Service"),
				new System.Data.SqlClient.SqlParameter("@Price", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Price", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Dariba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Dariba", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@DiscountNesba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "DiscountNesba", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@DiscountValue", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "DiscountValue", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_CompanyID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "CompanyID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_CompanyID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "CompanyID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Price", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Price", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Price", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Price", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Dariba", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Dariba", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Dariba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Dariba", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountNesba", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountNesba", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountNesba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "DiscountNesba", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountValue", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountValue", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountValue", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "DiscountValue", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlCommand8.CommandText = resources.GetString("sqlCommand8.CommandText");
			sqlCommand8.Connection = sqlConnection1;
			sqlCommand8.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo")
			});
			sqlCommand11.CommandText = resources.GetString("sqlCommand11.CommandText");
			sqlCommand11.Connection = sqlConnection1;
			sqlCommand11.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo")
			});
			sqlCommand14.CommandText = resources.GetString("sqlCommand14.CommandText");
			sqlCommand14.Connection = sqlConnection1;
			sqlCommand14.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo")
			});
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(crystalReportViewer1);
			base.Controls.Add(groupBox1);
			base.Controls.Add(dataGridView1);
			Font = null;
			base.Icon = null;
			base.Name = "FrmRptStockMoveNew";
			base.Load += new System.EventHandler(FrmRptStockMove_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(FrmRptStockMove_KeyDown);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}

		public FrmRptStockMoveNew()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		public FrmRptStockMoveNew(DateTime d1, DateTime d2, string FileName)
		{
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			try
			{
				dataGridView1.Rows.Clear();
				dataSet11.Clear();
				sqlConnection1.ConnectionString = dc.ConnectionStr;
				sqlConnection2.ConnectionString = dc.ConnectionStr;
				sqlConnection3.ConnectionString = dc.ConnectionStr;
				sqlConnection4.ConnectionString = dc.ConnectionStr;
				sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter2.SelectCommand.CommandText = string.Concat("  SELECT        dbo.PatientAccount.*\r\nFROM            dbo.PatientAccount \r\nwhere ID in (select PatientAcountId from Esal where Esal.Date between '", date1.Value.ToString("MM/dd/yyyy"), "' and '", date2.Value.ToString("MM/dd/yyyy"), "') and StockId ='", StockCom.SelectedValue, "'  and Bean<>'خدمة ثابتة'");
				DataTable tableText = dc.GetTableText(string.Concat("  SELECT        dbo.PatientAccount.*\r\nFROM            dbo.PatientAccount \r\nwhere ID in (select PatientAcountId from Esal where Esal.Date between '", date1.Value.ToString("MM/dd/yyyy"), "' and '", date2.Value.ToString("MM/dd/yyyy"), "') and StockId ='", StockCom.SelectedValue, "'  and Bean<>'خدمة ثابتة'"));
				if (tableText.Rows.Count < 1)
				{
					MessageBox.Show("لا يوجد بيانات في هذه الفترة");
					return;
				}
				DataTable tableText2 = dc.GetTableText(string.Concat("  SELECT    dbo.PatientAccount.DoctorID,PatientAccount.Bean\r\nFROM            dbo.PatientAccount \r\nwhere ID in (select PatientAcountId from Esal where Esal.Date between '", date1.Value.ToString("MM/dd/yyyy"), "' and '", date2.Value.ToString("MM/dd/yyyy"), "') and StockId ='", StockCom.SelectedValue, "' and Bean<>'خدمة ثابتة'  group by  dbo.PatientAccount.DoctorID,PatientAccount.Bean"));
				int num = 0;
				num = Convert.ToInt32(dc.GetTableText("select isnull(max(ID),0)+1 from NesbaDoctor").Rows[0][0].ToString());
				for (int i = 0; i < tableText2.Rows.Count; i++)
				{
					DataTable tableText3 = dc.GetTableText("select * from NesbaDoctor where Service='" + tableText2.Rows[i][1].ToString() + "' and DoctorID='" + Convert.ToInt32(tableText2.Rows[i][0].ToString()) + "'");
					if (tableText3.Rows.Count > 0)
					{
						((DataTable)(object)dataSet11.NesbaDoctor).Rows.Add(Convert.ToInt32(tableText3.Rows[0][0]), Convert.ToString(tableText3.Rows[0][1]), Convert.ToInt32(tableText3.Rows[0][2]), Convert.ToString(tableText3.Rows[0][3]), Convert.ToDecimal(tableText3.Rows[0][4]), Convert.ToDecimal(tableText3.Rows[0][5]), Convert.ToDecimal(tableText3.Rows[0][6]), Convert.ToDecimal(tableText3.Rows[0][7]), Convert.ToDecimal(tableText3.Rows[0][8]), Convert.ToInt32(tableText3.Rows[0][9]));
					}
					else
					{
						DataTable tableText4 = dc.GetTableText("select Name from Empdata where ID='" + Convert.ToInt32(tableText2.Rows[i][0].ToString()) + "'");
						((DataTable)(object)dataSet11.NesbaDoctor).Rows.Add(num, Convert.ToString(tableText4.Rows[0][0].ToString()), 0, tableText2.Rows[i][1].ToString(), 0, 0, 0, 0, 0, Convert.ToInt32(tableText2.Rows[i][0].ToString()));
					}
					num++;
				}
				DataTable tableText5 = dc.GetTableText(string.Concat("  SELECT    dbo.PatientAccount.Assistant,PatientAccount.Bean\r\nFROM            dbo.PatientAccount \r\nwhere ID in (select PatientAcountId from Esal where Esal.Date between '", date1.Value.ToString("MM/dd/yyyy"), "' and '", date2.Value.ToString("MM/dd/yyyy"), "') and StockId ='", StockCom.SelectedValue, "' and Bean<>'خدمة ثابتة' group by  dbo.PatientAccount.Assistant,PatientAccount.Bean"));
				int num2 = 0;
				num2 = Convert.ToInt32(dc.GetTableText("select isnull(max(ID),0)+1 from NesbaAssistant").Rows[0][0].ToString());
				for (int i = 0; i < tableText5.Rows.Count; i++)
				{
					DataTable tableText6 = dc.GetTableText("select * from NesbaAssistant where Service='" + tableText5.Rows[i][1].ToString() + "' and Assistant='" + tableText5.Rows[i][0].ToString() + "'");
					if (tableText6.Rows.Count > 0)
					{
						((DataTable)(object)dataSet11.NesbaAssistant).Rows.Add(Convert.ToInt32(tableText6.Rows[0][0]), Convert.ToString(tableText6.Rows[0][1]), Convert.ToInt32(tableText6.Rows[0][2]), Convert.ToString(tableText6.Rows[0][3]), Convert.ToDecimal(tableText6.Rows[0][4]), Convert.ToDecimal(tableText6.Rows[0][5]), Convert.ToDecimal(tableText6.Rows[0][6]), Convert.ToDecimal(tableText6.Rows[0][7]), Convert.ToDecimal(tableText6.Rows[0][8]));
					}
					else
					{
						((DataTable)(object)dataSet11.NesbaAssistant).Rows.Add(num2, tableText5.Rows[i][0].ToString(), 0, tableText5.Rows[i][1].ToString(), 0, 0, 0, 0, 0);
					}
					num2++;
				}
				sqlDataAdapter1.Fill(dataSet11);
				sqlDataAdapter2.Fill(dataSet11);
				sqlDataAdapter3.Fill(dataSet11);
				sqlDataAdapter4.Fill(dataSet11);
				((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value, date2.Value);
				RptStockMoveNew rptStockMoveNew = new RptStockMoveNew();
				rptStockMoveNew.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = rptStockMoveNew;
			}
			catch
			{
			}
		}

		private void FrmRptStockMove_Load(object sender, EventArgs e)
		{
			dataGridView1.Columns.Add("price", "السعر");
			dataGridView1.Columns.Add("date", "التاريخ");
			dataGridView1.Columns.Add("type", "البيان");
			dataGridView1.Columns.Add("bean", "تفصيلى");
			dataGridView1.Columns.Add("move", "الحاله");
			try
			{
				DataTable tableText = dc.GetTableText("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				StockCom.DataSource = null;
				StockCom.DataSource = tableText;
				StockCom.DisplayMember = tableText.Columns[1].ToString();
				StockCom.ValueMember = tableText.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void FrmRptStockMove_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void date2_ValueChanged(object sender, EventArgs e)
		{
		}
	}
}
