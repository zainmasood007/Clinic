using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Media;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class DoctorBackReserve : BaseForm
	{
		private ClassDataBase dc;

		private GUI gui = new GUI();

		private dataClass codes = new dataClass(".\\sqlExpress");

		public static int DoctorId;

		private IContainer components = null;

		private GroupBox groupBox1;

		private DataGridView dataGridView1;

		private Label label1;

		private GroupBox groupBox2;

		private DateTimePicker dateTimePicker1;

		private Label label3;

		public DoctorBackReserve()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		public void DataGrid()
		{
			string[] fields = new string[2] { "ID", "detectDate" };
			dc.Select("doctorpackreserve", fields, DoctorId, dateTimePicker1.Value.ToString("MM/dd/yyyy"));
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView1.Columns["PName"].HeaderText = "Patient Name";
				dataGridView1.Columns["PName"].Width = 150;
				dataGridView1.Columns["AppointNum"].HeaderText = "Appointment No.";
				dataGridView1.Columns[1].Width = 100;
				dataGridView1.Columns["Titel"].HeaderText = " ";
				dataGridView1.Columns["Doctor ID"].Visible = false;
				dataGridView1.Columns["Patient ID"].Visible = false;
				dataGridView1.Columns["PAddress"].HeaderText = "Address";
				dataGridView1.Columns["PAddress"].Width = 200;
				dataGridView1.Columns["Titel"].HeaderText = "Social Status";
				dataGridView1.Columns["Name"].HeaderText = "Company Name";
				dataGridView1.Columns["BirthDate"].HeaderText = "Birth Date";
				dataGridView1.Columns["LastVistDate"].HeaderText = "Last Visit Date";
				dataGridView1.Columns["FileNo"].HeaderText = "File Number";
			}
			else
			{
				dataGridView1.Columns["PName"].HeaderText = "اسم المريض";
				dataGridView1.Columns["PName"].Width = 150;
				dataGridView1.Columns[1].HeaderText = "رقم الكشف";
				dataGridView1.Columns[1].Width = 100;
				dataGridView1.Columns["Doctor ID"].Visible = false;
				dataGridView1.Columns["Patient ID"].Visible = false;
				dataGridView1.Columns["PAddress"].Width = 200;
				dataGridView1.Columns["Titel"].HeaderText = "الحالة الاجتماعية";
				dataGridView1.Columns["PAddress"].HeaderText = "العنوان";
				dataGridView1.Columns["Name"].HeaderText = "اسم الشركة";
				dataGridView1.Columns["BirthDate"].HeaderText = "تاريخ الميلاد";
				dataGridView1.Columns["LastVistDate"].HeaderText = "تاريخ آخر زيارة";
				dataGridView1.Columns["FileNo"].HeaderText = "كود المريض";
			}
			dataGridView1.Columns["Status"].Visible = false;
			if (Settings.Default.Language == "en-GB")
			{
				foreach (DataGridViewRow item in (IEnumerable)dataGridView1.Rows)
				{
					if (item.Cells["Status"].Value.ToString() == "Confirmed")
					{
						item.DefaultCellStyle.BackColor = Color.FromArgb(187, 240, 188);
					}
					else if (item.Cells["Status"].Value.ToString() == "Not Confirmed")
					{
						item.DefaultCellStyle.BackColor = Color.FromArgb(201, 226, 245);
					}
					else if (item.Cells["Status"].Value.ToString() == "Cancelled")
					{
						item.DefaultCellStyle.BackColor = Color.FromArgb(240, 209, 200);
					}
				}
			}
			else
			{
				foreach (DataGridViewRow item2 in (IEnumerable)dataGridView1.Rows)
				{
					if (item2.Cells["Status"].Value.ToString() == "تم التأكيد")
					{
						item2.DefaultCellStyle.BackColor = Color.FromArgb(187, 240, 188);
					}
					else if (item2.Cells["Status"].Value.ToString() == "لم يؤكد")
					{
						item2.DefaultCellStyle.BackColor = Color.FromArgb(201, 226, 245);
					}
					else if (item2.Cells["Status"].Value.ToString() == "تم إلغاؤه")
					{
						item2.DefaultCellStyle.BackColor = Color.FromArgb(240, 209, 200);
					}
				}
			}
			dataGridView1.Columns[11].Visible = false;
			dataGridView1.Columns[12].Visible = false;
			dataGridView1.Columns[13].Visible = false;
			dataGridView1.Columns[14].Visible = false;
			dataGridView1.Columns[15].Visible = false;
			dataGridView1.Columns[16].Visible = false;
			dataGridView1.Columns[17].Visible = false;
			dataGridView1.Columns[18].Visible = false;
			dataGridView1.Columns[19].Visible = false;
			dataGridView1.Columns[20].Visible = false;
			dataGridView1.Columns[21].Visible = false;
			dataGridView1.Columns[22].Visible = false;
			dataGridView1.Columns[23].Visible = false;
			dataGridView1.Columns[24].Visible = false;
			dataGridView1.Columns[25].Visible = false;
			dataGridView1.Columns[26].Visible = false;
			dataGridView1.Columns[27].Visible = false;
			dataGridView1.Columns[28].Visible = false;
			dataGridView1.Columns[29].Visible = false;
			dataGridView1.Columns[30].Visible = false;
			dataGridView1.Columns[31].Visible = false;
		}

		public void sound()
		{
			SoundPlayer soundPlayer = new SoundPlayer(Resources.translate_tts);
			soundPlayer.Play();
		}

		public void Doctor()
		{
			try
			{
				string[] fields = new string[2] { "ID", "detectDate" };
				DataTable dataTable = codes.Search2("select AcceptPatients from Properties");
				DataTable dt = ((!Convert.ToBoolean(dataTable.Rows[0][0].ToString())) ? dc.Select("doctorpackreserve", fields, DoctorId, dateTimePicker1.Value.ToString("MM/dd/yyyy")) : codes.Search2("SELECT     Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID',PatientData.FileNo, PatientData.Titel, PatientData.PName, PatientData.PAddress, \r\n                      PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, \r\n                      PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB, \r\n                      PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy, \r\n                      PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status\r\nFROM         PatientData INNER JOIN\r\n                      Company ON PatientData.company = Company.ID INNER JOIN\r\n                      Empdata INNER JOIN\r\n                      Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID WHERE (Appointments.Status='تم التأكيد' or Appointments.Status='Confirmed') and (Empdata.ID ='" + DoctorId + "') AND (Appointments.packDate ='" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "') AND (Appointments.PackDone = 'false') GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID,PatientData.FileNo, PatientData.Titel, PatientData.PName, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Bleaching, PatientData.Opretive, PatientData.Hepatitisc, PatientData.HepatitisB, PatientData.Pregnant, PatientData.Lactating,Appointments.Status ,Appointments.AcceptDate order by   CONVERT(VARCHAR(10),Appointments.AcceptDate, 108) asc"));
				gui.loadDataGrid(dataGridView1, dt);
				DataGrid();
				if (dataGridView1.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						label3.Text = "Number Of Reservations: " + Convert.ToString(dataGridView1.Rows.Count.ToString());
					}
					else
					{
						label3.Text = "عدد الحجوزات : " + Convert.ToString(dataGridView1.Rows.Count.ToString());
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					label3.Text = "No Reservation";
				}
				else
				{
					label3.Text = "لا يوجد حجز";
				}
			}
			catch
			{
			}
		}

		private void DoctorBackReserve_Load(object sender, EventArgs e)
		{
			Doctor();
		}

		private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
		{
			Doctor();
		}

		private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
		{
		}

		private void DoctorBackReserve_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				PationtAccountReBack pationtAccountReBack = new PationtAccountReBack(int.Parse(dataGridView1.CurrentRow.Cells[3].Value.ToString()), int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString()), DoctorId);
				pationtAccountReBack.ShowDialog();
				Doctor();
				if (dataGridView1.Rows.Count > 0)
				{
					sound();
					if (Settings.Default.Language == "en-GB")
					{
						label3.Text = "Number Of Reservations: " + Convert.ToString(dataGridView1.Rows.Count.ToString());
					}
					else
					{
						label3.Text = "عدد الحجوزات : " + Convert.ToString(dataGridView1.Rows.Count.ToString());
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					label3.Text = "No Reservation";
				}
				else
				{
					label3.Text = "لا يوجد حجز";
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.DoctorBackReserve));
			groupBox1 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			label1 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label3 = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox2.SuspendLayout();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(dataGridView1);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowTemplate.Height = 30;
			dataGridView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(dataGridView1_MouseDoubleClick);
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			dataGridView1.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_CellMouseDoubleClick);
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(label1);
			groupBox2.Controls.Add(dateTimePicker1);
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.Font = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			dateTimePicker1.ValueChanged += new System.EventHandler(dateTimePicker1_ValueChanged);
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			label3.ForeColor = System.Drawing.Color.Maroon;
			label3.Name = "label3";
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox2);
			base.Controls.Add(label3);
			Font = null;
			base.Name = "DoctorBackReserve";
			base.Load += new System.EventHandler(DoctorBackReserve_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(DoctorBackReserve_KeyDown);
			groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
