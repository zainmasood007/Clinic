using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using VistaButtonTest;

namespace DentistClinic
{
	public class FrmSplash : Form
	{
		private dataClass codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private Button button1;

		private VistaButton vistaButton1;

		public FrmSplash()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void FrmSplash_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select Pic1 from MainPics");
				SqlBytes sqlBytes = new SqlBytes((byte[])dataTable.Rows[0][0]);
				BackgroundImage = Image.FromStream(sqlBytes.Stream);
			}
			catch
			{
			}
		}

		private void vistaButton1_Click(object sender, EventArgs e)
		{
			Close();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmSplash));
			button1 = new System.Windows.Forms.Button();
			vistaButton1 = new VistaButtonTest.VistaButton();
			SuspendLayout();
			button1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			button1.BackColor = System.Drawing.Color.White;
			button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
			button1.FlatAppearance.BorderSize = 0;
			button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			button1.ForeColor = System.Drawing.Color.Black;
			button1.Location = new System.Drawing.Point(2002, 215);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(21, 22);
			button1.TabIndex = 79;
			button1.Text = "X";
			button1.UseVisualStyleBackColor = false;
			button1.Visible = false;
			button1.Click += new System.EventHandler(button1_Click);
			vistaButton1.BackColor = System.Drawing.Color.Transparent;
			vistaButton1.BaseColor = System.Drawing.Color.FromArgb(132, 234, 252);
			vistaButton1.ButtonColor = System.Drawing.Color.Transparent;
			vistaButton1.ButtonText = "X";
			vistaButton1.Cursor = System.Windows.Forms.Cursors.Hand;
			vistaButton1.Font = new System.Drawing.Font("Arial", 10f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			vistaButton1.ForeColor = System.Drawing.Color.Black;
			vistaButton1.GlowColor = System.Drawing.Color.Transparent;
			vistaButton1.HighlightColor = System.Drawing.Color.Transparent;
			vistaButton1.Location = new System.Drawing.Point(473, 2);
			vistaButton1.Name = "vistaButton1";
			vistaButton1.Size = new System.Drawing.Size(26, 27);
			vistaButton1.TabIndex = 81;
			vistaButton1.Click += new System.EventHandler(vistaButton1_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.Blue;
			BackgroundImage = DentistClinic.Properties.Resources.clinic_splash5;
			BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			base.ClientSize = new System.Drawing.Size(500, 657);
			base.Controls.Add(vistaButton1);
			base.Controls.Add(button1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.Name = "FrmSplash";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "من نحن";
			base.TransparencyKey = System.Drawing.Color.Blue;
			base.Load += new System.EventHandler(FrmSplash_Load);
			ResumeLayout(false);
		}
	}
}
