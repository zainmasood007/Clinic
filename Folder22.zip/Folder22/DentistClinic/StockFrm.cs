using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using FloatTextBox;

namespace DentistClinic
{
	public class StockFrm : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private FloatText ValueText;

		private TextBox Nots;

		private Label label4;

		private TextBox GuardText;

		private TextBox Nametect;

		private Label label3;

		private Label label2;

		private Label label1;

		private Button button1;

		private Button button2;

		private Button button3;

		private DataGridView dataGridView1;

		private Button button4;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private int id;

		private GeneralMethods MethodsClass = new GeneralMethods();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.StockFrm));
			groupBox1 = new System.Windows.Forms.GroupBox();
			ValueText = new FloatTextBox.FloatText();
			Nots = new System.Windows.Forms.TextBox();
			label4 = new System.Windows.Forms.Label();
			GuardText = new System.Windows.Forms.TextBox();
			Nametect = new System.Windows.Forms.TextBox();
			label3 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			button1 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			button4 = new System.Windows.Forms.Button();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(ValueText);
			groupBox1.Controls.Add(Nots);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(GuardText);
			groupBox1.Controls.Add(Nametect);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(label1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			ValueText.AccessibleDescription = null;
			ValueText.AccessibleName = null;
			resources.ApplyResources(ValueText, "ValueText");
			ValueText.BackgroundImage = null;
			ValueText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			ValueText.Font = null;
			ValueText.Name = "ValueText";
			Nots.AccessibleDescription = null;
			Nots.AccessibleName = null;
			resources.ApplyResources(Nots, "Nots");
			Nots.BackgroundImage = null;
			Nots.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			Nots.Font = null;
			Nots.Name = "Nots";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Font = null;
			label4.Name = "label4";
			GuardText.AccessibleDescription = null;
			GuardText.AccessibleName = null;
			resources.ApplyResources(GuardText, "GuardText");
			GuardText.BackgroundImage = null;
			GuardText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			GuardText.Font = null;
			GuardText.Name = "GuardText";
			Nametect.AccessibleDescription = null;
			Nametect.AccessibleName = null;
			resources.ApplyResources(Nametect, "Nametect");
			Nametect.BackgroundImage = null;
			Nametect.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			Nametect.Font = null;
			Nametect.Name = "Nametect";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Font = null;
			label3.Name = "label3";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Font = null;
			label2.Name = "label2";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.Name = "label1";
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackgroundImage = null;
			button3.Font = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseClick);
			button4.AccessibleDescription = null;
			button4.AccessibleName = null;
			resources.ApplyResources(button4, "button4");
			button4.BackgroundImage = null;
			button4.Font = null;
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = true;
			button4.Click += new System.EventHandler(button4_Click);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(button4);
			base.Controls.Add(dataGridView1);
			base.Controls.Add(button3);
			base.Controls.Add(button2);
			base.Controls.Add(button1);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "StockFrm";
			base.Load += new System.EventHandler(StockFrm_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
		}

		public StockFrm()
		{
			InitializeComponent();
		}

		public void ClearData()
		{
			try
			{
				Nametect.Text = "";
				GuardText.Text = "";
				ValueText.Text = "0";
				Nots.Text = "";
				ValueText.Enabled = true;
				button2.Visible = false;
				button1.Visible = true;
			}
			catch
			{
			}
		}

		public void GetData()
		{
			try
			{
				DataTable dataSource = Codes.Search2("select * from Stock ");
				dataGridView1.DataSource = null;
				dataGridView1.DataSource = dataSource;
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].Visible = false;
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns[2].HeaderText = "Treasury Name";
				}
				else
				{
					dataGridView1.Columns[2].HeaderText = "اسم الخزينة";
				}
				dataGridView1.Columns[3].Visible = false;
				dataGridView1.Columns[4].Visible = false;
				dataGridView1.Columns[2].Width = 250;
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("select * from stock where Name='" + Nametect.Text + "'");
				if (Nametect.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Treasury Name");
					}
					else
					{
						MessageBox.Show("من فضلك قم بادخال اسم الخزينة");
					}
					return;
				}
				if (dataTable.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This Before");
					}
					else
					{
						MessageBox.Show("اسم الخزينة مسجل من قبل");
					}
					return;
				}
				try
				{
					Codes.Add2("INSERT INTO Stock (Value, Name, StockGuard, Nots) VALUES ('" + ValueText.Text + "','" + Nametect.Text + "','" + GuardText.Text + "','" + Nots.Text + "')");
					Codes.Add2("insert into StokeMove (Price, date, Type, StockId) values('" + ValueText.Text + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','رصيد اول المدة','" + Codes.Search2("select max(id) from stock").Rows[0][0].ToString() + "')");
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Saved Successfully");
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح");
					}
					MethodsClass.UserMove("أضافة خزينة");
				}
				catch (Exception)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Error Happend While Saving");
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حفظ البيانات");
					}
					return;
				}
				GetData();
				ClearData();
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				GetData();
				ClearData();
				button2.Visible = false;
				button1.Visible = true;
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
				ValueText.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
				ValueText.Enabled = false;
				Nametect.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
				GuardText.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
				Nots.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
				button2.Visible = true;
				button1.Visible = false;
				DataTable dataTable = Codes.Search2("select * from StokeMove where StockId=" + id);
				if (dataTable.Rows.Count == 0)
				{
					ValueText.Enabled = true;
				}
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("select * from stock where Name='" + Nametect.Text + "' where Id<>'" + id + "'");
				if (Nametect.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Treasury Name");
					}
					else
					{
						MessageBox.Show("من فضلك قم بادخال اسم الخزينة");
					}
					return;
				}
				if (dataTable.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This Before");
					}
					else
					{
						MessageBox.Show("اسم الخزينة مسجل من قبل");
					}
					return;
				}
				try
				{
					if (ValueText.Enabled)
					{
						Codes.Edit2("UPDATE Stock SET value='" + ValueText.Text + "', Name ='" + Nametect.Text + "', StockGuard ='" + GuardText.Text + "', Nots ='" + Nots.Text + "' where Id='" + id + "'");
						Codes.Add2("insert into StokeMove (Price, date, Type, StockId) values('" + ValueText.Text + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','رصيد اول المدة','" + id + "')");
					}
					else
					{
						Codes.Edit2("UPDATE    Stock SET  Name ='" + Nametect.Text + "', StockGuard ='" + GuardText.Text + "', Nots ='" + Nots.Text + "' where Id='" + id + "'");
					}
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Saved Successfully");
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح");
					}
					MethodsClass.UserMove("تعديل خزينة");
				}
				catch (Exception)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Error Happend While Saving");
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حفظ البيانات");
					}
					return;
				}
				GetData();
				ClearData();
			}
			catch
			{
			}
		}

		private void StockFrm_Load(object sender, EventArgs e)
		{
			GetData();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			StockUsersFrm stockUsersFrm = new StockUsersFrm();
			stockUsersFrm.Show();
		}
	}
}
