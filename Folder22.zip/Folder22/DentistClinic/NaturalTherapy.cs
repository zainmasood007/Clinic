using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class NaturalTherapy : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private TextBox NotestextBox;

		private Label label2;

		private Label label1;

		private TextBox NametextBox;

		private Button searchBtn;

		private Button saveBtn;

		private Button DeleteBtn;

		private Button EditBtn;

		private GroupBox groupBox2;

		private GroupBox groupBox3;

		private DataGridView dataGridView1;

		private GroupBox groupBox4;

		private Label label3;

		private ClassDataBase dc;

		private int ID;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		private GUI gui = new GUI();

		private string CategoryName = "";

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.NaturalTherapy));
			groupBox1 = new System.Windows.Forms.GroupBox();
			NametextBox = new System.Windows.Forms.TextBox();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			NotestextBox = new System.Windows.Forms.TextBox();
			searchBtn = new System.Windows.Forms.Button();
			saveBtn = new System.Windows.Forms.Button();
			DeleteBtn = new System.Windows.Forms.Button();
			EditBtn = new System.Windows.Forms.Button();
			groupBox2 = new System.Windows.Forms.GroupBox();
			groupBox3 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox4 = new System.Windows.Forms.GroupBox();
			label3 = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox4.SuspendLayout();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(NametextBox);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(NotestextBox);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			NametextBox.AccessibleDescription = null;
			NametextBox.AccessibleName = null;
			resources.ApplyResources(NametextBox, "NametextBox");
			NametextBox.BackgroundImage = null;
			NametextBox.Font = null;
			NametextBox.Name = "NametextBox";
			NametextBox.TextChanged += new System.EventHandler(NametextBox_TextChanged);
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.BackColor = System.Drawing.Color.Transparent;
			label2.Name = "label2";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.BackColor = System.Drawing.Color.Transparent;
			label1.Name = "label1";
			NotestextBox.AccessibleDescription = null;
			NotestextBox.AccessibleName = null;
			resources.ApplyResources(NotestextBox, "NotestextBox");
			NotestextBox.BackgroundImage = null;
			NotestextBox.Font = null;
			NotestextBox.Name = "NotestextBox";
			searchBtn.AccessibleDescription = null;
			searchBtn.AccessibleName = null;
			resources.ApplyResources(searchBtn, "searchBtn");
			searchBtn.BackColor = System.Drawing.Color.Gainsboro;
			searchBtn.BackgroundImage = null;
			searchBtn.Name = "searchBtn";
			searchBtn.UseVisualStyleBackColor = false;
			searchBtn.Click += new System.EventHandler(searchBtn_Click);
			saveBtn.AccessibleDescription = null;
			saveBtn.AccessibleName = null;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			saveBtn.BackgroundImage = null;
			saveBtn.Name = "saveBtn";
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			DeleteBtn.AccessibleDescription = null;
			DeleteBtn.AccessibleName = null;
			resources.ApplyResources(DeleteBtn, "DeleteBtn");
			DeleteBtn.BackColor = System.Drawing.Color.Gainsboro;
			DeleteBtn.BackgroundImage = null;
			DeleteBtn.Name = "DeleteBtn";
			DeleteBtn.UseVisualStyleBackColor = false;
			DeleteBtn.Click += new System.EventHandler(DeleteBtn_Click);
			EditBtn.AccessibleDescription = null;
			EditBtn.AccessibleName = null;
			resources.ApplyResources(EditBtn, "EditBtn");
			EditBtn.BackColor = System.Drawing.Color.Gainsboro;
			EditBtn.BackgroundImage = null;
			EditBtn.Name = "EditBtn";
			EditBtn.UseVisualStyleBackColor = false;
			EditBtn.Click += new System.EventHandler(EditBtn_Click);
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(saveBtn);
			groupBox2.Controls.Add(searchBtn);
			groupBox2.Controls.Add(EditBtn);
			groupBox2.Controls.Add(DeleteBtn);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(dataGridView1);
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseClick);
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(label3);
			groupBox4.Font = null;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(groupBox4);
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "NaturalTherapy";
			base.Load += new System.EventHandler(Company_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			ResumeLayout(false);
		}

		public NaturalTherapy()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		private void searchBtn_Click(object sender, EventArgs e)
		{
			AllData();
			Clear();
			EditBtn.Enabled = false;
			saveBtn.Enabled = true;
			DeleteBtn.Enabled = false;
		}

		public void Clear()
		{
			NametextBox.Text = "";
			NotestextBox.Text = "";
			EditBtn.Enabled = false;
			saveBtn.Enabled = true;
			DeleteBtn.Enabled = false;
		}

		public void DataGrid()
		{
			try
			{
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns[0].Visible = false;
					dataGridView1.Columns[1].HeaderText = "Device Name";
					dataGridView1.Columns[1].Width = 242;
					dataGridView1.Columns[2].Width = 300;
					dataGridView1.Columns[2].HeaderText = "Notes";
				}
				else
				{
					dataGridView1.Columns[0].Visible = false;
					dataGridView1.Columns[1].HeaderText = "اسم الجهاز";
					dataGridView1.Columns[1].Width = 242;
					dataGridView1.Columns[2].Width = 300;
					dataGridView1.Columns[2].HeaderText = "ملاحظات";
				}
			}
			catch
			{
			}
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (NametextBox.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Device Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الجهاز");
					}
					return;
				}
				DataTable tableText = dc.GetTableText("select * from NaturalTherapy where Name='" + NametextBox.Text + "'");
				if (tableText.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This Device Before");
					}
					else
					{
						MessageBox.Show("اسم الجهاز مسجل من قبل");
					}
					return;
				}
				codes.Add("insert into NaturalTherapy (Name,Notes) values ('" + NametextBox.Text + "','" + NotestextBox.Text + "')");
				MethodsClass.UserMove("أضافة جهاز علاج طبيعي");
				AllData();
				Clear();
			}
			catch
			{
			}
		}

		private void NametextBox_TextChanged(object sender, EventArgs e)
		{
			string text = NametextBox.Text;
			if (text.StartsWith(" "))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("It IS Not Allowed To Use Space In The Beginning", "Notes");
				}
				else
				{
					MessageBox.Show("لا يمكن ترك فراغ في بداية الإسم", "تنبيه");
				}
				NametextBox.Text = "";
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					if (NametextBox.Text == "")
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please enter Device Name");
						}
						else
						{
							MessageBox.Show("من فضلك ادخل اسم الجهاز");
						}
						return;
					}
					DataTable tableText = dc.GetTableText("select * from NaturalTherapy where Name='" + NametextBox.Text + "'and ID <>'" + Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString()) + "'");
					if (tableText.Rows.Count > 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Have Save This Device Before");
						}
						else
						{
							MessageBox.Show("اسم الجهاز مسجل من قبل");
						}
						AllData();
						return;
					}
					codes.Edit("update NaturalTherapy set Name='" + NametextBox.Text + "',Notes='" + NotestextBox.Text + "' where ID=" + Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString()));
					MethodsClass.UserMove("تعديل جهاز علاج طبيعي");
					Clear();
					AllData();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Select Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اختر البيانات أولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void DeleteBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					codes.Delete("delete NaturalTherapy where ID=" + Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString()));
					MethodsClass.UserMove("حذف جهاز علاج طبيعي");
					Clear();
					AllData();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Select Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اختر البيانات أولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			EditBtn.Enabled = true;
			saveBtn.Enabled = false;
			DeleteBtn.Enabled = true;
			ID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
			NametextBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
			CategoryName = NametextBox.Text;
			NotestextBox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
		}

		public void AllData()
		{
			DataTable tableText = dc.GetTableText("select * from NaturalTherapy");
			dataGridView1.DataSource = tableText;
			DataGrid();
		}

		private void Company_Load(object sender, EventArgs e)
		{
			AllData();
			Clear();
			EditBtn.Enabled = false;
			saveBtn.Enabled = true;
			DeleteBtn.Enabled = false;
		}
	}
}
