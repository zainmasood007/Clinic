using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace DentistClinic
{
	public class FrmSearchDate : Form
	{
		private DataTable dt = new DataTable();

		private GUI Gui = new GUI();

		private IContainer components = null;

		private GroupBox groupBox1;

		private Button button1;

		private DateTimePicker dateTimePicker1;

		public FrmSearchDate()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Search.text = dateTimePicker1.Value.ToString("MM/dd/yyyy");
			Close();
		}

		private void FrmSearchDate_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			groupBox1 = new System.Windows.Forms.GroupBox();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			button1 = new System.Windows.Forms.Button();
			groupBox1.SuspendLayout();
			SuspendLayout();
			groupBox1.BackColor = System.Drawing.Color.LightSteelBlue;
			groupBox1.Controls.Add(dateTimePicker1);
			groupBox1.Controls.Add(button1);
			groupBox1.Location = new System.Drawing.Point(6, 6);
			groupBox1.Name = "groupBox1";
			groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox1.Size = new System.Drawing.Size(200, 88);
			groupBox1.TabIndex = 2;
			groupBox1.TabStop = false;
			dateTimePicker1.CustomFormat = "dd/MM/yyyy";
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Location = new System.Drawing.Point(3, 16);
			dateTimePicker1.Name = "dateTimePicker1";
			dateTimePicker1.Size = new System.Drawing.Size(191, 20);
			dateTimePicker1.TabIndex = 0;
			button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button1.Location = new System.Drawing.Point(65, 45);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(75, 37);
			button1.TabIndex = 1;
			button1.Text = "Search";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			base.AcceptButton = button1;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			base.ClientSize = new System.Drawing.Size(213, 103);
			base.Controls.Add(groupBox1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "FrmSearchDate";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "FrmSearchDate";
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(FrmSearchDate_KeyDown);
			groupBox1.ResumeLayout(false);
			ResumeLayout(false);
		}
	}
}
