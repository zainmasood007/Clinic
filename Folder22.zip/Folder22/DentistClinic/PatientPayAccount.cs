using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class PatientPayAccount : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private DataGridView dataGridView1;

		private GroupBox groupBox4;

		private DateTimePicker paydateTimePicker1;

		private ComboBox PatientComboBox;

		private TextBox tottextBox;

		private GroupBox groupBox5;

		private Button saveBtn;

		private TextBox totpaytextBox;

		private GroupBox groupBox3;

		private CheckBox checkBox1;

		private RadioButton radioButton2;

		private RadioButton radioButton1;

		private TextBox textBox2;

		private ComboBox comboBox1;

		private Button button1;

		private SqlCommand sqlInsertCommand1;

		private CheckBox checkBox2;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand2;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private TextBox textBox1;

		private TextBox textBox3;

		private ComboBox comboBox2;

		private TextBox EsalNoTxt;

		private Label label45;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlCommand1;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlSelectCommand2;

		private RadioButton PayNaqdy;

		private RadioButton PayBefore;

		private TextBox Rased;

		private Label label5;

		private DataGridViewTextBoxColumn ID;

		private DataGridViewTextBoxColumn Service;

		private DataGridViewTextBoxColumn ServicePrice;

		private DataGridViewTextBoxColumn Count;

		private DataGridViewTextBoxColumn Price;

		private DataGridViewTextBoxColumn OldPaid;

		private DataGridViewTextBoxColumn Paid;

		private DataGridViewTextBoxColumn DoctorId;

		private DataGridViewTextBoxColumn Date;

		private DataGridViewTextBoxColumn TotalPaid;

		private DataGridViewTextBoxColumn Dariba;

		private DataGridViewTextBoxColumn BeforeDariba;

		private ClassDataBase dc;

		private decimal oldPay = 0m;

		private double total;

		private double totpay;

		private bool b;

		private GUI gui = new GUI();

		private int PatientId;

		private string Teeth;

		private DataSet1 ds = new DataSet1();

		private dataClass codes;

		private GeneralMethods MethodsClass = new GeneralMethods();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.PatientPayAccount));
			groupBox1 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox4 = new System.Windows.Forms.GroupBox();
			this.label5 = new System.Windows.Forms.Label();
			Rased = new System.Windows.Forms.TextBox();
			PayNaqdy = new System.Windows.Forms.RadioButton();
			PayBefore = new System.Windows.Forms.RadioButton();
			EsalNoTxt = new System.Windows.Forms.TextBox();
			label45 = new System.Windows.Forms.Label();
			paydateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			comboBox2 = new System.Windows.Forms.ComboBox();
			PatientComboBox = new System.Windows.Forms.ComboBox();
			tottextBox = new System.Windows.Forms.TextBox();
			groupBox5 = new System.Windows.Forms.GroupBox();
			checkBox2 = new System.Windows.Forms.CheckBox();
			button1 = new System.Windows.Forms.Button();
			saveBtn = new System.Windows.Forms.Button();
			totpaytextBox = new System.Windows.Forms.TextBox();
			groupBox3 = new System.Windows.Forms.GroupBox();
			checkBox1 = new System.Windows.Forms.CheckBox();
			radioButton2 = new System.Windows.Forms.RadioButton();
			radioButton1 = new System.Windows.Forms.RadioButton();
			textBox2 = new System.Windows.Forms.TextBox();
			comboBox1 = new System.Windows.Forms.ComboBox();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			textBox1 = new System.Windows.Forms.TextBox();
			textBox3 = new System.Windows.Forms.TextBox();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Service = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ServicePrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Count = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
			OldPaid = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Paid = new System.Windows.Forms.DataGridViewTextBoxColumn();
			DoctorId = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
			TotalPaid = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Dariba = new System.Windows.Forms.DataGridViewTextBoxColumn();
			BeforeDariba = new System.Windows.Forms.DataGridViewTextBoxColumn();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label7 = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox4.SuspendLayout();
			groupBox5.SuspendLayout();
			groupBox3.SuspendLayout();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "addressLabel");
			label.Name = "addressLabel";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "titelLabel");
			label2.Name = "titelLabel";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.ForeColor = System.Drawing.Color.Firebrick;
			label3.Name = "label3";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label1");
			label4.ForeColor = System.Drawing.Color.Firebrick;
			label4.Name = "label1";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label2");
			label5.ForeColor = System.Drawing.Color.Firebrick;
			label5.Name = "label2";
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "label4");
			label6.ForeColor = System.Drawing.Color.Firebrick;
			label6.Name = "label4";
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "label110");
			label7.Name = "label110";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(dataGridView1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(ID, Service, ServicePrice, Count, Price, OldPaid, Paid, DoctorId, Date, TotalPaid, Dariba, BeforeDariba);
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(dataGridView1_CellValueChanged);
			dataGridView1.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(dataGridView1_CellEndEdit);
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			dataGridView1.CurrentCellDirtyStateChanged += new System.EventHandler(dataGridView1_CurrentCellDirtyStateChanged);
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(this.label5);
			groupBox4.Controls.Add(label7);
			groupBox4.Controls.Add(Rased);
			groupBox4.Controls.Add(PayBefore);
			groupBox4.Controls.Add(EsalNoTxt);
			groupBox4.Controls.Add(PayNaqdy);
			groupBox4.Controls.Add(label45);
			groupBox4.Controls.Add(paydateTimePicker1);
			groupBox4.Controls.Add(label);
			groupBox4.Controls.Add(comboBox2);
			groupBox4.Controls.Add(label2);
			groupBox4.Controls.Add(PatientComboBox);
			groupBox4.ForeColor = System.Drawing.Color.Black;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			this.label5.AccessibleDescription = null;
			this.label5.AccessibleName = null;
			resources.ApplyResources(this.label5, "label5");
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Name = "label5";
			Rased.AccessibleDescription = null;
			Rased.AccessibleName = null;
			resources.ApplyResources(Rased, "Rased");
			Rased.BackColor = System.Drawing.Color.White;
			Rased.BackgroundImage = null;
			Rased.Font = null;
			Rased.ForeColor = System.Drawing.Color.Black;
			Rased.Name = "Rased";
			Rased.ReadOnly = true;
			PayNaqdy.AccessibleDescription = null;
			PayNaqdy.AccessibleName = null;
			resources.ApplyResources(PayNaqdy, "PayNaqdy");
			PayNaqdy.BackColor = System.Drawing.Color.Transparent;
			PayNaqdy.BackgroundImage = null;
			PayNaqdy.Checked = true;
			PayNaqdy.Name = "PayNaqdy";
			PayNaqdy.TabStop = true;
			PayNaqdy.UseVisualStyleBackColor = false;
			PayNaqdy.CheckedChanged += new System.EventHandler(PayNaqdy_CheckedChanged);
			PayBefore.AccessibleDescription = null;
			PayBefore.AccessibleName = null;
			resources.ApplyResources(PayBefore, "PayBefore");
			PayBefore.BackColor = System.Drawing.Color.Transparent;
			PayBefore.BackgroundImage = null;
			PayBefore.Name = "PayBefore";
			PayBefore.UseVisualStyleBackColor = false;
			EsalNoTxt.AccessibleDescription = null;
			EsalNoTxt.AccessibleName = null;
			resources.ApplyResources(EsalNoTxt, "EsalNoTxt");
			EsalNoTxt.BackgroundImage = null;
			EsalNoTxt.Font = null;
			EsalNoTxt.Name = "EsalNoTxt";
			EsalNoTxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(EsalNoTxt_KeyPress);
			label45.AccessibleDescription = null;
			label45.AccessibleName = null;
			resources.ApplyResources(label45, "label45");
			label45.BackColor = System.Drawing.Color.Transparent;
			label45.Name = "label45";
			paydateTimePicker1.AccessibleDescription = null;
			paydateTimePicker1.AccessibleName = null;
			resources.ApplyResources(paydateTimePicker1, "paydateTimePicker1");
			paydateTimePicker1.BackgroundImage = null;
			paydateTimePicker1.CalendarFont = null;
			paydateTimePicker1.Font = null;
			paydateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			paydateTimePicker1.Name = "paydateTimePicker1";
			comboBox2.AccessibleDescription = null;
			comboBox2.AccessibleName = null;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.BackgroundImage = null;
			comboBox2.FormattingEnabled = true;
			comboBox2.Name = "comboBox2";
			PatientComboBox.AccessibleDescription = null;
			PatientComboBox.AccessibleName = null;
			resources.ApplyResources(PatientComboBox, "PatientComboBox");
			PatientComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			PatientComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientComboBox.BackgroundImage = null;
			PatientComboBox.FormattingEnabled = true;
			PatientComboBox.Name = "PatientComboBox";
			PatientComboBox.SelectionChangeCommitted += new System.EventHandler(PatientComboBox_SelectedIndexChanged);
			PatientComboBox.SelectedIndexChanged += new System.EventHandler(PatientComboBox_SelectedIndexChanged);
			tottextBox.AccessibleDescription = null;
			tottextBox.AccessibleName = null;
			resources.ApplyResources(tottextBox, "tottextBox");
			tottextBox.BackgroundImage = null;
			tottextBox.Font = null;
			tottextBox.ForeColor = System.Drawing.Color.Maroon;
			tottextBox.Name = "tottextBox";
			tottextBox.ReadOnly = true;
			groupBox5.AccessibleDescription = null;
			groupBox5.AccessibleName = null;
			resources.ApplyResources(groupBox5, "groupBox5");
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.BackgroundImage = null;
			groupBox5.Controls.Add(checkBox2);
			groupBox5.Controls.Add(button1);
			groupBox5.Controls.Add(saveBtn);
			groupBox5.Font = null;
			groupBox5.Name = "groupBox5";
			groupBox5.TabStop = false;
			checkBox2.AccessibleDescription = null;
			checkBox2.AccessibleName = null;
			resources.ApplyResources(checkBox2, "checkBox2");
			checkBox2.BackgroundImage = null;
			checkBox2.Name = "checkBox2";
			checkBox2.UseVisualStyleBackColor = true;
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.BackgroundImage = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			saveBtn.AccessibleDescription = null;
			saveBtn.AccessibleName = null;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			saveBtn.BackgroundImage = null;
			saveBtn.Name = "saveBtn";
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			totpaytextBox.AccessibleDescription = null;
			totpaytextBox.AccessibleName = null;
			resources.ApplyResources(totpaytextBox, "totpaytextBox");
			totpaytextBox.BackgroundImage = null;
			totpaytextBox.Font = null;
			totpaytextBox.ForeColor = System.Drawing.Color.Maroon;
			totpaytextBox.Name = "totpaytextBox";
			totpaytextBox.ReadOnly = true;
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(checkBox1);
			groupBox3.Controls.Add(radioButton2);
			groupBox3.Controls.Add(radioButton1);
			groupBox3.Controls.Add(textBox2);
			groupBox3.Controls.Add(comboBox1);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			checkBox1.AccessibleDescription = null;
			checkBox1.AccessibleName = null;
			resources.ApplyResources(checkBox1, "checkBox1");
			checkBox1.BackgroundImage = null;
			checkBox1.Font = null;
			checkBox1.Name = "checkBox1";
			checkBox1.UseVisualStyleBackColor = true;
			checkBox1.CheckedChanged += new System.EventHandler(checkBox1_CheckedChanged);
			radioButton2.AccessibleDescription = null;
			radioButton2.AccessibleName = null;
			resources.ApplyResources(radioButton2, "radioButton2");
			radioButton2.BackgroundImage = null;
			radioButton2.Checked = true;
			radioButton2.Font = null;
			radioButton2.Name = "radioButton2";
			radioButton2.TabStop = true;
			radioButton2.UseVisualStyleBackColor = true;
			radioButton1.AccessibleDescription = null;
			radioButton1.AccessibleName = null;
			resources.ApplyResources(radioButton1, "radioButton1");
			radioButton1.BackgroundImage = null;
			radioButton1.Font = null;
			radioButton1.Name = "radioButton1";
			radioButton1.TabStop = true;
			radioButton1.UseVisualStyleBackColor = true;
			textBox2.AccessibleDescription = null;
			textBox2.AccessibleName = null;
			resources.ApplyResources(textBox2, "textBox2");
			textBox2.BackgroundImage = null;
			textBox2.Font = null;
			textBox2.Name = "textBox2";
			textBox2.TextChanged += new System.EventHandler(textBox2_TextChanged);
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Name = "comboBox1";
			comboBox1.SelectedIndexChanged += new System.EventHandler(comboBox1_SelectedIndexChanged);
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo")
			});
			sqlSelectCommand1.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.CommandText = resources.GetString("sqlInsertCommand2.CommandText");
			sqlInsertCommand2.Connection = sqlConnection1;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[8]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[22]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[9]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Font = null;
			textBox1.ForeColor = System.Drawing.Color.Maroon;
			textBox1.Name = "textBox1";
			textBox1.ReadOnly = true;
			textBox3.AccessibleDescription = null;
			textBox3.AccessibleName = null;
			resources.ApplyResources(textBox3, "textBox3");
			textBox3.BackgroundImage = null;
			textBox3.Font = null;
			textBox3.ForeColor = System.Drawing.Color.Maroon;
			textBox3.Name = "textBox3";
			textBox3.ReadOnly = true;
			sqlDataAdapter2.InsertCommand = sqlCommand1;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[51]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
					new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
					new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
					new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
					new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
					new System.Data.Common.DataColumnMapping("Implant", "Implant"),
					new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
					new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers"),
					new System.Data.Common.DataColumnMapping("DoctoreName", "DoctoreName"),
					new System.Data.Common.DataColumnMapping("NextVisit", "NextVisit"),
					new System.Data.Common.DataColumnMapping("Accept", "Accept"),
					new System.Data.Common.DataColumnMapping("Taqweem", "Taqweem"),
					new System.Data.Common.DataColumnMapping("Photo", "Photo"),
					new System.Data.Common.DataColumnMapping("BloodType", "BloodType"),
					new System.Data.Common.DataColumnMapping("Active", "Active"),
					new System.Data.Common.DataColumnMapping("FileNo", "FileNo"),
					new System.Data.Common.DataColumnMapping("Patient", "Patient"),
					new System.Data.Common.DataColumnMapping("Facebook", "Facebook"),
					new System.Data.Common.DataColumnMapping("Adv", "Adv"),
					new System.Data.Common.DataColumnMapping("FormerPatient", "FormerPatient"),
					new System.Data.Common.DataColumnMapping("Discount", "Discount"),
					new System.Data.Common.DataColumnMapping("Without", "Without"),
					new System.Data.Common.DataColumnMapping("Doctor", "Doctor"),
					new System.Data.Common.DataColumnMapping("DoctorId", "DoctorId")
				})
			});
			sqlCommand1.CommandText = resources.GetString("sqlCommand1.CommandText");
			sqlCommand1.Connection = sqlConnection2;
			sqlCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[50]
			{
				new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
				new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
				new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
				new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
				new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
				new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
				new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
				new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
				new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
				new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
				new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
				new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
				new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
				new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
				new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
				new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
				new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
				new System.Data.SqlClient.SqlParameter("@Lactating", System.Data.SqlDbType.Bit, 0, "Lactating"),
				new System.Data.SqlClient.SqlParameter("@Pregnant", System.Data.SqlDbType.Bit, 0, "Pregnant"),
				new System.Data.SqlClient.SqlParameter("@HepatitisB", System.Data.SqlDbType.Bit, 0, "HepatitisB"),
				new System.Data.SqlClient.SqlParameter("@Hepatitisc", System.Data.SqlDbType.Bit, 0, "Hepatitisc"),
				new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
				new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
				new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
				new System.Data.SqlClient.SqlParameter("@Endodontics", System.Data.SqlDbType.Bit, 0, "Endodontics"),
				new System.Data.SqlClient.SqlParameter("@Fixed", System.Data.SqlDbType.Bit, 0, "Fixed"),
				new System.Data.SqlClient.SqlParameter("@Implant", System.Data.SqlDbType.Bit, 0, "Implant"),
				new System.Data.SqlClient.SqlParameter("@Opretive", System.Data.SqlDbType.Bit, 0, "Opretive"),
				new System.Data.SqlClient.SqlParameter("@Bleaching", System.Data.SqlDbType.Bit, 0, "Bleaching"),
				new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers"),
				new System.Data.SqlClient.SqlParameter("@DoctoreName", System.Data.SqlDbType.NVarChar, 0, "DoctoreName"),
				new System.Data.SqlClient.SqlParameter("@NextVisit", System.Data.SqlDbType.NVarChar, 0, "NextVisit"),
				new System.Data.SqlClient.SqlParameter("@Accept", System.Data.SqlDbType.Bit, 0, "Accept"),
				new System.Data.SqlClient.SqlParameter("@Taqweem", System.Data.SqlDbType.Bit, 0, "Taqweem"),
				new System.Data.SqlClient.SqlParameter("@Photo", System.Data.SqlDbType.Image, 0, "Photo"),
				new System.Data.SqlClient.SqlParameter("@BloodType", System.Data.SqlDbType.NVarChar, 0, "BloodType"),
				new System.Data.SqlClient.SqlParameter("@Active", System.Data.SqlDbType.Bit, 0, "Active"),
				new System.Data.SqlClient.SqlParameter("@FileNo", System.Data.SqlDbType.Int, 0, "FileNo"),
				new System.Data.SqlClient.SqlParameter("@Patient", System.Data.SqlDbType.Bit, 0, "Patient"),
				new System.Data.SqlClient.SqlParameter("@Facebook", System.Data.SqlDbType.Bit, 0, "Facebook"),
				new System.Data.SqlClient.SqlParameter("@Adv", System.Data.SqlDbType.Bit, 0, "Adv"),
				new System.Data.SqlClient.SqlParameter("@FormerPatient", System.Data.SqlDbType.NVarChar, 0, "FormerPatient"),
				new System.Data.SqlClient.SqlParameter("@Discount", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Discount", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Without", System.Data.SqlDbType.Bit, 0, "Without"),
				new System.Data.SqlClient.SqlParameter("@Doctor", System.Data.SqlDbType.Bit, 0, "Doctor"),
				new System.Data.SqlClient.SqlParameter("@DoctorId", System.Data.SqlDbType.NVarChar, 0, "DoctorId")
			});
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlSelectCommand2.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlSelectCommand2.Connection = sqlConnection2;
			resources.ApplyResources(ID, "ID");
			ID.Name = "ID";
			resources.ApplyResources(Service, "Service");
			Service.Name = "Service";
			resources.ApplyResources(ServicePrice, "ServicePrice");
			ServicePrice.Name = "ServicePrice";
			resources.ApplyResources(Count, "Count");
			Count.Name = "Count";
			resources.ApplyResources(Price, "Price");
			Price.Name = "Price";
			resources.ApplyResources(OldPaid, "OldPaid");
			OldPaid.Name = "OldPaid";
			resources.ApplyResources(Paid, "Paid");
			Paid.Name = "Paid";
			resources.ApplyResources(DoctorId, "DoctorId");
			DoctorId.Name = "DoctorId";
			resources.ApplyResources(Date, "Date");
			Date.Name = "Date";
			resources.ApplyResources(TotalPaid, "TotalPaid");
			TotalPaid.Name = "TotalPaid";
			resources.ApplyResources(Dariba, "Dariba");
			Dariba.Name = "Dariba";
			resources.ApplyResources(BeforeDariba, "BeforeDariba");
			BeforeDariba.Name = "BeforeDariba";
			base.AcceptButton = saveBtn;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(textBox1);
			base.Controls.Add(label5);
			base.Controls.Add(textBox3);
			base.Controls.Add(label6);
			base.Controls.Add(groupBox3);
			base.Controls.Add(totpaytextBox);
			base.Controls.Add(label4);
			base.Controls.Add(tottextBox);
			base.Controls.Add(label3);
			base.Controls.Add(groupBox5);
			base.Controls.Add(groupBox4);
			base.Controls.Add(groupBox1);
			Font = null;
			base.KeyPreview = true;
			base.Name = "PatientPayAccount";
			base.Load += new System.EventHandler(PatientPayAccount_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(PatientPayAccount_KeyDown);
			groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			groupBox5.ResumeLayout(false);
			groupBox5.PerformLayout();
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		public PatientPayAccount(int Patient)
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
			PatientId = Patient;
		}

		private void PatientPayAccount_Load(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2("select DeletePatientPay from users where userId=" + Main.userId);
			if (Convert.ToBoolean(dataTable.Rows[0]["DeletePatientPay"].ToString()))
			{
				button1.Visible = true;
			}
			else
			{
				button1.Visible = false;
			}
			try
			{
				if (UsersClass.AutoEsal)
				{
					EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
					EsalNoTxt.Enabled = false;
				}
				else
				{
					EsalNoTxt.Text = "";
					EsalNoTxt.Enabled = true;
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = codes.Search2("select * from Company");
				comboBox1.DataSource = dataTable2;
				comboBox1.ValueMember = dataTable2.Columns[0].ToString();
				comboBox1.DisplayMember = dataTable2.Columns[1].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				comboBox2.DataSource = null;
				comboBox2.DataSource = dataTable2;
				comboBox2.DisplayMember = dataTable2.Columns[1].ToString();
				comboBox2.ValueMember = dataTable2.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				if (PatientId == 0)
				{
					PatientComboBox.Enabled = true;
					DataTable dataTable2 = new DataTable();
					try
					{
						DataTable dataTable3 = new DataTable();
						if (Convert.ToBoolean(codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString()))
						{
							dataTable3 = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True' order by PName");
							PatientComboBox.DataSource = dataTable3;
							PatientComboBox.DisplayMember = dataTable3.Columns[1].ToString();
							PatientComboBox.ValueMember = dataTable3.Columns[0].ToString();
						}
						else
						{
							dataTable3 = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True'");
							PatientComboBox.DataSource = dataTable3;
							PatientComboBox.DisplayMember = dataTable3.Columns[1].ToString();
							PatientComboBox.ValueMember = dataTable3.Columns[0].ToString();
						}
					}
					catch
					{
					}
					try
					{
						PatientComboBox.SelectedValue = PatientComboBox.Items[0];
					}
					catch
					{
					}
					dataGridView1.Columns[1].ReadOnly = true;
					dataGridView1.Columns[2].ReadOnly = true;
					dataGridView1.Columns[3].ReadOnly = true;
					dataGridView1.Columns[4].ReadOnly = true;
					dataGridView1.Columns[5].ReadOnly = true;
				}
				else
				{
					PatientComboBox.Enabled = false;
					DataTable dataTable2 = new DataTable();
					dataTable2 = dc.Select("SelectAllPatient");
					gui.loadComboBox(PatientComboBox, dataTable2);
					dataGridView1.Columns[1].ReadOnly = true;
					dataGridView1.Columns[2].ReadOnly = true;
					dataGridView1.Columns[3].ReadOnly = true;
					dataGridView1.Columns[4].ReadOnly = true;
					dataGridView1.Columns[5].ReadOnly = true;
					PatientComboBox.SelectedValue = PatientId;
					PatientComboBox_SelectedIndexChanged(sender, e);
				}
				checkBox2.Checked = Settings.Default.LivePrint;
			}
			catch
			{
			}
			try
			{
				decimal num = 0m;
				decimal num2 = 0m;
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					num += Convert.ToDecimal(dataGridView1.Rows[i].Cells["Price"].Value);
					num2 += Convert.ToDecimal(dataGridView1.Rows[i].Cells["OldPaid"].Value);
				}
				textBox3.Text = num.ToString();
				textBox1.Text = num2.ToString();
			}
			catch
			{
			}
		}

		private void PatientComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				try
				{
					DataTable dataTable = codes.Search2("select isnull(sum(Daen),0) from PatientBeforePay where PatientID=" + PatientComboBox.SelectedValue);
					Rased.Text = Math.Round(Convert.ToDecimal(dataTable.Rows[0][0]), 2).ToString();
				}
				catch
				{
				}
				dataGridView1.Rows.Clear();
				totpaytextBox.Text = "0";
				tottextBox.Text = "0";
				totpay = 0.0;
				total = 0.0;
				oldPay = 0m;
				DataTable dataTable2 = new DataTable();
				dataTable2 = dc.GetTableText(string.Concat("select * from PatientAccount where PatientId = '", PatientComboBox.SelectedValue, "' and Pay = 'False' and Bean<>'خدمة ثابتة'"));
				for (int i = 0; i < dataTable2.Rows.Count; i++)
				{
					dataGridView1.Rows.Add(dataTable2.Rows[i]["ID"].ToString(), dataTable2.Rows[i]["Bean"].ToString(), Convert.ToDouble(dataTable2.Rows[i]["Price"].ToString()) / Convert.ToDouble(dataTable2.Rows[i]["ServiceCount"].ToString()), Convert.ToDouble(dataTable2.Rows[i]["ServiceCount"].ToString()), Convert.ToDouble(dataTable2.Rows[i]["Price"].ToString()), Convert.ToDouble(dataTable2.Rows[i]["PricePay"].ToString()), 0, dataTable2.Rows[i]["DoctorID"].ToString(), dataTable2.Rows[i]["Date"].ToString(), 0, dataTable2.Rows[i]["Dariba"].ToString(), dataTable2.Rows[i]["PriceBeforeDariba"].ToString());
					total += Convert.ToDouble(dataTable2.Rows[i]["Price"].ToString());
					oldPay += Convert.ToDecimal(dataTable2.Rows[i]["PricePay"].ToString());
				}
				tottextBox.Text = (Convert.ToDecimal(total) - oldPay).ToString();
			}
			catch
			{
			}
			try
			{
				decimal num = 0m;
				decimal num2 = 0m;
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					num += Convert.ToDecimal(dataGridView1.Rows[i].Cells["Price"].Value);
					num2 += Convert.ToDecimal(dataGridView1.Rows[i].Cells["OldPaid"].Value);
				}
				textBox3.Text = num.ToString();
				textBox1.Text = num2.ToString();
			}
			catch
			{
			}
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				ds.Clear();
				if (PatientComboBox.SelectedItem != null)
				{
					if (EsalNoTxt.Text == "")
					{
						MessageBox.Show("من فضلك ادخل رقم الايصال");
						return;
					}
					DataTable dataTable = codes.Search2("select EsalNo from Esal where EsalNo ='" + EsalNoTxt.Text + "'");
					if (dataTable.Rows.Count > 0)
					{
						MessageBox.Show("رقم الايصال مسجل من قبل");
						EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
					}
					string text = EsalNoTxt.Text;
					double num = 0.0;
					string text2 = "";
					double num2 = 0.0;
					double num3 = 0.0;
					double num4 = 0.0;
					double num5 = 0.0;
					for (int i = 0; i < dataGridView1.Rows.Count; i++)
					{
						num5 = Convert.ToDouble(dataGridView1.Rows[i].Cells["Paid"].Value.ToString());
						if (dataGridView1.Rows[i].Cells["Paid"].Value == dataGridView1.Rows[i].Cells["TotalPaid"].Value && (Convert.ToDouble(dataGridView1.Rows[i].Cells["TotalPaid"].Value) != Convert.ToDouble(dataGridView1.Rows[i].Cells["OldPaid"].Value) || Convert.ToDouble(dataGridView1.Rows[i].Cells["OldPaid"].Value) != Convert.ToDouble(dataGridView1.Rows[i].Cells["Price"].Value)) && num5 != 0.0)
						{
							num2 += Convert.ToDouble(dataGridView1.Rows[i].Cells["Price"].Value.ToString());
							num3 += Convert.ToDouble(dataGridView1.Rows[i].Cells["OldPaid"].Value.ToString());
							num4 += Convert.ToDouble(dataGridView1.Rows[i].Cells["Paid"].Value.ToString());
						}
					}
					int num6 = 0;
					DataTable dataTable2 = new DataTable();
					dataTable2.Columns.Add("ID");
					string text3 = "";
					bool flag = false;
					try
					{
						for (num6 = 0; num6 < dataGridView1.Rows.Count; num6++)
						{
							if (Convert.ToDouble(dataGridView1.Rows[num6].Cells["Paid"].Value.ToString()) > 0.0)
							{
								if (dataTable2.Rows.Count == 0)
								{
									DataRow dataRow = dataTable2.NewRow();
									dataRow["ID"] = dataGridView1.Rows[num6].Cells[7].Value.ToString();
									dataTable2.Rows.InsertAt(dataRow, 0);
									text3 = codes.Search2("select Name from Empdata where ID='" + dataGridView1.Rows[num6].Cells[7].Value.ToString() + "'").Rows[0][0].ToString();
								}
								else
								{
									for (int j = 0; j < dataTable2.Rows.Count; j++)
									{
										if (!(dataGridView1.Rows[num6].Cells[7].Value.ToString() != dataTable2.Rows[j][0].ToString()))
										{
											text3 = codes.Search2("select Name from Empdata where ID='" + dataGridView1.Rows[num6].Cells[7].Value.ToString() + "'").Rows[0][0].ToString();
											continue;
										}
										text3 = "";
										flag = true;
										break;
									}
								}
							}
							if (flag)
							{
								break;
							}
						}
					}
					catch
					{
					}
					for (int i = 0; i < dataGridView1.Rows.Count; i++)
					{
						DataTable dataTable3 = new DataTable();
						dataTable3 = dc.GetTableText("select Price,PricePay,TeathId,Assistant from PatientAccount where ID = " + Convert.ToInt32(dataGridView1.Rows[i].Cells["ID"].Value.ToString()));
						double num7 = Convert.ToDouble(dataTable3.Rows[0][0].ToString());
						double num8 = Convert.ToDouble(dataTable3.Rows[0][1].ToString());
						text2 = dataTable3.Rows[0][3].ToString();
						double num9 = Convert.ToDouble(dataGridView1.Rows[i].Cells["Paid"].Value.ToString());
						DataTable tableText = dc.GetTableText("select ClinicType from DentalData ");
						bool flag2 = Convert.ToBoolean(tableText.Rows[0][0]);
						num += Convert.ToDouble(dataGridView1.Rows[i].Cells["Paid"].Value.ToString()) + Convert.ToDouble(dataGridView1.Rows[i].Cells["OldPaid"].Value.ToString());
						if (dataTable3.Rows[0]["TeathId"].ToString() == "" || dataTable3.Rows[0]["TeathId"].ToString() == "0" || !flag2)
						{
							Teeth = "NULL";
						}
						else
						{
							try
							{
								Teeth = codes.Search2("select Name from Teath where ID=" + dataTable3.Rows[0]["TeathId"].ToString()).Rows[0][0].ToString();
							}
							catch
							{
								Teeth = "General";
							}
						}
						if (dataGridView1.Rows[i].Cells["Paid"].Value != dataGridView1.Rows[i].Cells["TotalPaid"].Value || (Convert.ToDouble(dataGridView1.Rows[i].Cells["TotalPaid"].Value) == Convert.ToDouble(dataGridView1.Rows[i].Cells["OldPaid"].Value) && Convert.ToDouble(dataGridView1.Rows[i].Cells["OldPaid"].Value) == Convert.ToDouble(dataGridView1.Rows[i].Cells["Price"].Value)))
						{
							continue;
						}
						if (num9 > 0.0)
						{
							string text4 = "";
							DataTable dataTable4 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
							try
							{
								text4 = dataTable4.Rows[0][0].ToString();
							}
							catch
							{
							}
							((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, paydateTimePicker1.Value, dataGridView1.Rows[i].Cells["Service"].Value.ToString(), num2.ToString(), dataGridView1.Rows[i].Cells["Price"].Value.ToString(), totpaytextBox.Text, Teeth, text4, Main.usernames, text, dataGridView1.Rows[i].Cells["Count"].Value.ToString(), dataGridView1.Rows[i].Cells["ServicePrice"].Value.ToString(), dataGridView1.Rows[i].Cells[10].Value.ToString(), text3);
							codes.Add2("insert into Esal (EsalNo, PatientAcountId, Date,Pay, Patient, Bean, Price, Teeth, Company, Username,Assistant) values('" + text + "','" + Convert.ToInt32(dataGridView1.Rows[i].Cells["ID"].Value.ToString()) + "','" + paydateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToDecimal(dataGridView1.Rows[i].Cells["Paid"].Value.ToString()) + "','" + PatientComboBox.Text + "', '" + dataGridView1.Rows[i].Cells["Service"].Value.ToString() + "','" + dataGridView1.Rows[i].Cells["Price"].Value.ToString() + "','" + Teeth + "','" + text4 + "','" + Main.usernames + "','" + text2 + "')");
						}
						double num10 = num8 + num9;
						if (num10 == num7)
						{
							string[] fields = new string[1] { "ID" };
							dc.Update("updatepatientAccountPay", fields, Convert.ToInt32(dataGridView1.Rows[i].Cells["ID"].Value.ToString()));
						}
						string[] fields2 = new string[2] { "ID", "PricePay" };
						b = dc.Update("updatepatientAccountPricepay", fields2, Convert.ToInt32(dataGridView1.Rows[i].Cells["ID"].Value.ToString()), num10.ToString());
						codes.Edit2("update PatientAccount set StockId = '" + Convert.ToInt32(comboBox2.SelectedValue.ToString()) + "' where ID = '" + Convert.ToInt32(dataGridView1.Rows[i].Cells["ID"].Value.ToString()) + "'");
						codes.Add2(string.Concat("insert into AccountDetails (PatientId, DoctorId, Date, Bean, Price, PricePay,PatientAcountId,StockId) values('", PatientComboBox.SelectedValue, "','", dataGridView1.Rows[i].Cells["DoctorId"].Value.ToString(), "','", paydateTimePicker1.Value.ToString("MM/dd/yyyy"), "','", dataGridView1.Rows[i].Cells["Service"].Value.ToString(), "','", dataGridView1.Rows[i].Cells["Price"].Value.ToString(), "','", dataGridView1.Rows[i].Cells["Paid"].Value.ToString(), "','", dataGridView1.Rows[i].Cells["ID"].Value.ToString(), "','", Convert.ToInt32(comboBox2.SelectedValue.ToString()), "')"));
						if (dataGridView1.Rows[i].Cells["Service"].Value.ToString() == "سحب كميات اصناف")
						{
							DataTable dataTable5 = codes.Search2("SELECT     dbo.Items.Name, dbo.Sahb_details.Qty, dbo.Sahb_details.Price\r\nFROM         dbo.Sahb INNER JOIN\r\n                      dbo.Sahb_details ON dbo.Sahb.ID = dbo.Sahb_details.SahbId INNER JOIN\r\n                      dbo.Items ON dbo.Sahb_details.ItemId = dbo.Items.Id where dbo.Sahb.PatientAccountId = '" + Convert.ToInt32(dataGridView1.Rows[i].Cells["ID"].Value.ToString()) + "'");
							for (int k = 0; k < dataTable5.Rows.Count; k++)
							{
								decimal num11 = Convert.ToDecimal(dataTable5.Rows[k][1].ToString()) * Convert.ToDecimal(dataTable5.Rows[k][2].ToString());
								((DataTable)(object)ds.SahbItemEsal).Rows.Add(dataTable5.Rows[k][0].ToString(), dataTable5.Rows[k][1].ToString(), dataTable5.Rows[k][2].ToString(), num11);
							}
						}
					}
					if (!b)
					{
						return;
					}
					if (PayNaqdy.Checked)
					{
						string[] fields3 = new string[3] { "PatientID", "Pay", "Date" };
						b = dc.Insert("AddPatientPay", fields3, Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), totpaytextBox.Text, paydateTimePicker1.Value.ToString("MM/dd/yyyy"));
					}
					if (b)
					{
						if (PayNaqdy.Checked)
						{
							double num7 = Convert.ToDouble(totpaytextBox.Text);
							codes.Edit2("update Stock Set Value = Value + '" + num7.ToString() + "' where ID = '" + Convert.ToInt32(comboBox2.SelectedValue.ToString()) + "'");
							codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('مدفوعات مريض' ," + Convert.ToDecimal(totpaytextBox.Text) + ",'" + PatientComboBox.Text + " إيصال رقم: " + EsalNoTxt.Text + "','" + paydateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox2.SelectedValue.ToString()) + "')");
						}
						else if (PayBefore.Checked)
						{
							decimal num12 = Convert.ToDecimal(Rased.Text) - Convert.ToDecimal(totpaytextBox.Text);
							DataTable dataTable6 = codes.Search2("select max(ID) from Esal");
							codes.Search2(string.Concat("insert into PatientBeforePay (PatientID,Daen,Madeen,Raseed,Bayan,[Date],EsalNum,StockID,Type) values (", PatientComboBox.SelectedValue, ",", Convert.ToDecimal(totpaytextBox.Text) * -1m, ",0,", num12, ",'مدفوع من رصيد سابق','", paydateTimePicker1.Value.ToString("MM/dd/yyyy"), "','", dataTable6.Rows[0][0].ToString(), "','0','true')"));
						}
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove("أضافة مدفوع لمريض");
						try
						{
							if (UsersClass.AutoEsal)
							{
								EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
								EsalNoTxt.Enabled = false;
							}
							else
							{
								EsalNoTxt.Text = "";
								EsalNoTxt.Enabled = true;
							}
						}
						catch
						{
						}
						DataTable dataTable7 = codes.Search2("select chTxtUnderPres,TxtUnderPres from Properties");
						string text5 = "";
						text5 = ((!Convert.ToBoolean(dataTable7.Rows[0]["chTxtUnderPres"].ToString())) ? "" : dataTable7.Rows[0]["TxtUnderPres"].ToString());
						DataTable dataTable8 = codes.Search2("select EsalPrinter from Properties");
						string text6 = dataTable8.Rows[0][0].ToString();
						sqlConnection1.ConnectionString = codes.ConnectionStr;
						sqlDataAdapter1.Fill(ds);
						sqlConnection2.ConnectionString = codes.ConnectionStr;
						sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
						sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
						sqlDataAdapter2.Fill(ds);
						if (Teeth == "NULL")
						{
							switch (text6)
							{
							case "A5":
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptA5.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text5;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = num3.ToString();
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = (num2 - num3 - num4).ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								if (checkBox2.Checked)
								{
									reportDocument.PrintToPrinter(1, collated: true, 1, 1);
									break;
								}
								StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
								statmentRptFrm.ShowDialog();
								break;
							}
							case "Reset":
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1Reset.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text5;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = num3.ToString();
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = (num2 - num3 - num4).ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								if (checkBox2.Checked)
								{
									reportDocument.PrintToPrinter(1, collated: true, 1, 1);
									break;
								}
								StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
								statmentRptFrm.ShowDialog();
								break;
							}
							case "1/2 A4":
							{
								((DataTable)(object)ds.Statment).Rows.Clear();
								double num13 = 0.0;
								int num14 = 0;
								DataTable dataTable9 = new DataTable();
								dataTable9.Columns.Add("ID");
								string text7 = "";
								bool flag3 = false;
								try
								{
									for (num14 = 0; num14 < dataGridView1.Rows.Count; num14++)
									{
										if (Convert.ToDouble(dataGridView1.Rows[num14].Cells["Paid"].Value.ToString()) > 0.0)
										{
											if (dataTable9.Rows.Count == 0)
											{
												DataRow dataRow = dataTable2.NewRow();
												dataRow["ID"] = dataGridView1.Rows[num14].Cells[7].Value.ToString();
												dataTable2.Rows.InsertAt(dataRow, 0);
												text7 = codes.Search2("select Name from Empdata where ID='" + dataGridView1.Rows[num14].Cells[7].Value.ToString() + "'").Rows[0][0].ToString();
											}
											else
											{
												for (int j = 0; j < dataTable9.Rows.Count; j++)
												{
													if (!(dataGridView1.Rows[num14].Cells[7].Value.ToString() != dataTable9.Rows[j][0].ToString()))
													{
														text7 = codes.Search2("select Name from Empdata where ID='" + dataGridView1.Rows[num14].Cells[7].Value.ToString() + "'").Rows[0][0].ToString();
														continue;
													}
													text3 = "";
													flag3 = true;
													break;
												}
											}
										}
										if (flag3)
										{
											break;
										}
									}
								}
								catch
								{
								}
								for (int i = 0; i < dataGridView1.Rows.Count; i++)
								{
									string text4 = "";
									num13 = ((!(dataGridView1.Rows[i].Cells["BeforeDariba"].Value.ToString() != "")) ? (num13 + 0.0) : (num13 + Convert.ToDouble(dataGridView1.Rows[i].Cells["BeforeDariba"].Value.ToString())));
									DataTable dataTable4 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
									try
									{
										text4 = dataTable4.Rows[0][0].ToString();
									}
									catch
									{
									}
									double num9 = Convert.ToDouble(dataGridView1.Rows[i].Cells["Paid"].Value.ToString());
									if (num9 > 0.0)
									{
										text3 = dataGridView1.Rows[i].Cells[7].Value.ToString();
										DataTable dataTable10 = codes.Search2("SELECT dbo.PatientAccount.Bean FROM  dbo.CompanyService INNER JOIN\r\n                      dbo.PatientAccount ON dbo.CompanyService.Service COLLATE SQL_Latin1_General_CP1_CI_AS = dbo.PatientAccount.Bean where dbo.PatientAccount.ID='" + dataGridView1.Rows[i].Cells["ID"].Value.ToString() + "'");
										if (dataTable10.Rows.Count > 0)
										{
											((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, paydateTimePicker1.Value, dataGridView1.Rows[i].Cells["Service"].Value.ToString(), num13.ToString(), dataGridView1.Rows[i].Cells["OldPaid"].Value.ToString(), totpaytextBox.Text, Teeth, text4, Main.usernames, text, dataGridView1.Rows[i].Cells["Count"].Value.ToString(), dataGridView1.Rows[i].Cells["ServicePrice"].Value.ToString(), Convert.ToDouble(dataGridView1.Rows[i].Cells["BeforeDariba"].Value.ToString()) * Convert.ToDouble(dataGridView1.Rows[i].Cells["Dariba"].Value.ToString()) / 100.0, text7);
										}
										else
										{
											((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, paydateTimePicker1.Value, dataGridView1.Rows[i].Cells["Service"].Value.ToString(), num13.ToString(), dataGridView1.Rows[i].Cells["OldPaid"].Value.ToString(), totpaytextBox.Text, Teeth, text4, Main.usernames, text, dataGridView1.Rows[i].Cells["Count"].Value.ToString(), dataGridView1.Rows[i].Cells["ServicePrice"].Value.ToString(), 0, text7);
										}
									}
								}
								sqlConnection2.ConnectionString = codes.ConnectionStr;
								sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
								sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
								sqlDataAdapter2.Fill(ds);
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt_HalfA4.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text5;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = num3.ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								try
								{
									DataTable dataTable11 = codes.Search2("SELECT Name from Empdata where ID='" + text3 + "'");
									reportDocument.SetParameterValue("DoctorName", dataTable11.Rows[0][0].ToString());
								}
								catch
								{
								}
								if (checkBox2.Checked)
								{
									reportDocument.PrintToPrinter(1, collated: true, 1, 1);
									break;
								}
								FrmStatmentRpt_HalfA4 frmStatmentRpt_HalfA = new FrmStatmentRpt_HalfA4(reportDocument);
								frmStatmentRpt_HalfA.ShowDialog();
								break;
							}
							default:
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text5;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = num3.ToString();
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = (num2 - num3 - num4).ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								reportDocument.SetParameterValue("Assistant", text2);
								if (checkBox2.Checked)
								{
									reportDocument.PrintToPrinter(1, collated: true, 1, 1);
									break;
								}
								StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
								statmentRptFrm.ShowDialog();
								break;
							}
							}
						}
						else
						{
							switch (text6)
							{
							case "1/2 A4":
							{
								((DataTable)(object)ds.Statment).Rows.Clear();
								double num13 = 0.0;
								int num15 = 0;
								DataTable dataTable12 = new DataTable();
								dataTable12.Columns.Add("ID");
								string text8 = "";
								bool flag4 = false;
								try
								{
									for (num15 = 0; num15 < dataGridView1.Rows.Count; num15++)
									{
										if (Convert.ToDouble(dataGridView1.Rows[num15].Cells["Paid"].Value.ToString()) > 0.0)
										{
											if (dataTable12.Rows.Count == 0)
											{
												DataRow dataRow = dataTable12.NewRow();
												dataRow["ID"] = dataGridView1.Rows[num15].Cells[7].Value.ToString();
												dataTable12.Rows.InsertAt(dataRow, 0);
												text8 = codes.Search2("select Name from Empdata where ID='" + dataGridView1.Rows[num15].Cells[7].Value.ToString() + "'").Rows[0][0].ToString();
											}
											else
											{
												for (int j = 0; j < dataTable12.Rows.Count; j++)
												{
													if (!(dataGridView1.Rows[num15].Cells[7].Value.ToString() != dataTable12.Rows[j][0].ToString()))
													{
														text8 = codes.Search2("select Name from Empdata where ID='" + dataGridView1.Rows[num15].Cells[7].Value.ToString() + "'").Rows[0][0].ToString();
														continue;
													}
													text8 = "";
													flag4 = true;
													break;
												}
											}
										}
										if (flag4)
										{
											break;
										}
									}
								}
								catch
								{
								}
								for (int i = 0; i < dataGridView1.Rows.Count; i++)
								{
									string text4 = "";
									num13 += Convert.ToDouble(dataGridView1.Rows[i].Cells["BeforeDariba"].Value.ToString());
									DataTable dataTable4 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
									try
									{
										text4 = dataTable4.Rows[0][0].ToString();
									}
									catch
									{
									}
									double num9 = Convert.ToDouble(dataGridView1.Rows[i].Cells["Paid"].Value.ToString());
									if (num9 > 0.0)
									{
										DataTable dataTable10 = codes.Search2("SELECT dbo.PatientAccount.Bean FROM  dbo.CompanyService INNER JOIN\r\n                      dbo.PatientAccount ON dbo.CompanyService.Service COLLATE SQL_Latin1_General_CP1_CI_AS = dbo.PatientAccount.Bean where dbo.PatientAccount.ID='" + dataGridView1.Rows[i].Cells["ID"].Value.ToString() + "'");
										if (dataTable10.Rows.Count > 0)
										{
											((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, paydateTimePicker1.Value, dataGridView1.Rows[i].Cells["Service"].Value.ToString(), num13.ToString(), dataGridView1.Rows[i].Cells["OldPaid"].Value.ToString(), totpaytextBox.Text, Teeth, text4, Main.usernames, text, dataGridView1.Rows[i].Cells["Count"].Value.ToString(), dataGridView1.Rows[i].Cells["ServicePrice"].Value.ToString(), Convert.ToDouble(dataGridView1.Rows[i].Cells["BeforeDariba"].Value.ToString()) * Convert.ToDouble(dataGridView1.Rows[i].Cells["Dariba"].Value.ToString()) / 100.0, text8);
										}
										else
										{
											((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, paydateTimePicker1.Value, dataGridView1.Rows[i].Cells["Service"].Value.ToString(), num13.ToString(), dataGridView1.Rows[i].Cells["OldPaid"].Value.ToString(), totpaytextBox.Text, Teeth, text4, Main.usernames, text, dataGridView1.Rows[i].Cells["Count"].Value.ToString(), dataGridView1.Rows[i].Cells["ServicePrice"].Value.ToString(), 0, text8);
										}
									}
								}
								sqlConnection2.ConnectionString = codes.ConnectionStr;
								sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
								sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
								sqlDataAdapter2.Fill(ds);
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt_HalfA4.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text5;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = num3.ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								try
								{
									reportDocument.SetParameterValue("DoctorName", Main.usernames);
								}
								catch
								{
								}
								if (checkBox2.Checked)
								{
									reportDocument.PrintToPrinter(1, collated: true, 1, 1);
									break;
								}
								FrmStatmentRpt_HalfA4 frmStatmentRpt_HalfA = new FrmStatmentRpt_HalfA4(reportDocument);
								frmStatmentRpt_HalfA.ShowDialog();
								break;
							}
							case "A5":
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptA5.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text5;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = num3.ToString();
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = (num2 - num3 - num4).ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								if (checkBox2.Checked)
								{
									reportDocument.PrintToPrinter(1, collated: true, 1, 1);
									break;
								}
								StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
								statmentRptFrm.ShowDialog();
								break;
							}
							case "Reset":
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1Reset.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text5;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = num3.ToString();
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = (num2 - num3 - num4).ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								if (checkBox2.Checked)
								{
									reportDocument.PrintToPrinter(1, collated: true, 1, 1);
									break;
								}
								StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
								statmentRptFrm.ShowDialog();
								break;
							}
							default:
							{
								sqlConnection1.ConnectionString = codes.ConnectionStr;
								sqlDataAdapter1.Fill(ds);
								sqlConnection2.ConnectionString = codes.ConnectionStr;
								sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
								sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
								sqlDataAdapter2.Fill(ds);
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
									textObject.Text = text5;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = num3.ToString();
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = (num2 - num3 - num4).ToString();
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								reportDocument.SetParameterValue("Assistant", text2);
								if (checkBox2.Checked)
								{
									reportDocument.PrintToPrinter(1, collated: true, 1, 1);
									break;
								}
								StatmentRptFrm statmentRptFrm2 = new StatmentRptFrm(reportDocument);
								statmentRptFrm2.ShowDialog();
								break;
							}
							}
						}
						Settings.Default.LivePrint = checkBox2.Checked;
						Settings.Default.Save();
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					dataGridView1.Rows.Clear();
					totpaytextBox.Text = "0";
					tottextBox.Text = "0";
					totpay = 0.0;
					total = 0.0;
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Valid Patient Name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					MessageBox.Show("من فضلك اختر اسم مريض صحيح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
		{
			try
			{
				totpay = 0.0;
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					double num = Convert.ToDouble(dataGridView1.Rows[i].Cells["Paid"].Value.ToString());
					if (num == 0.0)
					{
						continue;
					}
					try
					{
						if (PayBefore.Checked && num > Convert.ToDouble(Rased.Text))
						{
							MessageBox.Show("لا يمكن الدفع لان المدفوع اكبر من الرصيد السابق للمريض", "تنبيه");
							dataGridView1.Rows[i].Cells["Paid"].Value = 0;
							return;
						}
					}
					catch
					{
					}
					DataTable dataTable = new DataTable();
					dataTable = dc.GetTableText("select Price,PricePay from PatientAccount where ID = " + Convert.ToInt32(dataGridView1.Rows[i].Cells["ID"].Value.ToString()));
					double num2 = Convert.ToDouble(dataTable.Rows[0][0].ToString());
					double num3 = Convert.ToDouble(dataTable.Rows[0][1].ToString());
					if (num > num2 - num3)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Paid more than required , rest = '" + (num2 - num3) + "'", "Notes");
						}
						else
						{
							MessageBox.Show("المدفوع أكثر من المطلوب الباقي = '" + (num2 - num3) + "'", "تنبيه");
						}
						dataGridView1.Rows[i].Cells["Paid"].Value = (num2 - num3).ToString();
					}
					if (num < 0.0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Paid can not be < 0 ", "Notes");
						}
						else
						{
							MessageBox.Show(" لا يمكن الدفع بالسالب ", "تنبيه");
						}
						dataGridView1.Rows[i].Cells["Paid"].Value = 0;
					}
					totpay += Convert.ToDouble(dataGridView1.Rows[i].Cells["Paid"].Value.ToString());
					totpaytextBox.Text = totpay.ToString();
				}
			}
			catch
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Enter numbers only in the Price", "Notes");
				}
				else
				{
					MessageBox.Show("ادخل ارقام فقط في خانة المبلغ", "تنبيه");
				}
			}
		}

		private void PatientPayAccount_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (!checkBox1.Checked)
				{
					DataTable dt = dc.Select("SelectAllPatient");
					gui.loadComboBox(PatientComboBox, dt);
				}
			}
			catch
			{
			}
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBox1.Checked)
				{
					DataTable dataTable = codes.Search2(string.Concat("select id,pname from PatientData where company='", comboBox1.SelectedValue, "' and Active = 'True'"));
					PatientComboBox.DataSource = dataTable;
					PatientComboBox.ValueMember = dataTable.Columns[0].ToString();
					PatientComboBox.DisplayMember = dataTable.Columns[1].ToString();
				}
			}
			catch
			{
			}
		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBox1.Checked)
				{
					DataTable dataTable = codes.Search2("select id,pname from PatientData where Mob like '%" + textBox2.Text + "%' and Active = 'True'");
					PatientComboBox.DataSource = dataTable;
					PatientComboBox.ValueMember = dataTable.Columns[0].ToString();
					PatientComboBox.DisplayMember = dataTable.Columns[1].ToString();
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count == 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please select record");
					}
					else
					{
						MessageBox.Show("من فضلك اختر سجل");
					}
					return;
				}
				if (Convert.ToDecimal(dataGridView1.SelectedRows[0].Cells["OldPaid"].Value.ToString()) > 0m)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("This service can not be deleted because it is paid or paid part of it");
					}
					else
					{
						MessageBox.Show("لا يمكن حذف هذه الخدمة لأنها مدفوعة أو مدفوع جزء منها");
					}
					return;
				}
				decimal num = 0m;
				try
				{
					num = Convert.ToDecimal(codes.Search2("select DiscountValue from PatientAccount where id='" + dataGridView1.SelectedRows[0].Cells["ID"].Value.ToString() + "'").Rows[0][0]);
				}
				catch
				{
				}
				if (num != 0m)
				{
					codes.Add2("insert into AddDiscounts (Patient, Discount, Date) values('" + PatientComboBox.Text + "','" + num + "','" + paydateTimePicker1.Value.ToString("MM/dd/yyyy") + "')");
				}
				codes.Delete2("delete from PatientAccount where id='" + dataGridView1.SelectedRows[0].Cells["ID"].Value.ToString() + "'");
				codes.Delete2("delete from AccountDetails where PatientAcountId='" + dataGridView1.SelectedRows[0].Cells["ID"].Value.ToString() + "'");
				try
				{
					DataTable dataTable = codes.Search2("select ID,Madeen from Company5 where PatientAccountId ='" + dataGridView1.SelectedRows[0].Cells["ID"].Value.ToString() + "'");
					string text = dataTable.Rows[0][0].ToString();
					string text2 = dataTable.Rows[0][1].ToString();
					codes.Edit2("update Company5 set Raseed = Raseed - " + text2 + " where ID > '" + text + "'");
					codes.Delete2("delete from Company5 where PatientAccountId ='" + dataGridView1.SelectedRows[0].Cells["ID"].Value.ToString() + "'");
				}
				catch
				{
				}
				try
				{
					if (dataGridView1.SelectedRows[0].Cells[1].Value.ToString() == "سحب كميات اصناف")
					{
						string text3 = codes.Search2("select ID from Sahb where PatientAccountId ='" + dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + "'").Rows[0][0].ToString();
						DataTable dataTable2 = codes.Search2("select * from Sahb_details where SahbId='" + text3 + "'");
						for (int i = 0; i < dataTable2.Rows.Count; i++)
						{
							string text4 = dataTable2.Rows[i][2].ToString();
							string text5 = dataTable2.Rows[i][3].ToString();
							string text6 = dataTable2.Rows[i][4].ToString();
							decimal num2 = 0m;
							try
							{
								DataTable dataTable3 = codes.Search2("select Qnt from store where ItemID='" + text4 + "'");
								num2 = Convert.ToDecimal(dataTable3.Rows[0][0].ToString());
							}
							catch
							{
							}
							decimal num3 = 0m;
							try
							{
								DataTable dataTable4 = codes.Search2("select BuyPrice from store where ItemID='" + text4 + "'");
								num3 = Convert.ToDecimal(dataTable4.Rows[0][0].ToString());
							}
							catch
							{
							}
							decimal num4 = 0m;
							try
							{
								DataTable dataTable5 = codes.Search2("select SalePrice from Items where ID='" + text4 + "'");
								num4 = Convert.ToDecimal(dataTable5.Rows[0][0].ToString());
							}
							catch
							{
							}
							codes.Add2("INSERT INTO ItemsMove\r\n                      (ItemId, StoreId, IncomeQnt, IncomePrice, OutcomeQnt, OutcomePrice, LastQnt, LastIncomePrice, LastOutComePrice, Bayan, MoveDate, UserId, Time,Type)\r\n                       VALUES ('" + text4 + "',0,0,0,'" + text6 + "','" + text5 + "','" + num2 + "','" + num3 + "','" + num4 + "','حذف سحب أصناف في كشف','" + DateTime.Now.ToString("MM/dd/yyyy") + "','" + Main.userId + "','" + DateTime.Now.ToShortTimeString() + "','دخول')");
							codes.Edit2("update Store set Qnt = Qnt + '" + text6 + "' where ItemId = '" + text4 + "'");
							codes.Add2("insert into SahbItem (TypeSahb, ItemId, Qty, Date, Notes) values('حذف استهلاك مرضى','" + text4 + "','" + Convert.ToDecimal(text6) * -1m + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','')");
						}
						codes.Delete2("delete from Sahb where PatientAccountId ='" + dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + "'");
						codes.Delete2("delete from Sahb_details where SahbId='" + text3 + "'");
					}
				}
				catch
				{
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Deleted Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				MethodsClass.UserMove("حذف مدفوع لمريض");
				PatientComboBox_SelectedIndexChanged(sender, e);
			}
			catch
			{
			}
		}

		private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
		{
			try
			{
				decimal num = 0m;
				decimal num2 = 0m;
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					num += Convert.ToDecimal(dataGridView1.Rows[i].Cells["Price"].Value);
					num2 += Convert.ToDecimal(dataGridView1.Rows[i].Cells["OldPaid"].Value);
				}
				textBox3.Text = num.ToString();
				textBox1.Text = num2.ToString();
				dataGridView1.CurrentRow.Cells["TotalPaid"].Value = dataGridView1.CurrentRow.Cells["Paid"].Value;
			}
			catch
			{
			}
		}

		private void dataGridView1_CurrentCellDirtyStateChanged(object sender, EventArgs e)
		{
			if (dataGridView1.IsCurrentCellDirty)
			{
				dataGridView1.CommitEdit(DataGridViewDataErrorContexts.Commit);
			}
		}

		private void EsalNoTxt_KeyPress(object sender, KeyPressEventArgs e)
		{
			if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
			{
				if (e.KeyChar == '.' && EsalNoTxt.Text.Contains("."))
				{
					e.Handled = true;
				}
			}
			else
			{
				e.Handled = true;
				MessageBox.Show("من فضلك أدخل رقم الإيصال بالارقام");
			}
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			DataTable dataTable = codes.Search2("SELECT PatientNotice.NoteType,PatientNotice.Amount FROM PatientNotice INNER JOIN PatientAccount ON PatientNotice.PAccount_ID = PatientAccount.ID where PatientAccount.ID=" + Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString()));
			if (dataTable.Rows.Count > 0)
			{
				string text = dataTable.Rows[0]["NoteType"].ToString();
				decimal num = Convert.ToDecimal(dataTable.Rows[0]["Amount"].ToString());
				MessageBox.Show("يوجد إشعار " + text + " قيمته =" + num);
			}
			else
			{
				MessageBox.Show("لا يوجد إشعارات لهذه الخدمة");
			}
		}

		private void PayNaqdy_CheckedChanged(object sender, EventArgs e)
		{
			if (PayNaqdy.Checked)
			{
				label5.Visible = true;
				comboBox2.Visible = true;
			}
			else
			{
				label5.Visible = false;
				comboBox2.Visible = false;
			}
		}
	}
}
