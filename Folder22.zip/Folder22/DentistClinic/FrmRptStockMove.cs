using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmRptStockMove : ReportBaseForm
	{
		private IContainer components = null;

		private CrystalReportViewer crystalReportViewer1;

		private GroupBox groupBox1;

		private Button ViewRptBtn;

		private DateTimePicker date2;

		private DateTimePicker date1;

		private Label label3;

		private Label label2;

		private DataGridView dataGridView1;

		private Label label4;

		private ComboBox StockCom;

		private DataSet1 dataSet11;

		private RadioButton radioButton2;

		private CheckBox checkBox1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlDeleteCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlSelectCommand1;

		private SqlCommand sqlUpdateCommand1;

		private RadioButton radioButton1;

		private ClassDataBase dc;

		private double pay;

		private double take;

		private decimal balance;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmRptStockMove));
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			groupBox1 = new System.Windows.Forms.GroupBox();
			radioButton1 = new System.Windows.Forms.RadioButton();
			radioButton2 = new System.Windows.Forms.RadioButton();
			checkBox1 = new System.Windows.Forms.CheckBox();
			label4 = new System.Windows.Forms.Label();
			StockCom = new System.Windows.Forms.ComboBox();
			ViewRptBtn = new System.Windows.Forms.Button();
			date2 = new System.Windows.Forms.DateTimePicker();
			date1 = new System.Windows.Forms.DateTimePicker();
			label3 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			dataSet11 = new DataSet1();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(radioButton1);
			groupBox1.Controls.Add(radioButton2);
			groupBox1.Controls.Add(checkBox1);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(StockCom);
			groupBox1.Controls.Add(ViewRptBtn);
			groupBox1.Controls.Add(date2);
			groupBox1.Controls.Add(date1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(label2);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			radioButton1.AccessibleDescription = null;
			radioButton1.AccessibleName = null;
			resources.ApplyResources(radioButton1, "radioButton1");
			radioButton1.BackgroundImage = null;
			radioButton1.Name = "radioButton1";
			radioButton1.UseVisualStyleBackColor = true;
			radioButton2.AccessibleDescription = null;
			radioButton2.AccessibleName = null;
			resources.ApplyResources(radioButton2, "radioButton2");
			radioButton2.BackgroundImage = null;
			radioButton2.Checked = true;
			radioButton2.Name = "radioButton2";
			radioButton2.TabStop = true;
			radioButton2.UseVisualStyleBackColor = true;
			checkBox1.AccessibleDescription = null;
			checkBox1.AccessibleName = null;
			resources.ApplyResources(checkBox1, "checkBox1");
			checkBox1.BackgroundImage = null;
			checkBox1.Name = "checkBox1";
			checkBox1.UseVisualStyleBackColor = true;
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Font = null;
			label4.Name = "label4";
			StockCom.AccessibleDescription = null;
			StockCom.AccessibleName = null;
			resources.ApplyResources(StockCom, "StockCom");
			StockCom.BackgroundImage = null;
			StockCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			StockCom.Font = null;
			StockCom.FormattingEnabled = true;
			StockCom.Name = "StockCom";
			ViewRptBtn.AccessibleDescription = null;
			ViewRptBtn.AccessibleName = null;
			resources.ApplyResources(ViewRptBtn, "ViewRptBtn");
			ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
			ViewRptBtn.BackgroundImage = null;
			ViewRptBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			ViewRptBtn.Name = "ViewRptBtn";
			ViewRptBtn.UseVisualStyleBackColor = false;
			ViewRptBtn.Click += new System.EventHandler(ViewRptBtn_Click);
			date2.AccessibleDescription = null;
			date2.AccessibleName = null;
			resources.ApplyResources(date2, "date2");
			date2.BackgroundImage = null;
			date2.CalendarFont = null;
			date2.Font = null;
			date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date2.Name = "date2";
			date1.AccessibleDescription = null;
			date1.AccessibleName = null;
			resources.ApplyResources(date1, "date1");
			date1.BackgroundImage = null;
			date1.CalendarFont = null;
			date1.Font = null;
			date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date1.Name = "date1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[8]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Car.mdf;Integrated Security=True;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo")
			});
			sqlSelectCommand1.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(crystalReportViewer1);
			base.Controls.Add(groupBox1);
			base.Controls.Add(dataGridView1);
			Font = null;
			base.Name = "FrmRptStockMove";
			base.Load += new System.EventHandler(FrmRptStockMove_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(FrmRptStockMove_KeyDown);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}

		public FrmRptStockMove()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		public FrmRptStockMove(DateTime d1, DateTime d2, string FileName)
		{
			try
			{
				dataGridView1.Rows.Clear();
				take = 0.0;
				pay = 0.0;
				balance = 0m;
				dataSet11.Clear();
				try
				{
					DataTable tableText = dc.GetTableText("select isnull(sum(price),0) as Revenues  from StokeMove where type != 'حذف كشف' and type!='حساب طبيب' and type!='مصروفات' and type!='فاتورة مشتريات' and type!='مدفوعات للمورد' and type!='حذف إيرادات أخرى' and type!='حذف خدمات و مدفوعات مريض' and type != 'حساب مساعد' and type != 'تحويل الى خزينة' and type !='حذف أشعة' and type !='حذف تحليل' and Date < '" + d1.ToString("MM/dd/yyyy") + "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					DataTable tableText2 = dc.GetTableText("SELECT isnull(sum(Price),0) as Expenses FROM StokeMove where (type='حذف كشف' or type='حساب طبيب' or type='مصروفات' or type='فاتورة مشتريات' or type='مدفوعات للمورد' or type='حذف إيرادات أخرى' or type='حذف خدمات و مدفوعات مريض' or type = 'حساب مساعد' or type='تحويل الى خزينة' or type='حذف أشعة' or type='حذف تحليل') and Date < '" + d1.ToString("MM/dd/yyyy") + "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					DataTable tableText3 = dc.GetTableText(" select isnull(sum(Price),0) from StokeMove where type = 'رصيد اول المدة' and date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "'");
					balance = Convert.ToDecimal(tableText.Rows[0][0]) - Convert.ToDecimal(tableText2.Rows[0][0]) + Convert.ToDecimal(tableText3.Rows[0][0]);
					take = Convert.ToDouble(balance);
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'كشف' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل كشف' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'إعادة كشف' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText5 = dc.GetTableText(" select * from StokeMove where type = 'مدفوع مقدما\u064b من حساب مريض' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText5.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText5.Rows[i][1].ToString(), tableText5.Rows[i][2].ToString(), tableText5.Rows[i][3].ToString(), tableText5.Rows[i][4].ToString(), "دخول للخزينة", tableText5.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText5.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'مدفوعات مريض' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل مدفوعات مريض' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(Convert.ToDouble(tableText4.Rows[i][1].ToString()), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل مدفوعات مريض' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price<0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						double num = -1.0 * Convert.ToDouble(tableText4.Rows[i][1].ToString());
						dataGridView1.Rows.Add(-1.0 * Convert.ToDouble(tableText4.Rows[i][1].ToString()), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += num;
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'إيرادات أخرى' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حساب شركة' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف كشف' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حساب طبيب' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف حساب طبيب' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول من الخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حساب مساعد' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'مصروفات' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف إيرادات أخرى' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف خدمات و مدفوعات مريض' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف مصروفات' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'فاتورة مشتريات' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'مدفوعات للمورد' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'مدفوعات من المورد' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'فاتورة مبيعات' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'زيارة' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل زيارة' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price<0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل زيارة' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(-1.0 * Convert.ToDouble(tableText4.Rows[i][1].ToString()), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تحويل من خزينة' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تحويل الى خزينة' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'أشعة' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل أشعة' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل أشعة' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price<0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(Convert.ToDouble(tableText4.Rows[i][1].ToString()), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += -1.0 * Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف أشعة' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تحليل' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل تحليل' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price>0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل تحليل' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and Price<0 and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(Convert.ToDouble(tableText4.Rows[i][1].ToString()), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += -1.0 * Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف تحليل' and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				double num2 = take - pay;
				((DataTable)(object)dataSet11.DataTable2).Rows.Add(balance, date1.Value.ToShortDateString(), "رصيد اول المدة", "دخول للخزينة", pay, take, num2, "رصيد اول المدة", date1.Value, date2.Value, 0);
				for (int i = 1; i < dataGridView1.Rows.Count; i++)
				{
					string text = "";
					text = dataGridView1.Rows[i - 1].Cells[3].Value.ToString().Substring(dataGridView1.Rows[i - 1].Cells[3].Value.ToString().IndexOf(":") + 2);
					if (text == "")
					{
						((DataTable)(object)dataSet11.DataTableServices).Rows.Add(dataGridView1.Rows[i - 1].Cells[5].Value.ToString(), "");
					}
					else
					{
						try
						{
							if (dataGridView1.Rows[i - 1].Cells[3].Value.ToString().Contains("كشف"))
							{
								DataTable tableText6 = dc.GetTableText("select Bean from Esal where EsalNo='" + text + "'");
								for (int j = 0; j < tableText6.Rows.Count; j++)
								{
									((DataTable)(object)dataSet11.DataTableServices).Rows.Add(dataGridView1.Rows[i - 1].Cells[5].Value.ToString(), tableText6.Rows[j][0].ToString());
								}
							}
							else if (dataGridView1.Rows[i - 1].Cells[3].Value.ToString().Contains("حجز"))
							{
								DataTable tableText6 = dc.GetTableText("SELECT  dbo.PatientAccount.Bean FROM   dbo.AppointEsal INNER JOIN dbo.PatientAccount ON dbo.AppointEsal.PatientAcountId = dbo.PatientAccount.ID where AppointEsal.Id='" + text + "'");
								for (int j = 0; j < tableText6.Rows.Count; j++)
								{
									((DataTable)(object)dataSet11.DataTableServices).Rows.Add(dataGridView1.Rows[i - 1].Cells[5].Value.ToString(), tableText6.Rows[j][0].ToString());
								}
							}
							else
							{
								DataTable tableText6 = dc.GetTableText("select Bean from Esal where EsalNo='" + text + "'");
								for (int j = 0; j < tableText6.Rows.Count; j++)
								{
									((DataTable)(object)dataSet11.DataTableServices).Rows.Add(dataGridView1.Rows[i - 1].Cells[5].Value.ToString(), tableText6.Rows[j][0].ToString());
								}
							}
						}
						catch
						{
							((DataTable)(object)dataSet11.DataTableServices).Rows.Add(dataGridView1.Rows[i - 1].Cells[5].Value.ToString(), "");
						}
					}
					((DataTable)(object)dataSet11.DataTable2).Rows.Add(dataGridView1.Rows[i - 1].Cells[0].Value.ToString(), dataGridView1.Rows[i - 1].Cells[1].Value.ToString(), dataGridView1.Rows[i - 1].Cells[2].Value.ToString(), dataGridView1.Rows[i - 1].Cells[4].Value.ToString(), pay, take, num2, dataGridView1.Rows[i - 1].Cells[3].Value.ToString(), date1.Value, date2.Value, dataGridView1.Rows[i - 1].Cells[5].Value.ToString());
				}
				((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", d1, d2);
				((DataTable)(object)dataSet11.RptStockMove).Rows.Add(balance, "الكل", num2);
				RptStockMove rptStockMove = new RptStockMove();
				rptStockMove.SetDataSource(dataSet11);
				DiskFileDestinationOptions diskFileDestinationOptions = new DiskFileDestinationOptions();
				PdfRtfWordFormatOptions formatOptions = new PdfRtfWordFormatOptions();
				diskFileDestinationOptions.DiskFileName = FileName;
				ExportOptions exportOptions = rptStockMove.ExportOptions;
				exportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				exportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
				exportOptions.DestinationOptions = diskFileDestinationOptions;
				exportOptions.FormatOptions = formatOptions;
				rptStockMove.Export();
			}
			catch
			{
			}
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			try
			{
				dataGridView1.Rows.Clear();
				take = 0.0;
				pay = 0.0;
				balance = 0m;
				dataSet11.Clear();
				try
				{
					DataTable tableText = dc.GetTableText("select isnull(sum(price),0) as Revenues  from StokeMove where type != 'حذف كشف' and type!='حساب طبيب' and type!='مصروفات' and type!='فاتورة مشتريات' and type!='مدفوعات للمورد' and type!='حذف إيرادات أخرى' and type!='حذف خدمات و مدفوعات مريض' and type != 'حساب مساعد' and type != 'تحويل الى خزينة' and type !='حذف أشعة' and type !='حذف تحليل' and Date < '" + date1.Value.ToString("MM/dd/yyyy") + "' and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					DataTable tableText2 = dc.GetTableText("SELECT isnull(sum(Price),0) as Expenses FROM StokeMove where (type='حذف كشف' or type='حساب طبيب' or type='مصروفات' or type='فاتورة مشتريات' or type='مدفوعات للمورد' or type='حذف إيرادات أخرى' or type='حذف خدمات و مدفوعات مريض' or type = 'حساب مساعد' or type='تحويل الى خزينة' or type='حذف أشعة' or type='حذف تحليل') and Date < '" + date1.Value.ToString("MM/dd/yyyy") + "' and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					DataTable tableText3 = dc.GetTableText(" select isnull(sum(Price),0) from StokeMove where type = 'رصيد اول المدة' and date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and StockId='" + Convert.ToInt32(StockCom.SelectedValue) + "'");
					balance = Convert.ToDecimal(tableText.Rows[0][0]) - Convert.ToDecimal(tableText2.Rows[0][0]) + Convert.ToDecimal(tableText3.Rows[0][0]);
					take = Convert.ToDouble(balance);
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'كشف' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل كشف' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'إعادة كشف' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText5 = dc.GetTableText(" select * from StokeMove where type = 'مدفوع مقدما\u064b من حساب مريض' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and  StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText5.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText5.Rows[i][1].ToString(), tableText5.Rows[i][2].ToString(), tableText5.Rows[i][3].ToString(), tableText5.Rows[i][4].ToString(), "دخول للخزينة", tableText5.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText5.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'مدفوعات مريض' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل مدفوعات مريض' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(Convert.ToDouble(tableText4.Rows[i][1].ToString()), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل مدفوعات مريض' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price<0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						double num = -1.0 * Convert.ToDouble(tableText4.Rows[i][1].ToString());
						dataGridView1.Rows.Add(-1.0 * Convert.ToDouble(tableText4.Rows[i][1].ToString()), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += num;
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'إيرادات أخرى' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حساب شركة' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف كشف' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حساب طبيب' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف حساب طبيب' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول من الخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حساب مساعد' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'مصروفات' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف إيرادات أخرى' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف خدمات و مدفوعات مريض' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف مصروفات' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'فاتورة مشتريات' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'مدفوعات للمورد' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'مدفوعات من المورد' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'فاتورة مبيعات' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'زيارة' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل زيارة' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price<0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل زيارة' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(-1.0 * Convert.ToDouble(tableText4.Rows[i][1].ToString()), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تحويل من خزينة' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تحويل الى خزينة' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'أشعة' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل أشعة' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل أشعة' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price<0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(Convert.ToDouble(tableText4.Rows[i][1].ToString()), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += -1.0 * Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف أشعة' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تحليل' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل تحليل' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price>0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "دخول للخزينة", tableText4.Rows[i][0].ToString());
						take += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'تعديل تحليل' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and Price<0 and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(Convert.ToDouble(tableText4.Rows[i][1].ToString()), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += -1.0 * Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText4 = dc.GetTableText(" select * from StokeMove where type = 'حذف تحليل' and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
					for (int i = 0; i < tableText4.Rows.Count; i++)
					{
						dataGridView1.Rows.Add(tableText4.Rows[i][1].ToString(), tableText4.Rows[i][2].ToString(), tableText4.Rows[i][3].ToString(), tableText4.Rows[i][4].ToString(), "خروج من الخزينة", tableText4.Rows[i][0].ToString());
						pay += Convert.ToDouble(tableText4.Rows[i][1].ToString());
					}
				}
				catch
				{
				}
				double num2 = take - pay;
				((DataTable)(object)dataSet11.DataTable2).Rows.Add(balance, date1.Value.ToShortDateString(), "رصيد اول المدة", "دخول للخزينة", pay, take, num2, "رصيد اول المدة", date1.Value, date2.Value, 0);
				for (int i = 1; i < dataGridView1.Rows.Count; i++)
				{
					string text = "";
					text = dataGridView1.Rows[i - 1].Cells[3].Value.ToString().Substring(dataGridView1.Rows[i - 1].Cells[3].Value.ToString().IndexOf(":") + 2);
					if (text == "")
					{
						((DataTable)(object)dataSet11.DataTableServices).Rows.Add(dataGridView1.Rows[i - 1].Cells[5].Value.ToString(), "");
					}
					else
					{
						try
						{
							if (dataGridView1.Rows[i - 1].Cells[3].Value.ToString().Contains("كشف"))
							{
								DataTable tableText6 = dc.GetTableText("select Bean from Esal where EsalNo='" + text + "'");
								for (int j = 0; j < tableText6.Rows.Count; j++)
								{
									((DataTable)(object)dataSet11.DataTableServices).Rows.Add(dataGridView1.Rows[i - 1].Cells[5].Value.ToString(), tableText6.Rows[j][0].ToString());
								}
							}
							else if (dataGridView1.Rows[i - 1].Cells[3].Value.ToString().Contains("حجز"))
							{
								DataTable tableText6 = dc.GetTableText("SELECT  dbo.PatientAccount.Bean FROM   dbo.AppointEsal INNER JOIN dbo.PatientAccount ON dbo.AppointEsal.PatientAcountId = dbo.PatientAccount.ID where AppointEsal.Id='" + text + "'");
								for (int j = 0; j < tableText6.Rows.Count; j++)
								{
									((DataTable)(object)dataSet11.DataTableServices).Rows.Add(dataGridView1.Rows[i - 1].Cells[5].Value.ToString(), tableText6.Rows[j][0].ToString());
								}
							}
							else
							{
								DataTable tableText6 = dc.GetTableText("select Bean from Esal where EsalNo='" + text + "'");
								for (int j = 0; j < tableText6.Rows.Count; j++)
								{
									((DataTable)(object)dataSet11.DataTableServices).Rows.Add(dataGridView1.Rows[i - 1].Cells[5].Value.ToString(), tableText6.Rows[j][0].ToString());
								}
							}
						}
						catch
						{
							((DataTable)(object)dataSet11.DataTableServices).Rows.Add(dataGridView1.Rows[i - 1].Cells[5].Value.ToString(), "");
						}
					}
					((DataTable)(object)dataSet11.DataTable2).Rows.Add(dataGridView1.Rows[i - 1].Cells[0].Value.ToString(), dataGridView1.Rows[i - 1].Cells[1].Value.ToString(), dataGridView1.Rows[i - 1].Cells[2].Value.ToString(), dataGridView1.Rows[i - 1].Cells[4].Value.ToString(), pay, take, num2, dataGridView1.Rows[i - 1].Cells[3].Value.ToString(), date1.Value, date2.Value, dataGridView1.Rows[i - 1].Cells[5].Value.ToString());
				}
				((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value, date1.Value);
				((DataTable)(object)dataSet11.RptStockMove).Rows.Add(balance, StockCom.Text, num2);
				sqlConnection1.ConnectionString = dc.ConnectionStr;
				sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter1.SelectCommand.CommandText = " select * from DentalData ";
				sqlDataAdapter1.Fill(dataSet11);
				if (checkBox1.Checked)
				{
					if (radioButton2.Checked)
					{
						RptStockMove1 rptStockMove = new RptStockMove1();
						rptStockMove.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = rptStockMove;
					}
					else
					{
						RptStockMove2 rptStockMove2 = new RptStockMove2();
						rptStockMove2.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = rptStockMove2;
					}
				}
				else
				{
					RptStockMove rptStockMove3 = new RptStockMove();
					rptStockMove3.SetDataSource(dataSet11);
					crystalReportViewer1.ReportSource = rptStockMove3;
				}
			}
			catch
			{
			}
		}

		private void FrmRptStockMove_Load(object sender, EventArgs e)
		{
			dataGridView1.Columns.Add("price", "السعر");
			dataGridView1.Columns.Add("date", "التاريخ");
			dataGridView1.Columns.Add("type", "البيان");
			dataGridView1.Columns.Add("bean", "تفصيلى");
			dataGridView1.Columns.Add("move", "الحاله");
			dataGridView1.Columns.Add("ID", "ID");
			try
			{
				DataTable tableText = dc.GetTableText("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				StockCom.DataSource = null;
				StockCom.DataSource = tableText;
				StockCom.DisplayMember = tableText.Columns[1].ToString();
				StockCom.ValueMember = tableText.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void FrmRptStockMove_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}
	}
}
