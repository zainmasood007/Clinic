using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Properties;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmDoctorAcountByDate : ReportBaseForm
	{
		private ClassDataBase dc = new ClassDataBase(".\\sqlExpress");

		private GUI gui = new GUI();

		private IContainer components = null;

		private GroupBox groupBox1;

		private DateTimePicker date2;

		private DateTimePicker date1;

		private Label label3;

		private ComboBox doctorcomboBox;

		private Label label2;

		private Label label1;

		private GroupBox groupBox2;

		private Button ViewRptBtn;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlSelectCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlInsertCommand2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlSelectCommand3;

		private SqlConnection sqlConnection3;

		private SqlCommand sqlInsertCommand3;

		private SqlDataAdapter sqlDataAdapter3;

		private SqlCommand sqlSelectCommand4;

		private SqlConnection sqlConnection4;

		private SqlCommand sqlInsertCommand4;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter4;

		private CrystalReportViewer crystalReportViewer1;

		private Label l3;

		private Label l2;

		private Label l1;

		private Label l5;

		private Label l4;

		private SqlDataAdapter sqlDataAdapter5;

		private SqlCommand sqlCommand1;

		private SqlConnection sqlConnection5;

		private SqlCommand sqlCommand2;

		private SqlCommand sqlCommand3;

		private SqlCommand sqlCommand4;

		private CheckBox checkBox1;

		private CheckBox DoctorService;

		private SqlDataAdapter sqlDataAdapter6;

		private SqlCommand sqlCommand5;

		private SqlConnection sqlConnection6;

		private SqlCommand sqlCommand6;

		private SqlCommand sqlCommand7;

		private SqlCommand sqlCommand8;

		private SqlDataAdapter sqlDataAdapter7;

		private SqlCommand sqlCommand9;

		private SqlConnection sqlConnection7;

		private SqlCommand sqlCommand10;

		private SqlCommand sqlCommand11;

		private SqlCommand sqlCommand12;

		private SqlConnection sqlConnection8;

		public FrmDoctorAcountByDate()
		{
			InitializeComponent();
		}

		public FrmDoctorAcountByDate(DateTime d1, DateTime d2, string FileName, string ID)
		{
			InitializeComponent();
			try
			{
				DataTable tableText = dc.GetTableText("select * from PatientAccount where DoctorID='" + ID + "' and Bean<>'خدمة ثابتة' and Date Between'" + d1.ToString("MM/dd/yyyy") + "'and'" + d2.ToString("MM/dd/yyyy") + "'");
				if (tableText.Rows.Count <= 0)
				{
					return;
				}
				sqlConnection1.ConnectionString = dc.ConnectionStr;
				sqlConnection2.ConnectionString = dc.ConnectionStr;
				sqlConnection3.ConnectionString = dc.ConnectionStr;
				sqlConnection4.ConnectionString = dc.ConnectionStr;
				sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter1.SelectCommand.CommandText = "select * from PatientAccount where DoctorID='" + ID + "' and Bean<>'خدمة ثابتة' and Date Between'" + d1.ToString("MM/dd/yyyy") + "'and'" + d2.ToString("MM/dd/yyyy") + "'";
				string value = date2.Value.Subtract(date1.Value).Days.ToString();
				DataTable tableText2 = dc.GetTableText("select Salary,isnull(Percentage,0) from Empdata where ID = " + ID);
				int value2 = Convert.ToInt32(value) + 1;
				string value3 = (Convert.ToDecimal(tableText2.Rows[0][0].ToString()) / 30m * Convert.ToDecimal(value2)).ToString();
				string text = tableText2.Rows[0][1].ToString();
				DataTable tableText3 = dc.GetTableText("select isnull(sum(Price),0) from Appointments where DoctorID = '" + ID + "' and Done = '" + true + "' and detectDate between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "'");
				string text2 = tableText3.Rows[0][0].ToString();
				if (text == "")
				{
					text = "0.00";
				}
				string text3 = dc.GetTableText("select ServiceName from Properties ").Rows[0][0].ToString();
				DataTable dataTable = new DataTable();
				dataTable = dc.GetTableText("select isnull(sum(Price),0) from PatientAccount where DoctorID = '" + ID + "'  and Date between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "'and Bean != '" + text3 + "'");
				string text4 = dataTable.Rows[0][0].ToString();
				DataTable tableText4 = dc.GetTableText("SELECT     dbo.PatientData.PName, dbo.PatientAccount.BeanDate, dbo.PatientAccount.Bean,dbo.PatientData.company,dbo.PatientAccount.Price\r\nFROM         dbo.PatientData INNER JOIN\r\n                      dbo.PatientAccount ON dbo.PatientData.ID = dbo.PatientAccount.PatientId where dbo.PatientAccount.DoctorID = '" + ID + "' and PatientAccount.Bean<>'خدمة ثابتة' and dbo.PatientAccount.BeanDate Between '" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "'");
				string value4 = "0";
				for (int i = 0; i < tableText4.Rows.Count; i++)
				{
					DataTable tableText5 = dc.GetTableText("select dbo.NesbaDoctor.Price, dbo.NesbaDoctor.Cost, dbo.NesbaDoctor.Safy, dbo.NesbaDoctor.Nesba, dbo.NesbaDoctor.NesbaValue from NesbaDoctor where dbo.NesbaDoctor.DoctorID= '" + ID + "@' AND dbo.NesbaDoctor.Company = '" + tableText4.Rows[i]["company"].ToString() + "' AND dbo.NesbaDoctor.Service = '" + tableText4.Rows[i]["Bean"].ToString() + "'");
					if (tableText5.Rows.Count > 0)
					{
						value4 = (Convert.ToDouble(value4) + Convert.ToDouble(tableText5.Rows[0][4].ToString())).ToString();
						continue;
					}
					string value5 = Convert.ToDouble(dc.GetTableText(string.Concat("select Percentage from Empdata where ID='", doctorcomboBox.SelectedValue, "'")).Rows[0][0]).ToString();
					value4 = (Convert.ToDouble(value4) + Convert.ToDouble(Convert.ToDouble(tableText4.Rows[i][4].ToString()) * Convert.ToDouble(value5) / 100.0)).ToString();
				}
				value4 = (Convert.ToDouble(value4) + Convert.ToDouble(value3)).ToString();
				sqlDataAdapter1.Fill(dataSet11);
				sqlDataAdapter2.Fill(dataSet11);
				sqlDataAdapter3.Fill(dataSet11);
				sqlDataAdapter4.Fill(dataSet11);
				((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", d1, d2);
				((DataTable)(object)dataSet11.DoctorAcountByDate).Rows.Add(Convert.ToDecimal(value3), text, text2, text4, Convert.ToDecimal(value4));
				DoctorAcountbyDateRpt doctorAcountbyDateRpt = new DoctorAcountbyDateRpt();
				doctorAcountbyDateRpt.SetDataSource(dataSet11);
				doctorAcountbyDateRpt.SetDataSource(dataSet11);
				DiskFileDestinationOptions diskFileDestinationOptions = new DiskFileDestinationOptions();
				PdfRtfWordFormatOptions formatOptions = new PdfRtfWordFormatOptions();
				diskFileDestinationOptions.DiskFileName = FileName;
				ExportOptions exportOptions = doctorAcountbyDateRpt.ExportOptions;
				exportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
				exportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
				exportOptions.DestinationOptions = diskFileDestinationOptions;
				exportOptions.FormatOptions = formatOptions;
				doctorAcountbyDateRpt.Export();
			}
			catch
			{
			}
		}

		private void FrmDoctorAcountByDate_Load(object sender, EventArgs e)
		{
			DataTable dataTable = new DataTable();
			try
			{
				dataTable = dc.Select("SelectAllDoctor");
				gui.loadComboBox(doctorcomboBox, dataTable);
			}
			catch
			{
			}
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			try
			{
				sqlConnection1.ConnectionString = dc.ConnectionStr;
				sqlConnection2.ConnectionString = dc.ConnectionStr;
				sqlConnection3.ConnectionString = dc.ConnectionStr;
				sqlConnection4.ConnectionString = dc.ConnectionStr;
				sqlConnection5.ConnectionString = dc.ConnectionStr;
				sqlConnection6.ConnectionString = dc.ConnectionStr;
				sqlConnection7.ConnectionString = dc.ConnectionStr;
				sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter6.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter7.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter7.SelectCommand.CommandText = "SELECT * from users where userId=" + Main.userId;
				dataSet11.Clear();
				DataTable tableText = dc.GetTableText("select * from Empdata where Name='" + doctorcomboBox.Text + "'");
				DataTable dataTable2;
				DataTable tableText5;
				string value3;
				if (tableText.Rows.Count > 0)
				{
					DataTable tableText2;
					if (checkBox1.Checked)
					{
						tableText2 = dc.GetTableText(" SELECT distinct PatientAccount.[ID] ,PatientAccount.[PatientId],PatientAccount.[DoctorID],PatientAccount.[Bean],PatientAccount.[Price],PatientAccount.[Pay] ,PatientAccount.[Date] ,PatientAccount.[PricePay] ,PatientAccount.[BeanDate],PatientAccount.[TeathId] ,PatientAccount.[Appears] ,PatientAccount.[VisitID] ,PatientAccount.[AppointNum],PatientAccount.[Assistant],PatientAccount.[StockId],PatientAccount.[RayId] ,PatientAccount.[AnalyzeId],PatientAccount.[DiscountValue],PatientAccount.[ServiceCount] ,PatientAccount.[Dariba] ,PatientAccount.[PriceBeforeDariba],PatientAccount.[EnterDiscount] ,PatientAccount.[EnterDiscountValue],PatientAccount.[wieght] FROM dbo.PatientAccount INNER JOIN dbo.Esal ON dbo.Esal.PatientAcountId = dbo.PatientAccount.ID where PatientAccount.DoctorID='" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "'  and PatientAccount.Bean<>'خدمة ثابتة' and dbo.Esal.Date Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "' group by PatientAccount.[ID] ,PatientAccount.[PatientId],PatientAccount.[DoctorID],PatientAccount.[Bean],PatientAccount.[Price],PatientAccount.[Pay] ,PatientAccount.[Date] ,PatientAccount.[PricePay] ,PatientAccount.[BeanDate],PatientAccount.[TeathId] ,PatientAccount.[Appears] ,PatientAccount.[VisitID] ,PatientAccount.[AppointNum],PatientAccount.[Assistant],PatientAccount.[StockId],PatientAccount.[RayId] ,PatientAccount.[AnalyzeId],PatientAccount.[DiscountValue],PatientAccount.[ServiceCount] ,PatientAccount.[Dariba] ,PatientAccount.[PriceBeforeDariba],PatientAccount.[EnterDiscount] ,PatientAccount.[EnterDiscountValue],PatientAccount.[wieght] order by PatientAccount.[Date]");
						sqlDataAdapter1.SelectCommand.CommandText = "SELECT distinct PatientAccount.[ID] ,PatientAccount.[PatientId],PatientAccount.[DoctorID],PatientAccount.[Bean],PatientAccount.[Price],PatientAccount.[Pay] ,PatientAccount.[Date] ,PatientAccount.[PricePay] ,PatientAccount.[BeanDate],PatientAccount.[TeathId] ,PatientAccount.[Appears] ,PatientAccount.[VisitID] ,PatientAccount.[AppointNum],PatientAccount.[Assistant],PatientAccount.[StockId],PatientAccount.[RayId] ,PatientAccount.[AnalyzeId],PatientAccount.[DiscountValue],PatientAccount.[ServiceCount] ,PatientAccount.[Dariba] ,PatientAccount.[PriceBeforeDariba],PatientAccount.[EnterDiscount] ,PatientAccount.[EnterDiscountValue],PatientAccount.[wieght] FROM dbo.PatientAccount INNER JOIN dbo.Esal ON dbo.Esal.PatientAcountId = dbo.PatientAccount.ID where PatientAccount.DoctorID='" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "'  and PatientAccount.Bean<>'خدمة ثابتة' and dbo.Esal.Date Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "' group by PatientAccount.[ID] ,PatientAccount.[PatientId],PatientAccount.[DoctorID],PatientAccount.[Bean],PatientAccount.[Price],PatientAccount.[Pay] ,PatientAccount.[Date] ,PatientAccount.[PricePay] ,PatientAccount.[BeanDate],PatientAccount.[TeathId] ,PatientAccount.[Appears] ,PatientAccount.[VisitID] ,PatientAccount.[AppointNum],PatientAccount.[Assistant],PatientAccount.[StockId],PatientAccount.[RayId] ,PatientAccount.[AnalyzeId],PatientAccount.[DiscountValue],PatientAccount.[ServiceCount] ,PatientAccount.[Dariba] ,PatientAccount.[PriceBeforeDariba],PatientAccount.[EnterDiscount] ,PatientAccount.[EnterDiscountValue],PatientAccount.[wieght] order by PatientAccount.[Date]";
						sqlDataAdapter6.SelectCommand.CommandText = "SELECT  dbo.Esal.* FROM dbo.Esal where dbo.Esal.Date Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "' order by Esal.[Date]";
					}
					else
					{
						tableText2 = dc.GetTableText("select * from PatientAccount where DoctorID='" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "' and PatientAccount.Bean<>'خدمة ثابتة' and Date Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "' order by PatientAccount.[Date]");
						sqlDataAdapter1.SelectCommand.CommandText = "select * from PatientAccount where DoctorID='" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "' and PatientAccount.Bean<>'خدمة ثابتة' and Date Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "' order by PatientAccount.[Date]";
					}
					if (tableText2.Rows.Count > 0)
					{
						string value = date2.Value.Subtract(date1.Value).Days.ToString();
						DataTable tableText3 = dc.GetTableText("select Salary,isnull(Percentage,0) from Empdata where ID = " + doctorcomboBox.SelectedValue.ToString());
						int value2 = Convert.ToInt32(value) + 1;
						l1.Text = (Convert.ToDouble(tableText3.Rows[0][0].ToString()) / 30.0 * Convert.ToDouble(value2)).ToString();
						l2.Text = tableText3.Rows[0][1].ToString();
						DataTable tableText4 = dc.GetTableText("select isnull(sum(Price),0) from Appointments where DoctorID = '" + doctorcomboBox.SelectedValue.ToString() + "' and detectDate between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "'");
						l3.Text = tableText4.Rows[0][0].ToString();
						if (l2.Text == "")
						{
							l2.Text = "0.00";
						}
						string text = dc.GetTableText("select ServiceName from Properties ").Rows[0][0].ToString();
						DataTable dataTable = new DataTable();
						dataTable2 = new DataTable();
						if (checkBox1.Checked)
						{
							dataTable = dc.GetTableText("select isnull(sum(PatientAccount.Price),0) from PatientAccount INNER JOIN dbo.Esal ON dbo.Esal.PatientAcountId = dbo.PatientAccount.ID where PatientAccount.DoctorID = '" + doctorcomboBox.SelectedValue.ToString() + "' and PatientAccount.Bean<>'خدمة ثابتة'  and Esal.Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "'and PatientAccount.Bean != '" + text + "'");
							l5.Text = dataTable.Rows[0][0].ToString();
							dataTable2 = dc.GetTableText("SELECT      distinct  dbo.PatientData.PName, dbo.PatientAccount.BeanDate, dbo.PatientAccount.Bean, dbo.PatientData.company, dbo.PatientAccount.Price, dbo.PatientAccount.ID , PatientAccount.ServiceCount\r\nFROM            dbo.PatientData INNER JOIN\r\n                         dbo.PatientAccount ON dbo.PatientData.ID = dbo.PatientAccount.PatientId INNER JOIN\r\n                         dbo.Esal ON dbo.PatientAccount.ID = dbo.Esal.PatientAcountId where dbo.PatientAccount.DoctorID = '" + doctorcomboBox.SelectedValue.ToString() + "' and PatientAccount.Bean<>'خدمة ثابتة' and dbo.Esal.Date Between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "'");
						}
						else
						{
							dataTable = dc.GetTableText("select isnull(sum(Price),0) from PatientAccount where DoctorID = '" + doctorcomboBox.SelectedValue.ToString() + "' and PatientAccount.Bean<>'خدمة ثابتة'  and Date between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "'and Bean != '" + text + "'");
							l5.Text = dataTable.Rows[0][0].ToString();
							dataTable2 = dc.GetTableText("SELECT     dbo.PatientData.PName, dbo.PatientAccount.Date, dbo.PatientAccount.Bean,dbo.PatientData.company,dbo.PatientAccount.Price, PatientAccount.ID , PatientAccount.ServiceCount\r\nFROM         dbo.PatientData INNER JOIN\r\n                      dbo.PatientAccount ON dbo.PatientData.ID = dbo.PatientAccount.PatientId where dbo.PatientAccount.DoctorID = '" + doctorcomboBox.SelectedValue.ToString() + "' and PatientAccount.Bean<>'خدمة ثابتة' and dbo.PatientAccount.BeanDate Between '" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' order by PatientAccount.[Date]");
						}
						value3 = "0";
						tableText5 = dc.GetTableText("select EmpNesba,DocNesba from Properties ");
						if (Convert.ToBoolean(tableText5.Rows[0][1].ToString()))
						{
							sqlDataAdapter5.SelectCommand.CommandText = string.Concat("select dbo.NesbaDoctor.Price, dbo.NesbaDoctor.Cost, dbo.NesbaDoctor.Safy, dbo.NesbaDoctor.Nesba, dbo.NesbaDoctor.NesbaValue from NesbaDoctor where dbo.NesbaDoctor.DoctorID= '", doctorcomboBox.SelectedValue, "'");
							for (int i = 0; i < dataTable2.Rows.Count; i++)
							{
								DataTable tableText6 = dc.GetTableText(string.Concat("select dbo.NesbaDoctor.Price, dbo.NesbaDoctor.Cost, dbo.NesbaDoctor.Safy, dbo.NesbaDoctor.Nesba, dbo.NesbaDoctor.NesbaValue from NesbaDoctor where dbo.NesbaDoctor.Service='", dataTable2.Rows[i]["Bean"].ToString(), "' and dbo.NesbaDoctor.DoctorID= '", doctorcomboBox.SelectedValue, "' AND dbo.NesbaDoctor.Company = '", dataTable2.Rows[i]["company"].ToString(), "'"));
								if (tableText6.Rows.Count > 0)
								{
									double num = Math.Round((Convert.ToDouble(dataTable2.Rows[i][4]) - Convert.ToDouble(tableText6.Rows[0][1]) * Convert.ToDouble(dataTable2.Rows[i]["ServiceCount"])) * Convert.ToDouble(tableText6.Rows[0][3].ToString()) / 100.0, 2);
									value3 = (Convert.ToDouble(value3) + num).ToString();
									((DataTable)(object)dataSet11.DoctorServiceNesba).Rows.Add(Convert.ToDouble(tableText6.Rows[0][3].ToString()), Convert.ToInt32(dataTable2.Rows[i]["ID"].ToString()), Convert.ToDouble(tableText6.Rows[0][1].ToString()), num);
								}
								else
								{
									value3 = (Convert.ToDouble(value3) + 0.0).ToString();
									((DataTable)(object)dataSet11.DoctorServiceNesba).Rows.Add(0, Convert.ToInt32(dataTable2.Rows[i]["ID"].ToString()), 0, 0);
								}
							}
							goto IL_0cca;
						}
						if (Convert.ToBoolean(tableText5.Rows[0][0].ToString()))
						{
							for (int i = 0; i < dataTable2.Rows.Count; i++)
							{
								DataTable tableText7 = dc.GetTableText(string.Concat("select Percentage from Empdata where ID='", doctorcomboBox.SelectedValue, "'"));
								if (tableText7.Rows.Count > 0)
								{
									string text2 = tableText7.Rows[0][0].ToString();
									if (text2 == "")
									{
										text2 = "0";
									}
									value3 = (Convert.ToDouble(value3) + Convert.ToDouble(Convert.ToDouble(dataTable2.Rows[i][4].ToString()) * Convert.ToDouble(text2) / 100.0)).ToString();
								}
								else
								{
									MessageBox.Show("برجاء أدخال نسبة الطبيب في شاشة نسب الأطباء");
								}
							}
							goto IL_0cca;
						}
						MessageBox.Show("برجاء أختيار نوع نسبه الطبيب من الأعدادات");
					}
					else
					{
						crystalReportViewer1.ReportSource = null;
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("No Data");
						}
						else
						{
							MessageBox.Show("لا يوجد بيانات لهذا الطبيب");
						}
					}
				}
				else
				{
					crystalReportViewer1.ReportSource = null;
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Choose Doctor Name");
					}
					else
					{
						MessageBox.Show("من فضلك تأكد من اسم الطبيب");
					}
				}
				goto end_IL_0001;
				IL_0cca:
				value3 = (Convert.ToDouble(value3) + Convert.ToDouble(l1.Text)).ToString();
				if (Convert.ToBoolean(tableText5.Rows[0][1].ToString()))
				{
					for (int i = 0; i < dataTable2.Rows.Count; i++)
					{
						DataTable tableText6 = dc.GetTableText(string.Concat("select dbo.NesbaDoctor.Price, dbo.NesbaDoctor.Cost, dbo.NesbaDoctor.Safy, dbo.NesbaDoctor.Nesba, dbo.NesbaDoctor.NesbaValue from NesbaDoctor where dbo.NesbaDoctor.Service='", dataTable2.Rows[i]["Bean"].ToString(), "' and dbo.NesbaDoctor.DoctorID= '", doctorcomboBox.SelectedValue, "' AND dbo.NesbaDoctor.Company = '", dataTable2.Rows[i]["company"].ToString(), "'"));
						if (tableText6.Rows.Count > 0)
						{
							double num2 = Math.Round(Convert.ToDouble(dataTable2.Rows[i][4]) - Convert.ToDouble(tableText6.Rows[0][1]) * Convert.ToDouble(dataTable2.Rows[i]["ServiceCount"]), 2);
							((DataTable)(object)dataSet11.DoctorAcountByDate).Rows.Add(Convert.ToDecimal(l1.Text), l2.Text, l3.Text, l5.Text, Convert.ToDecimal(value3), num2, Convert.ToInt32(dataTable2.Rows[i]["ID"].ToString()));
						}
						else
						{
							((DataTable)(object)dataSet11.DoctorAcountByDate).Rows.Add(Convert.ToDecimal(l1.Text), l2.Text, l3.Text, l5.Text, Convert.ToDecimal(value3), Convert.ToDouble(dataTable2.Rows[i][4]), Convert.ToInt32(dataTable2.Rows[i]["ID"].ToString()));
						}
					}
				}
				else
				{
					((DataTable)(object)dataSet11.DoctorAcountByDate).Rows.Add(Convert.ToDecimal(l1.Text), l2.Text, l3.Text, l5.Text, Convert.ToDecimal(value3));
				}
				sqlDataAdapter1.Fill(dataSet11);
				sqlDataAdapter2.Fill(dataSet11);
				sqlDataAdapter3.Fill(dataSet11);
				sqlDataAdapter4.Fill(dataSet11);
				sqlDataAdapter5.Fill(dataSet11);
				sqlDataAdapter6.Fill(dataSet11);
				sqlDataAdapter7.Fill(dataSet11);
				((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value, date2.Value);
				if (checkBox1.Checked)
				{
					DataTable tableText8 = dc.GetTableText("SELECT  dbo.Esal.* FROM dbo.Esal where dbo.Esal.Date Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "' order by PatientAcountId");
					decimal num3 = 0m;
					string text3 = "";
					for (int j = 0; j < tableText8.Rows.Count; j++)
					{
						num3 = ((!(text3 != tableText8.Rows[j]["PatientAcountId"].ToString())) ? 0m : Convert.ToDecimal(tableText8.Rows[j][8].ToString()));
						((DataTable)(object)dataSet11.Esalat1).Rows.Add(0, "", num3, 0, tableText8.Rows[j][4].ToString(), tableText8.Rows[j][3].ToString(), tableText8.Rows[j][3].ToString(), tableText8.Rows[j][7].ToString(), tableText8.Rows[j][2].ToString());
						text3 = tableText8.Rows[j]["PatientAcountId"].ToString();
						tableText8.Rows[j][7].ToString();
					}
				}
				if (!DoctorService.Checked && !checkBox1.Checked)
				{
					DoctorAcountbyDateRpt doctorAcountbyDateRpt = new DoctorAcountbyDateRpt();
					doctorAcountbyDateRpt.SetDataSource(dataSet11);
					if (checkBox1.Checked)
					{
						doctorAcountbyDateRpt.SetParameterValue("CheCK", true);
					}
					else
					{
						doctorAcountbyDateRpt.SetParameterValue("CheCK", false);
					}
					crystalReportViewer1.ReportSource = doctorAcountbyDateRpt;
				}
				else if (Convert.ToBoolean(tableText5.Rows[0][1].ToString()))
				{
					if (checkBox1.Checked)
					{
						DoctorAcountServices3Rpt doctorAcountServices3Rpt = new DoctorAcountServices3Rpt();
						doctorAcountServices3Rpt.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = doctorAcountServices3Rpt;
					}
					else
					{
						DoctorAcountServices2Rpt doctorAcountServices2Rpt = new DoctorAcountServices2Rpt();
						doctorAcountServices2Rpt.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = doctorAcountServices2Rpt;
					}
				}
				else if (Convert.ToBoolean(tableText5.Rows[0][0].ToString()))
				{
					if (checkBox1.Checked)
					{
						DoctorAcountServicesRpt4 doctorAcountServicesRpt = new DoctorAcountServicesRpt4();
						doctorAcountServicesRpt.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = doctorAcountServicesRpt;
					}
					else
					{
						DoctorAcountServicesRpt doctorAcountServicesRpt2 = new DoctorAcountServicesRpt();
						doctorAcountServicesRpt2.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = doctorAcountServicesRpt2;
					}
				}
				end_IL_0001:;
			}
			catch
			{
			}
		}

		private void groupBox1_Enter(object sender, EventArgs e)
		{
		}

		private void FrmDoctorAcountByDate_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmDoctorAcountByDate));
			groupBox1 = new System.Windows.Forms.GroupBox();
			DoctorService = new System.Windows.Forms.CheckBox();
			checkBox1 = new System.Windows.Forms.CheckBox();
			l5 = new System.Windows.Forms.Label();
			l4 = new System.Windows.Forms.Label();
			l3 = new System.Windows.Forms.Label();
			l2 = new System.Windows.Forms.Label();
			l1 = new System.Windows.Forms.Label();
			date2 = new System.Windows.Forms.DateTimePicker();
			date1 = new System.Windows.Forms.DateTimePicker();
			ViewRptBtn = new System.Windows.Forms.Button();
			label3 = new System.Windows.Forms.Label();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlConnection3 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlConnection4 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter4 = new System.Data.SqlClient.SqlDataAdapter();
			dataSet11 = new DataSet1();
			sqlDataAdapter5 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection5 = new System.Data.SqlClient.SqlConnection();
			sqlCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter6 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand5 = new System.Data.SqlClient.SqlCommand();
			sqlConnection6 = new System.Data.SqlClient.SqlConnection();
			sqlCommand6 = new System.Data.SqlClient.SqlCommand();
			sqlCommand7 = new System.Data.SqlClient.SqlCommand();
			sqlCommand8 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter7 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand9 = new System.Data.SqlClient.SqlCommand();
			sqlConnection7 = new System.Data.SqlClient.SqlConnection();
			sqlCommand10 = new System.Data.SqlClient.SqlCommand();
			sqlCommand11 = new System.Data.SqlClient.SqlCommand();
			sqlCommand12 = new System.Data.SqlClient.SqlCommand();
			sqlConnection8 = new System.Data.SqlClient.SqlConnection();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(DoctorService);
			groupBox1.Controls.Add(checkBox1);
			groupBox1.Controls.Add(l5);
			groupBox1.Controls.Add(l4);
			groupBox1.Controls.Add(l3);
			groupBox1.Controls.Add(l2);
			groupBox1.Controls.Add(l1);
			groupBox1.Controls.Add(date2);
			groupBox1.Controls.Add(date1);
			groupBox1.Controls.Add(ViewRptBtn);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(doctorcomboBox);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(label1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			groupBox1.Enter += new System.EventHandler(groupBox1_Enter);
			DoctorService.AccessibleDescription = null;
			DoctorService.AccessibleName = null;
			resources.ApplyResources(DoctorService, "DoctorService");
			DoctorService.BackgroundImage = null;
			DoctorService.Name = "DoctorService";
			DoctorService.UseVisualStyleBackColor = true;
			checkBox1.AccessibleDescription = null;
			checkBox1.AccessibleName = null;
			resources.ApplyResources(checkBox1, "checkBox1");
			checkBox1.BackgroundImage = null;
			checkBox1.Name = "checkBox1";
			checkBox1.UseVisualStyleBackColor = true;
			l5.AccessibleDescription = null;
			l5.AccessibleName = null;
			resources.ApplyResources(l5, "l5");
			l5.Font = null;
			l5.Name = "l5";
			l4.AccessibleDescription = null;
			l4.AccessibleName = null;
			resources.ApplyResources(l4, "l4");
			l4.Font = null;
			l4.Name = "l4";
			l3.AccessibleDescription = null;
			l3.AccessibleName = null;
			resources.ApplyResources(l3, "l3");
			l3.Font = null;
			l3.Name = "l3";
			l2.AccessibleDescription = null;
			l2.AccessibleName = null;
			resources.ApplyResources(l2, "l2");
			l2.Font = null;
			l2.Name = "l2";
			l1.AccessibleDescription = null;
			l1.AccessibleName = null;
			resources.ApplyResources(l1, "l1");
			l1.Font = null;
			l1.Name = "l1";
			date2.AccessibleDescription = null;
			date2.AccessibleName = null;
			resources.ApplyResources(date2, "date2");
			date2.BackgroundImage = null;
			date2.CalendarFont = null;
			date2.Font = null;
			date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date2.Name = "date2";
			date1.AccessibleDescription = null;
			date1.AccessibleName = null;
			resources.ApplyResources(date1, "date1");
			date1.BackgroundImage = null;
			date1.CalendarFont = null;
			date1.Font = null;
			date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date1.Name = "date1";
			ViewRptBtn.AccessibleDescription = null;
			ViewRptBtn.AccessibleName = null;
			resources.ApplyResources(ViewRptBtn, "ViewRptBtn");
			ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
			ViewRptBtn.BackgroundImage = null;
			ViewRptBtn.Name = "ViewRptBtn";
			ViewRptBtn.UseVisualStyleBackColor = false;
			ViewRptBtn.Click += new System.EventHandler(ViewRptBtn_Click);
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			doctorcomboBox.AccessibleDescription = null;
			doctorcomboBox.AccessibleName = null;
			resources.ApplyResources(doctorcomboBox, "doctorcomboBox");
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.BackgroundImage = null;
			doctorcomboBox.Font = null;
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Name = "doctorcomboBox";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			sqlSelectCommand1.CommandText = "SELECT        PatientAccount.*\r\nFROM            PatientAccount";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = "INSERT INTO [PatientAccount] ([PatientId], [DoctorID], [Bean], [Price], [Pay], [Date], [PricePay]) VALUES (@PatientId, @DoctorID, @Bean, @Price, @Pay, @Date, @PricePay)";
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@PatientId", System.Data.SqlDbType.Int, 0, "PatientId"),
				new System.Data.SqlClient.SqlParameter("@DoctorID", System.Data.SqlDbType.Int, 0, "DoctorID"),
				new System.Data.SqlClient.SqlParameter("@Bean", System.Data.SqlDbType.NVarChar, 0, "Bean"),
				new System.Data.SqlClient.SqlParameter("@Price", System.Data.SqlDbType.Money, 0, "Price"),
				new System.Data.SqlClient.SqlParameter("@Pay", System.Data.SqlDbType.Bit, 0, "Pay"),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
				new System.Data.SqlClient.SqlParameter("@PricePay", System.Data.SqlDbType.Money, 0, "PricePay")
			});
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientAccount", new System.Data.Common.DataColumnMapping[8]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("PatientId", "PatientId"),
					new System.Data.Common.DataColumnMapping("DoctorID", "DoctorID"),
					new System.Data.Common.DataColumnMapping("Bean", "Bean"),
					new System.Data.Common.DataColumnMapping("Price", "Price"),
					new System.Data.Common.DataColumnMapping("Pay", "Pay"),
					new System.Data.Common.DataColumnMapping("Date", "Date"),
					new System.Data.Common.DataColumnMapping("PricePay", "PricePay")
				})
			});
			sqlSelectCommand2.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlSelectCommand2.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.CommandText = resources.GetString("sqlInsertCommand2.CommandText");
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[34]
			{
				new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
				new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
				new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
				new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
				new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
				new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
				new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
				new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
				new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
				new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
				new System.Data.SqlClient.SqlParameter("@pain", System.Data.SqlDbType.Bit, 0, "pain"),
				new System.Data.SqlClient.SqlParameter("@Caries", System.Data.SqlDbType.Bit, 0, "Caries"),
				new System.Data.SqlClient.SqlParameter("@RoutineVisit", System.Data.SqlDbType.Bit, 0, "RoutineVisit"),
				new System.Data.SqlClient.SqlParameter("@Swelling", System.Data.SqlDbType.Bit, 0, "Swelling"),
				new System.Data.SqlClient.SqlParameter("@Esthetics", System.Data.SqlDbType.Bit, 0, "Esthetics"),
				new System.Data.SqlClient.SqlParameter("@Others", System.Data.SqlDbType.NVarChar, 0, "Others"),
				new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
				new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
				new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
				new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
				new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
				new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
				new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
				new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
				new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
				new System.Data.SqlClient.SqlParameter("@DrugSensitivity", System.Data.SqlDbType.Bit, 0, "DrugSensitivity"),
				new System.Data.SqlClient.SqlParameter("@PulpTherapy", System.Data.SqlDbType.Bit, 0, "PulpTherapy"),
				new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
				new System.Data.SqlClient.SqlParameter("@FlourideTherapy", System.Data.SqlDbType.Bit, 0, "FlourideTherapy"),
				new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers")
			});
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[35]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("pain", "pain"),
					new System.Data.Common.DataColumnMapping("Caries", "Caries"),
					new System.Data.Common.DataColumnMapping("RoutineVisit", "RoutineVisit"),
					new System.Data.Common.DataColumnMapping("Swelling", "Swelling"),
					new System.Data.Common.DataColumnMapping("Esthetics", "Esthetics"),
					new System.Data.Common.DataColumnMapping("Others", "Others"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("DrugSensitivity", "DrugSensitivity"),
					new System.Data.Common.DataColumnMapping("PulpTherapy", "PulpTherapy"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("FlourideTherapy", "FlourideTherapy"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers")
				})
			});
			sqlSelectCommand3.CommandText = "SELECT        Empdata.*\r\nFROM            Empdata";
			sqlSelectCommand3.Connection = sqlConnection3;
			sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection3.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand3.CommandText = "INSERT INTO [Empdata] ([Designation], [Name], [Address], [Tel], [Mob], [Email], [Salary], [Percentage]) VALUES (@Designation, @Name, @Address, @Tel, @Mob, @Email, @Salary, @Percentage)";
			sqlInsertCommand3.Connection = sqlConnection3;
			sqlInsertCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[8]
			{
				new System.Data.SqlClient.SqlParameter("@Designation", System.Data.SqlDbType.NVarChar, 0, "Designation"),
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 0, "Address"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@Salary", System.Data.SqlDbType.Money, 0, "Salary"),
				new System.Data.SqlClient.SqlParameter("@Percentage", System.Data.SqlDbType.NVarChar, 0, "Percentage")
			});
			sqlDataAdapter3.InsertCommand = sqlInsertCommand3;
			sqlDataAdapter3.SelectCommand = sqlSelectCommand3;
			sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Empdata", new System.Data.Common.DataColumnMapping[9]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Designation", "Designation"),
					new System.Data.Common.DataColumnMapping("Name", "Name"),
					new System.Data.Common.DataColumnMapping("Address", "Address"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("Salary", "Salary"),
					new System.Data.Common.DataColumnMapping("Percentage", "Percentage")
				})
			});
			sqlSelectCommand4.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand4.Connection = sqlConnection4;
			sqlConnection4.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection4.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand4.CommandText = resources.GetString("sqlInsertCommand4.CommandText");
			sqlInsertCommand4.Connection = sqlConnection4;
			sqlInsertCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection4;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection4;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter4.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter4.InsertCommand = sqlInsertCommand4;
			sqlDataAdapter4.SelectCommand = sqlSelectCommand4;
			sqlDataAdapter4.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[8]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo")
				})
			});
			sqlDataAdapter4.UpdateCommand = sqlUpdateCommand1;
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlDataAdapter5.DeleteCommand = sqlCommand1;
			sqlDataAdapter5.InsertCommand = sqlCommand2;
			sqlDataAdapter5.SelectCommand = sqlCommand3;
			sqlDataAdapter5.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "NesbaDoctor", new System.Data.Common.DataColumnMapping[10]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Doctor", "Doctor"),
					new System.Data.Common.DataColumnMapping("Company", "Company"),
					new System.Data.Common.DataColumnMapping("Service", "Service"),
					new System.Data.Common.DataColumnMapping("Price", "Price"),
					new System.Data.Common.DataColumnMapping("Cost", "Cost"),
					new System.Data.Common.DataColumnMapping("Safy", "Safy"),
					new System.Data.Common.DataColumnMapping("Nesba", "Nesba"),
					new System.Data.Common.DataColumnMapping("NesbaValue", "NesbaValue"),
					new System.Data.Common.DataColumnMapping("DoctorID", "DoctorID")
				})
			});
			sqlDataAdapter5.UpdateCommand = sqlCommand4;
			sqlCommand1.CommandText = resources.GetString("sqlCommand1.CommandText");
			sqlCommand1.Connection = sqlConnection5;
			sqlCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[19]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Doctor", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Doctor", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Doctor", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Doctor", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Company", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Company", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Company", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Company", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Service", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Service", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Service", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Service", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Price", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Price", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Price", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Price", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Cost", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Cost", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Cost", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Cost", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Safy", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Safy", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Safy", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Safy", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Nesba", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Nesba", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Nesba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Nesba", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NesbaValue", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NesbaValue", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NesbaValue", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "NesbaValue", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorID", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection5.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection5.FireInfoMessageEventOnUserErrors = false;
			sqlCommand2.CommandText = resources.GetString("sqlCommand2.CommandText");
			sqlCommand2.Connection = sqlConnection5;
			sqlCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[9]
			{
				new System.Data.SqlClient.SqlParameter("@Doctor", System.Data.SqlDbType.NVarChar, 0, "Doctor"),
				new System.Data.SqlClient.SqlParameter("@Company", System.Data.SqlDbType.Int, 0, "Company"),
				new System.Data.SqlClient.SqlParameter("@Service", System.Data.SqlDbType.NVarChar, 0, "Service"),
				new System.Data.SqlClient.SqlParameter("@Price", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Price", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Cost", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Cost", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Safy", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Safy", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Nesba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Nesba", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@NesbaValue", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "NesbaValue", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@DoctorID", System.Data.SqlDbType.Int, 0, "DoctorID")
			});
			sqlCommand3.CommandText = "SELECT        NesbaDoctor.*\r\nFROM            NesbaDoctor";
			sqlCommand3.Connection = sqlConnection5;
			sqlCommand4.CommandText = resources.GetString("sqlCommand4.CommandText");
			sqlCommand4.Connection = sqlConnection5;
			sqlCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[29]
			{
				new System.Data.SqlClient.SqlParameter("@Doctor", System.Data.SqlDbType.NVarChar, 0, "Doctor"),
				new System.Data.SqlClient.SqlParameter("@Company", System.Data.SqlDbType.Int, 0, "Company"),
				new System.Data.SqlClient.SqlParameter("@Service", System.Data.SqlDbType.NVarChar, 0, "Service"),
				new System.Data.SqlClient.SqlParameter("@Price", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Price", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Cost", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Cost", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Safy", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Safy", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Nesba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Nesba", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@NesbaValue", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "NesbaValue", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@DoctorID", System.Data.SqlDbType.Int, 0, "DoctorID"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Doctor", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Doctor", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Doctor", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Doctor", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Company", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Company", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Company", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Company", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Service", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Service", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Service", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Service", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Price", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Price", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Price", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Price", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Cost", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Cost", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Cost", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Cost", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Safy", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Safy", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Safy", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Safy", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Nesba", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Nesba", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Nesba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Nesba", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NesbaValue", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NesbaValue", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NesbaValue", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "NesbaValue", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDataAdapter6.DeleteCommand = sqlCommand5;
			sqlDataAdapter6.InsertCommand = sqlCommand6;
			sqlDataAdapter6.SelectCommand = sqlCommand7;
			sqlDataAdapter6.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Esal", new System.Data.Common.DataColumnMapping[13]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("EsalNo", "EsalNo"),
					new System.Data.Common.DataColumnMapping("PatientAcountId", "PatientAcountId"),
					new System.Data.Common.DataColumnMapping("Date", "Date"),
					new System.Data.Common.DataColumnMapping("Pay", "Pay"),
					new System.Data.Common.DataColumnMapping("DetectId", "DetectId"),
					new System.Data.Common.DataColumnMapping("Patient", "Patient"),
					new System.Data.Common.DataColumnMapping("Bean", "Bean"),
					new System.Data.Common.DataColumnMapping("Price", "Price"),
					new System.Data.Common.DataColumnMapping("Teeth", "Teeth"),
					new System.Data.Common.DataColumnMapping("Company", "Company"),
					new System.Data.Common.DataColumnMapping("Username", "Username"),
					new System.Data.Common.DataColumnMapping("Assistant", "Assistant")
				})
			});
			sqlDataAdapter6.UpdateCommand = sqlCommand8;
			sqlCommand5.CommandText = resources.GetString("sqlCommand5.CommandText");
			sqlCommand5.Connection = sqlConnection6;
			sqlCommand5.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[23]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EsalNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EsalNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EsalNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EsalNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientAcountId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientAcountId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientAcountId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientAcountId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Date", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Date", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Date", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Date", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Pay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Pay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Pay", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Pay", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DetectId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DetectId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DetectId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DetectId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Patient", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Patient", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Patient", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Patient", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Price", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Price", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Price", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Price", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Teeth", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Teeth", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Teeth", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Teeth", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Company", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Company", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Company", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Company", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Username", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Username", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Username", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Username", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Assistant", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Assistant", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Assistant", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Assistant", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection6.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection6.FireInfoMessageEventOnUserErrors = false;
			sqlCommand6.CommandText = resources.GetString("sqlCommand6.CommandText");
			sqlCommand6.Connection = sqlConnection6;
			sqlCommand6.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[12]
			{
				new System.Data.SqlClient.SqlParameter("@EsalNo", System.Data.SqlDbType.Int, 0, "EsalNo"),
				new System.Data.SqlClient.SqlParameter("@PatientAcountId", System.Data.SqlDbType.Int, 0, "PatientAcountId"),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
				new System.Data.SqlClient.SqlParameter("@Pay", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Pay", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@DetectId", System.Data.SqlDbType.Int, 0, "DetectId"),
				new System.Data.SqlClient.SqlParameter("@Patient", System.Data.SqlDbType.NVarChar, 0, "Patient"),
				new System.Data.SqlClient.SqlParameter("@Bean", System.Data.SqlDbType.NVarChar, 0, "Bean"),
				new System.Data.SqlClient.SqlParameter("@Price", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Price", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Teeth", System.Data.SqlDbType.NVarChar, 0, "Teeth"),
				new System.Data.SqlClient.SqlParameter("@Company", System.Data.SqlDbType.NVarChar, 0, "Company"),
				new System.Data.SqlClient.SqlParameter("@Username", System.Data.SqlDbType.NVarChar, 0, "Username"),
				new System.Data.SqlClient.SqlParameter("@Assistant", System.Data.SqlDbType.NVarChar, 0, "Assistant")
			});
			sqlCommand7.CommandText = "SELECT        Esal.*\r\nFROM            Esal";
			sqlCommand7.Connection = sqlConnection6;
			sqlCommand8.CommandText = resources.GetString("sqlCommand8.CommandText");
			sqlCommand8.Connection = sqlConnection6;
			sqlCommand8.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[36]
			{
				new System.Data.SqlClient.SqlParameter("@EsalNo", System.Data.SqlDbType.Int, 0, "EsalNo"),
				new System.Data.SqlClient.SqlParameter("@PatientAcountId", System.Data.SqlDbType.Int, 0, "PatientAcountId"),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
				new System.Data.SqlClient.SqlParameter("@Pay", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Pay", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@DetectId", System.Data.SqlDbType.Int, 0, "DetectId"),
				new System.Data.SqlClient.SqlParameter("@Patient", System.Data.SqlDbType.NVarChar, 0, "Patient"),
				new System.Data.SqlClient.SqlParameter("@Bean", System.Data.SqlDbType.NVarChar, 0, "Bean"),
				new System.Data.SqlClient.SqlParameter("@Price", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Price", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Teeth", System.Data.SqlDbType.NVarChar, 0, "Teeth"),
				new System.Data.SqlClient.SqlParameter("@Company", System.Data.SqlDbType.NVarChar, 0, "Company"),
				new System.Data.SqlClient.SqlParameter("@Username", System.Data.SqlDbType.NVarChar, 0, "Username"),
				new System.Data.SqlClient.SqlParameter("@Assistant", System.Data.SqlDbType.NVarChar, 0, "Assistant"),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EsalNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EsalNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EsalNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EsalNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientAcountId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientAcountId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientAcountId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientAcountId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Date", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Date", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Date", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Date", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Pay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Pay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Pay", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Pay", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DetectId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DetectId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DetectId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DetectId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Patient", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Patient", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Patient", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Patient", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Price", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Price", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Price", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Price", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Teeth", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Teeth", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Teeth", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Teeth", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Company", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Company", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Company", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Company", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Username", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Username", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Username", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Username", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Assistant", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Assistant", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Assistant", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Assistant", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDataAdapter7.DeleteCommand = sqlCommand9;
			sqlDataAdapter7.InsertCommand = sqlCommand10;
			sqlDataAdapter7.SelectCommand = sqlCommand11;
			sqlDataAdapter7.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "users", new System.Data.Common.DataColumnMapping[139]
				{
					new System.Data.Common.DataColumnMapping("userId", "userId"),
					new System.Data.Common.DataColumnMapping("EmpID", "EmpID"),
					new System.Data.Common.DataColumnMapping("userName", "userName"),
					new System.Data.Common.DataColumnMapping("userPassward", "userPassward"),
					new System.Data.Common.DataColumnMapping("AddEmployee", "AddEmployee"),
					new System.Data.Common.DataColumnMapping("AddPatient", "AddPatient"),
					new System.Data.Common.DataColumnMapping("Appointment", "Appointment"),
					new System.Data.Common.DataColumnMapping("DoctorPatientList", "DoctorPatientList"),
					new System.Data.Common.DataColumnMapping("SecretaryPatientList", "SecretaryPatientList"),
					new System.Data.Common.DataColumnMapping("DentalData", "DentalData"),
					new System.Data.Common.DataColumnMapping("DoctorAccount", "DoctorAccount"),
					new System.Data.Common.DataColumnMapping("SearchPatient", "SearchPatient"),
					new System.Data.Common.DataColumnMapping("Company", "Company"),
					new System.Data.Common.DataColumnMapping("PatientPay", "PatientPay"),
					new System.Data.Common.DataColumnMapping("PatientAccount", "PatientAccount"),
					new System.Data.Common.DataColumnMapping("PatientXray", "PatientXray"),
					new System.Data.Common.DataColumnMapping("Permission", "Permission"),
					new System.Data.Common.DataColumnMapping("PatAccountRpt", "PatAccountRpt"),
					new System.Data.Common.DataColumnMapping("ALLPatAccountRpt", "ALLPatAccountRpt"),
					new System.Data.Common.DataColumnMapping("DoctorAccountRpt", "DoctorAccountRpt"),
					new System.Data.Common.DataColumnMapping("DoctorPaymentRpt", "DoctorPaymentRpt"),
					new System.Data.Common.DataColumnMapping("MovOfPatSTrpt", "MovOfPatSTrpt"),
					new System.Data.Common.DataColumnMapping("MovOfPatStbyDr", "MovOfPatStbyDr"),
					new System.Data.Common.DataColumnMapping("Expenses", "Expenses"),
					new System.Data.Common.DataColumnMapping("Revenues", "Revenues"),
					new System.Data.Common.DataColumnMapping("RptExpenses", "RptExpenses"),
					new System.Data.Common.DataColumnMapping("RptRevenues", "RptRevenues"),
					new System.Data.Common.DataColumnMapping("RptStockMove", "RptStockMove"),
					new System.Data.Common.DataColumnMapping("DoctorBackReserve", "DoctorBackReserve"),
					new System.Data.Common.DataColumnMapping("SecretaryBackReserve", "SecretaryBackReserve"),
					new System.Data.Common.DataColumnMapping("UpdateRebackdate", "UpdateRebackdate"),
					new System.Data.Common.DataColumnMapping("medicineFrmBtn", "medicineFrmBtn"),
					new System.Data.Common.DataColumnMapping("PrescriptionFrmBtn", "PrescriptionFrmBtn"),
					new System.Data.Common.DataColumnMapping("ItemsFrmBtn", "ItemsFrmBtn"),
					new System.Data.Common.DataColumnMapping("SupplierBtn", "SupplierBtn"),
					new System.Data.Common.DataColumnMapping("IncomingBillFrmBtn", "IncomingBillFrmBtn"),
					new System.Data.Common.DataColumnMapping("FrmSupplierAccountsBtn", "FrmSupplierAccountsBtn"),
					new System.Data.Common.DataColumnMapping("FormSupplier5Btn", "FormSupplier5Btn"),
					new System.Data.Common.DataColumnMapping("FrmBillIncomeRptBtn", "FrmBillIncomeRptBtn"),
					new System.Data.Common.DataColumnMapping("OldServicesRptFrmBtn", "OldServicesRptFrmBtn"),
					new System.Data.Common.DataColumnMapping("NetDailyClinicRptFrmBtn", "NetDailyClinicRptFrmBtn"),
					new System.Data.Common.DataColumnMapping("ClinicMonthGraphRptFrmBtn", "ClinicMonthGraphRptFrmBtn"),
					new System.Data.Common.DataColumnMapping("DailymeasureRotFrmBtn", "DailymeasureRotFrmBtn"),
					new System.Data.Common.DataColumnMapping("RptFrmSearchMedicine", "RptFrmSearchMedicine"),
					new System.Data.Common.DataColumnMapping("ServicePatientBtn", "ServicePatientBtn"),
					new System.Data.Common.DataColumnMapping("MainComplaintBtn", "MainComplaintBtn"),
					new System.Data.Common.DataColumnMapping("SahbItemsBtn", "SahbItemsBtn"),
					new System.Data.Common.DataColumnMapping("FrmRptSahbItemBtn", "FrmRptSahbItemBtn"),
					new System.Data.Common.DataColumnMapping("FrmRptBillByDateBtn", "FrmRptBillByDateBtn"),
					new System.Data.Common.DataColumnMapping("FrmFilePatientBtn", "FrmFilePatientBtn"),
					new System.Data.Common.DataColumnMapping("FrmPropertiesBtn", "FrmPropertiesBtn"),
					new System.Data.Common.DataColumnMapping("ChangeServicePrice", "ChangeServicePrice"),
					new System.Data.Common.DataColumnMapping("btnBackup_Restore", "btnBackup_Restore"),
					new System.Data.Common.DataColumnMapping("Surgery", "Surgery"),
					new System.Data.Common.DataColumnMapping("BookingVisits", "BookingVisits"),
					new System.Data.Common.DataColumnMapping("RptVisits", "RptVisits"),
					new System.Data.Common.DataColumnMapping("SecretaryVisits", "SecretaryVisits"),
					new System.Data.Common.DataColumnMapping("DoctorVisits", "DoctorVisits"),
					new System.Data.Common.DataColumnMapping("PatientSurgery", "PatientSurgery"),
					new System.Data.Common.DataColumnMapping("BtnFrmRptReb7ya", "BtnFrmRptReb7ya"),
					new System.Data.Common.DataColumnMapping("BtnFrmRptCompanies_Services", "BtnFrmRptCompanies_Services"),
					new System.Data.Common.DataColumnMapping("BtnFrmSell", "BtnFrmSell"),
					new System.Data.Common.DataColumnMapping("FrmRptSellByDateBtn", "FrmRptSellByDateBtn"),
					new System.Data.Common.DataColumnMapping("PatientAccountUpdateBtn", "PatientAccountUpdateBtn"),
					new System.Data.Common.DataColumnMapping("PatientServiceUpdateBtn", "PatientServiceUpdateBtn"),
					new System.Data.Common.DataColumnMapping("FrmInventoryRptBtn", "FrmInventoryRptBtn"),
					new System.Data.Common.DataColumnMapping("FrmLimitOrderRptBtn", "FrmLimitOrderRptBtn"),
					new System.Data.Common.DataColumnMapping("FrmInoculationBtn", "FrmInoculationBtn"),
					new System.Data.Common.DataColumnMapping("FrmPatientInoculationBtn", "FrmPatientInoculationBtn"),
					new System.Data.Common.DataColumnMapping("FrmAssistantRptBtn", "FrmAssistantRptBtn"),
					new System.Data.Common.DataColumnMapping("FrmRptPatientDebtBtn", "FrmRptPatientDebtBtn"),
					new System.Data.Common.DataColumnMapping("doctorAcountBtn", "doctorAcountBtn"),
					new System.Data.Common.DataColumnMapping("FrmBillBtn", "FrmBillBtn"),
					new System.Data.Common.DataColumnMapping("FrmVisitMedicalRepBtn", "FrmVisitMedicalRepBtn"),
					new System.Data.Common.DataColumnMapping("AppointmentspBtn", "AppointmentspBtn"),
					new System.Data.Common.DataColumnMapping("FrmRptSurgeryBtn", "FrmRptSurgeryBtn"),
					new System.Data.Common.DataColumnMapping("FrmRptSpecialBtn", "FrmRptSpecialBtn"),
					new System.Data.Common.DataColumnMapping("CompanyPayBtn", "CompanyPayBtn"),
					new System.Data.Common.DataColumnMapping("FrmRptCompanyAcountBtn", "FrmRptCompanyAcountBtn"),
					new System.Data.Common.DataColumnMapping("AssistantAccountBtn", "AssistantAccountBtn"),
					new System.Data.Common.DataColumnMapping("AssistantAcountDate", "AssistantAcountDate"),
					new System.Data.Common.DataColumnMapping("RptAssistantPaymentBtn", "RptAssistantPaymentBtn"),
					new System.Data.Common.DataColumnMapping("RptLoginUserBtn", "RptLoginUserBtn"),
					new System.Data.Common.DataColumnMapping("StockFrmBtn", "StockFrmBtn"),
					new System.Data.Common.DataColumnMapping("StockUsersFrmBtn", "StockUsersFrmBtn"),
					new System.Data.Common.DataColumnMapping("FrmTarnsbetweenStockBtn", "FrmTarnsbetweenStockBtn"),
					new System.Data.Common.DataColumnMapping("StockTransRptFrmBtn", "StockTransRptFrmBtn"),
					new System.Data.Common.DataColumnMapping("FrmDeanSupplierBtn", "FrmDeanSupplierBtn"),
					new System.Data.Common.DataColumnMapping("updateSurgery", "updateSurgery"),
					new System.Data.Common.DataColumnMapping("ReserveServiceRptFrmBtn", "ReserveServiceRptFrmBtn"),
					new System.Data.Common.DataColumnMapping("FrmEsalBtn", "FrmEsalBtn"),
					new System.Data.Common.DataColumnMapping("FrmAnalyzesBtn", "FrmAnalyzesBtn"),
					new System.Data.Common.DataColumnMapping("FrmRptRayAnalyzeBtn", "FrmRptRayAnalyzeBtn"),
					new System.Data.Common.DataColumnMapping("FrmChat", "FrmChat"),
					new System.Data.Common.DataColumnMapping("FrmBeforeAndAfterBtn", "FrmBeforeAndAfterBtn"),
					new System.Data.Common.DataColumnMapping("DiscountPointsBtn", "DiscountPointsBtn"),
					new System.Data.Common.DataColumnMapping("PatientPointRptBtn", "PatientPointRptBtn"),
					new System.Data.Common.DataColumnMapping("RptKnowFromBtn", "RptKnowFromBtn"),
					new System.Data.Common.DataColumnMapping("RptPatientDetails", "RptPatientDetails"),
					new System.Data.Common.DataColumnMapping("ItemsMoveRpt", "ItemsMoveRpt"),
					new System.Data.Common.DataColumnMapping("ExpectedBirthDate", "ExpectedBirthDate"),
					new System.Data.Common.DataColumnMapping("ShowAppointments", "ShowAppointments"),
					new System.Data.Common.DataColumnMapping("Notes", "Notes"),
					new System.Data.Common.DataColumnMapping("Comments", "Comments"),
					new System.Data.Common.DataColumnMapping("OldServiceProvided", "OldServiceProvided"),
					new System.Data.Common.DataColumnMapping("UpdatePackDate", "UpdatePackDate"),
					new System.Data.Common.DataColumnMapping("SarfFreeSample", "SarfFreeSample"),
					new System.Data.Common.DataColumnMapping("AddPoints", "AddPoints"),
					new System.Data.Common.DataColumnMapping("FollowUpKids", "FollowUpKids"),
					new System.Data.Common.DataColumnMapping("EmailCnfgs", "EmailCnfgs"),
					new System.Data.Common.DataColumnMapping("RptEmails", "RptEmails"),
					new System.Data.Common.DataColumnMapping("RptEmailConfig", "RptEmailConfig"),
					new System.Data.Common.DataColumnMapping("NesbaDoctor", "NesbaDoctor"),
					new System.Data.Common.DataColumnMapping("PrintCard", "PrintCard"),
					new System.Data.Common.DataColumnMapping("SurgeryDate", "SurgeryDate"),
					new System.Data.Common.DataColumnMapping("SurgeryDateRpt", "SurgeryDateRpt"),
					new System.Data.Common.DataColumnMapping("EmpWorkData", "EmpWorkData"),
					new System.Data.Common.DataColumnMapping("RaysAnalysis", "RaysAnalysis"),
					new System.Data.Common.DataColumnMapping("MedicalReport", "MedicalReport"),
					new System.Data.Common.DataColumnMapping("BarcodePrint", "BarcodePrint"),
					new System.Data.Common.DataColumnMapping("CompanyServices", "CompanyServices"),
					new System.Data.Common.DataColumnMapping("DeletePatientPay", "DeletePatientPay"),
					new System.Data.Common.DataColumnMapping("RPTPatientNotice", "RPTPatientNotice"),
					new System.Data.Common.DataColumnMapping("PatientNotice", "PatientNotice"),
					new System.Data.Common.DataColumnMapping("Pediatric", "Pediatric"),
					new System.Data.Common.DataColumnMapping("Orthopedical", "Orthopedical"),
					new System.Data.Common.DataColumnMapping("Neurological", "Neurological"),
					new System.Data.Common.DataColumnMapping("NaturalTherapy", "NaturalTherapy"),
					new System.Data.Common.DataColumnMapping("DiscountSecretary", "DiscountSecretary"),
					new System.Data.Common.DataColumnMapping("DiscountPatientAcc", "DiscountPatientAcc"),
					new System.Data.Common.DataColumnMapping("ShowPrice", "ShowPrice"),
					new System.Data.Common.DataColumnMapping("ReAccountDoctor", "ReAccountDoctor"),
					new System.Data.Common.DataColumnMapping("ReAccountPatient", "ReAccountPatient"),
					new System.Data.Common.DataColumnMapping("DataBaseChange", "DataBaseChange"),
					new System.Data.Common.DataColumnMapping("SMSSetting", "SMSSetting"),
					new System.Data.Common.DataColumnMapping("PhoneNum", "PhoneNum"),
					new System.Data.Common.DataColumnMapping("SendSMS", "SendSMS"),
					new System.Data.Common.DataColumnMapping("SendReportSetting", "SendReportSetting"),
					new System.Data.Common.DataColumnMapping("DeleteUpdateApp", "DeleteUpdateApp")
				})
			});
			sqlDataAdapter7.UpdateCommand = sqlCommand12;
			sqlCommand9.CommandText = resources.GetString("sqlCommand9.CommandText");
			sqlCommand9.Connection = sqlConnection7;
			sqlCommand9.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[277]
			{
				new System.Data.SqlClient.SqlParameter("@Original_userId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EmpID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EmpID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EmpID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EmpID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_userName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "userName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_userName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_userPassward", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "userPassward", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_userPassward", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userPassward", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AddEmployee", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AddEmployee", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AddEmployee", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AddEmployee", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AddPatient", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AddPatient", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AddPatient", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AddPatient", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Appointment", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Appointment", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Appointment", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Appointment", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorPatientList", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorPatientList", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorPatientList", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorPatientList", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SecretaryPatientList", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SecretaryPatientList", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SecretaryPatientList", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SecretaryPatientList", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalData", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalData", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalData", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalData", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorAccount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorAccount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorAccount", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorAccount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SearchPatient", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SearchPatient", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SearchPatient", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SearchPatient", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Company", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Company", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Company", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Company", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientPay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientPay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientPay", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientPay", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientAccount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientAccount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientAccount", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientAccount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientXray", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientXray", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientXray", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientXray", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Permission", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Permission", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Permission", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Permission", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatAccountRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatAccountRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatAccountRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatAccountRpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ALLPatAccountRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ALLPatAccountRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ALLPatAccountRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ALLPatAccountRpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorAccountRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorAccountRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorAccountRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorAccountRpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorPaymentRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorPaymentRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorPaymentRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorPaymentRpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_MovOfPatSTrpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MovOfPatSTrpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_MovOfPatSTrpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MovOfPatSTrpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_MovOfPatStbyDr", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MovOfPatStbyDr", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_MovOfPatStbyDr", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MovOfPatStbyDr", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Expenses", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Expenses", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Expenses", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Expenses", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Revenues", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Revenues", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Revenues", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Revenues", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptExpenses", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptExpenses", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptExpenses", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptExpenses", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptRevenues", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptRevenues", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptRevenues", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptRevenues", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptStockMove", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptStockMove", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptStockMove", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptStockMove", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorBackReserve", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorBackReserve", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorBackReserve", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorBackReserve", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SecretaryBackReserve", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SecretaryBackReserve", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SecretaryBackReserve", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SecretaryBackReserve", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_UpdateRebackdate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "UpdateRebackdate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_UpdateRebackdate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "UpdateRebackdate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_medicineFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "medicineFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_medicineFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "medicineFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PrescriptionFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PrescriptionFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PrescriptionFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PrescriptionFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ItemsFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemsFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ItemsFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemsFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupplierBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_IncomingBillFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "IncomingBillFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_IncomingBillFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "IncomingBillFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmSupplierAccountsBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmSupplierAccountsBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmSupplierAccountsBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmSupplierAccountsBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FormSupplier5Btn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FormSupplier5Btn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FormSupplier5Btn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FormSupplier5Btn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmBillIncomeRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmBillIncomeRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmBillIncomeRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmBillIncomeRptBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_OldServicesRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "OldServicesRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_OldServicesRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "OldServicesRptFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NetDailyClinicRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NetDailyClinicRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NetDailyClinicRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NetDailyClinicRptFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicMonthGraphRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicMonthGraphRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicMonthGraphRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicMonthGraphRptFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DailymeasureRotFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DailymeasureRotFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DailymeasureRotFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DailymeasureRotFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptFrmSearchMedicine", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptFrmSearchMedicine", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptFrmSearchMedicine", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptFrmSearchMedicine", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ServicePatientBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ServicePatientBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ServicePatientBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ServicePatientBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_MainComplaintBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MainComplaintBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_MainComplaintBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MainComplaintBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SahbItemsBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SahbItemsBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SahbItemsBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SahbItemsBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSahbItemBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSahbItemBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptSahbItemBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSahbItemBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptBillByDateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptBillByDateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptBillByDateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptBillByDateBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmFilePatientBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmFilePatientBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmFilePatientBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmFilePatientBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmPropertiesBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmPropertiesBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmPropertiesBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmPropertiesBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ChangeServicePrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ChangeServicePrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ChangeServicePrice", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ChangeServicePrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_btnBackup_Restore", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "btnBackup_Restore", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_btnBackup_Restore", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "btnBackup_Restore", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Surgery", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Surgery", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Surgery", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Surgery", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BookingVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BookingVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BookingVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BookingVisits", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptVisits", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SecretaryVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SecretaryVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SecretaryVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SecretaryVisits", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorVisits", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientSurgery", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientSurgery", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientSurgery", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientSurgery", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BtnFrmRptReb7ya", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BtnFrmRptReb7ya", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BtnFrmRptReb7ya", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BtnFrmRptReb7ya", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BtnFrmRptCompanies_Services", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BtnFrmRptCompanies_Services", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BtnFrmRptCompanies_Services", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BtnFrmRptCompanies_Services", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BtnFrmSell", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BtnFrmSell", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BtnFrmSell", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BtnFrmSell", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSellByDateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSellByDateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptSellByDateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSellByDateBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientAccountUpdateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientAccountUpdateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientAccountUpdateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientAccountUpdateBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientServiceUpdateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientServiceUpdateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientServiceUpdateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientServiceUpdateBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmInventoryRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmInventoryRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmInventoryRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmInventoryRptBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmLimitOrderRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmLimitOrderRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmLimitOrderRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmLimitOrderRptBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmInoculationBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmInoculationBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmInoculationBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmInoculationBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmPatientInoculationBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmPatientInoculationBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmPatientInoculationBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmPatientInoculationBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmAssistantRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmAssistantRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmAssistantRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmAssistantRptBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptPatientDebtBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptPatientDebtBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptPatientDebtBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptPatientDebtBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_doctorAcountBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "doctorAcountBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_doctorAcountBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "doctorAcountBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmBillBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmBillBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmBillBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmBillBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmVisitMedicalRepBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmVisitMedicalRepBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmVisitMedicalRepBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmVisitMedicalRepBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AppointmentspBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AppointmentspBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AppointmentspBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AppointmentspBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSurgeryBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSurgeryBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptSurgeryBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSurgeryBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSpecialBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSpecialBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptSpecialBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSpecialBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_CompanyPayBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "CompanyPayBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_CompanyPayBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "CompanyPayBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptCompanyAcountBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptCompanyAcountBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptCompanyAcountBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptCompanyAcountBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AssistantAccountBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AssistantAccountBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AssistantAccountBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AssistantAccountBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AssistantAcountDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AssistantAcountDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AssistantAcountDate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AssistantAcountDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptAssistantPaymentBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptAssistantPaymentBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptAssistantPaymentBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptAssistantPaymentBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptLoginUserBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptLoginUserBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptLoginUserBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptLoginUserBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_StockFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "StockFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_StockFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "StockFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_StockUsersFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "StockUsersFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_StockUsersFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "StockUsersFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmTarnsbetweenStockBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmTarnsbetweenStockBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmTarnsbetweenStockBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmTarnsbetweenStockBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_StockTransRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "StockTransRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_StockTransRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "StockTransRptFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmDeanSupplierBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmDeanSupplierBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmDeanSupplierBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmDeanSupplierBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_updateSurgery", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "updateSurgery", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_updateSurgery", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "updateSurgery", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ReserveServiceRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ReserveServiceRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ReserveServiceRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ReserveServiceRptFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmEsalBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmEsalBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmEsalBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmEsalBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmAnalyzesBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmAnalyzesBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmAnalyzesBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmAnalyzesBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptRayAnalyzeBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptRayAnalyzeBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptRayAnalyzeBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptRayAnalyzeBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmChat", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmChat", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmChat", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmChat", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmBeforeAndAfterBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmBeforeAndAfterBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmBeforeAndAfterBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmBeforeAndAfterBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountPointsBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountPointsBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountPointsBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountPointsBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientPointRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientPointRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientPointRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientPointRptBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptKnowFromBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptKnowFromBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptKnowFromBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptKnowFromBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptPatientDetails", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptPatientDetails", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptPatientDetails", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptPatientDetails", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ItemsMoveRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemsMoveRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ItemsMoveRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemsMoveRpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ExpectedBirthDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ExpectedBirthDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ExpectedBirthDate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ExpectedBirthDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ShowAppointments", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ShowAppointments", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ShowAppointments", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ShowAppointments", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Notes", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Notes", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Notes", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Notes", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Comments", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Comments", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Comments", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Comments", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_OldServiceProvided", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "OldServiceProvided", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_OldServiceProvided", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "OldServiceProvided", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_UpdatePackDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "UpdatePackDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_UpdatePackDate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "UpdatePackDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SarfFreeSample", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SarfFreeSample", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SarfFreeSample", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SarfFreeSample", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AddPoints", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AddPoints", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AddPoints", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AddPoints", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FollowUpKids", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FollowUpKids", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FollowUpKids", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FollowUpKids", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EmailCnfgs", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EmailCnfgs", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EmailCnfgs", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EmailCnfgs", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptEmails", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptEmails", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptEmails", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptEmails", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptEmailConfig", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptEmailConfig", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptEmailConfig", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptEmailConfig", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NesbaDoctor", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NesbaDoctor", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NesbaDoctor", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NesbaDoctor", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PrintCard", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PrintCard", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PrintCard", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PrintCard", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SurgeryDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SurgeryDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SurgeryDate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SurgeryDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SurgeryDateRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SurgeryDateRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SurgeryDateRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SurgeryDateRpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EmpWorkData", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EmpWorkData", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EmpWorkData", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EmpWorkData", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RaysAnalysis", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RaysAnalysis", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RaysAnalysis", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RaysAnalysis", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_MedicalReport", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MedicalReport", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_MedicalReport", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MedicalReport", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BarcodePrint", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BarcodePrint", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BarcodePrint", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BarcodePrint", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_CompanyServices", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "CompanyServices", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_CompanyServices", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "CompanyServices", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DeletePatientPay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DeletePatientPay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DeletePatientPay", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DeletePatientPay", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RPTPatientNotice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RPTPatientNotice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RPTPatientNotice", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RPTPatientNotice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientNotice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientNotice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientNotice", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientNotice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Pediatric", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Pediatric", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Pediatric", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Pediatric", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Orthopedical", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Orthopedical", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Orthopedical", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Orthopedical", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Neurological", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Neurological", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Neurological", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Neurological", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalTherapy", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalTherapy", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalTherapy", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalTherapy", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountSecretary", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountSecretary", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountSecretary", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountSecretary", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountPatientAcc", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountPatientAcc", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountPatientAcc", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountPatientAcc", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ShowPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ShowPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ShowPrice", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ShowPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ReAccountDoctor", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ReAccountDoctor", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ReAccountDoctor", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ReAccountDoctor", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ReAccountPatient", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ReAccountPatient", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ReAccountPatient", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ReAccountPatient", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DataBaseChange", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DataBaseChange", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DataBaseChange", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DataBaseChange", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SMSSetting", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SMSSetting", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SMSSetting", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SMSSetting", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PhoneNum", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PhoneNum", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PhoneNum", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PhoneNum", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SendSMS", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SendSMS", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SendSMS", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SendSMS", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SendReportSetting", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SendReportSetting", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SendReportSetting", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SendReportSetting", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DeleteUpdateApp", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DeleteUpdateApp", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DeleteUpdateApp", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DeleteUpdateApp", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection7.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection7.FireInfoMessageEventOnUserErrors = false;
			sqlCommand10.CommandText = resources.GetString("sqlCommand10.CommandText");
			sqlCommand10.Connection = sqlConnection7;
			sqlCommand10.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[138]
			{
				new System.Data.SqlClient.SqlParameter("@EmpID", System.Data.SqlDbType.Int, 0, "EmpID"),
				new System.Data.SqlClient.SqlParameter("@userName", System.Data.SqlDbType.NVarChar, 0, "userName"),
				new System.Data.SqlClient.SqlParameter("@userPassward", System.Data.SqlDbType.NVarChar, 0, "userPassward"),
				new System.Data.SqlClient.SqlParameter("@AddEmployee", System.Data.SqlDbType.Bit, 0, "AddEmployee"),
				new System.Data.SqlClient.SqlParameter("@AddPatient", System.Data.SqlDbType.Bit, 0, "AddPatient"),
				new System.Data.SqlClient.SqlParameter("@Appointment", System.Data.SqlDbType.Bit, 0, "Appointment"),
				new System.Data.SqlClient.SqlParameter("@DoctorPatientList", System.Data.SqlDbType.Bit, 0, "DoctorPatientList"),
				new System.Data.SqlClient.SqlParameter("@SecretaryPatientList", System.Data.SqlDbType.Bit, 0, "SecretaryPatientList"),
				new System.Data.SqlClient.SqlParameter("@DentalData", System.Data.SqlDbType.Bit, 0, "DentalData"),
				new System.Data.SqlClient.SqlParameter("@DoctorAccount", System.Data.SqlDbType.Bit, 0, "DoctorAccount"),
				new System.Data.SqlClient.SqlParameter("@SearchPatient", System.Data.SqlDbType.Bit, 0, "SearchPatient"),
				new System.Data.SqlClient.SqlParameter("@Company", System.Data.SqlDbType.Bit, 0, "Company"),
				new System.Data.SqlClient.SqlParameter("@PatientPay", System.Data.SqlDbType.Bit, 0, "PatientPay"),
				new System.Data.SqlClient.SqlParameter("@PatientAccount", System.Data.SqlDbType.Bit, 0, "PatientAccount"),
				new System.Data.SqlClient.SqlParameter("@PatientXray", System.Data.SqlDbType.Bit, 0, "PatientXray"),
				new System.Data.SqlClient.SqlParameter("@Permission", System.Data.SqlDbType.Bit, 0, "Permission"),
				new System.Data.SqlClient.SqlParameter("@PatAccountRpt", System.Data.SqlDbType.Bit, 0, "PatAccountRpt"),
				new System.Data.SqlClient.SqlParameter("@ALLPatAccountRpt", System.Data.SqlDbType.Bit, 0, "ALLPatAccountRpt"),
				new System.Data.SqlClient.SqlParameter("@DoctorAccountRpt", System.Data.SqlDbType.Bit, 0, "DoctorAccountRpt"),
				new System.Data.SqlClient.SqlParameter("@DoctorPaymentRpt", System.Data.SqlDbType.Bit, 0, "DoctorPaymentRpt"),
				new System.Data.SqlClient.SqlParameter("@MovOfPatSTrpt", System.Data.SqlDbType.Bit, 0, "MovOfPatSTrpt"),
				new System.Data.SqlClient.SqlParameter("@MovOfPatStbyDr", System.Data.SqlDbType.Bit, 0, "MovOfPatStbyDr"),
				new System.Data.SqlClient.SqlParameter("@Expenses", System.Data.SqlDbType.Bit, 0, "Expenses"),
				new System.Data.SqlClient.SqlParameter("@Revenues", System.Data.SqlDbType.Bit, 0, "Revenues"),
				new System.Data.SqlClient.SqlParameter("@RptExpenses", System.Data.SqlDbType.Bit, 0, "RptExpenses"),
				new System.Data.SqlClient.SqlParameter("@RptRevenues", System.Data.SqlDbType.Bit, 0, "RptRevenues"),
				new System.Data.SqlClient.SqlParameter("@RptStockMove", System.Data.SqlDbType.Bit, 0, "RptStockMove"),
				new System.Data.SqlClient.SqlParameter("@DoctorBackReserve", System.Data.SqlDbType.Bit, 0, "DoctorBackReserve"),
				new System.Data.SqlClient.SqlParameter("@SecretaryBackReserve", System.Data.SqlDbType.Bit, 0, "SecretaryBackReserve"),
				new System.Data.SqlClient.SqlParameter("@UpdateRebackdate", System.Data.SqlDbType.Bit, 0, "UpdateRebackdate"),
				new System.Data.SqlClient.SqlParameter("@medicineFrmBtn", System.Data.SqlDbType.Bit, 0, "medicineFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@PrescriptionFrmBtn", System.Data.SqlDbType.Bit, 0, "PrescriptionFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@ItemsFrmBtn", System.Data.SqlDbType.Bit, 0, "ItemsFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@SupplierBtn", System.Data.SqlDbType.Bit, 0, "SupplierBtn"),
				new System.Data.SqlClient.SqlParameter("@IncomingBillFrmBtn", System.Data.SqlDbType.Bit, 0, "IncomingBillFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmSupplierAccountsBtn", System.Data.SqlDbType.Bit, 0, "FrmSupplierAccountsBtn"),
				new System.Data.SqlClient.SqlParameter("@FormSupplier5Btn", System.Data.SqlDbType.Bit, 0, "FormSupplier5Btn"),
				new System.Data.SqlClient.SqlParameter("@FrmBillIncomeRptBtn", System.Data.SqlDbType.Bit, 0, "FrmBillIncomeRptBtn"),
				new System.Data.SqlClient.SqlParameter("@OldServicesRptFrmBtn", System.Data.SqlDbType.Bit, 0, "OldServicesRptFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@NetDailyClinicRptFrmBtn", System.Data.SqlDbType.Bit, 0, "NetDailyClinicRptFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@ClinicMonthGraphRptFrmBtn", System.Data.SqlDbType.Bit, 0, "ClinicMonthGraphRptFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@DailymeasureRotFrmBtn", System.Data.SqlDbType.Bit, 0, "DailymeasureRotFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@RptFrmSearchMedicine", System.Data.SqlDbType.Bit, 0, "RptFrmSearchMedicine"),
				new System.Data.SqlClient.SqlParameter("@ServicePatientBtn", System.Data.SqlDbType.Bit, 0, "ServicePatientBtn"),
				new System.Data.SqlClient.SqlParameter("@MainComplaintBtn", System.Data.SqlDbType.Bit, 0, "MainComplaintBtn"),
				new System.Data.SqlClient.SqlParameter("@SahbItemsBtn", System.Data.SqlDbType.Bit, 0, "SahbItemsBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptSahbItemBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSahbItemBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptBillByDateBtn", System.Data.SqlDbType.Bit, 0, "FrmRptBillByDateBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmFilePatientBtn", System.Data.SqlDbType.Bit, 0, "FrmFilePatientBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmPropertiesBtn", System.Data.SqlDbType.Bit, 0, "FrmPropertiesBtn"),
				new System.Data.SqlClient.SqlParameter("@ChangeServicePrice", System.Data.SqlDbType.Bit, 0, "ChangeServicePrice"),
				new System.Data.SqlClient.SqlParameter("@btnBackup_Restore", System.Data.SqlDbType.Bit, 0, "btnBackup_Restore"),
				new System.Data.SqlClient.SqlParameter("@Surgery", System.Data.SqlDbType.Bit, 0, "Surgery"),
				new System.Data.SqlClient.SqlParameter("@BookingVisits", System.Data.SqlDbType.Bit, 0, "BookingVisits"),
				new System.Data.SqlClient.SqlParameter("@RptVisits", System.Data.SqlDbType.Bit, 0, "RptVisits"),
				new System.Data.SqlClient.SqlParameter("@SecretaryVisits", System.Data.SqlDbType.Bit, 0, "SecretaryVisits"),
				new System.Data.SqlClient.SqlParameter("@DoctorVisits", System.Data.SqlDbType.Bit, 0, "DoctorVisits"),
				new System.Data.SqlClient.SqlParameter("@PatientSurgery", System.Data.SqlDbType.Bit, 0, "PatientSurgery"),
				new System.Data.SqlClient.SqlParameter("@BtnFrmRptReb7ya", System.Data.SqlDbType.Bit, 0, "BtnFrmRptReb7ya"),
				new System.Data.SqlClient.SqlParameter("@BtnFrmRptCompanies_Services", System.Data.SqlDbType.Bit, 0, "BtnFrmRptCompanies_Services"),
				new System.Data.SqlClient.SqlParameter("@BtnFrmSell", System.Data.SqlDbType.Bit, 0, "BtnFrmSell"),
				new System.Data.SqlClient.SqlParameter("@FrmRptSellByDateBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSellByDateBtn"),
				new System.Data.SqlClient.SqlParameter("@PatientAccountUpdateBtn", System.Data.SqlDbType.Bit, 0, "PatientAccountUpdateBtn"),
				new System.Data.SqlClient.SqlParameter("@PatientServiceUpdateBtn", System.Data.SqlDbType.Bit, 0, "PatientServiceUpdateBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmInventoryRptBtn", System.Data.SqlDbType.Bit, 0, "FrmInventoryRptBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmLimitOrderRptBtn", System.Data.SqlDbType.Bit, 0, "FrmLimitOrderRptBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmInoculationBtn", System.Data.SqlDbType.Bit, 0, "FrmInoculationBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmPatientInoculationBtn", System.Data.SqlDbType.Bit, 0, "FrmPatientInoculationBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmAssistantRptBtn", System.Data.SqlDbType.Bit, 0, "FrmAssistantRptBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptPatientDebtBtn", System.Data.SqlDbType.Bit, 0, "FrmRptPatientDebtBtn"),
				new System.Data.SqlClient.SqlParameter("@doctorAcountBtn", System.Data.SqlDbType.Bit, 0, "doctorAcountBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmBillBtn", System.Data.SqlDbType.Bit, 0, "FrmBillBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmVisitMedicalRepBtn", System.Data.SqlDbType.Bit, 0, "FrmVisitMedicalRepBtn"),
				new System.Data.SqlClient.SqlParameter("@AppointmentspBtn", System.Data.SqlDbType.Bit, 0, "AppointmentspBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptSurgeryBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSurgeryBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptSpecialBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSpecialBtn"),
				new System.Data.SqlClient.SqlParameter("@CompanyPayBtn", System.Data.SqlDbType.Bit, 0, "CompanyPayBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptCompanyAcountBtn", System.Data.SqlDbType.Bit, 0, "FrmRptCompanyAcountBtn"),
				new System.Data.SqlClient.SqlParameter("@AssistantAccountBtn", System.Data.SqlDbType.Bit, 0, "AssistantAccountBtn"),
				new System.Data.SqlClient.SqlParameter("@AssistantAcountDate", System.Data.SqlDbType.Bit, 0, "AssistantAcountDate"),
				new System.Data.SqlClient.SqlParameter("@RptAssistantPaymentBtn", System.Data.SqlDbType.Bit, 0, "RptAssistantPaymentBtn"),
				new System.Data.SqlClient.SqlParameter("@RptLoginUserBtn", System.Data.SqlDbType.Bit, 0, "RptLoginUserBtn"),
				new System.Data.SqlClient.SqlParameter("@StockFrmBtn", System.Data.SqlDbType.Bit, 0, "StockFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@StockUsersFrmBtn", System.Data.SqlDbType.Bit, 0, "StockUsersFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmTarnsbetweenStockBtn", System.Data.SqlDbType.Bit, 0, "FrmTarnsbetweenStockBtn"),
				new System.Data.SqlClient.SqlParameter("@StockTransRptFrmBtn", System.Data.SqlDbType.Bit, 0, "StockTransRptFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmDeanSupplierBtn", System.Data.SqlDbType.Bit, 0, "FrmDeanSupplierBtn"),
				new System.Data.SqlClient.SqlParameter("@updateSurgery", System.Data.SqlDbType.Bit, 0, "updateSurgery"),
				new System.Data.SqlClient.SqlParameter("@ReserveServiceRptFrmBtn", System.Data.SqlDbType.Bit, 0, "ReserveServiceRptFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmEsalBtn", System.Data.SqlDbType.Bit, 0, "FrmEsalBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmAnalyzesBtn", System.Data.SqlDbType.Bit, 0, "FrmAnalyzesBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptRayAnalyzeBtn", System.Data.SqlDbType.Bit, 0, "FrmRptRayAnalyzeBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmChat", System.Data.SqlDbType.Bit, 0, "FrmChat"),
				new System.Data.SqlClient.SqlParameter("@FrmBeforeAndAfterBtn", System.Data.SqlDbType.Bit, 0, "FrmBeforeAndAfterBtn"),
				new System.Data.SqlClient.SqlParameter("@DiscountPointsBtn", System.Data.SqlDbType.Bit, 0, "DiscountPointsBtn"),
				new System.Data.SqlClient.SqlParameter("@PatientPointRptBtn", System.Data.SqlDbType.Bit, 0, "PatientPointRptBtn"),
				new System.Data.SqlClient.SqlParameter("@RptKnowFromBtn", System.Data.SqlDbType.Bit, 0, "RptKnowFromBtn"),
				new System.Data.SqlClient.SqlParameter("@RptPatientDetails", System.Data.SqlDbType.Bit, 0, "RptPatientDetails"),
				new System.Data.SqlClient.SqlParameter("@ItemsMoveRpt", System.Data.SqlDbType.Bit, 0, "ItemsMoveRpt"),
				new System.Data.SqlClient.SqlParameter("@ExpectedBirthDate", System.Data.SqlDbType.Bit, 0, "ExpectedBirthDate"),
				new System.Data.SqlClient.SqlParameter("@ShowAppointments", System.Data.SqlDbType.Bit, 0, "ShowAppointments"),
				new System.Data.SqlClient.SqlParameter("@Notes", System.Data.SqlDbType.Bit, 0, "Notes"),
				new System.Data.SqlClient.SqlParameter("@Comments", System.Data.SqlDbType.Bit, 0, "Comments"),
				new System.Data.SqlClient.SqlParameter("@OldServiceProvided", System.Data.SqlDbType.Bit, 0, "OldServiceProvided"),
				new System.Data.SqlClient.SqlParameter("@UpdatePackDate", System.Data.SqlDbType.Bit, 0, "UpdatePackDate"),
				new System.Data.SqlClient.SqlParameter("@SarfFreeSample", System.Data.SqlDbType.Bit, 0, "SarfFreeSample"),
				new System.Data.SqlClient.SqlParameter("@AddPoints", System.Data.SqlDbType.Bit, 0, "AddPoints"),
				new System.Data.SqlClient.SqlParameter("@FollowUpKids", System.Data.SqlDbType.Bit, 0, "FollowUpKids"),
				new System.Data.SqlClient.SqlParameter("@EmailCnfgs", System.Data.SqlDbType.Bit, 0, "EmailCnfgs"),
				new System.Data.SqlClient.SqlParameter("@RptEmails", System.Data.SqlDbType.Bit, 0, "RptEmails"),
				new System.Data.SqlClient.SqlParameter("@RptEmailConfig", System.Data.SqlDbType.Bit, 0, "RptEmailConfig"),
				new System.Data.SqlClient.SqlParameter("@NesbaDoctor", System.Data.SqlDbType.Bit, 0, "NesbaDoctor"),
				new System.Data.SqlClient.SqlParameter("@PrintCard", System.Data.SqlDbType.Bit, 0, "PrintCard"),
				new System.Data.SqlClient.SqlParameter("@SurgeryDate", System.Data.SqlDbType.Bit, 0, "SurgeryDate"),
				new System.Data.SqlClient.SqlParameter("@SurgeryDateRpt", System.Data.SqlDbType.Bit, 0, "SurgeryDateRpt"),
				new System.Data.SqlClient.SqlParameter("@EmpWorkData", System.Data.SqlDbType.Bit, 0, "EmpWorkData"),
				new System.Data.SqlClient.SqlParameter("@RaysAnalysis", System.Data.SqlDbType.Bit, 0, "RaysAnalysis"),
				new System.Data.SqlClient.SqlParameter("@MedicalReport", System.Data.SqlDbType.Bit, 0, "MedicalReport"),
				new System.Data.SqlClient.SqlParameter("@BarcodePrint", System.Data.SqlDbType.Bit, 0, "BarcodePrint"),
				new System.Data.SqlClient.SqlParameter("@CompanyServices", System.Data.SqlDbType.Bit, 0, "CompanyServices"),
				new System.Data.SqlClient.SqlParameter("@DeletePatientPay", System.Data.SqlDbType.Bit, 0, "DeletePatientPay"),
				new System.Data.SqlClient.SqlParameter("@RPTPatientNotice", System.Data.SqlDbType.Bit, 0, "RPTPatientNotice"),
				new System.Data.SqlClient.SqlParameter("@PatientNotice", System.Data.SqlDbType.Bit, 0, "PatientNotice"),
				new System.Data.SqlClient.SqlParameter("@Pediatric", System.Data.SqlDbType.Bit, 0, "Pediatric"),
				new System.Data.SqlClient.SqlParameter("@Orthopedical", System.Data.SqlDbType.Bit, 0, "Orthopedical"),
				new System.Data.SqlClient.SqlParameter("@Neurological", System.Data.SqlDbType.Bit, 0, "Neurological"),
				new System.Data.SqlClient.SqlParameter("@NaturalTherapy", System.Data.SqlDbType.Bit, 0, "NaturalTherapy"),
				new System.Data.SqlClient.SqlParameter("@DiscountSecretary", System.Data.SqlDbType.Bit, 0, "DiscountSecretary"),
				new System.Data.SqlClient.SqlParameter("@DiscountPatientAcc", System.Data.SqlDbType.Bit, 0, "DiscountPatientAcc"),
				new System.Data.SqlClient.SqlParameter("@ShowPrice", System.Data.SqlDbType.Bit, 0, "ShowPrice"),
				new System.Data.SqlClient.SqlParameter("@ReAccountDoctor", System.Data.SqlDbType.Bit, 0, "ReAccountDoctor"),
				new System.Data.SqlClient.SqlParameter("@ReAccountPatient", System.Data.SqlDbType.Bit, 0, "ReAccountPatient"),
				new System.Data.SqlClient.SqlParameter("@DataBaseChange", System.Data.SqlDbType.Bit, 0, "DataBaseChange"),
				new System.Data.SqlClient.SqlParameter("@SMSSetting", System.Data.SqlDbType.Bit, 0, "SMSSetting"),
				new System.Data.SqlClient.SqlParameter("@PhoneNum", System.Data.SqlDbType.Bit, 0, "PhoneNum"),
				new System.Data.SqlClient.SqlParameter("@SendSMS", System.Data.SqlDbType.Bit, 0, "SendSMS"),
				new System.Data.SqlClient.SqlParameter("@SendReportSetting", System.Data.SqlDbType.Bit, 0, "SendReportSetting"),
				new System.Data.SqlClient.SqlParameter("@DeleteUpdateApp", System.Data.SqlDbType.Bit, 0, "DeleteUpdateApp")
			});
			sqlCommand11.CommandText = "SELECT        users.*\r\nFROM            users";
			sqlCommand11.Connection = sqlConnection7;
			sqlCommand12.CommandText = resources.GetString("sqlCommand12.CommandText");
			sqlCommand12.Connection = sqlConnection7;
			sqlCommand12.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[416]
			{
				new System.Data.SqlClient.SqlParameter("@EmpID", System.Data.SqlDbType.Int, 0, "EmpID"),
				new System.Data.SqlClient.SqlParameter("@userName", System.Data.SqlDbType.NVarChar, 0, "userName"),
				new System.Data.SqlClient.SqlParameter("@userPassward", System.Data.SqlDbType.NVarChar, 0, "userPassward"),
				new System.Data.SqlClient.SqlParameter("@AddEmployee", System.Data.SqlDbType.Bit, 0, "AddEmployee"),
				new System.Data.SqlClient.SqlParameter("@AddPatient", System.Data.SqlDbType.Bit, 0, "AddPatient"),
				new System.Data.SqlClient.SqlParameter("@Appointment", System.Data.SqlDbType.Bit, 0, "Appointment"),
				new System.Data.SqlClient.SqlParameter("@DoctorPatientList", System.Data.SqlDbType.Bit, 0, "DoctorPatientList"),
				new System.Data.SqlClient.SqlParameter("@SecretaryPatientList", System.Data.SqlDbType.Bit, 0, "SecretaryPatientList"),
				new System.Data.SqlClient.SqlParameter("@DentalData", System.Data.SqlDbType.Bit, 0, "DentalData"),
				new System.Data.SqlClient.SqlParameter("@DoctorAccount", System.Data.SqlDbType.Bit, 0, "DoctorAccount"),
				new System.Data.SqlClient.SqlParameter("@SearchPatient", System.Data.SqlDbType.Bit, 0, "SearchPatient"),
				new System.Data.SqlClient.SqlParameter("@Company", System.Data.SqlDbType.Bit, 0, "Company"),
				new System.Data.SqlClient.SqlParameter("@PatientPay", System.Data.SqlDbType.Bit, 0, "PatientPay"),
				new System.Data.SqlClient.SqlParameter("@PatientAccount", System.Data.SqlDbType.Bit, 0, "PatientAccount"),
				new System.Data.SqlClient.SqlParameter("@PatientXray", System.Data.SqlDbType.Bit, 0, "PatientXray"),
				new System.Data.SqlClient.SqlParameter("@Permission", System.Data.SqlDbType.Bit, 0, "Permission"),
				new System.Data.SqlClient.SqlParameter("@PatAccountRpt", System.Data.SqlDbType.Bit, 0, "PatAccountRpt"),
				new System.Data.SqlClient.SqlParameter("@ALLPatAccountRpt", System.Data.SqlDbType.Bit, 0, "ALLPatAccountRpt"),
				new System.Data.SqlClient.SqlParameter("@DoctorAccountRpt", System.Data.SqlDbType.Bit, 0, "DoctorAccountRpt"),
				new System.Data.SqlClient.SqlParameter("@DoctorPaymentRpt", System.Data.SqlDbType.Bit, 0, "DoctorPaymentRpt"),
				new System.Data.SqlClient.SqlParameter("@MovOfPatSTrpt", System.Data.SqlDbType.Bit, 0, "MovOfPatSTrpt"),
				new System.Data.SqlClient.SqlParameter("@MovOfPatStbyDr", System.Data.SqlDbType.Bit, 0, "MovOfPatStbyDr"),
				new System.Data.SqlClient.SqlParameter("@Expenses", System.Data.SqlDbType.Bit, 0, "Expenses"),
				new System.Data.SqlClient.SqlParameter("@Revenues", System.Data.SqlDbType.Bit, 0, "Revenues"),
				new System.Data.SqlClient.SqlParameter("@RptExpenses", System.Data.SqlDbType.Bit, 0, "RptExpenses"),
				new System.Data.SqlClient.SqlParameter("@RptRevenues", System.Data.SqlDbType.Bit, 0, "RptRevenues"),
				new System.Data.SqlClient.SqlParameter("@RptStockMove", System.Data.SqlDbType.Bit, 0, "RptStockMove"),
				new System.Data.SqlClient.SqlParameter("@DoctorBackReserve", System.Data.SqlDbType.Bit, 0, "DoctorBackReserve"),
				new System.Data.SqlClient.SqlParameter("@SecretaryBackReserve", System.Data.SqlDbType.Bit, 0, "SecretaryBackReserve"),
				new System.Data.SqlClient.SqlParameter("@UpdateRebackdate", System.Data.SqlDbType.Bit, 0, "UpdateRebackdate"),
				new System.Data.SqlClient.SqlParameter("@medicineFrmBtn", System.Data.SqlDbType.Bit, 0, "medicineFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@PrescriptionFrmBtn", System.Data.SqlDbType.Bit, 0, "PrescriptionFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@ItemsFrmBtn", System.Data.SqlDbType.Bit, 0, "ItemsFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@SupplierBtn", System.Data.SqlDbType.Bit, 0, "SupplierBtn"),
				new System.Data.SqlClient.SqlParameter("@IncomingBillFrmBtn", System.Data.SqlDbType.Bit, 0, "IncomingBillFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmSupplierAccountsBtn", System.Data.SqlDbType.Bit, 0, "FrmSupplierAccountsBtn"),
				new System.Data.SqlClient.SqlParameter("@FormSupplier5Btn", System.Data.SqlDbType.Bit, 0, "FormSupplier5Btn"),
				new System.Data.SqlClient.SqlParameter("@FrmBillIncomeRptBtn", System.Data.SqlDbType.Bit, 0, "FrmBillIncomeRptBtn"),
				new System.Data.SqlClient.SqlParameter("@OldServicesRptFrmBtn", System.Data.SqlDbType.Bit, 0, "OldServicesRptFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@NetDailyClinicRptFrmBtn", System.Data.SqlDbType.Bit, 0, "NetDailyClinicRptFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@ClinicMonthGraphRptFrmBtn", System.Data.SqlDbType.Bit, 0, "ClinicMonthGraphRptFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@DailymeasureRotFrmBtn", System.Data.SqlDbType.Bit, 0, "DailymeasureRotFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@RptFrmSearchMedicine", System.Data.SqlDbType.Bit, 0, "RptFrmSearchMedicine"),
				new System.Data.SqlClient.SqlParameter("@ServicePatientBtn", System.Data.SqlDbType.Bit, 0, "ServicePatientBtn"),
				new System.Data.SqlClient.SqlParameter("@MainComplaintBtn", System.Data.SqlDbType.Bit, 0, "MainComplaintBtn"),
				new System.Data.SqlClient.SqlParameter("@SahbItemsBtn", System.Data.SqlDbType.Bit, 0, "SahbItemsBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptSahbItemBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSahbItemBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptBillByDateBtn", System.Data.SqlDbType.Bit, 0, "FrmRptBillByDateBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmFilePatientBtn", System.Data.SqlDbType.Bit, 0, "FrmFilePatientBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmPropertiesBtn", System.Data.SqlDbType.Bit, 0, "FrmPropertiesBtn"),
				new System.Data.SqlClient.SqlParameter("@ChangeServicePrice", System.Data.SqlDbType.Bit, 0, "ChangeServicePrice"),
				new System.Data.SqlClient.SqlParameter("@btnBackup_Restore", System.Data.SqlDbType.Bit, 0, "btnBackup_Restore"),
				new System.Data.SqlClient.SqlParameter("@Surgery", System.Data.SqlDbType.Bit, 0, "Surgery"),
				new System.Data.SqlClient.SqlParameter("@BookingVisits", System.Data.SqlDbType.Bit, 0, "BookingVisits"),
				new System.Data.SqlClient.SqlParameter("@RptVisits", System.Data.SqlDbType.Bit, 0, "RptVisits"),
				new System.Data.SqlClient.SqlParameter("@SecretaryVisits", System.Data.SqlDbType.Bit, 0, "SecretaryVisits"),
				new System.Data.SqlClient.SqlParameter("@DoctorVisits", System.Data.SqlDbType.Bit, 0, "DoctorVisits"),
				new System.Data.SqlClient.SqlParameter("@PatientSurgery", System.Data.SqlDbType.Bit, 0, "PatientSurgery"),
				new System.Data.SqlClient.SqlParameter("@BtnFrmRptReb7ya", System.Data.SqlDbType.Bit, 0, "BtnFrmRptReb7ya"),
				new System.Data.SqlClient.SqlParameter("@BtnFrmRptCompanies_Services", System.Data.SqlDbType.Bit, 0, "BtnFrmRptCompanies_Services"),
				new System.Data.SqlClient.SqlParameter("@BtnFrmSell", System.Data.SqlDbType.Bit, 0, "BtnFrmSell"),
				new System.Data.SqlClient.SqlParameter("@FrmRptSellByDateBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSellByDateBtn"),
				new System.Data.SqlClient.SqlParameter("@PatientAccountUpdateBtn", System.Data.SqlDbType.Bit, 0, "PatientAccountUpdateBtn"),
				new System.Data.SqlClient.SqlParameter("@PatientServiceUpdateBtn", System.Data.SqlDbType.Bit, 0, "PatientServiceUpdateBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmInventoryRptBtn", System.Data.SqlDbType.Bit, 0, "FrmInventoryRptBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmLimitOrderRptBtn", System.Data.SqlDbType.Bit, 0, "FrmLimitOrderRptBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmInoculationBtn", System.Data.SqlDbType.Bit, 0, "FrmInoculationBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmPatientInoculationBtn", System.Data.SqlDbType.Bit, 0, "FrmPatientInoculationBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmAssistantRptBtn", System.Data.SqlDbType.Bit, 0, "FrmAssistantRptBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptPatientDebtBtn", System.Data.SqlDbType.Bit, 0, "FrmRptPatientDebtBtn"),
				new System.Data.SqlClient.SqlParameter("@doctorAcountBtn", System.Data.SqlDbType.Bit, 0, "doctorAcountBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmBillBtn", System.Data.SqlDbType.Bit, 0, "FrmBillBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmVisitMedicalRepBtn", System.Data.SqlDbType.Bit, 0, "FrmVisitMedicalRepBtn"),
				new System.Data.SqlClient.SqlParameter("@AppointmentspBtn", System.Data.SqlDbType.Bit, 0, "AppointmentspBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptSurgeryBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSurgeryBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptSpecialBtn", System.Data.SqlDbType.Bit, 0, "FrmRptSpecialBtn"),
				new System.Data.SqlClient.SqlParameter("@CompanyPayBtn", System.Data.SqlDbType.Bit, 0, "CompanyPayBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptCompanyAcountBtn", System.Data.SqlDbType.Bit, 0, "FrmRptCompanyAcountBtn"),
				new System.Data.SqlClient.SqlParameter("@AssistantAccountBtn", System.Data.SqlDbType.Bit, 0, "AssistantAccountBtn"),
				new System.Data.SqlClient.SqlParameter("@AssistantAcountDate", System.Data.SqlDbType.Bit, 0, "AssistantAcountDate"),
				new System.Data.SqlClient.SqlParameter("@RptAssistantPaymentBtn", System.Data.SqlDbType.Bit, 0, "RptAssistantPaymentBtn"),
				new System.Data.SqlClient.SqlParameter("@RptLoginUserBtn", System.Data.SqlDbType.Bit, 0, "RptLoginUserBtn"),
				new System.Data.SqlClient.SqlParameter("@StockFrmBtn", System.Data.SqlDbType.Bit, 0, "StockFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@StockUsersFrmBtn", System.Data.SqlDbType.Bit, 0, "StockUsersFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmTarnsbetweenStockBtn", System.Data.SqlDbType.Bit, 0, "FrmTarnsbetweenStockBtn"),
				new System.Data.SqlClient.SqlParameter("@StockTransRptFrmBtn", System.Data.SqlDbType.Bit, 0, "StockTransRptFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmDeanSupplierBtn", System.Data.SqlDbType.Bit, 0, "FrmDeanSupplierBtn"),
				new System.Data.SqlClient.SqlParameter("@updateSurgery", System.Data.SqlDbType.Bit, 0, "updateSurgery"),
				new System.Data.SqlClient.SqlParameter("@ReserveServiceRptFrmBtn", System.Data.SqlDbType.Bit, 0, "ReserveServiceRptFrmBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmEsalBtn", System.Data.SqlDbType.Bit, 0, "FrmEsalBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmAnalyzesBtn", System.Data.SqlDbType.Bit, 0, "FrmAnalyzesBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmRptRayAnalyzeBtn", System.Data.SqlDbType.Bit, 0, "FrmRptRayAnalyzeBtn"),
				new System.Data.SqlClient.SqlParameter("@FrmChat", System.Data.SqlDbType.Bit, 0, "FrmChat"),
				new System.Data.SqlClient.SqlParameter("@FrmBeforeAndAfterBtn", System.Data.SqlDbType.Bit, 0, "FrmBeforeAndAfterBtn"),
				new System.Data.SqlClient.SqlParameter("@DiscountPointsBtn", System.Data.SqlDbType.Bit, 0, "DiscountPointsBtn"),
				new System.Data.SqlClient.SqlParameter("@PatientPointRptBtn", System.Data.SqlDbType.Bit, 0, "PatientPointRptBtn"),
				new System.Data.SqlClient.SqlParameter("@RptKnowFromBtn", System.Data.SqlDbType.Bit, 0, "RptKnowFromBtn"),
				new System.Data.SqlClient.SqlParameter("@RptPatientDetails", System.Data.SqlDbType.Bit, 0, "RptPatientDetails"),
				new System.Data.SqlClient.SqlParameter("@ItemsMoveRpt", System.Data.SqlDbType.Bit, 0, "ItemsMoveRpt"),
				new System.Data.SqlClient.SqlParameter("@ExpectedBirthDate", System.Data.SqlDbType.Bit, 0, "ExpectedBirthDate"),
				new System.Data.SqlClient.SqlParameter("@ShowAppointments", System.Data.SqlDbType.Bit, 0, "ShowAppointments"),
				new System.Data.SqlClient.SqlParameter("@Notes", System.Data.SqlDbType.Bit, 0, "Notes"),
				new System.Data.SqlClient.SqlParameter("@Comments", System.Data.SqlDbType.Bit, 0, "Comments"),
				new System.Data.SqlClient.SqlParameter("@OldServiceProvided", System.Data.SqlDbType.Bit, 0, "OldServiceProvided"),
				new System.Data.SqlClient.SqlParameter("@UpdatePackDate", System.Data.SqlDbType.Bit, 0, "UpdatePackDate"),
				new System.Data.SqlClient.SqlParameter("@SarfFreeSample", System.Data.SqlDbType.Bit, 0, "SarfFreeSample"),
				new System.Data.SqlClient.SqlParameter("@AddPoints", System.Data.SqlDbType.Bit, 0, "AddPoints"),
				new System.Data.SqlClient.SqlParameter("@FollowUpKids", System.Data.SqlDbType.Bit, 0, "FollowUpKids"),
				new System.Data.SqlClient.SqlParameter("@EmailCnfgs", System.Data.SqlDbType.Bit, 0, "EmailCnfgs"),
				new System.Data.SqlClient.SqlParameter("@RptEmails", System.Data.SqlDbType.Bit, 0, "RptEmails"),
				new System.Data.SqlClient.SqlParameter("@RptEmailConfig", System.Data.SqlDbType.Bit, 0, "RptEmailConfig"),
				new System.Data.SqlClient.SqlParameter("@NesbaDoctor", System.Data.SqlDbType.Bit, 0, "NesbaDoctor"),
				new System.Data.SqlClient.SqlParameter("@PrintCard", System.Data.SqlDbType.Bit, 0, "PrintCard"),
				new System.Data.SqlClient.SqlParameter("@SurgeryDate", System.Data.SqlDbType.Bit, 0, "SurgeryDate"),
				new System.Data.SqlClient.SqlParameter("@SurgeryDateRpt", System.Data.SqlDbType.Bit, 0, "SurgeryDateRpt"),
				new System.Data.SqlClient.SqlParameter("@EmpWorkData", System.Data.SqlDbType.Bit, 0, "EmpWorkData"),
				new System.Data.SqlClient.SqlParameter("@RaysAnalysis", System.Data.SqlDbType.Bit, 0, "RaysAnalysis"),
				new System.Data.SqlClient.SqlParameter("@MedicalReport", System.Data.SqlDbType.Bit, 0, "MedicalReport"),
				new System.Data.SqlClient.SqlParameter("@BarcodePrint", System.Data.SqlDbType.Bit, 0, "BarcodePrint"),
				new System.Data.SqlClient.SqlParameter("@CompanyServices", System.Data.SqlDbType.Bit, 0, "CompanyServices"),
				new System.Data.SqlClient.SqlParameter("@DeletePatientPay", System.Data.SqlDbType.Bit, 0, "DeletePatientPay"),
				new System.Data.SqlClient.SqlParameter("@RPTPatientNotice", System.Data.SqlDbType.Bit, 0, "RPTPatientNotice"),
				new System.Data.SqlClient.SqlParameter("@PatientNotice", System.Data.SqlDbType.Bit, 0, "PatientNotice"),
				new System.Data.SqlClient.SqlParameter("@Pediatric", System.Data.SqlDbType.Bit, 0, "Pediatric"),
				new System.Data.SqlClient.SqlParameter("@Orthopedical", System.Data.SqlDbType.Bit, 0, "Orthopedical"),
				new System.Data.SqlClient.SqlParameter("@Neurological", System.Data.SqlDbType.Bit, 0, "Neurological"),
				new System.Data.SqlClient.SqlParameter("@NaturalTherapy", System.Data.SqlDbType.Bit, 0, "NaturalTherapy"),
				new System.Data.SqlClient.SqlParameter("@DiscountSecretary", System.Data.SqlDbType.Bit, 0, "DiscountSecretary"),
				new System.Data.SqlClient.SqlParameter("@DiscountPatientAcc", System.Data.SqlDbType.Bit, 0, "DiscountPatientAcc"),
				new System.Data.SqlClient.SqlParameter("@ShowPrice", System.Data.SqlDbType.Bit, 0, "ShowPrice"),
				new System.Data.SqlClient.SqlParameter("@ReAccountDoctor", System.Data.SqlDbType.Bit, 0, "ReAccountDoctor"),
				new System.Data.SqlClient.SqlParameter("@ReAccountPatient", System.Data.SqlDbType.Bit, 0, "ReAccountPatient"),
				new System.Data.SqlClient.SqlParameter("@DataBaseChange", System.Data.SqlDbType.Bit, 0, "DataBaseChange"),
				new System.Data.SqlClient.SqlParameter("@SMSSetting", System.Data.SqlDbType.Bit, 0, "SMSSetting"),
				new System.Data.SqlClient.SqlParameter("@PhoneNum", System.Data.SqlDbType.Bit, 0, "PhoneNum"),
				new System.Data.SqlClient.SqlParameter("@SendSMS", System.Data.SqlDbType.Bit, 0, "SendSMS"),
				new System.Data.SqlClient.SqlParameter("@SendReportSetting", System.Data.SqlDbType.Bit, 0, "SendReportSetting"),
				new System.Data.SqlClient.SqlParameter("@DeleteUpdateApp", System.Data.SqlDbType.Bit, 0, "DeleteUpdateApp"),
				new System.Data.SqlClient.SqlParameter("@Original_userId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EmpID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EmpID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EmpID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EmpID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_userName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "userName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_userName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_userPassward", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "userPassward", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_userPassward", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "userPassward", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AddEmployee", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AddEmployee", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AddEmployee", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AddEmployee", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AddPatient", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AddPatient", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AddPatient", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AddPatient", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Appointment", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Appointment", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Appointment", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Appointment", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorPatientList", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorPatientList", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorPatientList", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorPatientList", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SecretaryPatientList", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SecretaryPatientList", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SecretaryPatientList", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SecretaryPatientList", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalData", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalData", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalData", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalData", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorAccount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorAccount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorAccount", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorAccount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SearchPatient", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SearchPatient", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SearchPatient", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SearchPatient", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Company", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Company", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Company", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Company", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientPay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientPay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientPay", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientPay", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientAccount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientAccount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientAccount", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientAccount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientXray", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientXray", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientXray", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientXray", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Permission", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Permission", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Permission", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Permission", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatAccountRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatAccountRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatAccountRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatAccountRpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ALLPatAccountRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ALLPatAccountRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ALLPatAccountRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ALLPatAccountRpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorAccountRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorAccountRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorAccountRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorAccountRpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorPaymentRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorPaymentRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorPaymentRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorPaymentRpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_MovOfPatSTrpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MovOfPatSTrpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_MovOfPatSTrpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MovOfPatSTrpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_MovOfPatStbyDr", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MovOfPatStbyDr", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_MovOfPatStbyDr", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MovOfPatStbyDr", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Expenses", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Expenses", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Expenses", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Expenses", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Revenues", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Revenues", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Revenues", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Revenues", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptExpenses", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptExpenses", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptExpenses", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptExpenses", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptRevenues", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptRevenues", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptRevenues", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptRevenues", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptStockMove", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptStockMove", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptStockMove", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptStockMove", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorBackReserve", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorBackReserve", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorBackReserve", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorBackReserve", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SecretaryBackReserve", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SecretaryBackReserve", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SecretaryBackReserve", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SecretaryBackReserve", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_UpdateRebackdate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "UpdateRebackdate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_UpdateRebackdate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "UpdateRebackdate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_medicineFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "medicineFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_medicineFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "medicineFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PrescriptionFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PrescriptionFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PrescriptionFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PrescriptionFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ItemsFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemsFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ItemsFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemsFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupplierBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_IncomingBillFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "IncomingBillFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_IncomingBillFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "IncomingBillFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmSupplierAccountsBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmSupplierAccountsBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmSupplierAccountsBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmSupplierAccountsBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FormSupplier5Btn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FormSupplier5Btn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FormSupplier5Btn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FormSupplier5Btn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmBillIncomeRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmBillIncomeRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmBillIncomeRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmBillIncomeRptBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_OldServicesRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "OldServicesRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_OldServicesRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "OldServicesRptFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NetDailyClinicRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NetDailyClinicRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NetDailyClinicRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NetDailyClinicRptFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicMonthGraphRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicMonthGraphRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicMonthGraphRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicMonthGraphRptFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DailymeasureRotFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DailymeasureRotFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DailymeasureRotFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DailymeasureRotFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptFrmSearchMedicine", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptFrmSearchMedicine", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptFrmSearchMedicine", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptFrmSearchMedicine", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ServicePatientBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ServicePatientBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ServicePatientBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ServicePatientBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_MainComplaintBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MainComplaintBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_MainComplaintBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MainComplaintBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SahbItemsBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SahbItemsBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SahbItemsBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SahbItemsBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSahbItemBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSahbItemBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptSahbItemBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSahbItemBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptBillByDateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptBillByDateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptBillByDateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptBillByDateBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmFilePatientBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmFilePatientBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmFilePatientBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmFilePatientBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmPropertiesBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmPropertiesBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmPropertiesBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmPropertiesBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ChangeServicePrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ChangeServicePrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ChangeServicePrice", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ChangeServicePrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_btnBackup_Restore", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "btnBackup_Restore", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_btnBackup_Restore", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "btnBackup_Restore", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Surgery", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Surgery", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Surgery", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Surgery", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BookingVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BookingVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BookingVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BookingVisits", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptVisits", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SecretaryVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SecretaryVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SecretaryVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SecretaryVisits", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorVisits", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorVisits", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorVisits", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorVisits", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientSurgery", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientSurgery", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientSurgery", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientSurgery", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BtnFrmRptReb7ya", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BtnFrmRptReb7ya", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BtnFrmRptReb7ya", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BtnFrmRptReb7ya", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BtnFrmRptCompanies_Services", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BtnFrmRptCompanies_Services", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BtnFrmRptCompanies_Services", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BtnFrmRptCompanies_Services", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BtnFrmSell", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BtnFrmSell", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BtnFrmSell", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BtnFrmSell", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSellByDateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSellByDateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptSellByDateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSellByDateBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientAccountUpdateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientAccountUpdateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientAccountUpdateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientAccountUpdateBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientServiceUpdateBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientServiceUpdateBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientServiceUpdateBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientServiceUpdateBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmInventoryRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmInventoryRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmInventoryRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmInventoryRptBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmLimitOrderRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmLimitOrderRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmLimitOrderRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmLimitOrderRptBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmInoculationBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmInoculationBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmInoculationBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmInoculationBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmPatientInoculationBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmPatientInoculationBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmPatientInoculationBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmPatientInoculationBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmAssistantRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmAssistantRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmAssistantRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmAssistantRptBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptPatientDebtBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptPatientDebtBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptPatientDebtBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptPatientDebtBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_doctorAcountBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "doctorAcountBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_doctorAcountBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "doctorAcountBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmBillBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmBillBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmBillBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmBillBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmVisitMedicalRepBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmVisitMedicalRepBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmVisitMedicalRepBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmVisitMedicalRepBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AppointmentspBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AppointmentspBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AppointmentspBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AppointmentspBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSurgeryBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSurgeryBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptSurgeryBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSurgeryBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptSpecialBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptSpecialBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptSpecialBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptSpecialBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_CompanyPayBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "CompanyPayBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_CompanyPayBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "CompanyPayBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptCompanyAcountBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptCompanyAcountBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptCompanyAcountBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptCompanyAcountBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AssistantAccountBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AssistantAccountBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AssistantAccountBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AssistantAccountBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AssistantAcountDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AssistantAcountDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AssistantAcountDate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AssistantAcountDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptAssistantPaymentBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptAssistantPaymentBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptAssistantPaymentBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptAssistantPaymentBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptLoginUserBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptLoginUserBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptLoginUserBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptLoginUserBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_StockFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "StockFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_StockFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "StockFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_StockUsersFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "StockUsersFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_StockUsersFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "StockUsersFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmTarnsbetweenStockBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmTarnsbetweenStockBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmTarnsbetweenStockBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmTarnsbetweenStockBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_StockTransRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "StockTransRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_StockTransRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "StockTransRptFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmDeanSupplierBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmDeanSupplierBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmDeanSupplierBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmDeanSupplierBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_updateSurgery", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "updateSurgery", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_updateSurgery", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "updateSurgery", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ReserveServiceRptFrmBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ReserveServiceRptFrmBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ReserveServiceRptFrmBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ReserveServiceRptFrmBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmEsalBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmEsalBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmEsalBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmEsalBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmAnalyzesBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmAnalyzesBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmAnalyzesBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmAnalyzesBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmRptRayAnalyzeBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmRptRayAnalyzeBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmRptRayAnalyzeBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmRptRayAnalyzeBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmChat", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmChat", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmChat", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmChat", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FrmBeforeAndAfterBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FrmBeforeAndAfterBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FrmBeforeAndAfterBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FrmBeforeAndAfterBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountPointsBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountPointsBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountPointsBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountPointsBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientPointRptBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientPointRptBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientPointRptBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientPointRptBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptKnowFromBtn", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptKnowFromBtn", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptKnowFromBtn", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptKnowFromBtn", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptPatientDetails", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptPatientDetails", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptPatientDetails", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptPatientDetails", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ItemsMoveRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemsMoveRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ItemsMoveRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemsMoveRpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ExpectedBirthDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ExpectedBirthDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ExpectedBirthDate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ExpectedBirthDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ShowAppointments", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ShowAppointments", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ShowAppointments", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ShowAppointments", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Notes", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Notes", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Notes", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Notes", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Comments", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Comments", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Comments", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Comments", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_OldServiceProvided", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "OldServiceProvided", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_OldServiceProvided", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "OldServiceProvided", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_UpdatePackDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "UpdatePackDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_UpdatePackDate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "UpdatePackDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SarfFreeSample", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SarfFreeSample", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SarfFreeSample", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SarfFreeSample", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AddPoints", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AddPoints", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AddPoints", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AddPoints", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FollowUpKids", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FollowUpKids", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FollowUpKids", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FollowUpKids", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EmailCnfgs", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EmailCnfgs", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EmailCnfgs", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EmailCnfgs", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptEmails", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptEmails", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptEmails", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptEmails", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RptEmailConfig", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RptEmailConfig", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RptEmailConfig", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RptEmailConfig", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NesbaDoctor", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NesbaDoctor", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NesbaDoctor", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NesbaDoctor", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PrintCard", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PrintCard", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PrintCard", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PrintCard", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SurgeryDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SurgeryDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SurgeryDate", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SurgeryDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SurgeryDateRpt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SurgeryDateRpt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SurgeryDateRpt", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SurgeryDateRpt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EmpWorkData", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EmpWorkData", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EmpWorkData", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EmpWorkData", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RaysAnalysis", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RaysAnalysis", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RaysAnalysis", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RaysAnalysis", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_MedicalReport", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "MedicalReport", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_MedicalReport", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "MedicalReport", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BarcodePrint", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BarcodePrint", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BarcodePrint", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BarcodePrint", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_CompanyServices", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "CompanyServices", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_CompanyServices", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "CompanyServices", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DeletePatientPay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DeletePatientPay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DeletePatientPay", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DeletePatientPay", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_RPTPatientNotice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "RPTPatientNotice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_RPTPatientNotice", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "RPTPatientNotice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientNotice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientNotice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientNotice", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientNotice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Pediatric", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Pediatric", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Pediatric", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Pediatric", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Orthopedical", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Orthopedical", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Orthopedical", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Orthopedical", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Neurological", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Neurological", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Neurological", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Neurological", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalTherapy", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalTherapy", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalTherapy", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalTherapy", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountSecretary", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountSecretary", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountSecretary", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountSecretary", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountPatientAcc", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountPatientAcc", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountPatientAcc", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountPatientAcc", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ShowPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ShowPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ShowPrice", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ShowPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ReAccountDoctor", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ReAccountDoctor", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ReAccountDoctor", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ReAccountDoctor", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ReAccountPatient", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ReAccountPatient", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ReAccountPatient", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ReAccountPatient", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DataBaseChange", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DataBaseChange", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DataBaseChange", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DataBaseChange", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SMSSetting", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SMSSetting", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SMSSetting", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SMSSetting", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PhoneNum", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PhoneNum", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PhoneNum", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PhoneNum", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SendSMS", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SendSMS", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SendSMS", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SendSMS", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SendReportSetting", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SendReportSetting", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SendReportSetting", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SendReportSetting", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DeleteUpdateApp", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DeleteUpdateApp", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DeleteUpdateApp", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DeleteUpdateApp", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@userId", System.Data.SqlDbType.Int, 4, "userId")
			});
			sqlConnection8.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection8.FireInfoMessageEventOnUserErrors = false;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox2);
			Font = null;
			base.Name = "FrmDoctorAcountByDate";
			base.Load += new System.EventHandler(FrmDoctorAcountByDate_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(FrmDoctorAcountByDate_KeyDown);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}
	}
}
