using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Properties;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class BeautyClinicRpt : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox2;

		private CrystalReportViewer crystalReportViewer1;

		private GroupBox groupBox1;

		private Button ViewRptBtn;

		private ComboBox PatientCombo;

		private Label label1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlInsertCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlSelectCommand1;

		private SqlDataAdapter sqlDataAdapter4;

		private SqlCommand sqlDeleteCommand1;

		private SqlConnection sqlConnection4;

		private SqlCommand sqlInsertCommand4;

		private SqlCommand sqlSelectCommand4;

		private SqlCommand sqlUpdateCommand1;

		private SqlDataAdapter sqlDataAdapter3;

		private SqlConnection sqlConnection3;

		private SqlCommand sqlCommand6;

		private SqlCommand sqlCommand7;

		private DataSet1 dataSet11;

		private ClassDataBase dc;

		private dataClass codes;

		private GUI gui = new GUI();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BeautyClinicRpt));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ViewRptBtn = new System.Windows.Forms.Button();
            this.PatientCombo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
            this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
            this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlDataAdapter4 = new System.Data.SqlClient.SqlDataAdapter();
            this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlConnection4 = new System.Data.SqlClient.SqlConnection();
            this.sqlInsertCommand4 = new System.Data.SqlClient.SqlCommand();
            this.sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
            this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
            this.sqlCommand6 = new System.Data.SqlClient.SqlCommand();
            this.sqlConnection3 = new System.Data.SqlClient.SqlConnection();
            this.sqlCommand7 = new System.Data.SqlClient.SqlCommand();
            this.dataSet11 = new DataSet1();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.crystalReportViewer1);
            this.groupBox2.Location = new System.Drawing.Point(8, 74);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(959, 489);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crystalReportViewer1.Location = new System.Drawing.Point(3, 16);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.SelectionFormula = "";
            this.crystalReportViewer1.Size = new System.Drawing.Size(953, 470);
            this.crystalReportViewer1.TabIndex = 0;
            this.crystalReportViewer1.ViewTimeSelectionFormula = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.ViewRptBtn);
            this.groupBox1.Controls.Add(this.PatientCombo);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(955, 60);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // ViewRptBtn
            // 
            this.ViewRptBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.ViewRptBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ViewRptBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.ViewRptBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.ViewRptBtn.Location = new System.Drawing.Point(379, 16);
            this.ViewRptBtn.Name = "ViewRptBtn";
            this.ViewRptBtn.Size = new System.Drawing.Size(108, 32);
            this.ViewRptBtn.TabIndex = 4;
            this.ViewRptBtn.Text = "عرض التقرير";
            this.ViewRptBtn.UseVisualStyleBackColor = false;
            this.ViewRptBtn.Click += new System.EventHandler(this.ViewRptBtn_Click);
            // 
            // PatientCombo
            // 
            this.PatientCombo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PatientCombo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.PatientCombo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.PatientCombo.FormattingEnabled = true;
            this.PatientCombo.Location = new System.Drawing.Point(513, 25);
            this.PatientCombo.Name = "PatientCombo";
            this.PatientCombo.Size = new System.Drawing.Size(315, 21);
            this.PatientCombo.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(834, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "اختر اسم المريض";
            // 
            // sqlDataAdapter1
            // 
            this.sqlDataAdapter1.InsertCommand = this.sqlInsertCommand1;
            this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
            this.sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("ID", "ID"),
                        new System.Data.Common.DataColumnMapping("Titel", "Titel"),
                        new System.Data.Common.DataColumnMapping("PName", "PName"),
                        new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
                        new System.Data.Common.DataColumnMapping("City", "City"),
                        new System.Data.Common.DataColumnMapping("Tel", "Tel"),
                        new System.Data.Common.DataColumnMapping("Mob", "Mob"),
                        new System.Data.Common.DataColumnMapping("Email", "Email"),
                        new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
                        new System.Data.Common.DataColumnMapping("Sex", "Sex"),
                        new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
                        new System.Data.Common.DataColumnMapping("Statue", "Statue"),
                        new System.Data.Common.DataColumnMapping("company", "company"),
                        new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
                        new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
                        new System.Data.Common.DataColumnMapping("pain", "pain"),
                        new System.Data.Common.DataColumnMapping("Caries", "Caries"),
                        new System.Data.Common.DataColumnMapping("CheckUp", "CheckUp"),
                        new System.Data.Common.DataColumnMapping("Swelling", "Swelling"),
                        new System.Data.Common.DataColumnMapping("Esthetics", "Esthetics"),
                        new System.Data.Common.DataColumnMapping("Others", "Others"),
                        new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
                        new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
                        new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
                        new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
                        new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
                        new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
                        new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
                        new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
                        new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
                        new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
                        new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
                        new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
                        new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
                        new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
                        new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
                        new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
                        new System.Data.Common.DataColumnMapping("Implant", "Implant"),
                        new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
                        new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
                        new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers")})});
            // 
            // sqlInsertCommand1
            // 
            this.sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
            this.sqlInsertCommand1.Connection = this.sqlConnection1;
            this.sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
            new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
            new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
            new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
            new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
            new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
            new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
            new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
            new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
            new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
            new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
            new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
            new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
            new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
            new System.Data.SqlClient.SqlParameter("@pain", System.Data.SqlDbType.Bit, 0, "pain"),
            new System.Data.SqlClient.SqlParameter("@Caries", System.Data.SqlDbType.Bit, 0, "Caries"),
            new System.Data.SqlClient.SqlParameter("@CheckUp", System.Data.SqlDbType.Bit, 0, "CheckUp"),
            new System.Data.SqlClient.SqlParameter("@Swelling", System.Data.SqlDbType.Bit, 0, "Swelling"),
            new System.Data.SqlClient.SqlParameter("@Esthetics", System.Data.SqlDbType.Bit, 0, "Esthetics"),
            new System.Data.SqlClient.SqlParameter("@Others", System.Data.SqlDbType.NVarChar, 0, "Others"),
            new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
            new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
            new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
            new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
            new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
            new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
            new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
            new System.Data.SqlClient.SqlParameter("@Lactating", System.Data.SqlDbType.Bit, 0, "Lactating"),
            new System.Data.SqlClient.SqlParameter("@Pregnant", System.Data.SqlDbType.Bit, 0, "Pregnant"),
            new System.Data.SqlClient.SqlParameter("@HepatitisB", System.Data.SqlDbType.Bit, 0, "HepatitisB"),
            new System.Data.SqlClient.SqlParameter("@Hepatitisc", System.Data.SqlDbType.Bit, 0, "Hepatitisc"),
            new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
            new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
            new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
            new System.Data.SqlClient.SqlParameter("@Endodontics", System.Data.SqlDbType.Bit, 0, "Endodontics"),
            new System.Data.SqlClient.SqlParameter("@Fixed", System.Data.SqlDbType.Bit, 0, "Fixed"),
            new System.Data.SqlClient.SqlParameter("@Implant", System.Data.SqlDbType.Bit, 0, "Implant"),
            new System.Data.SqlClient.SqlParameter("@Opretive", System.Data.SqlDbType.Bit, 0, "Opretive"),
            new System.Data.SqlClient.SqlParameter("@Bleaching", System.Data.SqlDbType.Bit, 0, "Bleaching"),
            new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers")});
            // 
            // sqlConnection1
            // 
            this.sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrat" +
    "ed Security=True;Connect Timeout=30;User Instance=True";
            this.sqlConnection1.FireInfoMessageEventOnUserErrors = false;
            // 
            // sqlSelectCommand1
            // 
            this.sqlSelectCommand1.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
            this.sqlSelectCommand1.Connection = this.sqlConnection1;
            // 
            // sqlDataAdapter4
            // 
            this.sqlDataAdapter4.DeleteCommand = this.sqlDeleteCommand1;
            this.sqlDataAdapter4.InsertCommand = this.sqlInsertCommand4;
            this.sqlDataAdapter4.SelectCommand = this.sqlSelectCommand4;
            this.sqlDataAdapter4.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("ID", "ID"),
                        new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
                        new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
                        new System.Data.Common.DataColumnMapping("DTel", "DTel"),
                        new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
                        new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
                        new System.Data.Common.DataColumnMapping("DSite", "DSite"),
                        new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
                        new System.Data.Common.DataColumnMapping("WorkData", "WorkData"),
                        new System.Data.Common.DataColumnMapping("Powred", "Powred"),
                        new System.Data.Common.DataColumnMapping("ClinicType", "ClinicType"),
                        new System.Data.Common.DataColumnMapping("EyeClinic", "EyeClinic"),
                        new System.Data.Common.DataColumnMapping("FemaleClinic", "FemaleClinic"),
                        new System.Data.Common.DataColumnMapping("NaturalClinic", "NaturalClinic"),
                        new System.Data.Common.DataColumnMapping("EnName", "EnName"),
                        new System.Data.Common.DataColumnMapping("GeneralClinic", "GeneralClinic"),
                        new System.Data.Common.DataColumnMapping("HeartClinic", "HeartClinic")})});
            this.sqlDataAdapter4.UpdateCommand = this.sqlUpdateCommand1;
            // 
            // sqlDeleteCommand1
            // 
            this.sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
            this.sqlDeleteCommand1.Connection = this.sqlConnection4;
            this.sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ID", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Powred", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ClinicType", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "EyeClinic", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "FemaleClinic", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "NaturalClinic", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_GeneralClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "GeneralClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_GeneralClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "GeneralClinic", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_HeartClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "HeartClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_HeartClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "HeartClinic", System.Data.DataRowVersion.Original, null)});
            // 
            // sqlConnection4
            // 
            this.sqlConnection4.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrat" +
    "ed Security=True;Connect Timeout=30;User Instance=True";
            this.sqlConnection4.FireInfoMessageEventOnUserErrors = false;
            // 
            // sqlInsertCommand4
            // 
            this.sqlInsertCommand4.CommandText = resources.GetString("sqlInsertCommand4.CommandText");
            this.sqlInsertCommand4.Connection = this.sqlConnection4;
            this.sqlInsertCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
            new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
            new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
            new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
            new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
            new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
            new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
            new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
            new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
            new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
            new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
            new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
            new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
            new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
            new System.Data.SqlClient.SqlParameter("@GeneralClinic", System.Data.SqlDbType.Bit, 0, "GeneralClinic"),
            new System.Data.SqlClient.SqlParameter("@HeartClinic", System.Data.SqlDbType.Bit, 0, "HeartClinic")});
            // 
            // sqlSelectCommand4
            // 
            this.sqlSelectCommand4.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
            this.sqlSelectCommand4.Connection = this.sqlConnection4;
            // 
            // sqlUpdateCommand1
            // 
            this.sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
            this.sqlUpdateCommand1.Connection = this.sqlConnection4;
            this.sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
            new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
            new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
            new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
            new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
            new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
            new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
            new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
            new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
            new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
            new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
            new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
            new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
            new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
            new System.Data.SqlClient.SqlParameter("@GeneralClinic", System.Data.SqlDbType.Bit, 0, "GeneralClinic"),
            new System.Data.SqlClient.SqlParameter("@HeartClinic", System.Data.SqlDbType.Bit, 0, "HeartClinic"),
            new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ID", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Powred", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ClinicType", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "EyeClinic", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "FemaleClinic", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "NaturalClinic", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_GeneralClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "GeneralClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_GeneralClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "GeneralClinic", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_HeartClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "HeartClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_HeartClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "HeartClinic", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")});
            // 
            // sqlDataAdapter3
            // 
            this.sqlDataAdapter3.InsertCommand = this.sqlCommand6;
            this.sqlDataAdapter3.SelectCommand = this.sqlCommand7;
            this.sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "PatientAccount", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("ID", "ID"),
                        new System.Data.Common.DataColumnMapping("PatientId", "PatientId"),
                        new System.Data.Common.DataColumnMapping("DoctorID", "DoctorID"),
                        new System.Data.Common.DataColumnMapping("Bean", "Bean"),
                        new System.Data.Common.DataColumnMapping("Price", "Price"),
                        new System.Data.Common.DataColumnMapping("Pay", "Pay"),
                        new System.Data.Common.DataColumnMapping("Date", "Date"),
                        new System.Data.Common.DataColumnMapping("PricePay", "PricePay"),
                        new System.Data.Common.DataColumnMapping("BeanDate", "BeanDate"),
                        new System.Data.Common.DataColumnMapping("TeathId", "TeathId"),
                        new System.Data.Common.DataColumnMapping("Appears", "Appears"),
                        new System.Data.Common.DataColumnMapping("VisitID", "VisitID"),
                        new System.Data.Common.DataColumnMapping("AppointNum", "AppointNum"),
                        new System.Data.Common.DataColumnMapping("Assistant", "Assistant"),
                        new System.Data.Common.DataColumnMapping("StockId", "StockId"),
                        new System.Data.Common.DataColumnMapping("RayId", "RayId"),
                        new System.Data.Common.DataColumnMapping("AnalyzeId", "AnalyzeId"),
                        new System.Data.Common.DataColumnMapping("DiscountValue", "DiscountValue"),
                        new System.Data.Common.DataColumnMapping("ServiceCount", "ServiceCount"),
                        new System.Data.Common.DataColumnMapping("Dariba", "Dariba"),
                        new System.Data.Common.DataColumnMapping("PriceBeforeDariba", "PriceBeforeDariba"),
                        new System.Data.Common.DataColumnMapping("EnterDiscount", "EnterDiscount"),
                        new System.Data.Common.DataColumnMapping("EnterDiscountValue", "EnterDiscountValue"),
                        new System.Data.Common.DataColumnMapping("wieght", "wieght"),
                        new System.Data.Common.DataColumnMapping("OfferNumUsed", "OfferNumUsed"),
                        new System.Data.Common.DataColumnMapping("OfferID", "OfferID"),
                        new System.Data.Common.DataColumnMapping("Freq", "Freq"),
                        new System.Data.Common.DataColumnMapping("Area", "Area")})});
            // 
            // sqlCommand6
            // 
            this.sqlCommand6.CommandText = resources.GetString("sqlCommand6.CommandText");
            this.sqlCommand6.Connection = this.sqlConnection3;
            this.sqlCommand6.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@PatientId", System.Data.SqlDbType.Int, 0, "PatientId"),
            new System.Data.SqlClient.SqlParameter("@DoctorID", System.Data.SqlDbType.Int, 0, "DoctorID"),
            new System.Data.SqlClient.SqlParameter("@Bean", System.Data.SqlDbType.NVarChar, 0, "Bean"),
            new System.Data.SqlClient.SqlParameter("@Price", System.Data.SqlDbType.Money, 0, "Price"),
            new System.Data.SqlClient.SqlParameter("@Pay", System.Data.SqlDbType.Bit, 0, "Pay"),
            new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
            new System.Data.SqlClient.SqlParameter("@PricePay", System.Data.SqlDbType.Money, 0, "PricePay"),
            new System.Data.SqlClient.SqlParameter("@BeanDate", System.Data.SqlDbType.DateTime, 0, "BeanDate"),
            new System.Data.SqlClient.SqlParameter("@TeathId", System.Data.SqlDbType.Int, 0, "TeathId"),
            new System.Data.SqlClient.SqlParameter("@Appears", System.Data.SqlDbType.Bit, 0, "Appears"),
            new System.Data.SqlClient.SqlParameter("@VisitID", System.Data.SqlDbType.Int, 0, "VisitID"),
            new System.Data.SqlClient.SqlParameter("@AppointNum", System.Data.SqlDbType.Int, 0, "AppointNum"),
            new System.Data.SqlClient.SqlParameter("@Assistant", System.Data.SqlDbType.NVarChar, 0, "Assistant"),
            new System.Data.SqlClient.SqlParameter("@StockId", System.Data.SqlDbType.Int, 0, "StockId"),
            new System.Data.SqlClient.SqlParameter("@RayId", System.Data.SqlDbType.Int, 0, "RayId"),
            new System.Data.SqlClient.SqlParameter("@AnalyzeId", System.Data.SqlDbType.Int, 0, "AnalyzeId"),
            new System.Data.SqlClient.SqlParameter("@DiscountValue", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, ((byte)(18)), ((byte)(2)), "DiscountValue", System.Data.DataRowVersion.Current, null),
            new System.Data.SqlClient.SqlParameter("@ServiceCount", System.Data.SqlDbType.Int, 0, "ServiceCount"),
            new System.Data.SqlClient.SqlParameter("@Dariba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, ((byte)(18)), ((byte)(2)), "Dariba", System.Data.DataRowVersion.Current, null),
            new System.Data.SqlClient.SqlParameter("@PriceBeforeDariba", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, ((byte)(18)), ((byte)(2)), "PriceBeforeDariba", System.Data.DataRowVersion.Current, null),
            new System.Data.SqlClient.SqlParameter("@EnterDiscount", System.Data.SqlDbType.NVarChar, 0, "EnterDiscount"),
            new System.Data.SqlClient.SqlParameter("@EnterDiscountValue", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, ((byte)(18)), ((byte)(2)), "EnterDiscountValue", System.Data.DataRowVersion.Current, null),
            new System.Data.SqlClient.SqlParameter("@wieght", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, ((byte)(18)), ((byte)(0)), "wieght", System.Data.DataRowVersion.Current, null),
            new System.Data.SqlClient.SqlParameter("@OfferNumUsed", System.Data.SqlDbType.Int, 0, "OfferNumUsed"),
            new System.Data.SqlClient.SqlParameter("@OfferID", System.Data.SqlDbType.Int, 0, "OfferID"),
            new System.Data.SqlClient.SqlParameter("@Freq", System.Data.SqlDbType.NVarChar, 0, "Freq"),
            new System.Data.SqlClient.SqlParameter("@Area", System.Data.SqlDbType.NVarChar, 0, "Area")});
            // 
            // sqlConnection3
            // 
            this.sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrat" +
    "ed Security=True;Connect Timeout=30;User Instance=True";
            this.sqlConnection3.FireInfoMessageEventOnUserErrors = false;
            // 
            // sqlCommand7
            // 
            this.sqlCommand7.CommandText = "SELECT        PatientAccount.*\r\nFROM            PatientAccount";
            this.sqlCommand7.Connection = this.sqlConnection3;
            // 
            // dataSet11
            // 
            this.dataSet11.DataSetName = "DataSet1";
            this.dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // BeautyClinicRpt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(979, 403);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = true;
            this.Name = "BeautyClinicRpt";
            this.Text = "تقرير كشوفات التجميل";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.BeautyClinicRpt_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).EndInit();
            this.ResumeLayout(false);

		}

		public BeautyClinicRpt()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
		}

		private void BeautyClinicRpt_Load(object sender, EventArgs e)
		{
			DataTable dataTable = new DataTable();
			try
			{
				dataTable = dc.GetTableText("SELECT ID, PName FROM PatientData where Active = 'True' ORDER BY PName");
				gui.loadComboBox(PatientCombo, dataTable);
			}
			catch
			{
			}
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = dc.GetTableText("select * from PatientData where PName='" + PatientCombo.Text + "'");
				if (tableText.Rows.Count > 0)
				{
					sqlConnection1.ConnectionString = dc.ConnectionStr;
					sqlConnection3.ConnectionString = dc.ConnectionStr;
					sqlConnection4.ConnectionString = dc.ConnectionStr;
					dataSet11.Clear();
					DataTable tableText2 = dc.GetTableText("select * from PatientAccount where PatientId='" + Convert.ToInt32(PatientCombo.SelectedValue.ToString()) + "'and ( OfferID <>0 or OfferID <> null)");
					sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
					sqlDataAdapter1.SelectCommand.CommandText = "select * from PatientData where ID='" + Convert.ToInt32(PatientCombo.SelectedValue.ToString()) + "'";
					if (tableText2.Rows.Count > 0)
					{
						sqlDataAdapter3.SelectCommand.CommandType = CommandType.Text;
						sqlDataAdapter3.SelectCommand.CommandText = "select * from PatientAccount where PatientId='" + Convert.ToInt32(PatientCombo.SelectedValue.ToString()) + "'and ( OfferID <>0 or OfferID <> null)";
						sqlDataAdapter4.Fill(dataSet11);
						sqlDataAdapter1.Fill(dataSet11);
						sqlDataAdapter3.Fill(dataSet11);
						BeautyClinicRPT beautyClinicRPT = new BeautyClinicRPT();
						beautyClinicRPT.SetDataSource(dataSet11);
						beautyClinicRPT.SetParameterValue("User", "");
						crystalReportViewer1.ReportSource = beautyClinicRPT;
					}
					else
					{
						crystalReportViewer1.ReportSource = null;
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("No Data");
						}
						else
						{
							MessageBox.Show("لا يوجد بيانات لهذا المريض");
						}
					}
				}
				else
				{
					crystalReportViewer1.ReportSource = null;
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Choose Patient Name");
					}
					else
					{
						MessageBox.Show("من فضلك أختر أسم المريض");
					}
				}
			}
			catch
			{
			}
		}
	}
}
