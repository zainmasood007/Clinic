using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace DentistClinic
{
	public class ChooseNaturalThuory : BaseForm
	{
		private IContainer components = null;

		private Button button26;

		private Button button1;

		private Button button2;

		private string PatientID = "";

		private ClassDataBase dc;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			button26 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			SuspendLayout();
			button26.BackColor = System.Drawing.Color.Gainsboro;
			button26.Cursor = System.Windows.Forms.Cursors.Hand;
			button26.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold);
			button26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			button26.Location = new System.Drawing.Point(54, 57);
			button26.Name = "button26";
			button26.Size = new System.Drawing.Size(247, 31);
			button26.TabIndex = 100;
			button26.Text = "Pediatric  Assessment  ";
			button26.UseVisualStyleBackColor = false;
			button26.Click += new System.EventHandler(button26_Click);
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.Cursor = System.Windows.Forms.Cursors.Hand;
			button1.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold);
			button1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			button1.Location = new System.Drawing.Point(54, 100);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(247, 31);
			button1.TabIndex = 101;
			button1.Text = "Orthopedical – physiotherapy ";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			button2.BackColor = System.Drawing.Color.Gainsboro;
			button2.Cursor = System.Windows.Forms.Cursors.Hand;
			button2.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold);
			button2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			button2.Location = new System.Drawing.Point(54, 145);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(247, 31);
			button2.TabIndex = 102;
			button2.Text = "Neurological – physiotherapy";
			button2.UseVisualStyleBackColor = false;
			button2.Click += new System.EventHandler(button2_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(365, 226);
			base.Controls.Add(button2);
			base.Controls.Add(button1);
			base.Controls.Add(button26);
			base.Name = "ChooseNaturalThuory";
			RightToLeftLayout = true;
			Text = "أختر نوع العلاج الطبيعي";
			base.Load += new System.EventHandler(ChooseNaturalThuory_Load);
			ResumeLayout(false);
		}

		public ChooseNaturalThuory(string ID)
		{
			InitializeComponent();
			PatientID = ID;
			dc = new ClassDataBase(".\\sqlExpress");
		}

		private void button26_Click(object sender, EventArgs e)
		{
			pediatricfrm pediatricfrm2 = new pediatricfrm(PatientID);
			pediatricfrm2.Show();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			OrthopedicalFrm orthopedicalFrm = new OrthopedicalFrm(PatientID);
			orthopedicalFrm.Show();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			gender gender2 = new gender(PatientID);
			gender2.Show();
		}

		private void ChooseNaturalThuory_Load(object sender, EventArgs e)
		{
			DataTable tableText = dc.GetTableText("select * from users where userName ='" + Main.usernames + "'");
			if (!Convert.ToBoolean(tableText.Rows[0]["Pediatric"].ToString()))
			{
				button26.Visible = false;
			}
			if (!Convert.ToBoolean(tableText.Rows[0]["Orthopedical"].ToString()))
			{
				button1.Visible = false;
			}
			if (!Convert.ToBoolean(tableText.Rows[0]["Neurological"].ToString()))
			{
				button2.Visible = false;
			}
		}
	}
}
