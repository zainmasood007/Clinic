using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using FloatTextBox;

namespace DentistClinic
{
	public class IncomingBillFrm : BaseForm
	{
		private dataClass codes;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private IContainer components = null;

		private TextBox billNoTextBox;

		private ComboBox supplierIdComboBox;

		private DateTimePicker billDateDateTimePicker;

		private ComboBox itemIdComboBox;

		private FloatText qntFloatText;

		private FloatText unitPriceFloatText;

		private FloatText sanfDiscountFloatText;

		private FloatText totalPriceFloatText;

		private FloatText billTotalBeforeDiscountFloatText;

		private FloatText discountPerFloatText;

		private FloatText discountAmountFloatText;

		private FloatText billTotAfterDiscountFloatText;

		private FloatText payFloatText;

		private FloatText backeyFloatText;

		private GroupBox groupBox1;

		private GroupBox groupBox2;

		private DataGridView dataGridView1;

		private Button button1;

		private Button button2;

		private Label storeQntLbl;

		private TextBox textBox1;

		private Button button3;

		private Label label69;

		private ComboBox comboBox7;

		private DataGridViewTextBoxColumn ItemId;

		private DataGridViewTextBoxColumn ItName;

		private DataGridViewTextBoxColumn ItQuantity;

		private DataGridViewTextBoxColumn ItUnitPrice;

		private DataGridViewTextBoxColumn ItDiscount;

		private DataGridViewTextBoxColumn ItTot;

		private DataGridViewTextBoxColumn UnitAfter;

		private TextBox textBox2;

		public IncomingBillFrm()
		{
			InitializeComponent();
			codes = new dataClass(".\\sqlExpress");
		}

		public void LoadSupplier()
		{
			try
			{
				DataTable dataTable = codes.Search2("select * from Supplier");
				supplierIdComboBox.DataSource = null;
				supplierIdComboBox.DataSource = dataTable;
				supplierIdComboBox.DisplayMember = dataTable.Columns[1].ToString();
				supplierIdComboBox.ValueMember = dataTable.Columns[0].ToString();
				supplierIdComboBox.SelectedIndex = -1;
			}
			catch
			{
			}
		}

		public void LoadItems()
		{
			try
			{
				DataTable dataTable = codes.Search2("select * from Items");
				itemIdComboBox.DataSource = null;
				itemIdComboBox.DataSource = dataTable;
				itemIdComboBox.DisplayMember = dataTable.Columns[1].ToString();
				itemIdComboBox.ValueMember = dataTable.Columns[0].ToString();
				itemIdComboBox.SelectedIndex = -1;
			}
			catch
			{
			}
		}

		public void Clear()
		{
			payFloatText.TextChanged -= billTotAfterDiscountFloatText_TextChanged;
			billTotAfterDiscountFloatText.TextChanged -= billTotAfterDiscountFloatText_TextChanged;
			discountAmountFloatText.TextChanged -= billTotalBeforeDiscountFloatText_TextChanged;
			discountPerFloatText.Text = "0";
			discountAmountFloatText.Text = "0";
			billTotalBeforeDiscountFloatText.Text = "0";
			billTotAfterDiscountFloatText.Text = "0";
			payFloatText.Text = "0";
			backeyFloatText.Text = "0";
			textBox1.Text = "";
			dataGridView1.Rows.Clear();
			if (billNoTextBox.ReadOnly)
			{
				billNoTextBox.Text = codes.Search2("select isnull(max(BillNo)+1,1) from IncomingBill").Rows[0][0].ToString();
			}
			else
			{
				billNoTextBox.Text = "";
			}
			supplierIdComboBox.SelectedIndex = -1;
			payFloatText.TextChanged += billTotAfterDiscountFloatText_TextChanged;
			billTotAfterDiscountFloatText.TextChanged += billTotAfterDiscountFloatText_TextChanged;
			discountAmountFloatText.TextChanged += billTotalBeforeDiscountFloatText_TextChanged;
		}

		private void IncomingBillFrm_Load(object sender, EventArgs e)
		{
			LoadSupplier();
			LoadItems();
			try
			{
				billNoTextBox.ReadOnly = Convert.ToBoolean(codes.Search2("select IncommingBillNo from Properties").Rows[0][0]);
			}
			catch
			{
			}
			if (billNoTextBox.ReadOnly)
			{
				billNoTextBox.Text = codes.Search2("select isnull(max(BillNo)+1,1) from IncomingBill").Rows[0][0].ToString();
			}
			else
			{
				billNoTextBox.Text = "";
			}
			try
			{
				DataTable dataTable = codes.Search2("select * from users where userName = '" + Main.usernames + "'");
				button3.Visible = Convert.ToBoolean(dataTable.Rows[0]["ItemsFrmBtn"].ToString());
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				comboBox7.DataSource = null;
				comboBox7.DataSource = dataTable2;
				comboBox7.DisplayMember = dataTable2.Columns[1].ToString();
				comboBox7.ValueMember = dataTable2.Columns[0].ToString();
			}
			catch
			{
			}
			unitPriceFloatText.Enabled = UsersClass.ChangeServicePrice;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				decimal num = Convert.ToDecimal(qntFloatText.Text);
				decimal num2 = 0m;
				if (itemIdComboBox.SelectedItem == null)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Choose Correct Item Name");
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم صنف صحيح");
					}
					return;
				}
				if (num == 0m)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Quantity");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل الكمية");
					}
					return;
				}
				int num3 = 0;
				while (true)
				{
					if (num3 < dataGridView1.Rows.Count)
					{
						if (itemIdComboBox.SelectedValue.ToString() == dataGridView1.Rows[num3].Cells[0].Value.ToString())
						{
							break;
						}
						num3++;
						continue;
					}
					dataGridView1.Rows.Add(itemIdComboBox.SelectedValue.ToString(), itemIdComboBox.Text, num, unitPriceFloatText.Text, sanfDiscountFloatText.Text, totalPriceFloatText.Text, (Convert.ToDecimal(totalPriceFloatText.Text) / Convert.ToDecimal(qntFloatText.Text)).ToString());
					for (int i = 0; i < dataGridView1.Rows.Count; i++)
					{
						num2 += Convert.ToDecimal(dataGridView1.Rows[i].Cells[5].Value.ToString());
					}
					billTotalBeforeDiscountFloatText.Text = num2.ToString();
					storeQntLbl.Text = "0";
					itemIdComboBox.SelectedIndex = -1;
					qntFloatText.Text = "0";
					unitPriceFloatText.Text = "0";
					sanfDiscountFloatText.Text = "0";
					totalPriceFloatText.Text = "0";
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("You Have Enter This Item Before");
				}
				else
				{
					MessageBox.Show("هذا الصنف مضاف من قبل");
				}
			}
			catch
			{
			}
		}

		private void itemIdComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				storeQntLbl.Text = "0";
				unitPriceFloatText.Text = "0";
				DataTable dataTable = codes.Search2("select * from Store where ItemId=" + itemIdComboBox.SelectedValue.ToString());
				storeQntLbl.Text = dataTable.Rows[0][2].ToString();
				unitPriceFloatText.Text = dataTable.Rows[0][3].ToString();
				try
				{
					if (itemIdComboBox.Focused)
					{
						textBox2.Text = codes.Search2("select Barcode from Items where Name = '" + itemIdComboBox.Text + "'").Rows[0][0].ToString();
					}
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void qntFloatText_TextChanged(object sender, EventArgs e)
		{
			try
			{
				decimal num = Convert.ToDecimal(qntFloatText.Text);
				decimal num2 = Convert.ToDecimal(unitPriceFloatText.Text);
				decimal num3 = Convert.ToDecimal(sanfDiscountFloatText.Text);
				decimal num4 = num * num2 - num * num2 * num3 / 100m;
				totalPriceFloatText.Text = num4.ToString();
			}
			catch
			{
			}
		}

		private void dataGridView1_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
			try
			{
				decimal num = 0m;
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					num += Convert.ToDecimal(dataGridView1.Rows[i].Cells[5].Value.ToString());
				}
				billTotalBeforeDiscountFloatText.Text = num.ToString();
			}
			catch
			{
			}
		}

		private void billTotalBeforeDiscountFloatText_TextChanged(object sender, EventArgs e)
		{
			try
			{
				decimal num = Convert.ToDecimal(billTotalBeforeDiscountFloatText.Text);
				decimal num2 = Convert.ToDecimal(discountAmountFloatText.Text);
				if (num2 > num)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Discount Amount Must Be Less Than Total Before Discount");
					}
					else
					{
						MessageBox.Show("قيمة الخصم يجب ان تكون اقل من الإجمالي");
					}
					discountAmountFloatText.Text = "0";
				}
				else
				{
					decimal num3 = num - num2;
					billTotAfterDiscountFloatText.Text = num3.ToString();
				}
			}
			catch
			{
			}
		}

		private void discountPerFloatText_TextChanged(object sender, EventArgs e)
		{
			try
			{
				decimal num = Convert.ToDecimal(billTotalBeforeDiscountFloatText.Text);
				decimal num2 = Convert.ToDecimal(discountPerFloatText.Text);
				if (num2 > 100m)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Discount Percent Must Be Less Than 100%");
					}
					else
					{
						MessageBox.Show("نسبة الخصم يجب أن تكون أقل من 100 %");
					}
					discountPerFloatText.Text = "0";
				}
				else
				{
					decimal num3 = num * num2 / 100m;
					discountAmountFloatText.Text = num3.ToString();
				}
			}
			catch
			{
			}
		}

		private void billTotAfterDiscountFloatText_TextChanged(object sender, EventArgs e)
		{
			try
			{
				decimal num = Convert.ToDecimal(payFloatText.Text);
				decimal num2 = Convert.ToDecimal(billTotAfterDiscountFloatText.Text);
				if (num > num2)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Pay Value More Than Total Bill Value After Discount");
					}
					else
					{
						MessageBox.Show("المدفوع اكبر من الإجمالي بعد الخصم");
					}
					payFloatText.Text = "0";
				}
				else
				{
					decimal num3 = num2 - num;
					backeyFloatText.Text = num3.ToString();
				}
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				if (comboBox7.SelectedIndex != -1)
				{
					dataTable = codes.Search2("select Value from Stock where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
				}
				DataTable dataTable2 = codes.Search2("select BillNo from IncomingBill where BillNo='" + billNoTextBox.Text + "'");
				if (billNoTextBox.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Bill Number");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل رقم الفاتورة");
					}
					return;
				}
				if (supplierIdComboBox.SelectedItem == null)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Select Correct Supplier Name");
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم مورد صحيح");
					}
					return;
				}
				if (dataTable2.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Bill Number added Before ");
					}
					else
					{
						MessageBox.Show("رقم الفاتورة مسجل من قبل");
					}
					return;
				}
				if (dataGridView1.Rows.Count == 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Add At Least One Item In Bill ");
					}
					else
					{
						MessageBox.Show("اضف للفاتورة صنف واحد على الأقل");
					}
					return;
				}
				if (comboBox7.SelectedIndex == -1)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Treasury Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الخزينة");
					}
					return;
				}
				if (Convert.ToDecimal(payFloatText.Text) > Convert.ToDecimal(dataTable.Rows[0][0].ToString()))
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Paid more than the amount in the treasury");
					}
					else
					{
						MessageBox.Show("المدفوع أكبر من المبلغ الذى يوجد فى الخزينة");
					}
					return;
				}
				string text = "فاتورة رقم " + billNoTextBox.Text;
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					codes.Add2("INSERT INTO IncomingBill(BillNo, SupplierId, BillDate, ItemId, Qnt, UnitPrice, SanfDiscount, TotalPrice, BillTotalBeforeDiscount, DiscountPer, DiscountAmount, BillTotAfterDiscount, Pay,Backey,Notes,StockId)VALUES('" + billNoTextBox.Text + "','" + supplierIdComboBox.SelectedValue.ToString() + "','" + billDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "','" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[3].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[5].Value.ToString() + "','" + billTotalBeforeDiscountFloatText.Text + "','" + discountPerFloatText.Text + "','" + discountAmountFloatText.Text + "','" + billTotAfterDiscountFloatText.Text + "','" + payFloatText.Text + "','" + backeyFloatText.Text + "','" + textBox1.Text + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
					decimal num = 0m;
					try
					{
						DataTable dataTable3 = codes.Search2("select Qnt from store where ItemID='" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "'");
						num = Convert.ToDecimal(dataTable3.Rows[0][0].ToString());
					}
					catch
					{
					}
					decimal num2 = 0m;
					try
					{
						DataTable dataTable4 = codes.Search2("select BuyPrice from store where ItemID='" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "'");
						num2 = Convert.ToDecimal(dataTable4.Rows[0][0].ToString());
					}
					catch
					{
					}
					decimal num3 = 0m;
					try
					{
						DataTable dataTable5 = codes.Search2("select SalePrice from Items where ID='" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "'");
						num3 = Convert.ToDecimal(dataTable5.Rows[0][0].ToString());
					}
					catch
					{
					}
					codes.Add2("INSERT INTO ItemsMove\r\n                      (ItemId, StoreId, IncomeQnt, IncomePrice, OutcomeQnt, OutcomePrice, LastQnt, LastIncomePrice, LastOutComePrice, Bayan, MoveDate, UserId, Time,Type)\r\n                       VALUES ('" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "',0,'" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[3].Value.ToString() + "',0,'" + num3 + "','" + num + "','" + num2 + "','" + num3 + "','فاتورة مشتريات رقم " + billNoTextBox.Text + "','" + billDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "','" + Main.userId + "','" + billDateDateTimePicker.Value.ToShortTimeString() + "','دخول')");
					DataTable dataTable6 = codes.Search2("select * from Store where  ItemId=" + dataGridView1.Rows[i].Cells[0].Value.ToString());
					codes.Edit2("update store set Qnt=" + (Convert.ToDecimal(dataTable6.Rows[0]["Qnt"].ToString()) + Convert.ToDecimal(dataGridView1.Rows[i].Cells[2].Value.ToString())) + ",BuyPrice=" + dataGridView1.Rows[i].Cells[6].Value.ToString() + " where  ItemId=" + dataGridView1.Rows[i].Cells[0].Value.ToString());
					string text2 = text;
					text = text2 + "\nاسم الصنف: " + dataGridView1.Rows[i].Cells[1].Value.ToString() + " / الكمية: " + Math.Round(Convert.ToDecimal(dataGridView1.Rows[i].Cells[2].Value.ToString()), 2) + " / سعر الوحدة: " + Math.Round(Convert.ToDecimal(dataGridView1.Rows[i].Cells[3].Value.ToString()), 2);
				}
				codes.Edit2("update Stock set [Value] = [Value] - " + Convert.ToDecimal(payFloatText.Text) + " where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
				codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('فاتورة مشتريات' ," + Convert.ToDecimal(payFloatText.Text) + ",'" + supplierIdComboBox.Text + " رقم الفاتورة  " + billNoTextBox.Text + "','" + billDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
				codes.Add2("insert into Discounts (DiscountIn,[Date]) values (" + discountPerFloatText.Text + ",'" + billDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "')");
				codes.Add2("insert into SuppliersMove (BillNo,SupplierID,TotalPriceBeforeDiscount,DiscoutPercent,DiscountValue,TotalPriceAfterDiscount,[Date])values('" + billNoTextBox.Text + "'," + supplierIdComboBox.SelectedValue.ToString() + "," + billTotalBeforeDiscountFloatText.Text + "," + discountPerFloatText.Text + "," + discountAmountFloatText.Text + "," + billTotAfterDiscountFloatText.Text + ",'" + billDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "' )");
				DataTable dataTable7 = codes.Search2("select sum(Daen),sum(Madeen) from Supplier5 where SupplierID=" + supplierIdComboBox.SelectedValue.ToString());
				decimal num4;
				decimal num5;
				try
				{
					num4 = Convert.ToDecimal(dataTable7.Rows[0][0].ToString());
					num5 = Convert.ToDecimal(dataTable7.Rows[0][1].ToString());
				}
				catch
				{
					num4 = 0m;
					num5 = 0m;
				}
				decimal num6 = num4 - num5 + (Convert.ToDecimal(billTotAfterDiscountFloatText.Text) - Convert.ToDecimal(payFloatText.Text));
				codes.Add2("insert into Supplier5 (SupplierId,Daen,Madeen,Raseed,Bayan,[Date]) values (" + supplierIdComboBox.SelectedValue.ToString() + "," + billTotAfterDiscountFloatText.Text + "," + payFloatText.Text + "," + num6 + ",'" + text + "','" + billDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "')");
				codes.Add2("insert into SupplierAccounts (SupplierID,Pay,[Date],Notes)values(" + supplierIdComboBox.SelectedValue.ToString() + "," + payFloatText.Text + ",'" + billDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "','Payeed' )");
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				MethodsClass.UserMove("أضافة فاتوره مشتريات");
				FrmBillIncomeRpt frmBillIncomeRpt = new FrmBillIncomeRpt(billNoTextBox.Text);
				frmBillIncomeRpt.ShowDialog();
				Clear();
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			ItemsFrm itemsFrm = new ItemsFrm();
			itemsFrm.ShowDialog();
			LoadItems();
		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{
			try
			{
				if (textBox2.Focused)
				{
					itemIdComboBox.SelectedValue = codes.Search2("select ID from Items where Barcode = '" + textBox2.Text + "'").Rows[0][0].ToString();
				}
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.IncomingBillFrm));
			billNoTextBox = new System.Windows.Forms.TextBox();
			supplierIdComboBox = new System.Windows.Forms.ComboBox();
			billDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
			itemIdComboBox = new System.Windows.Forms.ComboBox();
			qntFloatText = new FloatTextBox.FloatText();
			unitPriceFloatText = new FloatTextBox.FloatText();
			sanfDiscountFloatText = new FloatTextBox.FloatText();
			totalPriceFloatText = new FloatTextBox.FloatText();
			billTotalBeforeDiscountFloatText = new FloatTextBox.FloatText();
			discountPerFloatText = new FloatTextBox.FloatText();
			discountAmountFloatText = new FloatTextBox.FloatText();
			billTotAfterDiscountFloatText = new FloatTextBox.FloatText();
			payFloatText = new FloatTextBox.FloatText();
			backeyFloatText = new FloatTextBox.FloatText();
			groupBox1 = new System.Windows.Forms.GroupBox();
			label69 = new System.Windows.Forms.Label();
			comboBox7 = new System.Windows.Forms.ComboBox();
			textBox1 = new System.Windows.Forms.TextBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			textBox2 = new System.Windows.Forms.TextBox();
			button3 = new System.Windows.Forms.Button();
			storeQntLbl = new System.Windows.Forms.Label();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			ItemId = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ItName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ItQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ItUnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ItDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ItTot = new System.Windows.Forms.DataGridViewTextBoxColumn();
			UnitAfter = new System.Windows.Forms.DataGridViewTextBoxColumn();
			button1 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label7 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label8 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label9 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label10 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label11 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label12 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label13 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label14 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label15 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label16 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label17 = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "billNoLabel");
			label.ForeColor = System.Drawing.Color.White;
			label.Name = "billNoLabel";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "supplierIdLabel");
			label2.ForeColor = System.Drawing.Color.White;
			label2.Name = "supplierIdLabel";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "billDateLabel");
			label3.ForeColor = System.Drawing.Color.White;
			label3.Name = "billDateLabel";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "itemIdLabel");
			label4.ForeColor = System.Drawing.Color.White;
			label4.Name = "itemIdLabel";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "qntLabel");
			label5.ForeColor = System.Drawing.Color.White;
			label5.Name = "qntLabel";
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "unitPriceLabel");
			label6.ForeColor = System.Drawing.Color.White;
			label6.Name = "unitPriceLabel";
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "sanfDiscountLabel");
			label7.ForeColor = System.Drawing.Color.White;
			label7.Name = "sanfDiscountLabel";
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "totalPriceLabel");
			label8.ForeColor = System.Drawing.Color.White;
			label8.Name = "totalPriceLabel";
			label9.AccessibleDescription = null;
			label9.AccessibleName = null;
			resources.ApplyResources(label9, "billTotalBeforeDiscountLabel");
			label9.ForeColor = System.Drawing.Color.White;
			label9.Name = "billTotalBeforeDiscountLabel";
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "discountPerLabel");
			label10.ForeColor = System.Drawing.Color.White;
			label10.Name = "discountPerLabel";
			label11.AccessibleDescription = null;
			label11.AccessibleName = null;
			resources.ApplyResources(label11, "discountAmountLabel");
			label11.ForeColor = System.Drawing.Color.White;
			label11.Name = "discountAmountLabel";
			label12.AccessibleDescription = null;
			label12.AccessibleName = null;
			resources.ApplyResources(label12, "billTotAfterDiscountLabel");
			label12.ForeColor = System.Drawing.Color.White;
			label12.Name = "billTotAfterDiscountLabel";
			label13.AccessibleDescription = null;
			label13.AccessibleName = null;
			resources.ApplyResources(label13, "payLabel");
			label13.ForeColor = System.Drawing.Color.White;
			label13.Name = "payLabel";
			label14.AccessibleDescription = null;
			label14.AccessibleName = null;
			resources.ApplyResources(label14, "backeyLabel");
			label14.ForeColor = System.Drawing.Color.White;
			label14.Name = "backeyLabel";
			label15.AccessibleDescription = null;
			label15.AccessibleName = null;
			resources.ApplyResources(label15, "label1");
			label15.ForeColor = System.Drawing.Color.White;
			label15.Name = "label1";
			label16.AccessibleDescription = null;
			label16.AccessibleName = null;
			resources.ApplyResources(label16, "label2");
			label16.ForeColor = System.Drawing.Color.White;
			label16.Name = "label2";
			label17.AccessibleDescription = null;
			label17.AccessibleName = null;
			resources.ApplyResources(label17, "label3");
			label17.ForeColor = System.Drawing.Color.White;
			label17.Name = "label3";
			billNoTextBox.AccessibleDescription = null;
			billNoTextBox.AccessibleName = null;
			resources.ApplyResources(billNoTextBox, "billNoTextBox");
			billNoTextBox.BackgroundImage = null;
			billNoTextBox.Font = null;
			billNoTextBox.Name = "billNoTextBox";
			supplierIdComboBox.AccessibleDescription = null;
			supplierIdComboBox.AccessibleName = null;
			resources.ApplyResources(supplierIdComboBox, "supplierIdComboBox");
			supplierIdComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			supplierIdComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			supplierIdComboBox.BackgroundImage = null;
			supplierIdComboBox.Font = null;
			supplierIdComboBox.FormattingEnabled = true;
			supplierIdComboBox.Name = "supplierIdComboBox";
			billDateDateTimePicker.AccessibleDescription = null;
			billDateDateTimePicker.AccessibleName = null;
			resources.ApplyResources(billDateDateTimePicker, "billDateDateTimePicker");
			billDateDateTimePicker.BackgroundImage = null;
			billDateDateTimePicker.CalendarFont = null;
			billDateDateTimePicker.Font = null;
			billDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			billDateDateTimePicker.Name = "billDateDateTimePicker";
			itemIdComboBox.AccessibleDescription = null;
			itemIdComboBox.AccessibleName = null;
			resources.ApplyResources(itemIdComboBox, "itemIdComboBox");
			itemIdComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			itemIdComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			itemIdComboBox.BackgroundImage = null;
			itemIdComboBox.Font = null;
			itemIdComboBox.FormattingEnabled = true;
			itemIdComboBox.Name = "itemIdComboBox";
			itemIdComboBox.SelectedIndexChanged += new System.EventHandler(itemIdComboBox_SelectedIndexChanged);
			qntFloatText.AccessibleDescription = null;
			qntFloatText.AccessibleName = null;
			resources.ApplyResources(qntFloatText, "qntFloatText");
			qntFloatText.BackgroundImage = null;
			qntFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			qntFloatText.Font = null;
			qntFloatText.Name = "qntFloatText";
			qntFloatText.TextChanged += new System.EventHandler(qntFloatText_TextChanged);
			unitPriceFloatText.AccessibleDescription = null;
			unitPriceFloatText.AccessibleName = null;
			resources.ApplyResources(unitPriceFloatText, "unitPriceFloatText");
			unitPriceFloatText.BackgroundImage = null;
			unitPriceFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			unitPriceFloatText.Font = null;
			unitPriceFloatText.Name = "unitPriceFloatText";
			unitPriceFloatText.TextChanged += new System.EventHandler(qntFloatText_TextChanged);
			sanfDiscountFloatText.AccessibleDescription = null;
			sanfDiscountFloatText.AccessibleName = null;
			resources.ApplyResources(sanfDiscountFloatText, "sanfDiscountFloatText");
			sanfDiscountFloatText.BackgroundImage = null;
			sanfDiscountFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			sanfDiscountFloatText.Font = null;
			sanfDiscountFloatText.Name = "sanfDiscountFloatText";
			sanfDiscountFloatText.TextChanged += new System.EventHandler(qntFloatText_TextChanged);
			totalPriceFloatText.AccessibleDescription = null;
			totalPriceFloatText.AccessibleName = null;
			resources.ApplyResources(totalPriceFloatText, "totalPriceFloatText");
			totalPriceFloatText.BackgroundImage = null;
			totalPriceFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			totalPriceFloatText.Font = null;
			totalPriceFloatText.Name = "totalPriceFloatText";
			billTotalBeforeDiscountFloatText.AccessibleDescription = null;
			billTotalBeforeDiscountFloatText.AccessibleName = null;
			resources.ApplyResources(billTotalBeforeDiscountFloatText, "billTotalBeforeDiscountFloatText");
			billTotalBeforeDiscountFloatText.BackgroundImage = null;
			billTotalBeforeDiscountFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			billTotalBeforeDiscountFloatText.Font = null;
			billTotalBeforeDiscountFloatText.Name = "billTotalBeforeDiscountFloatText";
			billTotalBeforeDiscountFloatText.TextChanged += new System.EventHandler(billTotalBeforeDiscountFloatText_TextChanged);
			discountPerFloatText.AccessibleDescription = null;
			discountPerFloatText.AccessibleName = null;
			resources.ApplyResources(discountPerFloatText, "discountPerFloatText");
			discountPerFloatText.BackgroundImage = null;
			discountPerFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			discountPerFloatText.Font = null;
			discountPerFloatText.Name = "discountPerFloatText";
			discountPerFloatText.TextChanged += new System.EventHandler(discountPerFloatText_TextChanged);
			discountAmountFloatText.AccessibleDescription = null;
			discountAmountFloatText.AccessibleName = null;
			resources.ApplyResources(discountAmountFloatText, "discountAmountFloatText");
			discountAmountFloatText.BackgroundImage = null;
			discountAmountFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			discountAmountFloatText.Font = null;
			discountAmountFloatText.Name = "discountAmountFloatText";
			discountAmountFloatText.TextChanged += new System.EventHandler(billTotalBeforeDiscountFloatText_TextChanged);
			billTotAfterDiscountFloatText.AccessibleDescription = null;
			billTotAfterDiscountFloatText.AccessibleName = null;
			resources.ApplyResources(billTotAfterDiscountFloatText, "billTotAfterDiscountFloatText");
			billTotAfterDiscountFloatText.BackgroundImage = null;
			billTotAfterDiscountFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			billTotAfterDiscountFloatText.Font = null;
			billTotAfterDiscountFloatText.Name = "billTotAfterDiscountFloatText";
			billTotAfterDiscountFloatText.TextChanged += new System.EventHandler(billTotAfterDiscountFloatText_TextChanged);
			payFloatText.AccessibleDescription = null;
			payFloatText.AccessibleName = null;
			resources.ApplyResources(payFloatText, "payFloatText");
			payFloatText.BackgroundImage = null;
			payFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			payFloatText.Font = null;
			payFloatText.Name = "payFloatText";
			payFloatText.TextChanged += new System.EventHandler(billTotAfterDiscountFloatText_TextChanged);
			backeyFloatText.AccessibleDescription = null;
			backeyFloatText.AccessibleName = null;
			resources.ApplyResources(backeyFloatText, "backeyFloatText");
			backeyFloatText.BackgroundImage = null;
			backeyFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			backeyFloatText.Font = null;
			backeyFloatText.Name = "backeyFloatText";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(label69);
			groupBox1.Controls.Add(comboBox7);
			groupBox1.Controls.Add(textBox1);
			groupBox1.Controls.Add(label16);
			groupBox1.Controls.Add(billNoTextBox);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(label);
			groupBox1.Controls.Add(supplierIdComboBox);
			groupBox1.Controls.Add(billDateDateTimePicker);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(billTotalBeforeDiscountFloatText);
			groupBox1.Controls.Add(billTotAfterDiscountFloatText);
			groupBox1.Controls.Add(label12);
			groupBox1.Controls.Add(discountAmountFloatText);
			groupBox1.Controls.Add(label11);
			groupBox1.Controls.Add(label13);
			groupBox1.Controls.Add(label9);
			groupBox1.Controls.Add(payFloatText);
			groupBox1.Controls.Add(label14);
			groupBox1.Controls.Add(discountPerFloatText);
			groupBox1.Controls.Add(backeyFloatText);
			groupBox1.Controls.Add(label10);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			label69.AccessibleDescription = null;
			label69.AccessibleName = null;
			resources.ApplyResources(label69, "label69");
			label69.BackColor = System.Drawing.Color.Transparent;
			label69.ForeColor = System.Drawing.Color.White;
			label69.Name = "label69";
			comboBox7.AccessibleDescription = null;
			comboBox7.AccessibleName = null;
			resources.ApplyResources(comboBox7, "comboBox7");
			comboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox7.BackgroundImage = null;
			comboBox7.FormattingEnabled = true;
			comboBox7.Name = "comboBox7";
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Font = null;
			textBox1.Name = "textBox1";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(textBox2);
			groupBox2.Controls.Add(label17);
			groupBox2.Controls.Add(button3);
			groupBox2.Controls.Add(storeQntLbl);
			groupBox2.Controls.Add(label15);
			groupBox2.Controls.Add(dataGridView1);
			groupBox2.Controls.Add(button1);
			groupBox2.Controls.Add(itemIdComboBox);
			groupBox2.Controls.Add(label4);
			groupBox2.Controls.Add(label6);
			groupBox2.Controls.Add(label5);
			groupBox2.Controls.Add(unitPriceFloatText);
			groupBox2.Controls.Add(label7);
			groupBox2.Controls.Add(qntFloatText);
			groupBox2.Controls.Add(sanfDiscountFloatText);
			groupBox2.Controls.Add(totalPriceFloatText);
			groupBox2.Controls.Add(label8);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			textBox2.AccessibleDescription = null;
			textBox2.AccessibleName = null;
			resources.ApplyResources(textBox2, "textBox2");
			textBox2.BackgroundImage = null;
			textBox2.Font = null;
			textBox2.Name = "textBox2";
			textBox2.TextChanged += new System.EventHandler(textBox2_TextChanged);
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackColor = System.Drawing.Color.Gainsboro;
			button3.BackgroundImage = null;
			button3.Font = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = false;
			button3.Click += new System.EventHandler(button3_Click);
			storeQntLbl.AccessibleDescription = null;
			storeQntLbl.AccessibleName = null;
			resources.ApplyResources(storeQntLbl, "storeQntLbl");
			storeQntLbl.Font = null;
			storeQntLbl.Name = "storeQntLbl";
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(ItemId, ItName, ItQuantity, ItUnitPrice, ItDiscount, ItTot, UnitAfter);
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(dataGridView1_RowsRemoved);
			resources.ApplyResources(ItemId, "ItemId");
			ItemId.Name = "ItemId";
			ItemId.ReadOnly = true;
			resources.ApplyResources(ItName, "ItName");
			ItName.Name = "ItName";
			ItName.ReadOnly = true;
			resources.ApplyResources(ItQuantity, "ItQuantity");
			ItQuantity.Name = "ItQuantity";
			ItQuantity.ReadOnly = true;
			resources.ApplyResources(ItUnitPrice, "ItUnitPrice");
			ItUnitPrice.Name = "ItUnitPrice";
			ItUnitPrice.ReadOnly = true;
			resources.ApplyResources(ItDiscount, "ItDiscount");
			ItDiscount.Name = "ItDiscount";
			ItDiscount.ReadOnly = true;
			resources.ApplyResources(ItTot, "ItTot");
			ItTot.Name = "ItTot";
			ItTot.ReadOnly = true;
			resources.ApplyResources(UnitAfter, "UnitAfter");
			UnitAfter.Name = "UnitAfter";
			UnitAfter.ReadOnly = true;
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackColor = System.Drawing.Color.Gainsboro;
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = false;
			button2.Click += new System.EventHandler(button2_Click);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(button2);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.MaximizeBox = true;
			base.Name = "IncomingBillFrm";
			base.Load += new System.EventHandler(IncomingBillFrm_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
		}
	}
}
