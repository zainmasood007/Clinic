using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmReBackPrice : BaseForm
	{
		private IContainer components = null;

		private Label label1;

		private TextBox priceTextBox;

		private Button saveBtn;

		private GroupBox groupBox1;

		private DateTimePicker appdateTimePicker1;

		private string patientname;

		private int appointid;

		private ClassDataBase dc;

		private dataClass codes;

		private GUI gui = new GUI();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmReBackPrice));
			label1 = new System.Windows.Forms.Label();
			priceTextBox = new System.Windows.Forms.TextBox();
			saveBtn = new System.Windows.Forms.Button();
			groupBox1 = new System.Windows.Forms.GroupBox();
			appdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			groupBox1.SuspendLayout();
			SuspendLayout();
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			priceTextBox.AccessibleDescription = null;
			priceTextBox.AccessibleName = null;
			resources.ApplyResources(priceTextBox, "priceTextBox");
			priceTextBox.BackgroundImage = null;
			priceTextBox.Name = "priceTextBox";
			priceTextBox.Leave += new System.EventHandler(priceTextBox_Leave);
			priceTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(priceTextBox_KeyPress);
			saveBtn.AccessibleDescription = null;
			saveBtn.AccessibleName = null;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			saveBtn.BackgroundImage = null;
			saveBtn.Name = "saveBtn";
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(priceTextBox);
			groupBox1.Controls.Add(saveBtn);
			groupBox1.Controls.Add(label1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			appdateTimePicker1.AccessibleDescription = null;
			appdateTimePicker1.AccessibleName = null;
			resources.ApplyResources(appdateTimePicker1, "appdateTimePicker1");
			appdateTimePicker1.BackgroundImage = null;
			appdateTimePicker1.CalendarFont = null;
			appdateTimePicker1.Font = null;
			appdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			appdateTimePicker1.Name = "appdateTimePicker1";
			base.AcceptButton = saveBtn;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(appdateTimePicker1);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FrmReBackPrice";
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(FrmReBackPrice_KeyDown);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			ResumeLayout(false);
		}

		public FrmReBackPrice(string PATIENTName, int AppointID)
		{
			patientname = PATIENTName;
			appointid = AppointID;
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
			InitializeComponent();
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = dc.GetTableText("select packprice from Appointments where ID = " + appointid);
				double num = Convert.ToDouble(dataTable.Rows[0][0].ToString());
				double num2 = Convert.ToDouble(priceTextBox.Text);
				string[] fields = new string[2] { "ID", "packprice" };
				DataTable tableText = dc.GetTableText("select Price,PricePay,StockId from PatientAccount where AppointNum= " + appointid);
				if (Convert.ToDecimal(tableText.Rows[0][1].ToString()) != 0m)
				{
					if (Convert.ToDouble(tableText.Rows[0][1].ToString()) < num2)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Can not return money more than patient paied before", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("لا يمكن إرجاع نقود أكثر من المبلغ الذي دفعه المريض سابقا", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else if (dc.Update("updateAppointPackPrice", fields, appointid, priceTextBox.Text))
					{
						DataTable dataTable2 = new DataTable();
						dataTable2 = dc.GetTableText("select * from Stock where ID=" + tableText.Rows[0][2].ToString());
						double num3 = Convert.ToDouble(dataTable2.Rows[0][1].ToString());
						double num4 = num3 - num2 + num;
						codes.Edit2("update Stock Set Value=" + num4 + " where ID = '" + tableText.Rows[0][2].ToString() + "'");
						double num5 = num2 - num;
						codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('إعادة كشف' ," + num5 + ",'" + patientname.ToString() + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + tableText.Rows[0][2].ToString() + "')");
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						Close();
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء الحفظ", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Can not return money because patient did not pay for this service before");
				}
				else
				{
					MessageBox.Show("لا يمكن أرجاع النقود لان هذا المريض لم يدفع لهذه الخدمة من قبل");
				}
			}
			catch
			{
			}
		}

		private void priceTextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && priceTextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل ارقام فقط");
				}
				e.Handled = true;
			}
			catch
			{
			}
		}

		private void priceTextBox_Leave(object sender, EventArgs e)
		{
			try
			{
				if (priceTextBox.Text == "")
				{
					priceTextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void FrmReBackPrice_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}
	}
}
