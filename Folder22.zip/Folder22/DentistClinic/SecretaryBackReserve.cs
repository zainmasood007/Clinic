using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class SecretaryBackReserve : BaseForm
	{
		private ClassDataBase dc;

		private GUI gui = new GUI();

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		private IContainer components = null;

		private GroupBox groupBox2;

		private Button searchBtn;

		private Label label2;

		private ComboBox doctorcomboBox;

		private Label label1;

		private DateTimePicker dateTimePicker1;

		private Label label3;

		private Timer timer1;

		private DataGridView dataGridView1;

		private GroupBox groupBox1;

		private Label label4;

		private DataGridViewTextBoxColumn ID;

		private DataGridViewTextBoxColumn AppointNum;

		private DataGridViewTextBoxColumn DoctorId;

		private DataGridViewTextBoxColumn PatientId;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Title;

		private DataGridViewTextBoxColumn PName;

		private DataGridViewTextBoxColumn PAddress;

		private DataGridViewTextBoxColumn BirthDate;

		private DataGridViewTextBoxColumn LastVistDate;

		private new DataGridViewTextBoxColumn CompanyName;

		private DataGridViewButtonColumn PackDate;

		private DataGridViewButtonColumn Appointment;

		private DataGridViewButtonColumn Done;

		private DataGridViewButtonColumn Detect;

		public SecretaryBackReserve()
		{
			dc = new ClassDataBase(".\\sqlExpress");
			InitializeComponent();
		}

		public void DataGrid()
		{
			dataGridView1.Columns["PName"].Width = 150;
			dataGridView1.Columns[1].Width = 100;
			dataGridView1.Columns["Doctor ID"].Visible = false;
			dataGridView1.Columns["Patient ID"].Visible = false;
			dataGridView1.Columns["PAddress"].Width = 200;
			DataGridViewButtonColumn dataGridViewButtonColumn = new DataGridViewButtonColumn();
			dataGridView1.Columns.Add(dataGridViewButtonColumn);
			dataGridViewButtonColumn.HeaderText = "تعديل الميعاد";
			dataGridViewButtonColumn.Text = "تعديل الميعاد";
			dataGridViewButtonColumn.Name = "PackDate";
			DataGridViewButtonColumn dataGridViewButtonColumn2 = new DataGridViewButtonColumn();
			dataGridView1.Columns.Add(dataGridViewButtonColumn2);
			dataGridViewButtonColumn2.HeaderText = "التحويل الى الحجز";
			dataGridViewButtonColumn2.Text = "التحويل الى الحجز";
			dataGridViewButtonColumn2.Name = "Appointment";
			DataGridViewButtonColumn dataGridViewButtonColumn3 = new DataGridViewButtonColumn();
			dataGridView1.Columns.Add(dataGridViewButtonColumn3);
			dataGridViewButtonColumn3.HeaderText = "التحويل الى الكشف";
			dataGridViewButtonColumn3.Text = "الكشف السريع";
			dataGridViewButtonColumn3.Name = "Detect";
			dataGridView1.Columns["Status"].Visible = false;
			foreach (DataGridViewRow item in (IEnumerable)dataGridView1.Rows)
			{
				if (item.Cells["Status"].Value.ToString() == "تم التأكيد")
				{
					item.DefaultCellStyle.BackColor = Color.FromArgb(187, 240, 188);
				}
				else if (item.Cells["Status"].Value.ToString() == "لم يؤكد")
				{
					item.DefaultCellStyle.BackColor = Color.FromArgb(201, 226, 245);
				}
				else if (item.Cells["Status"].Value.ToString() == "تم إلغاؤه")
				{
					item.DefaultCellStyle.BackColor = Color.FromArgb(240, 209, 200);
				}
			}
			dataGridView1.Columns[10].Visible = false;
			dataGridView1.Columns[11].Visible = false;
			dataGridView1.Columns[12].Visible = false;
			dataGridView1.Columns[13].Visible = false;
			dataGridView1.Columns[14].Visible = false;
			dataGridView1.Columns[15].Visible = false;
			dataGridView1.Columns[16].Visible = false;
			dataGridView1.Columns[17].Visible = false;
			dataGridView1.Columns[18].Visible = false;
			dataGridView1.Columns[19].Visible = false;
			dataGridView1.Columns[20].Visible = false;
			dataGridView1.Columns[21].Visible = false;
			dataGridView1.Columns[22].Visible = false;
			dataGridView1.Columns[23].Visible = false;
			dataGridView1.Columns[24].Visible = false;
			dataGridView1.Columns[25].Visible = false;
			dataGridView1.Columns[26].Visible = false;
			dataGridView1.Columns[27].Visible = false;
			dataGridView1.Columns[28].Visible = false;
			dataGridView1.Columns[29].Visible = false;
			dataGridView1.Columns[30].Visible = false;
			dataGridView1.Columns[31].Visible = false;
			dataGridView1.Columns[32].Visible = false;
			dataGridView1.Columns[33].Visible = false;
			dataGridView1.Columns[34].Visible = false;
		}

		public void Doctor()
		{
			try
			{
				dataGridView1.Rows.Clear();
				string[] array = new string[2] { "ID", "detectDate" };
				DataTable dataTable = Codes.Search2("SELECT     dbo.Appointments.ID, dbo.Appointments.AppointNum, dbo.Empdata.ID AS 'Doctor ID', dbo.PatientData.ID AS 'Patient ID',PatientData.FileNo, dbo.PatientData.Titel, dbo.PatientData.PName, \r\n                      dbo.PatientData.PAddress, dbo.PatientData.BirthDate, dbo.PatientData.LastVistDate, dbo.Company.Name\r\nFROM         dbo.PatientData INNER JOIN\r\n                      dbo.Company ON dbo.PatientData.company = dbo.Company.ID INNER JOIN\r\n                      dbo.Empdata INNER JOIN\r\n                      dbo.Appointments ON dbo.Empdata.ID = dbo.Appointments.DoctorID ON dbo.PatientData.ID = dbo.Appointments.PatuentID\r\nWHERE     (Empdata.ID = '" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "') AND (Appointments.packDate = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "') AND (Appointments.PackDone = 'false') GROUP BY dbo.Appointments.ID, dbo.Appointments.AppointNum, dbo.Empdata.ID, dbo.PatientData.ID,PatientData.FileNo, dbo.PatientData.Titel, dbo.PatientData.PName, dbo.PatientData.PAddress, dbo.PatientData.BirthDate, dbo.PatientData.LastVistDate, dbo.Company.Name");
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					if (Settings.Default.Language == "en-GB")
					{
						dataGridView1.Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString(), dataTable.Rows[i][4].ToString(), dataTable.Rows[i][5].ToString(), dataTable.Rows[i][6].ToString(), dataTable.Rows[i][7].ToString(), Convert.ToDateTime(dataTable.Rows[i][8].ToString()), Convert.ToDateTime(dataTable.Rows[i][9].ToString()), dataTable.Rows[i][10].ToString(), "Update Date", "Transfer to Appointment", "Reserve Done", "Quick Detection");
					}
					else
					{
						dataGridView1.Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString(), dataTable.Rows[i][4].ToString(), dataTable.Rows[i][5].ToString(), dataTable.Rows[i][6].ToString(), dataTable.Rows[i][7].ToString(), Convert.ToDateTime(dataTable.Rows[i][8].ToString()), Convert.ToDateTime(dataTable.Rows[i][9].ToString()), dataTable.Rows[i][10].ToString(), "تعديل الميعاد", "التحويل الى الحجز", "تم الحجز", "الكشف السريع");
					}
				}
				if (dataGridView1.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						label3.Text = "Number Of Reservations: " + Convert.ToString(dataGridView1.Rows.Count.ToString());
						label4.Text = "Patient Name:" + Convert.ToString(dataTable.Rows[0]["PName"].ToString());
					}
					else
					{
						label3.Text = "عدد الحجوزات : " + Convert.ToString(dataGridView1.Rows.Count.ToString());
						label4.Text = "اسم المريض :" + Convert.ToString(dataTable.Rows[0]["PName"].ToString());
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					label3.Text = "No Reservation";
					label4.Text = "";
				}
				else
				{
					label3.Text = "لا يوجد حجز";
					label4.Text = "";
				}
			}
			catch
			{
			}
		}

		private void SecretaryBackReserve_Load(object sender, EventArgs e)
		{
			MethodsClass.UserMove("الدخول الي قائمه اعادة الكشف");
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = dc.Select("SelectAllDoctor");
				gui.loadComboBox(doctorcomboBox, dataTable);
			}
			catch
			{
			}
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			Doctor();
		}

		private void searchBtn_Click(object sender, EventArgs e)
		{
			Doctor();
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				FrmReBackPrice frmReBackPrice = new FrmReBackPrice(dataGridView1.CurrentRow.Cells[5].Value.ToString(), int.Parse(dataGridView1.CurrentRow.Cells[0].Value.ToString()));
				frmReBackPrice.ShowDialog();
			}
			catch
			{
			}
		}

		private void SecretaryBackReserve_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			try
			{
				if (dataGridView1.CurrentCell.OwningColumn.Name == "PackDate")
				{
					FrmDate frmDate = new FrmDate(dataGridView1.CurrentRow.Cells[0].Value.ToString());
					frmDate.ShowDialog();
					Doctor();
				}
				if (dataGridView1.CurrentCell.OwningColumn.Name == "Appointment")
				{
					Appointments appointments = new Appointments(dataGridView1.CurrentRow.Cells["PName"].Value.ToString());
					appointments.ShowDialog();
				}
				if (dataGridView1.CurrentCell.OwningColumn.Name == "Done")
				{
					try
					{
						Codes.Edit2("update Appointments set PackDone = 1 where ID = '" + dataGridView1.CurrentRow.Cells["ID"].Value.ToString() + "'");
					}
					catch
					{
					}
					Doctor();
				}
				if (dataGridView1.CurrentCell.OwningColumn.Name == "Detect")
				{
					PatientAccountSecretaryFrm patientAccountSecretaryFrm = new PatientAccountSecretaryFrm(Convert.ToInt32(dataGridView1.CurrentRow.Cells["PatientId"].Value.ToString()), Convert.ToInt32(dataGridView1.CurrentRow.Cells["DoctorId"].Value.ToString()));
					patientAccountSecretaryFrm.ShowDialog();
				}
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.SecretaryBackReserve));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			groupBox2 = new System.Windows.Forms.GroupBox();
			searchBtn = new System.Windows.Forms.Button();
			label2 = new System.Windows.Forms.Label();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			label1 = new System.Windows.Forms.Label();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label3 = new System.Windows.Forms.Label();
			timer1 = new System.Windows.Forms.Timer(components);
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox1 = new System.Windows.Forms.GroupBox();
			label4 = new System.Windows.Forms.Label();
			ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			AppointNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
			DoctorId = new System.Windows.Forms.DataGridViewTextBoxColumn();
			PatientId = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Title = new System.Windows.Forms.DataGridViewTextBoxColumn();
			PName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			PAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
			BirthDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
			LastVistDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
			CompanyName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			PackDate = new System.Windows.Forms.DataGridViewButtonColumn();
			Appointment = new System.Windows.Forms.DataGridViewButtonColumn();
			Done = new System.Windows.Forms.DataGridViewButtonColumn();
			Detect = new System.Windows.Forms.DataGridViewButtonColumn();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox1.SuspendLayout();
			SuspendLayout();
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(searchBtn);
			groupBox2.Controls.Add(label2);
			groupBox2.Controls.Add(doctorcomboBox);
			groupBox2.Controls.Add(label1);
			groupBox2.Controls.Add(dateTimePicker1);
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			searchBtn.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(searchBtn, "searchBtn");
			searchBtn.Name = "searchBtn";
			searchBtn.UseVisualStyleBackColor = false;
			searchBtn.Click += new System.EventHandler(searchBtn_Click);
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.FormattingEnabled = true;
			resources.ApplyResources(doctorcomboBox, "doctorcomboBox");
			doctorcomboBox.Name = "doctorcomboBox";
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			resources.ApplyResources(label3, "label3");
			label3.BackColor = System.Drawing.Color.Transparent;
			label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			label3.ForeColor = System.Drawing.Color.Maroon;
			label3.Name = "label3";
			timer1.Enabled = true;
			timer1.Interval = 3000;
			timer1.Tick += new System.EventHandler(timer1_Tick);
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(ID, AppointNum, DoctorId, PatientId, Column1, Title, PName, PAddress, BirthDate, LastVistDate, CompanyName, PackDate, Appointment, Done, Detect);
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowTemplate.Height = 30;
			dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(dataGridView1_CellClick);
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(dataGridView1);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			resources.ApplyResources(label4, "label4");
			label4.BackColor = System.Drawing.Color.Transparent;
			label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			label4.ForeColor = System.Drawing.Color.Maroon;
			label4.Name = "label4";
			resources.ApplyResources(ID, "ID");
			ID.Name = "ID";
			ID.ReadOnly = true;
			resources.ApplyResources(AppointNum, "AppointNum");
			AppointNum.Name = "AppointNum";
			AppointNum.ReadOnly = true;
			resources.ApplyResources(DoctorId, "DoctorId");
			DoctorId.Name = "DoctorId";
			DoctorId.ReadOnly = true;
			resources.ApplyResources(PatientId, "PatientId");
			PatientId.Name = "PatientId";
			PatientId.ReadOnly = true;
			resources.ApplyResources(Column1, "Column1");
			Column1.Name = "Column1";
			Column1.ReadOnly = true;
			resources.ApplyResources(Title, "Title");
			Title.Name = "Title";
			Title.ReadOnly = true;
			resources.ApplyResources(PName, "PName");
			PName.Name = "PName";
			PName.ReadOnly = true;
			resources.ApplyResources(PAddress, "PAddress");
			PAddress.Name = "PAddress";
			PAddress.ReadOnly = true;
			dataGridViewCellStyle.Format = "d";
			dataGridViewCellStyle.NullValue = null;
			BirthDate.DefaultCellStyle = dataGridViewCellStyle;
			resources.ApplyResources(BirthDate, "BirthDate");
			BirthDate.Name = "BirthDate";
			BirthDate.ReadOnly = true;
			dataGridViewCellStyle2.Format = "d";
			dataGridViewCellStyle2.NullValue = null;
			LastVistDate.DefaultCellStyle = dataGridViewCellStyle2;
			resources.ApplyResources(LastVistDate, "LastVistDate");
			LastVistDate.Name = "LastVistDate";
			LastVistDate.ReadOnly = true;
			resources.ApplyResources(CompanyName, "CompanyName");
			CompanyName.Name = "CompanyName";
			CompanyName.ReadOnly = true;
			resources.ApplyResources(PackDate, "PackDate");
			PackDate.Name = "PackDate";
			PackDate.ReadOnly = true;
			PackDate.Text = "تعديل الميعاد";
			resources.ApplyResources(Appointment, "Appointment");
			Appointment.Name = "Appointment";
			Appointment.ReadOnly = true;
			Appointment.Text = "حجز مريض";
			resources.ApplyResources(Done, "Done");
			Done.Name = "Done";
			Done.ReadOnly = true;
			Done.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			Done.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
			resources.ApplyResources(Detect, "Detect");
			Detect.Name = "Detect";
			Detect.ReadOnly = true;
			Detect.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			Detect.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			base.Controls.Add(groupBox2);
			base.Controls.Add(label3);
			base.Controls.Add(groupBox1);
			base.Controls.Add(label4);
			base.Name = "SecretaryBackReserve";
			base.Load += new System.EventHandler(SecretaryBackReserve_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(SecretaryBackReserve_KeyDown);
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox1.ResumeLayout(false);
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
