using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Properties;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class NetDailyClinicRptFrm : ReportBaseForm
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private GroupBox groupBox1;

		private GroupBox groupBox2;

		private CrystalReportViewer crystalReportViewer1;

		private DateTimePicker date2;

		private Button ViewRptBtn;

		private DateTimePicker date1;

		private Label label3;

		private Label label2;

		private DataSet1 dataSet11;

		private Button button1;

		private Label label4;

		private ComboBox StockCom;

		public NetDailyClinicRptFrm()
		{
			InitializeComponent();
		}

		public NetDailyClinicRptFrm(DateTime d1, DateTime d2, string FileName)
		{
			InitializeComponent();
			DataTable dataTable = Codes.Search2("select distinct date from StokeMove where Date between'" + d1.ToString("MM/dd/yyyy") + "' and '" + d2.ToString("MM/dd/yyyy") + "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
			if (dataTable.Rows.Count <= 0)
			{
				return;
			}
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				decimal num = 0m;
				decimal num2 = 0m;
				decimal num3 = 0m;
				DataTable dataTable2 = Codes.Search2(string.Concat("SELECT isnull(sum(Price),0) as Expenses FROM StokeMove where (type='حذف كشف' or type='حساب طبيب' or type='مصروفات' or type='فاتورة مشتريات' or type='مدفوعات للمورد' or type='حذف إيرادات أخرى' or type='حذف خدمات و مدفوعات مريض' or type = 'حساب مساعد' or type='تحويل الى خزينة' or type='حذف أشعة' or type='حذف تحليل') and date = '", Convert.ToDateTime(dataTable.Rows[i][0]), "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='", Main.userId, "')"));
				DataTable dataTable3 = Codes.Search2(string.Concat("select isnull(sum(price),0) as Revenues  from StokeMove where (type != 'حذف كشف' and type!='حساب طبيب' and type!='مصروفات' and type!='فاتورة مشتريات' and type!='مدفوعات للمورد' and type!='حذف إيرادات أخرى' and type!='حذف خدمات و مدفوعات مريض' and type != 'حساب مساعد' and type != 'تحويل الى خزينة' and type !='حذف أشعة' and type !='حذف تحليل' and date = '", Convert.ToDateTime(dataTable.Rows[i][0]), "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='", Main.userId, "'))"));
				try
				{
					num2 = Convert.ToDecimal(dataTable2.Rows[0][0]);
				}
				catch
				{
				}
				try
				{
					num3 = Convert.ToDecimal(dataTable3.Rows[0][0]);
				}
				catch
				{
				}
				num = num3 - num2;
				((DataTable)(object)dataSet11.NetDailyClinic).Rows.Add(Convert.ToDateTime(dataTable.Rows[i][0].ToString()), num);
			}
			((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", d1, d2);
			NetDailyClincRpt netDailyClincRpt = new NetDailyClincRpt();
			netDailyClincRpt.SetDataSource(dataSet11);
			DiskFileDestinationOptions diskFileDestinationOptions = new DiskFileDestinationOptions();
			PdfRtfWordFormatOptions formatOptions = new PdfRtfWordFormatOptions();
			diskFileDestinationOptions.DiskFileName = FileName;
			ExportOptions exportOptions = netDailyClincRpt.ExportOptions;
			exportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
			exportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
			exportOptions.DestinationOptions = diskFileDestinationOptions;
			exportOptions.FormatOptions = formatOptions;
			netDailyClincRpt.Export();
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			if (StockCom.SelectedIndex == 0)
			{
				try
				{
					dataSet11.Clear();
					DataTable dataTable = Codes.Search2("select distinct date from StokeMove where Date between'" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					if (dataTable.Rows.Count > 0)
					{
						for (int i = 0; i < dataTable.Rows.Count; i++)
						{
							decimal num = 0m;
							decimal num2 = 0m;
							decimal num3 = 0m;
							DataTable dataTable2 = Codes.Search2(string.Concat("SELECT isnull(sum(Price),0) as Expenses FROM StokeMove where (type='حذف كشف' or type='حساب طبيب' or type='مصروفات' or type='فاتورة مشتريات' or type='مدفوعات للمورد' or type='حذف إيرادات أخرى' or type='حذف خدمات و مدفوعات مريض' or type = 'حساب مساعد' or type='تحويل الى خزينة' or type='حذف أشعة' or type='حذف تحليل') and date = '", Convert.ToDateTime(dataTable.Rows[i][0]), "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='", Main.userId, "')"));
							DataTable dataTable3 = Codes.Search2(string.Concat("select isnull(sum(price),0) as Revenues  from StokeMove where (type != 'حذف كشف' and type!='حساب طبيب' and type!='مصروفات' and type!='فاتورة مشتريات' and type!='مدفوعات للمورد' and type!='حذف إيرادات أخرى' and type!='حذف خدمات و مدفوعات مريض' and type != 'حساب مساعد' and type != 'تحويل الى خزينة' and type !='حذف أشعة' and type !='حذف تحليل' and date = '", Convert.ToDateTime(dataTable.Rows[i][0]), "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='", Main.userId, "'))"));
							try
							{
								num2 = Convert.ToDecimal(dataTable2.Rows[0][0]);
							}
							catch
							{
							}
							try
							{
								num3 = Convert.ToDecimal(dataTable3.Rows[0][0]);
							}
							catch
							{
							}
							num = num3 - num2;
							((DataTable)(object)dataSet11.NetDailyClinic).Rows.Add(Convert.ToDateTime(dataTable.Rows[i][0].ToString()), num);
						}
						((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value, date2.Value);
						NetDailyClincRpt netDailyClincRpt = new NetDailyClincRpt();
						netDailyClincRpt.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = netDailyClincRpt;
						button1.Visible = true;
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("No Data");
					}
					else
					{
						MessageBox.Show("لا يوجد بيانات");
					}
				}
				catch
				{
				}
				return;
			}
			try
			{
				dataSet11.Clear();
				DataTable dataTable = Codes.Search2("select distinct date from StokeMove where Date between'" + date1.Value.ToString("MM/dd/yyyy") + "' and '" + date2.Value.ToString("MM/dd/yyyy") + "' and StockId = '" + Convert.ToInt32(StockCom.SelectedValue.ToString()) + "'");
				if (dataTable.Rows.Count > 0)
				{
					for (int i = 0; i < dataTable.Rows.Count; i++)
					{
						decimal num = 0m;
						decimal num2 = 0m;
						decimal num3 = 0m;
						DataTable dataTable2 = Codes.Search2(string.Concat("SELECT isnull(sum(Price),0) as Expenses FROM  StokeMove where (type='حذف كشف' or type='حساب طبيب' or type='مصروفات' or type='فاتورة مشتريات' or type='مدفوعات للمورد' or type='حذف إيرادات أخرى' or type='حذف خدمات و مدفوعات مريض' or type = 'حساب مساعد' or type='تحويل الى خزينة' or type='حذف أشعة') and date = '", Convert.ToDateTime(dataTable.Rows[i][0]), "' and StockId = '", Convert.ToInt32(StockCom.SelectedValue.ToString()), "'"));
						DataTable dataTable3 = Codes.Search2(string.Concat("select isnull(sum(price),0) as Revenues  from StokeMove where (type != 'حذف كشف' and type!='حساب طبيب' and type!='مصروفات' and type!='فاتورة مشتريات' and type!='مدفوعات للمورد' and type!='حذف إيرادات أخرى' and type!='حذف خدمات و مدفوعات مريض' and type != 'تحويل الى خزينة' and type !='حذف أشعة' and date = '", Convert.ToDateTime(dataTable.Rows[i][0]), "' and StockId = '", Convert.ToInt32(StockCom.SelectedValue.ToString()), "')"));
						try
						{
							num2 = Convert.ToDecimal(dataTable2.Rows[0][0]);
						}
						catch
						{
						}
						try
						{
							num3 = Convert.ToDecimal(dataTable3.Rows[0][0]);
						}
						catch
						{
						}
						num = num3 - num2;
						((DataTable)(object)dataSet11.NetDailyClinic).Rows.Add(Convert.ToDateTime(dataTable.Rows[i][0].ToString()), num);
					}
					((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value, date2.Value);
					NetDailyClincRpt netDailyClincRpt = new NetDailyClincRpt();
					netDailyClincRpt.SetDataSource(dataSet11);
					crystalReportViewer1.ReportSource = netDailyClincRpt;
					button1.Visible = true;
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("No Data");
				}
				else
				{
					MessageBox.Show("لا يوجد بيانات");
				}
			}
			catch
			{
			}
		}

		private void NetDailyClinicRptFrm_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				StockCom.DataSource = null;
				DataRow dataRow = dataTable.NewRow();
				if (Settings.Default.Language == "en-GB")
				{
					dataRow["Name"] = "All";
				}
				else
				{
					dataRow["Name"] = "الكل";
				}
				StockCom.SelectedIndex = -1;
				dataTable.Rows.InsertAt(dataRow, 0);
				StockCom.DataSource = dataTable;
				StockCom.DisplayMember = dataTable.Columns[1].ToString();
				StockCom.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			NetDailyClinicRptFrm2 netDailyClinicRptFrm = new NetDailyClinicRptFrm2(date1.Value, date2.Value, StockCom.SelectedValue.ToString());
			netDailyClinicRptFrm.Show();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.NetDailyClinicRptFrm));
			groupBox1 = new System.Windows.Forms.GroupBox();
			label4 = new System.Windows.Forms.Label();
			StockCom = new System.Windows.Forms.ComboBox();
			button1 = new System.Windows.Forms.Button();
			date2 = new System.Windows.Forms.DateTimePicker();
			ViewRptBtn = new System.Windows.Forms.Button();
			date1 = new System.Windows.Forms.DateTimePicker();
			label3 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			dataSet11 = new DataSet1();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(StockCom);
			groupBox1.Controls.Add(button1);
			groupBox1.Controls.Add(date2);
			groupBox1.Controls.Add(ViewRptBtn);
			groupBox1.Controls.Add(date1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(label2);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Font = null;
			label4.Name = "label4";
			StockCom.AccessibleDescription = null;
			StockCom.AccessibleName = null;
			resources.ApplyResources(StockCom, "StockCom");
			StockCom.BackgroundImage = null;
			StockCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			StockCom.Font = null;
			StockCom.FormattingEnabled = true;
			StockCom.Name = "StockCom";
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.BackgroundImage = null;
			button1.Cursor = System.Windows.Forms.Cursors.Hand;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			date2.AccessibleDescription = null;
			date2.AccessibleName = null;
			resources.ApplyResources(date2, "date2");
			date2.BackgroundImage = null;
			date2.CalendarFont = null;
			date2.Font = null;
			date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date2.Name = "date2";
			ViewRptBtn.AccessibleDescription = null;
			ViewRptBtn.AccessibleName = null;
			resources.ApplyResources(ViewRptBtn, "ViewRptBtn");
			ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
			ViewRptBtn.BackgroundImage = null;
			ViewRptBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			ViewRptBtn.Name = "ViewRptBtn";
			ViewRptBtn.UseVisualStyleBackColor = false;
			ViewRptBtn.Click += new System.EventHandler(ViewRptBtn_Click);
			date1.AccessibleDescription = null;
			date1.AccessibleName = null;
			resources.ApplyResources(date1, "date1");
			date1.BackgroundImage = null;
			date1.CalendarFont = null;
			date1.Font = null;
			date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date1.Name = "date1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "NetDailyClinicRptFrm";
			base.Load += new System.EventHandler(NetDailyClinicRptFrm_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}
	}
}
