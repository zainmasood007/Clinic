using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class PrescriptionFrm : BaseForm
	{
		private dataClass codes;

		private int patientId;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private int id;

		private ClassDataBase dc = new ClassDataBase(".\\sqlExpress");

		private GUI gui = new GUI();

		private IContainer components = null;

		private GroupBox groupBox1;

		private Label label3;

		private Label label4;

		private Label label2;

		private Label label1;

		private TextBox medicineDisc;

		private Label label5;

		private ComboBox MedicineCom;

		private ComboBox DoctorCom;

		private ComboBox PatientCom;

		private DateTimePicker dateTimePicker1;

		private DataGridView dataGridView1;

		private GroupBox groupBox2;

		private Button button1;

		private Button button2;

		private Label label6;

		private TextBox NotsText;

		private Button button3;

		private Button EditBtn;

		private Button SearchBtn;

		private GroupBox groupBox3;

		private ComboBox comboBox1;

		private ComboBox comboBox2;

		private DateTimePicker dateTimePicker2;

		private Label label7;

		private Label label8;

		private Label label9;

		private Label label12;

		private TextBox textBox1;

		private Button button4;

		private DataGridViewTextBoxColumn MedId;

		private DataGridViewTextBoxColumn MedicineName;

		private DataGridViewTextBoxColumn MedicineDescription;

		private DataGridViewTextBoxColumn Column1;

		public PrescriptionFrm(int Patient)
		{
			InitializeComponent();
			codes = new dataClass(".\\sqlExpress");
			patientId = Patient;
		}

		public void method_0()
		{
			try
			{
				DataTable dataTable = codes.Search2("select * from PatientData where Active = 'True'");
				comboBox2.DataSource = null;
				comboBox2.DataSource = dataTable;
				comboBox2.DisplayMember = dataTable.Columns[2].ToString();
				comboBox2.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		public void LoadDoctorSearch()
		{
			try
			{
				DataTable dataTable = codes.Search2("select * from Empdata where Designation='Doctor'");
				comboBox1.DataSource = null;
				comboBox1.DataSource = dataTable;
				comboBox1.DisplayMember = dataTable.Columns[2].ToString();
				comboBox1.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		public void LoadPatient()
		{
			try
			{
				DataTable dataTable = new DataTable();
				if (Convert.ToBoolean(codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString()))
				{
					dataTable = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True' order by PName");
					PatientCom.DataSource = dataTable;
					PatientCom.DisplayMember = dataTable.Columns[1].ToString();
					PatientCom.ValueMember = dataTable.Columns[0].ToString();
				}
				else
				{
					dataTable = dc.Select("SelectAllPatient");
					gui.loadComboBox(PatientCom, dataTable);
				}
			}
			catch
			{
			}
		}

		public void LoadDoctor()
		{
			try
			{
				DataTable dataTable = codes.Search2("select * from Empdata where Designation='Doctor'");
				DoctorCom.DataSource = null;
				DoctorCom.DataSource = dataTable;
				DoctorCom.DisplayMember = dataTable.Columns[2].ToString();
				DoctorCom.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		public void LoadMedicine()
		{
			try
			{
				DataTable dataTable = codes.Search2("select * from Medicine ");
				MedicineCom.DataSource = null;
				MedicineCom.DataSource = dataTable;
				MedicineCom.DisplayMember = dataTable.Columns[1].ToString();
				MedicineCom.ValueMember = dataTable.Columns[0].ToString();
				MedicineCom.SelectedIndex = -1;
			}
			catch
			{
			}
		}

		private void PrescriptionFrm_Load(object sender, EventArgs e)
		{
			try
			{
				if (patientId == 0)
				{
					PatientCom.Enabled = true;
					LoadDoctor();
					LoadMedicine();
					LoadPatient();
					method_0();
					LoadDoctorSearch();
					MedicineCom.SelectedValue = UsersClass.EmpId;
				}
				else
				{
					PatientCom.Enabled = false;
					LoadDoctor();
					LoadMedicine();
					LoadPatient();
					method_0();
					LoadDoctorSearch();
					MedicineCom.SelectedValue = UsersClass.EmpId;
					PatientCom.SelectedValue = patientId;
				}
				MedicineCom.SelectedIndex = -1;
				button4.Enabled = Convert.ToBoolean(codes.Search2("select medicineFrmBtn from users where userId = '" + Main.userId + "'").Rows[0][0].ToString());
			}
			catch
			{
			}
		}

		private void MedicineCom_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				medicineDisc.Text = "";
				DataTable dataTable = codes.Search2("select MedicineDescription,NotItem from Medicine where Id=" + MedicineCom.SelectedValue.ToString());
				textBox1.Text = dataTable.Rows[0][1].ToString();
				DataTable dataTable2 = codes.Search2("select  MedicinDescrip from Prescription where MedicineId=" + MedicineCom.SelectedValue.ToString());
				if (dataTable2.Rows.Count > 0)
				{
					medicineDisc.Text = dataTable2.Rows[Convert.ToInt32(dataTable2.Rows.Count) - 1][0].ToString();
				}
				if (medicineDisc.Text == "")
				{
					medicineDisc.Text = dataTable.Rows[0][0].ToString();
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				int num = 0;
				while (true)
				{
					if (num < dataGridView1.Rows.Count)
					{
						if (Convert.ToInt32(dataGridView1.Rows[num].Cells[0].Value.ToString()) == Convert.ToInt32(MedicineCom.SelectedValue.ToString()))
						{
							break;
						}
						num++;
						continue;
					}
					dataGridView1.Rows.Add(MedicineCom.SelectedValue.ToString(), MedicineCom.Text, medicineDisc.Text, textBox1.Text);
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("You Have Save This Before");
				}
				else
				{
					MessageBox.Show("هذا الدواء مسجل من قبل");
				}
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				bool flag = false;
				int num = Convert.ToInt32(codes.Search2("select count(Id) from Prescription").Rows[0][0].ToString());
				if (num >= 50)
				{
					MessageBox.Show("انتهت المدة المحددة لتشغيل البرنامج إذا أردت النسخة الكاملة الرجاء الإتصال بالشركة", "تحذير", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return;
				}
				if (PatientCom.SelectedItem == null)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Valid Patient Name");
					}
					else
					{
						MessageBox.Show(" من فضلك اختر اسم مريض صحيح");
					}
					return;
				}
				if (DoctorCom.SelectedItem == null)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Valid Doctor Name");
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم طبيب صحيح");
					}
					return;
				}
				if (MedicineCom.SelectedItem == null)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Valid Medicine Name");
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم الدواء صحيح");
					}
					return;
				}
				if (dataGridView1.Rows.Count == 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Add At Least One Medicine");
					}
					else
					{
						MessageBox.Show("من فضلك اضف دواء واحد على الأقل");
					}
					return;
				}
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					codes.Add2("INSERT INTO Prescription  (Date, PatientId, EmpdataId, MedicineId,Nots,MedicinDescrip)VALUES ('" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "'," + PatientCom.SelectedValue.ToString() + "," + DoctorCom.SelectedValue.ToString() + ",'" + Convert.ToInt32(dataGridView1.Rows[i].Cells[0].Value.ToString()) + "','" + NotsText.Text + "','" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "')");
					flag = true;
				}
				if (flag)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Have Been Saved");
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح");
					}
					MethodsClass.UserMove("أضافة روشتة");
					PrescriptionRptFrm prescriptionRptFrm = new PrescriptionRptFrm(Convert.ToInt32(PatientCom.SelectedValue.ToString()), Convert.ToInt32(DoctorCom.SelectedValue.ToString()), dateTimePicker1.Value);
					prescriptionRptFrm.ShowDialog();
					clear();
				}
			}
			catch
			{
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				EditBtn.Enabled = false;
				bool flag = false;
				codes.Delete2(string.Concat("delete from Prescription where dbo.Prescription.Date =  '", dateTimePicker2.Value.ToString("MM/dd/yyyy"), "' and dbo.Prescription.PatientId = '", comboBox2.SelectedValue, "' and dbo.Prescription.EmpdataId = '", comboBox1.SelectedValue, "'"));
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					codes.Add2("INSERT INTO Prescription  (Date, PatientId, EmpdataId, MedicineId,Nots,MedicinDescrip)VALUES ('" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "'," + PatientCom.SelectedValue.ToString() + "," + DoctorCom.SelectedValue.ToString() + ",'" + Convert.ToInt32(dataGridView1.Rows[i].Cells[0].Value.ToString()) + "','" + NotsText.Text + "','" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "')");
					flag = true;
				}
				if (flag)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Have Been Saved");
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح");
					}
					MethodsClass.UserMove("تعديل روشتة");
					PrescriptionRptFrm prescriptionRptFrm = new PrescriptionRptFrm(Convert.ToInt32(PatientCom.SelectedValue.ToString()), Convert.ToInt32(DoctorCom.SelectedValue.ToString()), dateTimePicker1.Value);
					prescriptionRptFrm.ShowDialog();
					clear();
				}
			}
			catch
			{
			}
		}

		private void clear()
		{
			dateTimePicker1.Value = DateTime.Now;
			dateTimePicker2.Value = DateTime.Now;
			PatientCom.SelectedIndex = -1;
			DoctorCom.SelectedIndex = -1;
			NotsText.Text = "";
			MedicineCom.SelectedIndex = -1;
			medicineDisc.Text = "";
			dataGridView1.DataSource = null;
			dataGridView1.Rows.Clear();
			comboBox1.SelectedIndex = -1;
			comboBox2.SelectedIndex = -1;
			SearchBtn.Enabled = true;
			dateTimePicker2.Enabled = true;
			comboBox1.Enabled = true;
			comboBox2.Enabled = true;
			EditBtn.Enabled = false;
			button2.Enabled = true;
		}

		private void button3_Click(object sender, EventArgs e)
		{
			clear();
		}

		private void SearchBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (comboBox1.SelectedIndex == -1)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Valid Doctor Name");
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم طبيب صحيح");
					}
					return;
				}
				if (comboBox2.SelectedIndex == -1)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Valid Patient Name");
					}
					else
					{
						MessageBox.Show(" من فضلك اختر اسم مريض صحيح");
					}
					return;
				}
				DataTable dataTable = codes.Search2(string.Concat("SELECT  dbo.Prescription.Date, dbo.Prescription.PatientId, dbo.Prescription.EmpdataId, dbo.Prescription.Nots, dbo.Medicine.MedecineName, dbo.Medicine.MedicineDescription,dbo.Medicine.Id,dbo.Medicine.NotItem,Prescription.MedicinDescrip FROM dbo.Prescription INNER JOIN dbo.Medicine ON dbo.Prescription.MedicineId = dbo.Medicine.Id where dbo.Prescription.Date =  '", dateTimePicker2.Value.ToString("MM/dd/yyyy"), "' and dbo.Prescription.PatientId = '", comboBox2.SelectedValue, "' and dbo.Prescription.EmpdataId = '", comboBox1.SelectedValue, "'"));
				if (dataTable.Rows.Count > 0)
				{
					dateTimePicker2.Enabled = false;
					comboBox1.Enabled = false;
					comboBox2.Enabled = false;
					SearchBtn.Enabled = false;
					EditBtn.Enabled = true;
					button2.Enabled = false;
					for (int i = 0; i < dataTable.Rows.Count; i++)
					{
						dataGridView1.Rows.Add();
						dateTimePicker1.Value = Convert.ToDateTime(dataTable.Rows[0][0].ToString());
						PatientCom.SelectedValue = Convert.ToInt32(dataTable.Rows[0][1].ToString());
						DoctorCom.SelectedValue = Convert.ToInt32(dataTable.Rows[0][2].ToString());
						NotsText.Text = dataTable.Rows[0][3].ToString();
						dataGridView1.Rows[i].Cells[0].Value = dataTable.Rows[i][6].ToString();
						dataGridView1.Rows[i].Cells[1].Value = dataTable.Rows[i][4].ToString();
						dataGridView1.Rows[i].Cells[2].Value = dataTable.Rows[i][8].ToString();
						dataGridView1.Rows[i].Cells[3].Value = dataTable.Rows[i][7].ToString();
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("No Prescription");
				}
				else
				{
					MessageBox.Show(" لا يوجد روشته ");
				}
			}
			catch
			{
			}
		}

		private void button4_Click(object sender, EventArgs e)
		{
			try
			{
				medicineFrm medicineFrm2 = new medicineFrm();
				medicineFrm2.ShowDialog();
				DataTable dataTable = codes.Search2("select * from Medicine ");
				MedicineCom.DataSource = null;
				MedicineCom.DataSource = dataTable;
				MedicineCom.DisplayMember = dataTable.Columns[1].ToString();
				MedicineCom.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.PrescriptionFrm));
			groupBox1 = new System.Windows.Forms.GroupBox();
			label6 = new System.Windows.Forms.Label();
			DoctorCom = new System.Windows.Forms.ComboBox();
			PatientCom = new System.Windows.Forms.ComboBox();
			NotsText = new System.Windows.Forms.TextBox();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label4 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			button1 = new System.Windows.Forms.Button();
			label3 = new System.Windows.Forms.Label();
			MedicineCom = new System.Windows.Forms.ComboBox();
			label5 = new System.Windows.Forms.Label();
			medicineDisc = new System.Windows.Forms.TextBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			MedId = new System.Windows.Forms.DataGridViewTextBoxColumn();
			MedicineName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			MedicineDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			groupBox2 = new System.Windows.Forms.GroupBox();
			button4 = new System.Windows.Forms.Button();
			textBox1 = new System.Windows.Forms.TextBox();
			label12 = new System.Windows.Forms.Label();
			button2 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			EditBtn = new System.Windows.Forms.Button();
			SearchBtn = new System.Windows.Forms.Button();
			groupBox3 = new System.Windows.Forms.GroupBox();
			comboBox1 = new System.Windows.Forms.ComboBox();
			comboBox2 = new System.Windows.Forms.ComboBox();
			dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			label7 = new System.Windows.Forms.Label();
			label8 = new System.Windows.Forms.Label();
			label9 = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox2.SuspendLayout();
			groupBox3.SuspendLayout();
			SuspendLayout();
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(label6);
			groupBox1.Controls.Add(DoctorCom);
			groupBox1.Controls.Add(PatientCom);
			groupBox1.Controls.Add(NotsText);
			groupBox1.Controls.Add(dateTimePicker1);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(label1);
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			resources.ApplyResources(label6, "label6");
			label6.ForeColor = System.Drawing.Color.WhiteSmoke;
			label6.Name = "label6";
			DoctorCom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			DoctorCom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			DoctorCom.FormattingEnabled = true;
			resources.ApplyResources(DoctorCom, "DoctorCom");
			DoctorCom.Name = "DoctorCom";
			PatientCom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			PatientCom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientCom.FormattingEnabled = true;
			resources.ApplyResources(PatientCom, "PatientCom");
			PatientCom.Name = "PatientCom";
			resources.ApplyResources(NotsText, "NotsText");
			NotsText.Name = "NotsText";
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			resources.ApplyResources(label4, "label4");
			label4.ForeColor = System.Drawing.Color.WhiteSmoke;
			label4.Name = "label4";
			resources.ApplyResources(label2, "label2");
			label2.ForeColor = System.Drawing.Color.WhiteSmoke;
			label2.Name = "label2";
			resources.ApplyResources(label1, "label1");
			label1.ForeColor = System.Drawing.Color.WhiteSmoke;
			label1.Name = "label1";
			button1.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(button1, "button1");
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			resources.ApplyResources(label3, "label3");
			label3.ForeColor = System.Drawing.Color.WhiteSmoke;
			label3.Name = "label3";
			MedicineCom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			MedicineCom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			MedicineCom.FormattingEnabled = true;
			resources.ApplyResources(MedicineCom, "MedicineCom");
			MedicineCom.Name = "MedicineCom";
			MedicineCom.SelectedIndexChanged += new System.EventHandler(MedicineCom_SelectedIndexChanged);
			resources.ApplyResources(label5, "label5");
			label5.ForeColor = System.Drawing.Color.WhiteSmoke;
			label5.Name = "label5";
			resources.ApplyResources(medicineDisc, "medicineDisc");
			medicineDisc.Name = "medicineDisc";
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(MedId, MedicineName, MedicineDescription, Column1);
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			resources.ApplyResources(MedId, "MedId");
			MedId.Name = "MedId";
			MedId.ReadOnly = true;
			resources.ApplyResources(MedicineName, "MedicineName");
			MedicineName.Name = "MedicineName";
			MedicineName.ReadOnly = true;
			resources.ApplyResources(MedicineDescription, "MedicineDescription");
			MedicineDescription.Name = "MedicineDescription";
			MedicineDescription.ReadOnly = true;
			resources.ApplyResources(Column1, "Column1");
			Column1.Name = "Column1";
			Column1.ReadOnly = true;
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(button4);
			groupBox2.Controls.Add(textBox1);
			groupBox2.Controls.Add(button1);
			groupBox2.Controls.Add(label3);
			groupBox2.Controls.Add(label12);
			groupBox2.Controls.Add(dataGridView1);
			groupBox2.Controls.Add(MedicineCom);
			groupBox2.Controls.Add(medicineDisc);
			groupBox2.Controls.Add(label5);
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			button4.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(button4, "button4");
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = false;
			button4.Click += new System.EventHandler(button4_Click);
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.Name = "textBox1";
			textBox1.ReadOnly = true;
			resources.ApplyResources(label12, "label12");
			label12.ForeColor = System.Drawing.Color.WhiteSmoke;
			label12.Name = "label12";
			button2.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(button2, "button2");
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = false;
			button2.Click += new System.EventHandler(button2_Click);
			button3.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(button3, "button3");
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = false;
			button3.Click += new System.EventHandler(button3_Click);
			EditBtn.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(EditBtn, "EditBtn");
			EditBtn.Name = "EditBtn";
			EditBtn.UseVisualStyleBackColor = false;
			EditBtn.Click += new System.EventHandler(EditBtn_Click);
			SearchBtn.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(SearchBtn, "SearchBtn");
			SearchBtn.Name = "SearchBtn";
			SearchBtn.UseVisualStyleBackColor = false;
			SearchBtn.Click += new System.EventHandler(SearchBtn_Click);
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.Controls.Add(comboBox1);
			groupBox3.Controls.Add(comboBox2);
			groupBox3.Controls.Add(dateTimePicker2);
			groupBox3.Controls.Add(SearchBtn);
			groupBox3.Controls.Add(label7);
			groupBox3.Controls.Add(label8);
			groupBox3.Controls.Add(label9);
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.FormattingEnabled = true;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.Name = "comboBox1";
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.FormattingEnabled = true;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.Name = "comboBox2";
			resources.ApplyResources(dateTimePicker2, "dateTimePicker2");
			dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker2.Name = "dateTimePicker2";
			resources.ApplyResources(label7, "label7");
			label7.ForeColor = System.Drawing.Color.WhiteSmoke;
			label7.Name = "label7";
			resources.ApplyResources(label8, "label8");
			label8.ForeColor = System.Drawing.Color.WhiteSmoke;
			label8.Name = "label8";
			resources.ApplyResources(label9, "label9");
			label9.ForeColor = System.Drawing.Color.WhiteSmoke;
			label9.Name = "label9";
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(groupBox3);
			base.Controls.Add(button3);
			base.Controls.Add(EditBtn);
			base.Controls.Add(button2);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.Name = "PrescriptionFrm";
			base.Load += new System.EventHandler(PrescriptionFrm_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			ResumeLayout(false);
		}
	}
}
