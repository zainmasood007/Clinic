using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmPrintImages : ReportBaseForm
	{
		private IContainer components = null;

		private Panel panel1;

		private CrystalReportViewer crystalReportViewer1;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlSelectCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlInsertCommand2;

		private SqlCommand sqlUpdateCommand2;

		private SqlCommand sqlDeleteCommand2;

		private SqlDataAdapter sqlDataAdapter2;

		private string ID;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private string Analyze;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmPrintImages));
			panel1 = new System.Windows.Forms.Panel();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			dataSet11 = new DataSet1();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			panel1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			panel1.BackColor = System.Drawing.Color.Transparent;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(crystalReportViewer1);
			panel1.Location = new System.Drawing.Point(2, 1);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(656, 504);
			panel1.TabIndex = 2;
			crystalReportViewer1.ActiveViewIndex = -1;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
			crystalReportViewer1.Location = new System.Drawing.Point(0, 0);
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.Size = new System.Drawing.Size(654, 502);
			crystalReportViewer1.TabIndex = 0;
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlSelectCommand1.CommandText = "SELECT        PatientRay.*\r\nFROM            PatientRay";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[4]
			{
				new System.Data.SqlClient.SqlParameter("@PatientID", System.Data.SqlDbType.Int, 0, "PatientID"),
				new System.Data.SqlClient.SqlParameter("@XrayImage", System.Data.SqlDbType.Image, 0, "XrayImage"),
				new System.Data.SqlClient.SqlParameter("@XrayDate", System.Data.SqlDbType.DateTime, 0, "XrayDate"),
				new System.Data.SqlClient.SqlParameter("@XrayNots", System.Data.SqlDbType.NVarChar, 0, "XrayNots")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[10]
			{
				new System.Data.SqlClient.SqlParameter("@PatientID", System.Data.SqlDbType.Int, 0, "PatientID"),
				new System.Data.SqlClient.SqlParameter("@XrayImage", System.Data.SqlDbType.Image, 0, "XrayImage"),
				new System.Data.SqlClient.SqlParameter("@XrayDate", System.Data.SqlDbType.DateTime, 0, "XrayDate"),
				new System.Data.SqlClient.SqlParameter("@XrayNots", System.Data.SqlDbType.NVarChar, 0, "XrayNots"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_XrayDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "XrayDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_XrayDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "XrayDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[5]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_XrayDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "XrayDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_XrayDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "XrayDate", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientRay", new System.Data.Common.DataColumnMapping[5]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("PatientID", "PatientID"),
					new System.Data.Common.DataColumnMapping("XrayImage", "XrayImage"),
					new System.Data.Common.DataColumnMapping("XrayDate", "XrayDate"),
					new System.Data.Common.DataColumnMapping("XrayNots", "XrayNots")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			sqlSelectCommand2.CommandText = "SELECT        PatientAnalyze.*\r\nFROM            PatientAnalyze";
			sqlSelectCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.CommandText = resources.GetString("sqlInsertCommand2.CommandText");
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@PatientID", System.Data.SqlDbType.Int, 0, "PatientID"),
				new System.Data.SqlClient.SqlParameter("@AnalyzeImage", System.Data.SqlDbType.Image, 0, "AnalyzeImage"),
				new System.Data.SqlClient.SqlParameter("@AnalyzeDate", System.Data.SqlDbType.DateTime, 0, "AnalyzeDate"),
				new System.Data.SqlClient.SqlParameter("@AnalyzeNots", System.Data.SqlDbType.NVarChar, 0, "AnalyzeNots"),
				new System.Data.SqlClient.SqlParameter("@Free", System.Data.SqlDbType.Bit, 0, "Free"),
				new System.Data.SqlClient.SqlParameter("@DoctorId", System.Data.SqlDbType.Int, 0, "DoctorId"),
				new System.Data.SqlClient.SqlParameter("@AnalyzeName", System.Data.SqlDbType.NVarChar, 0, "AnalyzeName")
			});
			sqlUpdateCommand2.CommandText = resources.GetString("sqlUpdateCommand2.CommandText");
			sqlUpdateCommand2.Connection = sqlConnection2;
			sqlUpdateCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[19]
			{
				new System.Data.SqlClient.SqlParameter("@PatientID", System.Data.SqlDbType.Int, 0, "PatientID"),
				new System.Data.SqlClient.SqlParameter("@AnalyzeImage", System.Data.SqlDbType.Image, 0, "AnalyzeImage"),
				new System.Data.SqlClient.SqlParameter("@AnalyzeDate", System.Data.SqlDbType.DateTime, 0, "AnalyzeDate"),
				new System.Data.SqlClient.SqlParameter("@AnalyzeNots", System.Data.SqlDbType.NVarChar, 0, "AnalyzeNots"),
				new System.Data.SqlClient.SqlParameter("@Free", System.Data.SqlDbType.Bit, 0, "Free"),
				new System.Data.SqlClient.SqlParameter("@DoctorId", System.Data.SqlDbType.Int, 0, "DoctorId"),
				new System.Data.SqlClient.SqlParameter("@AnalyzeName", System.Data.SqlDbType.NVarChar, 0, "AnalyzeName"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AnalyzeDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AnalyzeDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AnalyzeDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AnalyzeDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Free", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Free", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Free", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Free", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AnalyzeName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AnalyzeName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AnalyzeName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AnalyzeName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand2.CommandText = resources.GetString("sqlDeleteCommand2.CommandText");
			sqlDeleteCommand2.Connection = sqlConnection2;
			sqlDeleteCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[11]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AnalyzeDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AnalyzeDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AnalyzeDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AnalyzeDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Free", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Free", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Free", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Free", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AnalyzeName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AnalyzeName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AnalyzeName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AnalyzeName", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter2.DeleteCommand = sqlDeleteCommand2;
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientAnalyze", new System.Data.Common.DataColumnMapping[8]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("PatientID", "PatientID"),
					new System.Data.Common.DataColumnMapping("AnalyzeImage", "AnalyzeImage"),
					new System.Data.Common.DataColumnMapping("AnalyzeDate", "AnalyzeDate"),
					new System.Data.Common.DataColumnMapping("AnalyzeNots", "AnalyzeNots"),
					new System.Data.Common.DataColumnMapping("Free", "Free"),
					new System.Data.Common.DataColumnMapping("DoctorId", "DoctorId"),
					new System.Data.Common.DataColumnMapping("AnalyzeName", "AnalyzeName")
				})
			});
			sqlDataAdapter2.UpdateCommand = sqlUpdateCommand2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(658, 508);
			base.Controls.Add(panel1);
			base.Location = new System.Drawing.Point(0, 0);
			base.Name = "FrmPrintImages";
			Text = "طباعة الصورة";
			base.Load += new System.EventHandler(FrmPrintImages_Load);
			panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}

		public FrmPrintImages()
		{
			InitializeComponent();
		}

		public FrmPrintImages(string id, string analyze)
		{
			InitializeComponent();
			ID = id;
			Analyze = analyze;
		}

		private void FrmPrintImages_Load(object sender, EventArgs e)
		{
			dataSet11.Clear();
			if (Analyze == "")
			{
				sqlConnection1.ConnectionString = Codes.ConnectionStr;
				sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter1.SelectCommand.CommandText = "select * from PatientRay where ID='" + ID + "'";
				sqlDataAdapter1.Fill(dataSet11);
				RptPatientRay rptPatientRay = new RptPatientRay();
				rptPatientRay.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = rptPatientRay;
			}
			else
			{
				sqlConnection2.ConnectionString = Codes.ConnectionStr;
				sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter2.SelectCommand.CommandText = "select * from PatientAnalyze where ID='" + ID + "'";
				sqlDataAdapter2.Fill(dataSet11);
				RptPatientAnalyze rptPatientAnalyze = new RptPatientAnalyze();
				rptPatientAnalyze.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = rptPatientAnalyze;
			}
		}
	}
}
