using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmSurgery : BaseForm
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		private string ID;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private GroupBox groupBox1;

		private TextBox textBox2;

		private TextBox textBox1;

		private NumericUpDown numericUpDown1;

		private GroupBox groupBox2;

		private GroupBox groupBox3;

		private DataGridView dataGridView1;

		private Button button3;

		private Button button2;

		private Button button1;

		public FrmSurgery()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (textBox1.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Surgery Name");
					}
					else
					{
						MessageBox.Show("من فضلك أدخل اسم العملية");
					}
					return;
				}
				DataTable dataTable = Codes.Search2("select * from Surgery where name = '" + textBox1.Text + "'");
				if (dataTable.Rows.Count == 0)
				{
					Codes.Add("insert into surgery (Name, Notes, Price) Values ('" + textBox1.Text + "', '" + textBox2.Text + "', '" + numericUpDown1.Value + "')");
					MethodsClass.UserMove("أضافة عملية");
					Clear();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("You Have Save This Surgery Before");
				}
				else
				{
					MessageBox.Show("هذا الإسم مسجل من قبل");
				}
			}
			catch
			{
			}
		}

		private void FrmSurgery_Load(object sender, EventArgs e)
		{
			try
			{
				Clear();
			}
			catch
			{
			}
		}

		private void Clear()
		{
			button1.Visible = true;
			button2.Visible = false;
			button3.Visible = false;
			textBox1.Text = "";
			textBox2.Text = "";
			numericUpDown1.Value = 0m;
			DataTable dataTable = new DataTable();
			dataTable = ((!(Settings.Default.Language == "en-GB")) ? Codes.Search2("select id, Name [اسم العملية],Price [تكلفة العملية],Notes [ملاحظات] from Surgery") : Codes.Search2("select id, Name [Surgery Name],Price [Cost],Notes [Notes] from Surgery"));
			dataGridView1.DataSource = dataTable;
			dataGridView1.Columns[0].Visible = false;
			numericUpDown1.Enabled = true;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				if (textBox1.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Surgery Name");
					}
					else
					{
						MessageBox.Show("من فضلك أدخل اسم العملية");
					}
					return;
				}
				DataTable dataTable = Codes.Search2("select * from Surgery where name = '" + textBox1.Text + "' and ID <> '" + ID + "'");
				if (dataTable.Rows.Count == 0)
				{
					Codes.Edit("update Surgery set Name = '" + textBox1.Text + "',Price = '" + numericUpDown1.Value + "' ,Notes = '" + textBox2.Text + "' where ID= '" + ID + "'");
					MethodsClass.UserMove("تعديل عملية");
					Clear();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("You Have Save This Surgery Before");
				}
				else
				{
					MessageBox.Show("هذا الإسم مسجل من قبل");
				}
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				Codes.Delete("Delete from Surgery where ID= '" + ID + "'");
				MethodsClass.UserMove("حذف عملية");
				Clear();
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				ID = dataGridView1.CurrentRow.Cells[0].Value.ToString();
				textBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
				numericUpDown1.Value = Convert.ToDecimal(dataGridView1.CurrentRow.Cells[2].Value.ToString());
				textBox2.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
				button1.Visible = false;
				button2.Visible = true;
				button3.Visible = true;
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmSurgery));
			groupBox1 = new System.Windows.Forms.GroupBox();
			numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			textBox2 = new System.Windows.Forms.TextBox();
			textBox1 = new System.Windows.Forms.TextBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			button3 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			groupBox3 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
			groupBox2.SuspendLayout();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "label5");
			label.Name = "label5";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label1");
			label2.Name = "label1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label2");
			label3.Name = "label2";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(numericUpDown1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(textBox2);
			groupBox1.Controls.Add(textBox1);
			groupBox1.Controls.Add(label);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			numericUpDown1.AccessibleDescription = null;
			numericUpDown1.AccessibleName = null;
			resources.ApplyResources(numericUpDown1, "numericUpDown1");
			numericUpDown1.DecimalPlaces = 2;
			numericUpDown1.Font = null;
			numericUpDown1.Maximum = new decimal(new int[4] { -1530494977, 232830, 0, 0 });
			numericUpDown1.Name = "numericUpDown1";
			textBox2.AccessibleDescription = null;
			textBox2.AccessibleName = null;
			resources.ApplyResources(textBox2, "textBox2");
			textBox2.BackgroundImage = null;
			textBox2.Name = "textBox2";
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Name = "textBox1";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(button3);
			groupBox2.Controls.Add(button2);
			groupBox2.Controls.Add(button1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackgroundImage = null;
			button3.Font = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(dataGridView1);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FrmSurgery";
			base.Load += new System.EventHandler(FrmSurgery_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
		}
	}
}
