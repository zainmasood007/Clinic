using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;

namespace DentistClinic
{
	public class FrmRptSuplierMoves : BaseForm
	{
		private ClassDataBase cr;

		private DataTable dt;

		private IContainer components = null;

		private Panel panel1;

		private Label label1;

		private ComboBox SupliercomboBox;

		private Button btnSearch;

		private DateTimePicker SeconddateTimePicker;

		private DateTimePicker FirstdateTimePicker;

		private CrystalReportViewer crystalReportViewer1;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlSelectCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlInsertCommand2;

		private SqlCommand sqlUpdateCommand2;

		private SqlCommand sqlDeleteCommand2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlSelectCommand3;

		private SqlConnection sqlConnection3;

		private SqlCommand sqlInsertCommand3;

		private SqlCommand sqlUpdateCommand3;

		private SqlCommand sqlDeleteCommand3;

		private SqlDataAdapter sqlDataAdapter3;

		private SqlCommand sqlSelectCommand4;

		private SqlConnection sqlConnection4;

		private SqlCommand sqlInsertCommand4;

		private SqlCommand sqlUpdateCommand4;

		private SqlCommand sqlDeleteCommand4;

		private SqlDataAdapter sqlDataAdapter4;

		private GroupBox groupBox2;

		private GroupBox groupBox1;

		private Label label4;

		private Label label5;

		public FrmRptSuplierMoves()
		{
			InitializeComponent();
			cr = new ClassDataBase(".\\sqlExpress");
		}

		private void FrmRptSuplierMoves_Load(object sender, EventArgs e)
		{
			LoadSupliers();
		}

		private void LoadSupliers()
		{
			try
			{
				dt = cr.GetTableText("SELECT     SupplierID, SupName FROM Supplier");
				SupliercomboBox.DataSource = dt;
				SupliercomboBox.DisplayMember = "SupName";
				SupliercomboBox.ValueMember = "SupplierID";
			}
			catch
			{
				MessageBox.Show("لايوجد موردين");
			}
		}

		private void btnSearch_Click(object sender, EventArgs e)
		{
			dataSet11.Clear();
			sqlConnection1.ConnectionString = cr.ConnectionStr;
			sqlConnection2.ConnectionString = cr.ConnectionStr;
			sqlConnection3.ConnectionString = cr.ConnectionStr;
			sqlConnection4.ConnectionString = cr.ConnectionStr;
			sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
			sqlDataAdapter1.SelectCommand.CommandText = "SELECT  * FROM BuyCar WHERE BuyDate between '" + FirstdateTimePicker.Value.ToString("MM/dd/yyyy") + "'and '" + SeconddateTimePicker.Value.ToString("MM/dd/yyyy") + "' ";
			sqlDataAdapter1.Fill(dataSet11);
			sqlDataAdapter2.Fill(dataSet11);
			sqlDataAdapter3.Fill(dataSet11);
			sqlDataAdapter4.Fill(dataSet11);
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmRptSuplierMoves));
			panel1 = new System.Windows.Forms.Panel();
			groupBox2 = new System.Windows.Forms.GroupBox();
			groupBox1 = new System.Windows.Forms.GroupBox();
			label4 = new System.Windows.Forms.Label();
			label5 = new System.Windows.Forms.Label();
			SupliercomboBox = new System.Windows.Forms.ComboBox();
			btnSearch = new System.Windows.Forms.Button();
			SeconddateTimePicker = new System.Windows.Forms.DateTimePicker();
			FirstdateTimePicker = new System.Windows.Forms.DateTimePicker();
			label1 = new System.Windows.Forms.Label();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			dataSet11 = new DataSet1();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlConnection3 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlConnection4 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter4 = new System.Data.SqlClient.SqlDataAdapter();
			panel1.SuspendLayout();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			panel1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			panel1.BackColor = System.Drawing.Color.Transparent;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(groupBox2);
			panel1.Controls.Add(groupBox1);
			panel1.Controls.Add(crystalReportViewer1);
			panel1.Location = new System.Drawing.Point(7, 7);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(890, 641);
			panel1.TabIndex = 0;
			groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			groupBox2.Location = new System.Drawing.Point(5, 114);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(880, 2);
			groupBox2.TabIndex = 14;
			groupBox2.TabStop = false;
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(label5);
			groupBox1.Controls.Add(SupliercomboBox);
			groupBox1.Controls.Add(btnSearch);
			groupBox1.Controls.Add(SeconddateTimePicker);
			groupBox1.Controls.Add(FirstdateTimePicker);
			groupBox1.Controls.Add(label1);
			groupBox1.Location = new System.Drawing.Point(3, 4);
			groupBox1.Name = "groupBox1";
			groupBox1.Size = new System.Drawing.Size(707, 100);
			groupBox1.TabIndex = 13;
			groupBox1.TabStop = false;
			label4.AutoSize = true;
			label4.Font = new System.Drawing.Font("Arial", 10f, System.Drawing.FontStyle.Bold);
			label4.Location = new System.Drawing.Point(142, 61);
			label4.Name = "label4";
			label4.Size = new System.Drawing.Size(48, 16);
			label4.TabIndex = 2;
			label4.Text = "From:";
			label5.AutoSize = true;
			label5.Font = new System.Drawing.Font("Arial", 10f, System.Drawing.FontStyle.Bold);
			label5.Location = new System.Drawing.Point(353, 60);
			label5.Name = "label5";
			label5.Size = new System.Drawing.Size(28, 16);
			label5.TabIndex = 3;
			label5.Text = "To:";
			SupliercomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			SupliercomboBox.FormattingEnabled = true;
			SupliercomboBox.Location = new System.Drawing.Point(145, 19);
			SupliercomboBox.Name = "SupliercomboBox";
			SupliercomboBox.Size = new System.Drawing.Size(368, 21);
			SupliercomboBox.TabIndex = 1;
			btnSearch.BackColor = System.Drawing.Color.Gainsboro;
			btnSearch.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold);
			btnSearch.Location = new System.Drawing.Point(570, 58);
			btnSearch.Name = "btnSearch";
			btnSearch.Size = new System.Drawing.Size(98, 33);
			btnSearch.TabIndex = 6;
			btnSearch.Text = "Search";
			btnSearch.UseVisualStyleBackColor = false;
			btnSearch.Click += new System.EventHandler(btnSearch_Click);
			SeconddateTimePicker.CustomFormat = "dd/MM/yyyy";
			SeconddateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			SeconddateTimePicker.Location = new System.Drawing.Point(387, 58);
			SeconddateTimePicker.Name = "SeconddateTimePicker";
			SeconddateTimePicker.Size = new System.Drawing.Size(126, 20);
			SeconddateTimePicker.TabIndex = 5;
			FirstdateTimePicker.CustomFormat = "dd/MM/yyyy";
			FirstdateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			FirstdateTimePicker.Location = new System.Drawing.Point(196, 58);
			FirstdateTimePicker.Name = "FirstdateTimePicker";
			FirstdateTimePicker.Size = new System.Drawing.Size(115, 20);
			FirstdateTimePicker.TabIndex = 4;
			label1.AutoSize = true;
			label1.Font = new System.Drawing.Font("Arial", 10f, System.Drawing.FontStyle.Bold);
			label1.Location = new System.Drawing.Point(25, 20);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(114, 16);
			label1.TabIndex = 0;
			label1.Text = "Supplier Name:";
			crystalReportViewer1.ActiveViewIndex = -1;
			crystalReportViewer1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.DisplayGroupTree = false;
			crystalReportViewer1.Location = new System.Drawing.Point(5, 122);
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.Size = new System.Drawing.Size(880, 514);
			crystalReportViewer1.TabIndex = 1;
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlSelectCommand1.CommandText = "SELECT        BuyCar.*\r\nFROM            BuyCar";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Car.mdf;Integrated Security=True;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@BuyDate", System.Data.SqlDbType.DateTime, 0, "BuyDate"),
				new System.Data.SqlClient.SqlParameter("@SupplierId", System.Data.SqlDbType.Int, 0, "SupplierId"),
				new System.Data.SqlClient.SqlParameter("@CarKindId", System.Data.SqlDbType.Int, 0, "CarKindId"),
				new System.Data.SqlClient.SqlParameter("@EngineNo", System.Data.SqlDbType.NVarChar, 0, "EngineNo"),
				new System.Data.SqlClient.SqlParameter("@ChassisNo", System.Data.SqlDbType.NVarChar, 0, "ChassisNo"),
				new System.Data.SqlClient.SqlParameter("@License", System.Data.SqlDbType.NVarChar, 0, "License"),
				new System.Data.SqlClient.SqlParameter("@EndLicenseDate", System.Data.SqlDbType.DateTime, 0, "EndLicenseDate"),
				new System.Data.SqlClient.SqlParameter("@PlateNo", System.Data.SqlDbType.NVarChar, 0, "PlateNo"),
				new System.Data.SqlClient.SqlParameter("@BuyPrice", System.Data.SqlDbType.Money, 0, "BuyPrice"),
				new System.Data.SqlClient.SqlParameter("@Paid", System.Data.SqlDbType.Money, 0, "Paid"),
				new System.Data.SqlClient.SqlParameter("@Rest", System.Data.SqlDbType.Money, 0, "Rest"),
				new System.Data.SqlClient.SqlParameter("@Nots", System.Data.SqlDbType.NVarChar, 0, "Nots"),
				new System.Data.SqlClient.SqlParameter("@Archive", System.Data.SqlDbType.Bit, 0, "Archive")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[39]
			{
				new System.Data.SqlClient.SqlParameter("@BuyDate", System.Data.SqlDbType.DateTime, 0, "BuyDate"),
				new System.Data.SqlClient.SqlParameter("@SupplierId", System.Data.SqlDbType.Int, 0, "SupplierId"),
				new System.Data.SqlClient.SqlParameter("@CarKindId", System.Data.SqlDbType.Int, 0, "CarKindId"),
				new System.Data.SqlClient.SqlParameter("@EngineNo", System.Data.SqlDbType.NVarChar, 0, "EngineNo"),
				new System.Data.SqlClient.SqlParameter("@ChassisNo", System.Data.SqlDbType.NVarChar, 0, "ChassisNo"),
				new System.Data.SqlClient.SqlParameter("@License", System.Data.SqlDbType.NVarChar, 0, "License"),
				new System.Data.SqlClient.SqlParameter("@EndLicenseDate", System.Data.SqlDbType.DateTime, 0, "EndLicenseDate"),
				new System.Data.SqlClient.SqlParameter("@PlateNo", System.Data.SqlDbType.NVarChar, 0, "PlateNo"),
				new System.Data.SqlClient.SqlParameter("@BuyPrice", System.Data.SqlDbType.Money, 0, "BuyPrice"),
				new System.Data.SqlClient.SqlParameter("@Paid", System.Data.SqlDbType.Money, 0, "Paid"),
				new System.Data.SqlClient.SqlParameter("@Rest", System.Data.SqlDbType.Money, 0, "Rest"),
				new System.Data.SqlClient.SqlParameter("@Nots", System.Data.SqlDbType.NVarChar, 0, "Nots"),
				new System.Data.SqlClient.SqlParameter("@Archive", System.Data.SqlDbType.Bit, 0, "Archive"),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BuyDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BuyDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BuyDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BuyDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_CarKindId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "CarKindId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_CarKindId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "CarKindId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EngineNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EngineNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EngineNo", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EngineNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ChassisNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ChassisNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ChassisNo", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ChassisNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_License", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "License", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_License", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "License", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EndLicenseDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EndLicenseDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EndLicenseDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EndLicenseDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PlateNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PlateNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PlateNo", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PlateNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BuyPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BuyPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BuyPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BuyPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Paid", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Paid", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Paid", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Paid", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Rest", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Rest", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Rest", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Rest", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Archive", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Archive", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Archive", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Archive", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[25]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BuyDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BuyDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BuyDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BuyDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_CarKindId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "CarKindId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_CarKindId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "CarKindId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EngineNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EngineNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EngineNo", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EngineNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ChassisNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ChassisNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ChassisNo", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ChassisNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_License", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "License", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_License", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "License", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EndLicenseDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EndLicenseDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EndLicenseDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EndLicenseDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PlateNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PlateNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PlateNo", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PlateNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BuyPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BuyPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BuyPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BuyPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Paid", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Paid", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Paid", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Paid", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Rest", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Rest", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Rest", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Rest", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Archive", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Archive", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Archive", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Archive", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "BuyCar", new System.Data.Common.DataColumnMapping[14]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("BuyDate", "BuyDate"),
					new System.Data.Common.DataColumnMapping("SupplierId", "SupplierId"),
					new System.Data.Common.DataColumnMapping("CarKindId", "CarKindId"),
					new System.Data.Common.DataColumnMapping("EngineNo", "EngineNo"),
					new System.Data.Common.DataColumnMapping("ChassisNo", "ChassisNo"),
					new System.Data.Common.DataColumnMapping("License", "License"),
					new System.Data.Common.DataColumnMapping("EndLicenseDate", "EndLicenseDate"),
					new System.Data.Common.DataColumnMapping("PlateNo", "PlateNo"),
					new System.Data.Common.DataColumnMapping("BuyPrice", "BuyPrice"),
					new System.Data.Common.DataColumnMapping("Paid", "Paid"),
					new System.Data.Common.DataColumnMapping("Rest", "Rest"),
					new System.Data.Common.DataColumnMapping("Nots", "Nots"),
					new System.Data.Common.DataColumnMapping("Archive", "Archive")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			sqlSelectCommand2.CommandText = "SELECT        Company.*\r\nFROM            Company";
			sqlSelectCommand2.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Car.mdf;Integrated Security=True;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.CommandText = "INSERT INTO [Company] ([Name]) VALUES (@Name);\r\nSELECT Id, Name FROM Company WHERE (Id = SCOPE_IDENTITY())";
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[1]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name")
			});
			sqlUpdateCommand2.CommandText = "UPDATE [Company] SET [Name] = @Name WHERE (([Id] = @Original_Id) AND ((@IsNull_Name = 1 AND [Name] IS NULL) OR ([Name] = @Original_Name)));\r\nSELECT Id, Name FROM Company WHERE (Id = @Id)";
			sqlUpdateCommand2.Connection = sqlConnection2;
			sqlUpdateCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[5]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Name", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Name", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Name", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Name", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDeleteCommand2.CommandText = "DELETE FROM [Company] WHERE (([Id] = @Original_Id) AND ((@IsNull_Name = 1 AND [Name] IS NULL) OR ([Name] = @Original_Name)))";
			sqlDeleteCommand2.Connection = sqlConnection2;
			sqlDeleteCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[3]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Name", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Name", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Name", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Name", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter2.DeleteCommand = sqlDeleteCommand2;
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Company", new System.Data.Common.DataColumnMapping[2]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("Name", "Name")
				})
			});
			sqlDataAdapter2.UpdateCommand = sqlUpdateCommand2;
			sqlSelectCommand3.CommandText = "SELECT        Supplier.*\r\nFROM            Supplier";
			sqlSelectCommand3.Connection = sqlConnection3;
			sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Car.mdf;Integrated Security=True;User Instance=True";
			sqlConnection3.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand3.CommandText = resources.GetString("sqlInsertCommand3.CommandText");
			sqlInsertCommand3.Connection = sqlConnection3;
			sqlInsertCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[5]
			{
				new System.Data.SqlClient.SqlParameter("@SupName", System.Data.SqlDbType.NVarChar, 0, "SupName"),
				new System.Data.SqlClient.SqlParameter("@SupAddress", System.Data.SqlDbType.NVarChar, 0, "SupAddress"),
				new System.Data.SqlClient.SqlParameter("@NationalId", System.Data.SqlDbType.NVarChar, 0, "NationalId"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mobile", System.Data.SqlDbType.NVarChar, 0, "Mobile")
			});
			sqlUpdateCommand3.CommandText = resources.GetString("sqlUpdateCommand3.CommandText");
			sqlUpdateCommand3.Connection = sqlConnection3;
			sqlUpdateCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[17]
			{
				new System.Data.SqlClient.SqlParameter("@SupName", System.Data.SqlDbType.NVarChar, 0, "SupName"),
				new System.Data.SqlClient.SqlParameter("@SupAddress", System.Data.SqlDbType.NVarChar, 0, "SupAddress"),
				new System.Data.SqlClient.SqlParameter("@NationalId", System.Data.SqlDbType.NVarChar, 0, "NationalId"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mobile", System.Data.SqlDbType.NVarChar, 0, "Mobile"),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NationalId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NationalId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NationalId", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NationalId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@SupplierID", System.Data.SqlDbType.Int, 4, "SupplierID")
			});
			sqlDeleteCommand3.CommandText = resources.GetString("sqlDeleteCommand3.CommandText");
			sqlDeleteCommand3.Connection = sqlConnection3;
			sqlDeleteCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[11]
			{
				new System.Data.SqlClient.SqlParameter("@Original_SupplierID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NationalId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NationalId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NationalId", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NationalId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mobile", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter3.DeleteCommand = sqlDeleteCommand3;
			sqlDataAdapter3.InsertCommand = sqlInsertCommand3;
			sqlDataAdapter3.SelectCommand = sqlSelectCommand3;
			sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Supplier", new System.Data.Common.DataColumnMapping[6]
				{
					new System.Data.Common.DataColumnMapping("SupplierID", "SupplierID"),
					new System.Data.Common.DataColumnMapping("SupName", "SupName"),
					new System.Data.Common.DataColumnMapping("SupAddress", "SupAddress"),
					new System.Data.Common.DataColumnMapping("NationalId", "NationalId"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mobile", "Mobile")
				})
			});
			sqlDataAdapter3.UpdateCommand = sqlUpdateCommand3;
			sqlSelectCommand4.CommandText = "SELECT        CarKind.*\r\nFROM            CarKind";
			sqlSelectCommand4.Connection = sqlConnection4;
			sqlConnection4.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Car.mdf;Integrated Security=True;User Instance=True";
			sqlConnection4.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand4.CommandText = "INSERT INTO [CarKind] ([CompanyId], [Kind], [Model], [Color]) VALUES (@CompanyId, @Kind, @Model, @Color);\r\nSELECT Id, CompanyId, Kind, Model, Color FROM CarKind WHERE (Id = SCOPE_IDENTITY())";
			sqlInsertCommand4.Connection = sqlConnection4;
			sqlInsertCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[4]
			{
				new System.Data.SqlClient.SqlParameter("@CompanyId", System.Data.SqlDbType.Int, 0, "CompanyId"),
				new System.Data.SqlClient.SqlParameter("@Kind", System.Data.SqlDbType.NVarChar, 0, "Kind"),
				new System.Data.SqlClient.SqlParameter("@Model", System.Data.SqlDbType.NVarChar, 0, "Model"),
				new System.Data.SqlClient.SqlParameter("@Color", System.Data.SqlDbType.NVarChar, 0, "Color")
			});
			sqlUpdateCommand4.CommandText = resources.GetString("sqlUpdateCommand4.CommandText");
			sqlUpdateCommand4.Connection = sqlConnection4;
			sqlUpdateCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[14]
			{
				new System.Data.SqlClient.SqlParameter("@CompanyId", System.Data.SqlDbType.Int, 0, "CompanyId"),
				new System.Data.SqlClient.SqlParameter("@Kind", System.Data.SqlDbType.NVarChar, 0, "Kind"),
				new System.Data.SqlClient.SqlParameter("@Model", System.Data.SqlDbType.NVarChar, 0, "Model"),
				new System.Data.SqlClient.SqlParameter("@Color", System.Data.SqlDbType.NVarChar, 0, "Color"),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_CompanyId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "CompanyId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_CompanyId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "CompanyId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Kind", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Kind", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Kind", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Kind", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Model", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Model", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Model", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Model", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Color", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Color", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Color", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Color", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDeleteCommand4.CommandText = resources.GetString("sqlDeleteCommand4.CommandText");
			sqlDeleteCommand4.Connection = sqlConnection4;
			sqlDeleteCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[9]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_CompanyId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "CompanyId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_CompanyId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "CompanyId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Kind", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Kind", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Kind", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Kind", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Model", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Model", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Model", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Model", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Color", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Color", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Color", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Color", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter4.DeleteCommand = sqlDeleteCommand4;
			sqlDataAdapter4.InsertCommand = sqlInsertCommand4;
			sqlDataAdapter4.SelectCommand = sqlSelectCommand4;
			sqlDataAdapter4.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "CarKind", new System.Data.Common.DataColumnMapping[5]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("CompanyId", "CompanyId"),
					new System.Data.Common.DataColumnMapping("Kind", "Kind"),
					new System.Data.Common.DataColumnMapping("Model", "Model"),
					new System.Data.Common.DataColumnMapping("Color", "Color")
				})
			});
			sqlDataAdapter4.UpdateCommand = sqlUpdateCommand4;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(904, 656);
			base.Controls.Add(panel1);
			base.MaximizeBox = true;
			base.Name = "FrmRptSuplierMoves";
			Text = "حركة مورد";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.Load += new System.EventHandler(FrmRptSuplierMoves_Load);
			panel1.ResumeLayout(false);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}
	}
}
