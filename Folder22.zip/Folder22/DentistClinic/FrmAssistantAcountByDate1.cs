using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Properties;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmAssistantAcountByDate1 : ReportBaseForm
	{
		private ClassDataBase dc;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GUI gui = new GUI();

		private IContainer components = null;

		private GroupBox groupBox1;

		private DateTimePicker date2;

		private DateTimePicker date1;

		private Label label3;

		private ComboBox doctorcomboBox;

		private Label label2;

		private Label label1;

		private GroupBox groupBox2;

		private Button ViewRptBtn;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand4;

		private SqlConnection sqlConnection4;

		private SqlCommand sqlInsertCommand4;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter4;

		private CrystalReportViewer crystalReportViewer1;

		private Label l3;

		private Label l2;

		private Label l1;

		private Label l5;

		private Label l4;

		public FrmAssistantAcountByDate1()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		private void FrmDoctorAcountByDate_Load(object sender, EventArgs e)
		{
			DataTable dataTable = new DataTable();
			try
			{
				dataTable = codes.Search2("SELECT ID, Name FROM Empdata WHERE (Designation = N'Assistant')");
				gui.loadComboBox(doctorcomboBox, dataTable);
			}
			catch
			{
			}
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = dc.GetTableText("select * from Empdata where Name='" + doctorcomboBox.Text + "'");
				if (tableText.Rows.Count > 0)
				{
					DataTable tableText2 = dc.GetTableText("SELECT     dbo.PatientData.PName, dbo.Empdata.Name, dbo.PatientAccount.BeanDate, dbo.NesbaAssistant.Service, dbo.PatientAccount.Price, dbo.NesbaAssistant.Cost, \r\n                      dbo.NesbaAssistant.Safy, dbo.NesbaAssistant.Nesba, dbo.NesbaAssistant.NesbaValue, PatientAccount.ServiceCount\r\nFROM         dbo.PatientData INNER JOIN\r\n                      dbo.PatientAccount ON dbo.PatientData.ID = dbo.PatientAccount.PatientId INNER JOIN\r\n                      dbo.Empdata ON dbo.Empdata.ID = dbo.PatientAccount.DoctorID INNER JOIN\r\n                      dbo.NesbaAssistant ON dbo.PatientAccount.Assistant = dbo.NesbaAssistant.Assistant AND dbo.PatientData.company = dbo.NesbaAssistant.Company AND \r\n                      dbo.PatientAccount.Bean COLLATE Arabic_CI_AS_WS = dbo.NesbaAssistant.Service where dbo.NesbaAssistant.Assistant = '" + doctorcomboBox.Text + "' and dbo.PatientAccount.BeanDate Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "'");
					if (tableText2.Rows.Count > 0)
					{
						sqlConnection4.ConnectionString = dc.ConnectionStr;
						dataSet11.Clear();
						for (int i = 0; i < tableText2.Rows.Count; i++)
						{
							double num = Math.Round((Convert.ToDouble(tableText2.Rows[i]["Price"]) - Convert.ToDouble(tableText2.Rows[i]["Cost"]) * Convert.ToDouble(tableText2.Rows[i]["ServiceCount"])) * Convert.ToDouble(tableText2.Rows[i]["Nesba"].ToString()) / 100.0, 2);
							((DataTable)(object)dataSet11.AccountAssistant).Rows.Add(doctorcomboBox.Text, tableText2.Rows[i][0].ToString(), tableText2.Rows[i][1].ToString(), tableText2.Rows[i][2].ToString(), tableText2.Rows[i][3].ToString(), tableText2.Rows[i][4].ToString(), tableText2.Rows[i][5].ToString(), tableText2.Rows[i][6].ToString(), tableText2.Rows[i][7].ToString(), num);
						}
						sqlDataAdapter4.Fill(dataSet11);
						((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value, date2.Value);
						AssistantAcountbyDateRpt1 assistantAcountbyDateRpt = new AssistantAcountbyDateRpt1();
						assistantAcountbyDateRpt.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = assistantAcountbyDateRpt;
					}
					else
					{
						crystalReportViewer1.ReportSource = null;
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("No Data");
						}
						else
						{
							MessageBox.Show("لا يوجد بيانات لهذا المساعد");
						}
					}
				}
				else
				{
					crystalReportViewer1.ReportSource = null;
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Choose Assistant Name");
					}
					else
					{
						MessageBox.Show("من فضلك تأكد من اسم المساعد");
					}
				}
			}
			catch
			{
			}
		}

		private void groupBox1_Enter(object sender, EventArgs e)
		{
		}

		private void FrmDoctorAcountByDate_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmAssistantAcountByDate1));
			groupBox1 = new System.Windows.Forms.GroupBox();
			l5 = new System.Windows.Forms.Label();
			l4 = new System.Windows.Forms.Label();
			l3 = new System.Windows.Forms.Label();
			l2 = new System.Windows.Forms.Label();
			l1 = new System.Windows.Forms.Label();
			date2 = new System.Windows.Forms.DateTimePicker();
			date1 = new System.Windows.Forms.DateTimePicker();
			ViewRptBtn = new System.Windows.Forms.Button();
			label3 = new System.Windows.Forms.Label();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			dataSet11 = new DataSet1();
			sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlConnection4 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter4 = new System.Data.SqlClient.SqlDataAdapter();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(l5);
			groupBox1.Controls.Add(l4);
			groupBox1.Controls.Add(l3);
			groupBox1.Controls.Add(l2);
			groupBox1.Controls.Add(l1);
			groupBox1.Controls.Add(date2);
			groupBox1.Controls.Add(date1);
			groupBox1.Controls.Add(ViewRptBtn);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(doctorcomboBox);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(label1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			groupBox1.Enter += new System.EventHandler(groupBox1_Enter);
			l5.AccessibleDescription = null;
			l5.AccessibleName = null;
			resources.ApplyResources(l5, "l5");
			l5.Font = null;
			l5.Name = "l5";
			l4.AccessibleDescription = null;
			l4.AccessibleName = null;
			resources.ApplyResources(l4, "l4");
			l4.Font = null;
			l4.Name = "l4";
			l3.AccessibleDescription = null;
			l3.AccessibleName = null;
			resources.ApplyResources(l3, "l3");
			l3.Font = null;
			l3.Name = "l3";
			l2.AccessibleDescription = null;
			l2.AccessibleName = null;
			resources.ApplyResources(l2, "l2");
			l2.Font = null;
			l2.Name = "l2";
			l1.AccessibleDescription = null;
			l1.AccessibleName = null;
			resources.ApplyResources(l1, "l1");
			l1.Font = null;
			l1.Name = "l1";
			date2.AccessibleDescription = null;
			date2.AccessibleName = null;
			resources.ApplyResources(date2, "date2");
			date2.BackgroundImage = null;
			date2.CalendarFont = null;
			date2.Font = null;
			date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date2.Name = "date2";
			date1.AccessibleDescription = null;
			date1.AccessibleName = null;
			resources.ApplyResources(date1, "date1");
			date1.BackgroundImage = null;
			date1.CalendarFont = null;
			date1.Font = null;
			date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date1.Name = "date1";
			ViewRptBtn.AccessibleDescription = null;
			ViewRptBtn.AccessibleName = null;
			resources.ApplyResources(ViewRptBtn, "ViewRptBtn");
			ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
			ViewRptBtn.BackgroundImage = null;
			ViewRptBtn.Name = "ViewRptBtn";
			ViewRptBtn.UseVisualStyleBackColor = false;
			ViewRptBtn.Click += new System.EventHandler(ViewRptBtn_Click);
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			doctorcomboBox.AccessibleDescription = null;
			doctorcomboBox.AccessibleName = null;
			resources.ApplyResources(doctorcomboBox, "doctorcomboBox");
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.BackgroundImage = null;
			doctorcomboBox.Font = null;
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Name = "doctorcomboBox";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlSelectCommand4.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand4.Connection = sqlConnection4;
			sqlConnection4.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection4.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand4.CommandText = resources.GetString("sqlInsertCommand4.CommandText");
			sqlInsertCommand4.Connection = sqlConnection4;
			sqlInsertCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection4;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection4;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter4.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter4.InsertCommand = sqlInsertCommand4;
			sqlDataAdapter4.SelectCommand = sqlSelectCommand4;
			sqlDataAdapter4.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[8]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo")
				})
			});
			sqlDataAdapter4.UpdateCommand = sqlUpdateCommand1;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox2);
			Font = null;
			base.Name = "FrmAssistantAcountByDate1";
			base.Load += new System.EventHandler(FrmDoctorAcountByDate_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(FrmDoctorAcountByDate_KeyDown);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}
	}
}
