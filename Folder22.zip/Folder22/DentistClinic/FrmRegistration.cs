using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmRegistration : Form
	{
		private Splash f = new Splash();

		private string ss;

		private IContainer components = null;

		private GroupBox groupBox1;

		private TextBox textBox1;

		private GroupBox groupBox2;

		private Button button1;

		private Button button3;

		private Label label13;

		private GroupBox groupBox3;

		private Label label6;

		private Label label5;

		private Label label7;

		private TextBox label1;

		public FrmRegistration(string SS)
		{
			InitializeComponent();
			ss = SS;
		}

		private void FrmRegistration_Load(object sender, EventArgs e)
		{
			label1.Text = ss;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (f.getSerial(ss) == textBox1.Text)
				{
					Settings.Default.GetPassword = textBox1.Text;
					Settings.Default.Save();
					MessageBox.Show("نهنئك لقد تم تسجيل البرنامج بنجاح", "شكرا\u064b لإختيارك برنامجنا");
					Application.Restart();
				}
				else if (f.getSerialForSecondary(ss) == textBox1.Text)
				{
					Settings.Default.GetPassword = textBox1.Text;
					Settings.Default.Save();
					MessageBox.Show("نهنئك لقد تم تسجيل البرنامج بنجاح", "شكرا\u064b لإختيارك برنامجنا");
					Application.Restart();
				}
				else
				{
					MessageBox.Show("نأسف , السيريال الذي أدخلته غير صحيح", "خطأ");
				}
			}
			catch
			{
				MessageBox.Show("نأسف , السيريال الذي أدخلته غير صحيح", "خطأ");
			}
		}

		private void FrmRegistration_FormClosing(object sender, FormClosingEventArgs e)
		{
			Application.Exit();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void FrmRegistration_Activated(object sender, EventArgs e)
		{
			textBox1.Focus();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			groupBox1 = new System.Windows.Forms.GroupBox();
			label1 = new System.Windows.Forms.TextBox();
			textBox1 = new System.Windows.Forms.TextBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			button3 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			label13 = new System.Windows.Forms.Label();
			groupBox3 = new System.Windows.Forms.GroupBox();
			label7 = new System.Windows.Forms.Label();
			label6 = new System.Windows.Forms.Label();
			label5 = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			groupBox3.SuspendLayout();
			SuspendLayout();
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(textBox1);
			groupBox1.Location = new System.Drawing.Point(12, 128);
			groupBox1.Name = "groupBox1";
			groupBox1.Size = new System.Drawing.Size(630, 85);
			groupBox1.TabIndex = 19;
			groupBox1.TabStop = false;
			label1.BackColor = System.Drawing.Color.White;
			label1.Font = new System.Drawing.Font("Arial", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label1.ForeColor = System.Drawing.Color.FromArgb(0, 0, 192);
			label1.Location = new System.Drawing.Point(50, 15);
			label1.Name = "label1";
			label1.ReadOnly = true;
			label1.Size = new System.Drawing.Size(516, 26);
			label1.TabIndex = 8;
			label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			textBox1.Font = new System.Drawing.Font("Arial", 12f, System.Drawing.FontStyle.Bold);
			textBox1.Location = new System.Drawing.Point(50, 47);
			textBox1.Name = "textBox1";
			textBox1.Size = new System.Drawing.Size(516, 26);
			textBox1.TabIndex = 0;
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(button3);
			groupBox2.Controls.Add(button1);
			groupBox2.Location = new System.Drawing.Point(12, 219);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(630, 44);
			groupBox2.TabIndex = 20;
			groupBox2.TabStop = false;
			button3.Location = new System.Drawing.Point(30, 13);
			button3.Name = "button3";
			button3.Size = new System.Drawing.Size(75, 23);
			button3.TabIndex = 5;
			button3.Text = "خروج";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			button1.Location = new System.Drawing.Point(269, 13);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(75, 23);
			button1.TabIndex = 4;
			button1.Text = "تسجيل";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			label13.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			label13.BackColor = System.Drawing.Color.SteelBlue;
			label13.Font = new System.Drawing.Font("Arial", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label13.ForeColor = System.Drawing.Color.White;
			label13.Location = new System.Drawing.Point(-1, 1);
			label13.Name = "label13";
			label13.Size = new System.Drawing.Size(654, 20);
			label13.TabIndex = 81;
			label13.Text = "تسجيل البرنامج";
			label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.Controls.Add(label7);
			groupBox3.Controls.Add(label6);
			groupBox3.Controls.Add(label5);
			groupBox3.Location = new System.Drawing.Point(12, 21);
			groupBox3.Name = "groupBox3";
			groupBox3.Size = new System.Drawing.Size(630, 103);
			groupBox3.TabIndex = 82;
			groupBox3.TabStop = false;
			label7.AutoSize = true;
			label7.Font = new System.Drawing.Font("Arial", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label7.ForeColor = System.Drawing.Color.Black;
			label7.Location = new System.Drawing.Point(182, 16);
			label7.Name = "label7";
			label7.Size = new System.Drawing.Size(247, 19);
			label7.TabIndex = 10;
			label7.Text = "هذه الشاشة لا تظهر مطلقا بعد تسجيل البرنامج";
			label6.Font = new System.Drawing.Font("Arial", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label6.ForeColor = System.Drawing.Color.Black;
			label6.Location = new System.Drawing.Point(41, 62);
			label6.Name = "label6";
			label6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			label6.Size = new System.Drawing.Size(549, 27);
			label6.TabIndex = 9;
			label6.Text = "من فضلك أعط هذا الكود لمندوب الشركة و سوف يعطيك الرقم المسلسل الصحيح اللازم لتسجيل البرنامج";
			label5.AutoSize = true;
			label5.Font = new System.Drawing.Font("Arial", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label5.ForeColor = System.Drawing.Color.Black;
			label5.Location = new System.Drawing.Point(136, 39);
			label5.Name = "label5";
			label5.Size = new System.Drawing.Size(344, 19);
			label5.TabIndex = 8;
			label5.Text = "الكود الذي يظهر باللون الازرق ليس هو الكود الذي يكتب بالأسفل ";
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			base.ClientSize = new System.Drawing.Size(654, 273);
			base.Controls.Add(groupBox3);
			base.Controls.Add(label13);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "FrmRegistration";
			base.ShowIcon = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "تسجيل البرنامج";
			base.Load += new System.EventHandler(FrmRegistration_Load);
			base.Activated += new System.EventHandler(FrmRegistration_Activated);
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(FrmRegistration_FormClosing);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			ResumeLayout(false);
		}
	}
}
