using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class CommentFrm : FrmBase
	{
		private dataClass codes;

		private int PatientId;

		private int id;

		private int DoctorID;

		private IContainer components = null;

		private GroupBox groupBox1;

		private GroupBox groupBox2;

		private Button DeleteBtn;

		private Button EditBtn;

		private Button AddBtn;

		private TextBox CommentText;

		private ComboBox PatientIdCom;

		private DateTimePicker dateTimePicker1;

		private Label label3;

		private Label label1;

		private Label label2;

		private DataGridView dataGridView1;

		private Button button1;

		public CommentFrm(int PATIENTID)
		{
			InitializeComponent();
			codes = new dataClass(".\\sqlExpress");
			PatientId = PATIENTID;
		}

		public CommentFrm(int PATIENTID, string Comm)
		{
			InitializeComponent();
			codes = new dataClass(".\\sqlExpress");
			PatientId = PATIENTID;
			CommentText.Text = Comm;
		}

		public CommentFrm(int PATIENTID, int doctorid)
		{
			InitializeComponent();
			codes = new dataClass(".\\sqlExpress");
			PatientId = PATIENTID;
			DoctorID = doctorid;
		}

		public void LoadPatient()
		{
			try
			{
				DataTable dataTable = codes.Search2("select ID,PName from PatientData ");
				PatientIdCom.DataSource = null;
				PatientIdCom.DataSource = dataTable;
				PatientIdCom.DisplayMember = dataTable.Columns[1].ToString();
				PatientIdCom.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		public void DataGrid()
		{
			try
			{
				dataGridView1.Columns[0].Visible = false;
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns[1].HeaderText = "Patient Name";
					dataGridView1.Columns[2].HeaderText = "Date";
					dataGridView1.Columns[3].HeaderText = "Comment";
				}
				else
				{
					dataGridView1.Columns[1].HeaderText = "اسم المريض";
					dataGridView1.Columns[2].HeaderText = "التاريخ";
					dataGridView1.Columns[3].HeaderText = "الملاحظة";
				}
				dataGridView1.Columns[1].Width = 150;
				dataGridView1.Columns[2].Width = 150;
				dataGridView1.Columns[3].Width = 350;
			}
			catch
			{
			}
		}

		public void LoadGrid()
		{
			try
			{
				DataTable dataSource = codes.Search2("SELECT Comments.Id, PatientData.PName, Comments.Date, Comments.Comment\r\n                           FROM   Comments INNER JOIN PatientData ON Comments.PatientId = PatientData.ID where Comments.PatientId =" + PatientId);
				dataGridView1.DataSource = null;
				dataGridView1.DataSource = dataSource;
				DataGrid();
			}
			catch
			{
			}
		}

		private void CommentFrm_Load(object sender, EventArgs e)
		{
			LoadPatient();
			PatientIdCom.SelectedValue = PatientId;
			LoadGrid();
		}

		private void AddBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (PatientIdCom.SelectedItem == null)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Select Correct Patient");
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم مريض صحيح");
					}
					return;
				}
				if (CommentText.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Comment");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل الملاحظة");
					}
					return;
				}
				codes.Add2("INSERT INTO Comments (PatientId, Comment, Date,DoctorID)VALUES('" + PatientIdCom.SelectedValue.ToString() + "','" + CommentText.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "'," + DoctorID + ")");
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				Clear();
			}
			catch
			{
			}
		}

		public void Clear()
		{
			CommentText.Text = "";
			LoadGrid();
			AddBtn.Enabled = true;
			EditBtn.Enabled = false;
			DeleteBtn.Enabled = false;
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
				PatientIdCom.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
				dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[2].Value.ToString());
				CommentText.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
				AddBtn.Enabled = false;
				EditBtn.Enabled = true;
				DeleteBtn.Enabled = true;
			}
			catch
			{
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (PatientIdCom.SelectedItem == null)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Select Correct Patient");
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم مريض صحيح");
					}
					return;
				}
				if (CommentText.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Comment");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل الملاحظة");
					}
					return;
				}
				codes.Edit2("UPDATE Comments SET PatientId ='" + PatientIdCom.SelectedValue.ToString() + "', Comment ='" + CommentText.Text + "', Date ='" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' where Id=" + id);
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Updated Successfully", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("تم تعديل البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				Clear();
			}
			catch
			{
			}
		}

		private void DeleteBtn_Click(object sender, EventArgs e)
		{
			codes.Delete2("DELETE FROM Comments where Id=" + id);
			if (Settings.Default.Language == "en-GB")
			{
				MessageBox.Show("Category Deleted Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else
			{
				MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			Clear();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Clear();
		}

		private void CommentFrm_FormClosing(object sender, FormClosingEventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CommentText = new System.Windows.Forms.TextBox();
            this.PatientIdCom = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.EditBtn = new System.Windows.Forms.Button();
            this.AddBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.CommentText);
            this.groupBox1.Controls.Add(this.PatientIdCom);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(720, 153);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // CommentText
            // 
            this.CommentText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CommentText.Location = new System.Drawing.Point(30, 75);
            this.CommentText.Multiline = true;
            this.CommentText.Name = "CommentText";
            this.CommentText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.CommentText.Size = new System.Drawing.Size(591, 62);
            this.CommentText.TabIndex = 7;
            // 
            // PatientIdCom
            // 
            this.PatientIdCom.Enabled = false;
            this.PatientIdCom.FormattingEnabled = true;
            this.PatientIdCom.Location = new System.Drawing.Point(335, 48);
            this.PatientIdCom.Name = "PatientIdCom";
            this.PatientIdCom.Size = new System.Drawing.Size(286, 21);
            this.PatientIdCom.TabIndex = 6;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(421, 15);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.RightToLeftLayout = true;
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 11.25F);
            this.label3.Location = new System.Drawing.Point(627, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "التاريخ :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 11.25F);
            this.label1.Location = new System.Drawing.Point(626, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "اسم المريض :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 11.25F);
            this.label2.Location = new System.Drawing.Point(626, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "الملاحظة :";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.dataGridView1);
            this.groupBox2.Location = new System.Drawing.Point(12, 205);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(720, 306);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 16);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(714, 287);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.DeleteBtn.Enabled = false;
            this.DeleteBtn.Font = new System.Drawing.Font("Arial", 9.75F);
            this.DeleteBtn.Location = new System.Drawing.Point(375, 172);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(75, 27);
            this.DeleteBtn.TabIndex = 10;
            this.DeleteBtn.Text = "حذف";
            this.DeleteBtn.UseVisualStyleBackColor = false;
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // EditBtn
            // 
            this.EditBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.EditBtn.Enabled = false;
            this.EditBtn.Font = new System.Drawing.Font("Arial", 9.75F);
            this.EditBtn.Location = new System.Drawing.Point(476, 172);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(75, 27);
            this.EditBtn.TabIndex = 8;
            this.EditBtn.Text = "تعديل";
            this.EditBtn.UseVisualStyleBackColor = false;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // AddBtn
            // 
            this.AddBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.AddBtn.Font = new System.Drawing.Font("Arial", 9.75F);
            this.AddBtn.Location = new System.Drawing.Point(579, 172);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(88, 27);
            this.AddBtn.TabIndex = 7;
            this.AddBtn.Text = "اضافة";
            this.AddBtn.UseVisualStyleBackColor = false;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gainsboro;
            this.button1.Enabled = false;
            this.button1.Font = new System.Drawing.Font("Arial", 9.75F);
            this.button1.Location = new System.Drawing.Point(21, 172);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 27);
            this.button1.TabIndex = 11;
            this.button1.Text = "مسح";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // CommentFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(745, 523);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.DeleteBtn);
            this.Controls.Add(this.EditBtn);
            this.Controls.Add(this.AddBtn);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "CommentFrm";
            this.Text = "الملاحظات";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CommentFrm_FormClosing);
            this.Load += new System.EventHandler(this.CommentFrm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

		}
	}
}
