using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmSupplierAccounts : BaseForm
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		private int h;

		private bool b;

		private decimal x;

		private decimal y;

		private decimal m;

		private decimal n;

		private decimal d;

		private decimal o;

		private IContainer components = null;

		private DataGridView dataGridView1;

		private GroupBox groupBox3;

		private Button button4;

		private Button button2;

		private GroupBox groupBox2;

		private DateTimePicker dateTimePicker2;

		private Label label13;

		private Label label5;

		private GroupBox groupBox1;

		private Label label8;

		private ComboBox comboBox1;

		private Label label10;

		private Label label11;

		private Label label1;

		private Button button1;

		private TextBox textBox1;

		private TextBox textBox2;

		private Label label2;

		private TextBox textBox3;

		private Label label4;

		private Label label69;

		private ComboBox comboBox7;

		public FrmSupplierAccounts()
		{
			InitializeComponent();
			h = base.Height;
		}

		public void LoadSupplier()
		{
			try
			{
				DataTable dataTable = Codes.Search2("select * from Supplier ");
				comboBox1.DataSource = null;
				comboBox1.DataSource = dataTable;
				comboBox1.DisplayMember = dataTable.Columns[1].ToString();
				comboBox1.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void FrmSupplierAccounts_Load(object sender, EventArgs e)
		{
			try
			{
				LoadSupplier();
				x = 0m;
				y = 0m;
				b = true;
				Codes.FillDataGrid(dataGridView1, "select SupplierAccounts.ID, Supplier.SupName,SupplierAccounts.Pay,SupplierAccounts.Date from SupplierAccounts,Supplier where SupplierAccounts.SupplierID = Supplier.SupplierID ");
				Headers();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = Codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				comboBox7.DataSource = null;
				comboBox7.DataSource = dataTable;
				comboBox7.DisplayMember = dataTable.Columns[1].ToString();
				comboBox7.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void label1_MouseDown(object sender, MouseEventArgs e)
		{
			Codes.mov = true;
			Codes.x = e.X;
			Codes.y = e.Y;
		}

		private void label1_MouseMove(object sender, MouseEventArgs e)
		{
			if (Codes.mov)
			{
				Point point2 = (base.Location = new Point(Cursor.Position.X - Codes.x, Cursor.Position.Y - Codes.y));
			}
		}

		private void label1_MouseUp(object sender, MouseEventArgs e)
		{
			Codes.mov = false;
		}

		private void button4_Click(object sender, EventArgs e)
		{
			try
			{
				Codes.Showdata(this, h, dataGridView1);
			}
			catch
			{
			}
		}

		private void Headers()
		{
			dataGridView1.Columns[0].Visible = false;
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView1.Columns[1].HeaderText = "Supplier Name";
				dataGridView1.Columns[2].HeaderText = "Pay";
				dataGridView1.Columns[3].HeaderText = "Date";
			}
			else
			{
				dataGridView1.Columns[1].HeaderText = "اسم المورد";
				dataGridView1.Columns[2].HeaderText = "المدفوع";
				dataGridView1.Columns[3].HeaderText = "التاريخ";
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				if (textBox1.Text != "0" || textBox2.Text != "0")
				{
					if (comboBox1.Text == "" || comboBox1.SelectedItem == null)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please enter Supplier Name");
						}
						else
						{
							MessageBox.Show("من فضلك ادخل اسم المورد");
						}
						return;
					}
					if (comboBox1.SelectedIndex == -1)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please enter Treasury Name");
						}
						else
						{
							MessageBox.Show("من فضلك ادخل اسم الخزينة");
						}
						return;
					}
					Codes.Edit2("update Stock set [Value] = [Value] - " + (Convert.ToDecimal(textBox1.Text) - Convert.ToDecimal(textBox2.Text)) + " where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
					decimal num = Convert.ToDecimal(textBox1.Text) - Convert.ToDecimal(textBox2.Text);
					if (num > 0m)
					{
						Codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('مدفوعات للمورد' ," + (Convert.ToDecimal(textBox1.Text) - Convert.ToDecimal(textBox2.Text)) + ",'" + comboBox1.Text + "','" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
					}
					else if (num < 0m)
					{
						Codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('مدفوعات من المورد' ," + Convert.ToDecimal(textBox2.Text) + ",'" + comboBox1.Text + "','" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
					}
					new DataTable();
					if (textBox2.Text != "0")
					{
						DataTable dataTable = Codes.Search2("select sum(Daen),sum(Madeen) from Supplier5 where SupplierID=" + comboBox1.SelectedValue.ToString());
						decimal num2;
						decimal num3;
						try
						{
							num2 = Convert.ToDecimal(dataTable.Rows[0][0].ToString());
							num3 = Convert.ToDecimal(dataTable.Rows[0][1].ToString());
						}
						catch
						{
							num2 = 0m;
							num3 = 0m;
						}
						decimal num4 = num2 - num3 + Convert.ToDecimal(textBox2.Text);
						Codes.Add2("insert into Supplier5 (SupplierID,Daen,Madeen,Raseed,Bayan,[Date]) values (" + comboBox1.SelectedValue.ToString() + "," + Convert.ToDecimal(textBox2.Text) + ",0," + num4 + ",'" + textBox3.Text + "','" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "')");
						Codes.Search2("select * from Supplier5");
					}
					if (textBox1.Text != "0")
					{
						DataTable dataTable = Codes.Search2("select sum(Daen),sum(Madeen) from Supplier5 where SupplierID=" + comboBox1.SelectedValue.ToString());
						decimal num2;
						decimal num3;
						try
						{
							num2 = Convert.ToDecimal(dataTable.Rows[0][0].ToString());
							num3 = Convert.ToDecimal(dataTable.Rows[0][1].ToString());
						}
						catch
						{
							num2 = 0m;
							num3 = 0m;
						}
						decimal num4 = num2 - num3 - Convert.ToDecimal(textBox1.Text);
						Codes.Add2("insert into Supplier5 (SupplierID,Daen,Madeen,Raseed,Bayan,[Date]) values (" + comboBox1.SelectedValue.ToString() + ",0," + Convert.ToDecimal(textBox1.Text) + "," + num4 + ",'" + textBox3.Text + "','" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "')");
						Codes.Search2("select * from Supplier5");
					}
					Codes.Add("insert into SupplierAccounts (SupplierID,Pay,[Date]) values (" + comboBox1.SelectedValue.ToString() + "," + (Convert.ToDecimal(textBox1.Text) - Convert.ToDecimal(textBox2.Text)) + ",'" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "')");
					Codes.FillDataGrid(dataGridView1, "select SupplierAccounts.ID, Supplier.SupName,SupplierAccounts.Pay,SupplierAccounts.Date from SupplierAccounts,Supplier where SupplierAccounts.SupplierID = Supplier.SupplierID ");
					MethodsClass.UserMove("أضافة حساب لمورد");
					Headers();
					clear();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter pay", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else
				{
					MessageBox.Show("من فضلك ادخل قيمة المدفوع", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
			}
		}

		private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && textBox1.Text.Contains("."))
					{
						e.Handled = true;
					}
				}
				else
				{
					e.Handled = true;
				}
			}
			catch
			{
			}
		}

		private void textBox1_Leave(object sender, EventArgs e)
		{
			try
			{
				if (textBox1.Text == "")
				{
					textBox1.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void clear()
		{
			comboBox1.SelectedItem = comboBox1.Items[0];
			textBox1.Text = "0";
			textBox2.Text = "0";
			label8.Text = "0";
		}

		private void label6_Click(object sender, EventArgs e)
		{
		}

		private void label2_Click(object sender, EventArgs e)
		{
		}

		private void label7_Click(object sender, EventArgs e)
		{
		}

		private void groupBox3_Enter(object sender, EventArgs e)
		{
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
			try
			{
				double num = Convert.ToDouble(textBox2.Text);
				if (num > 0.0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("There is a value in Pay From");
					}
					else
					{
						MessageBox.Show("يوجد قيمة في المدفوع منه");
					}
					textBox1.Text = "0";
					return;
				}
				m = Convert.ToDecimal(textBox1.Text.ToString());
				DataTable dataTable = Codes.Search2("select Value from Stock where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
				if (dataTable.Rows.Count <= 0)
				{
					return;
				}
				n = Convert.ToDecimal(dataTable.Rows[0][0].ToString());
				if (m > n)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Treasury value " + n + " Only", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
					else
					{
						MessageBox.Show("قيمة الخزينة" + n + " فقط", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
					textBox1.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				label8.Text = "0";
				if (b)
				{
					try
					{
						x = Convert.ToDecimal(Codes.Search2("select sum(Madeen) from Supplier5 where SupplierId = " + comboBox1.SelectedValue.ToString()).Rows[0][0].ToString());
					}
					catch
					{
						x = 0m;
					}
					try
					{
						y = Convert.ToDecimal(Codes.Search2("select sum(Daen) from Supplier5 where SupplierId = " + comboBox1.SelectedValue.ToString()).Rows[0][0].ToString());
					}
					catch
					{
						y = 0m;
					}
					label8.Text = (y - x).ToString();
				}
			}
			catch
			{
			}
		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{
			try
			{
				double num = Convert.ToDouble(textBox1.Text);
				if (num > 0.0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("There is a value in Pay For");
					}
					else
					{
						MessageBox.Show("يوجد قيمة في المدفوع له");
					}
					textBox2.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void textBox2_Leave(object sender, EventArgs e)
		{
			try
			{
				if (textBox2.Text == "")
				{
					textBox2.Text = "0";
				}
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmSupplierAccounts));
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox3 = new System.Windows.Forms.GroupBox();
			button4 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			groupBox2 = new System.Windows.Forms.GroupBox();
			textBox3 = new System.Windows.Forms.TextBox();
			label4 = new System.Windows.Forms.Label();
			textBox2 = new System.Windows.Forms.TextBox();
			label2 = new System.Windows.Forms.Label();
			textBox1 = new System.Windows.Forms.TextBox();
			label5 = new System.Windows.Forms.Label();
			dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			label13 = new System.Windows.Forms.Label();
			groupBox1 = new System.Windows.Forms.GroupBox();
			label69 = new System.Windows.Forms.Label();
			comboBox7 = new System.Windows.Forms.ComboBox();
			label8 = new System.Windows.Forms.Label();
			comboBox1 = new System.Windows.Forms.ComboBox();
			label10 = new System.Windows.Forms.Label();
			label11 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			button1 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox3.SuspendLayout();
			groupBox2.SuspendLayout();
			groupBox1.SuspendLayout();
			SuspendLayout();
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(button4);
			groupBox3.Controls.Add(button2);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			groupBox3.Enter += new System.EventHandler(groupBox3_Enter);
			button4.AccessibleDescription = null;
			button4.AccessibleName = null;
			resources.ApplyResources(button4, "button4");
			button4.BackColor = System.Drawing.Color.Gainsboro;
			button4.BackgroundImage = null;
			button4.Font = null;
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = false;
			button4.Click += new System.EventHandler(button4_Click);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackColor = System.Drawing.Color.Gainsboro;
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = false;
			button2.Click += new System.EventHandler(button2_Click);
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(textBox3);
			groupBox2.Controls.Add(label4);
			groupBox2.Controls.Add(textBox2);
			groupBox2.Controls.Add(label2);
			groupBox2.Controls.Add(textBox1);
			groupBox2.Controls.Add(label5);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			textBox3.AccessibleDescription = null;
			textBox3.AccessibleName = null;
			resources.ApplyResources(textBox3, "textBox3");
			textBox3.BackgroundImage = null;
			textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			textBox3.Font = null;
			textBox3.Name = "textBox3";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Font = null;
			label4.ForeColor = System.Drawing.Color.Black;
			label4.Name = "label4";
			textBox2.AccessibleDescription = null;
			textBox2.AccessibleName = null;
			resources.ApplyResources(textBox2, "textBox2");
			textBox2.BackgroundImage = null;
			textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			textBox2.Font = null;
			textBox2.Name = "textBox2";
			textBox2.TextChanged += new System.EventHandler(textBox2_TextChanged);
			textBox2.Leave += new System.EventHandler(textBox2_Leave);
			textBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(textBox1_KeyPress);
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Font = null;
			label2.ForeColor = System.Drawing.Color.Black;
			label2.Name = "label2";
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			textBox1.Font = null;
			textBox1.Name = "textBox1";
			textBox1.TextChanged += new System.EventHandler(textBox1_TextChanged);
			textBox1.Leave += new System.EventHandler(textBox1_Leave);
			textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(textBox1_KeyPress);
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label5");
			label5.Font = null;
			label5.ForeColor = System.Drawing.Color.Black;
			label5.Name = "label5";
			dateTimePicker2.AccessibleDescription = null;
			dateTimePicker2.AccessibleName = null;
			resources.ApplyResources(dateTimePicker2, "dateTimePicker2");
			dateTimePicker2.BackgroundImage = null;
			dateTimePicker2.CalendarFont = null;
			dateTimePicker2.Font = null;
			dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker2.Name = "dateTimePicker2";
			label13.AccessibleDescription = null;
			label13.AccessibleName = null;
			resources.ApplyResources(label13, "label13");
			label13.Font = null;
			label13.ForeColor = System.Drawing.Color.Black;
			label13.Name = "label13";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(label69);
			groupBox1.Controls.Add(comboBox7);
			groupBox1.Controls.Add(label8);
			groupBox1.Controls.Add(comboBox1);
			groupBox1.Controls.Add(label10);
			groupBox1.Controls.Add(label11);
			groupBox1.Controls.Add(dateTimePicker2);
			groupBox1.Controls.Add(label13);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			label69.AccessibleDescription = null;
			label69.AccessibleName = null;
			resources.ApplyResources(label69, "label69");
			label69.BackColor = System.Drawing.Color.Transparent;
			label69.Name = "label69";
			comboBox7.AccessibleDescription = null;
			comboBox7.AccessibleName = null;
			resources.ApplyResources(comboBox7, "comboBox7");
			comboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox7.BackgroundImage = null;
			comboBox7.FormattingEnabled = true;
			comboBox7.Name = "comboBox7";
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "label8");
			label8.BackColor = System.Drawing.Color.White;
			label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			label8.Font = null;
			label8.Name = "label8";
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.Font = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Name = "comboBox1";
			comboBox1.SelectedIndexChanged += new System.EventHandler(comboBox1_SelectedIndexChanged);
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "label10");
			label10.Font = null;
			label10.ForeColor = System.Drawing.Color.Black;
			label10.Name = "label10";
			label11.AccessibleDescription = null;
			label11.AccessibleName = null;
			resources.ApplyResources(label11, "label11");
			label11.Font = null;
			label11.ForeColor = System.Drawing.Color.Black;
			label11.Name = "label11";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.BackColor = System.Drawing.Color.DimGray;
			label1.ForeColor = System.Drawing.Color.White;
			label1.Name = "label1";
			label1.MouseMove += new System.Windows.Forms.MouseEventHandler(label1_MouseMove);
			label1.MouseDown += new System.Windows.Forms.MouseEventHandler(label1_MouseDown);
			label1.MouseUp += new System.Windows.Forms.MouseEventHandler(label1_MouseUp);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.White;
			button1.BackgroundImage = null;
			button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
			button1.Font = null;
			button1.ForeColor = System.Drawing.Color.Black;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightGray;
			BackgroundImage = null;
			base.Controls.Add(dataGridView1);
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.Controls.Add(label1);
			base.Controls.Add(button1);
			Font = null;
			base.Name = "FrmSupplierAccounts";
			base.Load += new System.EventHandler(FrmSupplierAccounts_Load);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox3.ResumeLayout(false);
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			ResumeLayout(false);
		}
	}
}
