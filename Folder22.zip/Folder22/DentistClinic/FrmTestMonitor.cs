using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace DentistClinic
{
	public class FrmTestMonitor : Form
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private TreeView treeView1;

		private Timer timer1;

		private Label label1;

		public FrmTestMonitor()
		{
			InitializeComponent();
		}

		private void FrmTestMonitor_Load(object sender, EventArgs e)
		{
			try
			{
				treeView1.Nodes.Clear();
				DataTable dataTable = new DataTable();
				dataTable = Codes.Search2("SELECT distinct Empdata.Name\r\nFROM         dbo.Appointments INNER JOIN\r\n                      dbo.Empdata ON dbo.Appointments.DoctorID = dbo.Empdata.ID where Appointments.detectDate='" + DateTime.Now.ToString("MM/dd/yyyy") + "' and Appointments.Done='False'");
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					treeView1.Nodes.Add("دكتور / " + dataTable.Rows[i][0].ToString());
					DataTable dataTable2 = new DataTable();
					dataTable2 = ((!(Codes.Search2("select AppointSystem from Properties").Rows[0][0].ToString() == "1")) ? Codes.Search2("SELECT dbo.PatientData.PName,dbo.Appointments.AppointNum,dbo.Appointments.detectStartTime,Appointments.AppointNum\r\nFROM         dbo.Appointments INNER JOIN\r\n                      dbo.Empdata ON dbo.Appointments.DoctorID = dbo.Empdata.ID INNER JOIN\r\n                      dbo.PatientData ON dbo.Appointments.PatuentID = dbo.PatientData.ID  where Appointments.detectDate='" + DateTime.Now.ToString("MM/dd/yyyy") + "' and Appointments.Done='False' and Empdata.Name='" + dataTable.Rows[i][0].ToString() + "' order by Appointments.AppointNum") : Codes.Search2("SELECT dbo.PatientData.PName,dbo.Appointments.AppointNum,dbo.Appointments.detectStartTime,Appointments.AppointNum\r\nFROM         dbo.Appointments INNER JOIN\r\n                      dbo.Empdata ON dbo.Appointments.DoctorID = dbo.Empdata.ID INNER JOIN\r\n                      dbo.PatientData ON dbo.Appointments.PatuentID = dbo.PatientData.ID  where Appointments.detectDate='" + DateTime.Now.ToString("MM/dd/yyyy") + "' and Appointments.Done='False' and Empdata.Name='" + dataTable.Rows[i][0].ToString() + "' order by LEFT(Appointments.detectStartTime, 2),substring(Appointments.detectStartTime,4,2)"));
					string text = "";
					try
					{
						text = dataTable2.Rows[1][0].ToString();
					}
					catch
					{
						text = "";
					}
					if (dataTable2.Rows.Count > 0)
					{
						treeView1.Nodes[i].Nodes.Add("     الحالى / " + dataTable2.Rows[0][0].ToString());
						treeView1.Nodes[i].Nodes.Add("     التالى / " + text);
						treeView1.Nodes[i].Nodes.Add("");
					}
				}
				treeView1.ExpandAll();
			}
			catch
			{
			}
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				treeView1.Nodes.Clear();
				DataTable dataTable = new DataTable();
				dataTable = Codes.Search2("SELECT distinct Empdata.Name\r\nFROM         dbo.Appointments INNER JOIN\r\n                      dbo.Empdata ON dbo.Appointments.DoctorID = dbo.Empdata.ID where Appointments.detectDate='" + DateTime.Now.ToString("MM/dd/yyyy") + "' and Appointments.Done='False'");
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					treeView1.Nodes.Add("دكتور / " + dataTable.Rows[i][0].ToString());
					DataTable dataTable2 = new DataTable();
					dataTable2 = ((!(Codes.Search2("select AppointSystem from Properties").Rows[0][0].ToString() == "1")) ? Codes.Search2("SELECT dbo.PatientData.PName,dbo.Appointments.AppointNum,dbo.Appointments.detectStartTime,Appointments.AppointNum\r\nFROM         dbo.Appointments INNER JOIN\r\n                      dbo.Empdata ON dbo.Appointments.DoctorID = dbo.Empdata.ID INNER JOIN\r\n                      dbo.PatientData ON dbo.Appointments.PatuentID = dbo.PatientData.ID  where Appointments.detectDate='" + DateTime.Now.ToString("MM/dd/yyyy") + "' and Appointments.Done='False' and Empdata.Name='" + dataTable.Rows[i][0].ToString() + "' order by Appointments.AppointNum") : Codes.Search2("SELECT dbo.PatientData.PName,dbo.Appointments.AppointNum,dbo.Appointments.detectStartTime,Appointments.AppointNum\r\nFROM         dbo.Appointments INNER JOIN\r\n                      dbo.Empdata ON dbo.Appointments.DoctorID = dbo.Empdata.ID INNER JOIN\r\n                      dbo.PatientData ON dbo.Appointments.PatuentID = dbo.PatientData.ID  where Appointments.detectDate='" + DateTime.Now.ToString("MM/dd/yyyy") + "' and Appointments.Done='False' and Empdata.Name='" + dataTable.Rows[i][0].ToString() + "' order by LEFT(Appointments.detectStartTime, 2),substring(Appointments.detectStartTime,4,2)"));
					string text = "";
					try
					{
						text = dataTable2.Rows[1][0].ToString();
					}
					catch
					{
						text = "";
					}
					if (dataTable2.Rows.Count > 0)
					{
						treeView1.Nodes[i].Nodes.Add("     الحالى / " + dataTable2.Rows[0][0].ToString());
						treeView1.Nodes[i].Nodes.Add("     التالى / " + text);
						treeView1.Nodes[i].Nodes.Add("");
					}
				}
				treeView1.ExpandAll();
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			timer1 = new System.Windows.Forms.Timer(components);
			label1 = new System.Windows.Forms.Label();
			treeView1 = new System.Windows.Forms.TreeView();
			SuspendLayout();
			timer1.Enabled = true;
			timer1.Interval = 3000;
			timer1.Tick += new System.EventHandler(timer1_Tick);
			label1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			label1.BackColor = System.Drawing.SystemColors.Window;
			label1.Font = new System.Drawing.Font("Tahoma", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label1.ForeColor = System.Drawing.Color.FromArgb(85, 182, 250);
			label1.Location = new System.Drawing.Point(-1, 0);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(726, 35);
			label1.TabIndex = 2;
			label1.Text = "شاشة الحجوزات";
			label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			treeView1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			treeView1.BackColor = System.Drawing.Color.FromArgb(85, 182, 250);
			treeView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			treeView1.Font = new System.Drawing.Font("Elephant", 48f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			treeView1.ForeColor = System.Drawing.Color.Black;
			treeView1.HideSelection = false;
			treeView1.Location = new System.Drawing.Point(12, 54);
			treeView1.Name = "treeView1";
			treeView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			treeView1.RightToLeftLayout = true;
			treeView1.ShowLines = false;
			treeView1.ShowPlusMinus = false;
			treeView1.ShowRootLines = false;
			treeView1.Size = new System.Drawing.Size(700, 542);
			treeView1.TabIndex = 1;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.FromArgb(85, 182, 250);
			BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			base.ClientSize = new System.Drawing.Size(724, 787);
			base.Controls.Add(treeView1);
			base.Controls.Add(label1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "FrmTestMonitor";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "FrmTestMonitor";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.Load += new System.EventHandler(FrmTestMonitor_Load);
			ResumeLayout(false);
		}
	}
}
