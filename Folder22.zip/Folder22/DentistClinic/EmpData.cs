using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class EmpData : BaseForm
	{
		private int empid;

		private ClassDataBase dc;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private GUI gui = new GUI();

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private GroupBox groupBox5;

		private Button EditBtn;

		private Button saveBtn;

		private Button Searchbtn;

		private GroupBox groupBox1;

		private DataGridView dataGridView1;

		private Button DeletBtn;

		private GroupBox groupBox2;

		private Label label7;

		private ColorDialog colorDialog1;

		private FontDialog fontDialog1;

		private TextBox emailTextBox;

		private TextBox mobTextBox;

		private TextBox telTextBox;

		private TextBox SalaryTextBox;

		private ComboBox typeComboBox;

		private TextBox percentTextBox;

		private Label label2;

		private TextBox SignatureText;

		private Label label4;

		private Label label3;

		private Label label5;

		private NumericUpDown numericUpDown1;

		private NumericUpDown numericUpDown2;

		private RichTextBox nameTextBox;

		private Button button2;

		private Button button3;

		private Button button4;

		private Button button1;

		private Button button6;

		private Button button5;

		private RichTextBox addressTextBox;

		private RichTextBox SpecialtyText;

		private Button button8;

		private Button button7;

		private GroupBox groupBox4;

		private Label label8;

		private RichTextBox richTextBox2;

		private Button button9;

		private Button button10;

		private Label label9;

		private Label label10;

		private RichTextBox richTextBox1;

		private Label cardNumLabel;

		private Label label1;

		private Label label6;

		private DataGridViewTextBoxColumn ID;

		private DataGridViewTextBoxColumn Designation;

		private DataGridViewTextBoxColumn Names;

		private DataGridViewTextBoxColumn Address;

		private DataGridViewTextBoxColumn Tel;

		private DataGridViewTextBoxColumn Mob;

		private DataGridViewTextBoxColumn Email;

		private DataGridViewTextBoxColumn Salary;

		private DataGridViewTextBoxColumn Percentage;

		private DataGridViewTextBoxColumn Specialty;

		private DataGridViewTextBoxColumn Signature;

		private DataGridViewTextBoxColumn AppointCount;

		private DataGridViewTextBoxColumn BacksCount;

		private DataGridViewTextBoxColumn EnName;

		private DataGridViewTextBoxColumn EnSpecialty;

		private TextBox WorkDatatEXT;

		private Label label11;

		public EmpData()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		private void EmpData_Load(object sender, EventArgs e)
		{
			loaddata();
		}

		private string GetText(string rtfText)
		{
			try
			{
				RichTextBox richTextBox = new RichTextBox();
				richTextBox.Rtf = rtfText;
				return richTextBox.Text;
			}
			catch
			{
				return rtfText;
			}
		}

		public string GetPlainText(object richText)
		{
			using (RichTextBox richTextBox = new RichTextBox())
			{
				richTextBox.Rtf = Convert.ToString(richText);
				return richTextBox.Text;
			}
		}

		private void loaddata()
		{
			typeComboBox.SelectedItem = typeComboBox.Items[0];
			DataTable dataTable = new DataTable();
			dataTable = dc.GetTableText("select * from EmpData");
			dataGridView1.DataSource = null;
			dataGridView1.Rows.Clear();
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				string text = "";
				string text2 = "";
				try
				{
					RichTextBox richTextBox = new RichTextBox();
					richTextBox.Rtf = dataTable.Rows[i][3].ToString();
					text = richTextBox.Text;
				}
				catch
				{
					text = dataTable.Rows[i][3].ToString();
				}
				try
				{
					RichTextBox richTextBox2 = new RichTextBox();
					richTextBox2.Rtf = dataTable.Rows[i][9].ToString();
					text2 = richTextBox2.Text;
				}
				catch
				{
					text2 = dataTable.Rows[i][9].ToString();
				}
				try
				{
					RichTextBox richTextBox3 = new RichTextBox();
					richTextBox3.Rtf = dataTable.Rows[i][14].ToString();
					_ = richTextBox3.Text;
				}
				catch
				{
					dataTable.Rows[i][14].ToString();
				}
				dataGridView1.Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), text, dataTable.Rows[i][4].ToString(), dataTable.Rows[i][5].ToString(), dataTable.Rows[i][6].ToString(), dataTable.Rows[i][7].ToString(), dataTable.Rows[i][8].ToString(), text2, dataTable.Rows[i][10].ToString(), dataTable.Rows[i][11].ToString(), dataTable.Rows[i][12].ToString(), dataTable.Rows[i][13].ToString(), dataTable.Rows[i][14].ToString());
			}
		}

		private void clear()
		{
			SpecialtyText.Text = "";
			SignatureText.Text = "";
			nameTextBox.Text = "";
			addressTextBox.Text = "";
			telTextBox.Text = "";
			mobTextBox.Text = "";
			emailTextBox.Text = "";
			richTextBox1.Text = "";
			richTextBox2.Text = "";
			SalaryTextBox.Text = "0";
			percentTextBox.Text = "0";
			numericUpDown1.Value = 0m;
			numericUpDown2.Value = 0m;
			WorkDatatEXT.Text = "";
			saveBtn.Enabled = true;
			EditBtn.Enabled = false;
			DeletBtn.Enabled = false;
		}

		private void telTextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && telTextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل ارقام فقط");
				}
				e.Handled = true;
			}
			catch
			{
			}
		}

		private void SalaryTextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && SalaryTextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل ارقام فقط");
				}
				e.Handled = true;
			}
			catch
			{
			}
		}

		private void percentTextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && percentTextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل ارقام فقط");
				}
				e.Handled = true;
			}
			catch
			{
			}
		}

		private void emailTextBox_Validating(object sender, CancelEventArgs e)
		{
			Regex regex = new Regex("^[a-zA-Z][\\w\\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z][a-zA-Z\\.]*[a-zA-Z]$");
			if (emailTextBox.Text.Length > 0 && !regex.IsMatch(emailTextBox.Text))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Valid Email");
				}
				else
				{
					MessageBox.Show("من فضلك أدخل بريد الكتروني صحيح");
				}
				emailTextBox.Text = "";
			}
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (nameTextBox.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الموظف");
					}
					return;
				}
				DataTable dataTable = new DataTable();
				dataTable = dc.GetTableText("select * from Empdata where Name = '" + nameTextBox.Text + "'");
				if (dataTable.Rows.Count == 0)
				{
					string[] fields = new string[15]
					{
						"Designation", "Name", "Address", "Tel", "Mob", "Email", "Salary", "Percentage", "Specialty", "Signature",
						"AppointCount", "BacksCount", "EnName", "EnSpecialty", "WorkData"
					};
					if (dc.Insert("AddEmpData", fields, typeComboBox.Text, nameTextBox.Text, addressTextBox.Rtf, telTextBox.Text, mobTextBox.Text, emailTextBox.Text, SalaryTextBox.Text, percentTextBox.Text, SpecialtyText.Rtf, SignatureText.Text, Convert.ToInt32(numericUpDown1.Value), Convert.ToInt32(numericUpDown2.Value), richTextBox1.Text, richTextBox2.Rtf, WorkDatatEXT.Text))
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove(" أضافة موظف");
						loaddata();
						clear();
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("You Have Save This Name Before");
				}
				else
				{
					MessageBox.Show("هذا الإسم مسجل من قبل", "تنبيه");
				}
			}
			catch
			{
			}
		}

		private void SalaryTextBox_Leave(object sender, EventArgs e)
		{
			try
			{
				if (SalaryTextBox.Text == "")
				{
					SalaryTextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void percentTextBox_Leave(object sender, EventArgs e)
		{
			try
			{
				if (percentTextBox.Text == "")
				{
					percentTextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void nameTextBox_TextChanged(object sender, EventArgs e)
		{
			string text = nameTextBox.Text;
			if (text.StartsWith(" "))
			{
				MessageBox.Show("لا يمكن ترك فراغ في بداية الإسم", "تنبيه");
				nameTextBox.Text = "";
			}
		}

		private void mobTextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			char keyChar = e.KeyChar;
			if (!char.IsDigit(keyChar) && keyChar != '\b')
			{
				e.Handled = true;
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل ارقام فقط");
				}
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (nameTextBox.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الموظف");
					}
					return;
				}
				DataTable dataTable = new DataTable();
				dataTable = dc.GetTableText("select * from Empdata where Name = '" + nameTextBox.Text + "' and ID != " + empid);
				if (dataTable.Rows.Count == 0)
				{
					string[] fields = new string[16]
					{
						"ID", "Designation", "Name", "Address", "Tel", "Mob", "Email", "Salary", "Percentage", "Specialty",
						"Signature", "AppointCount", "BacksCount", "EnName", "EnSpecialty", "WorkData"
					};
					if (dc.Update("UpdateEmpData", fields, empid, typeComboBox.Text, nameTextBox.Text, addressTextBox.Rtf, telTextBox.Text, mobTextBox.Text, emailTextBox.Text, SalaryTextBox.Text, percentTextBox.Text, SpecialtyText.Rtf, SignatureText.Text, Convert.ToInt32(numericUpDown1.Value), Convert.ToInt32(numericUpDown2.Value), richTextBox1.Text, richTextBox2.Rtf, WorkDatatEXT.Text))
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove(" تعديل موظف");
						loaddata();
						clear();
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("You Have Save This Name Before");
				}
				else
				{
					MessageBox.Show("هذا الإسم مسجل من قبل", "تنبيه");
				}
			}
			catch
			{
			}
		}

		private void DeletBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.CurrentRow.Cells[0].Value.ToString() == "1")
				{
					MessageBox.Show("ليس لديك صلاحية حذف موظف رئيسي");
					return;
				}
				DialogResult dialogResult = DialogResult.None;
				dialogResult = ((!(Settings.Default.Language == "en-GB")) ? MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) : MessageBox.Show("Are You Sure You Want To Delete This Data?", "", MessageBoxButtons.OKCancel, MessageBoxIcon.Question));
				if (dialogResult != DialogResult.OK)
				{
					return;
				}
				string[] fields = new string[1] { "ID" };
				if (dc.Delete("DeleteEmpData", fields, empid))
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Deleted Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					MethodsClass.UserMove(" حذف موظف");
					loaddata();
					clear();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("An Error Occurred During The Deletion Process ", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			catch
			{
			}
		}

		private void Searchbtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = dc.GetTableText("select * from EmpData where Name like  '%" + Codes.SearchText("") + "%'");
				gui.loadDataGrid(dataGridView1, tableText);
				dataGridView1.DataSource = null;
				dataGridView1.Rows.Clear();
				for (int i = 0; i < tableText.Rows.Count; i++)
				{
					string text = "";
					string text2 = "";
					try
					{
						RichTextBox richTextBox = new RichTextBox();
						richTextBox.Rtf = tableText.Rows[i][3].ToString();
						text = richTextBox.Text;
					}
					catch
					{
						text = tableText.Rows[i][3].ToString();
					}
					try
					{
						RichTextBox richTextBox2 = new RichTextBox();
						richTextBox2.Rtf = tableText.Rows[i][9].ToString();
						text2 = richTextBox2.Text;
					}
					catch
					{
						text2 = tableText.Rows[i][9].ToString();
					}
					try
					{
						RichTextBox richTextBox3 = new RichTextBox();
						richTextBox3.Rtf = tableText.Rows[i][14].ToString();
						_ = richTextBox3.Text;
					}
					catch
					{
						tableText.Rows[i][14].ToString();
					}
					dataGridView1.Rows.Add(tableText.Rows[i][0].ToString(), tableText.Rows[i][1].ToString(), tableText.Rows[i][2].ToString(), text, tableText.Rows[i][4].ToString(), tableText.Rows[i][5].ToString(), tableText.Rows[i][6].ToString(), tableText.Rows[i][7].ToString(), tableText.Rows[i][8].ToString(), text2, tableText.Rows[i][10].ToString(), tableText.Rows[i][11].ToString(), tableText.Rows[i][12].ToString(), tableText.Rows[i][13].ToString(), tableText.Rows[i][14].ToString());
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				EditBtn.Enabled = true;
				saveBtn.Enabled = false;
				DeletBtn.Enabled = true;
				empid = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
				typeComboBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
				nameTextBox.Text = Convert.ToString(dataGridView1.CurrentRow.Cells[2].Value);
				telTextBox.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
				mobTextBox.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
				emailTextBox.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
				SalaryTextBox.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
				percentTextBox.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
				richTextBox1.Text = dataGridView1.CurrentRow.Cells[13].Value.ToString();
				SignatureText.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
				numericUpDown1.Value = Convert.ToDecimal(dataGridView1.CurrentRow.Cells[11].Value.ToString());
				numericUpDown2.Value = Convert.ToDecimal(dataGridView1.CurrentRow.Cells[12].Value.ToString());
				DataTable dataTable = Codes.Search2("select Name,Address,Specialty,EnSpecialty,WorkData from Empdata where ID = '" + empid + "'");
				addressTextBox.Rtf = dataTable.Rows[0][1].ToString();
				SpecialtyText.Rtf = dataTable.Rows[0][2].ToString();
				richTextBox2.Rtf = dataTable.Rows[0][3].ToString();
				try
				{
					WorkDatatEXT.Text = dataTable.Rows[0]["WorkData"].ToString();
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void EmpData_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void typeComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (typeComboBox.Text == "Doctor")
			{
				SpecialtyText.Visible = true;
				label2.Visible = true;
				SignatureText.Visible = true;
				label4.Visible = true;
				label3.Visible = true;
				label5.Visible = true;
				numericUpDown1.Visible = true;
				numericUpDown2.Visible = true;
				label9.Visible = true;
				button6.Visible = true;
				button5.Visible = true;
				label10.Visible = true;
				label8.Visible = true;
				richTextBox2.Visible = true;
				button10.Visible = true;
				button9.Visible = true;
				label6.Visible = true;
				richTextBox1.Visible = true;
				button8.Visible = true;
				button7.Visible = true;
				cardNumLabel.Visible = true;
				percentTextBox.Visible = true;
				label1.Visible = true;
				label11.Visible = true;
				WorkDatatEXT.Visible = true;
			}
			else
			{
				SpecialtyText.Visible = false;
				label2.Visible = false;
				SignatureText.Visible = false;
				label4.Visible = false;
				label3.Visible = false;
				label5.Visible = false;
				numericUpDown1.Visible = false;
				numericUpDown2.Visible = false;
				numericUpDown1.Value = 0m;
				numericUpDown2.Value = 0m;
				label9.Visible = false;
				button6.Visible = false;
				button5.Visible = false;
				label10.Visible = false;
				label8.Visible = false;
				richTextBox2.Visible = false;
				button10.Visible = false;
				button9.Visible = false;
				label6.Visible = false;
				richTextBox1.Visible = false;
				button8.Visible = false;
				button7.Visible = false;
				cardNumLabel.Visible = false;
				percentTextBox.Visible = false;
				label1.Visible = false;
				label11.Visible = false;
				WorkDatatEXT.Visible = false;
			}
		}

		private void button4_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = fontDialog1.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				nameTextBox.SelectionFont = fontDialog1.Font;
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = colorDialog1.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				nameTextBox.SelectionColor = colorDialog1.Color;
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = fontDialog1.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				addressTextBox.SelectionFont = fontDialog1.Font;
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = colorDialog1.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				addressTextBox.SelectionColor = colorDialog1.Color;
			}
		}

		private void button6_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = fontDialog1.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				SpecialtyText.SelectionFont = fontDialog1.Font;
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = colorDialog1.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				SpecialtyText.SelectionColor = colorDialog1.Color;
			}
		}

		private void SpecialtyText_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
		{
		}

		private void SpecialtyText_KeyDown(object sender, KeyEventArgs e)
		{
		}

		private void button8_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = fontDialog1.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				richTextBox1.SelectionFont = fontDialog1.Font;
			}
		}

		private void button7_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = colorDialog1.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				richTextBox1.SelectionColor = colorDialog1.Color;
			}
		}

		private void button9_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = colorDialog1.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				richTextBox2.SelectionColor = colorDialog1.Color;
			}
		}

		private void button10_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = fontDialog1.ShowDialog();
			if (dialogResult == DialogResult.OK)
			{
				richTextBox2.SelectionFont = fontDialog1.Font;
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.EmpData));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			cardNumLabel = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			groupBox5 = new System.Windows.Forms.GroupBox();
			DeletBtn = new System.Windows.Forms.Button();
			Searchbtn = new System.Windows.Forms.Button();
			saveBtn = new System.Windows.Forms.Button();
			EditBtn = new System.Windows.Forms.Button();
			groupBox1 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Designation = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Names = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Tel = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Mob = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Salary = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Percentage = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Specialty = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Signature = new System.Windows.Forms.DataGridViewTextBoxColumn();
			AppointCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
			BacksCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
			EnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			EnSpecialty = new System.Windows.Forms.DataGridViewTextBoxColumn();
			groupBox2 = new System.Windows.Forms.GroupBox();
			this.label7 = new System.Windows.Forms.Label();
			colorDialog1 = new System.Windows.Forms.ColorDialog();
			fontDialog1 = new System.Windows.Forms.FontDialog();
			emailTextBox = new System.Windows.Forms.TextBox();
			mobTextBox = new System.Windows.Forms.TextBox();
			telTextBox = new System.Windows.Forms.TextBox();
			SalaryTextBox = new System.Windows.Forms.TextBox();
			typeComboBox = new System.Windows.Forms.ComboBox();
			percentTextBox = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			SignatureText = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			numericUpDown2 = new System.Windows.Forms.NumericUpDown();
			nameTextBox = new System.Windows.Forms.RichTextBox();
			button2 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			button4 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			button6 = new System.Windows.Forms.Button();
			button5 = new System.Windows.Forms.Button();
			addressTextBox = new System.Windows.Forms.RichTextBox();
			SpecialtyText = new System.Windows.Forms.RichTextBox();
			button8 = new System.Windows.Forms.Button();
			button7 = new System.Windows.Forms.Button();
			groupBox4 = new System.Windows.Forms.GroupBox();
			WorkDatatEXT = new System.Windows.Forms.TextBox();
			label11 = new System.Windows.Forms.Label();
			richTextBox1 = new System.Windows.Forms.RichTextBox();
			label10 = new System.Windows.Forms.Label();
			label9 = new System.Windows.Forms.Label();
			label8 = new System.Windows.Forms.Label();
			richTextBox2 = new System.Windows.Forms.RichTextBox();
			button9 = new System.Windows.Forms.Button();
			button10 = new System.Windows.Forms.Button();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label7 = new System.Windows.Forms.Label();
			groupBox5.SuspendLayout();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
			groupBox4.SuspendLayout();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "emailLabel");
			label.Name = "emailLabel";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "mobLabel");
			label2.Name = "mobLabel";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "telLabel");
			label3.Name = "telLabel";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "nationalityLabel");
			label4.Name = "nationalityLabel";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "addressLabel");
			label5.Name = "addressLabel";
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "nameLabel");
			label6.Name = "nameLabel";
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "titelLabel");
			label7.Name = "titelLabel";
			cardNumLabel.AccessibleDescription = null;
			cardNumLabel.AccessibleName = null;
			resources.ApplyResources(cardNumLabel, "cardNumLabel");
			cardNumLabel.Name = "cardNumLabel";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			this.label6.AccessibleDescription = null;
			this.label6.AccessibleName = null;
			resources.ApplyResources(this.label6, "label6");
			this.label6.Name = "label6";
			groupBox5.AccessibleDescription = null;
			groupBox5.AccessibleName = null;
			resources.ApplyResources(groupBox5, "groupBox5");
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.BackgroundImage = null;
			groupBox5.Controls.Add(DeletBtn);
			groupBox5.Controls.Add(Searchbtn);
			groupBox5.Controls.Add(saveBtn);
			groupBox5.Controls.Add(EditBtn);
			groupBox5.Font = null;
			groupBox5.Name = "groupBox5";
			groupBox5.TabStop = false;
			DeletBtn.AccessibleDescription = null;
			DeletBtn.AccessibleName = null;
			resources.ApplyResources(DeletBtn, "DeletBtn");
			DeletBtn.BackColor = System.Drawing.Color.Gainsboro;
			DeletBtn.BackgroundImage = null;
			DeletBtn.Name = "DeletBtn";
			DeletBtn.UseVisualStyleBackColor = false;
			DeletBtn.Click += new System.EventHandler(DeletBtn_Click);
			Searchbtn.AccessibleDescription = null;
			Searchbtn.AccessibleName = null;
			resources.ApplyResources(Searchbtn, "Searchbtn");
			Searchbtn.BackColor = System.Drawing.Color.Gainsboro;
			Searchbtn.BackgroundImage = null;
			Searchbtn.Name = "Searchbtn";
			Searchbtn.UseVisualStyleBackColor = false;
			Searchbtn.Click += new System.EventHandler(Searchbtn_Click);
			saveBtn.AccessibleDescription = null;
			saveBtn.AccessibleName = null;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			saveBtn.BackgroundImage = null;
			saveBtn.Name = "saveBtn";
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			EditBtn.AccessibleDescription = null;
			EditBtn.AccessibleName = null;
			resources.ApplyResources(EditBtn, "EditBtn");
			EditBtn.BackColor = System.Drawing.Color.Gainsboro;
			EditBtn.BackgroundImage = null;
			EditBtn.Name = "EditBtn";
			EditBtn.UseVisualStyleBackColor = false;
			EditBtn.Click += new System.EventHandler(EditBtn_Click);
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(dataGridView1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridViewCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(ID, Designation, Names, Address, Tel, Mob, Email, Salary, Percentage, Specialty, Signature, AppointCount, BacksCount, EnName, EnSpecialty);
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
			dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseClick);
			resources.ApplyResources(ID, "ID");
			ID.Name = "ID";
			ID.ReadOnly = true;
			resources.ApplyResources(Designation, "Designation");
			Designation.Name = "Designation";
			Designation.ReadOnly = true;
			resources.ApplyResources(Names, "Names");
			Names.Name = "Names";
			Names.ReadOnly = true;
			resources.ApplyResources(Address, "Address");
			Address.Name = "Address";
			Address.ReadOnly = true;
			resources.ApplyResources(Tel, "Tel");
			Tel.Name = "Tel";
			Tel.ReadOnly = true;
			resources.ApplyResources(Mob, "Mob");
			Mob.Name = "Mob";
			Mob.ReadOnly = true;
			resources.ApplyResources(Email, "Email");
			Email.Name = "Email";
			Email.ReadOnly = true;
			resources.ApplyResources(Salary, "Salary");
			Salary.Name = "Salary";
			Salary.ReadOnly = true;
			resources.ApplyResources(Percentage, "Percentage");
			Percentage.Name = "Percentage";
			Percentage.ReadOnly = true;
			resources.ApplyResources(Specialty, "Specialty");
			Specialty.Name = "Specialty";
			Specialty.ReadOnly = true;
			resources.ApplyResources(Signature, "Signature");
			Signature.Name = "Signature";
			Signature.ReadOnly = true;
			resources.ApplyResources(AppointCount, "AppointCount");
			AppointCount.Name = "AppointCount";
			AppointCount.ReadOnly = true;
			resources.ApplyResources(BacksCount, "BacksCount");
			BacksCount.Name = "BacksCount";
			BacksCount.ReadOnly = true;
			resources.ApplyResources(EnName, "EnName");
			EnName.Name = "EnName";
			EnName.ReadOnly = true;
			resources.ApplyResources(EnSpecialty, "EnSpecialty");
			EnSpecialty.Name = "EnSpecialty";
			EnSpecialty.ReadOnly = true;
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(this.label7);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			this.label7.AccessibleDescription = null;
			this.label7.AccessibleName = null;
			resources.ApplyResources(this.label7, "label7");
			this.label7.Name = "label7";
			emailTextBox.AccessibleDescription = null;
			emailTextBox.AccessibleName = null;
			resources.ApplyResources(emailTextBox, "emailTextBox");
			emailTextBox.BackgroundImage = null;
			emailTextBox.Name = "emailTextBox";
			emailTextBox.Validating += new System.ComponentModel.CancelEventHandler(emailTextBox_Validating);
			mobTextBox.AccessibleDescription = null;
			mobTextBox.AccessibleName = null;
			resources.ApplyResources(mobTextBox, "mobTextBox");
			mobTextBox.BackgroundImage = null;
			mobTextBox.Name = "mobTextBox";
			mobTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(mobTextBox_KeyPress);
			telTextBox.AccessibleDescription = null;
			telTextBox.AccessibleName = null;
			resources.ApplyResources(telTextBox, "telTextBox");
			telTextBox.BackgroundImage = null;
			telTextBox.Name = "telTextBox";
			telTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(telTextBox_KeyPress);
			SalaryTextBox.AccessibleDescription = null;
			SalaryTextBox.AccessibleName = null;
			resources.ApplyResources(SalaryTextBox, "SalaryTextBox");
			SalaryTextBox.BackgroundImage = null;
			SalaryTextBox.Name = "SalaryTextBox";
			SalaryTextBox.Leave += new System.EventHandler(SalaryTextBox_Leave);
			SalaryTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(SalaryTextBox_KeyPress);
			typeComboBox.AccessibleDescription = null;
			typeComboBox.AccessibleName = null;
			resources.ApplyResources(typeComboBox, "typeComboBox");
			typeComboBox.BackgroundImage = null;
			typeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			typeComboBox.FormattingEnabled = true;
			typeComboBox.Items.AddRange(new object[5]
			{
				resources.GetString("typeComboBox.Items"),
				resources.GetString("typeComboBox.Items1"),
				resources.GetString("typeComboBox.Items2"),
				resources.GetString("typeComboBox.Items3"),
				resources.GetString("typeComboBox.Items4")
			});
			typeComboBox.Name = "typeComboBox";
			typeComboBox.SelectedIndexChanged += new System.EventHandler(typeComboBox_SelectedIndexChanged);
			percentTextBox.AccessibleDescription = null;
			percentTextBox.AccessibleName = null;
			resources.ApplyResources(percentTextBox, "percentTextBox");
			percentTextBox.BackgroundImage = null;
			percentTextBox.Name = "percentTextBox";
			percentTextBox.Leave += new System.EventHandler(percentTextBox_Leave);
			percentTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(percentTextBox_KeyPress);
			this.label2.AccessibleDescription = null;
			this.label2.AccessibleName = null;
			resources.ApplyResources(this.label2, "label2");
			this.label2.Name = "label2";
			SignatureText.AccessibleDescription = null;
			SignatureText.AccessibleName = null;
			resources.ApplyResources(SignatureText, "SignatureText");
			SignatureText.BackgroundImage = null;
			SignatureText.Name = "SignatureText";
			this.label4.AccessibleDescription = null;
			this.label4.AccessibleName = null;
			resources.ApplyResources(this.label4, "label4");
			this.label4.Name = "label4";
			this.label3.AccessibleDescription = null;
			this.label3.AccessibleName = null;
			resources.ApplyResources(this.label3, "label3");
			this.label3.Name = "label3";
			this.label5.AccessibleDescription = null;
			this.label5.AccessibleName = null;
			resources.ApplyResources(this.label5, "label5");
			this.label5.Name = "label5";
			numericUpDown1.AccessibleDescription = null;
			numericUpDown1.AccessibleName = null;
			resources.ApplyResources(numericUpDown1, "numericUpDown1");
			numericUpDown1.Font = null;
			numericUpDown1.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			numericUpDown1.Name = "numericUpDown1";
			numericUpDown2.AccessibleDescription = null;
			numericUpDown2.AccessibleName = null;
			resources.ApplyResources(numericUpDown2, "numericUpDown2");
			numericUpDown2.Font = null;
			numericUpDown2.Maximum = new decimal(new int[4] { 999999, 0, 0, 0 });
			numericUpDown2.Name = "numericUpDown2";
			nameTextBox.AccessibleDescription = null;
			nameTextBox.AccessibleName = null;
			resources.ApplyResources(nameTextBox, "nameTextBox");
			nameTextBox.BackgroundImage = null;
			nameTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
			nameTextBox.Font = null;
			nameTextBox.Name = "nameTextBox";
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.ForeColor = System.Drawing.Color.Blue;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackgroundImage = null;
			button3.ForeColor = System.Drawing.Color.Red;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			button4.AccessibleDescription = null;
			button4.AccessibleName = null;
			resources.ApplyResources(button4, "button4");
			button4.BackgroundImage = null;
			button4.ForeColor = System.Drawing.Color.Blue;
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = true;
			button4.Click += new System.EventHandler(button4_Click);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.ForeColor = System.Drawing.Color.Red;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			button6.AccessibleDescription = null;
			button6.AccessibleName = null;
			resources.ApplyResources(button6, "button6");
			button6.BackgroundImage = null;
			button6.ForeColor = System.Drawing.Color.Blue;
			button6.Name = "button6";
			button6.UseVisualStyleBackColor = true;
			button6.Click += new System.EventHandler(button6_Click);
			button5.AccessibleDescription = null;
			button5.AccessibleName = null;
			resources.ApplyResources(button5, "button5");
			button5.BackgroundImage = null;
			button5.ForeColor = System.Drawing.Color.Red;
			button5.Name = "button5";
			button5.UseVisualStyleBackColor = true;
			button5.Click += new System.EventHandler(button5_Click);
			addressTextBox.AccessibleDescription = null;
			addressTextBox.AccessibleName = null;
			resources.ApplyResources(addressTextBox, "addressTextBox");
			addressTextBox.BackgroundImage = null;
			addressTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
			addressTextBox.Font = null;
			addressTextBox.Name = "addressTextBox";
			SpecialtyText.AccessibleDescription = null;
			SpecialtyText.AccessibleName = null;
			resources.ApplyResources(SpecialtyText, "SpecialtyText");
			SpecialtyText.BackgroundImage = null;
			SpecialtyText.BorderStyle = System.Windows.Forms.BorderStyle.None;
			SpecialtyText.Font = null;
			SpecialtyText.Name = "SpecialtyText";
			SpecialtyText.KeyDown += new System.Windows.Forms.KeyEventHandler(SpecialtyText_KeyDown);
			SpecialtyText.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(SpecialtyText_PreviewKeyDown);
			button8.AccessibleDescription = null;
			button8.AccessibleName = null;
			resources.ApplyResources(button8, "button8");
			button8.BackgroundImage = null;
			button8.ForeColor = System.Drawing.Color.Blue;
			button8.Name = "button8";
			button8.UseVisualStyleBackColor = true;
			button8.Click += new System.EventHandler(button8_Click);
			button7.AccessibleDescription = null;
			button7.AccessibleName = null;
			resources.ApplyResources(button7, "button7");
			button7.BackgroundImage = null;
			button7.ForeColor = System.Drawing.Color.Red;
			button7.Name = "button7";
			button7.UseVisualStyleBackColor = true;
			button7.Click += new System.EventHandler(button7_Click);
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(WorkDatatEXT);
			groupBox4.Controls.Add(label11);
			groupBox4.Controls.Add(richTextBox1);
			groupBox4.Controls.Add(label10);
			groupBox4.Controls.Add(label9);
			groupBox4.Controls.Add(label8);
			groupBox4.Controls.Add(richTextBox2);
			groupBox4.Controls.Add(button9);
			groupBox4.Controls.Add(button10);
			groupBox4.Controls.Add(button7);
			groupBox4.Controls.Add(button8);
			groupBox4.Controls.Add(this.label6);
			groupBox4.Controls.Add(SpecialtyText);
			groupBox4.Controls.Add(addressTextBox);
			groupBox4.Controls.Add(button5);
			groupBox4.Controls.Add(button6);
			groupBox4.Controls.Add(button1);
			groupBox4.Controls.Add(button4);
			groupBox4.Controls.Add(button3);
			groupBox4.Controls.Add(button2);
			groupBox4.Controls.Add(nameTextBox);
			groupBox4.Controls.Add(numericUpDown2);
			groupBox4.Controls.Add(numericUpDown1);
			groupBox4.Controls.Add(this.label5);
			groupBox4.Controls.Add(this.label3);
			groupBox4.Controls.Add(this.label4);
			groupBox4.Controls.Add(SignatureText);
			groupBox4.Controls.Add(this.label2);
			groupBox4.Controls.Add(label1);
			groupBox4.Controls.Add(label7);
			groupBox4.Controls.Add(percentTextBox);
			groupBox4.Controls.Add(cardNumLabel);
			groupBox4.Controls.Add(typeComboBox);
			groupBox4.Controls.Add(label6);
			groupBox4.Controls.Add(label5);
			groupBox4.Controls.Add(SalaryTextBox);
			groupBox4.Controls.Add(label4);
			groupBox4.Controls.Add(label3);
			groupBox4.Controls.Add(telTextBox);
			groupBox4.Controls.Add(label2);
			groupBox4.Controls.Add(mobTextBox);
			groupBox4.Controls.Add(emailTextBox);
			groupBox4.Controls.Add(label);
			groupBox4.ForeColor = System.Drawing.Color.Black;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			WorkDatatEXT.AccessibleDescription = null;
			WorkDatatEXT.AccessibleName = null;
			resources.ApplyResources(WorkDatatEXT, "WorkDatatEXT");
			WorkDatatEXT.BackgroundImage = null;
			WorkDatatEXT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			WorkDatatEXT.Font = null;
			WorkDatatEXT.Name = "WorkDatatEXT";
			label11.AccessibleDescription = null;
			label11.AccessibleName = null;
			resources.ApplyResources(label11, "label11");
			label11.BackColor = System.Drawing.Color.Transparent;
			label11.Name = "label11";
			richTextBox1.AccessibleDescription = null;
			richTextBox1.AccessibleName = null;
			resources.ApplyResources(richTextBox1, "richTextBox1");
			richTextBox1.BackgroundImage = null;
			richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			richTextBox1.Font = null;
			richTextBox1.Name = "richTextBox1";
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "label10");
			label10.Name = "label10";
			label9.AccessibleDescription = null;
			label9.AccessibleName = null;
			resources.ApplyResources(label9, "label9");
			label9.Name = "label9";
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "label8");
			label8.Name = "label8";
			richTextBox2.AccessibleDescription = null;
			richTextBox2.AccessibleName = null;
			resources.ApplyResources(richTextBox2, "richTextBox2");
			richTextBox2.BackgroundImage = null;
			richTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			richTextBox2.Font = null;
			richTextBox2.Name = "richTextBox2";
			button9.AccessibleDescription = null;
			button9.AccessibleName = null;
			resources.ApplyResources(button9, "button9");
			button9.BackgroundImage = null;
			button9.ForeColor = System.Drawing.Color.Red;
			button9.Name = "button9";
			button9.UseVisualStyleBackColor = true;
			button9.Click += new System.EventHandler(button9_Click);
			button10.AccessibleDescription = null;
			button10.AccessibleName = null;
			resources.ApplyResources(button10, "button10");
			button10.BackgroundImage = null;
			button10.ForeColor = System.Drawing.Color.Blue;
			button10.Name = "button10";
			button10.UseVisualStyleBackColor = true;
			button10.Click += new System.EventHandler(button10_Click);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox5);
			base.Controls.Add(groupBox4);
			Font = null;
			base.Name = "EmpData";
			base.Load += new System.EventHandler(EmpData_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(EmpData_KeyDown);
			groupBox5.ResumeLayout(false);
			groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			ResumeLayout(false);
		}
	}
}
