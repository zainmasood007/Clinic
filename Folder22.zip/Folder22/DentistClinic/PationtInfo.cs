using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using DentistClinic.Properties;
using FloatTextBox;

namespace DentistClinic
{
	public class PationtInfo : BaseForm
	{
		private int PationtId;

		private ClassDataBase dc;

		private GUI gui = new GUI();

		private dataClass codes = new dataClass(".\\sqlExpress");

		private byte[] Logo;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private IContainer components = null;

		private ComboBox titelComboBox;

		private TextBox nameTextBox;

		private TextBox telTextBox;

		private TextBox mobTextBox;

		private TextBox emailTextBox;

		private DateTimePicker birthDateDateTimePicker;

		private ComboBox sexComboBox;

		private TextBox cardNumTextBox;

		private DateTimePicker lastVistDateDateTimePicker;

		private CheckBox allergiesCheckBox;

		private CheckBox cardiacDiseaseCheckBox;

		private CheckBox kidneyDeseaseCheckBox;

		private CheckBox diabetesCheckBox;

		private CheckBox rheumaticFeverCheckBox;

		private CheckBox asthmaCheckBox;

		private CheckBox bloodDyscrasiasCheckBox;

		private TextBox historyOtherTextBox;

		private CheckBox extractionCheckBox;

		private CheckBox drugSensitivityCheckBox;

		private CheckBox pulpTherapyCheckBox;

		private CheckBox periodontalTherpyCheckBox;

		private CheckBox flourideTherapyCheckBox;

		private TextBox prviousHistoryOthersTextBox;

		private GroupBox groupBox2;

		private GroupBox groupBox3;

		private GroupBox groupBox4;

		private ComboBox statueComboBox;

		private ComboBox companycomboBox;

		private Button saveBtn;

		private Button EditBtn;

		private TextBox IDtextBox;

		private GroupBox groupBox5;

		private Button button1;

		private GroupBox groupBox6;

		private Label label2;

		private CheckBox lactatingcheckBox;

		private CheckBox HepatitisCcheckBox;

		private CheckBox PregnantcheckBox;

		private CheckBox HepatitisBcheckBox;

		private CheckBox OpretivecheckBox;

		private CheckBox BleachingcheckBox;

		private ComboBox DoctorcomboBox;

		private Button AddComment;

		private Panel CommentPanel;

		private CheckBox checkBox1;

		private Panel panel1;

		private Button button2;

		private Button button3;

		private Button button4;

		private Button button5;

		private FlowLayoutPanel flowLayoutPanel1;

		private Button button6;

		private GroupBox groupBox1;

		private CheckedListBox checkedListBox1;

		private GroupBox groupBox8;

		private CheckedListBox checkedListBox2;

		private Button button7;

		private Button button8;

		private PictureBox pictureBox1;

		private Button DentalLogoBtn;

		private GroupBox groupBox7;

		private TextBox txtBloodType;

		private TabControl LightSteelBlue;

		private TabPage tabPage1;

		private TabPage tabPage2;

		private TabPage tabPage3;

		private GroupBox groupBox9;

		private TextBox textBox1;

		private NumericUpDown numericUpDown2;

		private NumericUpDown numericUpDown1;

		private CheckBox checkBox2;

		private CheckBox checkBox5;

		private CheckBox checkBox4;

		private CheckBox checkBox3;

		private NumericUpDown numericUpDown3;

		private CheckBox checkBox8;

		private CheckBox checkBox6;

		private CheckBox checkBox7;

		private TextBox textBox4;

		private NumericUpDown numericUpDown4;

		private ComboBox comboBox1;

		private NumericUpDown numericUpDown10;

		private NumericUpDown numericUpDown9;

		private NumericUpDown numericUpDown8;

		private NumericUpDown numericUpDown7;

		private NumericUpDown numericUpDown6;

		private NumericUpDown numericUpDown5;

		private CheckBox checkBox9;

		private NumericUpDown numericUpDown11;

		private DateTimePicker dateTimePicker1;

		private NumericUpDown numericUpDown12;

		private ComboBox comboBox2;

		private CheckBox checkBox10;

		private ComboBox comboBox4;

		private ComboBox comboBox3;

		private ComboBox comboBox5;

		private DateTimePicker dateTimePicker2;

		private GroupBox groupBox10;

		private SqlCommand sqlSelectCommand1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private Label label27;

		private Label label28;

		private NumericUpDown numericUpDown13;

		private ComboBox comboBox8;

		private ComboBox comboBox6;

		private ComboBox comboBox7;

		private ComboBox comboBox10;

		private ComboBox comboBox11;

		private ComboBox comboBox9;

		private Button button9;

		private DataGridView dataGridView1;

		private NumericUpDown numericUpDown14;

		private ComboBox comboBox12;

		private GroupBox groupBox11;

		private CheckedListBox checkedListBox3;

		private Button button10;

		private OpenFileDialog openFileDialog1;

		private TabPage tabPage4;

		private GroupBox groupBox12;

		private TextBox textBox3;

		private TextBox textBox2;

		private Label label47;

		private NumericUpDown numericUpDown18;

		private Label label44;

		private NumericUpDown numericUpDown17;

		private Label label40;

		private Label label43;

		private NumericUpDown numericUpDown15;

		private ComboBox comboBox16;

		private ComboBox comboBox17;

		private NumericUpDown numericUpDown16;

		private Label label41;

		private Label label42;

		private TextBox textBox5;

		private Label label36;

		private CheckBox checkBox11;

		private TextBox txtFileNo;

		private RadioButton radioButton2;

		private RadioButton radioButton1;

		private RadioButton radioButton3;

		private ComboBox PatientComboBox;

		private Panel panel2;

		private FloatText floatText1;

		private Label label49;

		private FloatText floatText2;

		private ComboBox cityTextBox;

		private ComboBox nationalityTextBox;

		private ComboBox addressTextBox;

		private Panel panel3;

		private ComboBox comboBox13;

		private RadioButton radioButton5;

		private RadioButton radioButton4;

		private DataGridViewTextBoxColumn No;

		private DataGridViewTextBoxColumn Period;

		private DataGridViewTextBoxColumn Way;

		private DataGridViewTextBoxColumn Place;

		private DataGridViewTextBoxColumn Result;

		private DataGridViewTextBoxColumn Baby;

		private DataGridViewTextBoxColumn Mother;

		private DataGridViewTextBoxColumn Notes;

		private TextBox nationalID;

		private CheckBox checkBox12;

		private Button button12;

		private Button button11;

		private TabPage tabPage9;

		private GroupBox groupBox35;

		private TextBox MedicalStatus;

		private Label label193;

		private Label label194;

		private NumericUpDown wieght;

		private TabPage tabPage5;

		private GroupBox groupBox13;

		private CheckedListBox checkedListBox4;

		private Button button13;

		private GroupBox groupBox14;

		private Label label55;

		private GroupBox groupBox15;

		private Button button14;

		private Button button15;

		private CheckBox checkBox13;

		private TextBox textBox6;

		private Panel panel4;

		private ComboBox comboBox14;

		private RadioButton radioButton6;

		private RadioButton radioButton7;

		private ComboBox comboBox15;

		private ComboBox comboBox18;

		private ComboBox comboBox19;

		private FloatText floatText3;

		private Panel panel5;

		private FloatText floatText4;

		private Label label61;

		private ComboBox comboBox20;

		private TextBox textBox7;

		private Button button16;

		private GroupBox groupBox16;

		private PictureBox pictureBox2;

		private RadioButton radioButton8;

		private RadioButton radioButton9;

		private RadioButton radioButton10;

		private TextBox textBox8;

		private CheckBox checkBox14;

		private TextBox textBox9;

		private ComboBox comboBox21;

		private Button button17;

		private ComboBox comboBox22;

		private ComboBox comboBox23;

		private DateTimePicker dateTimePicker3;

		private TextBox textBox10;

		private ComboBox comboBox24;

		private TextBox textBox11;

		private ComboBox comboBox25;

		private TextBox textBox12;

		private DateTimePicker dateTimePicker4;

		private TextBox textBox13;

		private TextBox textBox14;

		private Button button18;

		private Button button19;

		private GroupBox groupBox17;

		private CheckedListBox checkedListBox5;

		private GroupBox groupBox18;

		private CheckBox checkBox15;

		private CheckBox checkBox16;

		private CheckBox checkBox17;

		private CheckBox checkBox18;

		private TextBox textBox15;

		private CheckBox checkBox19;

		private CheckBox checkBox20;

		private CheckBox checkBox21;

		private CheckBox checkBox22;

		private CheckBox checkBox23;

		private CheckBox checkBox24;

		private CheckBox checkBox25;

		private GroupBox groupBox19;

		private CheckedListBox checkedListBox6;

		private GroupBox groupBox20;

		private CheckBox checkBox26;

		private CheckBox checkBox27;

		private TextBox textBox16;

		private CheckBox checkBox28;

		private CheckBox checkBox29;

		private CheckBox checkBox30;

		private CheckBox checkBox31;

		private CheckBox checkBox32;

		private TabPage tabPage6;

		private GroupBox groupBox21;

		private ComboBox comboBox26;

		private ComboBox comboBox27;

		private DateTimePicker dateTimePicker5;

		private ComboBox comboBox28;

		private ComboBox comboBox29;

		private ComboBox comboBox30;

		private CheckBox checkBox33;

		private DateTimePicker dateTimePicker6;

		private NumericUpDown numericUpDown19;

		private CheckBox checkBox34;

		private NumericUpDown numericUpDown20;

		private ComboBox comboBox31;

		private NumericUpDown numericUpDown21;

		private NumericUpDown numericUpDown22;

		private NumericUpDown numericUpDown23;

		private NumericUpDown numericUpDown24;

		private NumericUpDown numericUpDown25;

		private NumericUpDown numericUpDown26;

		private NumericUpDown numericUpDown27;

		private NumericUpDown numericUpDown28;

		private CheckBox checkBox35;

		private CheckBox checkBox36;

		private CheckBox checkBox37;

		private TextBox textBox17;

		private CheckBox checkBox38;

		private CheckBox checkBox39;

		private CheckBox checkBox40;

		private NumericUpDown numericUpDown29;

		private NumericUpDown numericUpDown30;

		private CheckBox checkBox41;

		private TextBox textBox18;

		private TabPage tabPage7;

		private GroupBox groupBox22;

		private NumericUpDown numericUpDown31;

		private Button button20;

		private ComboBox comboBox32;

		private ComboBox comboBox33;

		private ComboBox comboBox34;

		private ComboBox comboBox35;

		private ComboBox comboBox36;

		private ComboBox comboBox37;

		private NumericUpDown numericUpDown32;

		private Label label110;

		private Label label111;

		private DataGridView dataGridView2;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;

		private TabPage tabPage8;

		private GroupBox groupBox23;

		private TextBox textBox19;

		private Label label112;

		private TextBox textBox20;

		private TextBox textBox21;

		private Label label113;

		private NumericUpDown numericUpDown33;

		private Label label116;

		private NumericUpDown numericUpDown34;

		private Label label117;

		private Label label118;

		private NumericUpDown numericUpDown35;

		private ComboBox comboBox38;

		private ComboBox comboBox39;

		private NumericUpDown numericUpDown36;

		private Label label122;

		private Label label123;

		private TabPage tabPage10;

		private GroupBox groupBox24;

		private CheckedListBox checkedListBox7;

		private Button button21;

		private GroupBox groupBox25;

		private Label label124;

		private GroupBox groupBox26;

		private Button button22;

		private Button button23;

		private CheckBox checkBox42;

		private TextBox textBox22;

		private Panel panel6;

		private ComboBox comboBox40;

		private RadioButton radioButton11;

		private RadioButton radioButton12;

		private ComboBox comboBox41;

		private ComboBox comboBox42;

		private ComboBox comboBox43;

		private FloatText floatText5;

		private Panel panel7;

		private FloatText floatText6;

		private Label label130;

		private ComboBox comboBox44;

		private TextBox textBox23;

		private Button button24;

		private GroupBox groupBox27;

		private PictureBox pictureBox3;

		private RadioButton radioButton13;

		private RadioButton radioButton14;

		private RadioButton radioButton15;

		private TextBox textBox24;

		private CheckBox checkBox43;

		private TextBox textBox25;

		private ComboBox comboBox45;

		private Button button25;

		private ComboBox comboBox46;

		private ComboBox comboBox47;

		private DateTimePicker dateTimePicker7;

		private TextBox textBox26;

		private ComboBox comboBox48;

		private TextBox textBox27;

		private ComboBox comboBox49;

		private TextBox textBox28;

		private DateTimePicker dateTimePicker8;

		private TextBox textBox29;

		private TextBox textBox30;

		private Button button26;

		private Button button27;

		private GroupBox groupBox28;

		private CheckedListBox checkedListBox8;

		private GroupBox groupBox29;

		private CheckBox checkBox44;

		private CheckBox checkBox45;

		private CheckBox checkBox46;

		private CheckBox checkBox47;

		private TextBox textBox31;

		private CheckBox checkBox48;

		private CheckBox checkBox49;

		private CheckBox checkBox50;

		private CheckBox checkBox51;

		private CheckBox checkBox52;

		private CheckBox checkBox53;

		private CheckBox checkBox54;

		private GroupBox groupBox30;

		private CheckedListBox checkedListBox9;

		private GroupBox groupBox31;

		private CheckBox checkBox55;

		private CheckBox checkBox56;

		private TextBox textBox32;

		private CheckBox checkBox57;

		private CheckBox checkBox58;

		private CheckBox checkBox59;

		private CheckBox checkBox60;

		private CheckBox checkBox61;

		private TabPage tabPage11;

		private GroupBox groupBox32;

		private ComboBox comboBox50;

		private ComboBox comboBox51;

		private DateTimePicker dateTimePicker9;

		private ComboBox comboBox52;

		private ComboBox comboBox53;

		private ComboBox comboBox54;

		private CheckBox checkBox62;

		private DateTimePicker dateTimePicker10;

		private NumericUpDown numericUpDown37;

		private CheckBox checkBox63;

		private NumericUpDown numericUpDown38;

		private ComboBox comboBox55;

		private NumericUpDown numericUpDown39;

		private NumericUpDown numericUpDown40;

		private NumericUpDown numericUpDown41;

		private NumericUpDown numericUpDown42;

		private NumericUpDown numericUpDown43;

		private NumericUpDown numericUpDown44;

		private NumericUpDown numericUpDown45;

		private NumericUpDown numericUpDown46;

		private CheckBox checkBox64;

		private CheckBox checkBox65;

		private CheckBox checkBox66;

		private TextBox textBox33;

		private CheckBox checkBox67;

		private CheckBox checkBox68;

		private CheckBox checkBox69;

		private NumericUpDown numericUpDown47;

		private NumericUpDown numericUpDown48;

		private CheckBox checkBox70;

		private TextBox textBox34;

		private TabPage tabPage12;

		private GroupBox groupBox33;

		private NumericUpDown numericUpDown49;

		private Button button28;

		private ComboBox comboBox56;

		private ComboBox comboBox57;

		private ComboBox comboBox58;

		private ComboBox comboBox59;

		private ComboBox comboBox60;

		private ComboBox comboBox61;

		private NumericUpDown numericUpDown50;

		private Label label179;

		private Label label180;

		private DataGridView dataGridView3;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;

		private TabPage tabPage13;

		private GroupBox groupBox34;

		private TextBox textBox35;

		private Label label181;

		private TextBox textBox36;

		private TextBox textBox37;

		private Label label182;

		private NumericUpDown numericUpDown51;

		private Label label185;

		private NumericUpDown numericUpDown52;

		private Label label186;

		private Label label187;

		private NumericUpDown numericUpDown53;

		private ComboBox comboBox62;

		private ComboBox comboBox63;

		private NumericUpDown numericUpDown54;

		private Label label191;

		private Label label192;

		private TabPage tabPage14;

		private Label label203;

		private Label label204;

		private NumericUpDown FatsRate;

		private Label label199;

		private Label label202;

		private NumericUpDown MusclesRate;

		private Label label197;

		private Label label198;

		private NumericUpDown hieght;

		private Label label196;

		private TextBox Medicin;

		private Label label195;

		public PationtInfo(int Id)
		{
			try
			{
				InitializeComponent();
				dc = new ClassDataBase(".\\sqlExpress");
			}
			catch (Exception ex)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show(ex.Message, "Error");
				}
				else
				{
					MessageBox.Show(ex.Message, "حدث خطأ");
				}
			}
			PationtId = Id;
			LightSteelBlue.KeyDown += LightSteelBlue_KeyDown;
			LightSteelBlue.SelectedTab = tabPage1;
		}

		private byte[] GetImage(string path)
		{
			FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read);
			BinaryReader binaryReader = new BinaryReader(fileStream);
			byte[] result = binaryReader.ReadBytes(Convert.ToInt32(fileStream.Length));
			binaryReader.Close();
			fileStream.Close();
			return result;
		}

		private void telTextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			char keyChar = e.KeyChar;
			if (!char.IsDigit(keyChar) && keyChar != '\b')
			{
				e.Handled = true;
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Numbers Only");
				}
				else
				{
					MessageBox.Show("أرقام فقط");
				}
			}
		}

		private void mobTextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			char keyChar = e.KeyChar;
			if (!char.IsDigit(keyChar) && keyChar != '\b')
			{
				e.Handled = true;
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Numbers Only");
				}
				else
				{
					MessageBox.Show("أرقام فقط");
				}
			}
		}

		private void emailTextBox_Validating(object sender, CancelEventArgs e)
		{
			Regex regex = new Regex("^[a-zA-Z][\\w\\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z][a-zA-Z\\.]*[a-zA-Z]$");
			if (emailTextBox.Text.Length > 0 && !regex.IsMatch(emailTextBox.Text))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Valid E-Mail");
				}
				else
				{
					MessageBox.Show("من فضلك أدخل بريد الكتروني صحيح");
				}
				emailTextBox.Text = "";
			}
		}

		public void PatientNumber()
		{
			DataTable tableText = dc.GetTableText("select * from PatientData");
			if (tableText.Rows.Count == 0)
			{
				IDtextBox.Text = "1";
				return;
			}
			DataTable tableText2 = dc.GetTableText("select max(ID) from PatientData");
			IDtextBox.Text = Convert.ToString(Convert.ToInt32(tableText2.Rows[0][0]) + 1);
		}

		public void CompanyComb()
		{
			DataTable dataTable = new DataTable();
			dataTable = dc.GetTableText("select * from Company");
			gui.loadComboBox(companycomboBox, dataTable);
			companycomboBox.SelectedItem = companycomboBox.Items[0];
		}

		public void DisplayButtons()
		{
			try
			{
				DataTable tableText = dc.GetTableText("select ClinicType from DentalData ");
				if (Convert.ToBoolean(tableText.Rows[0][0].ToString()))
				{
					button5.Visible = true;
					button6.Visible = true;
				}
				else
				{
					button5.Visible = false;
					button6.Visible = false;
				}
			}
			catch
			{
			}
		}

		private void PationtInfo_Load(object sender, EventArgs e)
		{
			try
			{
				txtFileNo.ReadOnly = Convert.ToBoolean(codes.Search2("select AutoFileNo from Properties").Rows[0][0]);
			}
			catch
			{
			}
			try
			{
				groupBox3.Visible = false;
				groupBox2.Visible = false;
				DisplayButtons();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select distinct PAddress from PatientData");
				addressTextBox.DataSource = dataTable;
				addressTextBox.ValueMember = dataTable.Columns[0].ToString();
				addressTextBox.DisplayMember = dataTable.Columns[0].ToString();
				addressTextBox.SelectedIndex = -1;
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select * from City");
				cityTextBox.DataSource = dataTable;
				cityTextBox.ValueMember = dataTable.Columns[0].ToString();
				cityTextBox.DisplayMember = dataTable.Columns[1].ToString();
				cityTextBox.SelectedItem = cityTextBox.Items[0];
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select * from Nationality");
				nationalityTextBox.DataSource = dataTable;
				nationalityTextBox.ValueMember = dataTable.Columns[0].ToString();
				nationalityTextBox.DisplayMember = dataTable.Columns[1].ToString();
				nationalityTextBox.SelectedItem = nationalityTextBox.Items[0];
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = codes.Search2("select Complaint from MainComplaint");
				foreach (DataRow row in dataTable2.Rows)
				{
					checkedListBox1.Items.Add(row.ItemArray[0]);
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable3 = codes.Search2("select ServiceName from ServicePatient");
				foreach (DataRow row2 in dataTable3.Rows)
				{
					checkedListBox2.Items.Add(row2.ItemArray[0]);
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable4 = codes.Search2("select History from MedicalHistory");
				foreach (DataRow row3 in dataTable4.Rows)
				{
					checkedListBox3.Items.Add(row3.ItemArray[0]);
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable5 = codes.Search2("select * from prosetting");
				bool visible = Convert.ToBoolean(dataTable5.Rows[0][1].ToString());
				groupBox2.Visible = visible;
				groupBox3.Visible = visible;
			}
			catch
			{
			}
			try
			{
				DataTable dataTable6 = new DataTable();
				dataTable6 = dc.Select("SelectAllDoctor");
				gui.loadComboBox(DoctorcomboBox, dataTable6);
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select distinct DoctorId from PatientData where DoctorId !=''");
				comboBox13.DataSource = dataTable;
				comboBox13.ValueMember = dataTable.Columns[0].ToString();
				comboBox13.DisplayMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				if (PationtId == 0)
				{
					CommentPanel.Visible = false;
					groupBox8.Visible = false;
					panel1.Visible = false;
					saveBtn.Visible = true;
					EditBtn.Visible = false;
					PatientNumber();
					CompanyComb();
					EmptyText();
					companycomboBox.SelectedItem = companycomboBox.Items[0];
					comboBox12.SelectedIndex = 0;
					if (txtFileNo.ReadOnly)
					{
						txtFileNo.Text = codes.Search2("select isnull(max(FileNo)+ 1,1) from PatientData").Rows[0][0].ToString();
					}
					DateTime dateTime = Convert.ToDateTime(dateTimePicker1.Value);
					dateTimePicker2.Value = dateTime.AddMonths(9).AddDays(7.0);
					try
					{
						DataTable dataTable7 = codes.Search2("SELECT ID, PName from PatientData where Active = 'True'");
						PatientComboBox.DataSource = dataTable7;
						PatientComboBox.ValueMember = dataTable7.Columns[0].ToString();
						PatientComboBox.DisplayMember = dataTable7.Columns[1].ToString();
					}
					catch
					{
					}
				}
				else if (PationtId > 0)
				{
					try
					{
						CommentPanel.Visible = true;
						CompanyComb();
						groupBox8.Visible = true;
						button8.Visible = true;
						clear1();
						try
						{
							DataTable dataTable7 = codes.Search2("SELECT ID, PName from PatientData where Active = 'True' and ID != '" + PationtId + "'");
							PatientComboBox.DataSource = dataTable7;
							PatientComboBox.ValueMember = dataTable7.Columns[0].ToString();
							PatientComboBox.DisplayMember = dataTable7.Columns[1].ToString();
						}
						catch
						{
						}
						try
						{
							DataTable tableText = dc.GetTableText("SELECT SId FROM ServiceDetails where PatientID = '" + PationtId + "'");
							foreach (DataRow row4 in tableText.Rows)
							{
								int num = Convert.ToInt32(row4["SId"].ToString());
								checkedListBox2.SetItemChecked(num - 1, value: true);
							}
						}
						catch
						{
						}
						try
						{
							DataTable dataTable = dc.GetTableText("SELECT CId FROM ComplaintDetails where PatientID = '" + PationtId + "'");
							foreach (DataRow row5 in dataTable.Rows)
							{
								int num = Convert.ToInt32(row5["CId"].ToString());
								checkedListBox1.SetItemChecked(num - 1, value: true);
							}
						}
						catch
						{
						}
						try
						{
							DataTable dataTable = dc.GetTableText("SELECT MID FROM MedicalHistoryDetails where PatientID = '" + PationtId + "'");
							foreach (DataRow row6 in dataTable.Rows)
							{
								int num = Convert.ToInt32(row6["MID"].ToString());
								checkedListBox3.SetItemChecked(num - 1, value: true);
							}
						}
						catch
						{
						}
						try
						{
							txtFileNo.Text = codes.Search2("select FileNo from PatientData where ID = '" + PationtId + "'").Rows[0][0].ToString();
						}
						catch
						{
						}
						string[] fields = new string[1] { "ID" };
						DataTable dataTable5 = dc.Select("selectPatient", fields, PationtId);
						IDtextBox.Text = dataTable5.Rows[0]["ID"].ToString();
						titelComboBox.Text = dataTable5.Rows[0]["Titel"].ToString();
						nameTextBox.Text = dataTable5.Rows[0]["PName"].ToString();
						addressTextBox.Text = dataTable5.Rows[0]["PAddress"].ToString();
						telTextBox.Text = dataTable5.Rows[0]["Tel"].ToString();
						mobTextBox.Text = dataTable5.Rows[0]["Mob"].ToString();
						emailTextBox.Text = dataTable5.Rows[0]["Email"].ToString();
						birthDateDateTimePicker.Value = Convert.ToDateTime(dataTable5.Rows[0]["BirthDate"].ToString());
						sexComboBox.Text = dataTable5.Rows[0]["Sex"].ToString();
						statueComboBox.Text = dataTable5.Rows[0]["Statue"].ToString();
						companycomboBox.Text = dataTable5.Rows[0]["Name"].ToString();
						cardNumTextBox.Text = dataTable5.Rows[0]["cardNum"].ToString();
						nationalID.Text = dataTable5.Rows[0]["nationalID"].ToString();
						if (dataTable5.Rows[0]["Dariba"] == null || dataTable5.Rows[0]["Dariba"].ToString() == "")
						{
							checkBox12.Checked = false;
						}
						else
						{
							checkBox12.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Dariba"].ToString());
						}
						try
						{
							lastVistDateDateTimePicker.Value = Convert.ToDateTime(dataTable5.Rows[0]["LastVistDate"].ToString());
						}
						catch
						{
						}
						txtBloodType.Text = dataTable5.Rows[0]["BloodType"].ToString();
						try
						{
							SqlBytes sqlBytes = new SqlBytes((byte[])dataTable5.Rows[0]["Photo"]);
							Logo = (byte[])dataTable5.Rows[0]["Photo"];
							pictureBox1.BackgroundImage = Image.FromStream(sqlBytes.Stream);
						}
						catch
						{
						}
						try
						{
							allergiesCheckBox.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Allergies"].ToString());
							cardiacDiseaseCheckBox.Checked = Convert.ToBoolean(dataTable5.Rows[0]["CardiacDisease"].ToString());
							kidneyDeseaseCheckBox.Checked = Convert.ToBoolean(dataTable5.Rows[0]["KidneyDesease"].ToString());
							diabetesCheckBox.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Diabetes"].ToString());
							rheumaticFeverCheckBox.Checked = Convert.ToBoolean(dataTable5.Rows[0]["RheumaticFever"].ToString());
							asthmaCheckBox.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Asthma"].ToString());
							bloodDyscrasiasCheckBox.Checked = Convert.ToBoolean(dataTable5.Rows[0]["BloodDyscrasias"].ToString());
							historyOtherTextBox.Text = dataTable5.Rows[0]["HistoryOther"].ToString();
							extractionCheckBox.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Extraction"].ToString());
							drugSensitivityCheckBox.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Implant"].ToString());
							pulpTherapyCheckBox.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Endodontics"].ToString());
							periodontalTherpyCheckBox.Checked = Convert.ToBoolean(dataTable5.Rows[0]["PeriodontalTherpy"].ToString());
							flourideTherapyCheckBox.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Fixed"].ToString());
							prviousHistoryOthersTextBox.Text = dataTable5.Rows[0]["PrviousHistoryOthers"].ToString();
						}
						catch
						{
						}
						try
						{
						}
						catch
						{
						}
						checkBox11.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Active"].ToString());
						try
						{
							checkBox1.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Accept"].ToString());
						}
						catch
						{
							checkBox1.Checked = false;
						}
						DoctorcomboBox.Text = dataTable5.Rows[0]["DoctoreName"].ToString();
						txtFileNo.Text = dataTable5.Rows[0]["FileNo"].ToString();
						try
						{
							radioButton1.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Patient"].ToString());
							radioButton2.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Facebook"].ToString());
							radioButton3.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Adv"].ToString());
							radioButton4.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Without"].ToString());
							radioButton5.Checked = Convert.ToBoolean(dataTable5.Rows[0]["Doctor"].ToString());
							if (radioButton5.Checked)
							{
								comboBox13.Text = dataTable5.Rows[0]["DoctorId"].ToString();
							}
							if (radioButton1.Checked)
							{
								PatientComboBox.Text = dataTable5.Rows[0]["FormerPatient"].ToString();
								floatText1.Text = Convert.ToDouble(dataTable5.Rows[0]["Discount"].ToString()).ToString();
							}
							DataTable dataTable8 = codes.Search2("select * from Appointments where PatuentID = '" + PationtId + "'");
							if (dataTable8.Rows.Count > 0)
							{
								radioButton1.Enabled = false;
								radioButton2.Enabled = false;
								radioButton3.Enabled = false;
								radioButton4.Enabled = false;
								radioButton5.Enabled = false;
							}
							else
							{
								radioButton1.Enabled = true;
								radioButton2.Enabled = true;
								radioButton3.Enabled = true;
								radioButton4.Enabled = true;
								radioButton5.Enabled = true;
							}
						}
						catch
						{
						}
						saveBtn.Visible = false;
						EditBtn.Visible = true;
						if (Convert.ToBoolean(codes.Search2("select Taqweem from PatientData where ID='" + PationtId + "'").Rows[0][0].ToString()))
						{
							button5.Visible = false;
						}
						else
						{
							button6.Visible = false;
						}
					}
					catch
					{
					}
					if (Convert.ToBoolean(dc.GetTableText("select Physicaltherapy from DentalData").Rows[0][0]))
					{
						DataTable dataTable9 = codes.Search2("select * from PhysicaltherapyPatientData where Patientid='" + PationtId + "'");
						if (dataTable9.Rows.Count > 0)
						{
							MedicalStatus.Text = dataTable9.Rows[0][1].ToString();
							Medicin.Text = dataTable9.Rows[0][2].ToString();
							wieght.Value = Convert.ToDecimal(dataTable9.Rows[0][3].ToString());
							hieght.Value = Convert.ToDecimal(dataTable9.Rows[0][4].ToString());
							MusclesRate.Value = Convert.ToDecimal(dataTable9.Rows[0][5].ToString());
							FatsRate.Value = Convert.ToDecimal(dataTable9.Rows[0][6].ToString());
						}
					}
				}
			}
			catch
			{
			}
			try
			{
			}
			catch
			{
			}
			try
			{
				DataTable dataTable10 = codes.Search2("select FemaleClinic,NaturalClinic from DentalData");
				bool visible = Convert.ToBoolean(dataTable10.Rows[0][0].ToString());
				bool flag = Convert.ToBoolean(dataTable10.Rows[0][1].ToString());
				if (visible)
				{
					LightSteelBlue.TabPages.Remove(tabPage4);
					LightSteelBlue.TabPages.Remove(tabPage9);
					comboBox1.SelectedIndex = 0;
					DataTable dataSource = codes.Search2("select distinct MeansContraceptionType from MarriageData");
					comboBox2.DataSource = dataSource;
					comboBox2.DisplayMember = "MeansContraceptionType";
					comboBox2.ValueMember = "MeansContraceptionType";
					DataTable dataSource2 = codes.Search2("select distinct Complaint from MarriageData");
					comboBox3.DataSource = dataSource2;
					comboBox3.DisplayMember = "Complaint";
					comboBox3.ValueMember = "Complaint";
					DataTable dataSource3 = codes.Search2("select distinct OtherInfo from MarriageData");
					comboBox4.DataSource = dataSource3;
					comboBox4.DisplayMember = "OtherInfo";
					comboBox4.ValueMember = "OtherInfo";
					DataTable dataSource4 = codes.Search2("select distinct BirthSurgeryType from MarriageData");
					comboBox5.DataSource = dataSource4;
					comboBox5.DisplayMember = "BirthSurgeryType";
					comboBox5.ValueMember = "BirthSurgeryType";
					DataTable dataSource5 = codes.Search2("select distinct BirthWay from Births");
					comboBox7.DataSource = dataSource5;
					comboBox7.DisplayMember = "BirthWay";
					comboBox7.ValueMember = "BirthWay";
					DataTable dataSource6 = codes.Search2("select distinct BirthPlace from Births");
					comboBox6.DataSource = dataSource6;
					comboBox6.DisplayMember = "BirthPlace";
					comboBox6.ValueMember = "BirthPlace";
					DataTable dataSource7 = codes.Search2("select distinct BirthResult from Births");
					comboBox8.DataSource = dataSource7;
					comboBox8.DisplayMember = "BirthResult";
					comboBox8.ValueMember = "BirthResult";
					DataTable dataSource8 = codes.Search2("select distinct BabyComplications from Births");
					comboBox9.DataSource = dataSource8;
					comboBox9.DisplayMember = "BabyComplications";
					comboBox9.ValueMember = "BabyComplications";
					DataTable dataSource9 = codes.Search2("select distinct MotherComplications from Births");
					comboBox11.DataSource = dataSource9;
					comboBox11.DisplayMember = "MotherComplications";
					comboBox11.ValueMember = "MotherComplications";
					DataTable dataSource10 = codes.Search2("select distinct Notes from Births");
					comboBox10.DataSource = dataSource10;
					comboBox10.DisplayMember = "Notes";
					comboBox10.ValueMember = "Notes";
					if (PationtId > 0)
					{
						DataTable dataTable11 = codes.Search2("select * from MarriageData where PatientID = '" + PationtId + "'");
						textBox1.Text = dataTable11.Rows[0][2].ToString();
						numericUpDown9.Value = Convert.ToDecimal(dataTable11.Rows[0][3].ToString());
						numericUpDown10.Value = Convert.ToDecimal(dataTable11.Rows[0][4].ToString());
						checkBox2.Checked = Convert.ToBoolean(dataTable11.Rows[0][5].ToString());
						numericUpDown1.Value = Convert.ToDecimal(dataTable11.Rows[0][6].ToString());
						numericUpDown2.Value = Convert.ToDecimal(dataTable11.Rows[0][7].ToString());
						checkBox3.Checked = Convert.ToBoolean(dataTable11.Rows[0][8].ToString());
						checkBox4.Checked = Convert.ToBoolean(dataTable11.Rows[0][9].ToString());
						checkBox5.Checked = Convert.ToBoolean(dataTable11.Rows[0][10].ToString());
						textBox4.Text = dataTable11.Rows[0][11].ToString();
						checkBox7.Checked = Convert.ToBoolean(dataTable11.Rows[0][12].ToString());
						checkBox6.Checked = Convert.ToBoolean(dataTable11.Rows[0][13].ToString());
						checkBox8.Checked = Convert.ToBoolean(dataTable11.Rows[0][14].ToString());
						numericUpDown3.Value = Convert.ToDecimal(dataTable11.Rows[0][15].ToString());
						numericUpDown4.Value = Convert.ToDecimal(dataTable11.Rows[0][16].ToString());
						numericUpDown5.Value = Convert.ToDecimal(dataTable11.Rows[0][17].ToString());
						numericUpDown6.Value = Convert.ToDecimal(dataTable11.Rows[0][18].ToString());
						numericUpDown7.Value = Convert.ToDecimal(dataTable11.Rows[0][19].ToString());
						numericUpDown8.Value = Convert.ToDecimal(dataTable11.Rows[0][20].ToString());
						comboBox1.Text = dataTable11.Rows[0][21].ToString();
						numericUpDown11.Value = Convert.ToDecimal(dataTable11.Rows[0][22].ToString());
						checkBox9.Checked = Convert.ToBoolean(dataTable11.Rows[0][23].ToString());
						numericUpDown12.Value = Convert.ToDecimal(dataTable11.Rows[0][24].ToString());
						dateTimePicker1.Value = Convert.ToDateTime(dataTable11.Rows[0][25].ToString());
						checkBox10.Checked = Convert.ToBoolean(dataTable11.Rows[0][26].ToString());
						comboBox2.Text = dataTable11.Rows[0][27].ToString();
						comboBox3.Text = dataTable11.Rows[0][28].ToString();
						comboBox4.Text = dataTable11.Rows[0][29].ToString();
						dateTimePicker2.Value = Convert.ToDateTime(dataTable11.Rows[0][30].ToString());
						comboBox5.Text = dataTable11.Rows[0][31].ToString();
						comboBox12.Text = dataTable11.Rows[0]["MPeriod"].ToString();
						DataTable dataTable12 = codes.Search2("select * from Births where PatientID = '" + PationtId + "'");
						for (int num = 0; num < dataTable12.Rows.Count; num++)
						{
							dataGridView1.Rows.Add(dataTable12.Rows[num][2].ToString(), dataTable12.Rows[num][3].ToString(), dataTable12.Rows[num][4].ToString(), dataTable12.Rows[num][5].ToString(), dataTable12.Rows[num][6].ToString(), dataTable12.Rows[num][7].ToString(), dataTable12.Rows[num][8].ToString(), dataTable12.Rows[num][9].ToString());
						}
					}
					else
					{
						clear1();
					}
				}
				else if (flag)
				{
					LightSteelBlue.TabPages.Remove(tabPage2);
					LightSteelBlue.TabPages.Remove(tabPage3);
					LightSteelBlue.TabPages.Remove(tabPage9);
					if (PationtId == 0)
					{
						clear1();
					}
					else
					{
						DataTable dataTable13 = codes.Search2("select * from ChildData where PatientID = '" + PationtId + "'");
						numericUpDown15.Value = Convert.ToInt32(dataTable13.Rows[0][2].ToString());
						numericUpDown16.Value = Convert.ToDecimal(dataTable13.Rows[0][3].ToString());
						comboBox17.Text = dataTable13.Rows[0][4].ToString();
						numericUpDown17.Value = Convert.ToInt32(dataTable13.Rows[0][5].ToString());
						comboBox16.Text = dataTable13.Rows[0][6].ToString();
						numericUpDown18.Value = Convert.ToDecimal(dataTable13.Rows[0][7].ToString());
						textBox3.Text = dataTable13.Rows[0][8].ToString();
						textBox2.Text = dataTable13.Rows[0][9].ToString();
						textBox5.Text = dataTable13.Rows[0][10].ToString();
					}
				}
				else
				{
					LightSteelBlue.TabPages.Remove(tabPage2);
					LightSteelBlue.TabPages.Remove(tabPage3);
					LightSteelBlue.TabPages.Remove(tabPage4);
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable14 = codes.Search2("select * from users where userName = '" + Main.usernames + "'");
				button1.Visible = Convert.ToBoolean(dataTable14.Rows[0]["Company"].ToString());
			}
			catch
			{
			}
			try
			{
				if (Convert.ToBoolean(dc.GetTableText("select Physicaltherapy from DentalData").Rows[0][0]))
				{
					LightSteelBlue.TabPages.Remove(tabPage2);
					LightSteelBlue.TabPages.Remove(tabPage3);
					LightSteelBlue.TabPages.Remove(tabPage4);
				}
				else
				{
					LightSteelBlue.TabPages.Remove(tabPage9);
				}
			}
			catch
			{
			}
		}

		public void EmptyText()
		{
			titelComboBox.SelectedIndex = 0;
			statueComboBox.SelectedIndex = 0;
			nameTextBox.Text = "";
			addressTextBox.Text = "";
			cityTextBox.Text = "";
			telTextBox.Text = "";
			mobTextBox.Text = "";
			emailTextBox.Text = "";
			sexComboBox.SelectedIndex = 0;
			nationalityTextBox.Text = "";
			cardNumTextBox.Text = "";
			checkedListBox1.ClearSelected();
			checkedListBox2.ClearSelected();
			allergiesCheckBox.Checked = false;
			cardiacDiseaseCheckBox.Checked = false;
			kidneyDeseaseCheckBox.Checked = false;
			diabetesCheckBox.Checked = false;
			asthmaCheckBox.Checked = false;
			bloodDyscrasiasCheckBox.Checked = false;
			drugSensitivityCheckBox.Checked = false;
			rheumaticFeverCheckBox.Checked = false;
			historyOtherTextBox.Text = "";
			extractionCheckBox.Checked = false;
			pulpTherapyCheckBox.Checked = false;
			periodontalTherpyCheckBox.Checked = false;
			flourideTherapyCheckBox.Checked = false;
			prviousHistoryOthersTextBox.Text = "";
			checkBox1.Checked = false;
			PatientNumber();
			checkBox11.Checked = true;
			txtBloodType.Text = "";
			nationalID.Text = "";
			comboBox12.SelectedIndex = 0;
			MedicalStatus.Text = "";
			Medicin.Text = "";
			wieght.Value = 0m;
			hieght.Value = 0m;
			MusclesRate.Value = 0m;
			FatsRate.Value = 0m;
			if (txtFileNo.ReadOnly)
			{
				txtFileNo.Text = codes.Search2("select isnull(max(FileNo)+ 1,1) from PatientData").Rows[0][0].ToString();
			}
			else
			{
				txtFileNo.Text = "";
			}
			try
			{
				DataTable dataTable = codes.Search2("select distinct PAddress from PatientData");
				addressTextBox.DataSource = dataTable;
				addressTextBox.ValueMember = dataTable.Columns[0].ToString();
				addressTextBox.DisplayMember = dataTable.Columns[0].ToString();
				addressTextBox.SelectedIndex = -1;
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select * from City");
				cityTextBox.DataSource = dataTable;
				cityTextBox.ValueMember = dataTable.Columns[0].ToString();
				cityTextBox.DisplayMember = dataTable.Columns[1].ToString();
				cityTextBox.SelectedIndex = 0;
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select * from Nationality");
				nationalityTextBox.DataSource = dataTable;
				nationalityTextBox.ValueMember = dataTable.Columns[0].ToString();
				nationalityTextBox.DisplayMember = dataTable.Columns[1].ToString();
				nationalityTextBox.SelectedIndex = 0;
			}
			catch
			{
			}
			birthDateDateTimePicker.Value = DateTime.Now;
			floatText2.Text = "0";
			radioButton4.Checked = true;
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = dc.GetTableText("Select nationalID from PatientData where  nationalID ='" + nationalID.Text + "'");
				DataTable tableText2 = dc.GetTableText("Select Mob from PatientData where  Mob ='" + mobTextBox.Text + "'");
				if (!radioButton5.Checked)
				{
					comboBox13.Text = "";
				}
				if (!radioButton1.Checked)
				{
					PatientComboBox.Text = "";
				}
				int num = Convert.ToInt32(codes.Search2("select count(id) from PatientData").Rows[0][0].ToString());
				if (num >= 20)
				{
					MessageBox.Show("انتهت المدة المحددة لتشغيل البرنامج إذا أردت النسخة الكاملة الرجاء الإتصال بالشركة", "تحذير", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return;
				}
				if (nameTextBox.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter patient name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المريض");
					}
					return;
				}
				if (txtFileNo.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter patient code");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل كود المريض");
					}
					return;
				}
				if (checkedListBox1.CheckedItems.Count == 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter At Least One Of Patient Chief Complaint");
					}
					else
					{
						MessageBox.Show("اختر على الأقل شكوى واحدة للمريض");
					}
					return;
				}
				if (mobTextBox.Text != "" && tableText2.Rows.Count != 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("The number is already registered");
					}
					else
					{
						MessageBox.Show("رقم الموبايل مسجل سابقا\u064b");
					}
					mobTextBox.Text = "";
					return;
				}
				if (nationalID.Text != "" && tableText.Rows.Count != 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("The national number is already registered");
					}
					else
					{
						MessageBox.Show("رقم الهوية مسجل سابقا\u064b");
					}
					nationalID.Text = "";
					return;
				}
				string patient = nameTextBox.Text;
				string[] fields = new string[50]
				{
					"Titel", "PName", "PAddress", "City", "Tel", "Mob", "Email", "BirthDate", "Sex", "Nationality",
					"Statue", "company", "cardNum", "LastVistDate", "Allergies", "CardiacDisease", "KidneyDesease", "Diabetes", "RheumaticFever", "Asthma",
					"BloodDyscrasias", "HistoryOther", "Extraction", "DrugSensitivity", "PulpTherapy", "PeriodontalTherpy", "FlourideTherapy", "PrviousHistoryOthers", "Lactating", "Pregnant",
					"HepatitisB", "Hepatitisc", "Opretive", "Bleaching", "DoctoreName", "Accept", "FileNo", "Photo", "BloodType", "Active",
					"Patient", "Facebook", "Adv", "FormerPatient", "Discount", "Without", "Doctor", "DoctorId", "nationalID", "Dariba"
				};
				DataTable tableText4;
				if (companycomboBox.Text != "")
				{
					DataTable tableText3 = dc.GetTableText("Select * from Company where  Name='" + companycomboBox.Text + "'");
					if (tableText3.Rows.Count == 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please enter Valid company Name");
						}
						else
						{
							MessageBox.Show("من فضلك اختر اسم شركة صحيح", "", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						return;
					}
					tableText4 = dc.GetTableText("select * from PatientData where PName='" + nameTextBox.Text + "'");
					if (tableText4.Rows.Count == 0)
					{
						if (pictureBox1.BackgroundImage == null)
						{
							codes.Add2("insert into PatientData (Titel, PName, PAddress, City, Tel, Mob, Email, BirthDate, Sex, Nationality, Statue, company, cardNum, LastVistDate, Allergies, CardiacDisease, KidneyDesease, Diabetes, RheumaticFever, Asthma, BloodDyscrasias, HistoryOther, Extraction, Endodontics, Fixed, PeriodontalTherpy, Implant, PrviousHistoryOthers, Lactating, Pregnant, HepatitisB, Hepatitisc, Opretive, Bleaching, DoctoreName,Accept,Active,FileNo,Patient,Facebook,Adv,FormerPatient,Discount,Without,Doctor,DoctorId, nationalID, Dariba) values('" + titelComboBox.Text + "', '" + nameTextBox.Text + "', '" + addressTextBox.Text + "', '" + cityTextBox.Text + "', '" + telTextBox.Text + "', '" + mobTextBox.Text + "', '" + emailTextBox.Text + "', '" + birthDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "','" + sexComboBox.Text + "', '" + nationalityTextBox.Text + "', '" + statueComboBox.Text + "', '" + Convert.ToInt32(companycomboBox.SelectedValue.ToString()) + "','" + cardNumTextBox.Text + "', '" + lastVistDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "','" + allergiesCheckBox.Checked + "','" + cardiacDiseaseCheckBox.Checked + "', '" + kidneyDeseaseCheckBox.Checked + "','" + diabetesCheckBox.Checked + "', '" + rheumaticFeverCheckBox.Checked + "','" + asthmaCheckBox.Checked + "', '" + bloodDyscrasiasCheckBox.Checked + "','" + historyOtherTextBox.Text + "', '" + extractionCheckBox.Checked + "','" + drugSensitivityCheckBox.Checked + "', '" + pulpTherapyCheckBox.Checked + "','" + periodontalTherpyCheckBox.Checked + "', '" + flourideTherapyCheckBox.Checked + "','" + prviousHistoryOthersTextBox.Text + "', '" + lactatingcheckBox.Checked + "', '" + PregnantcheckBox.Checked + "', '" + HepatitisBcheckBox.Checked + "', '" + HepatitisCcheckBox.Checked + "', '" + OpretivecheckBox.Checked + "', '" + BleachingcheckBox.Checked + "', '" + DoctorcomboBox.Text + "', '" + checkBox1.Checked + "','" + checkBox11.Checked + "','" + txtFileNo.Text + "','" + radioButton1.Checked + "','" + radioButton2.Checked + "','" + radioButton3.Checked + "','" + PatientComboBox.Text + "','" + floatText1.Text + "','" + radioButton4.Checked + "','" + radioButton5.Checked + "','" + comboBox13.Text + "','" + nationalID.Text + "','" + checkBox12.Checked + "')");
							string text = codes.Search2("select Max(Id) from PatientData").Rows[0][0].ToString();
							foreach (object checkedItem in checkedListBox1.CheckedItems)
							{
								int num2 = checkedListBox1.Items.IndexOf(checkedItem) + 1;
								codes.Add2("insert into ComplaintDetails(CId,PatientID) Values('" + num2 + "','" + text + "')");
							}
							if (checkedListBox3.CheckedItems.Count != 0)
							{
								foreach (object checkedItem2 in checkedListBox3.CheckedItems)
								{
									int num2 = checkedListBox3.Items.IndexOf(checkedItem2) + 1;
									codes.Add2("insert into MedicalHistoryDetails(MID,PatientID) Values('" + num2 + "','" + text + "')");
								}
							}
							OtherData(0);
							if (Convert.ToBoolean(dc.GetTableText("select Physicaltherapy from DentalData").Rows[0][0]))
							{
								codes.Add2("insert into PhysicaltherapyPatientData(Patientid,MedicalStatus,Medicin,wieght,hieght,MusclesRate,FatsRate) Values('" + text + "','" + MedicalStatus.Text + "','" + Medicin.Text + "','" + wieght.Text + "','" + hieght.Text + "','" + MusclesRate.Text + "','" + FatsRate.Text + "')");
							}
							if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							else
							{
								MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								MethodsClass.UserMove("أضافة مريض");
							}
							Appointments appointments = new Appointments(patient);
							appointments.ShowDialog();
							EmptyText();
						}
						else if (dc.Insert("addPationt", fields, titelComboBox.Text, nameTextBox.Text, addressTextBox.Text, cityTextBox.Text, telTextBox.Text, mobTextBox.Text, emailTextBox.Text, birthDateDateTimePicker.Value.ToString("MM/dd/yyyy"), sexComboBox.Text, nationalityTextBox.Text, statueComboBox.Text, Convert.ToInt32(companycomboBox.SelectedValue.ToString()), cardNumTextBox.Text, lastVistDateDateTimePicker.Value.ToString("MM/dd/yyyy"), allergiesCheckBox.Checked ? true : false, cardiacDiseaseCheckBox.Checked ? true : false, kidneyDeseaseCheckBox.Checked ? true : false, diabetesCheckBox.Checked ? true : false, rheumaticFeverCheckBox.Checked ? true : false, asthmaCheckBox.Checked ? true : false, bloodDyscrasiasCheckBox.Checked ? true : false, historyOtherTextBox.Text, extractionCheckBox.Checked ? true : false, drugSensitivityCheckBox.Checked ? true : false, pulpTherapyCheckBox.Checked ? true : false, periodontalTherpyCheckBox.Checked ? true : false, flourideTherapyCheckBox.Checked ? true : false, prviousHistoryOthersTextBox.Text, lactatingcheckBox.Checked ? true : false, PregnantcheckBox.Checked ? true : false, HepatitisBcheckBox.Checked ? true : false, HepatitisCcheckBox.Checked ? true : false, OpretivecheckBox.Checked ? true : false, BleachingcheckBox.Checked ? true : false, DoctorcomboBox.Text, checkBox1.Checked, txtFileNo.Text, Logo, txtBloodType.Text, checkBox11.Checked, radioButton1.Checked, radioButton2.Checked, radioButton3.Checked, PatientComboBox.Text, floatText1.Text, radioButton4.Checked, radioButton5.Checked, comboBox13.Text, nationalID.Text, checkBox12.Checked))
						{
							string text = codes.Search2("select Max(Id) from PatientData").Rows[0][0].ToString();
							foreach (object checkedItem3 in checkedListBox1.CheckedItems)
							{
								int num2 = checkedListBox1.Items.IndexOf(checkedItem3) + 1;
								codes.Add2("insert into ComplaintDetails(CId,PatientID) Values('" + num2 + "','" + text + "')");
							}
							if (checkedListBox3.CheckedItems.Count != 0)
							{
								foreach (object checkedItem4 in checkedListBox3.CheckedItems)
								{
									int num2 = checkedListBox3.Items.IndexOf(checkedItem4) + 1;
									codes.Add2("insert into MedicalHistoryDetails(MID,PatientID) Values('" + num2 + "','" + text + "')");
								}
							}
							if (Convert.ToBoolean(dc.GetTableText("select Physicaltherapy from DentalData").Rows[0][0]))
							{
								codes.Add2("insert into PhysicaltherapyPatientData(Patientid,MedicalStatus,Medicin,wieght,hieght,MusclesRate,FatsRate) Values('" + text + "','" + MedicalStatus.Text + "','" + Medicin.Text + "','" + wieght.Text + "','" + hieght.Text + "','" + MusclesRate.Text + "','" + FatsRate.Text + "')");
							}
							OtherData(0);
							if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							else
							{
								MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								MethodsClass.UserMove("أضافة مريض");
							}
							Appointments appointments = new Appointments(patient);
							appointments.ShowDialog();
							EmptyText();
							try
							{
								DataTable dataTable = codes.Search2("SELECT ID, PName from PatientData where Active = 'True'");
								PatientComboBox.DataSource = dataTable;
								PatientComboBox.ValueMember = dataTable.Columns[0].ToString();
								PatientComboBox.DisplayMember = dataTable.Columns[1].ToString();
							}
							catch
							{
							}
						}
						else if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						else
						{
							MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This Patient Before", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("اسم المريض مسجل من قبل", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					return;
				}
				tableText4 = dc.GetTableText("select * from PatientData where PName='" + nameTextBox.Text + "'");
				if (tableText4.Rows.Count == 0)
				{
					if (pictureBox1.BackgroundImage == null)
					{
						codes.Add2("insert into PatientData (Titel, PName, PAddress, City, Tel, Mob, Email, BirthDate, Sex, Nationality, Statue, company, cardNum, LastVistDate, Allergies, CardiacDisease, KidneyDesease, Diabetes, RheumaticFever, Asthma, BloodDyscrasias, HistoryOther, Extraction, Endodontics, Fixed, PeriodontalTherpy, Implant, PrviousHistoryOthers, Lactating, Pregnant, HepatitisB, Hepatitisc, Opretive, Bleaching, DoctoreName,Accept,BloodType,Active,FileNo,Patient,Facebook,Adv,FormerPatient,Discount,Without,Doctor,DoctorId , nationalID) values('" + titelComboBox.Text + "', '" + nameTextBox.Text + "', '" + addressTextBox.Text + "', '" + cityTextBox.Text + "', '" + telTextBox.Text + "', '" + mobTextBox.Text + "', '" + emailTextBox.Text + "', '" + birthDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "','" + sexComboBox.Text + "', '" + nationalityTextBox.Text + "', '" + statueComboBox.Text + "', '" + Convert.ToInt32(companycomboBox.SelectedValue.ToString()) + "','" + cardNumTextBox.Text + "', '" + lastVistDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "','" + allergiesCheckBox.Checked + "','" + cardiacDiseaseCheckBox.Checked + "', '" + kidneyDeseaseCheckBox.Checked + "','" + diabetesCheckBox.Checked + "', '" + rheumaticFeverCheckBox.Checked + "','" + asthmaCheckBox.Checked + "', '" + bloodDyscrasiasCheckBox.Checked + "','" + historyOtherTextBox.Text + "', '" + extractionCheckBox.Checked + "','" + drugSensitivityCheckBox.Checked + "', '" + pulpTherapyCheckBox.Checked + "','" + periodontalTherpyCheckBox.Checked + "', '" + flourideTherapyCheckBox.Checked + "','" + prviousHistoryOthersTextBox.Text + "', '" + lactatingcheckBox.Checked + "', '" + PregnantcheckBox.Checked + "', '" + HepatitisBcheckBox.Checked + "', '" + HepatitisCcheckBox.Checked + "', '" + OpretivecheckBox.Checked + "', '" + BleachingcheckBox.Checked + "', '" + DoctorcomboBox.Text + "', '" + checkBox1.Checked + "','" + txtBloodType.Text + "','" + checkBox11.Checked + "','" + txtFileNo.Text + "','" + radioButton1.Checked + "','" + radioButton2.Checked + "',,'" + radioButton3.Checked + "','" + PatientComboBox.Text + "','" + floatText1.Text + "','" + radioButton4.Checked + "','" + radioButton5.Checked + "','" + comboBox13.Text + "','" + nationalID.Text + "')");
						string text = codes.Search2("select Max(Id) from PatientData").Rows[0][0].ToString();
						foreach (object checkedItem5 in checkedListBox1.CheckedItems)
						{
							int num2 = checkedListBox1.Items.IndexOf(checkedItem5) + 1;
							codes.Add2("insert into ComplaintDetails(CId,PatientID) Values('" + num2 + "','" + text + "')");
						}
						if (checkedListBox3.CheckedItems.Count != 0)
						{
							foreach (object checkedItem6 in checkedListBox3.CheckedItems)
							{
								int num2 = checkedListBox3.Items.IndexOf(checkedItem6) + 1;
								codes.Add2("insert into MedicalHistoryDetails(MID,PatientID) Values('" + num2 + "','" + text + "')");
							}
						}
						OtherData(0);
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove("أضافة مريض");
						Appointments appointments = new Appointments(patient);
						appointments.ShowDialog();
						EmptyText();
					}
					else if (dc.Insert("addPationt", fields, titelComboBox.Text, nameTextBox.Text, addressTextBox.Text, cityTextBox.Text, telTextBox.Text, mobTextBox.Text, emailTextBox.Text, birthDateDateTimePicker.Value.ToString("MM/dd/yyyy"), sexComboBox.Text, nationalityTextBox.Text, statueComboBox.Text, Convert.ToInt32(companycomboBox.SelectedValue.ToString()), cardNumTextBox.Text, lastVistDateDateTimePicker.Value.ToString("MM/dd/yyyy"), allergiesCheckBox.Checked ? true : false, cardiacDiseaseCheckBox.Checked ? true : false, kidneyDeseaseCheckBox.Checked ? true : false, diabetesCheckBox.Checked ? true : false, rheumaticFeverCheckBox.Checked ? true : false, asthmaCheckBox.Checked ? true : false, bloodDyscrasiasCheckBox.Checked ? true : false, historyOtherTextBox.Text, extractionCheckBox.Checked ? true : false, drugSensitivityCheckBox.Checked ? true : false, pulpTherapyCheckBox.Checked ? true : false, periodontalTherpyCheckBox.Checked ? true : false, flourideTherapyCheckBox.Checked ? true : false, prviousHistoryOthersTextBox.Text, lactatingcheckBox.Checked ? true : false, PregnantcheckBox.Checked ? true : false, HepatitisBcheckBox.Checked ? true : false, HepatitisCcheckBox.Checked ? true : false, OpretivecheckBox.Checked ? true : false, BleachingcheckBox.Checked ? true : false, DoctorcomboBox.Text, checkBox1.Checked, txtFileNo.Text, Logo, txtBloodType.Text, checkBox11.Checked, radioButton1.Checked, radioButton2.Checked, radioButton3.Checked, PatientComboBox.Text, floatText1.Text, radioButton4.Checked, radioButton5.Checked, comboBox13.Text, nationalID.Text))
					{
						string text = codes.Search2("select Max(Id) from PatientData").Rows[0][0].ToString();
						foreach (object checkedItem7 in checkedListBox1.CheckedItems)
						{
							int num2 = checkedListBox1.Items.IndexOf(checkedItem7) + 1;
							codes.Add2("insert into ComplaintDetails(CId,PatientID) Values('" + num2 + "','" + text + "')");
						}
						if (checkedListBox3.CheckedItems.Count != 0)
						{
							foreach (object checkedItem8 in checkedListBox3.CheckedItems)
							{
								int num2 = checkedListBox3.Items.IndexOf(checkedItem8) + 1;
								codes.Add2("insert into MedicalHistoryDetails(MID,PatientID) Values('" + num2 + "','" + text + "')");
							}
						}
						OtherData(0);
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove("أضافة مريض");
						Appointments appointments = new Appointments(patient);
						appointments.ShowDialog();
						EmptyText();
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("You Have Save This Patient Before", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اسم المريض مسجل من قبل", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void updatePatient()
		{
			DataTable tableText = dc.GetTableText("select * from PatientData where PName='" + nameTextBox.Text + "' and ID <> '" + PationtId + "'");
			if (txtFileNo.Text == "")
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter patient code");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل كود المريض");
				}
				return;
			}
			if (tableText.Rows.Count > 0)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("You Have Save This Patient Before", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اسم المريض مسجل من قبل", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				return;
			}
			codes.Delete2("delete from ComplaintDetails where PatientID = '" + PationtId + "'");
			foreach (object checkedItem in checkedListBox1.CheckedItems)
			{
				int num = checkedListBox1.Items.IndexOf(checkedItem) + 1;
				codes.Add2("insert into ComplaintDetails(CId,PatientID) Values('" + num.ToString() + "','" + PationtId + "')");
			}
			DataTable dataTable = codes.Search2("select * from ServiceDetails where PatientID = '" + PationtId + "'");
			if (dataTable.Rows.Count == 0)
			{
				if (checkedListBox2.CheckedItems.Count != 0)
				{
					foreach (object checkedItem2 in checkedListBox2.CheckedItems)
					{
						int num = checkedListBox2.Items.IndexOf(checkedItem2) + 1;
						codes.Add2("insert into ServiceDetails(SId,PatientID) Values('" + num.ToString() + "','" + PationtId + "')");
					}
				}
			}
			else
			{
				codes.Delete2("delete from ServiceDetails where PatientID = '" + PationtId + "'");
				if (checkedListBox2.CheckedItems.Count != 0)
				{
					foreach (object checkedItem3 in checkedListBox2.CheckedItems)
					{
						int num = checkedListBox2.Items.IndexOf(checkedItem3) + 1;
						codes.Add2("insert into ServiceDetails(SId,PatientID) Values('" + num.ToString() + "','" + PationtId + "')");
					}
				}
			}
			DataTable dataTable2 = codes.Search2("select * from MedicalHistoryDetails where PatientID = '" + PationtId + "'");
			if (dataTable2.Rows.Count == 0)
			{
				if (checkedListBox3.CheckedItems.Count != 0)
				{
					foreach (object checkedItem4 in checkedListBox3.CheckedItems)
					{
						int num = checkedListBox3.Items.IndexOf(checkedItem4) + 1;
						codes.Add2("insert into MedicalHistoryDetails(MID,PatientID) Values('" + num.ToString() + "','" + PationtId + "')");
					}
				}
			}
			else
			{
				codes.Delete2("delete from MedicalHistoryDetails where PatientID = '" + PationtId + "'");
				if (checkedListBox3.CheckedItems.Count != 0)
				{
					foreach (object checkedItem5 in checkedListBox3.CheckedItems)
					{
						int num = checkedListBox3.Items.IndexOf(checkedItem5) + 1;
						codes.Add2("insert into MedicalHistoryDetails(MID,PatientID) Values('" + num.ToString() + "','" + PationtId + "')");
					}
				}
			}
			try
			{
				if (pictureBox1.BackgroundImage == null)
				{
					codes.Edit2("update PatientData set Titel ='" + titelComboBox.Text + "' , PName = '" + nameTextBox.Text + "', PAddress = '" + addressTextBox.Text + "', City='" + cityTextBox.Text + "', Tel='" + telTextBox.Text + "', Mob='" + mobTextBox.Text + "', Email='" + emailTextBox.Text + "', BirthDate='" + birthDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "', Sex='" + sexComboBox.Text + "', Nationality='" + nationalityTextBox.Text + "', Statue='" + statueComboBox.Text + "', company='" + Convert.ToInt32(companycomboBox.SelectedValue.ToString()) + "', cardNum='" + cardNumTextBox.Text + "', LastVistDate='" + lastVistDateDateTimePicker.Value.ToString("MM/dd/yyyy") + "' ,HistoryOther='" + historyOtherTextBox.Text + "', DoctoreName='" + DoctorcomboBox.Text + "', Accept='" + checkBox1.Checked + "',BloodType = '" + txtBloodType.Text + "',Active = '" + checkBox11.Checked + "',FileNo='" + txtFileNo.Text + "',Patient='" + radioButton1.Checked + "',Facebook='" + radioButton2.Checked + "',Adv='" + radioButton3.Checked + "',FormerPatient='" + PatientComboBox.Text + "',Discount='" + floatText1.Text + "',Without='" + radioButton4.Checked + "',Doctor='" + radioButton5.Checked + "',DoctorId = '" + comboBox13.Text + "',nationalID = '" + nationalID.Text + "',Dariba='" + checkBox12.Checked + "' where ID ='" + PationtId.ToString() + "'");
					OtherData(PationtId);
					if (Convert.ToBoolean(dc.GetTableText("select Physicaltherapy from DentalData").Rows[0][0]))
					{
						codes.Edit2("update PhysicaltherapyPatientData set MedicalStatus='" + MedicalStatus.Text + "',Medicin='" + Medicin.Text + "',wieght='" + wieght.Text + "',hieght='" + hieght.Text + "',MusclesRate='" + MusclesRate.Text + "',FatsRate='" + FatsRate.Text + "' where Patientid='" + PationtId + "'");
					}
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					MethodsClass.UserMove("تعديل مريض");
					EmptyText();
					return;
				}
				string[] fields = new string[51]
				{
					"ID", "Titel", "PName", "PAddress", "City", "Tel", "Mob", "Email", "BirthDate", "Sex",
					"Nationality", "Statue", "company", "cardNum", "LastVistDate", "Allergies", "CardiacDisease", "KidneyDesease", "Diabetes", "RheumaticFever",
					"Asthma", "BloodDyscrasias", "HistoryOther", "Extraction", "DrugSensitivity", "PulpTherapy", "PeriodontalTherpy", "FlourideTherapy", "PrviousHistoryOthers", "Lactating",
					"Pregnant", "HepatitisB", "Hepatitisc", "Opretive", "Bleaching", "DoctoreName", "Accept", "Photo", "BloodType", "Active",
					"FileNo", "Patient", "Facebook", "Adv", "FormerPatient", "Discount", "Without", "Doctor", "DoctorId", "nationalID",
					"Dariba"
				};
				if (dc.Update("updatepatient", fields, PationtId, titelComboBox.Text, nameTextBox.Text, addressTextBox.Text, cityTextBox.Text, telTextBox.Text, mobTextBox.Text, emailTextBox.Text, birthDateDateTimePicker.Value.ToString("MM/dd/yyyy"), sexComboBox.Text, nationalityTextBox.Text, statueComboBox.Text, Convert.ToInt32(companycomboBox.SelectedValue.ToString()), cardNumTextBox.Text, lastVistDateDateTimePicker.Value.ToString("MM/dd/yyyy"), allergiesCheckBox.Checked ? true : false, cardiacDiseaseCheckBox.Checked ? true : false, kidneyDeseaseCheckBox.Checked ? true : false, diabetesCheckBox.Checked ? true : false, rheumaticFeverCheckBox.Checked ? true : false, asthmaCheckBox.Checked ? true : false, bloodDyscrasiasCheckBox.Checked ? true : false, historyOtherTextBox.Text, extractionCheckBox.Checked ? true : false, drugSensitivityCheckBox.Checked ? true : false, pulpTherapyCheckBox.Checked ? true : false, periodontalTherpyCheckBox.Checked ? true : false, flourideTherapyCheckBox.Checked ? true : false, prviousHistoryOthersTextBox.Text, lactatingcheckBox.Checked ? true : false, PregnantcheckBox.Checked ? true : false, HepatitisBcheckBox.Checked ? true : false, HepatitisCcheckBox.Checked ? true : false, OpretivecheckBox.Checked ? true : false, BleachingcheckBox.Checked ? true : false, DoctorcomboBox.Text, checkBox1.Checked, Logo, txtBloodType.Text, checkBox11.Checked, txtFileNo.Text, radioButton1.Checked, radioButton2.Checked, radioButton3.Checked, PatientComboBox.Text, floatText1.Text, radioButton4.Checked, radioButton5.Checked, comboBox13.Text, nationalID.Text, checkBox12.Checked))
				{
					OtherData(PationtId);
					if (Convert.ToBoolean(dc.GetTableText("select Physicaltherapy from DentalData").Rows[0][0]))
					{
						codes.Edit2("update PhysicaltherapyPatientData set MedicalStatus='" + MedicalStatus.Text + "',Medicin='" + Medicin.Text + "',wieght='" + wieght.Text + "',hieght='" + hieght.Text + "',MusclesRate='" + MusclesRate.Text + "',FatsRate='" + FatsRate.Text + "' where Patientid='" + PationtId + "'");
					}
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					MethodsClass.UserMove("تعديل مريض");
				}
			}
			catch
			{
			}
		}

		private void OtherData(int PatientID)
		{
			DataTable dataTable = codes.Search2("select FemaleClinic,NaturalClinic from DentalData");
			bool flag = Convert.ToBoolean(dataTable.Rows[0][0].ToString());
			bool flag2 = Convert.ToBoolean(dataTable.Rows[0][1].ToString());
			if (flag)
			{
				if (PatientID == 0)
				{
					DataTable dataTable2 = codes.Search2("select max(id) from PatientData");
					PatientID = Convert.ToInt32(dataTable2.Rows[0][0].ToString());
				}
				codes.Delete2("delete from MarriageData where PatientID = '" + PatientID + "'");
				codes.Delete2("delete from Births where PatientID = '" + PatientID + "'");
				codes.Add2("insert into MarriageData (PatientID, HusbandName, HusbandAge, MarriagePeriod, PreviousMarriage, PreviousMarriageKidsCount, Weight, Pressure, Sugar, TakeDrugs, Drugs, HusbandSmoke, WifeSmoke, Pregnant, PregnancyMonth, PregnancyCount, MaleCount, FemaleCount, Abortion, PeriodStart, BleedingAmount, PeriodCount, RegularPeriod, PeriodEnd, LastPerionDate, MeansContraception, MeansContraceptionType, Complaint, OtherInfo, BirthDate, BirthSurgeryType,MPeriod) Values ('" + PatientID + "', '" + textBox1.Text + "', '" + numericUpDown9.Value + "', '" + numericUpDown10.Value + "', '" + checkBox2.Checked + "', '" + numericUpDown1.Value + "', '" + numericUpDown2.Value + "', '" + checkBox3.Checked + "', '" + checkBox4.Checked + "', '" + checkBox5.Checked + "', '" + textBox4.Text + "', '" + checkBox7.Checked + "', '" + checkBox6.Checked + "', '" + checkBox8.Checked + "', '" + numericUpDown3.Value + "', '" + numericUpDown4.Value + "', '" + numericUpDown5.Value + "', '" + numericUpDown6.Value + "', '" + numericUpDown7.Value + "', '" + numericUpDown8.Value + "', '" + comboBox1.Text + "', '" + numericUpDown11.Value + "', '" + checkBox9.Checked + "', '" + numericUpDown12.Value + "', '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "', '" + checkBox10.Checked + "', '" + comboBox2.Text + "', '" + comboBox3.Text + "', '" + comboBox4.Text + "', '" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "', '" + comboBox5.Text + "','" + comboBox12.Text + "')");
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					codes.Add2("insert into Births (PatientID, PregnancyNo, PregnancyPeriod, BirthWay, BirthPlace, BirthResult, BabyComplications, MotherComplications, Notes) Values ('" + PatientID + "', '" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[1].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[3].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[4].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[5].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[6].Value.ToString() + "', '" + dataGridView1.Rows[i].Cells[7].Value.ToString() + "')");
				}
			}
			if (flag2)
			{
				if (PatientID == 0)
				{
					DataTable dataTable2 = codes.Search2("select max(id) from PatientData");
					PatientID = Convert.ToInt32(dataTable2.Rows[0][0].ToString());
				}
				DataTable dataTable3 = codes.Search2("select * from ChildData where PatientID = '" + PatientID + "'");
				if (dataTable3.Rows.Count > 0)
				{
					codes.Edit2("update ChildData set PregnancyNo ='" + numericUpDown15.Value + "' , PregnancyPeriod = '" + numericUpDown16.Value + "', BirthType = '" + comboBox17.Text + "' , ChildNo = '" + numericUpDown17.Value + "', BreastFeeding = '" + comboBox16.Text + "', Weight = '" + numericUpDown18.Value + "' , Surgery = '" + textBox3.Text + "', Notes ='" + textBox2.Text + "' , Allergies = '" + textBox5.Text + "' where PatientID = '" + PatientID.ToString() + "'");
				}
				else
				{
					codes.Add2("insert into ChildData (PatientID, PregnancyNo, PregnancyPeriod, BirthType, ChildNo, BreastFeeding, Weight, Surgery, Notes,Allergies) Values ('" + PatientID.ToString() + "', '" + numericUpDown15.Value + "', '" + numericUpDown16.Value + "', '" + comboBox17.Text + "', '" + numericUpDown17.Value + "', '" + comboBox16.Text + "', '" + numericUpDown18.Value + "', '" + textBox3.Text + "', '" + textBox2.Text + "','" + textBox5.Text + "')");
				}
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			DataTable tableText = dc.GetTableText("select * from PatientData where PName='" + nameTextBox.Text + "' and ID <> '" + PationtId + "'");
			if (!radioButton5.Checked)
			{
				comboBox13.Text = "";
			}
			if (!radioButton1.Checked)
			{
				PatientComboBox.Text = "";
			}
			if (tableText.Rows.Count > 0)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("You Have Save This Patient Before", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اسم المريض مسجل من قبل", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				return;
			}
			if (nationalID.Text != "")
			{
				DataTable tableText2 = dc.GetTableText("Select nationalID from PatientData where  nationalID ='" + nationalID.Text + "' and ID != '" + PationtId + "'");
				if (tableText2.Rows.Count != 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("The national number is already registered");
					}
					else
					{
						MessageBox.Show("رقم الهوية مسجل سابقا\u064b");
					}
					nationalID.Text = "";
					return;
				}
			}
			if (mobTextBox.Text != "")
			{
				DataTable tableText2 = dc.GetTableText("Select Mob from PatientData where  Mob ='" + mobTextBox.Text + "' and ID != '" + PationtId + "'");
				if (tableText2.Rows.Count != 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("The number is already registered");
					}
					else
					{
						MessageBox.Show("رقم الموبايل مسجل سابقا\u064b");
					}
					mobTextBox.Text = "";
					return;
				}
			}
			updatePatient();
			Close();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Company company = new Company();
			company.ShowDialog();
			try
			{
				DataTable tableText = dc.GetTableText("select * from Company");
				gui.loadComboBox(companycomboBox, tableText);
				companycomboBox.SelectedItem = companycomboBox.Items[0];
			}
			catch
			{
			}
		}

		private void companycomboBox_Enter(object sender, EventArgs e)
		{
			try
			{
				CompanyComb();
			}
			catch
			{
			}
		}

		private void nameTextBox_TextChanged(object sender, EventArgs e)
		{
			string text = nameTextBox.Text;
			if (text.StartsWith(" "))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("It IS Not Allowed To Use Space In The Beginning", "Notes");
				}
				else
				{
					MessageBox.Show("لا يمكن ترك فراغ في بداية الإسم", "تنبيه");
				}
				nameTextBox.Text = "";
			}
		}

		private void PationtInfo_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void AddComment_Click(object sender, EventArgs e)
		{
			CommentFrm commentFrm = new CommentFrm(PationtId);
			commentFrm.ShowDialog();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			PatientPayAccount patientPayAccount = new PatientPayAccount(PationtId);
			patientPayAccount.ShowDialog();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			PatientAccountSecretaryFrm patientAccountSecretaryFrm = new PatientAccountSecretaryFrm(PationtId);
			patientAccountSecretaryFrm.ShowDialog();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			Appointments appointments = new Appointments(PationtId);
			appointments.Show();
		}

		private void button5_Click(object sender, EventArgs e)
		{
			try
			{
				codes.Edit2("update PatientData set Taqweem='True' where ID='" + PationtId + "'");
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Added to Orthodontic");
				}
				else
				{
					MessageBox.Show("تم إضافة المريض للتقويم");
				}
				button5.Visible = false;
			}
			catch
			{
			}
		}

		private void button6_Click(object sender, EventArgs e)
		{
			try
			{
				codes.Edit2("update PatientData set Taqweem='False' where ID='" + PationtId + "'");
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Removed from Orthodontic");
				}
				else
				{
					MessageBox.Show("تم إزالة المريض من التقويم");
				}
				button6.Visible = false;
			}
			catch
			{
			}
		}

		private void checkedListBox2_ItemCheck(object sender, ItemCheckEventArgs e)
		{
			try
			{
				if (e.NewValue == CheckState.Checked)
				{
					CommentFrm commentFrm = new CommentFrm(int.Parse(IDtextBox.Text), checkedListBox2.SelectedItem.ToString());
					commentFrm.ShowDialog();
				}
			}
			catch
			{
			}
		}

		private void button7_Click(object sender, EventArgs e)
		{
			if (PationtId == 0)
			{
				FrmMainComplaint frmMainComplaint = new FrmMainComplaint();
				frmMainComplaint.ShowDialog();
				checkedListBox1.Items.Clear();
				try
				{
					DataTable dataTable = codes.Search2("select Complaint from MainComplaint");
					foreach (DataRow row in dataTable.Rows)
					{
						checkedListBox1.Items.Add(row.ItemArray[0]);
					}
				}
				catch
				{
				}
			}
			else
			{
				if (PationtId <= 0)
				{
					return;
				}
				FrmMainComplaint frmMainComplaint = new FrmMainComplaint();
				frmMainComplaint.ShowDialog();
				checkedListBox1.Items.Clear();
				try
				{
					DataTable dataTable = codes.Search2("select Complaint from MainComplaint");
					foreach (DataRow row2 in dataTable.Rows)
					{
						checkedListBox1.Items.Add(row2.ItemArray[0]);
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText = dc.GetTableText("SELECT CId FROM ComplaintDetails where PatientID = '" + PationtId + "'");
					foreach (DataRow row3 in tableText.Rows)
					{
						int num = Convert.ToInt32(row3["CId"].ToString());
						checkedListBox1.SetItemChecked(num - 1, value: true);
					}
				}
				catch
				{
				}
			}
		}

		private void button8_Click(object sender, EventArgs e)
		{
			FrmServicePatient frmServicePatient = new FrmServicePatient();
			frmServicePatient.ShowDialog();
			checkedListBox2.Items.Clear();
			try
			{
				DataTable dataTable = codes.Search2("select ServiceName from ServicePatient");
				foreach (DataRow row in dataTable.Rows)
				{
					checkedListBox2.Items.Add(row.ItemArray[0]);
				}
			}
			catch
			{
			}
			try
			{
				DataTable tableText = dc.GetTableText("SELECT SId FROM ServiceDetails where PatientID = '" + PationtId + "'");
				foreach (DataRow row2 in tableText.Rows)
				{
					int num = Convert.ToInt32(row2["SId"].ToString());
					checkedListBox2.SetItemChecked(num - 1, value: true);
				}
			}
			catch
			{
			}
		}

		private void DentalLogoBtn_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = openFileDialog1.ShowDialog();
			if (dialogResult != DialogResult.Cancel)
			{
				Logo = GetImage(openFileDialog1.FileName);
				pictureBox1.BackgroundImage = Image.FromFile(openFileDialog1.FileName);
			}
		}

		private void button9_Click(object sender, EventArgs e)
		{
			try
			{
				int num = 0;
				while (true)
				{
					if (num < dataGridView1.Rows.Count)
					{
						if (dataGridView1.Rows[num].Cells[0].Value.ToString() == numericUpDown14.Value.ToString())
						{
							break;
						}
						num++;
						continue;
					}
					dataGridView1.Rows.Add(numericUpDown14.Value, numericUpDown13.Value, comboBox7.Text, comboBox6.Text, comboBox8.Text, comboBox9.Text, comboBox11.Text, comboBox10.Text);
					return;
				}
				MessageBox.Show("رقم الحمل مسجل من قبل");
			}
			catch
			{
			}
		}

		private void button10_Click(object sender, EventArgs e)
		{
			if (PationtId == 0)
			{
				FrmMedicalHistory frmMedicalHistory = new FrmMedicalHistory();
				frmMedicalHistory.ShowDialog();
				checkedListBox3.Items.Clear();
				try
				{
					DataTable dataTable = codes.Search2("select History from MedicalHistory");
					foreach (DataRow row in dataTable.Rows)
					{
						checkedListBox3.Items.Add(row.ItemArray[0]);
					}
				}
				catch
				{
				}
			}
			else
			{
				if (PationtId <= 0)
				{
					return;
				}
				FrmMedicalHistory frmMedicalHistory = new FrmMedicalHistory();
				frmMedicalHistory.ShowDialog();
				checkedListBox3.Items.Clear();
				try
				{
					DataTable dataTable = codes.Search2("select History from MedicalHistory");
					foreach (DataRow row2 in dataTable.Rows)
					{
						checkedListBox3.Items.Add(row2.ItemArray[0]);
					}
				}
				catch
				{
				}
				try
				{
					DataTable tableText = dc.GetTableText("SELECT MID FROM MedicalHistoryDetails where PatientID = '" + PationtId + "'");
					foreach (DataRow row3 in tableText.Rows)
					{
						int num = Convert.ToInt32(row3["MID"].ToString());
						checkedListBox3.SetItemChecked(num - 1, value: true);
					}
				}
				catch
				{
				}
			}
		}

		private void clear1()
		{
			numericUpDown15.Value = 1m;
			numericUpDown16.Value = 0m;
			comboBox17.SelectedIndex = 0;
			numericUpDown17.Value = 0m;
			comboBox16.SelectedIndex = 0;
			numericUpDown18.Value = 0m;
			textBox3.Text = "";
			textBox2.Text = "";
		}

		private void label37_Click(object sender, EventArgs e)
		{
		}

		private void textBox6_TextChanged(object sender, EventArgs e)
		{
		}

		private void txtFileNo_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
			{
				e.Handled = true;
			}
		}

		private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
		{
			DateTime dateTime = Convert.ToDateTime(dateTimePicker1.Value);
			dateTimePicker2.Value = dateTime.AddMonths(9).AddDays(7.0);
		}

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{
			if (radioButton5.Checked)
			{
				panel3.Visible = true;
			}
			else if (!radioButton5.Checked)
			{
				panel3.Visible = false;
			}
			if (radioButton1.Checked)
			{
				panel2.Visible = true;
			}
			else if (!radioButton1.Checked)
			{
				panel2.Visible = false;
			}
		}

		private void radioButton2_CheckedChanged(object sender, EventArgs e)
		{
			if (radioButton5.Checked)
			{
				panel3.Visible = true;
			}
			else if (!radioButton5.Checked)
			{
				panel3.Visible = false;
			}
			if (radioButton1.Checked)
			{
				panel2.Visible = true;
			}
			else if (!radioButton1.Checked)
			{
				panel2.Visible = false;
			}
		}

		private void radioButton3_CheckedChanged(object sender, EventArgs e)
		{
			if (radioButton5.Checked)
			{
				panel3.Visible = true;
			}
			else if (!radioButton5.Checked)
			{
				panel3.Visible = false;
			}
			if (radioButton1.Checked)
			{
				panel2.Visible = true;
			}
			else if (!radioButton1.Checked)
			{
				panel2.Visible = false;
			}
		}

		private void floatText2_TextChanged(object sender, EventArgs e)
		{
			try
			{
				int value = -1 * Convert.ToInt32(floatText2.Text);
				DateTime dateTime = default(DateTime);
				dateTime = new DateTime(DateTime.Now.AddYears(value).Year, 1, 1);
				birthDateDateTimePicker.Value = dateTime;
			}
			catch
			{
			}
		}

		private void radioButton5_CheckedChanged(object sender, EventArgs e)
		{
			if (radioButton5.Checked)
			{
				panel3.Visible = true;
			}
			else if (!radioButton5.Checked)
			{
				panel3.Visible = false;
			}
			if (radioButton1.Checked)
			{
				panel2.Visible = true;
			}
			else if (!radioButton1.Checked)
			{
				panel2.Visible = false;
			}
		}

		private void radioButton4_CheckedChanged(object sender, EventArgs e)
		{
			if (radioButton5.Checked)
			{
				panel3.Visible = true;
			}
			else if (!radioButton5.Checked)
			{
				panel3.Visible = false;
			}
			if (radioButton1.Checked)
			{
				panel2.Visible = true;
			}
			else if (!radioButton1.Checked)
			{
				panel2.Visible = false;
			}
		}

		private void birthDateDateTimePicker_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				floatText2.TextChanged -= floatText2_TextChanged;
				DateTime.Today.Subtract(birthDateDateTimePicker.Value);
				int day = DateTime.Now.Day;
				int month = DateTime.Now.Month;
				int year = DateTime.Now.Year;
				int day2 = birthDateDateTimePicker.Value.Day;
				int month2 = birthDateDateTimePicker.Value.Month;
				int year2 = birthDateDateTimePicker.Value.Year;
				if (month * 100 + day >= month2 * 100 + day2)
				{
					floatText2.Text = (year - year2).ToString();
				}
				else
				{
					floatText2.Text = (year - year2 - 1).ToString();
				}
				floatText2.TextChanged += floatText2_TextChanged;
			}
			catch
			{
			}
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (keyData == Keys.Escape)
			{
				try
				{
					LightSteelBlue.SelectedTab = LightSteelBlue.TabPages[LightSteelBlue.SelectedIndex + 1];
				}
				catch
				{
					LightSteelBlue.SelectedTab = LightSteelBlue.TabPages[0];
				}
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}

		private void LightSteelBlue_KeyDown(object sender, KeyEventArgs e)
		{
		}

		private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
		{
			char keyChar = e.KeyChar;
			if (!char.IsDigit(keyChar) && keyChar != '\b')
			{
				e.Handled = true;
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Numbers Only");
				}
				else
				{
					MessageBox.Show("أرقام فقط");
				}
			}
		}

		private void button11_Click(object sender, EventArgs e)
		{
			FrmNationality frmNationality = new FrmNationality();
			frmNationality.ShowDialog();
			try
			{
				DataTable tableText = dc.GetTableText("select * from Nationality");
				gui.loadComboBox(nationalityTextBox, tableText);
				nationalityTextBox.SelectedItem = nationalityTextBox.Items[0];
			}
			catch
			{
			}
		}

		private void button12_Click(object sender, EventArgs e)
		{
			FrmCity frmCity = new FrmCity();
			frmCity.ShowDialog();
			try
			{
				DataTable tableText = dc.GetTableText("select * from City");
				gui.loadComboBox(cityTextBox, tableText);
				cityTextBox.SelectedItem = cityTextBox.Items[0];
			}
			catch
			{
			}
		}

		private void checkedListBox2_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

		private void textBox4_TextChanged(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.PationtInfo));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			this.label49 = new System.Windows.Forms.Label();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			No = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Period = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Way = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Place = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Result = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Baby = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Mother = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Notes = new System.Windows.Forms.DataGridViewTextBoxColumn();
			titelComboBox = new System.Windows.Forms.ComboBox();
			nameTextBox = new System.Windows.Forms.TextBox();
			telTextBox = new System.Windows.Forms.TextBox();
			mobTextBox = new System.Windows.Forms.TextBox();
			emailTextBox = new System.Windows.Forms.TextBox();
			birthDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
			sexComboBox = new System.Windows.Forms.ComboBox();
			cardNumTextBox = new System.Windows.Forms.TextBox();
			lastVistDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
			allergiesCheckBox = new System.Windows.Forms.CheckBox();
			cardiacDiseaseCheckBox = new System.Windows.Forms.CheckBox();
			kidneyDeseaseCheckBox = new System.Windows.Forms.CheckBox();
			diabetesCheckBox = new System.Windows.Forms.CheckBox();
			rheumaticFeverCheckBox = new System.Windows.Forms.CheckBox();
			asthmaCheckBox = new System.Windows.Forms.CheckBox();
			bloodDyscrasiasCheckBox = new System.Windows.Forms.CheckBox();
			historyOtherTextBox = new System.Windows.Forms.TextBox();
			extractionCheckBox = new System.Windows.Forms.CheckBox();
			drugSensitivityCheckBox = new System.Windows.Forms.CheckBox();
			pulpTherapyCheckBox = new System.Windows.Forms.CheckBox();
			periodontalTherpyCheckBox = new System.Windows.Forms.CheckBox();
			flourideTherapyCheckBox = new System.Windows.Forms.CheckBox();
			prviousHistoryOthersTextBox = new System.Windows.Forms.TextBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			HepatitisCcheckBox = new System.Windows.Forms.CheckBox();
			PregnantcheckBox = new System.Windows.Forms.CheckBox();
			HepatitisBcheckBox = new System.Windows.Forms.CheckBox();
			lactatingcheckBox = new System.Windows.Forms.CheckBox();
			groupBox3 = new System.Windows.Forms.GroupBox();
			OpretivecheckBox = new System.Windows.Forms.CheckBox();
			BleachingcheckBox = new System.Windows.Forms.CheckBox();
			CommentPanel = new System.Windows.Forms.Panel();
			AddComment = new System.Windows.Forms.Button();
			groupBox4 = new System.Windows.Forms.GroupBox();
			button12 = new System.Windows.Forms.Button();
			button11 = new System.Windows.Forms.Button();
			checkBox12 = new System.Windows.Forms.CheckBox();
			nationalID = new System.Windows.Forms.TextBox();
			panel3 = new System.Windows.Forms.Panel();
			comboBox13 = new System.Windows.Forms.ComboBox();
			radioButton5 = new System.Windows.Forms.RadioButton();
			radioButton4 = new System.Windows.Forms.RadioButton();
			cityTextBox = new System.Windows.Forms.ComboBox();
			nationalityTextBox = new System.Windows.Forms.ComboBox();
			addressTextBox = new System.Windows.Forms.ComboBox();
			floatText2 = new FloatTextBox.FloatText();
			panel2 = new System.Windows.Forms.Panel();
			floatText1 = new FloatTextBox.FloatText();
			PatientComboBox = new System.Windows.Forms.ComboBox();
			IDtextBox = new System.Windows.Forms.TextBox();
			DentalLogoBtn = new System.Windows.Forms.Button();
			groupBox7 = new System.Windows.Forms.GroupBox();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			radioButton3 = new System.Windows.Forms.RadioButton();
			radioButton2 = new System.Windows.Forms.RadioButton();
			radioButton1 = new System.Windows.Forms.RadioButton();
			txtFileNo = new System.Windows.Forms.TextBox();
			checkBox11 = new System.Windows.Forms.CheckBox();
			txtBloodType = new System.Windows.Forms.TextBox();
			DoctorcomboBox = new System.Windows.Forms.ComboBox();
			button1 = new System.Windows.Forms.Button();
			companycomboBox = new System.Windows.Forms.ComboBox();
			statueComboBox = new System.Windows.Forms.ComboBox();
			saveBtn = new System.Windows.Forms.Button();
			EditBtn = new System.Windows.Forms.Button();
			groupBox5 = new System.Windows.Forms.GroupBox();
			panel1 = new System.Windows.Forms.Panel();
			button6 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			button5 = new System.Windows.Forms.Button();
			button4 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			checkBox1 = new System.Windows.Forms.CheckBox();
			groupBox6 = new System.Windows.Forms.GroupBox();
			this.label2 = new System.Windows.Forms.Label();
			flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			groupBox8 = new System.Windows.Forms.GroupBox();
			checkedListBox2 = new System.Windows.Forms.CheckedListBox();
			groupBox1 = new System.Windows.Forms.GroupBox();
			checkedListBox1 = new System.Windows.Forms.CheckedListBox();
			button7 = new System.Windows.Forms.Button();
			button8 = new System.Windows.Forms.Button();
			LightSteelBlue = new System.Windows.Forms.TabControl();
			tabPage1 = new System.Windows.Forms.TabPage();
			groupBox11 = new System.Windows.Forms.GroupBox();
			checkedListBox3 = new System.Windows.Forms.CheckedListBox();
			button10 = new System.Windows.Forms.Button();
			tabPage2 = new System.Windows.Forms.TabPage();
			groupBox9 = new System.Windows.Forms.GroupBox();
			comboBox12 = new System.Windows.Forms.ComboBox();
			comboBox5 = new System.Windows.Forms.ComboBox();
			dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			comboBox4 = new System.Windows.Forms.ComboBox();
			comboBox3 = new System.Windows.Forms.ComboBox();
			comboBox2 = new System.Windows.Forms.ComboBox();
			checkBox10 = new System.Windows.Forms.CheckBox();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			numericUpDown12 = new System.Windows.Forms.NumericUpDown();
			checkBox9 = new System.Windows.Forms.CheckBox();
			numericUpDown11 = new System.Windows.Forms.NumericUpDown();
			comboBox1 = new System.Windows.Forms.ComboBox();
			numericUpDown10 = new System.Windows.Forms.NumericUpDown();
			numericUpDown9 = new System.Windows.Forms.NumericUpDown();
			numericUpDown8 = new System.Windows.Forms.NumericUpDown();
			numericUpDown7 = new System.Windows.Forms.NumericUpDown();
			numericUpDown6 = new System.Windows.Forms.NumericUpDown();
			numericUpDown5 = new System.Windows.Forms.NumericUpDown();
			numericUpDown4 = new System.Windows.Forms.NumericUpDown();
			numericUpDown3 = new System.Windows.Forms.NumericUpDown();
			checkBox8 = new System.Windows.Forms.CheckBox();
			checkBox6 = new System.Windows.Forms.CheckBox();
			checkBox7 = new System.Windows.Forms.CheckBox();
			textBox4 = new System.Windows.Forms.TextBox();
			checkBox5 = new System.Windows.Forms.CheckBox();
			checkBox4 = new System.Windows.Forms.CheckBox();
			checkBox3 = new System.Windows.Forms.CheckBox();
			numericUpDown2 = new System.Windows.Forms.NumericUpDown();
			numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			checkBox2 = new System.Windows.Forms.CheckBox();
			textBox1 = new System.Windows.Forms.TextBox();
			tabPage3 = new System.Windows.Forms.TabPage();
			groupBox10 = new System.Windows.Forms.GroupBox();
			numericUpDown14 = new System.Windows.Forms.NumericUpDown();
			button9 = new System.Windows.Forms.Button();
			comboBox10 = new System.Windows.Forms.ComboBox();
			comboBox11 = new System.Windows.Forms.ComboBox();
			comboBox9 = new System.Windows.Forms.ComboBox();
			comboBox8 = new System.Windows.Forms.ComboBox();
			comboBox6 = new System.Windows.Forms.ComboBox();
			comboBox7 = new System.Windows.Forms.ComboBox();
			numericUpDown13 = new System.Windows.Forms.NumericUpDown();
			this.label28 = new System.Windows.Forms.Label();
			this.label27 = new System.Windows.Forms.Label();
			tabPage4 = new System.Windows.Forms.TabPage();
			groupBox12 = new System.Windows.Forms.GroupBox();
			textBox5 = new System.Windows.Forms.TextBox();
			this.label36 = new System.Windows.Forms.Label();
			textBox3 = new System.Windows.Forms.TextBox();
			textBox2 = new System.Windows.Forms.TextBox();
			this.label47 = new System.Windows.Forms.Label();
			numericUpDown18 = new System.Windows.Forms.NumericUpDown();
			this.label44 = new System.Windows.Forms.Label();
			numericUpDown17 = new System.Windows.Forms.NumericUpDown();
			this.label40 = new System.Windows.Forms.Label();
			this.label43 = new System.Windows.Forms.Label();
			numericUpDown15 = new System.Windows.Forms.NumericUpDown();
			comboBox16 = new System.Windows.Forms.ComboBox();
			comboBox17 = new System.Windows.Forms.ComboBox();
			numericUpDown16 = new System.Windows.Forms.NumericUpDown();
			this.label41 = new System.Windows.Forms.Label();
			this.label42 = new System.Windows.Forms.Label();
			tabPage9 = new System.Windows.Forms.TabPage();
			groupBox35 = new System.Windows.Forms.GroupBox();
			label203 = new System.Windows.Forms.Label();
			label204 = new System.Windows.Forms.Label();
			FatsRate = new System.Windows.Forms.NumericUpDown();
			label199 = new System.Windows.Forms.Label();
			label202 = new System.Windows.Forms.Label();
			MusclesRate = new System.Windows.Forms.NumericUpDown();
			label197 = new System.Windows.Forms.Label();
			label198 = new System.Windows.Forms.Label();
			hieght = new System.Windows.Forms.NumericUpDown();
			label196 = new System.Windows.Forms.Label();
			Medicin = new System.Windows.Forms.TextBox();
			label195 = new System.Windows.Forms.Label();
			MedicalStatus = new System.Windows.Forms.TextBox();
			label193 = new System.Windows.Forms.Label();
			label194 = new System.Windows.Forms.Label();
			wieght = new System.Windows.Forms.NumericUpDown();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			tabPage5 = new System.Windows.Forms.TabPage();
			groupBox13 = new System.Windows.Forms.GroupBox();
			checkedListBox4 = new System.Windows.Forms.CheckedListBox();
			button13 = new System.Windows.Forms.Button();
			groupBox14 = new System.Windows.Forms.GroupBox();
			this.label55 = new System.Windows.Forms.Label();
			groupBox15 = new System.Windows.Forms.GroupBox();
			button14 = new System.Windows.Forms.Button();
			button15 = new System.Windows.Forms.Button();
			checkBox13 = new System.Windows.Forms.CheckBox();
			textBox6 = new System.Windows.Forms.TextBox();
			panel4 = new System.Windows.Forms.Panel();
			comboBox14 = new System.Windows.Forms.ComboBox();
			radioButton6 = new System.Windows.Forms.RadioButton();
			radioButton7 = new System.Windows.Forms.RadioButton();
			comboBox15 = new System.Windows.Forms.ComboBox();
			comboBox18 = new System.Windows.Forms.ComboBox();
			comboBox19 = new System.Windows.Forms.ComboBox();
			floatText3 = new FloatTextBox.FloatText();
			panel5 = new System.Windows.Forms.Panel();
			floatText4 = new FloatTextBox.FloatText();
			this.label61 = new System.Windows.Forms.Label();
			comboBox20 = new System.Windows.Forms.ComboBox();
			textBox7 = new System.Windows.Forms.TextBox();
			button16 = new System.Windows.Forms.Button();
			groupBox16 = new System.Windows.Forms.GroupBox();
			pictureBox2 = new System.Windows.Forms.PictureBox();
			radioButton8 = new System.Windows.Forms.RadioButton();
			radioButton9 = new System.Windows.Forms.RadioButton();
			radioButton10 = new System.Windows.Forms.RadioButton();
			textBox8 = new System.Windows.Forms.TextBox();
			checkBox14 = new System.Windows.Forms.CheckBox();
			textBox9 = new System.Windows.Forms.TextBox();
			comboBox21 = new System.Windows.Forms.ComboBox();
			button17 = new System.Windows.Forms.Button();
			comboBox22 = new System.Windows.Forms.ComboBox();
			comboBox23 = new System.Windows.Forms.ComboBox();
			dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
			textBox10 = new System.Windows.Forms.TextBox();
			comboBox24 = new System.Windows.Forms.ComboBox();
			textBox11 = new System.Windows.Forms.TextBox();
			comboBox25 = new System.Windows.Forms.ComboBox();
			textBox12 = new System.Windows.Forms.TextBox();
			dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
			textBox13 = new System.Windows.Forms.TextBox();
			textBox14 = new System.Windows.Forms.TextBox();
			button18 = new System.Windows.Forms.Button();
			button19 = new System.Windows.Forms.Button();
			groupBox17 = new System.Windows.Forms.GroupBox();
			checkedListBox5 = new System.Windows.Forms.CheckedListBox();
			groupBox18 = new System.Windows.Forms.GroupBox();
			checkBox15 = new System.Windows.Forms.CheckBox();
			checkBox16 = new System.Windows.Forms.CheckBox();
			checkBox17 = new System.Windows.Forms.CheckBox();
			checkBox18 = new System.Windows.Forms.CheckBox();
			textBox15 = new System.Windows.Forms.TextBox();
			checkBox19 = new System.Windows.Forms.CheckBox();
			checkBox20 = new System.Windows.Forms.CheckBox();
			checkBox21 = new System.Windows.Forms.CheckBox();
			checkBox22 = new System.Windows.Forms.CheckBox();
			checkBox23 = new System.Windows.Forms.CheckBox();
			checkBox24 = new System.Windows.Forms.CheckBox();
			checkBox25 = new System.Windows.Forms.CheckBox();
			groupBox19 = new System.Windows.Forms.GroupBox();
			checkedListBox6 = new System.Windows.Forms.CheckedListBox();
			groupBox20 = new System.Windows.Forms.GroupBox();
			checkBox26 = new System.Windows.Forms.CheckBox();
			checkBox27 = new System.Windows.Forms.CheckBox();
			textBox16 = new System.Windows.Forms.TextBox();
			checkBox28 = new System.Windows.Forms.CheckBox();
			checkBox29 = new System.Windows.Forms.CheckBox();
			checkBox30 = new System.Windows.Forms.CheckBox();
			checkBox31 = new System.Windows.Forms.CheckBox();
			checkBox32 = new System.Windows.Forms.CheckBox();
			tabPage6 = new System.Windows.Forms.TabPage();
			groupBox21 = new System.Windows.Forms.GroupBox();
			comboBox26 = new System.Windows.Forms.ComboBox();
			comboBox27 = new System.Windows.Forms.ComboBox();
			dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
			comboBox28 = new System.Windows.Forms.ComboBox();
			comboBox29 = new System.Windows.Forms.ComboBox();
			comboBox30 = new System.Windows.Forms.ComboBox();
			checkBox33 = new System.Windows.Forms.CheckBox();
			dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
			numericUpDown19 = new System.Windows.Forms.NumericUpDown();
			checkBox34 = new System.Windows.Forms.CheckBox();
			numericUpDown20 = new System.Windows.Forms.NumericUpDown();
			comboBox31 = new System.Windows.Forms.ComboBox();
			numericUpDown21 = new System.Windows.Forms.NumericUpDown();
			numericUpDown22 = new System.Windows.Forms.NumericUpDown();
			numericUpDown23 = new System.Windows.Forms.NumericUpDown();
			numericUpDown24 = new System.Windows.Forms.NumericUpDown();
			numericUpDown25 = new System.Windows.Forms.NumericUpDown();
			numericUpDown26 = new System.Windows.Forms.NumericUpDown();
			numericUpDown27 = new System.Windows.Forms.NumericUpDown();
			numericUpDown28 = new System.Windows.Forms.NumericUpDown();
			checkBox35 = new System.Windows.Forms.CheckBox();
			checkBox36 = new System.Windows.Forms.CheckBox();
			checkBox37 = new System.Windows.Forms.CheckBox();
			textBox17 = new System.Windows.Forms.TextBox();
			checkBox38 = new System.Windows.Forms.CheckBox();
			checkBox39 = new System.Windows.Forms.CheckBox();
			checkBox40 = new System.Windows.Forms.CheckBox();
			numericUpDown29 = new System.Windows.Forms.NumericUpDown();
			numericUpDown30 = new System.Windows.Forms.NumericUpDown();
			checkBox41 = new System.Windows.Forms.CheckBox();
			textBox18 = new System.Windows.Forms.TextBox();
			tabPage7 = new System.Windows.Forms.TabPage();
			groupBox22 = new System.Windows.Forms.GroupBox();
			numericUpDown31 = new System.Windows.Forms.NumericUpDown();
			button20 = new System.Windows.Forms.Button();
			comboBox32 = new System.Windows.Forms.ComboBox();
			comboBox33 = new System.Windows.Forms.ComboBox();
			comboBox34 = new System.Windows.Forms.ComboBox();
			comboBox35 = new System.Windows.Forms.ComboBox();
			comboBox36 = new System.Windows.Forms.ComboBox();
			comboBox37 = new System.Windows.Forms.ComboBox();
			numericUpDown32 = new System.Windows.Forms.NumericUpDown();
			this.label110 = new System.Windows.Forms.Label();
			this.label111 = new System.Windows.Forms.Label();
			dataGridView2 = new System.Windows.Forms.DataGridView();
			dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			tabPage8 = new System.Windows.Forms.TabPage();
			groupBox23 = new System.Windows.Forms.GroupBox();
			textBox19 = new System.Windows.Forms.TextBox();
			this.label112 = new System.Windows.Forms.Label();
			textBox20 = new System.Windows.Forms.TextBox();
			textBox21 = new System.Windows.Forms.TextBox();
			this.label113 = new System.Windows.Forms.Label();
			numericUpDown33 = new System.Windows.Forms.NumericUpDown();
			this.label116 = new System.Windows.Forms.Label();
			numericUpDown34 = new System.Windows.Forms.NumericUpDown();
			this.label117 = new System.Windows.Forms.Label();
			this.label118 = new System.Windows.Forms.Label();
			numericUpDown35 = new System.Windows.Forms.NumericUpDown();
			comboBox38 = new System.Windows.Forms.ComboBox();
			comboBox39 = new System.Windows.Forms.ComboBox();
			numericUpDown36 = new System.Windows.Forms.NumericUpDown();
			this.label122 = new System.Windows.Forms.Label();
			this.label123 = new System.Windows.Forms.Label();
			tabPage10 = new System.Windows.Forms.TabPage();
			groupBox24 = new System.Windows.Forms.GroupBox();
			checkedListBox7 = new System.Windows.Forms.CheckedListBox();
			button21 = new System.Windows.Forms.Button();
			groupBox25 = new System.Windows.Forms.GroupBox();
			this.label124 = new System.Windows.Forms.Label();
			groupBox26 = new System.Windows.Forms.GroupBox();
			button22 = new System.Windows.Forms.Button();
			button23 = new System.Windows.Forms.Button();
			checkBox42 = new System.Windows.Forms.CheckBox();
			textBox22 = new System.Windows.Forms.TextBox();
			panel6 = new System.Windows.Forms.Panel();
			comboBox40 = new System.Windows.Forms.ComboBox();
			radioButton11 = new System.Windows.Forms.RadioButton();
			radioButton12 = new System.Windows.Forms.RadioButton();
			comboBox41 = new System.Windows.Forms.ComboBox();
			comboBox42 = new System.Windows.Forms.ComboBox();
			comboBox43 = new System.Windows.Forms.ComboBox();
			floatText5 = new FloatTextBox.FloatText();
			panel7 = new System.Windows.Forms.Panel();
			floatText6 = new FloatTextBox.FloatText();
			this.label130 = new System.Windows.Forms.Label();
			comboBox44 = new System.Windows.Forms.ComboBox();
			textBox23 = new System.Windows.Forms.TextBox();
			button24 = new System.Windows.Forms.Button();
			groupBox27 = new System.Windows.Forms.GroupBox();
			pictureBox3 = new System.Windows.Forms.PictureBox();
			radioButton13 = new System.Windows.Forms.RadioButton();
			radioButton14 = new System.Windows.Forms.RadioButton();
			radioButton15 = new System.Windows.Forms.RadioButton();
			textBox24 = new System.Windows.Forms.TextBox();
			checkBox43 = new System.Windows.Forms.CheckBox();
			textBox25 = new System.Windows.Forms.TextBox();
			comboBox45 = new System.Windows.Forms.ComboBox();
			button25 = new System.Windows.Forms.Button();
			comboBox46 = new System.Windows.Forms.ComboBox();
			comboBox47 = new System.Windows.Forms.ComboBox();
			dateTimePicker7 = new System.Windows.Forms.DateTimePicker();
			textBox26 = new System.Windows.Forms.TextBox();
			comboBox48 = new System.Windows.Forms.ComboBox();
			textBox27 = new System.Windows.Forms.TextBox();
			comboBox49 = new System.Windows.Forms.ComboBox();
			textBox28 = new System.Windows.Forms.TextBox();
			dateTimePicker8 = new System.Windows.Forms.DateTimePicker();
			textBox29 = new System.Windows.Forms.TextBox();
			textBox30 = new System.Windows.Forms.TextBox();
			button26 = new System.Windows.Forms.Button();
			button27 = new System.Windows.Forms.Button();
			groupBox28 = new System.Windows.Forms.GroupBox();
			checkedListBox8 = new System.Windows.Forms.CheckedListBox();
			groupBox29 = new System.Windows.Forms.GroupBox();
			checkBox44 = new System.Windows.Forms.CheckBox();
			checkBox45 = new System.Windows.Forms.CheckBox();
			checkBox46 = new System.Windows.Forms.CheckBox();
			checkBox47 = new System.Windows.Forms.CheckBox();
			textBox31 = new System.Windows.Forms.TextBox();
			checkBox48 = new System.Windows.Forms.CheckBox();
			checkBox49 = new System.Windows.Forms.CheckBox();
			checkBox50 = new System.Windows.Forms.CheckBox();
			checkBox51 = new System.Windows.Forms.CheckBox();
			checkBox52 = new System.Windows.Forms.CheckBox();
			checkBox53 = new System.Windows.Forms.CheckBox();
			checkBox54 = new System.Windows.Forms.CheckBox();
			groupBox30 = new System.Windows.Forms.GroupBox();
			checkedListBox9 = new System.Windows.Forms.CheckedListBox();
			groupBox31 = new System.Windows.Forms.GroupBox();
			checkBox55 = new System.Windows.Forms.CheckBox();
			checkBox56 = new System.Windows.Forms.CheckBox();
			textBox32 = new System.Windows.Forms.TextBox();
			checkBox57 = new System.Windows.Forms.CheckBox();
			checkBox58 = new System.Windows.Forms.CheckBox();
			checkBox59 = new System.Windows.Forms.CheckBox();
			checkBox60 = new System.Windows.Forms.CheckBox();
			checkBox61 = new System.Windows.Forms.CheckBox();
			tabPage11 = new System.Windows.Forms.TabPage();
			groupBox32 = new System.Windows.Forms.GroupBox();
			comboBox50 = new System.Windows.Forms.ComboBox();
			comboBox51 = new System.Windows.Forms.ComboBox();
			dateTimePicker9 = new System.Windows.Forms.DateTimePicker();
			comboBox52 = new System.Windows.Forms.ComboBox();
			comboBox53 = new System.Windows.Forms.ComboBox();
			comboBox54 = new System.Windows.Forms.ComboBox();
			checkBox62 = new System.Windows.Forms.CheckBox();
			dateTimePicker10 = new System.Windows.Forms.DateTimePicker();
			numericUpDown37 = new System.Windows.Forms.NumericUpDown();
			checkBox63 = new System.Windows.Forms.CheckBox();
			numericUpDown38 = new System.Windows.Forms.NumericUpDown();
			comboBox55 = new System.Windows.Forms.ComboBox();
			numericUpDown39 = new System.Windows.Forms.NumericUpDown();
			numericUpDown40 = new System.Windows.Forms.NumericUpDown();
			numericUpDown41 = new System.Windows.Forms.NumericUpDown();
			numericUpDown42 = new System.Windows.Forms.NumericUpDown();
			numericUpDown43 = new System.Windows.Forms.NumericUpDown();
			numericUpDown44 = new System.Windows.Forms.NumericUpDown();
			numericUpDown45 = new System.Windows.Forms.NumericUpDown();
			numericUpDown46 = new System.Windows.Forms.NumericUpDown();
			checkBox64 = new System.Windows.Forms.CheckBox();
			checkBox65 = new System.Windows.Forms.CheckBox();
			checkBox66 = new System.Windows.Forms.CheckBox();
			textBox33 = new System.Windows.Forms.TextBox();
			checkBox67 = new System.Windows.Forms.CheckBox();
			checkBox68 = new System.Windows.Forms.CheckBox();
			checkBox69 = new System.Windows.Forms.CheckBox();
			numericUpDown47 = new System.Windows.Forms.NumericUpDown();
			numericUpDown48 = new System.Windows.Forms.NumericUpDown();
			checkBox70 = new System.Windows.Forms.CheckBox();
			textBox34 = new System.Windows.Forms.TextBox();
			tabPage12 = new System.Windows.Forms.TabPage();
			groupBox33 = new System.Windows.Forms.GroupBox();
			numericUpDown49 = new System.Windows.Forms.NumericUpDown();
			button28 = new System.Windows.Forms.Button();
			comboBox56 = new System.Windows.Forms.ComboBox();
			comboBox57 = new System.Windows.Forms.ComboBox();
			comboBox58 = new System.Windows.Forms.ComboBox();
			comboBox59 = new System.Windows.Forms.ComboBox();
			comboBox60 = new System.Windows.Forms.ComboBox();
			comboBox61 = new System.Windows.Forms.ComboBox();
			numericUpDown50 = new System.Windows.Forms.NumericUpDown();
			label179 = new System.Windows.Forms.Label();
			label180 = new System.Windows.Forms.Label();
			dataGridView3 = new System.Windows.Forms.DataGridView();
			dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			tabPage13 = new System.Windows.Forms.TabPage();
			groupBox34 = new System.Windows.Forms.GroupBox();
			textBox35 = new System.Windows.Forms.TextBox();
			label181 = new System.Windows.Forms.Label();
			textBox36 = new System.Windows.Forms.TextBox();
			textBox37 = new System.Windows.Forms.TextBox();
			label182 = new System.Windows.Forms.Label();
			numericUpDown51 = new System.Windows.Forms.NumericUpDown();
			label185 = new System.Windows.Forms.Label();
			numericUpDown52 = new System.Windows.Forms.NumericUpDown();
			label186 = new System.Windows.Forms.Label();
			label187 = new System.Windows.Forms.Label();
			numericUpDown53 = new System.Windows.Forms.NumericUpDown();
			comboBox62 = new System.Windows.Forms.ComboBox();
			comboBox63 = new System.Windows.Forms.ComboBox();
			numericUpDown54 = new System.Windows.Forms.NumericUpDown();
			label191 = new System.Windows.Forms.Label();
			label192 = new System.Windows.Forms.Label();
			tabPage14 = new System.Windows.Forms.TabPage();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label7 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label8 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label9 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label10 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label11 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label12 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label13 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label14 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label15 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label16 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label17 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label18 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label19 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label20 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label21 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label22 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label23 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label24 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label25 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label26 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label27 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label28 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label29 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label30 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label31 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label32 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label33 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label34 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label35 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label36 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label37 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label38 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label39 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label40 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label41 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label42 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label43 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label44 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label45 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label46 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label47 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label48 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label49 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label50 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label51 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label52 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label53 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label54 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label55 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label56 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label57 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label58 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label59 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label60 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label61 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label62 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label63 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label64 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label65 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label66 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label67 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label68 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label69 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label70 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label71 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label72 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label73 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label74 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label75 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label76 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label77 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label78 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label79 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label80 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label81 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label82 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label83 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label84 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label85 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label86 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label87 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label88 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label89 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label90 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label91 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label92 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label93 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label94 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label95 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label96 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label97 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label98 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label99 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label100 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label101 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label102 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label103 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label104 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label105 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label106 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label107 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label108 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label109 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label110 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label111 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label112 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label113 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label114 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label115 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label116 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label117 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label118 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label119 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label120 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label121 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label122 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label123 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label124 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label125 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label126 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label127 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label128 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label129 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label130 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label131 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label132 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label133 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label134 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label135 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label136 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label137 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label138 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label139 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label140 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label141 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label142 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label143 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label144 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label145 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label146 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label147 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label148 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label149 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label150 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label151 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label152 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label153 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label154 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label155 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label156 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label157 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label158 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label159 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label160 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label161 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label162 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label163 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label164 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label165 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label166 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label167 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label168 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label169 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label170 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label171 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label172 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label173 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label174 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox2.SuspendLayout();
			groupBox3.SuspendLayout();
			CommentPanel.SuspendLayout();
			groupBox4.SuspendLayout();
			panel3.SuspendLayout();
			panel2.SuspendLayout();
			groupBox7.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			groupBox5.SuspendLayout();
			panel1.SuspendLayout();
			groupBox6.SuspendLayout();
			groupBox8.SuspendLayout();
			groupBox1.SuspendLayout();
			LightSteelBlue.SuspendLayout();
			tabPage1.SuspendLayout();
			groupBox11.SuspendLayout();
			tabPage2.SuspendLayout();
			groupBox9.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown12).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown11).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown10).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown9).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown8).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown7).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown6).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown5).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown4).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown3).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
			tabPage3.SuspendLayout();
			groupBox10.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown14).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown13).BeginInit();
			tabPage4.SuspendLayout();
			groupBox12.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown18).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown17).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown15).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown16).BeginInit();
			tabPage9.SuspendLayout();
			groupBox35.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)FatsRate).BeginInit();
			((System.ComponentModel.ISupportInitialize)MusclesRate).BeginInit();
			((System.ComponentModel.ISupportInitialize)hieght).BeginInit();
			((System.ComponentModel.ISupportInitialize)wieght).BeginInit();
			tabPage5.SuspendLayout();
			groupBox13.SuspendLayout();
			groupBox14.SuspendLayout();
			groupBox15.SuspendLayout();
			panel4.SuspendLayout();
			panel5.SuspendLayout();
			groupBox16.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
			groupBox17.SuspendLayout();
			groupBox18.SuspendLayout();
			groupBox19.SuspendLayout();
			groupBox20.SuspendLayout();
			tabPage6.SuspendLayout();
			groupBox21.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown19).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown20).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown21).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown22).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown23).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown24).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown25).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown26).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown27).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown28).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown29).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown30).BeginInit();
			tabPage7.SuspendLayout();
			groupBox22.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown31).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown32).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
			tabPage8.SuspendLayout();
			groupBox23.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown33).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown34).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown35).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown36).BeginInit();
			tabPage10.SuspendLayout();
			groupBox24.SuspendLayout();
			groupBox25.SuspendLayout();
			groupBox26.SuspendLayout();
			panel6.SuspendLayout();
			panel7.SuspendLayout();
			groupBox27.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
			groupBox28.SuspendLayout();
			groupBox29.SuspendLayout();
			groupBox30.SuspendLayout();
			groupBox31.SuspendLayout();
			tabPage11.SuspendLayout();
			groupBox32.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown37).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown38).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown39).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown40).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown41).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown42).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown43).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown44).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown45).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown46).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown47).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown48).BeginInit();
			tabPage12.SuspendLayout();
			groupBox33.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown49).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown50).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
			tabPage13.SuspendLayout();
			groupBox34.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown51).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown52).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown53).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown54).BeginInit();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "titelLabel");
			label.Name = "titelLabel";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "nameLabel");
			label2.Name = "nameLabel";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "addressLabel");
			label3.Name = "addressLabel";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "cityLabel");
			label4.Name = "cityLabel";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "telLabel");
			label5.Name = "telLabel";
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "mobLabel");
			label6.Name = "mobLabel";
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "emailLabel");
			label7.Name = "emailLabel";
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "birthDateLabel");
			label8.Name = "birthDateLabel";
			label9.AccessibleDescription = null;
			label9.AccessibleName = null;
			resources.ApplyResources(label9, "sexLabel");
			label9.Name = "sexLabel";
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "nationalityLabel");
			label10.Name = "nationalityLabel";
			label11.AccessibleDescription = null;
			label11.AccessibleName = null;
			resources.ApplyResources(label11, "statueLabel");
			label11.Name = "statueLabel";
			label12.AccessibleDescription = null;
			label12.AccessibleName = null;
			resources.ApplyResources(label12, "companyLabel");
			label12.Name = "companyLabel";
			label13.AccessibleDescription = null;
			label13.AccessibleName = null;
			resources.ApplyResources(label13, "cardNumLabel");
			label13.Name = "cardNumLabel";
			label14.AccessibleDescription = null;
			label14.AccessibleName = null;
			resources.ApplyResources(label14, "lastVistDateLabel");
			label14.Name = "lastVistDateLabel";
			label15.AccessibleDescription = null;
			label15.AccessibleName = null;
			resources.ApplyResources(label15, "historyOtherLabel");
			label15.Name = "historyOtherLabel";
			label16.AccessibleDescription = null;
			label16.AccessibleName = null;
			resources.ApplyResources(label16, "label1");
			label16.ForeColor = System.Drawing.Color.Firebrick;
			label16.Name = "label1";
			label17.AccessibleDescription = null;
			label17.AccessibleName = null;
			resources.ApplyResources(label17, "label3");
			label17.Name = "label3";
			label18.AccessibleDescription = null;
			label18.AccessibleName = null;
			resources.ApplyResources(label18, "label4");
			label18.Name = "label4";
			label19.AccessibleDescription = null;
			label19.AccessibleName = null;
			resources.ApplyResources(label19, "label5");
			label19.Name = "label5";
			label20.AccessibleDescription = null;
			label20.AccessibleName = null;
			resources.ApplyResources(label20, "label6");
			label20.Name = "label6";
			label21.AccessibleDescription = null;
			label21.AccessibleName = null;
			resources.ApplyResources(label21, "label7");
			label21.Name = "label7";
			label22.AccessibleDescription = null;
			label22.AccessibleName = null;
			resources.ApplyResources(label22, "label8");
			label22.Name = "label8";
			label23.AccessibleDescription = null;
			label23.AccessibleName = null;
			resources.ApplyResources(label23, "label9");
			label23.Name = "label9";
			label24.AccessibleDescription = null;
			label24.AccessibleName = null;
			resources.ApplyResources(label24, "label10");
			label24.Name = "label10";
			label25.AccessibleDescription = null;
			label25.AccessibleName = null;
			resources.ApplyResources(label25, "label11");
			label25.Name = "label11";
			label26.AccessibleDescription = null;
			label26.AccessibleName = null;
			resources.ApplyResources(label26, "label12");
			label26.Name = "label12";
			label27.AccessibleDescription = null;
			label27.AccessibleName = null;
			resources.ApplyResources(label27, "label13");
			label27.Name = "label13";
			label28.AccessibleDescription = null;
			label28.AccessibleName = null;
			resources.ApplyResources(label28, "label14");
			label28.Name = "label14";
			label29.AccessibleDescription = null;
			label29.AccessibleName = null;
			resources.ApplyResources(label29, "label15");
			label29.Name = "label15";
			label30.AccessibleDescription = null;
			label30.AccessibleName = null;
			resources.ApplyResources(label30, "label16");
			label30.Name = "label16";
			label31.AccessibleDescription = null;
			label31.AccessibleName = null;
			resources.ApplyResources(label31, "label17");
			label31.Name = "label17";
			label32.AccessibleDescription = null;
			label32.AccessibleName = null;
			resources.ApplyResources(label32, "label18");
			label32.Name = "label18";
			label33.AccessibleDescription = null;
			label33.AccessibleName = null;
			resources.ApplyResources(label33, "label19");
			label33.Name = "label19";
			label34.AccessibleDescription = null;
			label34.AccessibleName = null;
			resources.ApplyResources(label34, "label20");
			label34.Name = "label20";
			label35.AccessibleDescription = null;
			label35.AccessibleName = null;
			resources.ApplyResources(label35, "label21");
			label35.Name = "label21";
			label36.AccessibleDescription = null;
			label36.AccessibleName = null;
			resources.ApplyResources(label36, "label22");
			label36.Name = "label22";
			label37.AccessibleDescription = null;
			label37.AccessibleName = null;
			resources.ApplyResources(label37, "label23");
			label37.Name = "label23";
			label38.AccessibleDescription = null;
			label38.AccessibleName = null;
			resources.ApplyResources(label38, "label24");
			label38.Name = "label24";
			label39.AccessibleDescription = null;
			label39.AccessibleName = null;
			resources.ApplyResources(label39, "label25");
			label39.Name = "label25";
			label40.AccessibleDescription = null;
			label40.AccessibleName = null;
			resources.ApplyResources(label40, "label26");
			label40.Name = "label26";
			label41.AccessibleDescription = null;
			label41.AccessibleName = null;
			resources.ApplyResources(label41, "label29");
			label41.Name = "label29";
			label42.AccessibleDescription = null;
			label42.AccessibleName = null;
			resources.ApplyResources(label42, "label30");
			label42.Name = "label30";
			label43.AccessibleDescription = null;
			label43.AccessibleName = null;
			resources.ApplyResources(label43, "label31");
			label43.Name = "label31";
			label44.AccessibleDescription = null;
			label44.AccessibleName = null;
			resources.ApplyResources(label44, "label32");
			label44.Name = "label32";
			label45.AccessibleDescription = null;
			label45.AccessibleName = null;
			resources.ApplyResources(label45, "label33");
			label45.Name = "label33";
			label46.AccessibleDescription = null;
			label46.AccessibleName = null;
			resources.ApplyResources(label46, "label34");
			label46.Name = "label34";
			label47.AccessibleDescription = null;
			label47.AccessibleName = null;
			resources.ApplyResources(label47, "label39");
			label47.Name = "label39";
			label48.AccessibleDescription = null;
			label48.AccessibleName = null;
			resources.ApplyResources(label48, "label38");
			label48.Name = "label38";
			label49.AccessibleDescription = null;
			label49.AccessibleName = null;
			resources.ApplyResources(label49, "label35");
			label49.Name = "label35";
			label50.AccessibleDescription = null;
			label50.AccessibleName = null;
			resources.ApplyResources(label50, "label45");
			label50.Name = "label45";
			label51.AccessibleDescription = null;
			label51.AccessibleName = null;
			resources.ApplyResources(label51, "label46");
			label51.Name = "label46";
			label52.AccessibleDescription = null;
			label52.AccessibleName = null;
			resources.ApplyResources(label52, "label48");
			label52.Name = "label48";
			label53.AccessibleDescription = null;
			label53.AccessibleName = null;
			resources.ApplyResources(label53, "label37");
			label53.Name = "label37";
			label54.AccessibleDescription = null;
			label54.AccessibleName = null;
			resources.ApplyResources(label54, "label50");
			label54.ForeColor = System.Drawing.Color.Firebrick;
			label54.Name = "label50";
			label55.AccessibleDescription = null;
			label55.AccessibleName = null;
			resources.ApplyResources(label55, "label51");
			label55.Name = "label51";
			label56.AccessibleDescription = null;
			label56.AccessibleName = null;
			resources.ApplyResources(label56, "label52");
			label56.Name = "label52";
			label57.AccessibleDescription = null;
			label57.AccessibleName = null;
			resources.ApplyResources(label57, "label53");
			label57.ForeColor = System.Drawing.Color.Firebrick;
			label57.Name = "label53";
			label58.AccessibleDescription = null;
			label58.AccessibleName = null;
			resources.ApplyResources(label58, "label54");
			label58.Name = "label54";
			label59.AccessibleDescription = null;
			label59.AccessibleName = null;
			resources.ApplyResources(label59, "label56");
			label59.Name = "label56";
			label60.AccessibleDescription = null;
			label60.AccessibleName = null;
			resources.ApplyResources(label60, "label57");
			label60.ForeColor = System.Drawing.Color.Firebrick;
			label60.Name = "label57";
			label61.AccessibleDescription = null;
			label61.AccessibleName = null;
			resources.ApplyResources(label61, "label58");
			label61.Name = "label58";
			label62.AccessibleDescription = null;
			label62.AccessibleName = null;
			resources.ApplyResources(label62, "label59");
			label62.Name = "label59";
			label63.AccessibleDescription = null;
			label63.AccessibleName = null;
			resources.ApplyResources(label63, "label60");
			label63.ForeColor = System.Drawing.Color.Firebrick;
			label63.Name = "label60";
			label64.AccessibleDescription = null;
			label64.AccessibleName = null;
			resources.ApplyResources(label64, "label62");
			label64.Name = "label62";
			label65.AccessibleDescription = null;
			label65.AccessibleName = null;
			resources.ApplyResources(label65, "label63");
			label65.Name = "label63";
			label66.AccessibleDescription = null;
			label66.AccessibleName = null;
			resources.ApplyResources(label66, "label64");
			label66.Name = "label64";
			label67.AccessibleDescription = null;
			label67.AccessibleName = null;
			resources.ApplyResources(label67, "label65");
			label67.Name = "label65";
			label68.AccessibleDescription = null;
			label68.AccessibleName = null;
			resources.ApplyResources(label68, "label66");
			label68.ForeColor = System.Drawing.Color.Firebrick;
			label68.Name = "label66";
			label69.AccessibleDescription = null;
			label69.AccessibleName = null;
			resources.ApplyResources(label69, "label67");
			label69.Name = "label67";
			label70.AccessibleDescription = null;
			label70.AccessibleName = null;
			resources.ApplyResources(label70, "label68");
			label70.Name = "label68";
			label71.AccessibleDescription = null;
			label71.AccessibleName = null;
			resources.ApplyResources(label71, "label69");
			label71.Name = "label69";
			label72.AccessibleDescription = null;
			label72.AccessibleName = null;
			resources.ApplyResources(label72, "label70");
			label72.Name = "label70";
			label73.AccessibleDescription = null;
			label73.AccessibleName = null;
			resources.ApplyResources(label73, "label71");
			label73.Name = "label71";
			label74.AccessibleDescription = null;
			label74.AccessibleName = null;
			resources.ApplyResources(label74, "label72");
			label74.Name = "label72";
			label75.AccessibleDescription = null;
			label75.AccessibleName = null;
			resources.ApplyResources(label75, "label73");
			label75.Name = "label73";
			label76.AccessibleDescription = null;
			label76.AccessibleName = null;
			resources.ApplyResources(label76, "label74");
			label76.Name = "label74";
			label77.AccessibleDescription = null;
			label77.AccessibleName = null;
			resources.ApplyResources(label77, "label75");
			label77.Name = "label75";
			label78.AccessibleDescription = null;
			label78.AccessibleName = null;
			resources.ApplyResources(label78, "label76");
			label78.Name = "label76";
			label79.AccessibleDescription = null;
			label79.AccessibleName = null;
			resources.ApplyResources(label79, "label77");
			label79.Name = "label77";
			label80.AccessibleDescription = null;
			label80.AccessibleName = null;
			resources.ApplyResources(label80, "label78");
			label80.Name = "label78";
			label81.AccessibleDescription = null;
			label81.AccessibleName = null;
			resources.ApplyResources(label81, "label79");
			label81.Name = "label79";
			label82.AccessibleDescription = null;
			label82.AccessibleName = null;
			resources.ApplyResources(label82, "label80");
			label82.Name = "label80";
			label83.AccessibleDescription = null;
			label83.AccessibleName = null;
			resources.ApplyResources(label83, "label81");
			label83.Name = "label81";
			label84.AccessibleDescription = null;
			label84.AccessibleName = null;
			resources.ApplyResources(label84, "label82");
			label84.Name = "label82";
			label85.AccessibleDescription = null;
			label85.AccessibleName = null;
			resources.ApplyResources(label85, "label83");
			label85.Name = "label83";
			label86.AccessibleDescription = null;
			label86.AccessibleName = null;
			resources.ApplyResources(label86, "label84");
			label86.Name = "label84";
			label87.AccessibleDescription = null;
			label87.AccessibleName = null;
			resources.ApplyResources(label87, "label85");
			label87.Name = "label85";
			label88.AccessibleDescription = null;
			label88.AccessibleName = null;
			resources.ApplyResources(label88, "label86");
			label88.Name = "label86";
			label89.AccessibleDescription = null;
			label89.AccessibleName = null;
			resources.ApplyResources(label89, "label87");
			label89.Name = "label87";
			label90.AccessibleDescription = null;
			label90.AccessibleName = null;
			resources.ApplyResources(label90, "label88");
			label90.Name = "label88";
			label91.AccessibleDescription = null;
			label91.AccessibleName = null;
			resources.ApplyResources(label91, "label89");
			label91.Name = "label89";
			label92.AccessibleDescription = null;
			label92.AccessibleName = null;
			resources.ApplyResources(label92, "label90");
			label92.Name = "label90";
			label93.AccessibleDescription = null;
			label93.AccessibleName = null;
			resources.ApplyResources(label93, "label91");
			label93.Name = "label91";
			label94.AccessibleDescription = null;
			label94.AccessibleName = null;
			resources.ApplyResources(label94, "label92");
			label94.Name = "label92";
			label95.AccessibleDescription = null;
			label95.AccessibleName = null;
			resources.ApplyResources(label95, "label93");
			label95.Name = "label93";
			label96.AccessibleDescription = null;
			label96.AccessibleName = null;
			resources.ApplyResources(label96, "label94");
			label96.Name = "label94";
			label97.AccessibleDescription = null;
			label97.AccessibleName = null;
			resources.ApplyResources(label97, "label95");
			label97.Name = "label95";
			label98.AccessibleDescription = null;
			label98.AccessibleName = null;
			resources.ApplyResources(label98, "label96");
			label98.Name = "label96";
			label99.AccessibleDescription = null;
			label99.AccessibleName = null;
			resources.ApplyResources(label99, "label97");
			label99.Name = "label97";
			label100.AccessibleDescription = null;
			label100.AccessibleName = null;
			resources.ApplyResources(label100, "label98");
			label100.Name = "label98";
			label101.AccessibleDescription = null;
			label101.AccessibleName = null;
			resources.ApplyResources(label101, "label99");
			label101.Name = "label99";
			label102.AccessibleDescription = null;
			label102.AccessibleName = null;
			resources.ApplyResources(label102, "label100");
			label102.Name = "label100";
			label103.AccessibleDescription = null;
			label103.AccessibleName = null;
			resources.ApplyResources(label103, "label101");
			label103.Name = "label101";
			label104.AccessibleDescription = null;
			label104.AccessibleName = null;
			resources.ApplyResources(label104, "label102");
			label104.Name = "label102";
			label105.AccessibleDescription = null;
			label105.AccessibleName = null;
			resources.ApplyResources(label105, "label103");
			label105.Name = "label103";
			label106.AccessibleDescription = null;
			label106.AccessibleName = null;
			resources.ApplyResources(label106, "label104");
			label106.Name = "label104";
			label107.AccessibleDescription = null;
			label107.AccessibleName = null;
			resources.ApplyResources(label107, "label105");
			label107.Name = "label105";
			label108.AccessibleDescription = null;
			label108.AccessibleName = null;
			resources.ApplyResources(label108, "label106");
			label108.Name = "label106";
			label109.AccessibleDescription = null;
			label109.AccessibleName = null;
			resources.ApplyResources(label109, "label107");
			label109.Name = "label107";
			label110.AccessibleDescription = null;
			label110.AccessibleName = null;
			resources.ApplyResources(label110, "label108");
			label110.Name = "label108";
			label111.AccessibleDescription = null;
			label111.AccessibleName = null;
			resources.ApplyResources(label111, "label109");
			label111.Name = "label109";
			label112.AccessibleDescription = null;
			label112.AccessibleName = null;
			resources.ApplyResources(label112, "label114");
			label112.Name = "label114";
			label113.AccessibleDescription = null;
			label113.AccessibleName = null;
			resources.ApplyResources(label113, "label115");
			label113.Name = "label115";
			label114.AccessibleDescription = null;
			label114.AccessibleName = null;
			resources.ApplyResources(label114, "label119");
			label114.Name = "label119";
			label115.AccessibleDescription = null;
			label115.AccessibleName = null;
			resources.ApplyResources(label115, "label120");
			label115.Name = "label120";
			label116.AccessibleDescription = null;
			label116.AccessibleName = null;
			resources.ApplyResources(label116, "label121");
			label116.Name = "label121";
			label117.AccessibleDescription = null;
			label117.AccessibleName = null;
			resources.ApplyResources(label117, "label125");
			label117.Name = "label125";
			label118.AccessibleDescription = null;
			label118.AccessibleName = null;
			resources.ApplyResources(label118, "label126");
			label118.ForeColor = System.Drawing.Color.Firebrick;
			label118.Name = "label126";
			label119.AccessibleDescription = null;
			label119.AccessibleName = null;
			resources.ApplyResources(label119, "label127");
			label119.Name = "label127";
			label120.AccessibleDescription = null;
			label120.AccessibleName = null;
			resources.ApplyResources(label120, "label128");
			label120.Name = "label128";
			label121.AccessibleDescription = null;
			label121.AccessibleName = null;
			resources.ApplyResources(label121, "label129");
			label121.ForeColor = System.Drawing.Color.Firebrick;
			label121.Name = "label129";
			label122.AccessibleDescription = null;
			label122.AccessibleName = null;
			resources.ApplyResources(label122, "label131");
			label122.Name = "label131";
			label123.AccessibleDescription = null;
			label123.AccessibleName = null;
			resources.ApplyResources(label123, "label132");
			label123.Name = "label132";
			label124.AccessibleDescription = null;
			label124.AccessibleName = null;
			resources.ApplyResources(label124, "label133");
			label124.Name = "label133";
			label125.AccessibleDescription = null;
			label125.AccessibleName = null;
			resources.ApplyResources(label125, "label134");
			label125.Name = "label134";
			label126.AccessibleDescription = null;
			label126.AccessibleName = null;
			resources.ApplyResources(label126, "label135");
			label126.ForeColor = System.Drawing.Color.Firebrick;
			label126.Name = "label135";
			label127.AccessibleDescription = null;
			label127.AccessibleName = null;
			resources.ApplyResources(label127, "label136");
			label127.Name = "label136";
			label128.AccessibleDescription = null;
			label128.AccessibleName = null;
			resources.ApplyResources(label128, "label137");
			label128.Name = "label137";
			label129.AccessibleDescription = null;
			label129.AccessibleName = null;
			resources.ApplyResources(label129, "label138");
			label129.Name = "label138";
			label130.AccessibleDescription = null;
			label130.AccessibleName = null;
			resources.ApplyResources(label130, "label139");
			label130.Name = "label139";
			label131.AccessibleDescription = null;
			label131.AccessibleName = null;
			resources.ApplyResources(label131, "label140");
			label131.Name = "label140";
			label132.AccessibleDescription = null;
			label132.AccessibleName = null;
			resources.ApplyResources(label132, "label141");
			label132.Name = "label141";
			label133.AccessibleDescription = null;
			label133.AccessibleName = null;
			resources.ApplyResources(label133, "label142");
			label133.Name = "label142";
			label134.AccessibleDescription = null;
			label134.AccessibleName = null;
			resources.ApplyResources(label134, "label143");
			label134.Name = "label143";
			label135.AccessibleDescription = null;
			label135.AccessibleName = null;
			resources.ApplyResources(label135, "label144");
			label135.Name = "label144";
			label136.AccessibleDescription = null;
			label136.AccessibleName = null;
			resources.ApplyResources(label136, "label145");
			label136.Name = "label145";
			label137.AccessibleDescription = null;
			label137.AccessibleName = null;
			resources.ApplyResources(label137, "label146");
			label137.Name = "label146";
			label138.AccessibleDescription = null;
			label138.AccessibleName = null;
			resources.ApplyResources(label138, "label147");
			label138.Name = "label147";
			label139.AccessibleDescription = null;
			label139.AccessibleName = null;
			resources.ApplyResources(label139, "label148");
			label139.Name = "label148";
			label140.AccessibleDescription = null;
			label140.AccessibleName = null;
			resources.ApplyResources(label140, "label149");
			label140.Name = "label149";
			label141.AccessibleDescription = null;
			label141.AccessibleName = null;
			resources.ApplyResources(label141, "label150");
			label141.Name = "label150";
			label142.AccessibleDescription = null;
			label142.AccessibleName = null;
			resources.ApplyResources(label142, "label151");
			label142.Name = "label151";
			label143.AccessibleDescription = null;
			label143.AccessibleName = null;
			resources.ApplyResources(label143, "label152");
			label143.Name = "label152";
			label144.AccessibleDescription = null;
			label144.AccessibleName = null;
			resources.ApplyResources(label144, "label153");
			label144.Name = "label153";
			label145.AccessibleDescription = null;
			label145.AccessibleName = null;
			resources.ApplyResources(label145, "label154");
			label145.Name = "label154";
			label146.AccessibleDescription = null;
			label146.AccessibleName = null;
			resources.ApplyResources(label146, "label155");
			label146.Name = "label155";
			label147.AccessibleDescription = null;
			label147.AccessibleName = null;
			resources.ApplyResources(label147, "label156");
			label147.Name = "label156";
			label148.AccessibleDescription = null;
			label148.AccessibleName = null;
			resources.ApplyResources(label148, "label157");
			label148.Name = "label157";
			label149.AccessibleDescription = null;
			label149.AccessibleName = null;
			resources.ApplyResources(label149, "label158");
			label149.Name = "label158";
			label150.AccessibleDescription = null;
			label150.AccessibleName = null;
			resources.ApplyResources(label150, "label159");
			label150.Name = "label159";
			label151.AccessibleDescription = null;
			label151.AccessibleName = null;
			resources.ApplyResources(label151, "label160");
			label151.Name = "label160";
			label152.AccessibleDescription = null;
			label152.AccessibleName = null;
			resources.ApplyResources(label152, "label161");
			label152.Name = "label161";
			label153.AccessibleDescription = null;
			label153.AccessibleName = null;
			resources.ApplyResources(label153, "label162");
			label153.Name = "label162";
			label154.AccessibleDescription = null;
			label154.AccessibleName = null;
			resources.ApplyResources(label154, "label163");
			label154.Name = "label163";
			label155.AccessibleDescription = null;
			label155.AccessibleName = null;
			resources.ApplyResources(label155, "label164");
			label155.Name = "label164";
			label156.AccessibleDescription = null;
			label156.AccessibleName = null;
			resources.ApplyResources(label156, "label165");
			label156.Name = "label165";
			label157.AccessibleDescription = null;
			label157.AccessibleName = null;
			resources.ApplyResources(label157, "label166");
			label157.Name = "label166";
			label158.AccessibleDescription = null;
			label158.AccessibleName = null;
			resources.ApplyResources(label158, "label167");
			label158.Name = "label167";
			label159.AccessibleDescription = null;
			label159.AccessibleName = null;
			resources.ApplyResources(label159, "label168");
			label159.Name = "label168";
			label160.AccessibleDescription = null;
			label160.AccessibleName = null;
			resources.ApplyResources(label160, "label169");
			label160.Name = "label169";
			label161.AccessibleDescription = null;
			label161.AccessibleName = null;
			resources.ApplyResources(label161, "label170");
			label161.Name = "label170";
			label162.AccessibleDescription = null;
			label162.AccessibleName = null;
			resources.ApplyResources(label162, "label171");
			label162.Name = "label171";
			label163.AccessibleDescription = null;
			label163.AccessibleName = null;
			resources.ApplyResources(label163, "label172");
			label163.Name = "label172";
			label164.AccessibleDescription = null;
			label164.AccessibleName = null;
			resources.ApplyResources(label164, "label173");
			label164.Name = "label173";
			label165.AccessibleDescription = null;
			label165.AccessibleName = null;
			resources.ApplyResources(label165, "label174");
			label165.Name = "label174";
			label166.AccessibleDescription = null;
			label166.AccessibleName = null;
			resources.ApplyResources(label166, "label175");
			label166.Name = "label175";
			label167.AccessibleDescription = null;
			label167.AccessibleName = null;
			resources.ApplyResources(label167, "label176");
			label167.Name = "label176";
			label168.AccessibleDescription = null;
			label168.AccessibleName = null;
			resources.ApplyResources(label168, "label177");
			label168.Name = "label177";
			label169.AccessibleDescription = null;
			label169.AccessibleName = null;
			resources.ApplyResources(label169, "label178");
			label169.Name = "label178";
			label170.AccessibleDescription = null;
			label170.AccessibleName = null;
			resources.ApplyResources(label170, "label183");
			label170.Name = "label183";
			label171.AccessibleDescription = null;
			label171.AccessibleName = null;
			resources.ApplyResources(label171, "label184");
			label171.Name = "label184";
			label172.AccessibleDescription = null;
			label172.AccessibleName = null;
			resources.ApplyResources(label172, "label188");
			label172.Name = "label188";
			label173.AccessibleDescription = null;
			label173.AccessibleName = null;
			resources.ApplyResources(label173, "label189");
			label173.Name = "label189";
			label174.AccessibleDescription = null;
			label174.AccessibleName = null;
			resources.ApplyResources(label174, "label190");
			label174.Name = "label190";
			this.label49.AccessibleDescription = null;
			this.label49.AccessibleName = null;
			resources.ApplyResources(this.label49, "label49");
			this.label49.Name = "label49";
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridViewCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(No, Period, Way, Place, Result, Baby, Mother, Notes);
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
			dataGridView1.Font = null;
			dataGridView1.GridColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.Name = "dataGridView1";
			resources.ApplyResources(No, "No");
			No.Name = "No";
			No.ReadOnly = true;
			resources.ApplyResources(Period, "Period");
			Period.Name = "Period";
			resources.ApplyResources(Way, "Way");
			Way.Name = "Way";
			Way.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			resources.ApplyResources(Place, "Place");
			Place.Name = "Place";
			Place.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			resources.ApplyResources(Result, "Result");
			Result.Name = "Result";
			Result.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			resources.ApplyResources(Baby, "Baby");
			Baby.Name = "Baby";
			Baby.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			resources.ApplyResources(Mother, "Mother");
			Mother.Name = "Mother";
			Mother.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			Mother.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			resources.ApplyResources(Notes, "Notes");
			Notes.Name = "Notes";
			titelComboBox.AccessibleDescription = null;
			titelComboBox.AccessibleName = null;
			resources.ApplyResources(titelComboBox, "titelComboBox");
			titelComboBox.BackgroundImage = null;
			titelComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			titelComboBox.FormattingEnabled = true;
			titelComboBox.Items.AddRange(new object[7]
			{
				resources.GetString("titelComboBox.Items"),
				resources.GetString("titelComboBox.Items1"),
				resources.GetString("titelComboBox.Items2"),
				resources.GetString("titelComboBox.Items3"),
				resources.GetString("titelComboBox.Items4"),
				resources.GetString("titelComboBox.Items5"),
				resources.GetString("titelComboBox.Items6")
			});
			titelComboBox.Name = "titelComboBox";
			nameTextBox.AccessibleDescription = null;
			nameTextBox.AccessibleName = null;
			resources.ApplyResources(nameTextBox, "nameTextBox");
			nameTextBox.BackgroundImage = null;
			nameTextBox.Name = "nameTextBox";
			nameTextBox.TextChanged += new System.EventHandler(nameTextBox_TextChanged);
			telTextBox.AccessibleDescription = null;
			telTextBox.AccessibleName = null;
			resources.ApplyResources(telTextBox, "telTextBox");
			telTextBox.BackgroundImage = null;
			telTextBox.Name = "telTextBox";
			telTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(telTextBox_KeyPress);
			mobTextBox.AccessibleDescription = null;
			mobTextBox.AccessibleName = null;
			resources.ApplyResources(mobTextBox, "mobTextBox");
			mobTextBox.BackgroundImage = null;
			mobTextBox.Name = "mobTextBox";
			mobTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(mobTextBox_KeyPress);
			emailTextBox.AccessibleDescription = null;
			emailTextBox.AccessibleName = null;
			resources.ApplyResources(emailTextBox, "emailTextBox");
			emailTextBox.BackgroundImage = null;
			emailTextBox.Name = "emailTextBox";
			emailTextBox.Validating += new System.ComponentModel.CancelEventHandler(emailTextBox_Validating);
			birthDateDateTimePicker.AccessibleDescription = null;
			birthDateDateTimePicker.AccessibleName = null;
			resources.ApplyResources(birthDateDateTimePicker, "birthDateDateTimePicker");
			birthDateDateTimePicker.BackgroundImage = null;
			birthDateDateTimePicker.CalendarFont = null;
			birthDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			birthDateDateTimePicker.Name = "birthDateDateTimePicker";
			birthDateDateTimePicker.ValueChanged += new System.EventHandler(birthDateDateTimePicker_ValueChanged);
			sexComboBox.AccessibleDescription = null;
			sexComboBox.AccessibleName = null;
			resources.ApplyResources(sexComboBox, "sexComboBox");
			sexComboBox.BackgroundImage = null;
			sexComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			sexComboBox.FormattingEnabled = true;
			sexComboBox.Items.AddRange(new object[2]
			{
				resources.GetString("sexComboBox.Items"),
				resources.GetString("sexComboBox.Items1")
			});
			sexComboBox.Name = "sexComboBox";
			cardNumTextBox.AccessibleDescription = null;
			cardNumTextBox.AccessibleName = null;
			resources.ApplyResources(cardNumTextBox, "cardNumTextBox");
			cardNumTextBox.BackgroundImage = null;
			cardNumTextBox.Name = "cardNumTextBox";
			lastVistDateDateTimePicker.AccessibleDescription = null;
			lastVistDateDateTimePicker.AccessibleName = null;
			resources.ApplyResources(lastVistDateDateTimePicker, "lastVistDateDateTimePicker");
			lastVistDateDateTimePicker.BackgroundImage = null;
			lastVistDateDateTimePicker.CalendarFont = null;
			lastVistDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			lastVistDateDateTimePicker.Name = "lastVistDateDateTimePicker";
			allergiesCheckBox.AccessibleDescription = null;
			allergiesCheckBox.AccessibleName = null;
			resources.ApplyResources(allergiesCheckBox, "allergiesCheckBox");
			allergiesCheckBox.BackgroundImage = null;
			allergiesCheckBox.Name = "allergiesCheckBox";
			allergiesCheckBox.UseVisualStyleBackColor = true;
			cardiacDiseaseCheckBox.AccessibleDescription = null;
			cardiacDiseaseCheckBox.AccessibleName = null;
			resources.ApplyResources(cardiacDiseaseCheckBox, "cardiacDiseaseCheckBox");
			cardiacDiseaseCheckBox.BackgroundImage = null;
			cardiacDiseaseCheckBox.Name = "cardiacDiseaseCheckBox";
			cardiacDiseaseCheckBox.UseVisualStyleBackColor = true;
			kidneyDeseaseCheckBox.AccessibleDescription = null;
			kidneyDeseaseCheckBox.AccessibleName = null;
			resources.ApplyResources(kidneyDeseaseCheckBox, "kidneyDeseaseCheckBox");
			kidneyDeseaseCheckBox.BackgroundImage = null;
			kidneyDeseaseCheckBox.Name = "kidneyDeseaseCheckBox";
			kidneyDeseaseCheckBox.UseVisualStyleBackColor = true;
			diabetesCheckBox.AccessibleDescription = null;
			diabetesCheckBox.AccessibleName = null;
			resources.ApplyResources(diabetesCheckBox, "diabetesCheckBox");
			diabetesCheckBox.BackgroundImage = null;
			diabetesCheckBox.Name = "diabetesCheckBox";
			diabetesCheckBox.UseVisualStyleBackColor = true;
			rheumaticFeverCheckBox.AccessibleDescription = null;
			rheumaticFeverCheckBox.AccessibleName = null;
			resources.ApplyResources(rheumaticFeverCheckBox, "rheumaticFeverCheckBox");
			rheumaticFeverCheckBox.BackgroundImage = null;
			rheumaticFeverCheckBox.Name = "rheumaticFeverCheckBox";
			rheumaticFeverCheckBox.UseVisualStyleBackColor = true;
			asthmaCheckBox.AccessibleDescription = null;
			asthmaCheckBox.AccessibleName = null;
			resources.ApplyResources(asthmaCheckBox, "asthmaCheckBox");
			asthmaCheckBox.BackgroundImage = null;
			asthmaCheckBox.Name = "asthmaCheckBox";
			asthmaCheckBox.UseVisualStyleBackColor = true;
			bloodDyscrasiasCheckBox.AccessibleDescription = null;
			bloodDyscrasiasCheckBox.AccessibleName = null;
			resources.ApplyResources(bloodDyscrasiasCheckBox, "bloodDyscrasiasCheckBox");
			bloodDyscrasiasCheckBox.BackgroundImage = null;
			bloodDyscrasiasCheckBox.Name = "bloodDyscrasiasCheckBox";
			bloodDyscrasiasCheckBox.UseVisualStyleBackColor = true;
			historyOtherTextBox.AccessibleDescription = null;
			historyOtherTextBox.AccessibleName = null;
			resources.ApplyResources(historyOtherTextBox, "historyOtherTextBox");
			historyOtherTextBox.BackgroundImage = null;
			historyOtherTextBox.Font = null;
			historyOtherTextBox.Name = "historyOtherTextBox";
			extractionCheckBox.AccessibleDescription = null;
			extractionCheckBox.AccessibleName = null;
			resources.ApplyResources(extractionCheckBox, "extractionCheckBox");
			extractionCheckBox.BackgroundImage = null;
			extractionCheckBox.Name = "extractionCheckBox";
			extractionCheckBox.UseVisualStyleBackColor = true;
			drugSensitivityCheckBox.AccessibleDescription = null;
			drugSensitivityCheckBox.AccessibleName = null;
			resources.ApplyResources(drugSensitivityCheckBox, "drugSensitivityCheckBox");
			drugSensitivityCheckBox.BackgroundImage = null;
			drugSensitivityCheckBox.Name = "drugSensitivityCheckBox";
			drugSensitivityCheckBox.UseVisualStyleBackColor = true;
			pulpTherapyCheckBox.AccessibleDescription = null;
			pulpTherapyCheckBox.AccessibleName = null;
			resources.ApplyResources(pulpTherapyCheckBox, "pulpTherapyCheckBox");
			pulpTherapyCheckBox.BackgroundImage = null;
			pulpTherapyCheckBox.Name = "pulpTherapyCheckBox";
			pulpTherapyCheckBox.UseVisualStyleBackColor = true;
			periodontalTherpyCheckBox.AccessibleDescription = null;
			periodontalTherpyCheckBox.AccessibleName = null;
			resources.ApplyResources(periodontalTherpyCheckBox, "periodontalTherpyCheckBox");
			periodontalTherpyCheckBox.BackgroundImage = null;
			periodontalTherpyCheckBox.Name = "periodontalTherpyCheckBox";
			periodontalTherpyCheckBox.UseVisualStyleBackColor = true;
			flourideTherapyCheckBox.AccessibleDescription = null;
			flourideTherapyCheckBox.AccessibleName = null;
			resources.ApplyResources(flourideTherapyCheckBox, "flourideTherapyCheckBox");
			flourideTherapyCheckBox.BackgroundImage = null;
			flourideTherapyCheckBox.Name = "flourideTherapyCheckBox";
			flourideTherapyCheckBox.UseVisualStyleBackColor = true;
			prviousHistoryOthersTextBox.AccessibleDescription = null;
			prviousHistoryOthersTextBox.AccessibleName = null;
			resources.ApplyResources(prviousHistoryOthersTextBox, "prviousHistoryOthersTextBox");
			prviousHistoryOthersTextBox.BackgroundImage = null;
			prviousHistoryOthersTextBox.Font = null;
			prviousHistoryOthersTextBox.Name = "prviousHistoryOthersTextBox";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(HepatitisCcheckBox);
			groupBox2.Controls.Add(PregnantcheckBox);
			groupBox2.Controls.Add(HepatitisBcheckBox);
			groupBox2.Controls.Add(lactatingcheckBox);
			groupBox2.Controls.Add(historyOtherTextBox);
			groupBox2.Controls.Add(label15);
			groupBox2.Controls.Add(bloodDyscrasiasCheckBox);
			groupBox2.Controls.Add(asthmaCheckBox);
			groupBox2.Controls.Add(rheumaticFeverCheckBox);
			groupBox2.Controls.Add(diabetesCheckBox);
			groupBox2.Controls.Add(kidneyDeseaseCheckBox);
			groupBox2.Controls.Add(cardiacDiseaseCheckBox);
			groupBox2.Controls.Add(allergiesCheckBox);
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			HepatitisCcheckBox.AccessibleDescription = null;
			HepatitisCcheckBox.AccessibleName = null;
			resources.ApplyResources(HepatitisCcheckBox, "HepatitisCcheckBox");
			HepatitisCcheckBox.BackgroundImage = null;
			HepatitisCcheckBox.Name = "HepatitisCcheckBox";
			HepatitisCcheckBox.UseVisualStyleBackColor = true;
			PregnantcheckBox.AccessibleDescription = null;
			PregnantcheckBox.AccessibleName = null;
			resources.ApplyResources(PregnantcheckBox, "PregnantcheckBox");
			PregnantcheckBox.BackgroundImage = null;
			PregnantcheckBox.Name = "PregnantcheckBox";
			PregnantcheckBox.UseVisualStyleBackColor = true;
			HepatitisBcheckBox.AccessibleDescription = null;
			HepatitisBcheckBox.AccessibleName = null;
			resources.ApplyResources(HepatitisBcheckBox, "HepatitisBcheckBox");
			HepatitisBcheckBox.BackgroundImage = null;
			HepatitisBcheckBox.Name = "HepatitisBcheckBox";
			HepatitisBcheckBox.UseVisualStyleBackColor = true;
			lactatingcheckBox.AccessibleDescription = null;
			lactatingcheckBox.AccessibleName = null;
			resources.ApplyResources(lactatingcheckBox, "lactatingcheckBox");
			lactatingcheckBox.BackgroundImage = null;
			lactatingcheckBox.Name = "lactatingcheckBox";
			lactatingcheckBox.UseVisualStyleBackColor = true;
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(OpretivecheckBox);
			groupBox3.Controls.Add(BleachingcheckBox);
			groupBox3.Controls.Add(prviousHistoryOthersTextBox);
			groupBox3.Controls.Add(flourideTherapyCheckBox);
			groupBox3.Controls.Add(periodontalTherpyCheckBox);
			groupBox3.Controls.Add(pulpTherapyCheckBox);
			groupBox3.Controls.Add(drugSensitivityCheckBox);
			groupBox3.Controls.Add(extractionCheckBox);
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			OpretivecheckBox.AccessibleDescription = null;
			OpretivecheckBox.AccessibleName = null;
			resources.ApplyResources(OpretivecheckBox, "OpretivecheckBox");
			OpretivecheckBox.BackgroundImage = null;
			OpretivecheckBox.Name = "OpretivecheckBox";
			OpretivecheckBox.UseVisualStyleBackColor = true;
			BleachingcheckBox.AccessibleDescription = null;
			BleachingcheckBox.AccessibleName = null;
			resources.ApplyResources(BleachingcheckBox, "BleachingcheckBox");
			BleachingcheckBox.BackgroundImage = null;
			BleachingcheckBox.Name = "BleachingcheckBox";
			BleachingcheckBox.UseVisualStyleBackColor = true;
			CommentPanel.AccessibleDescription = null;
			CommentPanel.AccessibleName = null;
			resources.ApplyResources(CommentPanel, "CommentPanel");
			CommentPanel.BackgroundImage = null;
			CommentPanel.Controls.Add(AddComment);
			CommentPanel.Font = null;
			CommentPanel.Name = "CommentPanel";
			AddComment.AccessibleDescription = null;
			AddComment.AccessibleName = null;
			resources.ApplyResources(AddComment, "AddComment");
			AddComment.BackColor = System.Drawing.Color.Gainsboro;
			AddComment.BackgroundImage = null;
			AddComment.Name = "AddComment";
			AddComment.UseVisualStyleBackColor = false;
			AddComment.Click += new System.EventHandler(AddComment_Click);
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.LightSteelBlue;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(button12);
			groupBox4.Controls.Add(button11);
			groupBox4.Controls.Add(checkBox12);
			groupBox4.Controls.Add(nationalID);
			groupBox4.Controls.Add(label58);
			groupBox4.Controls.Add(panel3);
			groupBox4.Controls.Add(radioButton5);
			groupBox4.Controls.Add(radioButton4);
			groupBox4.Controls.Add(cityTextBox);
			groupBox4.Controls.Add(nationalityTextBox);
			groupBox4.Controls.Add(addressTextBox);
			groupBox4.Controls.Add(floatText2);
			groupBox4.Controls.Add(label56);
			groupBox4.Controls.Add(label55);
			groupBox4.Controls.Add(panel2);
			groupBox4.Controls.Add(IDtextBox);
			groupBox4.Controls.Add(label52);
			groupBox4.Controls.Add(DentalLogoBtn);
			groupBox4.Controls.Add(groupBox7);
			groupBox4.Controls.Add(radioButton3);
			groupBox4.Controls.Add(radioButton2);
			groupBox4.Controls.Add(radioButton1);
			groupBox4.Controls.Add(label53);
			groupBox4.Controls.Add(txtFileNo);
			groupBox4.Controls.Add(checkBox11);
			groupBox4.Controls.Add(txtBloodType);
			groupBox4.Controls.Add(label18);
			groupBox4.Controls.Add(DoctorcomboBox);
			groupBox4.Controls.Add(label17);
			groupBox4.Controls.Add(button1);
			groupBox4.Controls.Add(label16);
			groupBox4.Controls.Add(companycomboBox);
			groupBox4.Controls.Add(statueComboBox);
			groupBox4.Controls.Add(label);
			groupBox4.Controls.Add(lastVistDateDateTimePicker);
			groupBox4.Controls.Add(label14);
			groupBox4.Controls.Add(cardNumTextBox);
			groupBox4.Controls.Add(label13);
			groupBox4.Controls.Add(titelComboBox);
			groupBox4.Controls.Add(label2);
			groupBox4.Controls.Add(label12);
			groupBox4.Controls.Add(nameTextBox);
			groupBox4.Controls.Add(label3);
			groupBox4.Controls.Add(label11);
			groupBox4.Controls.Add(label4);
			groupBox4.Controls.Add(label10);
			groupBox4.Controls.Add(sexComboBox);
			groupBox4.Controls.Add(label5);
			groupBox4.Controls.Add(label9);
			groupBox4.Controls.Add(telTextBox);
			groupBox4.Controls.Add(birthDateDateTimePicker);
			groupBox4.Controls.Add(label6);
			groupBox4.Controls.Add(label8);
			groupBox4.Controls.Add(mobTextBox);
			groupBox4.Controls.Add(emailTextBox);
			groupBox4.Controls.Add(label7);
			groupBox4.ForeColor = System.Drawing.Color.Black;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			button12.AccessibleDescription = null;
			button12.AccessibleName = null;
			resources.ApplyResources(button12, "button12");
			button12.BackgroundImage = null;
			button12.Name = "button12";
			button12.UseVisualStyleBackColor = true;
			button12.Click += new System.EventHandler(button12_Click);
			button11.AccessibleDescription = null;
			button11.AccessibleName = null;
			resources.ApplyResources(button11, "button11");
			button11.BackgroundImage = null;
			button11.Name = "button11";
			button11.UseVisualStyleBackColor = true;
			button11.Click += new System.EventHandler(button11_Click);
			checkBox12.AccessibleDescription = null;
			checkBox12.AccessibleName = null;
			resources.ApplyResources(checkBox12, "checkBox12");
			checkBox12.BackgroundImage = null;
			checkBox12.Checked = true;
			checkBox12.CheckState = System.Windows.Forms.CheckState.Checked;
			checkBox12.Name = "checkBox12";
			checkBox12.UseVisualStyleBackColor = true;
			nationalID.AccessibleDescription = null;
			nationalID.AccessibleName = null;
			resources.ApplyResources(nationalID, "nationalID");
			nationalID.BackgroundImage = null;
			nationalID.Name = "nationalID";
			nationalID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(textBox6_KeyPress);
			panel3.AccessibleDescription = null;
			panel3.AccessibleName = null;
			resources.ApplyResources(panel3, "panel3");
			panel3.BackgroundImage = null;
			panel3.Controls.Add(label57);
			panel3.Controls.Add(comboBox13);
			panel3.Name = "panel3";
			comboBox13.AccessibleDescription = null;
			comboBox13.AccessibleName = null;
			resources.ApplyResources(comboBox13, "comboBox13");
			comboBox13.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox13.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox13.BackgroundImage = null;
			comboBox13.FormattingEnabled = true;
			comboBox13.Name = "comboBox13";
			radioButton5.AccessibleDescription = null;
			radioButton5.AccessibleName = null;
			resources.ApplyResources(radioButton5, "radioButton5");
			radioButton5.BackgroundImage = null;
			radioButton5.Name = "radioButton5";
			radioButton5.UseVisualStyleBackColor = true;
			radioButton5.CheckedChanged += new System.EventHandler(radioButton5_CheckedChanged);
			radioButton4.AccessibleDescription = null;
			radioButton4.AccessibleName = null;
			resources.ApplyResources(radioButton4, "radioButton4");
			radioButton4.BackgroundImage = null;
			radioButton4.Checked = true;
			radioButton4.Name = "radioButton4";
			radioButton4.TabStop = true;
			radioButton4.UseVisualStyleBackColor = true;
			radioButton4.CheckedChanged += new System.EventHandler(radioButton4_CheckedChanged);
			cityTextBox.AccessibleDescription = null;
			cityTextBox.AccessibleName = null;
			resources.ApplyResources(cityTextBox, "cityTextBox");
			cityTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			cityTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			cityTextBox.BackgroundImage = null;
			cityTextBox.FormattingEnabled = true;
			cityTextBox.Name = "cityTextBox";
			nationalityTextBox.AccessibleDescription = null;
			nationalityTextBox.AccessibleName = null;
			resources.ApplyResources(nationalityTextBox, "nationalityTextBox");
			nationalityTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			nationalityTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			nationalityTextBox.BackgroundImage = null;
			nationalityTextBox.FormattingEnabled = true;
			nationalityTextBox.Name = "nationalityTextBox";
			addressTextBox.AccessibleDescription = null;
			addressTextBox.AccessibleName = null;
			resources.ApplyResources(addressTextBox, "addressTextBox");
			addressTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			addressTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			addressTextBox.BackgroundImage = null;
			addressTextBox.FormattingEnabled = true;
			addressTextBox.Name = "addressTextBox";
			floatText2.AccessibleDescription = null;
			floatText2.AccessibleName = null;
			resources.ApplyResources(floatText2, "floatText2");
			floatText2.BackgroundImage = null;
			floatText2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText2.Name = "floatText2";
			floatText2.TextChanged += new System.EventHandler(floatText2_TextChanged);
			panel2.AccessibleDescription = null;
			panel2.AccessibleName = null;
			resources.ApplyResources(panel2, "panel2");
			panel2.BackgroundImage = null;
			panel2.Controls.Add(label54);
			panel2.Controls.Add(floatText1);
			panel2.Controls.Add(this.label49);
			panel2.Controls.Add(PatientComboBox);
			panel2.Name = "panel2";
			floatText1.AccessibleDescription = null;
			floatText1.AccessibleName = null;
			resources.ApplyResources(floatText1, "floatText1");
			floatText1.BackgroundImage = null;
			floatText1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText1.Font = null;
			floatText1.Name = "floatText1";
			PatientComboBox.AccessibleDescription = null;
			PatientComboBox.AccessibleName = null;
			resources.ApplyResources(PatientComboBox, "PatientComboBox");
			PatientComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			PatientComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientComboBox.BackgroundImage = null;
			PatientComboBox.FormattingEnabled = true;
			PatientComboBox.Name = "PatientComboBox";
			IDtextBox.AccessibleDescription = null;
			IDtextBox.AccessibleName = null;
			resources.ApplyResources(IDtextBox, "IDtextBox");
			IDtextBox.BackgroundImage = null;
			IDtextBox.ForeColor = System.Drawing.Color.Maroon;
			IDtextBox.Name = "IDtextBox";
			IDtextBox.ReadOnly = true;
			DentalLogoBtn.AccessibleDescription = null;
			DentalLogoBtn.AccessibleName = null;
			resources.ApplyResources(DentalLogoBtn, "DentalLogoBtn");
			DentalLogoBtn.BackColor = System.Drawing.Color.Transparent;
			DentalLogoBtn.BackgroundImage = null;
			DentalLogoBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			DentalLogoBtn.Name = "DentalLogoBtn";
			DentalLogoBtn.UseVisualStyleBackColor = false;
			DentalLogoBtn.Click += new System.EventHandler(DentalLogoBtn_Click);
			groupBox7.AccessibleDescription = null;
			groupBox7.AccessibleName = null;
			resources.ApplyResources(groupBox7, "groupBox7");
			groupBox7.BackColor = System.Drawing.Color.Transparent;
			groupBox7.BackgroundImage = null;
			groupBox7.Controls.Add(pictureBox1);
			groupBox7.Name = "groupBox7";
			groupBox7.TabStop = false;
			pictureBox1.AccessibleDescription = null;
			pictureBox1.AccessibleName = null;
			resources.ApplyResources(pictureBox1, "pictureBox1");
			pictureBox1.BackColor = System.Drawing.Color.Transparent;
			pictureBox1.BackgroundImage = null;
			pictureBox1.Font = null;
			pictureBox1.ImageLocation = null;
			pictureBox1.Name = "pictureBox1";
			pictureBox1.TabStop = false;
			radioButton3.AccessibleDescription = null;
			radioButton3.AccessibleName = null;
			resources.ApplyResources(radioButton3, "radioButton3");
			radioButton3.BackgroundImage = null;
			radioButton3.Name = "radioButton3";
			radioButton3.UseVisualStyleBackColor = true;
			radioButton3.CheckedChanged += new System.EventHandler(radioButton3_CheckedChanged);
			radioButton2.AccessibleDescription = null;
			radioButton2.AccessibleName = null;
			resources.ApplyResources(radioButton2, "radioButton2");
			radioButton2.BackgroundImage = null;
			radioButton2.Name = "radioButton2";
			radioButton2.UseVisualStyleBackColor = true;
			radioButton2.CheckedChanged += new System.EventHandler(radioButton2_CheckedChanged);
			radioButton1.AccessibleDescription = null;
			radioButton1.AccessibleName = null;
			resources.ApplyResources(radioButton1, "radioButton1");
			radioButton1.BackgroundImage = null;
			radioButton1.Name = "radioButton1";
			radioButton1.UseVisualStyleBackColor = true;
			radioButton1.CheckedChanged += new System.EventHandler(radioButton1_CheckedChanged);
			txtFileNo.AccessibleDescription = null;
			txtFileNo.AccessibleName = null;
			resources.ApplyResources(txtFileNo, "txtFileNo");
			txtFileNo.BackgroundImage = null;
			txtFileNo.ForeColor = System.Drawing.Color.Maroon;
			txtFileNo.Name = "txtFileNo";
			txtFileNo.ReadOnly = true;
			txtFileNo.TextChanged += new System.EventHandler(textBox6_TextChanged);
			txtFileNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(txtFileNo_KeyPress);
			checkBox11.AccessibleDescription = null;
			checkBox11.AccessibleName = null;
			resources.ApplyResources(checkBox11, "checkBox11");
			checkBox11.BackgroundImage = null;
			checkBox11.Checked = true;
			checkBox11.CheckState = System.Windows.Forms.CheckState.Checked;
			checkBox11.Name = "checkBox11";
			checkBox11.UseVisualStyleBackColor = true;
			txtBloodType.AccessibleDescription = null;
			txtBloodType.AccessibleName = null;
			resources.ApplyResources(txtBloodType, "txtBloodType");
			txtBloodType.BackgroundImage = null;
			txtBloodType.Name = "txtBloodType";
			DoctorcomboBox.AccessibleDescription = null;
			DoctorcomboBox.AccessibleName = null;
			resources.ApplyResources(DoctorcomboBox, "DoctorcomboBox");
			DoctorcomboBox.BackgroundImage = null;
			DoctorcomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			DoctorcomboBox.FormattingEnabled = true;
			DoctorcomboBox.Name = "DoctorcomboBox";
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			companycomboBox.AccessibleDescription = null;
			companycomboBox.AccessibleName = null;
			resources.ApplyResources(companycomboBox, "companycomboBox");
			companycomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			companycomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			companycomboBox.BackgroundImage = null;
			companycomboBox.FormattingEnabled = true;
			companycomboBox.Name = "companycomboBox";
			companycomboBox.Enter += new System.EventHandler(companycomboBox_Enter);
			statueComboBox.AccessibleDescription = null;
			statueComboBox.AccessibleName = null;
			resources.ApplyResources(statueComboBox, "statueComboBox");
			statueComboBox.BackgroundImage = null;
			statueComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			statueComboBox.FormattingEnabled = true;
			statueComboBox.Items.AddRange(new object[3]
			{
				resources.GetString("statueComboBox.Items"),
				resources.GetString("statueComboBox.Items1"),
				resources.GetString("statueComboBox.Items2")
			});
			statueComboBox.Name = "statueComboBox";
			saveBtn.AccessibleDescription = null;
			saveBtn.AccessibleName = null;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			saveBtn.BackgroundImage = null;
			saveBtn.Name = "saveBtn";
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			EditBtn.AccessibleDescription = null;
			EditBtn.AccessibleName = null;
			resources.ApplyResources(EditBtn, "EditBtn");
			EditBtn.BackColor = System.Drawing.Color.Gainsboro;
			EditBtn.BackgroundImage = null;
			EditBtn.Name = "EditBtn";
			EditBtn.UseVisualStyleBackColor = false;
			EditBtn.Click += new System.EventHandler(EditBtn_Click);
			groupBox5.AccessibleDescription = null;
			groupBox5.AccessibleName = null;
			resources.ApplyResources(groupBox5, "groupBox5");
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.BackgroundImage = null;
			groupBox5.Controls.Add(CommentPanel);
			groupBox5.Controls.Add(panel1);
			groupBox5.Controls.Add(checkBox1);
			groupBox5.Controls.Add(EditBtn);
			groupBox5.Controls.Add(saveBtn);
			groupBox5.Font = null;
			groupBox5.Name = "groupBox5";
			groupBox5.TabStop = false;
			panel1.AccessibleDescription = null;
			panel1.AccessibleName = null;
			resources.ApplyResources(panel1, "panel1");
			panel1.BackgroundImage = null;
			panel1.Controls.Add(button6);
			panel1.Controls.Add(button3);
			panel1.Controls.Add(button5);
			panel1.Controls.Add(button4);
			panel1.Controls.Add(button2);
			panel1.Font = null;
			panel1.Name = "panel1";
			button6.AccessibleDescription = null;
			button6.AccessibleName = null;
			resources.ApplyResources(button6, "button6");
			button6.BackColor = System.Drawing.Color.Gainsboro;
			button6.BackgroundImage = null;
			button6.Name = "button6";
			button6.UseVisualStyleBackColor = false;
			button6.Click += new System.EventHandler(button6_Click);
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackColor = System.Drawing.Color.Gainsboro;
			button3.BackgroundImage = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = false;
			button3.Click += new System.EventHandler(button3_Click);
			button5.AccessibleDescription = null;
			button5.AccessibleName = null;
			resources.ApplyResources(button5, "button5");
			button5.BackColor = System.Drawing.Color.Gainsboro;
			button5.BackgroundImage = null;
			button5.Name = "button5";
			button5.UseVisualStyleBackColor = false;
			button5.Click += new System.EventHandler(button5_Click);
			button4.AccessibleDescription = null;
			button4.AccessibleName = null;
			resources.ApplyResources(button4, "button4");
			button4.BackColor = System.Drawing.Color.Gainsboro;
			button4.BackgroundImage = null;
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = false;
			button4.Click += new System.EventHandler(button4_Click);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackColor = System.Drawing.Color.Gainsboro;
			button2.BackgroundImage = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = false;
			button2.Click += new System.EventHandler(button2_Click);
			checkBox1.AccessibleDescription = null;
			checkBox1.AccessibleName = null;
			resources.ApplyResources(checkBox1, "checkBox1");
			checkBox1.BackgroundImage = null;
			checkBox1.Name = "checkBox1";
			checkBox1.UseVisualStyleBackColor = true;
			groupBox6.AccessibleDescription = null;
			groupBox6.AccessibleName = null;
			resources.ApplyResources(groupBox6, "groupBox6");
			groupBox6.BackColor = System.Drawing.Color.LightSteelBlue;
			groupBox6.BackgroundImage = null;
			groupBox6.Controls.Add(this.label2);
			groupBox6.Font = null;
			groupBox6.Name = "groupBox6";
			groupBox6.TabStop = false;
			this.label2.AccessibleDescription = null;
			this.label2.AccessibleName = null;
			resources.ApplyResources(this.label2, "label2");
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Name = "label2";
			flowLayoutPanel1.AccessibleDescription = null;
			flowLayoutPanel1.AccessibleName = null;
			resources.ApplyResources(flowLayoutPanel1, "flowLayoutPanel1");
			flowLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
			flowLayoutPanel1.BackgroundImage = null;
			flowLayoutPanel1.Font = null;
			flowLayoutPanel1.Name = "flowLayoutPanel1";
			groupBox8.AccessibleDescription = null;
			groupBox8.AccessibleName = null;
			resources.ApplyResources(groupBox8, "groupBox8");
			groupBox8.BackColor = System.Drawing.Color.Transparent;
			groupBox8.BackgroundImage = null;
			groupBox8.Controls.Add(checkedListBox2);
			groupBox8.Name = "groupBox8";
			groupBox8.TabStop = false;
			checkedListBox2.AccessibleDescription = null;
			checkedListBox2.AccessibleName = null;
			resources.ApplyResources(checkedListBox2, "checkedListBox2");
			checkedListBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
			checkedListBox2.BackgroundImage = null;
			checkedListBox2.CheckOnClick = true;
			checkedListBox2.Font = null;
			checkedListBox2.FormattingEnabled = true;
			checkedListBox2.Name = "checkedListBox2";
			checkedListBox2.SelectedIndexChanged += new System.EventHandler(checkedListBox2_SelectedIndexChanged);
			checkedListBox2.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(checkedListBox2_ItemCheck);
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(checkedListBox1);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			checkedListBox1.AccessibleDescription = null;
			checkedListBox1.AccessibleName = null;
			resources.ApplyResources(checkedListBox1, "checkedListBox1");
			checkedListBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
			checkedListBox1.BackgroundImage = null;
			checkedListBox1.CheckOnClick = true;
			checkedListBox1.Font = null;
			checkedListBox1.FormattingEnabled = true;
			checkedListBox1.Name = "checkedListBox1";
			checkedListBox1.UseCompatibleTextRendering = true;
			button7.AccessibleDescription = null;
			button7.AccessibleName = null;
			resources.ApplyResources(button7, "button7");
			button7.BackColor = System.Drawing.Color.Gainsboro;
			button7.BackgroundImage = null;
			button7.Name = "button7";
			button7.UseVisualStyleBackColor = false;
			button7.Click += new System.EventHandler(button7_Click);
			button8.AccessibleDescription = null;
			button8.AccessibleName = null;
			resources.ApplyResources(button8, "button8");
			button8.BackColor = System.Drawing.Color.Gainsboro;
			button8.BackgroundImage = null;
			button8.Name = "button8";
			button8.UseVisualStyleBackColor = false;
			button8.Click += new System.EventHandler(button8_Click);
			LightSteelBlue.AccessibleDescription = null;
			LightSteelBlue.AccessibleName = null;
			resources.ApplyResources(LightSteelBlue, "LightSteelBlue");
			LightSteelBlue.BackgroundImage = null;
			LightSteelBlue.Controls.Add(tabPage1);
			LightSteelBlue.Controls.Add(tabPage2);
			LightSteelBlue.Controls.Add(tabPage3);
			LightSteelBlue.Controls.Add(tabPage4);
			LightSteelBlue.Controls.Add(tabPage9);
			LightSteelBlue.Font = null;
			LightSteelBlue.Name = "LightSteelBlue";
			LightSteelBlue.SelectedIndex = 0;
			LightSteelBlue.KeyDown += new System.Windows.Forms.KeyEventHandler(LightSteelBlue_KeyDown);
			tabPage1.AccessibleDescription = null;
			tabPage1.AccessibleName = null;
			resources.ApplyResources(tabPage1, "tabPage1");
			tabPage1.BackColor = System.Drawing.Color.LightSteelBlue;
			tabPage1.BackgroundImage = null;
			tabPage1.Controls.Add(groupBox11);
			tabPage1.Controls.Add(button10);
			tabPage1.Controls.Add(groupBox6);
			tabPage1.Controls.Add(groupBox4);
			tabPage1.Controls.Add(button8);
			tabPage1.Controls.Add(button7);
			tabPage1.Controls.Add(groupBox8);
			tabPage1.Controls.Add(groupBox2);
			tabPage1.Controls.Add(groupBox1);
			tabPage1.Controls.Add(groupBox3);
			tabPage1.Font = null;
			tabPage1.Name = "tabPage1";
			tabPage1.UseVisualStyleBackColor = true;
			groupBox11.AccessibleDescription = null;
			groupBox11.AccessibleName = null;
			resources.ApplyResources(groupBox11, "groupBox11");
			groupBox11.BackColor = System.Drawing.Color.Transparent;
			groupBox11.BackgroundImage = null;
			groupBox11.Controls.Add(checkedListBox3);
			groupBox11.Name = "groupBox11";
			groupBox11.TabStop = false;
			checkedListBox3.AccessibleDescription = null;
			checkedListBox3.AccessibleName = null;
			resources.ApplyResources(checkedListBox3, "checkedListBox3");
			checkedListBox3.BackColor = System.Drawing.SystemColors.ActiveCaption;
			checkedListBox3.BackgroundImage = null;
			checkedListBox3.CheckOnClick = true;
			checkedListBox3.Font = null;
			checkedListBox3.FormattingEnabled = true;
			checkedListBox3.Name = "checkedListBox3";
			checkedListBox3.ThreeDCheckBoxes = true;
			button10.AccessibleDescription = null;
			button10.AccessibleName = null;
			resources.ApplyResources(button10, "button10");
			button10.BackColor = System.Drawing.Color.Gainsboro;
			button10.BackgroundImage = null;
			button10.Name = "button10";
			button10.UseVisualStyleBackColor = false;
			button10.Click += new System.EventHandler(button10_Click);
			tabPage2.AccessibleDescription = null;
			tabPage2.AccessibleName = null;
			resources.ApplyResources(tabPage2, "tabPage2");
			tabPage2.BackColor = System.Drawing.Color.LightSteelBlue;
			tabPage2.BackgroundImage = null;
			tabPage2.Controls.Add(groupBox9);
			tabPage2.Font = null;
			tabPage2.Name = "tabPage2";
			tabPage2.UseVisualStyleBackColor = true;
			groupBox9.AccessibleDescription = null;
			groupBox9.AccessibleName = null;
			resources.ApplyResources(groupBox9, "groupBox9");
			groupBox9.BackgroundImage = null;
			groupBox9.Controls.Add(comboBox12);
			groupBox9.Controls.Add(comboBox5);
			groupBox9.Controls.Add(label40);
			groupBox9.Controls.Add(dateTimePicker2);
			groupBox9.Controls.Add(label39);
			groupBox9.Controls.Add(comboBox4);
			groupBox9.Controls.Add(label38);
			groupBox9.Controls.Add(comboBox3);
			groupBox9.Controls.Add(label37);
			groupBox9.Controls.Add(comboBox2);
			groupBox9.Controls.Add(label36);
			groupBox9.Controls.Add(checkBox10);
			groupBox9.Controls.Add(dateTimePicker1);
			groupBox9.Controls.Add(label35);
			groupBox9.Controls.Add(numericUpDown12);
			groupBox9.Controls.Add(label34);
			groupBox9.Controls.Add(checkBox9);
			groupBox9.Controls.Add(numericUpDown11);
			groupBox9.Controls.Add(label33);
			groupBox9.Controls.Add(comboBox1);
			groupBox9.Controls.Add(label32);
			groupBox9.Controls.Add(numericUpDown10);
			groupBox9.Controls.Add(numericUpDown9);
			groupBox9.Controls.Add(numericUpDown8);
			groupBox9.Controls.Add(label31);
			groupBox9.Controls.Add(numericUpDown7);
			groupBox9.Controls.Add(label30);
			groupBox9.Controls.Add(label29);
			groupBox9.Controls.Add(label28);
			groupBox9.Controls.Add(numericUpDown6);
			groupBox9.Controls.Add(numericUpDown5);
			groupBox9.Controls.Add(label27);
			groupBox9.Controls.Add(numericUpDown4);
			groupBox9.Controls.Add(label26);
			groupBox9.Controls.Add(numericUpDown3);
			groupBox9.Controls.Add(label25);
			groupBox9.Controls.Add(checkBox8);
			groupBox9.Controls.Add(label24);
			groupBox9.Controls.Add(checkBox6);
			groupBox9.Controls.Add(checkBox7);
			groupBox9.Controls.Add(textBox4);
			groupBox9.Controls.Add(checkBox5);
			groupBox9.Controls.Add(checkBox4);
			groupBox9.Controls.Add(checkBox3);
			groupBox9.Controls.Add(label23);
			groupBox9.Controls.Add(label22);
			groupBox9.Controls.Add(numericUpDown2);
			groupBox9.Controls.Add(numericUpDown1);
			groupBox9.Controls.Add(checkBox2);
			groupBox9.Controls.Add(label21);
			groupBox9.Controls.Add(label20);
			groupBox9.Controls.Add(label19);
			groupBox9.Controls.Add(textBox1);
			groupBox9.Name = "groupBox9";
			groupBox9.TabStop = false;
			comboBox12.AccessibleDescription = null;
			comboBox12.AccessibleName = null;
			resources.ApplyResources(comboBox12, "comboBox12");
			comboBox12.BackgroundImage = null;
			comboBox12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox12.FormattingEnabled = true;
			comboBox12.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox12.Items"),
				resources.GetString("comboBox12.Items1")
			});
			comboBox12.Name = "comboBox12";
			comboBox5.AccessibleDescription = null;
			comboBox5.AccessibleName = null;
			resources.ApplyResources(comboBox5, "comboBox5");
			comboBox5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox5.BackgroundImage = null;
			comboBox5.FormattingEnabled = true;
			comboBox5.Name = "comboBox5";
			dateTimePicker2.AccessibleDescription = null;
			dateTimePicker2.AccessibleName = null;
			resources.ApplyResources(dateTimePicker2, "dateTimePicker2");
			dateTimePicker2.BackgroundImage = null;
			dateTimePicker2.CalendarFont = null;
			dateTimePicker2.CustomFormat = null;
			dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			dateTimePicker2.Name = "dateTimePicker2";
			comboBox4.AccessibleDescription = null;
			comboBox4.AccessibleName = null;
			resources.ApplyResources(comboBox4, "comboBox4");
			comboBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox4.BackgroundImage = null;
			comboBox4.FormattingEnabled = true;
			comboBox4.Name = "comboBox4";
			comboBox3.AccessibleDescription = null;
			comboBox3.AccessibleName = null;
			resources.ApplyResources(comboBox3, "comboBox3");
			comboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox3.BackgroundImage = null;
			comboBox3.FormattingEnabled = true;
			comboBox3.Name = "comboBox3";
			comboBox2.AccessibleDescription = null;
			comboBox2.AccessibleName = null;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.BackgroundImage = null;
			comboBox2.FormattingEnabled = true;
			comboBox2.Name = "comboBox2";
			checkBox10.AccessibleDescription = null;
			checkBox10.AccessibleName = null;
			resources.ApplyResources(checkBox10, "checkBox10");
			checkBox10.BackgroundImage = null;
			checkBox10.Name = "checkBox10";
			checkBox10.UseVisualStyleBackColor = true;
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.CustomFormat = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			dateTimePicker1.Name = "dateTimePicker1";
			dateTimePicker1.ValueChanged += new System.EventHandler(dateTimePicker1_ValueChanged);
			numericUpDown12.AccessibleDescription = null;
			numericUpDown12.AccessibleName = null;
			resources.ApplyResources(numericUpDown12, "numericUpDown12");
			numericUpDown12.DecimalPlaces = 2;
			numericUpDown12.Name = "numericUpDown12";
			checkBox9.AccessibleDescription = null;
			checkBox9.AccessibleName = null;
			resources.ApplyResources(checkBox9, "checkBox9");
			checkBox9.BackgroundImage = null;
			checkBox9.Name = "checkBox9";
			checkBox9.UseVisualStyleBackColor = true;
			numericUpDown11.AccessibleDescription = null;
			numericUpDown11.AccessibleName = null;
			resources.ApplyResources(numericUpDown11, "numericUpDown11");
			numericUpDown11.Name = "numericUpDown11";
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.BackgroundImage = null;
			comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox1.FormattingEnabled = true;
			comboBox1.Items.AddRange(new object[3]
			{
				resources.GetString("comboBox1.Items"),
				resources.GetString("comboBox1.Items1"),
				resources.GetString("comboBox1.Items2")
			});
			comboBox1.Name = "comboBox1";
			numericUpDown10.AccessibleDescription = null;
			numericUpDown10.AccessibleName = null;
			resources.ApplyResources(numericUpDown10, "numericUpDown10");
			numericUpDown10.DecimalPlaces = 2;
			numericUpDown10.Name = "numericUpDown10";
			numericUpDown9.AccessibleDescription = null;
			numericUpDown9.AccessibleName = null;
			resources.ApplyResources(numericUpDown9, "numericUpDown9");
			numericUpDown9.DecimalPlaces = 2;
			numericUpDown9.Name = "numericUpDown9";
			numericUpDown8.AccessibleDescription = null;
			numericUpDown8.AccessibleName = null;
			resources.ApplyResources(numericUpDown8, "numericUpDown8");
			numericUpDown8.DecimalPlaces = 2;
			numericUpDown8.Name = "numericUpDown8";
			numericUpDown7.AccessibleDescription = null;
			numericUpDown7.AccessibleName = null;
			resources.ApplyResources(numericUpDown7, "numericUpDown7");
			numericUpDown7.Name = "numericUpDown7";
			numericUpDown6.AccessibleDescription = null;
			numericUpDown6.AccessibleName = null;
			resources.ApplyResources(numericUpDown6, "numericUpDown6");
			numericUpDown6.Name = "numericUpDown6";
			numericUpDown5.AccessibleDescription = null;
			numericUpDown5.AccessibleName = null;
			resources.ApplyResources(numericUpDown5, "numericUpDown5");
			numericUpDown5.Name = "numericUpDown5";
			numericUpDown4.AccessibleDescription = null;
			numericUpDown4.AccessibleName = null;
			resources.ApplyResources(numericUpDown4, "numericUpDown4");
			numericUpDown4.Name = "numericUpDown4";
			numericUpDown3.AccessibleDescription = null;
			numericUpDown3.AccessibleName = null;
			resources.ApplyResources(numericUpDown3, "numericUpDown3");
			numericUpDown3.Maximum = new decimal(new int[4] { 9, 0, 0, 0 });
			numericUpDown3.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			numericUpDown3.Name = "numericUpDown3";
			numericUpDown3.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			checkBox8.AccessibleDescription = null;
			checkBox8.AccessibleName = null;
			resources.ApplyResources(checkBox8, "checkBox8");
			checkBox8.BackgroundImage = null;
			checkBox8.Name = "checkBox8";
			checkBox8.UseVisualStyleBackColor = true;
			checkBox6.AccessibleDescription = null;
			checkBox6.AccessibleName = null;
			resources.ApplyResources(checkBox6, "checkBox6");
			checkBox6.BackgroundImage = null;
			checkBox6.Name = "checkBox6";
			checkBox6.UseVisualStyleBackColor = true;
			checkBox7.AccessibleDescription = null;
			checkBox7.AccessibleName = null;
			resources.ApplyResources(checkBox7, "checkBox7");
			checkBox7.BackgroundImage = null;
			checkBox7.Name = "checkBox7";
			checkBox7.UseVisualStyleBackColor = true;
			textBox4.AccessibleDescription = null;
			textBox4.AccessibleName = null;
			resources.ApplyResources(textBox4, "textBox4");
			textBox4.BackgroundImage = null;
			textBox4.Name = "textBox4";
			textBox4.TextChanged += new System.EventHandler(textBox4_TextChanged);
			checkBox5.AccessibleDescription = null;
			checkBox5.AccessibleName = null;
			resources.ApplyResources(checkBox5, "checkBox5");
			checkBox5.BackgroundImage = null;
			checkBox5.Name = "checkBox5";
			checkBox5.UseVisualStyleBackColor = true;
			checkBox4.AccessibleDescription = null;
			checkBox4.AccessibleName = null;
			resources.ApplyResources(checkBox4, "checkBox4");
			checkBox4.BackgroundImage = null;
			checkBox4.Name = "checkBox4";
			checkBox4.UseVisualStyleBackColor = true;
			checkBox3.AccessibleDescription = null;
			checkBox3.AccessibleName = null;
			resources.ApplyResources(checkBox3, "checkBox3");
			checkBox3.BackgroundImage = null;
			checkBox3.Name = "checkBox3";
			checkBox3.UseVisualStyleBackColor = true;
			numericUpDown2.AccessibleDescription = null;
			numericUpDown2.AccessibleName = null;
			resources.ApplyResources(numericUpDown2, "numericUpDown2");
			numericUpDown2.DecimalPlaces = 2;
			numericUpDown2.Name = "numericUpDown2";
			numericUpDown1.AccessibleDescription = null;
			numericUpDown1.AccessibleName = null;
			resources.ApplyResources(numericUpDown1, "numericUpDown1");
			numericUpDown1.Name = "numericUpDown1";
			checkBox2.AccessibleDescription = null;
			checkBox2.AccessibleName = null;
			resources.ApplyResources(checkBox2, "checkBox2");
			checkBox2.BackgroundImage = null;
			checkBox2.Name = "checkBox2";
			checkBox2.UseVisualStyleBackColor = true;
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Name = "textBox1";
			tabPage3.AccessibleDescription = null;
			tabPage3.AccessibleName = null;
			resources.ApplyResources(tabPage3, "tabPage3");
			tabPage3.BackColor = System.Drawing.Color.LightSteelBlue;
			tabPage3.BackgroundImage = null;
			tabPage3.Controls.Add(groupBox10);
			tabPage3.Font = null;
			tabPage3.Name = "tabPage3";
			tabPage3.UseVisualStyleBackColor = true;
			groupBox10.AccessibleDescription = null;
			groupBox10.AccessibleName = null;
			resources.ApplyResources(groupBox10, "groupBox10");
			groupBox10.BackgroundImage = null;
			groupBox10.Controls.Add(numericUpDown14);
			groupBox10.Controls.Add(button9);
			groupBox10.Controls.Add(comboBox10);
			groupBox10.Controls.Add(label45);
			groupBox10.Controls.Add(comboBox11);
			groupBox10.Controls.Add(label46);
			groupBox10.Controls.Add(comboBox9);
			groupBox10.Controls.Add(label44);
			groupBox10.Controls.Add(comboBox8);
			groupBox10.Controls.Add(label43);
			groupBox10.Controls.Add(comboBox6);
			groupBox10.Controls.Add(label42);
			groupBox10.Controls.Add(comboBox7);
			groupBox10.Controls.Add(label41);
			groupBox10.Controls.Add(numericUpDown13);
			groupBox10.Controls.Add(this.label28);
			groupBox10.Controls.Add(this.label27);
			groupBox10.Controls.Add(dataGridView1);
			groupBox10.Font = null;
			groupBox10.Name = "groupBox10";
			groupBox10.TabStop = false;
			numericUpDown14.AccessibleDescription = null;
			numericUpDown14.AccessibleName = null;
			resources.ApplyResources(numericUpDown14, "numericUpDown14");
			numericUpDown14.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			numericUpDown14.Name = "numericUpDown14";
			numericUpDown14.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			button9.AccessibleDescription = null;
			button9.AccessibleName = null;
			resources.ApplyResources(button9, "button9");
			button9.BackgroundImage = null;
			button9.Name = "button9";
			button9.UseVisualStyleBackColor = true;
			button9.Click += new System.EventHandler(button9_Click);
			comboBox10.AccessibleDescription = null;
			comboBox10.AccessibleName = null;
			resources.ApplyResources(comboBox10, "comboBox10");
			comboBox10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox10.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox10.BackgroundImage = null;
			comboBox10.FormattingEnabled = true;
			comboBox10.Name = "comboBox10";
			comboBox11.AccessibleDescription = null;
			comboBox11.AccessibleName = null;
			resources.ApplyResources(comboBox11, "comboBox11");
			comboBox11.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox11.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox11.BackgroundImage = null;
			comboBox11.FormattingEnabled = true;
			comboBox11.Name = "comboBox11";
			comboBox9.AccessibleDescription = null;
			comboBox9.AccessibleName = null;
			resources.ApplyResources(comboBox9, "comboBox9");
			comboBox9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox9.BackgroundImage = null;
			comboBox9.FormattingEnabled = true;
			comboBox9.Name = "comboBox9";
			comboBox8.AccessibleDescription = null;
			comboBox8.AccessibleName = null;
			resources.ApplyResources(comboBox8, "comboBox8");
			comboBox8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox8.BackgroundImage = null;
			comboBox8.FormattingEnabled = true;
			comboBox8.Name = "comboBox8";
			comboBox6.AccessibleDescription = null;
			comboBox6.AccessibleName = null;
			resources.ApplyResources(comboBox6, "comboBox6");
			comboBox6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox6.BackgroundImage = null;
			comboBox6.FormattingEnabled = true;
			comboBox6.Name = "comboBox6";
			comboBox7.AccessibleDescription = null;
			comboBox7.AccessibleName = null;
			resources.ApplyResources(comboBox7, "comboBox7");
			comboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox7.BackgroundImage = null;
			comboBox7.FormattingEnabled = true;
			comboBox7.Name = "comboBox7";
			numericUpDown13.AccessibleDescription = null;
			numericUpDown13.AccessibleName = null;
			resources.ApplyResources(numericUpDown13, "numericUpDown13");
			numericUpDown13.DecimalPlaces = 2;
			numericUpDown13.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			numericUpDown13.Name = "numericUpDown13";
			this.label28.AccessibleDescription = null;
			this.label28.AccessibleName = null;
			resources.ApplyResources(this.label28, "label28");
			this.label28.Name = "label28";
			this.label27.AccessibleDescription = null;
			this.label27.AccessibleName = null;
			resources.ApplyResources(this.label27, "label27");
			this.label27.Name = "label27";
			tabPage4.AccessibleDescription = null;
			tabPage4.AccessibleName = null;
			resources.ApplyResources(tabPage4, "tabPage4");
			tabPage4.BackColor = System.Drawing.Color.LightSteelBlue;
			tabPage4.BackgroundImage = null;
			tabPage4.Controls.Add(groupBox12);
			tabPage4.Font = null;
			tabPage4.Name = "tabPage4";
			tabPage4.UseVisualStyleBackColor = true;
			groupBox12.AccessibleDescription = null;
			groupBox12.AccessibleName = null;
			resources.ApplyResources(groupBox12, "groupBox12");
			groupBox12.BackgroundImage = null;
			groupBox12.Controls.Add(textBox5);
			groupBox12.Controls.Add(this.label36);
			groupBox12.Controls.Add(textBox3);
			groupBox12.Controls.Add(textBox2);
			groupBox12.Controls.Add(this.label47);
			groupBox12.Controls.Add(numericUpDown18);
			groupBox12.Controls.Add(label51);
			groupBox12.Controls.Add(label50);
			groupBox12.Controls.Add(this.label44);
			groupBox12.Controls.Add(numericUpDown17);
			groupBox12.Controls.Add(this.label40);
			groupBox12.Controls.Add(this.label43);
			groupBox12.Controls.Add(numericUpDown15);
			groupBox12.Controls.Add(label49);
			groupBox12.Controls.Add(comboBox16);
			groupBox12.Controls.Add(label48);
			groupBox12.Controls.Add(comboBox17);
			groupBox12.Controls.Add(label47);
			groupBox12.Controls.Add(numericUpDown16);
			groupBox12.Controls.Add(this.label41);
			groupBox12.Controls.Add(this.label42);
			groupBox12.Font = null;
			groupBox12.Name = "groupBox12";
			groupBox12.TabStop = false;
			textBox5.AccessibleDescription = null;
			textBox5.AccessibleName = null;
			resources.ApplyResources(textBox5, "textBox5");
			textBox5.BackgroundImage = null;
			textBox5.Name = "textBox5";
			this.label36.AccessibleDescription = null;
			this.label36.AccessibleName = null;
			resources.ApplyResources(this.label36, "label36");
			this.label36.Name = "label36";
			textBox3.AccessibleDescription = null;
			textBox3.AccessibleName = null;
			resources.ApplyResources(textBox3, "textBox3");
			textBox3.BackgroundImage = null;
			textBox3.Name = "textBox3";
			textBox2.AccessibleDescription = null;
			textBox2.AccessibleName = null;
			resources.ApplyResources(textBox2, "textBox2");
			textBox2.BackgroundImage = null;
			textBox2.Name = "textBox2";
			this.label47.AccessibleDescription = null;
			this.label47.AccessibleName = null;
			resources.ApplyResources(this.label47, "label47");
			this.label47.Name = "label47";
			numericUpDown18.AccessibleDescription = null;
			numericUpDown18.AccessibleName = null;
			resources.ApplyResources(numericUpDown18, "numericUpDown18");
			numericUpDown18.DecimalPlaces = 2;
			numericUpDown18.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			numericUpDown18.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			numericUpDown18.Name = "numericUpDown18";
			this.label44.AccessibleDescription = null;
			this.label44.AccessibleName = null;
			resources.ApplyResources(this.label44, "label44");
			this.label44.Name = "label44";
			numericUpDown17.AccessibleDescription = null;
			numericUpDown17.AccessibleName = null;
			resources.ApplyResources(numericUpDown17, "numericUpDown17");
			numericUpDown17.DecimalPlaces = 2;
			numericUpDown17.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			numericUpDown17.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			numericUpDown17.Name = "numericUpDown17";
			this.label40.AccessibleDescription = null;
			this.label40.AccessibleName = null;
			resources.ApplyResources(this.label40, "label40");
			this.label40.Name = "label40";
			this.label43.AccessibleDescription = null;
			this.label43.AccessibleName = null;
			resources.ApplyResources(this.label43, "label43");
			this.label43.Name = "label43";
			numericUpDown15.AccessibleDescription = null;
			numericUpDown15.AccessibleName = null;
			resources.ApplyResources(numericUpDown15, "numericUpDown15");
			numericUpDown15.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			numericUpDown15.Name = "numericUpDown15";
			numericUpDown15.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			comboBox16.AccessibleDescription = null;
			comboBox16.AccessibleName = null;
			resources.ApplyResources(comboBox16, "comboBox16");
			comboBox16.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox16.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox16.BackgroundImage = null;
			comboBox16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox16.FormattingEnabled = true;
			comboBox16.Items.AddRange(new object[3]
			{
				resources.GetString("comboBox16.Items"),
				resources.GetString("comboBox16.Items1"),
				resources.GetString("comboBox16.Items2")
			});
			comboBox16.Name = "comboBox16";
			comboBox17.AccessibleDescription = null;
			comboBox17.AccessibleName = null;
			resources.ApplyResources(comboBox17, "comboBox17");
			comboBox17.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox17.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox17.BackgroundImage = null;
			comboBox17.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox17.FormattingEnabled = true;
			comboBox17.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox17.Items"),
				resources.GetString("comboBox17.Items1")
			});
			comboBox17.Name = "comboBox17";
			numericUpDown16.AccessibleDescription = null;
			numericUpDown16.AccessibleName = null;
			resources.ApplyResources(numericUpDown16, "numericUpDown16");
			numericUpDown16.DecimalPlaces = 2;
			numericUpDown16.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			numericUpDown16.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			numericUpDown16.Name = "numericUpDown16";
			this.label41.AccessibleDescription = null;
			this.label41.AccessibleName = null;
			resources.ApplyResources(this.label41, "label41");
			this.label41.Name = "label41";
			this.label42.AccessibleDescription = null;
			this.label42.AccessibleName = null;
			resources.ApplyResources(this.label42, "label42");
			this.label42.Name = "label42";
			tabPage9.AccessibleDescription = null;
			tabPage9.AccessibleName = null;
			resources.ApplyResources(tabPage9, "tabPage9");
			tabPage9.BackgroundImage = null;
			tabPage9.Controls.Add(groupBox35);
			tabPage9.Font = null;
			tabPage9.Name = "tabPage9";
			tabPage9.UseVisualStyleBackColor = true;
			groupBox35.AccessibleDescription = null;
			groupBox35.AccessibleName = null;
			resources.ApplyResources(groupBox35, "groupBox35");
			groupBox35.BackColor = System.Drawing.Color.LightSteelBlue;
			groupBox35.BackgroundImage = null;
			groupBox35.Controls.Add(label203);
			groupBox35.Controls.Add(label204);
			groupBox35.Controls.Add(FatsRate);
			groupBox35.Controls.Add(label199);
			groupBox35.Controls.Add(label202);
			groupBox35.Controls.Add(MusclesRate);
			groupBox35.Controls.Add(label197);
			groupBox35.Controls.Add(label198);
			groupBox35.Controls.Add(hieght);
			groupBox35.Controls.Add(label196);
			groupBox35.Controls.Add(Medicin);
			groupBox35.Controls.Add(label195);
			groupBox35.Controls.Add(MedicalStatus);
			groupBox35.Controls.Add(label193);
			groupBox35.Controls.Add(label194);
			groupBox35.Controls.Add(wieght);
			groupBox35.Font = null;
			groupBox35.Name = "groupBox35";
			groupBox35.TabStop = false;
			label203.AccessibleDescription = null;
			label203.AccessibleName = null;
			resources.ApplyResources(label203, "label203");
			label203.Name = "label203";
			label204.AccessibleDescription = null;
			label204.AccessibleName = null;
			resources.ApplyResources(label204, "label204");
			label204.Name = "label204";
			FatsRate.AccessibleDescription = null;
			FatsRate.AccessibleName = null;
			resources.ApplyResources(FatsRate, "FatsRate");
			FatsRate.DecimalPlaces = 2;
			FatsRate.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			FatsRate.Name = "FatsRate";
			label199.AccessibleDescription = null;
			label199.AccessibleName = null;
			resources.ApplyResources(label199, "label199");
			label199.Name = "label199";
			label202.AccessibleDescription = null;
			label202.AccessibleName = null;
			resources.ApplyResources(label202, "label202");
			label202.Name = "label202";
			MusclesRate.AccessibleDescription = null;
			MusclesRate.AccessibleName = null;
			resources.ApplyResources(MusclesRate, "MusclesRate");
			MusclesRate.DecimalPlaces = 2;
			MusclesRate.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			MusclesRate.Name = "MusclesRate";
			label197.AccessibleDescription = null;
			label197.AccessibleName = null;
			resources.ApplyResources(label197, "label197");
			label197.Name = "label197";
			label198.AccessibleDescription = null;
			label198.AccessibleName = null;
			resources.ApplyResources(label198, "label198");
			label198.Name = "label198";
			hieght.AccessibleDescription = null;
			hieght.AccessibleName = null;
			resources.ApplyResources(hieght, "hieght");
			hieght.DecimalPlaces = 2;
			hieght.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			hieght.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			hieght.Name = "hieght";
			label196.AccessibleDescription = null;
			label196.AccessibleName = null;
			resources.ApplyResources(label196, "label196");
			label196.Name = "label196";
			Medicin.AccessibleDescription = null;
			Medicin.AccessibleName = null;
			resources.ApplyResources(Medicin, "Medicin");
			Medicin.BackgroundImage = null;
			Medicin.Name = "Medicin";
			label195.AccessibleDescription = null;
			label195.AccessibleName = null;
			resources.ApplyResources(label195, "label195");
			label195.Name = "label195";
			MedicalStatus.AccessibleDescription = null;
			MedicalStatus.AccessibleName = null;
			resources.ApplyResources(MedicalStatus, "MedicalStatus");
			MedicalStatus.BackgroundImage = null;
			MedicalStatus.Name = "MedicalStatus";
			label193.AccessibleDescription = null;
			label193.AccessibleName = null;
			resources.ApplyResources(label193, "label193");
			label193.Name = "label193";
			label194.AccessibleDescription = null;
			label194.AccessibleName = null;
			resources.ApplyResources(label194, "label194");
			label194.Name = "label194";
			wieght.AccessibleDescription = null;
			wieght.AccessibleName = null;
			resources.ApplyResources(wieght, "wieght");
			wieght.DecimalPlaces = 2;
			wieght.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			wieght.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			wieght.Name = "wieght";
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			resources.ApplyResources(openFileDialog1, "openFileDialog1");
			tabPage5.AccessibleDescription = null;
			tabPage5.AccessibleName = null;
			resources.ApplyResources(tabPage5, "tabPage5");
			tabPage5.BackColor = System.Drawing.Color.LightSteelBlue;
			tabPage5.BackgroundImage = null;
			tabPage5.Controls.Add(groupBox13);
			tabPage5.Controls.Add(button13);
			tabPage5.Controls.Add(groupBox14);
			tabPage5.Controls.Add(groupBox15);
			tabPage5.Controls.Add(button18);
			tabPage5.Controls.Add(button19);
			tabPage5.Controls.Add(groupBox17);
			tabPage5.Controls.Add(groupBox18);
			tabPage5.Controls.Add(groupBox19);
			tabPage5.Controls.Add(groupBox20);
			tabPage5.Font = null;
			tabPage5.Name = "tabPage5";
			groupBox13.AccessibleDescription = null;
			groupBox13.AccessibleName = null;
			resources.ApplyResources(groupBox13, "groupBox13");
			groupBox13.BackColor = System.Drawing.Color.Transparent;
			groupBox13.BackgroundImage = null;
			groupBox13.Controls.Add(checkedListBox4);
			groupBox13.Name = "groupBox13";
			groupBox13.TabStop = false;
			checkedListBox4.AccessibleDescription = null;
			checkedListBox4.AccessibleName = null;
			resources.ApplyResources(checkedListBox4, "checkedListBox4");
			checkedListBox4.BackColor = System.Drawing.SystemColors.ActiveCaption;
			checkedListBox4.BackgroundImage = null;
			checkedListBox4.CheckOnClick = true;
			checkedListBox4.Font = null;
			checkedListBox4.FormattingEnabled = true;
			checkedListBox4.Name = "checkedListBox4";
			checkedListBox4.ThreeDCheckBoxes = true;
			button13.AccessibleDescription = null;
			button13.AccessibleName = null;
			resources.ApplyResources(button13, "button13");
			button13.BackColor = System.Drawing.Color.Gainsboro;
			button13.BackgroundImage = null;
			button13.Name = "button13";
			button13.UseVisualStyleBackColor = false;
			groupBox14.AccessibleDescription = null;
			groupBox14.AccessibleName = null;
			resources.ApplyResources(groupBox14, "groupBox14");
			groupBox14.BackColor = System.Drawing.Color.LightSteelBlue;
			groupBox14.BackgroundImage = null;
			groupBox14.Controls.Add(this.label55);
			groupBox14.Font = null;
			groupBox14.Name = "groupBox14";
			groupBox14.TabStop = false;
			this.label55.AccessibleDescription = null;
			this.label55.AccessibleName = null;
			resources.ApplyResources(this.label55, "label55");
			this.label55.BackColor = System.Drawing.Color.Transparent;
			this.label55.Name = "label55";
			groupBox15.AccessibleDescription = null;
			groupBox15.AccessibleName = null;
			resources.ApplyResources(groupBox15, "groupBox15");
			groupBox15.BackColor = System.Drawing.Color.LightSteelBlue;
			groupBox15.BackgroundImage = null;
			groupBox15.Controls.Add(button14);
			groupBox15.Controls.Add(button15);
			groupBox15.Controls.Add(checkBox13);
			groupBox15.Controls.Add(textBox6);
			groupBox15.Controls.Add(label59);
			groupBox15.Controls.Add(panel4);
			groupBox15.Controls.Add(radioButton6);
			groupBox15.Controls.Add(radioButton7);
			groupBox15.Controls.Add(comboBox15);
			groupBox15.Controls.Add(comboBox18);
			groupBox15.Controls.Add(comboBox19);
			groupBox15.Controls.Add(floatText3);
			groupBox15.Controls.Add(label61);
			groupBox15.Controls.Add(label62);
			groupBox15.Controls.Add(panel5);
			groupBox15.Controls.Add(textBox7);
			groupBox15.Controls.Add(label64);
			groupBox15.Controls.Add(button16);
			groupBox15.Controls.Add(groupBox16);
			groupBox15.Controls.Add(radioButton8);
			groupBox15.Controls.Add(radioButton9);
			groupBox15.Controls.Add(radioButton10);
			groupBox15.Controls.Add(label65);
			groupBox15.Controls.Add(textBox8);
			groupBox15.Controls.Add(checkBox14);
			groupBox15.Controls.Add(textBox9);
			groupBox15.Controls.Add(label66);
			groupBox15.Controls.Add(comboBox21);
			groupBox15.Controls.Add(label67);
			groupBox15.Controls.Add(button17);
			groupBox15.Controls.Add(label68);
			groupBox15.Controls.Add(comboBox22);
			groupBox15.Controls.Add(comboBox23);
			groupBox15.Controls.Add(label69);
			groupBox15.Controls.Add(dateTimePicker3);
			groupBox15.Controls.Add(label70);
			groupBox15.Controls.Add(textBox10);
			groupBox15.Controls.Add(label71);
			groupBox15.Controls.Add(comboBox24);
			groupBox15.Controls.Add(label72);
			groupBox15.Controls.Add(label73);
			groupBox15.Controls.Add(textBox11);
			groupBox15.Controls.Add(label74);
			groupBox15.Controls.Add(label75);
			groupBox15.Controls.Add(label76);
			groupBox15.Controls.Add(label77);
			groupBox15.Controls.Add(comboBox25);
			groupBox15.Controls.Add(label78);
			groupBox15.Controls.Add(label79);
			groupBox15.Controls.Add(textBox12);
			groupBox15.Controls.Add(dateTimePicker4);
			groupBox15.Controls.Add(label80);
			groupBox15.Controls.Add(label81);
			groupBox15.Controls.Add(textBox13);
			groupBox15.Controls.Add(textBox14);
			groupBox15.Controls.Add(label82);
			groupBox15.ForeColor = System.Drawing.Color.Black;
			groupBox15.Name = "groupBox15";
			groupBox15.TabStop = false;
			button14.AccessibleDescription = null;
			button14.AccessibleName = null;
			resources.ApplyResources(button14, "button14");
			button14.BackgroundImage = null;
			button14.Font = null;
			button14.Name = "button14";
			button14.UseVisualStyleBackColor = true;
			button15.AccessibleDescription = null;
			button15.AccessibleName = null;
			resources.ApplyResources(button15, "button15");
			button15.BackgroundImage = null;
			button15.Font = null;
			button15.Name = "button15";
			button15.UseVisualStyleBackColor = true;
			checkBox13.AccessibleDescription = null;
			checkBox13.AccessibleName = null;
			resources.ApplyResources(checkBox13, "checkBox13");
			checkBox13.BackgroundImage = null;
			checkBox13.Checked = true;
			checkBox13.CheckState = System.Windows.Forms.CheckState.Checked;
			checkBox13.Font = null;
			checkBox13.Name = "checkBox13";
			checkBox13.UseVisualStyleBackColor = true;
			textBox6.AccessibleDescription = null;
			textBox6.AccessibleName = null;
			resources.ApplyResources(textBox6, "textBox6");
			textBox6.BackgroundImage = null;
			textBox6.Name = "textBox6";
			panel4.AccessibleDescription = null;
			panel4.AccessibleName = null;
			resources.ApplyResources(panel4, "panel4");
			panel4.BackgroundImage = null;
			panel4.Controls.Add(label60);
			panel4.Controls.Add(comboBox14);
			panel4.Font = null;
			panel4.Name = "panel4";
			comboBox14.AccessibleDescription = null;
			comboBox14.AccessibleName = null;
			resources.ApplyResources(comboBox14, "comboBox14");
			comboBox14.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox14.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox14.BackgroundImage = null;
			comboBox14.FormattingEnabled = true;
			comboBox14.Name = "comboBox14";
			radioButton6.AccessibleDescription = null;
			radioButton6.AccessibleName = null;
			resources.ApplyResources(radioButton6, "radioButton6");
			radioButton6.BackgroundImage = null;
			radioButton6.Name = "radioButton6";
			radioButton6.UseVisualStyleBackColor = true;
			radioButton7.AccessibleDescription = null;
			radioButton7.AccessibleName = null;
			resources.ApplyResources(radioButton7, "radioButton7");
			radioButton7.BackgroundImage = null;
			radioButton7.Checked = true;
			radioButton7.Name = "radioButton7";
			radioButton7.TabStop = true;
			radioButton7.UseVisualStyleBackColor = true;
			comboBox15.AccessibleDescription = null;
			comboBox15.AccessibleName = null;
			resources.ApplyResources(comboBox15, "comboBox15");
			comboBox15.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox15.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox15.BackgroundImage = null;
			comboBox15.FormattingEnabled = true;
			comboBox15.Name = "comboBox15";
			comboBox18.AccessibleDescription = null;
			comboBox18.AccessibleName = null;
			resources.ApplyResources(comboBox18, "comboBox18");
			comboBox18.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox18.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox18.BackgroundImage = null;
			comboBox18.FormattingEnabled = true;
			comboBox18.Name = "comboBox18";
			comboBox19.AccessibleDescription = null;
			comboBox19.AccessibleName = null;
			resources.ApplyResources(comboBox19, "comboBox19");
			comboBox19.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox19.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox19.BackgroundImage = null;
			comboBox19.FormattingEnabled = true;
			comboBox19.Name = "comboBox19";
			floatText3.AccessibleDescription = null;
			floatText3.AccessibleName = null;
			resources.ApplyResources(floatText3, "floatText3");
			floatText3.BackgroundImage = null;
			floatText3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText3.Font = null;
			floatText3.Name = "floatText3";
			panel5.AccessibleDescription = null;
			panel5.AccessibleName = null;
			resources.ApplyResources(panel5, "panel5");
			panel5.BackgroundImage = null;
			panel5.Controls.Add(label63);
			panel5.Controls.Add(floatText4);
			panel5.Controls.Add(this.label61);
			panel5.Controls.Add(comboBox20);
			panel5.Font = null;
			panel5.Name = "panel5";
			floatText4.AccessibleDescription = null;
			floatText4.AccessibleName = null;
			resources.ApplyResources(floatText4, "floatText4");
			floatText4.BackgroundImage = null;
			floatText4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText4.Font = null;
			floatText4.Name = "floatText4";
			this.label61.AccessibleDescription = null;
			this.label61.AccessibleName = null;
			resources.ApplyResources(this.label61, "label61");
			this.label61.Name = "label61";
			comboBox20.AccessibleDescription = null;
			comboBox20.AccessibleName = null;
			resources.ApplyResources(comboBox20, "comboBox20");
			comboBox20.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox20.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox20.BackgroundImage = null;
			comboBox20.FormattingEnabled = true;
			comboBox20.Name = "comboBox20";
			textBox7.AccessibleDescription = null;
			textBox7.AccessibleName = null;
			resources.ApplyResources(textBox7, "textBox7");
			textBox7.BackgroundImage = null;
			textBox7.Font = null;
			textBox7.ForeColor = System.Drawing.Color.Maroon;
			textBox7.Name = "textBox7";
			textBox7.ReadOnly = true;
			button16.AccessibleDescription = null;
			button16.AccessibleName = null;
			resources.ApplyResources(button16, "button16");
			button16.BackColor = System.Drawing.Color.Transparent;
			button16.BackgroundImage = null;
			button16.Cursor = System.Windows.Forms.Cursors.Hand;
			button16.Name = "button16";
			button16.UseVisualStyleBackColor = false;
			groupBox16.AccessibleDescription = null;
			groupBox16.AccessibleName = null;
			resources.ApplyResources(groupBox16, "groupBox16");
			groupBox16.BackColor = System.Drawing.Color.Transparent;
			groupBox16.BackgroundImage = null;
			groupBox16.Controls.Add(pictureBox2);
			groupBox16.Name = "groupBox16";
			groupBox16.TabStop = false;
			pictureBox2.AccessibleDescription = null;
			pictureBox2.AccessibleName = null;
			resources.ApplyResources(pictureBox2, "pictureBox2");
			pictureBox2.BackColor = System.Drawing.Color.Transparent;
			pictureBox2.BackgroundImage = null;
			pictureBox2.Font = null;
			pictureBox2.ImageLocation = null;
			pictureBox2.Name = "pictureBox2";
			pictureBox2.TabStop = false;
			radioButton8.AccessibleDescription = null;
			radioButton8.AccessibleName = null;
			resources.ApplyResources(radioButton8, "radioButton8");
			radioButton8.BackgroundImage = null;
			radioButton8.Name = "radioButton8";
			radioButton8.UseVisualStyleBackColor = true;
			radioButton9.AccessibleDescription = null;
			radioButton9.AccessibleName = null;
			resources.ApplyResources(radioButton9, "radioButton9");
			radioButton9.BackgroundImage = null;
			radioButton9.Name = "radioButton9";
			radioButton9.UseVisualStyleBackColor = true;
			radioButton10.AccessibleDescription = null;
			radioButton10.AccessibleName = null;
			resources.ApplyResources(radioButton10, "radioButton10");
			radioButton10.BackgroundImage = null;
			radioButton10.Name = "radioButton10";
			radioButton10.UseVisualStyleBackColor = true;
			textBox8.AccessibleDescription = null;
			textBox8.AccessibleName = null;
			resources.ApplyResources(textBox8, "textBox8");
			textBox8.BackgroundImage = null;
			textBox8.Font = null;
			textBox8.ForeColor = System.Drawing.Color.Maroon;
			textBox8.Name = "textBox8";
			textBox8.ReadOnly = true;
			checkBox14.AccessibleDescription = null;
			checkBox14.AccessibleName = null;
			resources.ApplyResources(checkBox14, "checkBox14");
			checkBox14.BackgroundImage = null;
			checkBox14.Checked = true;
			checkBox14.CheckState = System.Windows.Forms.CheckState.Checked;
			checkBox14.Font = null;
			checkBox14.Name = "checkBox14";
			checkBox14.UseVisualStyleBackColor = true;
			textBox9.AccessibleDescription = null;
			textBox9.AccessibleName = null;
			resources.ApplyResources(textBox9, "textBox9");
			textBox9.BackgroundImage = null;
			textBox9.Name = "textBox9";
			comboBox21.AccessibleDescription = null;
			comboBox21.AccessibleName = null;
			resources.ApplyResources(comboBox21, "comboBox21");
			comboBox21.BackgroundImage = null;
			comboBox21.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox21.FormattingEnabled = true;
			comboBox21.Name = "comboBox21";
			button17.AccessibleDescription = null;
			button17.AccessibleName = null;
			resources.ApplyResources(button17, "button17");
			button17.BackgroundImage = null;
			button17.Font = null;
			button17.Name = "button17";
			button17.UseVisualStyleBackColor = true;
			comboBox22.AccessibleDescription = null;
			comboBox22.AccessibleName = null;
			resources.ApplyResources(comboBox22, "comboBox22");
			comboBox22.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox22.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox22.BackgroundImage = null;
			comboBox22.FormattingEnabled = true;
			comboBox22.Name = "comboBox22";
			comboBox23.AccessibleDescription = null;
			comboBox23.AccessibleName = null;
			resources.ApplyResources(comboBox23, "comboBox23");
			comboBox23.BackgroundImage = null;
			comboBox23.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox23.FormattingEnabled = true;
			comboBox23.Items.AddRange(new object[3]
			{
				resources.GetString("comboBox23.Items"),
				resources.GetString("comboBox23.Items1"),
				resources.GetString("comboBox23.Items2")
			});
			comboBox23.Name = "comboBox23";
			dateTimePicker3.AccessibleDescription = null;
			dateTimePicker3.AccessibleName = null;
			resources.ApplyResources(dateTimePicker3, "dateTimePicker3");
			dateTimePicker3.BackgroundImage = null;
			dateTimePicker3.CalendarFont = null;
			dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker3.Name = "dateTimePicker3";
			textBox10.AccessibleDescription = null;
			textBox10.AccessibleName = null;
			resources.ApplyResources(textBox10, "textBox10");
			textBox10.BackgroundImage = null;
			textBox10.Name = "textBox10";
			comboBox24.AccessibleDescription = null;
			comboBox24.AccessibleName = null;
			resources.ApplyResources(comboBox24, "comboBox24");
			comboBox24.BackgroundImage = null;
			comboBox24.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox24.FormattingEnabled = true;
			comboBox24.Items.AddRange(new object[7]
			{
				resources.GetString("comboBox24.Items"),
				resources.GetString("comboBox24.Items1"),
				resources.GetString("comboBox24.Items2"),
				resources.GetString("comboBox24.Items3"),
				resources.GetString("comboBox24.Items4"),
				resources.GetString("comboBox24.Items5"),
				resources.GetString("comboBox24.Items6")
			});
			comboBox24.Name = "comboBox24";
			textBox11.AccessibleDescription = null;
			textBox11.AccessibleName = null;
			resources.ApplyResources(textBox11, "textBox11");
			textBox11.BackgroundImage = null;
			textBox11.Name = "textBox11";
			comboBox25.AccessibleDescription = null;
			comboBox25.AccessibleName = null;
			resources.ApplyResources(comboBox25, "comboBox25");
			comboBox25.BackgroundImage = null;
			comboBox25.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox25.FormattingEnabled = true;
			comboBox25.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox25.Items"),
				resources.GetString("comboBox25.Items1")
			});
			comboBox25.Name = "comboBox25";
			textBox12.AccessibleDescription = null;
			textBox12.AccessibleName = null;
			resources.ApplyResources(textBox12, "textBox12");
			textBox12.BackgroundImage = null;
			textBox12.Name = "textBox12";
			dateTimePicker4.AccessibleDescription = null;
			dateTimePicker4.AccessibleName = null;
			resources.ApplyResources(dateTimePicker4, "dateTimePicker4");
			dateTimePicker4.BackgroundImage = null;
			dateTimePicker4.CalendarFont = null;
			dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker4.Name = "dateTimePicker4";
			textBox13.AccessibleDescription = null;
			textBox13.AccessibleName = null;
			resources.ApplyResources(textBox13, "textBox13");
			textBox13.BackgroundImage = null;
			textBox13.Name = "textBox13";
			textBox14.AccessibleDescription = null;
			textBox14.AccessibleName = null;
			resources.ApplyResources(textBox14, "textBox14");
			textBox14.BackgroundImage = null;
			textBox14.Name = "textBox14";
			button18.AccessibleDescription = null;
			button18.AccessibleName = null;
			resources.ApplyResources(button18, "button18");
			button18.BackColor = System.Drawing.Color.Gainsboro;
			button18.BackgroundImage = null;
			button18.Name = "button18";
			button18.UseVisualStyleBackColor = false;
			button19.AccessibleDescription = null;
			button19.AccessibleName = null;
			resources.ApplyResources(button19, "button19");
			button19.BackColor = System.Drawing.Color.Gainsboro;
			button19.BackgroundImage = null;
			button19.Name = "button19";
			button19.UseVisualStyleBackColor = false;
			groupBox17.AccessibleDescription = null;
			groupBox17.AccessibleName = null;
			resources.ApplyResources(groupBox17, "groupBox17");
			groupBox17.BackColor = System.Drawing.Color.Transparent;
			groupBox17.BackgroundImage = null;
			groupBox17.Controls.Add(checkedListBox5);
			groupBox17.Name = "groupBox17";
			groupBox17.TabStop = false;
			checkedListBox5.AccessibleDescription = null;
			checkedListBox5.AccessibleName = null;
			resources.ApplyResources(checkedListBox5, "checkedListBox5");
			checkedListBox5.BackColor = System.Drawing.SystemColors.ActiveCaption;
			checkedListBox5.BackgroundImage = null;
			checkedListBox5.CheckOnClick = true;
			checkedListBox5.Font = null;
			checkedListBox5.FormattingEnabled = true;
			checkedListBox5.Name = "checkedListBox5";
			groupBox18.AccessibleDescription = null;
			groupBox18.AccessibleName = null;
			resources.ApplyResources(groupBox18, "groupBox18");
			groupBox18.BackColor = System.Drawing.Color.Transparent;
			groupBox18.BackgroundImage = null;
			groupBox18.Controls.Add(checkBox15);
			groupBox18.Controls.Add(checkBox16);
			groupBox18.Controls.Add(checkBox17);
			groupBox18.Controls.Add(checkBox18);
			groupBox18.Controls.Add(textBox15);
			groupBox18.Controls.Add(label83);
			groupBox18.Controls.Add(checkBox19);
			groupBox18.Controls.Add(checkBox20);
			groupBox18.Controls.Add(checkBox21);
			groupBox18.Controls.Add(checkBox22);
			groupBox18.Controls.Add(checkBox23);
			groupBox18.Controls.Add(checkBox24);
			groupBox18.Controls.Add(checkBox25);
			groupBox18.Name = "groupBox18";
			groupBox18.TabStop = false;
			checkBox15.AccessibleDescription = null;
			checkBox15.AccessibleName = null;
			resources.ApplyResources(checkBox15, "checkBox15");
			checkBox15.BackgroundImage = null;
			checkBox15.Name = "checkBox15";
			checkBox15.UseVisualStyleBackColor = true;
			checkBox16.AccessibleDescription = null;
			checkBox16.AccessibleName = null;
			resources.ApplyResources(checkBox16, "checkBox16");
			checkBox16.BackgroundImage = null;
			checkBox16.Name = "checkBox16";
			checkBox16.UseVisualStyleBackColor = true;
			checkBox17.AccessibleDescription = null;
			checkBox17.AccessibleName = null;
			resources.ApplyResources(checkBox17, "checkBox17");
			checkBox17.BackgroundImage = null;
			checkBox17.Name = "checkBox17";
			checkBox17.UseVisualStyleBackColor = true;
			checkBox18.AccessibleDescription = null;
			checkBox18.AccessibleName = null;
			resources.ApplyResources(checkBox18, "checkBox18");
			checkBox18.BackgroundImage = null;
			checkBox18.Name = "checkBox18";
			checkBox18.UseVisualStyleBackColor = true;
			textBox15.AccessibleDescription = null;
			textBox15.AccessibleName = null;
			resources.ApplyResources(textBox15, "textBox15");
			textBox15.BackgroundImage = null;
			textBox15.Font = null;
			textBox15.Name = "textBox15";
			checkBox19.AccessibleDescription = null;
			checkBox19.AccessibleName = null;
			resources.ApplyResources(checkBox19, "checkBox19");
			checkBox19.BackgroundImage = null;
			checkBox19.Name = "checkBox19";
			checkBox19.UseVisualStyleBackColor = true;
			checkBox20.AccessibleDescription = null;
			checkBox20.AccessibleName = null;
			resources.ApplyResources(checkBox20, "checkBox20");
			checkBox20.BackgroundImage = null;
			checkBox20.Name = "checkBox20";
			checkBox20.UseVisualStyleBackColor = true;
			checkBox21.AccessibleDescription = null;
			checkBox21.AccessibleName = null;
			resources.ApplyResources(checkBox21, "checkBox21");
			checkBox21.BackgroundImage = null;
			checkBox21.Name = "checkBox21";
			checkBox21.UseVisualStyleBackColor = true;
			checkBox22.AccessibleDescription = null;
			checkBox22.AccessibleName = null;
			resources.ApplyResources(checkBox22, "checkBox22");
			checkBox22.BackgroundImage = null;
			checkBox22.Name = "checkBox22";
			checkBox22.UseVisualStyleBackColor = true;
			checkBox23.AccessibleDescription = null;
			checkBox23.AccessibleName = null;
			resources.ApplyResources(checkBox23, "checkBox23");
			checkBox23.BackgroundImage = null;
			checkBox23.Name = "checkBox23";
			checkBox23.UseVisualStyleBackColor = true;
			checkBox24.AccessibleDescription = null;
			checkBox24.AccessibleName = null;
			resources.ApplyResources(checkBox24, "checkBox24");
			checkBox24.BackgroundImage = null;
			checkBox24.Name = "checkBox24";
			checkBox24.UseVisualStyleBackColor = true;
			checkBox25.AccessibleDescription = null;
			checkBox25.AccessibleName = null;
			resources.ApplyResources(checkBox25, "checkBox25");
			checkBox25.BackgroundImage = null;
			checkBox25.Name = "checkBox25";
			checkBox25.UseVisualStyleBackColor = true;
			groupBox19.AccessibleDescription = null;
			groupBox19.AccessibleName = null;
			resources.ApplyResources(groupBox19, "groupBox19");
			groupBox19.BackColor = System.Drawing.Color.Transparent;
			groupBox19.BackgroundImage = null;
			groupBox19.Controls.Add(checkedListBox6);
			groupBox19.Name = "groupBox19";
			groupBox19.TabStop = false;
			checkedListBox6.AccessibleDescription = null;
			checkedListBox6.AccessibleName = null;
			resources.ApplyResources(checkedListBox6, "checkedListBox6");
			checkedListBox6.BackColor = System.Drawing.SystemColors.ActiveCaption;
			checkedListBox6.BackgroundImage = null;
			checkedListBox6.CheckOnClick = true;
			checkedListBox6.Font = null;
			checkedListBox6.FormattingEnabled = true;
			checkedListBox6.Name = "checkedListBox6";
			checkedListBox6.UseCompatibleTextRendering = true;
			groupBox20.AccessibleDescription = null;
			groupBox20.AccessibleName = null;
			resources.ApplyResources(groupBox20, "groupBox20");
			groupBox20.BackColor = System.Drawing.Color.Transparent;
			groupBox20.BackgroundImage = null;
			groupBox20.Controls.Add(checkBox26);
			groupBox20.Controls.Add(checkBox27);
			groupBox20.Controls.Add(textBox16);
			groupBox20.Controls.Add(checkBox28);
			groupBox20.Controls.Add(checkBox29);
			groupBox20.Controls.Add(checkBox30);
			groupBox20.Controls.Add(checkBox31);
			groupBox20.Controls.Add(checkBox32);
			groupBox20.Name = "groupBox20";
			groupBox20.TabStop = false;
			checkBox26.AccessibleDescription = null;
			checkBox26.AccessibleName = null;
			resources.ApplyResources(checkBox26, "checkBox26");
			checkBox26.BackgroundImage = null;
			checkBox26.Name = "checkBox26";
			checkBox26.UseVisualStyleBackColor = true;
			checkBox27.AccessibleDescription = null;
			checkBox27.AccessibleName = null;
			resources.ApplyResources(checkBox27, "checkBox27");
			checkBox27.BackgroundImage = null;
			checkBox27.Name = "checkBox27";
			checkBox27.UseVisualStyleBackColor = true;
			textBox16.AccessibleDescription = null;
			textBox16.AccessibleName = null;
			resources.ApplyResources(textBox16, "textBox16");
			textBox16.BackgroundImage = null;
			textBox16.Font = null;
			textBox16.Name = "textBox16";
			checkBox28.AccessibleDescription = null;
			checkBox28.AccessibleName = null;
			resources.ApplyResources(checkBox28, "checkBox28");
			checkBox28.BackgroundImage = null;
			checkBox28.Name = "checkBox28";
			checkBox28.UseVisualStyleBackColor = true;
			checkBox29.AccessibleDescription = null;
			checkBox29.AccessibleName = null;
			resources.ApplyResources(checkBox29, "checkBox29");
			checkBox29.BackgroundImage = null;
			checkBox29.Name = "checkBox29";
			checkBox29.UseVisualStyleBackColor = true;
			checkBox30.AccessibleDescription = null;
			checkBox30.AccessibleName = null;
			resources.ApplyResources(checkBox30, "checkBox30");
			checkBox30.BackgroundImage = null;
			checkBox30.Name = "checkBox30";
			checkBox30.UseVisualStyleBackColor = true;
			checkBox31.AccessibleDescription = null;
			checkBox31.AccessibleName = null;
			resources.ApplyResources(checkBox31, "checkBox31");
			checkBox31.BackgroundImage = null;
			checkBox31.Name = "checkBox31";
			checkBox31.UseVisualStyleBackColor = true;
			checkBox32.AccessibleDescription = null;
			checkBox32.AccessibleName = null;
			resources.ApplyResources(checkBox32, "checkBox32");
			checkBox32.BackgroundImage = null;
			checkBox32.Name = "checkBox32";
			checkBox32.UseVisualStyleBackColor = true;
			tabPage6.AccessibleDescription = null;
			tabPage6.AccessibleName = null;
			resources.ApplyResources(tabPage6, "tabPage6");
			tabPage6.BackColor = System.Drawing.Color.LightSteelBlue;
			tabPage6.BackgroundImage = null;
			tabPage6.Controls.Add(groupBox21);
			tabPage6.Font = null;
			tabPage6.Name = "tabPage6";
			tabPage6.UseVisualStyleBackColor = true;
			groupBox21.AccessibleDescription = null;
			groupBox21.AccessibleName = null;
			resources.ApplyResources(groupBox21, "groupBox21");
			groupBox21.BackgroundImage = null;
			groupBox21.Controls.Add(comboBox26);
			groupBox21.Controls.Add(comboBox27);
			groupBox21.Controls.Add(label84);
			groupBox21.Controls.Add(dateTimePicker5);
			groupBox21.Controls.Add(label85);
			groupBox21.Controls.Add(comboBox28);
			groupBox21.Controls.Add(label86);
			groupBox21.Controls.Add(comboBox29);
			groupBox21.Controls.Add(label87);
			groupBox21.Controls.Add(comboBox30);
			groupBox21.Controls.Add(label88);
			groupBox21.Controls.Add(checkBox33);
			groupBox21.Controls.Add(dateTimePicker6);
			groupBox21.Controls.Add(label89);
			groupBox21.Controls.Add(numericUpDown19);
			groupBox21.Controls.Add(label90);
			groupBox21.Controls.Add(checkBox34);
			groupBox21.Controls.Add(numericUpDown20);
			groupBox21.Controls.Add(label91);
			groupBox21.Controls.Add(comboBox31);
			groupBox21.Controls.Add(label92);
			groupBox21.Controls.Add(numericUpDown21);
			groupBox21.Controls.Add(numericUpDown22);
			groupBox21.Controls.Add(numericUpDown23);
			groupBox21.Controls.Add(label93);
			groupBox21.Controls.Add(numericUpDown24);
			groupBox21.Controls.Add(label94);
			groupBox21.Controls.Add(label95);
			groupBox21.Controls.Add(label96);
			groupBox21.Controls.Add(numericUpDown25);
			groupBox21.Controls.Add(numericUpDown26);
			groupBox21.Controls.Add(label97);
			groupBox21.Controls.Add(numericUpDown27);
			groupBox21.Controls.Add(label98);
			groupBox21.Controls.Add(numericUpDown28);
			groupBox21.Controls.Add(label99);
			groupBox21.Controls.Add(checkBox35);
			groupBox21.Controls.Add(label100);
			groupBox21.Controls.Add(checkBox36);
			groupBox21.Controls.Add(checkBox37);
			groupBox21.Controls.Add(textBox17);
			groupBox21.Controls.Add(checkBox38);
			groupBox21.Controls.Add(checkBox39);
			groupBox21.Controls.Add(checkBox40);
			groupBox21.Controls.Add(label101);
			groupBox21.Controls.Add(label102);
			groupBox21.Controls.Add(numericUpDown29);
			groupBox21.Controls.Add(numericUpDown30);
			groupBox21.Controls.Add(checkBox41);
			groupBox21.Controls.Add(label103);
			groupBox21.Controls.Add(label104);
			groupBox21.Controls.Add(label105);
			groupBox21.Controls.Add(textBox18);
			groupBox21.Name = "groupBox21";
			groupBox21.TabStop = false;
			comboBox26.AccessibleDescription = null;
			comboBox26.AccessibleName = null;
			resources.ApplyResources(comboBox26, "comboBox26");
			comboBox26.BackgroundImage = null;
			comboBox26.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox26.Font = null;
			comboBox26.FormattingEnabled = true;
			comboBox26.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox26.Items"),
				resources.GetString("comboBox26.Items1")
			});
			comboBox26.Name = "comboBox26";
			comboBox27.AccessibleDescription = null;
			comboBox27.AccessibleName = null;
			resources.ApplyResources(comboBox27, "comboBox27");
			comboBox27.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox27.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox27.BackgroundImage = null;
			comboBox27.Font = null;
			comboBox27.FormattingEnabled = true;
			comboBox27.Name = "comboBox27";
			dateTimePicker5.AccessibleDescription = null;
			dateTimePicker5.AccessibleName = null;
			resources.ApplyResources(dateTimePicker5, "dateTimePicker5");
			dateTimePicker5.BackgroundImage = null;
			dateTimePicker5.CalendarFont = null;
			dateTimePicker5.CustomFormat = null;
			dateTimePicker5.Font = null;
			dateTimePicker5.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			dateTimePicker5.Name = "dateTimePicker5";
			comboBox28.AccessibleDescription = null;
			comboBox28.AccessibleName = null;
			resources.ApplyResources(comboBox28, "comboBox28");
			comboBox28.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox28.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox28.BackgroundImage = null;
			comboBox28.Font = null;
			comboBox28.FormattingEnabled = true;
			comboBox28.Name = "comboBox28";
			comboBox29.AccessibleDescription = null;
			comboBox29.AccessibleName = null;
			resources.ApplyResources(comboBox29, "comboBox29");
			comboBox29.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox29.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox29.BackgroundImage = null;
			comboBox29.Font = null;
			comboBox29.FormattingEnabled = true;
			comboBox29.Name = "comboBox29";
			comboBox30.AccessibleDescription = null;
			comboBox30.AccessibleName = null;
			resources.ApplyResources(comboBox30, "comboBox30");
			comboBox30.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox30.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox30.BackgroundImage = null;
			comboBox30.Font = null;
			comboBox30.FormattingEnabled = true;
			comboBox30.Name = "comboBox30";
			checkBox33.AccessibleDescription = null;
			checkBox33.AccessibleName = null;
			resources.ApplyResources(checkBox33, "checkBox33");
			checkBox33.BackgroundImage = null;
			checkBox33.Name = "checkBox33";
			checkBox33.UseVisualStyleBackColor = true;
			dateTimePicker6.AccessibleDescription = null;
			dateTimePicker6.AccessibleName = null;
			resources.ApplyResources(dateTimePicker6, "dateTimePicker6");
			dateTimePicker6.BackgroundImage = null;
			dateTimePicker6.CalendarFont = null;
			dateTimePicker6.CustomFormat = null;
			dateTimePicker6.Font = null;
			dateTimePicker6.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			dateTimePicker6.Name = "dateTimePicker6";
			numericUpDown19.AccessibleDescription = null;
			numericUpDown19.AccessibleName = null;
			resources.ApplyResources(numericUpDown19, "numericUpDown19");
			numericUpDown19.DecimalPlaces = 2;
			numericUpDown19.Font = null;
			numericUpDown19.Name = "numericUpDown19";
			checkBox34.AccessibleDescription = null;
			checkBox34.AccessibleName = null;
			resources.ApplyResources(checkBox34, "checkBox34");
			checkBox34.BackgroundImage = null;
			checkBox34.Name = "checkBox34";
			checkBox34.UseVisualStyleBackColor = true;
			numericUpDown20.AccessibleDescription = null;
			numericUpDown20.AccessibleName = null;
			resources.ApplyResources(numericUpDown20, "numericUpDown20");
			numericUpDown20.Font = null;
			numericUpDown20.Name = "numericUpDown20";
			comboBox31.AccessibleDescription = null;
			comboBox31.AccessibleName = null;
			resources.ApplyResources(comboBox31, "comboBox31");
			comboBox31.BackgroundImage = null;
			comboBox31.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox31.Font = null;
			comboBox31.FormattingEnabled = true;
			comboBox31.Items.AddRange(new object[3]
			{
				resources.GetString("comboBox31.Items"),
				resources.GetString("comboBox31.Items1"),
				resources.GetString("comboBox31.Items2")
			});
			comboBox31.Name = "comboBox31";
			numericUpDown21.AccessibleDescription = null;
			numericUpDown21.AccessibleName = null;
			resources.ApplyResources(numericUpDown21, "numericUpDown21");
			numericUpDown21.DecimalPlaces = 2;
			numericUpDown21.Font = null;
			numericUpDown21.Name = "numericUpDown21";
			numericUpDown22.AccessibleDescription = null;
			numericUpDown22.AccessibleName = null;
			resources.ApplyResources(numericUpDown22, "numericUpDown22");
			numericUpDown22.DecimalPlaces = 2;
			numericUpDown22.Font = null;
			numericUpDown22.Name = "numericUpDown22";
			numericUpDown23.AccessibleDescription = null;
			numericUpDown23.AccessibleName = null;
			resources.ApplyResources(numericUpDown23, "numericUpDown23");
			numericUpDown23.DecimalPlaces = 2;
			numericUpDown23.Font = null;
			numericUpDown23.Name = "numericUpDown23";
			numericUpDown24.AccessibleDescription = null;
			numericUpDown24.AccessibleName = null;
			resources.ApplyResources(numericUpDown24, "numericUpDown24");
			numericUpDown24.Font = null;
			numericUpDown24.Name = "numericUpDown24";
			numericUpDown25.AccessibleDescription = null;
			numericUpDown25.AccessibleName = null;
			resources.ApplyResources(numericUpDown25, "numericUpDown25");
			numericUpDown25.Font = null;
			numericUpDown25.Name = "numericUpDown25";
			numericUpDown26.AccessibleDescription = null;
			numericUpDown26.AccessibleName = null;
			resources.ApplyResources(numericUpDown26, "numericUpDown26");
			numericUpDown26.Font = null;
			numericUpDown26.Name = "numericUpDown26";
			numericUpDown27.AccessibleDescription = null;
			numericUpDown27.AccessibleName = null;
			resources.ApplyResources(numericUpDown27, "numericUpDown27");
			numericUpDown27.Font = null;
			numericUpDown27.Name = "numericUpDown27";
			numericUpDown28.AccessibleDescription = null;
			numericUpDown28.AccessibleName = null;
			resources.ApplyResources(numericUpDown28, "numericUpDown28");
			numericUpDown28.Font = null;
			numericUpDown28.Maximum = new decimal(new int[4] { 9, 0, 0, 0 });
			numericUpDown28.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			numericUpDown28.Name = "numericUpDown28";
			numericUpDown28.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			checkBox35.AccessibleDescription = null;
			checkBox35.AccessibleName = null;
			resources.ApplyResources(checkBox35, "checkBox35");
			checkBox35.BackgroundImage = null;
			checkBox35.Name = "checkBox35";
			checkBox35.UseVisualStyleBackColor = true;
			checkBox36.AccessibleDescription = null;
			checkBox36.AccessibleName = null;
			resources.ApplyResources(checkBox36, "checkBox36");
			checkBox36.BackgroundImage = null;
			checkBox36.Name = "checkBox36";
			checkBox36.UseVisualStyleBackColor = true;
			checkBox37.AccessibleDescription = null;
			checkBox37.AccessibleName = null;
			resources.ApplyResources(checkBox37, "checkBox37");
			checkBox37.BackgroundImage = null;
			checkBox37.Name = "checkBox37";
			checkBox37.UseVisualStyleBackColor = true;
			textBox17.AccessibleDescription = null;
			textBox17.AccessibleName = null;
			resources.ApplyResources(textBox17, "textBox17");
			textBox17.BackgroundImage = null;
			textBox17.Font = null;
			textBox17.Name = "textBox17";
			checkBox38.AccessibleDescription = null;
			checkBox38.AccessibleName = null;
			resources.ApplyResources(checkBox38, "checkBox38");
			checkBox38.BackgroundImage = null;
			checkBox38.Name = "checkBox38";
			checkBox38.UseVisualStyleBackColor = true;
			checkBox39.AccessibleDescription = null;
			checkBox39.AccessibleName = null;
			resources.ApplyResources(checkBox39, "checkBox39");
			checkBox39.BackgroundImage = null;
			checkBox39.Name = "checkBox39";
			checkBox39.UseVisualStyleBackColor = true;
			checkBox40.AccessibleDescription = null;
			checkBox40.AccessibleName = null;
			resources.ApplyResources(checkBox40, "checkBox40");
			checkBox40.BackgroundImage = null;
			checkBox40.Name = "checkBox40";
			checkBox40.UseVisualStyleBackColor = true;
			numericUpDown29.AccessibleDescription = null;
			numericUpDown29.AccessibleName = null;
			resources.ApplyResources(numericUpDown29, "numericUpDown29");
			numericUpDown29.DecimalPlaces = 2;
			numericUpDown29.Font = null;
			numericUpDown29.Name = "numericUpDown29";
			numericUpDown30.AccessibleDescription = null;
			numericUpDown30.AccessibleName = null;
			resources.ApplyResources(numericUpDown30, "numericUpDown30");
			numericUpDown30.Font = null;
			numericUpDown30.Name = "numericUpDown30";
			checkBox41.AccessibleDescription = null;
			checkBox41.AccessibleName = null;
			resources.ApplyResources(checkBox41, "checkBox41");
			checkBox41.BackgroundImage = null;
			checkBox41.Name = "checkBox41";
			checkBox41.UseVisualStyleBackColor = true;
			textBox18.AccessibleDescription = null;
			textBox18.AccessibleName = null;
			resources.ApplyResources(textBox18, "textBox18");
			textBox18.BackgroundImage = null;
			textBox18.Name = "textBox18";
			tabPage7.AccessibleDescription = null;
			tabPage7.AccessibleName = null;
			resources.ApplyResources(tabPage7, "tabPage7");
			tabPage7.BackColor = System.Drawing.Color.LightSteelBlue;
			tabPage7.BackgroundImage = null;
			tabPage7.Controls.Add(groupBox22);
			tabPage7.Font = null;
			tabPage7.Name = "tabPage7";
			tabPage7.UseVisualStyleBackColor = true;
			groupBox22.AccessibleDescription = null;
			groupBox22.AccessibleName = null;
			resources.ApplyResources(groupBox22, "groupBox22");
			groupBox22.BackgroundImage = null;
			groupBox22.Controls.Add(numericUpDown31);
			groupBox22.Controls.Add(button20);
			groupBox22.Controls.Add(comboBox32);
			groupBox22.Controls.Add(label106);
			groupBox22.Controls.Add(comboBox33);
			groupBox22.Controls.Add(label107);
			groupBox22.Controls.Add(comboBox34);
			groupBox22.Controls.Add(label108);
			groupBox22.Controls.Add(comboBox35);
			groupBox22.Controls.Add(label109);
			groupBox22.Controls.Add(comboBox36);
			groupBox22.Controls.Add(label110);
			groupBox22.Controls.Add(comboBox37);
			groupBox22.Controls.Add(label111);
			groupBox22.Controls.Add(numericUpDown32);
			groupBox22.Controls.Add(this.label110);
			groupBox22.Controls.Add(this.label111);
			groupBox22.Controls.Add(dataGridView2);
			groupBox22.Font = null;
			groupBox22.Name = "groupBox22";
			groupBox22.TabStop = false;
			numericUpDown31.AccessibleDescription = null;
			numericUpDown31.AccessibleName = null;
			resources.ApplyResources(numericUpDown31, "numericUpDown31");
			numericUpDown31.Font = null;
			numericUpDown31.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			numericUpDown31.Name = "numericUpDown31";
			numericUpDown31.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			button20.AccessibleDescription = null;
			button20.AccessibleName = null;
			resources.ApplyResources(button20, "button20");
			button20.BackgroundImage = null;
			button20.Font = null;
			button20.Name = "button20";
			button20.UseVisualStyleBackColor = true;
			comboBox32.AccessibleDescription = null;
			comboBox32.AccessibleName = null;
			resources.ApplyResources(comboBox32, "comboBox32");
			comboBox32.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox32.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox32.BackgroundImage = null;
			comboBox32.Font = null;
			comboBox32.FormattingEnabled = true;
			comboBox32.Name = "comboBox32";
			comboBox33.AccessibleDescription = null;
			comboBox33.AccessibleName = null;
			resources.ApplyResources(comboBox33, "comboBox33");
			comboBox33.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox33.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox33.BackgroundImage = null;
			comboBox33.Font = null;
			comboBox33.FormattingEnabled = true;
			comboBox33.Name = "comboBox33";
			comboBox34.AccessibleDescription = null;
			comboBox34.AccessibleName = null;
			resources.ApplyResources(comboBox34, "comboBox34");
			comboBox34.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox34.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox34.BackgroundImage = null;
			comboBox34.Font = null;
			comboBox34.FormattingEnabled = true;
			comboBox34.Name = "comboBox34";
			comboBox35.AccessibleDescription = null;
			comboBox35.AccessibleName = null;
			resources.ApplyResources(comboBox35, "comboBox35");
			comboBox35.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox35.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox35.BackgroundImage = null;
			comboBox35.Font = null;
			comboBox35.FormattingEnabled = true;
			comboBox35.Name = "comboBox35";
			comboBox36.AccessibleDescription = null;
			comboBox36.AccessibleName = null;
			resources.ApplyResources(comboBox36, "comboBox36");
			comboBox36.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox36.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox36.BackgroundImage = null;
			comboBox36.Font = null;
			comboBox36.FormattingEnabled = true;
			comboBox36.Name = "comboBox36";
			comboBox37.AccessibleDescription = null;
			comboBox37.AccessibleName = null;
			resources.ApplyResources(comboBox37, "comboBox37");
			comboBox37.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox37.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox37.BackgroundImage = null;
			comboBox37.Font = null;
			comboBox37.FormattingEnabled = true;
			comboBox37.Name = "comboBox37";
			numericUpDown32.AccessibleDescription = null;
			numericUpDown32.AccessibleName = null;
			resources.ApplyResources(numericUpDown32, "numericUpDown32");
			numericUpDown32.DecimalPlaces = 2;
			numericUpDown32.Font = null;
			numericUpDown32.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			numericUpDown32.Name = "numericUpDown32";
			this.label110.AccessibleDescription = null;
			this.label110.AccessibleName = null;
			resources.ApplyResources(this.label110, "label110");
			this.label110.Font = null;
			this.label110.Name = "label110";
			this.label111.AccessibleDescription = null;
			this.label111.AccessibleName = null;
			resources.ApplyResources(this.label111, "label111");
			this.label111.Font = null;
			this.label111.Name = "label111";
			dataGridView2.AccessibleDescription = null;
			dataGridView2.AccessibleName = null;
			dataGridView2.AllowUserToAddRows = false;
			resources.ApplyResources(dataGridView2, "dataGridView2");
			dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView2.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView2.BackgroundImage = null;
			dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView2.Columns.AddRange(dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn5, dataGridViewTextBoxColumn6, dataGridViewTextBoxColumn7, dataGridViewTextBoxColumn8);
			dataGridView2.Font = null;
			dataGridView2.GridColor = System.Drawing.Color.LightSteelBlue;
			dataGridView2.Name = "dataGridView2";
			resources.ApplyResources(dataGridViewTextBoxColumn1, "dataGridViewTextBoxColumn1");
			dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			dataGridViewTextBoxColumn1.ReadOnly = true;
			resources.ApplyResources(dataGridViewTextBoxColumn2, "dataGridViewTextBoxColumn2");
			dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
			resources.ApplyResources(dataGridViewTextBoxColumn3, "dataGridViewTextBoxColumn3");
			dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
			dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			resources.ApplyResources(dataGridViewTextBoxColumn4, "dataGridViewTextBoxColumn4");
			dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			resources.ApplyResources(dataGridViewTextBoxColumn5, "dataGridViewTextBoxColumn5");
			dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
			dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			resources.ApplyResources(dataGridViewTextBoxColumn6, "dataGridViewTextBoxColumn6");
			dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
			dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			resources.ApplyResources(dataGridViewTextBoxColumn7, "dataGridViewTextBoxColumn7");
			dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
			dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			resources.ApplyResources(dataGridViewTextBoxColumn8, "dataGridViewTextBoxColumn8");
			dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
			tabPage8.AccessibleDescription = null;
			tabPage8.AccessibleName = null;
			resources.ApplyResources(tabPage8, "tabPage8");
			tabPage8.BackColor = System.Drawing.Color.LightSteelBlue;
			tabPage8.BackgroundImage = null;
			tabPage8.Controls.Add(groupBox23);
			tabPage8.Font = null;
			tabPage8.Name = "tabPage8";
			groupBox23.AccessibleDescription = null;
			groupBox23.AccessibleName = null;
			resources.ApplyResources(groupBox23, "groupBox23");
			groupBox23.BackgroundImage = null;
			groupBox23.Controls.Add(textBox19);
			groupBox23.Controls.Add(this.label112);
			groupBox23.Controls.Add(textBox20);
			groupBox23.Controls.Add(textBox21);
			groupBox23.Controls.Add(this.label113);
			groupBox23.Controls.Add(numericUpDown33);
			groupBox23.Controls.Add(label112);
			groupBox23.Controls.Add(label113);
			groupBox23.Controls.Add(this.label116);
			groupBox23.Controls.Add(numericUpDown34);
			groupBox23.Controls.Add(this.label117);
			groupBox23.Controls.Add(this.label118);
			groupBox23.Controls.Add(numericUpDown35);
			groupBox23.Controls.Add(label114);
			groupBox23.Controls.Add(comboBox38);
			groupBox23.Controls.Add(label115);
			groupBox23.Controls.Add(comboBox39);
			groupBox23.Controls.Add(label116);
			groupBox23.Controls.Add(numericUpDown36);
			groupBox23.Controls.Add(this.label122);
			groupBox23.Controls.Add(this.label123);
			groupBox23.Font = null;
			groupBox23.Name = "groupBox23";
			groupBox23.TabStop = false;
			textBox19.AccessibleDescription = null;
			textBox19.AccessibleName = null;
			resources.ApplyResources(textBox19, "textBox19");
			textBox19.BackgroundImage = null;
			textBox19.Font = null;
			textBox19.Name = "textBox19";
			this.label112.AccessibleDescription = null;
			this.label112.AccessibleName = null;
			resources.ApplyResources(this.label112, "label112");
			this.label112.Font = null;
			this.label112.Name = "label112";
			textBox20.AccessibleDescription = null;
			textBox20.AccessibleName = null;
			resources.ApplyResources(textBox20, "textBox20");
			textBox20.BackgroundImage = null;
			textBox20.Font = null;
			textBox20.Name = "textBox20";
			textBox21.AccessibleDescription = null;
			textBox21.AccessibleName = null;
			resources.ApplyResources(textBox21, "textBox21");
			textBox21.BackgroundImage = null;
			textBox21.Font = null;
			textBox21.Name = "textBox21";
			this.label113.AccessibleDescription = null;
			this.label113.AccessibleName = null;
			resources.ApplyResources(this.label113, "label113");
			this.label113.Font = null;
			this.label113.Name = "label113";
			numericUpDown33.AccessibleDescription = null;
			numericUpDown33.AccessibleName = null;
			resources.ApplyResources(numericUpDown33, "numericUpDown33");
			numericUpDown33.DecimalPlaces = 2;
			numericUpDown33.Font = null;
			numericUpDown33.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			numericUpDown33.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			numericUpDown33.Name = "numericUpDown33";
			this.label116.AccessibleDescription = null;
			this.label116.AccessibleName = null;
			resources.ApplyResources(this.label116, "label116");
			this.label116.Font = null;
			this.label116.Name = "label116";
			numericUpDown34.AccessibleDescription = null;
			numericUpDown34.AccessibleName = null;
			resources.ApplyResources(numericUpDown34, "numericUpDown34");
			numericUpDown34.DecimalPlaces = 2;
			numericUpDown34.Font = null;
			numericUpDown34.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			numericUpDown34.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			numericUpDown34.Name = "numericUpDown34";
			this.label117.AccessibleDescription = null;
			this.label117.AccessibleName = null;
			resources.ApplyResources(this.label117, "label117");
			this.label117.Font = null;
			this.label117.Name = "label117";
			this.label118.AccessibleDescription = null;
			this.label118.AccessibleName = null;
			resources.ApplyResources(this.label118, "label118");
			this.label118.Font = null;
			this.label118.Name = "label118";
			numericUpDown35.AccessibleDescription = null;
			numericUpDown35.AccessibleName = null;
			resources.ApplyResources(numericUpDown35, "numericUpDown35");
			numericUpDown35.Font = null;
			numericUpDown35.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			numericUpDown35.Name = "numericUpDown35";
			numericUpDown35.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			comboBox38.AccessibleDescription = null;
			comboBox38.AccessibleName = null;
			resources.ApplyResources(comboBox38, "comboBox38");
			comboBox38.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox38.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox38.BackgroundImage = null;
			comboBox38.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox38.Font = null;
			comboBox38.FormattingEnabled = true;
			comboBox38.Items.AddRange(new object[3]
			{
				resources.GetString("comboBox38.Items"),
				resources.GetString("comboBox38.Items1"),
				resources.GetString("comboBox38.Items2")
			});
			comboBox38.Name = "comboBox38";
			comboBox39.AccessibleDescription = null;
			comboBox39.AccessibleName = null;
			resources.ApplyResources(comboBox39, "comboBox39");
			comboBox39.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox39.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox39.BackgroundImage = null;
			comboBox39.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox39.Font = null;
			comboBox39.FormattingEnabled = true;
			comboBox39.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox39.Items"),
				resources.GetString("comboBox39.Items1")
			});
			comboBox39.Name = "comboBox39";
			numericUpDown36.AccessibleDescription = null;
			numericUpDown36.AccessibleName = null;
			resources.ApplyResources(numericUpDown36, "numericUpDown36");
			numericUpDown36.DecimalPlaces = 2;
			numericUpDown36.Font = null;
			numericUpDown36.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			numericUpDown36.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			numericUpDown36.Name = "numericUpDown36";
			this.label122.AccessibleDescription = null;
			this.label122.AccessibleName = null;
			resources.ApplyResources(this.label122, "label122");
			this.label122.Font = null;
			this.label122.Name = "label122";
			this.label123.AccessibleDescription = null;
			this.label123.AccessibleName = null;
			resources.ApplyResources(this.label123, "label123");
			this.label123.Font = null;
			this.label123.Name = "label123";
			tabPage10.AccessibleDescription = null;
			tabPage10.AccessibleName = null;
			resources.ApplyResources(tabPage10, "tabPage10");
			tabPage10.BackColor = System.Drawing.Color.LightSteelBlue;
			tabPage10.BackgroundImage = null;
			tabPage10.Controls.Add(groupBox24);
			tabPage10.Controls.Add(button21);
			tabPage10.Controls.Add(groupBox25);
			tabPage10.Controls.Add(groupBox26);
			tabPage10.Controls.Add(button26);
			tabPage10.Controls.Add(button27);
			tabPage10.Controls.Add(groupBox28);
			tabPage10.Controls.Add(groupBox29);
			tabPage10.Controls.Add(groupBox30);
			tabPage10.Controls.Add(groupBox31);
			tabPage10.Font = null;
			tabPage10.Name = "tabPage10";
			groupBox24.AccessibleDescription = null;
			groupBox24.AccessibleName = null;
			resources.ApplyResources(groupBox24, "groupBox24");
			groupBox24.BackColor = System.Drawing.Color.Transparent;
			groupBox24.BackgroundImage = null;
			groupBox24.Controls.Add(checkedListBox7);
			groupBox24.Name = "groupBox24";
			groupBox24.TabStop = false;
			checkedListBox7.AccessibleDescription = null;
			checkedListBox7.AccessibleName = null;
			resources.ApplyResources(checkedListBox7, "checkedListBox7");
			checkedListBox7.BackColor = System.Drawing.SystemColors.ActiveCaption;
			checkedListBox7.BackgroundImage = null;
			checkedListBox7.CheckOnClick = true;
			checkedListBox7.Font = null;
			checkedListBox7.FormattingEnabled = true;
			checkedListBox7.Name = "checkedListBox7";
			checkedListBox7.ThreeDCheckBoxes = true;
			button21.AccessibleDescription = null;
			button21.AccessibleName = null;
			resources.ApplyResources(button21, "button21");
			button21.BackColor = System.Drawing.Color.Gainsboro;
			button21.BackgroundImage = null;
			button21.Name = "button21";
			button21.UseVisualStyleBackColor = false;
			groupBox25.AccessibleDescription = null;
			groupBox25.AccessibleName = null;
			resources.ApplyResources(groupBox25, "groupBox25");
			groupBox25.BackColor = System.Drawing.Color.LightSteelBlue;
			groupBox25.BackgroundImage = null;
			groupBox25.Controls.Add(this.label124);
			groupBox25.Font = null;
			groupBox25.Name = "groupBox25";
			groupBox25.TabStop = false;
			this.label124.AccessibleDescription = null;
			this.label124.AccessibleName = null;
			resources.ApplyResources(this.label124, "label124");
			this.label124.BackColor = System.Drawing.Color.Transparent;
			this.label124.Name = "label124";
			groupBox26.AccessibleDescription = null;
			groupBox26.AccessibleName = null;
			resources.ApplyResources(groupBox26, "groupBox26");
			groupBox26.BackColor = System.Drawing.Color.LightSteelBlue;
			groupBox26.BackgroundImage = null;
			groupBox26.Controls.Add(button22);
			groupBox26.Controls.Add(button23);
			groupBox26.Controls.Add(checkBox42);
			groupBox26.Controls.Add(textBox22);
			groupBox26.Controls.Add(label117);
			groupBox26.Controls.Add(panel6);
			groupBox26.Controls.Add(radioButton11);
			groupBox26.Controls.Add(radioButton12);
			groupBox26.Controls.Add(comboBox41);
			groupBox26.Controls.Add(comboBox42);
			groupBox26.Controls.Add(comboBox43);
			groupBox26.Controls.Add(floatText5);
			groupBox26.Controls.Add(label119);
			groupBox26.Controls.Add(label120);
			groupBox26.Controls.Add(panel7);
			groupBox26.Controls.Add(textBox23);
			groupBox26.Controls.Add(label122);
			groupBox26.Controls.Add(button24);
			groupBox26.Controls.Add(groupBox27);
			groupBox26.Controls.Add(radioButton13);
			groupBox26.Controls.Add(radioButton14);
			groupBox26.Controls.Add(radioButton15);
			groupBox26.Controls.Add(label123);
			groupBox26.Controls.Add(textBox24);
			groupBox26.Controls.Add(checkBox43);
			groupBox26.Controls.Add(textBox25);
			groupBox26.Controls.Add(label124);
			groupBox26.Controls.Add(comboBox45);
			groupBox26.Controls.Add(label125);
			groupBox26.Controls.Add(button25);
			groupBox26.Controls.Add(label126);
			groupBox26.Controls.Add(comboBox46);
			groupBox26.Controls.Add(comboBox47);
			groupBox26.Controls.Add(label127);
			groupBox26.Controls.Add(dateTimePicker7);
			groupBox26.Controls.Add(label128);
			groupBox26.Controls.Add(textBox26);
			groupBox26.Controls.Add(label129);
			groupBox26.Controls.Add(comboBox48);
			groupBox26.Controls.Add(label130);
			groupBox26.Controls.Add(label131);
			groupBox26.Controls.Add(textBox27);
			groupBox26.Controls.Add(label132);
			groupBox26.Controls.Add(label133);
			groupBox26.Controls.Add(label134);
			groupBox26.Controls.Add(label135);
			groupBox26.Controls.Add(comboBox49);
			groupBox26.Controls.Add(label136);
			groupBox26.Controls.Add(label137);
			groupBox26.Controls.Add(textBox28);
			groupBox26.Controls.Add(dateTimePicker8);
			groupBox26.Controls.Add(label138);
			groupBox26.Controls.Add(label139);
			groupBox26.Controls.Add(textBox29);
			groupBox26.Controls.Add(textBox30);
			groupBox26.Controls.Add(label140);
			groupBox26.ForeColor = System.Drawing.Color.Black;
			groupBox26.Name = "groupBox26";
			groupBox26.TabStop = false;
			button22.AccessibleDescription = null;
			button22.AccessibleName = null;
			resources.ApplyResources(button22, "button22");
			button22.BackgroundImage = null;
			button22.Font = null;
			button22.Name = "button22";
			button22.UseVisualStyleBackColor = true;
			button23.AccessibleDescription = null;
			button23.AccessibleName = null;
			resources.ApplyResources(button23, "button23");
			button23.BackgroundImage = null;
			button23.Font = null;
			button23.Name = "button23";
			button23.UseVisualStyleBackColor = true;
			checkBox42.AccessibleDescription = null;
			checkBox42.AccessibleName = null;
			resources.ApplyResources(checkBox42, "checkBox42");
			checkBox42.BackgroundImage = null;
			checkBox42.Checked = true;
			checkBox42.CheckState = System.Windows.Forms.CheckState.Checked;
			checkBox42.Font = null;
			checkBox42.Name = "checkBox42";
			checkBox42.UseVisualStyleBackColor = true;
			textBox22.AccessibleDescription = null;
			textBox22.AccessibleName = null;
			resources.ApplyResources(textBox22, "textBox22");
			textBox22.BackgroundImage = null;
			textBox22.Name = "textBox22";
			panel6.AccessibleDescription = null;
			panel6.AccessibleName = null;
			resources.ApplyResources(panel6, "panel6");
			panel6.BackgroundImage = null;
			panel6.Controls.Add(label118);
			panel6.Controls.Add(comboBox40);
			panel6.Font = null;
			panel6.Name = "panel6";
			comboBox40.AccessibleDescription = null;
			comboBox40.AccessibleName = null;
			resources.ApplyResources(comboBox40, "comboBox40");
			comboBox40.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox40.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox40.BackgroundImage = null;
			comboBox40.FormattingEnabled = true;
			comboBox40.Name = "comboBox40";
			radioButton11.AccessibleDescription = null;
			radioButton11.AccessibleName = null;
			resources.ApplyResources(radioButton11, "radioButton11");
			radioButton11.BackgroundImage = null;
			radioButton11.Name = "radioButton11";
			radioButton11.UseVisualStyleBackColor = true;
			radioButton12.AccessibleDescription = null;
			radioButton12.AccessibleName = null;
			resources.ApplyResources(radioButton12, "radioButton12");
			radioButton12.BackgroundImage = null;
			radioButton12.Checked = true;
			radioButton12.Name = "radioButton12";
			radioButton12.TabStop = true;
			radioButton12.UseVisualStyleBackColor = true;
			comboBox41.AccessibleDescription = null;
			comboBox41.AccessibleName = null;
			resources.ApplyResources(comboBox41, "comboBox41");
			comboBox41.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox41.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox41.BackgroundImage = null;
			comboBox41.FormattingEnabled = true;
			comboBox41.Name = "comboBox41";
			comboBox42.AccessibleDescription = null;
			comboBox42.AccessibleName = null;
			resources.ApplyResources(comboBox42, "comboBox42");
			comboBox42.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox42.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox42.BackgroundImage = null;
			comboBox42.FormattingEnabled = true;
			comboBox42.Name = "comboBox42";
			comboBox43.AccessibleDescription = null;
			comboBox43.AccessibleName = null;
			resources.ApplyResources(comboBox43, "comboBox43");
			comboBox43.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox43.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox43.BackgroundImage = null;
			comboBox43.FormattingEnabled = true;
			comboBox43.Name = "comboBox43";
			floatText5.AccessibleDescription = null;
			floatText5.AccessibleName = null;
			resources.ApplyResources(floatText5, "floatText5");
			floatText5.BackgroundImage = null;
			floatText5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText5.Font = null;
			floatText5.Name = "floatText5";
			panel7.AccessibleDescription = null;
			panel7.AccessibleName = null;
			resources.ApplyResources(panel7, "panel7");
			panel7.BackgroundImage = null;
			panel7.Controls.Add(label121);
			panel7.Controls.Add(floatText6);
			panel7.Controls.Add(this.label130);
			panel7.Controls.Add(comboBox44);
			panel7.Font = null;
			panel7.Name = "panel7";
			floatText6.AccessibleDescription = null;
			floatText6.AccessibleName = null;
			resources.ApplyResources(floatText6, "floatText6");
			floatText6.BackgroundImage = null;
			floatText6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText6.Font = null;
			floatText6.Name = "floatText6";
			this.label130.AccessibleDescription = null;
			this.label130.AccessibleName = null;
			resources.ApplyResources(this.label130, "label130");
			this.label130.Name = "label130";
			comboBox44.AccessibleDescription = null;
			comboBox44.AccessibleName = null;
			resources.ApplyResources(comboBox44, "comboBox44");
			comboBox44.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox44.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox44.BackgroundImage = null;
			comboBox44.FormattingEnabled = true;
			comboBox44.Name = "comboBox44";
			textBox23.AccessibleDescription = null;
			textBox23.AccessibleName = null;
			resources.ApplyResources(textBox23, "textBox23");
			textBox23.BackgroundImage = null;
			textBox23.Font = null;
			textBox23.ForeColor = System.Drawing.Color.Maroon;
			textBox23.Name = "textBox23";
			textBox23.ReadOnly = true;
			button24.AccessibleDescription = null;
			button24.AccessibleName = null;
			resources.ApplyResources(button24, "button24");
			button24.BackColor = System.Drawing.Color.Transparent;
			button24.BackgroundImage = null;
			button24.Cursor = System.Windows.Forms.Cursors.Hand;
			button24.Name = "button24";
			button24.UseVisualStyleBackColor = false;
			groupBox27.AccessibleDescription = null;
			groupBox27.AccessibleName = null;
			resources.ApplyResources(groupBox27, "groupBox27");
			groupBox27.BackColor = System.Drawing.Color.Transparent;
			groupBox27.BackgroundImage = null;
			groupBox27.Controls.Add(pictureBox3);
			groupBox27.Name = "groupBox27";
			groupBox27.TabStop = false;
			pictureBox3.AccessibleDescription = null;
			pictureBox3.AccessibleName = null;
			resources.ApplyResources(pictureBox3, "pictureBox3");
			pictureBox3.BackColor = System.Drawing.Color.Transparent;
			pictureBox3.BackgroundImage = null;
			pictureBox3.Font = null;
			pictureBox3.ImageLocation = null;
			pictureBox3.Name = "pictureBox3";
			pictureBox3.TabStop = false;
			radioButton13.AccessibleDescription = null;
			radioButton13.AccessibleName = null;
			resources.ApplyResources(radioButton13, "radioButton13");
			radioButton13.BackgroundImage = null;
			radioButton13.Name = "radioButton13";
			radioButton13.UseVisualStyleBackColor = true;
			radioButton14.AccessibleDescription = null;
			radioButton14.AccessibleName = null;
			resources.ApplyResources(radioButton14, "radioButton14");
			radioButton14.BackgroundImage = null;
			radioButton14.Name = "radioButton14";
			radioButton14.UseVisualStyleBackColor = true;
			radioButton15.AccessibleDescription = null;
			radioButton15.AccessibleName = null;
			resources.ApplyResources(radioButton15, "radioButton15");
			radioButton15.BackgroundImage = null;
			radioButton15.Name = "radioButton15";
			radioButton15.UseVisualStyleBackColor = true;
			textBox24.AccessibleDescription = null;
			textBox24.AccessibleName = null;
			resources.ApplyResources(textBox24, "textBox24");
			textBox24.BackgroundImage = null;
			textBox24.Font = null;
			textBox24.ForeColor = System.Drawing.Color.Maroon;
			textBox24.Name = "textBox24";
			textBox24.ReadOnly = true;
			checkBox43.AccessibleDescription = null;
			checkBox43.AccessibleName = null;
			resources.ApplyResources(checkBox43, "checkBox43");
			checkBox43.BackgroundImage = null;
			checkBox43.Checked = true;
			checkBox43.CheckState = System.Windows.Forms.CheckState.Checked;
			checkBox43.Font = null;
			checkBox43.Name = "checkBox43";
			checkBox43.UseVisualStyleBackColor = true;
			textBox25.AccessibleDescription = null;
			textBox25.AccessibleName = null;
			resources.ApplyResources(textBox25, "textBox25");
			textBox25.BackgroundImage = null;
			textBox25.Name = "textBox25";
			comboBox45.AccessibleDescription = null;
			comboBox45.AccessibleName = null;
			resources.ApplyResources(comboBox45, "comboBox45");
			comboBox45.BackgroundImage = null;
			comboBox45.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox45.FormattingEnabled = true;
			comboBox45.Name = "comboBox45";
			button25.AccessibleDescription = null;
			button25.AccessibleName = null;
			resources.ApplyResources(button25, "button25");
			button25.BackgroundImage = null;
			button25.Font = null;
			button25.Name = "button25";
			button25.UseVisualStyleBackColor = true;
			comboBox46.AccessibleDescription = null;
			comboBox46.AccessibleName = null;
			resources.ApplyResources(comboBox46, "comboBox46");
			comboBox46.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox46.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox46.BackgroundImage = null;
			comboBox46.FormattingEnabled = true;
			comboBox46.Name = "comboBox46";
			comboBox47.AccessibleDescription = null;
			comboBox47.AccessibleName = null;
			resources.ApplyResources(comboBox47, "comboBox47");
			comboBox47.BackgroundImage = null;
			comboBox47.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox47.FormattingEnabled = true;
			comboBox47.Items.AddRange(new object[3]
			{
				resources.GetString("comboBox47.Items"),
				resources.GetString("comboBox47.Items1"),
				resources.GetString("comboBox47.Items2")
			});
			comboBox47.Name = "comboBox47";
			dateTimePicker7.AccessibleDescription = null;
			dateTimePicker7.AccessibleName = null;
			resources.ApplyResources(dateTimePicker7, "dateTimePicker7");
			dateTimePicker7.BackgroundImage = null;
			dateTimePicker7.CalendarFont = null;
			dateTimePicker7.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker7.Name = "dateTimePicker7";
			textBox26.AccessibleDescription = null;
			textBox26.AccessibleName = null;
			resources.ApplyResources(textBox26, "textBox26");
			textBox26.BackgroundImage = null;
			textBox26.Name = "textBox26";
			comboBox48.AccessibleDescription = null;
			comboBox48.AccessibleName = null;
			resources.ApplyResources(comboBox48, "comboBox48");
			comboBox48.BackgroundImage = null;
			comboBox48.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox48.FormattingEnabled = true;
			comboBox48.Items.AddRange(new object[7]
			{
				resources.GetString("comboBox48.Items"),
				resources.GetString("comboBox48.Items1"),
				resources.GetString("comboBox48.Items2"),
				resources.GetString("comboBox48.Items3"),
				resources.GetString("comboBox48.Items4"),
				resources.GetString("comboBox48.Items5"),
				resources.GetString("comboBox48.Items6")
			});
			comboBox48.Name = "comboBox48";
			textBox27.AccessibleDescription = null;
			textBox27.AccessibleName = null;
			resources.ApplyResources(textBox27, "textBox27");
			textBox27.BackgroundImage = null;
			textBox27.Name = "textBox27";
			comboBox49.AccessibleDescription = null;
			comboBox49.AccessibleName = null;
			resources.ApplyResources(comboBox49, "comboBox49");
			comboBox49.BackgroundImage = null;
			comboBox49.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox49.FormattingEnabled = true;
			comboBox49.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox49.Items"),
				resources.GetString("comboBox49.Items1")
			});
			comboBox49.Name = "comboBox49";
			textBox28.AccessibleDescription = null;
			textBox28.AccessibleName = null;
			resources.ApplyResources(textBox28, "textBox28");
			textBox28.BackgroundImage = null;
			textBox28.Name = "textBox28";
			dateTimePicker8.AccessibleDescription = null;
			dateTimePicker8.AccessibleName = null;
			resources.ApplyResources(dateTimePicker8, "dateTimePicker8");
			dateTimePicker8.BackgroundImage = null;
			dateTimePicker8.CalendarFont = null;
			dateTimePicker8.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker8.Name = "dateTimePicker8";
			textBox29.AccessibleDescription = null;
			textBox29.AccessibleName = null;
			resources.ApplyResources(textBox29, "textBox29");
			textBox29.BackgroundImage = null;
			textBox29.Name = "textBox29";
			textBox30.AccessibleDescription = null;
			textBox30.AccessibleName = null;
			resources.ApplyResources(textBox30, "textBox30");
			textBox30.BackgroundImage = null;
			textBox30.Name = "textBox30";
			button26.AccessibleDescription = null;
			button26.AccessibleName = null;
			resources.ApplyResources(button26, "button26");
			button26.BackColor = System.Drawing.Color.Gainsboro;
			button26.BackgroundImage = null;
			button26.Name = "button26";
			button26.UseVisualStyleBackColor = false;
			button27.AccessibleDescription = null;
			button27.AccessibleName = null;
			resources.ApplyResources(button27, "button27");
			button27.BackColor = System.Drawing.Color.Gainsboro;
			button27.BackgroundImage = null;
			button27.Name = "button27";
			button27.UseVisualStyleBackColor = false;
			groupBox28.AccessibleDescription = null;
			groupBox28.AccessibleName = null;
			resources.ApplyResources(groupBox28, "groupBox28");
			groupBox28.BackColor = System.Drawing.Color.Transparent;
			groupBox28.BackgroundImage = null;
			groupBox28.Controls.Add(checkedListBox8);
			groupBox28.Name = "groupBox28";
			groupBox28.TabStop = false;
			checkedListBox8.AccessibleDescription = null;
			checkedListBox8.AccessibleName = null;
			resources.ApplyResources(checkedListBox8, "checkedListBox8");
			checkedListBox8.BackColor = System.Drawing.SystemColors.ActiveCaption;
			checkedListBox8.BackgroundImage = null;
			checkedListBox8.CheckOnClick = true;
			checkedListBox8.Font = null;
			checkedListBox8.FormattingEnabled = true;
			checkedListBox8.Name = "checkedListBox8";
			groupBox29.AccessibleDescription = null;
			groupBox29.AccessibleName = null;
			resources.ApplyResources(groupBox29, "groupBox29");
			groupBox29.BackColor = System.Drawing.Color.Transparent;
			groupBox29.BackgroundImage = null;
			groupBox29.Controls.Add(checkBox44);
			groupBox29.Controls.Add(checkBox45);
			groupBox29.Controls.Add(checkBox46);
			groupBox29.Controls.Add(checkBox47);
			groupBox29.Controls.Add(textBox31);
			groupBox29.Controls.Add(label141);
			groupBox29.Controls.Add(checkBox48);
			groupBox29.Controls.Add(checkBox49);
			groupBox29.Controls.Add(checkBox50);
			groupBox29.Controls.Add(checkBox51);
			groupBox29.Controls.Add(checkBox52);
			groupBox29.Controls.Add(checkBox53);
			groupBox29.Controls.Add(checkBox54);
			groupBox29.Name = "groupBox29";
			groupBox29.TabStop = false;
			checkBox44.AccessibleDescription = null;
			checkBox44.AccessibleName = null;
			resources.ApplyResources(checkBox44, "checkBox44");
			checkBox44.BackgroundImage = null;
			checkBox44.Name = "checkBox44";
			checkBox44.UseVisualStyleBackColor = true;
			checkBox45.AccessibleDescription = null;
			checkBox45.AccessibleName = null;
			resources.ApplyResources(checkBox45, "checkBox45");
			checkBox45.BackgroundImage = null;
			checkBox45.Name = "checkBox45";
			checkBox45.UseVisualStyleBackColor = true;
			checkBox46.AccessibleDescription = null;
			checkBox46.AccessibleName = null;
			resources.ApplyResources(checkBox46, "checkBox46");
			checkBox46.BackgroundImage = null;
			checkBox46.Name = "checkBox46";
			checkBox46.UseVisualStyleBackColor = true;
			checkBox47.AccessibleDescription = null;
			checkBox47.AccessibleName = null;
			resources.ApplyResources(checkBox47, "checkBox47");
			checkBox47.BackgroundImage = null;
			checkBox47.Name = "checkBox47";
			checkBox47.UseVisualStyleBackColor = true;
			textBox31.AccessibleDescription = null;
			textBox31.AccessibleName = null;
			resources.ApplyResources(textBox31, "textBox31");
			textBox31.BackgroundImage = null;
			textBox31.Font = null;
			textBox31.Name = "textBox31";
			checkBox48.AccessibleDescription = null;
			checkBox48.AccessibleName = null;
			resources.ApplyResources(checkBox48, "checkBox48");
			checkBox48.BackgroundImage = null;
			checkBox48.Name = "checkBox48";
			checkBox48.UseVisualStyleBackColor = true;
			checkBox49.AccessibleDescription = null;
			checkBox49.AccessibleName = null;
			resources.ApplyResources(checkBox49, "checkBox49");
			checkBox49.BackgroundImage = null;
			checkBox49.Name = "checkBox49";
			checkBox49.UseVisualStyleBackColor = true;
			checkBox50.AccessibleDescription = null;
			checkBox50.AccessibleName = null;
			resources.ApplyResources(checkBox50, "checkBox50");
			checkBox50.BackgroundImage = null;
			checkBox50.Name = "checkBox50";
			checkBox50.UseVisualStyleBackColor = true;
			checkBox51.AccessibleDescription = null;
			checkBox51.AccessibleName = null;
			resources.ApplyResources(checkBox51, "checkBox51");
			checkBox51.BackgroundImage = null;
			checkBox51.Name = "checkBox51";
			checkBox51.UseVisualStyleBackColor = true;
			checkBox52.AccessibleDescription = null;
			checkBox52.AccessibleName = null;
			resources.ApplyResources(checkBox52, "checkBox52");
			checkBox52.BackgroundImage = null;
			checkBox52.Name = "checkBox52";
			checkBox52.UseVisualStyleBackColor = true;
			checkBox53.AccessibleDescription = null;
			checkBox53.AccessibleName = null;
			resources.ApplyResources(checkBox53, "checkBox53");
			checkBox53.BackgroundImage = null;
			checkBox53.Name = "checkBox53";
			checkBox53.UseVisualStyleBackColor = true;
			checkBox54.AccessibleDescription = null;
			checkBox54.AccessibleName = null;
			resources.ApplyResources(checkBox54, "checkBox54");
			checkBox54.BackgroundImage = null;
			checkBox54.Name = "checkBox54";
			checkBox54.UseVisualStyleBackColor = true;
			groupBox30.AccessibleDescription = null;
			groupBox30.AccessibleName = null;
			resources.ApplyResources(groupBox30, "groupBox30");
			groupBox30.BackColor = System.Drawing.Color.Transparent;
			groupBox30.BackgroundImage = null;
			groupBox30.Controls.Add(checkedListBox9);
			groupBox30.Name = "groupBox30";
			groupBox30.TabStop = false;
			checkedListBox9.AccessibleDescription = null;
			checkedListBox9.AccessibleName = null;
			resources.ApplyResources(checkedListBox9, "checkedListBox9");
			checkedListBox9.BackColor = System.Drawing.SystemColors.ActiveCaption;
			checkedListBox9.BackgroundImage = null;
			checkedListBox9.CheckOnClick = true;
			checkedListBox9.Font = null;
			checkedListBox9.FormattingEnabled = true;
			checkedListBox9.Name = "checkedListBox9";
			checkedListBox9.UseCompatibleTextRendering = true;
			groupBox31.AccessibleDescription = null;
			groupBox31.AccessibleName = null;
			resources.ApplyResources(groupBox31, "groupBox31");
			groupBox31.BackColor = System.Drawing.Color.Transparent;
			groupBox31.BackgroundImage = null;
			groupBox31.Controls.Add(checkBox55);
			groupBox31.Controls.Add(checkBox56);
			groupBox31.Controls.Add(textBox32);
			groupBox31.Controls.Add(checkBox57);
			groupBox31.Controls.Add(checkBox58);
			groupBox31.Controls.Add(checkBox59);
			groupBox31.Controls.Add(checkBox60);
			groupBox31.Controls.Add(checkBox61);
			groupBox31.Name = "groupBox31";
			groupBox31.TabStop = false;
			checkBox55.AccessibleDescription = null;
			checkBox55.AccessibleName = null;
			resources.ApplyResources(checkBox55, "checkBox55");
			checkBox55.BackgroundImage = null;
			checkBox55.Name = "checkBox55";
			checkBox55.UseVisualStyleBackColor = true;
			checkBox56.AccessibleDescription = null;
			checkBox56.AccessibleName = null;
			resources.ApplyResources(checkBox56, "checkBox56");
			checkBox56.BackgroundImage = null;
			checkBox56.Name = "checkBox56";
			checkBox56.UseVisualStyleBackColor = true;
			textBox32.AccessibleDescription = null;
			textBox32.AccessibleName = null;
			resources.ApplyResources(textBox32, "textBox32");
			textBox32.BackgroundImage = null;
			textBox32.Font = null;
			textBox32.Name = "textBox32";
			checkBox57.AccessibleDescription = null;
			checkBox57.AccessibleName = null;
			resources.ApplyResources(checkBox57, "checkBox57");
			checkBox57.BackgroundImage = null;
			checkBox57.Name = "checkBox57";
			checkBox57.UseVisualStyleBackColor = true;
			checkBox58.AccessibleDescription = null;
			checkBox58.AccessibleName = null;
			resources.ApplyResources(checkBox58, "checkBox58");
			checkBox58.BackgroundImage = null;
			checkBox58.Name = "checkBox58";
			checkBox58.UseVisualStyleBackColor = true;
			checkBox59.AccessibleDescription = null;
			checkBox59.AccessibleName = null;
			resources.ApplyResources(checkBox59, "checkBox59");
			checkBox59.BackgroundImage = null;
			checkBox59.Name = "checkBox59";
			checkBox59.UseVisualStyleBackColor = true;
			checkBox60.AccessibleDescription = null;
			checkBox60.AccessibleName = null;
			resources.ApplyResources(checkBox60, "checkBox60");
			checkBox60.BackgroundImage = null;
			checkBox60.Name = "checkBox60";
			checkBox60.UseVisualStyleBackColor = true;
			checkBox61.AccessibleDescription = null;
			checkBox61.AccessibleName = null;
			resources.ApplyResources(checkBox61, "checkBox61");
			checkBox61.BackgroundImage = null;
			checkBox61.Name = "checkBox61";
			checkBox61.UseVisualStyleBackColor = true;
			tabPage11.AccessibleDescription = null;
			tabPage11.AccessibleName = null;
			resources.ApplyResources(tabPage11, "tabPage11");
			tabPage11.BackColor = System.Drawing.Color.LightSteelBlue;
			tabPage11.BackgroundImage = null;
			tabPage11.Controls.Add(groupBox32);
			tabPage11.Font = null;
			tabPage11.Name = "tabPage11";
			tabPage11.UseVisualStyleBackColor = true;
			groupBox32.AccessibleDescription = null;
			groupBox32.AccessibleName = null;
			resources.ApplyResources(groupBox32, "groupBox32");
			groupBox32.BackgroundImage = null;
			groupBox32.Controls.Add(comboBox50);
			groupBox32.Controls.Add(comboBox51);
			groupBox32.Controls.Add(label142);
			groupBox32.Controls.Add(dateTimePicker9);
			groupBox32.Controls.Add(label143);
			groupBox32.Controls.Add(comboBox52);
			groupBox32.Controls.Add(label144);
			groupBox32.Controls.Add(comboBox53);
			groupBox32.Controls.Add(label145);
			groupBox32.Controls.Add(comboBox54);
			groupBox32.Controls.Add(label146);
			groupBox32.Controls.Add(checkBox62);
			groupBox32.Controls.Add(dateTimePicker10);
			groupBox32.Controls.Add(label147);
			groupBox32.Controls.Add(numericUpDown37);
			groupBox32.Controls.Add(label148);
			groupBox32.Controls.Add(checkBox63);
			groupBox32.Controls.Add(numericUpDown38);
			groupBox32.Controls.Add(label149);
			groupBox32.Controls.Add(comboBox55);
			groupBox32.Controls.Add(label150);
			groupBox32.Controls.Add(numericUpDown39);
			groupBox32.Controls.Add(numericUpDown40);
			groupBox32.Controls.Add(numericUpDown41);
			groupBox32.Controls.Add(label151);
			groupBox32.Controls.Add(numericUpDown42);
			groupBox32.Controls.Add(label152);
			groupBox32.Controls.Add(label153);
			groupBox32.Controls.Add(label154);
			groupBox32.Controls.Add(numericUpDown43);
			groupBox32.Controls.Add(numericUpDown44);
			groupBox32.Controls.Add(label155);
			groupBox32.Controls.Add(numericUpDown45);
			groupBox32.Controls.Add(label156);
			groupBox32.Controls.Add(numericUpDown46);
			groupBox32.Controls.Add(label157);
			groupBox32.Controls.Add(checkBox64);
			groupBox32.Controls.Add(label158);
			groupBox32.Controls.Add(checkBox65);
			groupBox32.Controls.Add(checkBox66);
			groupBox32.Controls.Add(textBox33);
			groupBox32.Controls.Add(checkBox67);
			groupBox32.Controls.Add(checkBox68);
			groupBox32.Controls.Add(checkBox69);
			groupBox32.Controls.Add(label159);
			groupBox32.Controls.Add(label160);
			groupBox32.Controls.Add(numericUpDown47);
			groupBox32.Controls.Add(numericUpDown48);
			groupBox32.Controls.Add(checkBox70);
			groupBox32.Controls.Add(label161);
			groupBox32.Controls.Add(label162);
			groupBox32.Controls.Add(label163);
			groupBox32.Controls.Add(textBox34);
			groupBox32.Name = "groupBox32";
			groupBox32.TabStop = false;
			comboBox50.AccessibleDescription = null;
			comboBox50.AccessibleName = null;
			resources.ApplyResources(comboBox50, "comboBox50");
			comboBox50.BackgroundImage = null;
			comboBox50.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox50.Font = null;
			comboBox50.FormattingEnabled = true;
			comboBox50.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox50.Items"),
				resources.GetString("comboBox50.Items1")
			});
			comboBox50.Name = "comboBox50";
			comboBox51.AccessibleDescription = null;
			comboBox51.AccessibleName = null;
			resources.ApplyResources(comboBox51, "comboBox51");
			comboBox51.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox51.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox51.BackgroundImage = null;
			comboBox51.Font = null;
			comboBox51.FormattingEnabled = true;
			comboBox51.Name = "comboBox51";
			dateTimePicker9.AccessibleDescription = null;
			dateTimePicker9.AccessibleName = null;
			resources.ApplyResources(dateTimePicker9, "dateTimePicker9");
			dateTimePicker9.BackgroundImage = null;
			dateTimePicker9.CalendarFont = null;
			dateTimePicker9.CustomFormat = null;
			dateTimePicker9.Font = null;
			dateTimePicker9.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			dateTimePicker9.Name = "dateTimePicker9";
			comboBox52.AccessibleDescription = null;
			comboBox52.AccessibleName = null;
			resources.ApplyResources(comboBox52, "comboBox52");
			comboBox52.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox52.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox52.BackgroundImage = null;
			comboBox52.Font = null;
			comboBox52.FormattingEnabled = true;
			comboBox52.Name = "comboBox52";
			comboBox53.AccessibleDescription = null;
			comboBox53.AccessibleName = null;
			resources.ApplyResources(comboBox53, "comboBox53");
			comboBox53.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox53.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox53.BackgroundImage = null;
			comboBox53.Font = null;
			comboBox53.FormattingEnabled = true;
			comboBox53.Name = "comboBox53";
			comboBox54.AccessibleDescription = null;
			comboBox54.AccessibleName = null;
			resources.ApplyResources(comboBox54, "comboBox54");
			comboBox54.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox54.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox54.BackgroundImage = null;
			comboBox54.Font = null;
			comboBox54.FormattingEnabled = true;
			comboBox54.Name = "comboBox54";
			checkBox62.AccessibleDescription = null;
			checkBox62.AccessibleName = null;
			resources.ApplyResources(checkBox62, "checkBox62");
			checkBox62.BackgroundImage = null;
			checkBox62.Name = "checkBox62";
			checkBox62.UseVisualStyleBackColor = true;
			dateTimePicker10.AccessibleDescription = null;
			dateTimePicker10.AccessibleName = null;
			resources.ApplyResources(dateTimePicker10, "dateTimePicker10");
			dateTimePicker10.BackgroundImage = null;
			dateTimePicker10.CalendarFont = null;
			dateTimePicker10.CustomFormat = null;
			dateTimePicker10.Font = null;
			dateTimePicker10.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			dateTimePicker10.Name = "dateTimePicker10";
			numericUpDown37.AccessibleDescription = null;
			numericUpDown37.AccessibleName = null;
			resources.ApplyResources(numericUpDown37, "numericUpDown37");
			numericUpDown37.DecimalPlaces = 2;
			numericUpDown37.Font = null;
			numericUpDown37.Name = "numericUpDown37";
			checkBox63.AccessibleDescription = null;
			checkBox63.AccessibleName = null;
			resources.ApplyResources(checkBox63, "checkBox63");
			checkBox63.BackgroundImage = null;
			checkBox63.Name = "checkBox63";
			checkBox63.UseVisualStyleBackColor = true;
			numericUpDown38.AccessibleDescription = null;
			numericUpDown38.AccessibleName = null;
			resources.ApplyResources(numericUpDown38, "numericUpDown38");
			numericUpDown38.Font = null;
			numericUpDown38.Name = "numericUpDown38";
			comboBox55.AccessibleDescription = null;
			comboBox55.AccessibleName = null;
			resources.ApplyResources(comboBox55, "comboBox55");
			comboBox55.BackgroundImage = null;
			comboBox55.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox55.Font = null;
			comboBox55.FormattingEnabled = true;
			comboBox55.Items.AddRange(new object[3]
			{
				resources.GetString("comboBox55.Items"),
				resources.GetString("comboBox55.Items1"),
				resources.GetString("comboBox55.Items2")
			});
			comboBox55.Name = "comboBox55";
			numericUpDown39.AccessibleDescription = null;
			numericUpDown39.AccessibleName = null;
			resources.ApplyResources(numericUpDown39, "numericUpDown39");
			numericUpDown39.DecimalPlaces = 2;
			numericUpDown39.Font = null;
			numericUpDown39.Name = "numericUpDown39";
			numericUpDown40.AccessibleDescription = null;
			numericUpDown40.AccessibleName = null;
			resources.ApplyResources(numericUpDown40, "numericUpDown40");
			numericUpDown40.DecimalPlaces = 2;
			numericUpDown40.Font = null;
			numericUpDown40.Name = "numericUpDown40";
			numericUpDown41.AccessibleDescription = null;
			numericUpDown41.AccessibleName = null;
			resources.ApplyResources(numericUpDown41, "numericUpDown41");
			numericUpDown41.DecimalPlaces = 2;
			numericUpDown41.Font = null;
			numericUpDown41.Name = "numericUpDown41";
			numericUpDown42.AccessibleDescription = null;
			numericUpDown42.AccessibleName = null;
			resources.ApplyResources(numericUpDown42, "numericUpDown42");
			numericUpDown42.Font = null;
			numericUpDown42.Name = "numericUpDown42";
			numericUpDown43.AccessibleDescription = null;
			numericUpDown43.AccessibleName = null;
			resources.ApplyResources(numericUpDown43, "numericUpDown43");
			numericUpDown43.Font = null;
			numericUpDown43.Name = "numericUpDown43";
			numericUpDown44.AccessibleDescription = null;
			numericUpDown44.AccessibleName = null;
			resources.ApplyResources(numericUpDown44, "numericUpDown44");
			numericUpDown44.Font = null;
			numericUpDown44.Name = "numericUpDown44";
			numericUpDown45.AccessibleDescription = null;
			numericUpDown45.AccessibleName = null;
			resources.ApplyResources(numericUpDown45, "numericUpDown45");
			numericUpDown45.Font = null;
			numericUpDown45.Name = "numericUpDown45";
			numericUpDown46.AccessibleDescription = null;
			numericUpDown46.AccessibleName = null;
			resources.ApplyResources(numericUpDown46, "numericUpDown46");
			numericUpDown46.Font = null;
			numericUpDown46.Maximum = new decimal(new int[4] { 9, 0, 0, 0 });
			numericUpDown46.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			numericUpDown46.Name = "numericUpDown46";
			numericUpDown46.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			checkBox64.AccessibleDescription = null;
			checkBox64.AccessibleName = null;
			resources.ApplyResources(checkBox64, "checkBox64");
			checkBox64.BackgroundImage = null;
			checkBox64.Name = "checkBox64";
			checkBox64.UseVisualStyleBackColor = true;
			checkBox65.AccessibleDescription = null;
			checkBox65.AccessibleName = null;
			resources.ApplyResources(checkBox65, "checkBox65");
			checkBox65.BackgroundImage = null;
			checkBox65.Name = "checkBox65";
			checkBox65.UseVisualStyleBackColor = true;
			checkBox66.AccessibleDescription = null;
			checkBox66.AccessibleName = null;
			resources.ApplyResources(checkBox66, "checkBox66");
			checkBox66.BackgroundImage = null;
			checkBox66.Name = "checkBox66";
			checkBox66.UseVisualStyleBackColor = true;
			textBox33.AccessibleDescription = null;
			textBox33.AccessibleName = null;
			resources.ApplyResources(textBox33, "textBox33");
			textBox33.BackgroundImage = null;
			textBox33.Font = null;
			textBox33.Name = "textBox33";
			checkBox67.AccessibleDescription = null;
			checkBox67.AccessibleName = null;
			resources.ApplyResources(checkBox67, "checkBox67");
			checkBox67.BackgroundImage = null;
			checkBox67.Name = "checkBox67";
			checkBox67.UseVisualStyleBackColor = true;
			checkBox68.AccessibleDescription = null;
			checkBox68.AccessibleName = null;
			resources.ApplyResources(checkBox68, "checkBox68");
			checkBox68.BackgroundImage = null;
			checkBox68.Name = "checkBox68";
			checkBox68.UseVisualStyleBackColor = true;
			checkBox69.AccessibleDescription = null;
			checkBox69.AccessibleName = null;
			resources.ApplyResources(checkBox69, "checkBox69");
			checkBox69.BackgroundImage = null;
			checkBox69.Name = "checkBox69";
			checkBox69.UseVisualStyleBackColor = true;
			numericUpDown47.AccessibleDescription = null;
			numericUpDown47.AccessibleName = null;
			resources.ApplyResources(numericUpDown47, "numericUpDown47");
			numericUpDown47.DecimalPlaces = 2;
			numericUpDown47.Font = null;
			numericUpDown47.Name = "numericUpDown47";
			numericUpDown48.AccessibleDescription = null;
			numericUpDown48.AccessibleName = null;
			resources.ApplyResources(numericUpDown48, "numericUpDown48");
			numericUpDown48.Font = null;
			numericUpDown48.Name = "numericUpDown48";
			checkBox70.AccessibleDescription = null;
			checkBox70.AccessibleName = null;
			resources.ApplyResources(checkBox70, "checkBox70");
			checkBox70.BackgroundImage = null;
			checkBox70.Name = "checkBox70";
			checkBox70.UseVisualStyleBackColor = true;
			textBox34.AccessibleDescription = null;
			textBox34.AccessibleName = null;
			resources.ApplyResources(textBox34, "textBox34");
			textBox34.BackgroundImage = null;
			textBox34.Name = "textBox34";
			tabPage12.AccessibleDescription = null;
			tabPage12.AccessibleName = null;
			resources.ApplyResources(tabPage12, "tabPage12");
			tabPage12.BackColor = System.Drawing.Color.LightSteelBlue;
			tabPage12.BackgroundImage = null;
			tabPage12.Controls.Add(groupBox33);
			tabPage12.Font = null;
			tabPage12.Name = "tabPage12";
			tabPage12.UseVisualStyleBackColor = true;
			groupBox33.AccessibleDescription = null;
			groupBox33.AccessibleName = null;
			resources.ApplyResources(groupBox33, "groupBox33");
			groupBox33.BackgroundImage = null;
			groupBox33.Controls.Add(numericUpDown49);
			groupBox33.Controls.Add(button28);
			groupBox33.Controls.Add(comboBox56);
			groupBox33.Controls.Add(label164);
			groupBox33.Controls.Add(comboBox57);
			groupBox33.Controls.Add(label165);
			groupBox33.Controls.Add(comboBox58);
			groupBox33.Controls.Add(label166);
			groupBox33.Controls.Add(comboBox59);
			groupBox33.Controls.Add(label167);
			groupBox33.Controls.Add(comboBox60);
			groupBox33.Controls.Add(label168);
			groupBox33.Controls.Add(comboBox61);
			groupBox33.Controls.Add(label169);
			groupBox33.Controls.Add(numericUpDown50);
			groupBox33.Controls.Add(label179);
			groupBox33.Controls.Add(label180);
			groupBox33.Controls.Add(dataGridView3);
			groupBox33.Font = null;
			groupBox33.Name = "groupBox33";
			groupBox33.TabStop = false;
			numericUpDown49.AccessibleDescription = null;
			numericUpDown49.AccessibleName = null;
			resources.ApplyResources(numericUpDown49, "numericUpDown49");
			numericUpDown49.Font = null;
			numericUpDown49.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			numericUpDown49.Name = "numericUpDown49";
			numericUpDown49.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			button28.AccessibleDescription = null;
			button28.AccessibleName = null;
			resources.ApplyResources(button28, "button28");
			button28.BackgroundImage = null;
			button28.Font = null;
			button28.Name = "button28";
			button28.UseVisualStyleBackColor = true;
			comboBox56.AccessibleDescription = null;
			comboBox56.AccessibleName = null;
			resources.ApplyResources(comboBox56, "comboBox56");
			comboBox56.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox56.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox56.BackgroundImage = null;
			comboBox56.Font = null;
			comboBox56.FormattingEnabled = true;
			comboBox56.Name = "comboBox56";
			comboBox57.AccessibleDescription = null;
			comboBox57.AccessibleName = null;
			resources.ApplyResources(comboBox57, "comboBox57");
			comboBox57.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox57.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox57.BackgroundImage = null;
			comboBox57.Font = null;
			comboBox57.FormattingEnabled = true;
			comboBox57.Name = "comboBox57";
			comboBox58.AccessibleDescription = null;
			comboBox58.AccessibleName = null;
			resources.ApplyResources(comboBox58, "comboBox58");
			comboBox58.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox58.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox58.BackgroundImage = null;
			comboBox58.Font = null;
			comboBox58.FormattingEnabled = true;
			comboBox58.Name = "comboBox58";
			comboBox59.AccessibleDescription = null;
			comboBox59.AccessibleName = null;
			resources.ApplyResources(comboBox59, "comboBox59");
			comboBox59.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox59.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox59.BackgroundImage = null;
			comboBox59.Font = null;
			comboBox59.FormattingEnabled = true;
			comboBox59.Name = "comboBox59";
			comboBox60.AccessibleDescription = null;
			comboBox60.AccessibleName = null;
			resources.ApplyResources(comboBox60, "comboBox60");
			comboBox60.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox60.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox60.BackgroundImage = null;
			comboBox60.Font = null;
			comboBox60.FormattingEnabled = true;
			comboBox60.Name = "comboBox60";
			comboBox61.AccessibleDescription = null;
			comboBox61.AccessibleName = null;
			resources.ApplyResources(comboBox61, "comboBox61");
			comboBox61.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox61.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox61.BackgroundImage = null;
			comboBox61.Font = null;
			comboBox61.FormattingEnabled = true;
			comboBox61.Name = "comboBox61";
			numericUpDown50.AccessibleDescription = null;
			numericUpDown50.AccessibleName = null;
			resources.ApplyResources(numericUpDown50, "numericUpDown50");
			numericUpDown50.DecimalPlaces = 2;
			numericUpDown50.Font = null;
			numericUpDown50.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			numericUpDown50.Name = "numericUpDown50";
			label179.AccessibleDescription = null;
			label179.AccessibleName = null;
			resources.ApplyResources(label179, "label179");
			label179.Font = null;
			label179.Name = "label179";
			label180.AccessibleDescription = null;
			label180.AccessibleName = null;
			resources.ApplyResources(label180, "label180");
			label180.Font = null;
			label180.Name = "label180";
			dataGridView3.AccessibleDescription = null;
			dataGridView3.AccessibleName = null;
			dataGridView3.AllowUserToAddRows = false;
			resources.ApplyResources(dataGridView3, "dataGridView3");
			dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView3.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView3.BackgroundImage = null;
			dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView3.Columns.AddRange(dataGridViewTextBoxColumn9, dataGridViewTextBoxColumn10, dataGridViewTextBoxColumn11, dataGridViewTextBoxColumn12, dataGridViewTextBoxColumn13, dataGridViewTextBoxColumn14, dataGridViewTextBoxColumn15, dataGridViewTextBoxColumn16);
			dataGridView3.Font = null;
			dataGridView3.GridColor = System.Drawing.Color.LightSteelBlue;
			dataGridView3.Name = "dataGridView3";
			resources.ApplyResources(dataGridViewTextBoxColumn9, "dataGridViewTextBoxColumn9");
			dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
			dataGridViewTextBoxColumn9.ReadOnly = true;
			resources.ApplyResources(dataGridViewTextBoxColumn10, "dataGridViewTextBoxColumn10");
			dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
			resources.ApplyResources(dataGridViewTextBoxColumn11, "dataGridViewTextBoxColumn11");
			dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
			dataGridViewTextBoxColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			resources.ApplyResources(dataGridViewTextBoxColumn12, "dataGridViewTextBoxColumn12");
			dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
			dataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			resources.ApplyResources(dataGridViewTextBoxColumn13, "dataGridViewTextBoxColumn13");
			dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
			dataGridViewTextBoxColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			resources.ApplyResources(dataGridViewTextBoxColumn14, "dataGridViewTextBoxColumn14");
			dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
			dataGridViewTextBoxColumn14.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			resources.ApplyResources(dataGridViewTextBoxColumn15, "dataGridViewTextBoxColumn15");
			dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
			dataGridViewTextBoxColumn15.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			dataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			resources.ApplyResources(dataGridViewTextBoxColumn16, "dataGridViewTextBoxColumn16");
			dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
			tabPage13.AccessibleDescription = null;
			tabPage13.AccessibleName = null;
			resources.ApplyResources(tabPage13, "tabPage13");
			tabPage13.BackColor = System.Drawing.Color.LightSteelBlue;
			tabPage13.BackgroundImage = null;
			tabPage13.Controls.Add(groupBox34);
			tabPage13.Font = null;
			tabPage13.Name = "tabPage13";
			groupBox34.AccessibleDescription = null;
			groupBox34.AccessibleName = null;
			resources.ApplyResources(groupBox34, "groupBox34");
			groupBox34.BackgroundImage = null;
			groupBox34.Controls.Add(textBox35);
			groupBox34.Controls.Add(label181);
			groupBox34.Controls.Add(textBox36);
			groupBox34.Controls.Add(textBox37);
			groupBox34.Controls.Add(label182);
			groupBox34.Controls.Add(numericUpDown51);
			groupBox34.Controls.Add(label170);
			groupBox34.Controls.Add(label171);
			groupBox34.Controls.Add(label185);
			groupBox34.Controls.Add(numericUpDown52);
			groupBox34.Controls.Add(label186);
			groupBox34.Controls.Add(label187);
			groupBox34.Controls.Add(numericUpDown53);
			groupBox34.Controls.Add(label172);
			groupBox34.Controls.Add(comboBox62);
			groupBox34.Controls.Add(label173);
			groupBox34.Controls.Add(comboBox63);
			groupBox34.Controls.Add(label174);
			groupBox34.Controls.Add(numericUpDown54);
			groupBox34.Controls.Add(label191);
			groupBox34.Controls.Add(label192);
			groupBox34.Font = null;
			groupBox34.Name = "groupBox34";
			groupBox34.TabStop = false;
			textBox35.AccessibleDescription = null;
			textBox35.AccessibleName = null;
			resources.ApplyResources(textBox35, "textBox35");
			textBox35.BackgroundImage = null;
			textBox35.Font = null;
			textBox35.Name = "textBox35";
			label181.AccessibleDescription = null;
			label181.AccessibleName = null;
			resources.ApplyResources(label181, "label181");
			label181.Font = null;
			label181.Name = "label181";
			textBox36.AccessibleDescription = null;
			textBox36.AccessibleName = null;
			resources.ApplyResources(textBox36, "textBox36");
			textBox36.BackgroundImage = null;
			textBox36.Font = null;
			textBox36.Name = "textBox36";
			textBox37.AccessibleDescription = null;
			textBox37.AccessibleName = null;
			resources.ApplyResources(textBox37, "textBox37");
			textBox37.BackgroundImage = null;
			textBox37.Font = null;
			textBox37.Name = "textBox37";
			label182.AccessibleDescription = null;
			label182.AccessibleName = null;
			resources.ApplyResources(label182, "label182");
			label182.Font = null;
			label182.Name = "label182";
			numericUpDown51.AccessibleDescription = null;
			numericUpDown51.AccessibleName = null;
			resources.ApplyResources(numericUpDown51, "numericUpDown51");
			numericUpDown51.DecimalPlaces = 2;
			numericUpDown51.Font = null;
			numericUpDown51.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			numericUpDown51.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			numericUpDown51.Name = "numericUpDown51";
			label185.AccessibleDescription = null;
			label185.AccessibleName = null;
			resources.ApplyResources(label185, "label185");
			label185.Font = null;
			label185.Name = "label185";
			numericUpDown52.AccessibleDescription = null;
			numericUpDown52.AccessibleName = null;
			resources.ApplyResources(numericUpDown52, "numericUpDown52");
			numericUpDown52.DecimalPlaces = 2;
			numericUpDown52.Font = null;
			numericUpDown52.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			numericUpDown52.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			numericUpDown52.Name = "numericUpDown52";
			label186.AccessibleDescription = null;
			label186.AccessibleName = null;
			resources.ApplyResources(label186, "label186");
			label186.Font = null;
			label186.Name = "label186";
			label187.AccessibleDescription = null;
			label187.AccessibleName = null;
			resources.ApplyResources(label187, "label187");
			label187.Font = null;
			label187.Name = "label187";
			numericUpDown53.AccessibleDescription = null;
			numericUpDown53.AccessibleName = null;
			resources.ApplyResources(numericUpDown53, "numericUpDown53");
			numericUpDown53.Font = null;
			numericUpDown53.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			numericUpDown53.Name = "numericUpDown53";
			numericUpDown53.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			comboBox62.AccessibleDescription = null;
			comboBox62.AccessibleName = null;
			resources.ApplyResources(comboBox62, "comboBox62");
			comboBox62.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox62.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox62.BackgroundImage = null;
			comboBox62.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox62.Font = null;
			comboBox62.FormattingEnabled = true;
			comboBox62.Items.AddRange(new object[3]
			{
				resources.GetString("comboBox62.Items"),
				resources.GetString("comboBox62.Items1"),
				resources.GetString("comboBox62.Items2")
			});
			comboBox62.Name = "comboBox62";
			comboBox63.AccessibleDescription = null;
			comboBox63.AccessibleName = null;
			resources.ApplyResources(comboBox63, "comboBox63");
			comboBox63.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox63.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox63.BackgroundImage = null;
			comboBox63.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox63.Font = null;
			comboBox63.FormattingEnabled = true;
			comboBox63.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox63.Items"),
				resources.GetString("comboBox63.Items1")
			});
			comboBox63.Name = "comboBox63";
			numericUpDown54.AccessibleDescription = null;
			numericUpDown54.AccessibleName = null;
			resources.ApplyResources(numericUpDown54, "numericUpDown54");
			numericUpDown54.DecimalPlaces = 2;
			numericUpDown54.Font = null;
			numericUpDown54.Maximum = new decimal(new int[4] { 300, 0, 0, 0 });
			numericUpDown54.Minimum = new decimal(new int[4] { 1, 0, 0, -2147483648 });
			numericUpDown54.Name = "numericUpDown54";
			label191.AccessibleDescription = null;
			label191.AccessibleName = null;
			resources.ApplyResources(label191, "label191");
			label191.Font = null;
			label191.Name = "label191";
			label192.AccessibleDescription = null;
			label192.AccessibleName = null;
			resources.ApplyResources(label192, "label192");
			label192.Font = null;
			label192.Name = "label192";
			tabPage14.AccessibleDescription = null;
			tabPage14.AccessibleName = null;
			resources.ApplyResources(tabPage14, "tabPage14");
			tabPage14.BackgroundImage = null;
			tabPage14.Font = null;
			tabPage14.Name = "tabPage14";
			tabPage14.UseVisualStyleBackColor = true;
			base.AcceptButton = saveBtn;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(groupBox5);
			base.Controls.Add(LightSteelBlue);
			base.Controls.Add(flowLayoutPanel1);
			Font = null;
			base.KeyPreview = true;
			base.MaximizeBox = true;
			base.Name = "PationtInfo";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.Load += new System.EventHandler(PationtInfo_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(PationtInfo_KeyDown);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			CommentPanel.ResumeLayout(false);
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			panel3.ResumeLayout(false);
			panel3.PerformLayout();
			panel2.ResumeLayout(false);
			panel2.PerformLayout();
			groupBox7.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			groupBox5.ResumeLayout(false);
			groupBox5.PerformLayout();
			panel1.ResumeLayout(false);
			groupBox6.ResumeLayout(false);
			groupBox6.PerformLayout();
			groupBox8.ResumeLayout(false);
			groupBox1.ResumeLayout(false);
			LightSteelBlue.ResumeLayout(false);
			tabPage1.ResumeLayout(false);
			groupBox11.ResumeLayout(false);
			tabPage2.ResumeLayout(false);
			groupBox9.ResumeLayout(false);
			groupBox9.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown12).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown11).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown10).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown9).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown8).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown7).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown6).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown5).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown4).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown3).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
			tabPage3.ResumeLayout(false);
			groupBox10.ResumeLayout(false);
			groupBox10.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown14).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown13).EndInit();
			tabPage4.ResumeLayout(false);
			groupBox12.ResumeLayout(false);
			groupBox12.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown18).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown17).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown15).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown16).EndInit();
			tabPage9.ResumeLayout(false);
			groupBox35.ResumeLayout(false);
			groupBox35.PerformLayout();
			((System.ComponentModel.ISupportInitialize)FatsRate).EndInit();
			((System.ComponentModel.ISupportInitialize)MusclesRate).EndInit();
			((System.ComponentModel.ISupportInitialize)hieght).EndInit();
			((System.ComponentModel.ISupportInitialize)wieght).EndInit();
			tabPage5.ResumeLayout(false);
			groupBox13.ResumeLayout(false);
			groupBox14.ResumeLayout(false);
			groupBox14.PerformLayout();
			groupBox15.ResumeLayout(false);
			groupBox15.PerformLayout();
			panel4.ResumeLayout(false);
			panel4.PerformLayout();
			panel5.ResumeLayout(false);
			panel5.PerformLayout();
			groupBox16.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
			groupBox17.ResumeLayout(false);
			groupBox18.ResumeLayout(false);
			groupBox18.PerformLayout();
			groupBox19.ResumeLayout(false);
			groupBox20.ResumeLayout(false);
			groupBox20.PerformLayout();
			tabPage6.ResumeLayout(false);
			groupBox21.ResumeLayout(false);
			groupBox21.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown19).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown20).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown21).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown22).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown23).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown24).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown25).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown26).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown27).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown28).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown29).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown30).EndInit();
			tabPage7.ResumeLayout(false);
			groupBox22.ResumeLayout(false);
			groupBox22.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown31).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown32).EndInit();
			((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
			tabPage8.ResumeLayout(false);
			groupBox23.ResumeLayout(false);
			groupBox23.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown33).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown34).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown35).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown36).EndInit();
			tabPage10.ResumeLayout(false);
			groupBox24.ResumeLayout(false);
			groupBox25.ResumeLayout(false);
			groupBox25.PerformLayout();
			groupBox26.ResumeLayout(false);
			groupBox26.PerformLayout();
			panel6.ResumeLayout(false);
			panel6.PerformLayout();
			panel7.ResumeLayout(false);
			panel7.PerformLayout();
			groupBox27.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
			groupBox28.ResumeLayout(false);
			groupBox29.ResumeLayout(false);
			groupBox29.PerformLayout();
			groupBox30.ResumeLayout(false);
			groupBox31.ResumeLayout(false);
			groupBox31.PerformLayout();
			tabPage11.ResumeLayout(false);
			groupBox32.ResumeLayout(false);
			groupBox32.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown37).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown38).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown39).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown40).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown41).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown42).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown43).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown44).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown45).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown46).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown47).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown48).EndInit();
			tabPage12.ResumeLayout(false);
			groupBox33.ResumeLayout(false);
			groupBox33.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown49).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown50).EndInit();
			((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
			tabPage13.ResumeLayout(false);
			groupBox34.ResumeLayout(false);
			groupBox34.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown51).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown52).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown53).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown54).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
