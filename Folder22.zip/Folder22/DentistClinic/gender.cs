using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using FloatTextBox;

namespace DentistClinic
{
	public class gender : BaseForm
	{
		private ClassDataBase dc;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		private GUI gui = new GUI();

		private string PatientID = "";

		private IContainer components = null;

		private GroupBox groupBox4;

		private Label label15;

		private TabControl tabControl1;

		private TabPage tabPage1;

		private TabPage tabPage2;

		private TabPage tabPage3;

		private TabPage tabPage4;

		private TabPage tabPage5;

		private TabPage tabPage6;

		private TabPage tabPage7;

		private TabPage tabPage8;

		private TabPage tabPage9;

		private TabPage tabPage10;

		private TabPage tabPage11;

		private TabPage tabPage12;

		private TabPage tabPage13;

		private Button update;

		private Button save;

		private FloatText age;

		private TextBox sex;

		private TextBox IPOP;

		private ComboBox PatientName;

		private DateTimePicker birthDateDateTimePicker;

		private DataGridView DGVitalSigns;

		private DataGridView DGNerves;

		private DataGridView DGRangeofMotion;

		private DataGridView DGMuscleTone2;

		private DataGridView DGMuscleTone1;

		private DataGridView DGCoordination1;

		private DataGridView DGReflexes;

		private DataGridView DGCoordination2;

		private TextBox Typee;

		private TextBox SymptomsHistory;

		private TextBox Onset;

		private TextBox SocioeconomicHistory;

		private TextBox Severity;

		private TextBox Duration;

		private new TextBox Site;

		private TextBox FamilyHistory;

		private TextBox PersonalHistory;

		private TextBox PastMedicalHistory;

		private TextBox ChiefComplaints;

		private TextBox Occupation;

		private TextBox RelievingFactors;

		private TextBox AggravatingFactors;

		private TextBox Time;

		private TextBox Place;

		private TextBox Person;

		private TextBox Orientation;

		private TextBox Consciousness;

		private TextBox Tenderness;

		private TextBox Warmth;

		private TextBox Tone;

		private TextBox Swelling;

		private TextBox ExternalAppliances;

		private TextBox Wounds;

		private TextBox Deformity;

		private TextBox PressureSores;

		private TextBox MuscleWasting;

		private TextBox Oedema;

		private TextBox Respiration;

		private TextBox ModeofVentilation;

		private TextBox PatternofMovement;

		private TextBox Gait;

		private TextBox Posture;

		private TextBox Built;

		private TextBox Attitudeoflimbs;

		private TextBox SpecialSenses;

		private TextBox AgnosiasApraxias;

		private TextBox Imaging;

		private TextBox Perception;

		private TextBox EmotionalStatus;

		private TextBox Attention;

		private TextBox ProverbInterpretation;

		private TextBox Calculation;

		private TextBox FundofKnowledge;

		private TextBox Cognition;

		private TextBox Communication;

		private TextBox Visual;

		private TextBox Verbal;

		private TextBox Remote;

		private TextBox Recent;

		private TextBox Immediate;

		private TextBox Memory;

		private TextBox Pathological;

		private TextBox Lying;

		private TextBox Standing;

		private TextBox Sitting;

		private TextBox Balance;

		private TextBox AssisstiveDevices;

		private TextBox BiomechanicalDeviations;

		private TextBox HandFunctions;

		private TextBox Grasping;

		private TextBox Releasing;

		private TextBox Sitting2;

		private TextBox Standing2;

		private TextBox StepLength;

		private TextBox StrideLength;

		private TextBox Basewidth;

		private TextBox Cadence;

		private TextBox Posturee;

		private TextBox BalanceReactions;

		private TextBox Status;

		private TextBox Incontinence;

		private TextBox ReflexSympatheticDystrophy;

		private TextBox PosturalHypotension;

		private TextBox TrophicChanges;

		private TextBox Pseudomotor;

		private TextBox Otherpathology;

		private TextBox Jointmobility;

		private TextBox Vasomotor;

		private TextBox Subluxations;

		private TextBox Contractures;

		private TextBox SkinStatus;

		private ComboBox Devicescomb;

		private TextBox Longterm;

		private TextBox Goals;

		private TextBox Shortterm;

		private TextBox FunctionalDiagnosis;

		private TextBox Referredby;

		private TextBox Sidee;

		private TextBox address;

		private DataGridView DGSENSORYSYS;

		private DataGridView dataGridView1;

		private DataGridView DGVoluntaryControl;

		private DataGridView DGMuscleGirth;

		private TextBox Handedness;

		private TextBox MOTORSYSTEM;

		private TextBox InvoluntaryMovements;

		private TextBox Reaching;

		private TextBox IntegSystem;

		private TextBox Thrombosis;

		private TextBox CVSStatus;

		private TextBox spinedeformity;

		private TextBox Patternofbreathing;

		private TextBox Secretions;

		private TextBox RSStatus;

		private TextBox RESPIRATORYSYSTEM;

		private TextBox PressureSoress;

		private TextBox InvestigationFindings;

		private TextBox Item17;

		private TextBox Item16;

		private TextBox Item15;

		private TextBox Item10;

		private TextBox Item9;

		private TextBox Item8;

		private TextBox Item11;

		private TextBox Evaluation5;

		private TextBox Item13;

		private TextBox Item14;

		private TextBox Evaluation4;

		private TextBox Item2;

		private TextBox Item3;

		private TextBox Item5;

		private TextBox Evaluation2;

		private TextBox Item6;

		private TextBox Item7;

		private TextBox Evaluation3;

		private TextBox Evaluation6;

		private TextBox Item4;

		private TextBox Item12;

		private TextBox Item1;

		private TextBox Evaluation1;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Column2;

		private DataGridViewTextBoxColumn Column3;

		private DataGridViewTextBoxColumn Column4;

		private DataGridViewTextBoxColumn Nerves;

		private DataGridViewTextBoxColumn Comments;

		private DataGridViewTextBoxColumn Nerves2;

		private DataGridViewTextBoxColumn Comments2;

		private DataGridViewTextBoxColumn Sideee;

		private DataGridViewTextBoxColumn Rt_;

		private DataGridViewTextBoxColumn Lt_;

		private DataGridViewTextBoxColumn Area;

		private DataGridViewTextBoxColumn Rt_cm;

		private DataGridViewTextBoxColumn Lt_cm;

		private DataGridViewTextBoxColumn Column9;

		private DataGridViewTextBoxColumn Rt1;

		private DataGridViewTextBoxColumn Lt1;

		private DataGridViewTextBoxColumn Rt22;

		private DataGridViewTextBoxColumn Lt22;

		private DataGridViewTextBoxColumn Rt3;

		private DataGridViewTextBoxColumn Lt3;

		private DataGridViewTextBoxColumn notes;

		private new DataGridViewTextBoxColumn Location;

		private DataGridViewTextBoxColumn Column5;

		private DataGridViewTextBoxColumn Column6;

		private DataGridViewTextBoxColumn Column7;

		private DataGridViewTextBoxColumn Column8;

		private DataGridViewTextBoxColumn Joint;

		private DataGridViewTextBoxColumn Side;

		private DataGridViewTextBoxColumn Movement;

		private DataGridViewTextBoxColumn Limitation;

		private DataGridViewTextBoxColumn Limitingfactor;

		private DataGridView DGLimbLength;

		private DataGridView DGRangeofMotion2;

		private DataGridView DGMusclePower1;

		private DataGridView DGMusclePower2;

		private DataGridViewTextBoxColumn Equilibriumtests;

		private DataGridViewTextBoxColumn Grade;

		private DataGridViewTextBoxColumn NonEquilibriumTests;

		private DataGridViewTextBoxColumn RT2;

		private DataGridViewTextBoxColumn LT2;

		private DataGridViewTextBoxColumn Reflex;

		private new DataGridViewTextBoxColumn Left;

		private new DataGridViewTextBoxColumn Right;

		private DataGridView DGProblemList;

		private DataGridViewTextBoxColumn Sl;

		private DataGridViewTextBoxColumn Impairment;

		private DataGridViewTextBoxColumn FunctionalLimitation;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;

		private DataGridViewTextBoxColumn PRT2;

		private DataGridViewTextBoxColumn PLT2;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;

		private DataGridViewTextBoxColumn TRT2;

		private DataGridViewTextBoxColumn TLT2;

		private DataGridViewTextBoxColumn Muscles;

		private DataGridViewTextBoxColumn TRT;

		private DataGridViewTextBoxColumn TLT;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;

		private DataGridViewTextBoxColumn Side2;

		private DataGridViewTextBoxColumn Movement2;

		private DataGridViewTextBoxColumn Limitation2;

		private DataGridViewTextBoxColumn Limitingfactor2;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;

		private DataGridViewTextBoxColumn LimbRt;

		private DataGridViewTextBoxColumn LimbLt;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;

		private DataGridViewTextBoxColumn PRT;

		private DataGridViewTextBoxColumn PLT;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlDataAdapter sqlDataAdapter1;

		private DataSet1 dataSet11;

		private SqlCommand sqlCommand1;

		private SqlConnection sqlConnection2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlDeleteCommand;

		private SqlCommand sqlInsertCommand;

		private SqlCommand sqlUpdateCommand;

		private SqlDataAdapter sqlDataAdapter3;

		private SqlCommand sqlCommand2;

		private SqlConnection sqlConnection3;

		private SqlCommand sqlCommand3;

		private SqlCommand sqlCommand4;

		private SqlCommand sqlCommand5;

		private SqlDataAdapter sqlDataAdapter4;

		private SqlCommand sqlCommand6;

		private SqlConnection sqlConnection4;

		private SqlCommand sqlCommand7;

		private SqlCommand sqlCommand8;

		private SqlCommand sqlCommand9;

		private SqlDataAdapter sqlDataAdapter5;

		private SqlCommand sqlCommand10;

		private SqlConnection sqlConnection5;

		private SqlCommand sqlCommand11;

		private SqlCommand sqlCommand12;

		private SqlCommand sqlCommand13;

		private SqlDataAdapter sqlDataAdapter6;

		private SqlCommand sqlCommand14;

		private SqlConnection sqlConnection6;

		private SqlCommand sqlCommand15;

		private SqlCommand sqlCommand16;

		private SqlCommand sqlCommand17;

		private SqlDataAdapter sqlDataAdapter7;

		private SqlCommand sqlCommand18;

		private SqlConnection sqlConnection7;

		private SqlCommand sqlCommand19;

		private SqlCommand sqlCommand20;

		private SqlCommand sqlCommand21;

		private SqlDataAdapter sqlDataAdapter8;

		private SqlCommand sqlCommand22;

		private SqlConnection sqlConnection8;

		private SqlCommand sqlCommand23;

		private SqlCommand sqlCommand24;

		private SqlCommand sqlCommand25;

		private SqlDataAdapter sqlDataAdapter9;

		private SqlCommand sqlCommand26;

		private SqlConnection sqlConnection9;

		private SqlCommand sqlCommand27;

		private SqlCommand sqlCommand28;

		private SqlCommand sqlCommand29;

		private SqlDataAdapter sqlDataAdapter10;

		private SqlCommand sqlCommand30;

		private SqlConnection sqlConnection10;

		private SqlCommand sqlCommand31;

		private SqlCommand sqlCommand32;

		private SqlCommand sqlCommand33;

		private SqlDataAdapter sqlDataAdapter11;

		private SqlCommand sqlCommand34;

		private SqlConnection sqlConnection11;

		private SqlCommand sqlCommand35;

		private SqlCommand sqlCommand36;

		private SqlCommand sqlCommand37;

		private Button Print;

		private Button button1;

		public gender(string ID)
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			PatientID = ID;
		}

		private void gender_Load(object sender, EventArgs e)
		{
			PatientName.SelectedIndexChanged -= PatientName_SelectedIndexChanged;
			DataTable dataTable = codes.Search2("select * from PatientData order by PName");
			PatientName.DataSource = null;
			PatientName.DataSource = dataTable;
			PatientName.DisplayMember = dataTable.Columns["PName"].ToString();
			PatientName.ValueMember = dataTable.Columns[0].ToString();
			PatientName.SelectedIndex = -1;
			PatientName.SelectedIndexChanged += PatientName_SelectedIndexChanged;
			try
			{
				FillDGV();
				DataTable tableText = dc.GetTableText("select ID,Name from NaturalTherapy");
				Devicescomb.DataSource = null;
				Devicescomb.DataSource = tableText;
				Devicescomb.DisplayMember = tableText.Columns["Name"].ToString();
				Devicescomb.ValueMember = tableText.Columns["ID"].ToString();
			}
			catch
			{
			}
			if (PatientID != "")
			{
				PatientName.Text = PatientID;
				PatientName.Enabled = false;
			}
		}

		private void PatientName_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (PatientName.SelectedValue == null)
			{
				return;
			}
			DataTable dataTable = codes.Search2("select * from PatientData where ID = '" + PatientName.SelectedValue.ToString() + "'");
			if (dataTable.Rows.Count > 0)
			{
				address.Text = dataTable.Rows[0]["PAddress"].ToString();
				sex.Text = dataTable.Rows[0]["Sex"].ToString();
				try
				{
					if (dataTable.Rows[0]["BirthDate"].ToString() != "")
					{
						birthDateDateTimePicker.Value = Convert.ToDateTime(dataTable.Rows[0]["BirthDate"]);
						birthDateDateTimePicker_ValueChanged(sender, e);
					}
					else
					{
						age.Text = "";
					}
				}
				catch
				{
				}
			}
			try
			{
				DataTable dataTable2 = codes.Search2("select * from neurological_physiotherapy where PatientID = '" + PatientName.SelectedValue.ToString() + "'");
				if (dataTable2.Rows.Count > 0)
				{
					int num = Convert.ToInt32(dataTable2.Rows[0]["ID"].ToString());
					IPOP.Text = dataTable2.Rows[0]["IPOP"].ToString();
					Handedness.Text = dataTable2.Rows[0]["Handedness"].ToString();
					Occupation.Text = dataTable2.Rows[0]["Occupation"].ToString();
					Referredby.Text = dataTable2.Rows[0]["Referredby"].ToString();
					ChiefComplaints.Text = dataTable2.Rows[0]["ChiefComplaints"].ToString();
					PastMedicalHistory.Text = dataTable2.Rows[0]["PastMedicalHistory"].ToString();
					PersonalHistory.Text = dataTable2.Rows[0]["PersonalHistory"].ToString();
					FamilyHistory.Text = dataTable2.Rows[0]["FamilyHistory"].ToString();
					SocioeconomicHistory.Text = dataTable2.Rows[0]["SocioeconomicHistory"].ToString();
					SymptomsHistory.Text = dataTable2.Rows[0]["SymptomsHistory"].ToString();
					Sidee.Text = dataTable2.Rows[0]["Sidee"].ToString();
					Site.Text = dataTable2.Rows[0]["Site"].ToString();
					Onset.Text = dataTable2.Rows[0]["Onset"].ToString();
					Duration.Text = dataTable2.Rows[0]["Duration"].ToString();
					Typee.Text = dataTable2.Rows[0]["Typee"].ToString();
					Severity.Text = dataTable2.Rows[0]["Severity"].ToString();
					AggravatingFactors.Text = dataTable2.Rows[0]["AggravatingFactors"].ToString();
					RelievingFactors.Text = dataTable2.Rows[0]["RelievingFactors"].ToString();
					DGVitalSigns.Rows[0].Cells["Column2"].Value = dataTable2.Rows[0]["DGVTemperature"].ToString();
					DGVitalSigns.Rows[0].Cells["Column4"].Value = dataTable2.Rows[0]["DGVBloodPressure"].ToString();
					DGVitalSigns.Rows[1].Cells["Column2"].Value = dataTable2.Rows[0]["DGVHeartRate"].ToString();
					DGVitalSigns.Rows[1].Cells["Column4"].Value = dataTable2.Rows[0]["DGVRespiratoryRate"].ToString();
					Attitudeoflimbs.Text = dataTable2.Rows[0]["Attitudeoflimbs"].ToString();
					Built.Text = dataTable2.Rows[0]["Built"].ToString();
					Posture.Text = dataTable2.Rows[0]["Posture"].ToString();
					Gait.Text = dataTable2.Rows[0]["Gait"].ToString();
					PatternofMovement.Text = dataTable2.Rows[0]["PatternofMovement"].ToString();
					ModeofVentilation.Text = dataTable2.Rows[0]["ModeofVentilation"].ToString();
					Respiration.Text = dataTable2.Rows[0]["Respiration"].ToString();
					Oedema.Text = dataTable2.Rows[0]["Oedema"].ToString();
					MuscleWasting.Text = dataTable2.Rows[0]["MuscleWasting"].ToString();
					PressureSores.Text = dataTable2.Rows[0]["PressureSores"].ToString();
					Deformity.Text = dataTable2.Rows[0]["Deformity"].ToString();
					Wounds.Text = dataTable2.Rows[0]["Wounds"].ToString();
					ExternalAppliances.Text = dataTable2.Rows[0]["ExternalAppliances"].ToString();
					Warmth.Text = dataTable2.Rows[0]["Warmth"].ToString();
					Tenderness.Text = dataTable2.Rows[0]["Tenderness"].ToString();
					Tone.Text = dataTable2.Rows[0]["Tone"].ToString();
					Swelling.Text = dataTable2.Rows[0]["Swelling"].ToString();
					Consciousness.Text = dataTable2.Rows[0]["Consciousness"].ToString();
					Orientation.Text = dataTable2.Rows[0]["Orientation"].ToString();
					Person.Text = dataTable2.Rows[0]["Person"].ToString();
					Place.Text = dataTable2.Rows[0]["Place"].ToString();
					Time.Text = dataTable2.Rows[0]["Time"].ToString();
					Memory.Text = dataTable2.Rows[0]["Memory"].ToString();
					Immediate.Text = dataTable2.Rows[0]["Immediate"].ToString();
					Recent.Text = dataTable2.Rows[0]["Recent"].ToString();
					Remote.Text = dataTable2.Rows[0]["Remote"].ToString();
					Verbal.Text = dataTable2.Rows[0]["Verbal"].ToString();
					Visual.Text = dataTable2.Rows[0]["Visual"].ToString();
					Communication.Text = dataTable2.Rows[0]["Communication"].ToString();
					Cognition.Text = dataTable2.Rows[0]["Cognition"].ToString();
					FundofKnowledge.Text = dataTable2.Rows[0]["FundofKnowledge"].ToString();
					Calculation.Text = dataTable2.Rows[0]["Calculation"].ToString();
					ProverbInterpretation.Text = dataTable2.Rows[0]["ProverbInterpretation"].ToString();
					Attention.Text = dataTable2.Rows[0]["Attention"].ToString();
					EmotionalStatus.Text = dataTable2.Rows[0]["EmotionalStatus"].ToString();
					Perception.Text = dataTable2.Rows[0]["Perception"].ToString();
					Imaging.Text = dataTable2.Rows[0]["Imaging"].ToString();
					AgnosiasApraxias.Text = dataTable2.Rows[0]["AgnosiasApraxias"].ToString();
					SpecialSenses.Text = dataTable2.Rows[0]["SpecialSenses"].ToString();
					DGNerves.Rows[0].Cells["Comments"].Value = dataTable2.Rows[0]["DGOlfactory"].ToString();
					DGNerves.Rows[1].Cells["Comments"].Value = dataTable2.Rows[0]["DGOptic"].ToString();
					DGNerves.Rows[2].Cells["Comments"].Value = dataTable2.Rows[0]["DGOculomotor"].ToString();
					DGNerves.Rows[3].Cells["Comments"].Value = dataTable2.Rows[0]["DGTrochlear"].ToString();
					DGNerves.Rows[4].Cells["Comments"].Value = dataTable2.Rows[0]["DGTrigeminal"].ToString();
					DGNerves.Rows[5].Cells["Comments"].Value = dataTable2.Rows[0]["DGAbducent"].ToString();
					DGNerves.Rows[0].Cells["Comments2"].Value = dataTable2.Rows[0]["DGFacial"].ToString();
					DGNerves.Rows[1].Cells["Comments2"].Value = dataTable2.Rows[0]["DGVestibuloCochlear"].ToString();
					DGNerves.Rows[2].Cells["Comments2"].Value = dataTable2.Rows[0]["DGGlossopharyngeal"].ToString();
					DGNerves.Rows[3].Cells["Comments2"].Value = dataTable2.Rows[0]["DGVagus"].ToString();
					DGNerves.Rows[4].Cells["Comments2"].Value = dataTable2.Rows[0]["DGAccessory"].ToString();
					DGNerves.Rows[5].Cells["Comments2"].Value = dataTable2.Rows[0]["DGHypoglossal"].ToString();
					MOTORSYSTEM.Text = dataTable2.Rows[0]["MOTORSYSTEM"].ToString();
					DGMuscleGirth.Rows[0].Cells["Rt_cm"].Value = dataTable2.Rows[0]["DGArmR"].ToString();
					DGMuscleGirth.Rows[0].Cells["Lt_cm"].Value = dataTable2.Rows[0]["DGArmL"].ToString();
					DGMuscleGirth.Rows[1].Cells["Rt_cm"].Value = dataTable2.Rows[0]["DGForearmR"].ToString();
					DGMuscleGirth.Rows[1].Cells["Lt_cm"].Value = dataTable2.Rows[0]["DGForearmL"].ToString();
					DGMuscleGirth.Rows[2].Cells["Rt_cm"].Value = dataTable2.Rows[0]["DGThighR"].ToString();
					DGMuscleGirth.Rows[2].Cells["Lt_cm"].Value = dataTable2.Rows[0]["DGThighL"].ToString();
					DGMuscleGirth.Rows[3].Cells["Rt_cm"].Value = dataTable2.Rows[0]["DGCalfR"].ToString();
					DGMuscleGirth.Rows[3].Cells["Lt_cm"].Value = dataTable2.Rows[0]["DGCalfL"].ToString();
					DGVoluntaryControl.Rows[0].Cells["Rt_"].Value = dataTable2.Rows[0]["DGUpperLimbR"].ToString();
					DGVoluntaryControl.Rows[0].Cells["Lt_"].Value = dataTable2.Rows[0]["DGUpperLimbL"].ToString();
					DGVoluntaryControl.Rows[1].Cells["Rt_"].Value = dataTable2.Rows[0]["DGLowerLimbR"].ToString();
					DGVoluntaryControl.Rows[1].Cells["Lt_"].Value = dataTable2.Rows[0]["DGLowerLimbL"].ToString();
					DGLimbLength.Rows[0].Cells["LimbRt"].Value = dataTable2.Rows[0]["DGTrueRt"].ToString();
					DGLimbLength.Rows[0].Cells["LimbLt"].Value = dataTable2.Rows[0]["DGTrueLt"].ToString();
					DGLimbLength.Rows[1].Cells["LimbRt"].Value = dataTable2.Rows[0]["DGApparentRt"].ToString();
					DGLimbLength.Rows[1].Cells["LimbLt"].Value = dataTable2.Rows[0]["DGApparentLt"].ToString();
					DGReflexes.Rows[0].Cells["Left"].Value = dataTable2.Rows[0]["DGReflexAbdominalL"].ToString();
					DGReflexes.Rows[0].Cells["Right"].Value = dataTable2.Rows[0]["DGReflexAbdominalR"].ToString();
					DGReflexes.Rows[1].Cells["Left"].Value = dataTable2.Rows[0]["DGReflexPlantarL"].ToString();
					DGReflexes.Rows[1].Cells["Right"].Value = dataTable2.Rows[0]["DGReflexPlantarR"].ToString();
					DGReflexes.Rows[2].Cells["Left"].Value = dataTable2.Rows[0]["DGReflexBicepsL"].ToString();
					DGReflexes.Rows[2].Cells["Right"].Value = dataTable2.Rows[0]["DGReflexBicepsR"].ToString();
					DGReflexes.Rows[3].Cells["Left"].Value = dataTable2.Rows[0]["DGReflexBrachioradialisL"].ToString();
					DGReflexes.Rows[3].Cells["Right"].Value = dataTable2.Rows[0]["DGReflexBrachioradialisR"].ToString();
					DGReflexes.Rows[4].Cells["Left"].Value = dataTable2.Rows[0]["DGReflexTricepsL"].ToString();
					DGReflexes.Rows[4].Cells["Right"].Value = dataTable2.Rows[0]["DGReflexTricepsR"].ToString();
					DGReflexes.Rows[5].Cells["Left"].Value = dataTable2.Rows[0]["DGReflexKneeL"].ToString();
					DGReflexes.Rows[5].Cells["Right"].Value = dataTable2.Rows[0]["DGReflexKneeR"].ToString();
					DGReflexes.Rows[6].Cells["Left"].Value = dataTable2.Rows[0]["DGReflexAnkleL"].ToString();
					DGReflexes.Rows[6].Cells["Right"].Value = dataTable2.Rows[0]["DGReflexAnkleR"].ToString();
					Pathological.Text = dataTable2.Rows[0]["Pathological"].ToString();
					InvoluntaryMovements.Text = dataTable2.Rows[0]["InvoluntaryMovements"].ToString();
					Balance.Text = dataTable2.Rows[0]["Balance"].ToString();
					Sitting.Text = dataTable2.Rows[0]["Sitting"].ToString();
					Standing.Text = dataTable2.Rows[0]["Standing"].ToString();
					BalanceReactions.Text = dataTable2.Rows[0]["BalanceReactions"].ToString();
					Posturee.Text = dataTable2.Rows[0]["Posturee"].ToString();
					Lying.Text = dataTable2.Rows[0]["Lying"].ToString();
					Sitting2.Text = dataTable2.Rows[0]["Sitting2"].ToString();
					Standing2.Text = dataTable2.Rows[0]["Standing2"].ToString();
					StepLength.Text = dataTable2.Rows[0]["StepLength"].ToString();
					StrideLength.Text = dataTable2.Rows[0]["StrideLength"].ToString();
					Basewidth.Text = dataTable2.Rows[0]["Basewidth"].ToString();
					Cadence.Text = dataTable2.Rows[0]["Cadence"].ToString();
					BiomechanicalDeviations.Text = dataTable2.Rows[0]["BiomechanicalDeviations"].ToString();
					HandFunctions.Text = dataTable2.Rows[0]["HandFunctions"].ToString();
					Reaching.Text = dataTable2.Rows[0]["Reaching"].ToString();
					Grasping.Text = dataTable2.Rows[0]["Grasping"].ToString();
					Releasing.Text = dataTable2.Rows[0]["Releasing"].ToString();
					AssisstiveDevices.Text = dataTable2.Rows[0]["AssisstiveDevices"].ToString();
					FunctionalDiagnosis.Text = dataTable2.Rows[0]["Functional Diagnosis"].ToString();
					Goals.Text = dataTable2.Rows[0]["Goals"].ToString();
					Shortterm.Text = dataTable2.Rows[0]["Short term"].ToString();
					Longterm.Text = dataTable2.Rows[0]["Long term"].ToString();
					Devicescomb.SelectedValue = dataTable2.Rows[0]["TreatmentID"].ToString();
					DataTable dataTable3 = codes.Search2("select * from SENSORY_SYSTEM where neurologicalID = '" + num + "'");
					DGSENSORYSYS.Rows[0].Cells["Rt1"].Value = dataTable3.Rows[0]["DGPainUpR"].ToString();
					DGSENSORYSYS.Rows[0].Cells["Lt1"].Value = dataTable3.Rows[0]["DGPainUpL"].ToString();
					DGSENSORYSYS.Rows[0].Cells["Rt22"].Value = dataTable3.Rows[0]["DGPainLoR"].ToString();
					DGSENSORYSYS.Rows[0].Cells["Lt22"].Value = dataTable3.Rows[0]["DGPainLoL"].ToString();
					DGSENSORYSYS.Rows[0].Cells["Rt3"].Value = dataTable3.Rows[0]["DGPainTrR"].ToString();
					DGSENSORYSYS.Rows[0].Cells["Lt3"].Value = dataTable3.Rows[0]["DGPainTrL"].ToString();
					DGSENSORYSYS.Rows[0].Cells["notes"].Value = dataTable3.Rows[0]["DGPainnote"].ToString();
					DGSENSORYSYS.Rows[1].Cells["Rt1"].Value = dataTable3.Rows[0]["DGTemperatureUpR"].ToString();
					DGSENSORYSYS.Rows[1].Cells["Lt1"].Value = dataTable3.Rows[0]["DGTemperatureUpL"].ToString();
					DGSENSORYSYS.Rows[1].Cells["Rt22"].Value = dataTable3.Rows[0]["DGTemperatureLoR"].ToString();
					DGSENSORYSYS.Rows[1].Cells["Lt22"].Value = dataTable3.Rows[0]["DGTemperatureLoL"].ToString();
					DGSENSORYSYS.Rows[1].Cells["Rt3"].Value = dataTable3.Rows[0]["DGTemperatureTrR"].ToString();
					DGSENSORYSYS.Rows[1].Cells["Lt3"].Value = dataTable3.Rows[0]["DGTemperatureTrL"].ToString();
					DGSENSORYSYS.Rows[1].Cells["notes"].Value = dataTable3.Rows[0]["DGTemperaturenote"].ToString();
					DGSENSORYSYS.Rows[2].Cells["Rt1"].Value = dataTable3.Rows[0]["DGTouchUpR"].ToString();
					DGSENSORYSYS.Rows[2].Cells["Lt1"].Value = dataTable3.Rows[0]["DGTouchUpL"].ToString();
					DGSENSORYSYS.Rows[2].Cells["Rt22"].Value = dataTable3.Rows[0]["DGTouchLoR"].ToString();
					DGSENSORYSYS.Rows[2].Cells["Lt22"].Value = dataTable3.Rows[0]["DGTouchLoL"].ToString();
					DGSENSORYSYS.Rows[2].Cells["Rt3"].Value = dataTable3.Rows[0]["DGTouchTrR"].ToString();
					DGSENSORYSYS.Rows[2].Cells["Lt3"].Value = dataTable3.Rows[0]["DGTouchTrL"].ToString();
					DGSENSORYSYS.Rows[2].Cells["notes"].Value = dataTable3.Rows[0]["DGTouchnote"].ToString();
					DGSENSORYSYS.Rows[3].Cells["Rt1"].Value = dataTable3.Rows[0]["DGPressureUpR"].ToString();
					DGSENSORYSYS.Rows[3].Cells["Lt1"].Value = dataTable3.Rows[0]["DGPressureUpL"].ToString();
					DGSENSORYSYS.Rows[3].Cells["Rt22"].Value = dataTable3.Rows[0]["DGPressureLoR"].ToString();
					DGSENSORYSYS.Rows[3].Cells["Lt22"].Value = dataTable3.Rows[0]["DGPressureLoL"].ToString();
					DGSENSORYSYS.Rows[3].Cells["Rt3"].Value = dataTable3.Rows[0]["DGPressureTrR"].ToString();
					DGSENSORYSYS.Rows[3].Cells["Lt3"].Value = dataTable3.Rows[0]["DGPressureTrL"].ToString();
					DGSENSORYSYS.Rows[3].Cells["notes"].Value = dataTable3.Rows[0]["DGPressurenote"].ToString();
					DGSENSORYSYS.Rows[4].Cells["Rt1"].Value = dataTable3.Rows[0]["DGMovSenseUpR"].ToString();
					DGSENSORYSYS.Rows[4].Cells["Lt1"].Value = dataTable3.Rows[0]["DGMovSenseUpL"].ToString();
					DGSENSORYSYS.Rows[4].Cells["Rt22"].Value = dataTable3.Rows[0]["DGMovSenseLoR"].ToString();
					DGSENSORYSYS.Rows[4].Cells["Lt22"].Value = dataTable3.Rows[0]["DGMovSenseLoL"].ToString();
					DGSENSORYSYS.Rows[4].Cells["Rt3"].Value = dataTable3.Rows[0]["DGMovSenseTrR"].ToString();
					DGSENSORYSYS.Rows[4].Cells["Lt3"].Value = dataTable3.Rows[0]["DGMovSenseTrL"].ToString();
					DGSENSORYSYS.Rows[4].Cells["notes"].Value = dataTable3.Rows[0]["DGMovSensenote"].ToString();
					DGSENSORYSYS.Rows[5].Cells["Rt1"].Value = dataTable3.Rows[0]["DGPosSenseUpR"].ToString();
					DGSENSORYSYS.Rows[5].Cells["Lt1"].Value = dataTable3.Rows[0]["DGPosSenseUpL"].ToString();
					DGSENSORYSYS.Rows[5].Cells["Rt22"].Value = dataTable3.Rows[0]["DGPosSenseLoR"].ToString();
					DGSENSORYSYS.Rows[5].Cells["Lt22"].Value = dataTable3.Rows[0]["DGPosSenseLoL"].ToString();
					DGSENSORYSYS.Rows[5].Cells["Rt3"].Value = dataTable3.Rows[0]["DGPosSenseTrR"].ToString();
					DGSENSORYSYS.Rows[5].Cells["Lt3"].Value = dataTable3.Rows[0]["DGPosSenseTrL"].ToString();
					DGSENSORYSYS.Rows[5].Cells["notes"].Value = dataTable3.Rows[0]["DGPosSensenote"].ToString();
					DGSENSORYSYS.Rows[6].Cells["Rt1"].Value = dataTable3.Rows[0]["DGVibrationUpR"].ToString();
					DGSENSORYSYS.Rows[6].Cells["Lt1"].Value = dataTable3.Rows[0]["DGVibrationUpL"].ToString();
					DGSENSORYSYS.Rows[6].Cells["Rt22"].Value = dataTable3.Rows[0]["DGVibrationLoR"].ToString();
					DGSENSORYSYS.Rows[6].Cells["Lt22"].Value = dataTable3.Rows[0]["DGVibrationLoL"].ToString();
					DGSENSORYSYS.Rows[6].Cells["Rt3"].Value = dataTable3.Rows[0]["DGVibrationTrR"].ToString();
					DGSENSORYSYS.Rows[6].Cells["Lt3"].Value = dataTable3.Rows[0]["DGVibrationTrL"].ToString();
					DGSENSORYSYS.Rows[6].Cells["notes"].Value = dataTable3.Rows[0]["DGVibrationnote"].ToString();
					DGSENSORYSYS.Rows[7].Cells["Rt1"].Value = dataTable3.Rows[0]["DGTactileLocalizationUpR"].ToString();
					DGSENSORYSYS.Rows[7].Cells["Lt1"].Value = dataTable3.Rows[0]["DGTactileLocalizationUpL"].ToString();
					DGSENSORYSYS.Rows[7].Cells["Rt22"].Value = dataTable3.Rows[0]["DGTactileLocalizationLoR"].ToString();
					DGSENSORYSYS.Rows[7].Cells["Lt22"].Value = dataTable3.Rows[0]["DGTactileLocalizationLoL"].ToString();
					DGSENSORYSYS.Rows[7].Cells["Rt3"].Value = dataTable3.Rows[0]["DGTactileLocalizationTrR"].ToString();
					DGSENSORYSYS.Rows[7].Cells["Lt3"].Value = dataTable3.Rows[0]["DGTactileLocalizationTrL"].ToString();
					DGSENSORYSYS.Rows[7].Cells["notes"].Value = dataTable3.Rows[0]["DGTactileLocalizationnote"].ToString();
					DGSENSORYSYS.Rows[8].Cells["Rt1"].Value = dataTable3.Rows[0]["DGptdiscriminationUpR"].ToString();
					DGSENSORYSYS.Rows[8].Cells["Lt1"].Value = dataTable3.Rows[0]["DGptdiscriminationUpL"].ToString();
					DGSENSORYSYS.Rows[8].Cells["Rt22"].Value = dataTable3.Rows[0]["DGptdiscriminationLoR"].ToString();
					DGSENSORYSYS.Rows[8].Cells["Lt22"].Value = dataTable3.Rows[0]["DGptdiscriminationLoL"].ToString();
					DGSENSORYSYS.Rows[8].Cells["Rt3"].Value = dataTable3.Rows[0]["DGptdiscriminationTrR"].ToString();
					DGSENSORYSYS.Rows[8].Cells["Lt3"].Value = dataTable3.Rows[0]["DGptdiscriminationTrL"].ToString();
					DGSENSORYSYS.Rows[8].Cells["notes"].Value = dataTable3.Rows[0]["DGptdiscriminationnote"].ToString();
					DGSENSORYSYS.Rows[9].Cells["Rt1"].Value = dataTable3.Rows[0]["DGStereognosisUpR"].ToString();
					DGSENSORYSYS.Rows[9].Cells["Lt1"].Value = dataTable3.Rows[0]["DGStereognosisUpL"].ToString();
					DGSENSORYSYS.Rows[9].Cells["Rt22"].Value = dataTable3.Rows[0]["DGStereognosisLoR"].ToString();
					DGSENSORYSYS.Rows[9].Cells["Lt22"].Value = dataTable3.Rows[0]["DGStereognosisLoL"].ToString();
					DGSENSORYSYS.Rows[9].Cells["Rt3"].Value = dataTable3.Rows[0]["DGStereognosisTrR"].ToString();
					DGSENSORYSYS.Rows[9].Cells["Lt3"].Value = dataTable3.Rows[0]["DGStereognosisTrL"].ToString();
					DGSENSORYSYS.Rows[9].Cells["notes"].Value = dataTable3.Rows[0]["DGStereognosisnote"].ToString();
					DGSENSORYSYS.Rows[10].Cells["Rt1"].Value = dataTable3.Rows[0]["DGBarognosisUpR"].ToString();
					DGSENSORYSYS.Rows[10].Cells["Lt1"].Value = dataTable3.Rows[0]["DGBarognosisUpL"].ToString();
					DGSENSORYSYS.Rows[10].Cells["Rt22"].Value = dataTable3.Rows[0]["DGBarognosisLoR"].ToString();
					DGSENSORYSYS.Rows[10].Cells["Lt22"].Value = dataTable3.Rows[0]["DGBarognosisLoL"].ToString();
					DGSENSORYSYS.Rows[10].Cells["Rt3"].Value = dataTable3.Rows[0]["DGBarognosisTrR"].ToString();
					DGSENSORYSYS.Rows[10].Cells["Lt3"].Value = dataTable3.Rows[0]["DGBarognosisTrL"].ToString();
					DGSENSORYSYS.Rows[10].Cells["notes"].Value = dataTable3.Rows[0]["DGBarognosisnote"].ToString();
					DGSENSORYSYS.Rows[11].Cells["Rt1"].Value = dataTable3.Rows[0]["DGGraphesthesiaUpR"].ToString();
					DGSENSORYSYS.Rows[11].Cells["Lt1"].Value = dataTable3.Rows[0]["DGGraphesthesiaUpL"].ToString();
					DGSENSORYSYS.Rows[11].Cells["Rt22"].Value = dataTable3.Rows[0]["DGGraphesthesiaLoR"].ToString();
					DGSENSORYSYS.Rows[11].Cells["Lt22"].Value = dataTable3.Rows[0]["DGGraphesthesiaLoL"].ToString();
					DGSENSORYSYS.Rows[11].Cells["Rt3"].Value = dataTable3.Rows[0]["DGGraphesthesiaTrR"].ToString();
					DGSENSORYSYS.Rows[11].Cells["Lt3"].Value = dataTable3.Rows[0]["DGGraphesthesiaTrL"].ToString();
					DGSENSORYSYS.Rows[11].Cells["notes"].Value = dataTable3.Rows[0]["DGGraphesthesianote"].ToString();
					DGSENSORYSYS.Rows[12].Cells["Rt1"].Value = dataTable3.Rows[0]["DGTextureRecognitionUpR"].ToString();
					DGSENSORYSYS.Rows[12].Cells["Lt1"].Value = dataTable3.Rows[0]["DGTextureRecognitionUpL"].ToString();
					DGSENSORYSYS.Rows[12].Cells["Rt22"].Value = dataTable3.Rows[0]["DGTextureRecognitionLoR"].ToString();
					DGSENSORYSYS.Rows[12].Cells["Lt22"].Value = dataTable3.Rows[0]["DGTextureRecognitionLoL"].ToString();
					DGSENSORYSYS.Rows[12].Cells["Rt3"].Value = dataTable3.Rows[0]["DGTextureRecognitionTrR"].ToString();
					DGSENSORYSYS.Rows[12].Cells["Lt3"].Value = dataTable3.Rows[0]["DGTextureRecognitionTrL"].ToString();
					DGSENSORYSYS.Rows[12].Cells["notes"].Value = dataTable3.Rows[0]["DGTextureRecognitionnote"].ToString();
					DGSENSORYSYS.Rows[13].Cells["Rt1"].Value = dataTable3.Rows[0]["DGStimulationUpR"].ToString();
					DGSENSORYSYS.Rows[13].Cells["Lt1"].Value = dataTable3.Rows[0]["DGStimulationUpL"].ToString();
					DGSENSORYSYS.Rows[13].Cells["Rt22"].Value = dataTable3.Rows[0]["DGStimulationLoR"].ToString();
					DGSENSORYSYS.Rows[13].Cells["Lt22"].Value = dataTable3.Rows[0]["DGStimulationLoL"].ToString();
					DGSENSORYSYS.Rows[13].Cells["Rt3"].Value = dataTable3.Rows[0]["DGStimulationTrR"].ToString();
					DGSENSORYSYS.Rows[13].Cells["Lt3"].Value = dataTable3.Rows[0]["DGStimulationTrL"].ToString();
					DGSENSORYSYS.Rows[13].Cells["notes"].Value = dataTable3.Rows[0]["DGStimulationnote"].ToString();
					DataTable dataTable4 = codes.Search2("select * from Range_of_Motion where neurologicalID = '" + num + "'");
					DGRangeofMotion.Rows[0].Cells["Side"].Value = dataTable4.Rows[0]["DGShoulderSide"].ToString();
					DGRangeofMotion.Rows[0].Cells["Movement"].Value = dataTable4.Rows[0]["DGShoulderMovement"].ToString();
					DGRangeofMotion.Rows[0].Cells["Limitation"].Value = dataTable4.Rows[0]["DGShoulderLimitation"].ToString();
					DGRangeofMotion.Rows[0].Cells["Limitingfactor"].Value = dataTable4.Rows[0]["DGShoulderfactor"].ToString();
					DGRangeofMotion.Rows[1].Cells["Side"].Value = dataTable4.Rows[0]["DGElbowSide"].ToString();
					DGRangeofMotion.Rows[1].Cells["Movement"].Value = dataTable4.Rows[0]["DGElbowMovement"].ToString();
					DGRangeofMotion.Rows[1].Cells["Limitation"].Value = dataTable4.Rows[0]["DGElbowLimitation"].ToString();
					DGRangeofMotion.Rows[1].Cells["Limitingfactor"].Value = dataTable4.Rows[0]["DGElbowfactor"].ToString();
					DGRangeofMotion.Rows[2].Cells["Side"].Value = dataTable4.Rows[0]["DGForearmSide"].ToString();
					DGRangeofMotion.Rows[2].Cells["Movement"].Value = dataTable4.Rows[0]["DGForearmMovement"].ToString();
					DGRangeofMotion.Rows[2].Cells["Limitation"].Value = dataTable4.Rows[0]["DGForearmLimitation"].ToString();
					DGRangeofMotion.Rows[2].Cells["Limitingfactor"].Value = dataTable4.Rows[0]["DGForearmfactor"].ToString();
					DGRangeofMotion.Rows[3].Cells["Side"].Value = dataTable4.Rows[0]["DGWristSide"].ToString();
					DGRangeofMotion.Rows[3].Cells["Movement"].Value = dataTable4.Rows[0]["DGWristMovement"].ToString();
					DGRangeofMotion.Rows[3].Cells["Limitation"].Value = dataTable4.Rows[0]["DGWristLimitation"].ToString();
					DGRangeofMotion.Rows[3].Cells["Limitingfactor"].Value = dataTable4.Rows[0]["DGWristfactor"].ToString();
					DGRangeofMotion.Rows[4].Cells["Side"].Value = dataTable4.Rows[0]["DGHandFingersSide"].ToString();
					DGRangeofMotion.Rows[4].Cells["Movement"].Value = dataTable4.Rows[0]["DGHandFingersMovement"].ToString();
					DGRangeofMotion.Rows[4].Cells["Limitation"].Value = dataTable4.Rows[0]["DGHandFingersLimitation"].ToString();
					DGRangeofMotion.Rows[4].Cells["Limitingfactor"].Value = dataTable4.Rows[0]["DGHandFingersfactor"].ToString();
					DGRangeofMotion.Rows[5].Cells["Side"].Value = dataTable4.Rows[0]["DGHipSide"].ToString();
					DGRangeofMotion.Rows[5].Cells["Movement"].Value = dataTable4.Rows[0]["DGHipMovement"].ToString();
					DGRangeofMotion.Rows[5].Cells["Limitation"].Value = dataTable4.Rows[0]["DGHipLimitation"].ToString();
					DGRangeofMotion.Rows[5].Cells["Limitingfactor"].Value = dataTable4.Rows[0]["DGHipfactor"].ToString();
					DGRangeofMotion.Rows[6].Cells["Side"].Value = dataTable4.Rows[0]["DGKneeSide"].ToString();
					DGRangeofMotion.Rows[6].Cells["Movement"].Value = dataTable4.Rows[0]["DGKneeMovement"].ToString();
					DGRangeofMotion.Rows[6].Cells["Limitation"].Value = dataTable4.Rows[0]["DGKneeLimitation"].ToString();
					DGRangeofMotion.Rows[6].Cells["Limitingfactor"].Value = dataTable4.Rows[0]["DGKneefactor"].ToString();
					DGRangeofMotion.Rows[7].Cells["Side"].Value = dataTable4.Rows[0]["DGAnklefootSide"].ToString();
					DGRangeofMotion.Rows[7].Cells["Movement"].Value = dataTable4.Rows[0]["DGAnklefootMovement"].ToString();
					DGRangeofMotion.Rows[7].Cells["Limitation"].Value = dataTable4.Rows[0]["DGAnklefootLimitation"].ToString();
					DGRangeofMotion.Rows[7].Cells["Limitingfactor"].Value = dataTable4.Rows[0]["DGAnklefootfactor"].ToString();
					DGRangeofMotion2.Rows[0].Cells["Side2"].Value = dataTable4.Rows[0]["DGCervicalSpineSide"].ToString();
					DGRangeofMotion2.Rows[0].Cells["Movement2"].Value = dataTable4.Rows[0]["DGCervicalSpineMovement"].ToString();
					DGRangeofMotion2.Rows[0].Cells["Limitation2"].Value = dataTable4.Rows[0]["DGCervicalSpineLimitation"].ToString();
					DGRangeofMotion2.Rows[0].Cells["Limitingfactor2"].Value = dataTable4.Rows[0]["DGCervicalSpinefactor"].ToString();
					DGRangeofMotion2.Rows[1].Cells["Side2"].Value = dataTable4.Rows[0]["DGThoracicSpineSide"].ToString();
					DGRangeofMotion2.Rows[1].Cells["Movement2"].Value = dataTable4.Rows[0]["DGThoracicSpineMovement"].ToString();
					DGRangeofMotion2.Rows[1].Cells["Limitation2"].Value = dataTable4.Rows[0]["DGThoracicSpineLimitation"].ToString();
					DGRangeofMotion2.Rows[1].Cells["Limitingfactor2"].Value = dataTable4.Rows[0]["DGThoracicSpinefactor"].ToString();
					DGRangeofMotion2.Rows[2].Cells["Side2"].Value = dataTable4.Rows[0]["DGLumbarSpineSide"].ToString();
					DGRangeofMotion2.Rows[2].Cells["Movement2"].Value = dataTable4.Rows[0]["DGLumbarSpineMovement"].ToString();
					DGRangeofMotion2.Rows[2].Cells["Limitation2"].Value = dataTable4.Rows[0]["DGLumbarSpineLimitation"].ToString();
					DGRangeofMotion2.Rows[2].Cells["Limitingfactor2"].Value = dataTable4.Rows[0]["DGLumbarSpinefactor"].ToString();
					DataTable dataTable5 = codes.Search2("select * from Muscle_Tone where neurologicalID = '" + num + "'");
					DGMuscleTone1.Rows[1].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneSFlexorsRt"].ToString();
					DGMuscleTone1.Rows[1].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneSFlexorsLt"].ToString();
					DGMuscleTone1.Rows[2].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneSExtensorsRt"].ToString();
					DGMuscleTone1.Rows[2].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneSExtensorsLt"].ToString();
					DGMuscleTone1.Rows[3].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneSAbductorsRt"].ToString();
					DGMuscleTone1.Rows[3].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneSAbductorsLt"].ToString();
					DGMuscleTone1.Rows[4].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneSAdductorsRt"].ToString();
					DGMuscleTone1.Rows[4].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneSAdductorsLt"].ToString();
					DGMuscleTone1.Rows[5].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneSExternalRotRt"].ToString();
					DGMuscleTone1.Rows[5].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneSExternalRotLt"].ToString();
					DGMuscleTone1.Rows[6].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneSInternalRotRt"].ToString();
					DGMuscleTone1.Rows[6].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneSInternalRotLt"].ToString();
					DGMuscleTone1.Rows[8].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneEFlexorsRt"].ToString();
					DGMuscleTone1.Rows[8].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneEFlexorsLt"].ToString();
					DGMuscleTone1.Rows[9].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneEExtensorsRt"].ToString();
					DGMuscleTone1.Rows[9].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneEExtensorsLt"].ToString();
					DGMuscleTone1.Rows[11].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneEPronatorsRt"].ToString();
					DGMuscleTone1.Rows[11].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneEPronatorsLt"].ToString();
					DGMuscleTone1.Rows[12].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneESupinatorsRt"].ToString();
					DGMuscleTone1.Rows[12].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneESupinatorsLt"].ToString();
					DGMuscleTone1.Rows[14].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneWFlexorsRt"].ToString();
					DGMuscleTone1.Rows[14].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneWFlexorsLt"].ToString();
					DGMuscleTone1.Rows[15].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneWExtensorsRt"].ToString();
					DGMuscleTone1.Rows[15].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneWExtensorsLt"].ToString();
					DGMuscleTone1.Rows[16].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneWRadialDevRt"].ToString();
					DGMuscleTone1.Rows[16].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneWRadialDevLt"].ToString();
					DGMuscleTone1.Rows[17].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneWUlnarDevRt"].ToString();
					DGMuscleTone1.Rows[17].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneWUlnarDevLt"].ToString();
					DGMuscleTone1.Rows[19].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneHIntrinsicsRt"].ToString();
					DGMuscleTone1.Rows[19].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneHIntrinsicsLt"].ToString();
					DGMuscleTone1.Rows[20].Cells["TRT"].Value = dataTable5.Rows[0]["DGToneEHxtrinsicsRt"].ToString();
					DGMuscleTone1.Rows[20].Cells["TLT"].Value = dataTable5.Rows[0]["DGToneHExtrinsicsLt"].ToString();
					DGMuscleTone2.Rows[1].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneHIFlexorsRt"].ToString();
					DGMuscleTone2.Rows[1].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneHIFlexorsLt"].ToString();
					DGMuscleTone2.Rows[2].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneHIExtensorsRt"].ToString();
					DGMuscleTone2.Rows[2].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneHIExtensorsLt"].ToString();
					DGMuscleTone2.Rows[3].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneHIAbductorsRt"].ToString();
					DGMuscleTone2.Rows[3].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneHIAbductorsLt"].ToString();
					DGMuscleTone2.Rows[4].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneHIAdductorsRt"].ToString();
					DGMuscleTone2.Rows[4].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneHIAdductorsLt"].ToString();
					DGMuscleTone2.Rows[5].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneHIExternalRotRt"].ToString();
					DGMuscleTone2.Rows[5].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneHIExternalRotLt"].ToString();
					DGMuscleTone2.Rows[6].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneHIInternalRotRt"].ToString();
					DGMuscleTone2.Rows[6].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneHIInternalRotLt"].ToString();
					DGMuscleTone2.Rows[8].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneKFlexorsRt"].ToString();
					DGMuscleTone2.Rows[8].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneKFlexorsLt"].ToString();
					DGMuscleTone2.Rows[9].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneKExtensorsRt"].ToString();
					DGMuscleTone2.Rows[9].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneKExtensorsLt"].ToString();
					DGMuscleTone2.Rows[11].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneANDorsiflexorsRt"].ToString();
					DGMuscleTone2.Rows[11].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneANDorsiflexorsLt"].ToString();
					DGMuscleTone2.Rows[12].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneANPlantarflexorsRt"].ToString();
					DGMuscleTone2.Rows[12].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneANPlantarflexorsLt"].ToString();
					DGMuscleTone2.Rows[14].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneFInvertorsRt"].ToString();
					DGMuscleTone2.Rows[14].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneFInvertorsLt"].ToString();
					DGMuscleTone2.Rows[15].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneFEvertorsRt"].ToString();
					DGMuscleTone2.Rows[15].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneFEvertorsLt"].ToString();
					DGMuscleTone2.Rows[16].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneFIntrinsicsRt"].ToString();
					DGMuscleTone2.Rows[16].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneFIntrinsicsLt"].ToString();
					DGMuscleTone2.Rows[17].Cells["TRT2"].Value = dataTable5.Rows[0]["DGToneFExtrinsicsRt"].ToString();
					DGMuscleTone2.Rows[17].Cells["TLT2"].Value = dataTable5.Rows[0]["DGToneFExtrinsicsLt"].ToString();
					DataTable dataTable6 = codes.Search2("select * from Muscle_Power where neurologicalID = '" + num + "'");
					DGMusclePower1.Rows[1].Cells["PRT"].Value = dataTable6.Rows[0]["PowerSFlexorsRt"].ToString();
					DGMusclePower1.Rows[1].Cells["PLT"].Value = dataTable6.Rows[0]["PowerSFlexorsLt"].ToString();
					DGMusclePower1.Rows[2].Cells["PRT"].Value = dataTable6.Rows[0]["PowerSExtensorsRt"].ToString();
					DGMusclePower1.Rows[3].Cells["PLT"].Value = dataTable6.Rows[0]["PowerSExtensorsLt"].ToString();
					DGMusclePower1.Rows[3].Cells["PRT"].Value = dataTable6.Rows[0]["PowerSAbductorsRt"].ToString();
					DGMusclePower1.Rows[3].Cells["PLT"].Value = dataTable6.Rows[0]["PowerSAbductorsLt"].ToString();
					DGMusclePower1.Rows[4].Cells["PRT"].Value = dataTable6.Rows[0]["PowerSAdductorsRt"].ToString();
					DGMusclePower1.Rows[4].Cells["PLT"].Value = dataTable6.Rows[0]["PowerSAdductorsLt"].ToString();
					DGMusclePower1.Rows[5].Cells["PRT"].Value = dataTable6.Rows[0]["PowerExternalRotRt"].ToString();
					DGMusclePower1.Rows[5].Cells["PLT"].Value = dataTable6.Rows[0]["PowerSExternalRotLt"].ToString();
					DGMusclePower1.Rows[6].Cells["PRT"].Value = dataTable6.Rows[0]["PowerSInternalRotRt"].ToString();
					DGMusclePower1.Rows[6].Cells["PLT"].Value = dataTable6.Rows[0]["PowerSInternalRotLt"].ToString();
					DGMusclePower1.Rows[8].Cells["PRT"].Value = dataTable6.Rows[0]["PowerEFlexorsRt"].ToString();
					DGMusclePower1.Rows[8].Cells["PLT"].Value = dataTable6.Rows[0]["PowerEFlexorsLt"].ToString();
					DGMusclePower1.Rows[9].Cells["PRT"].Value = dataTable6.Rows[0]["PowerEExtensorsRt"].ToString();
					DGMusclePower1.Rows[9].Cells["PLT"].Value = dataTable6.Rows[0]["PowerEExtensorsLt"].ToString();
					DGMusclePower1.Rows[11].Cells["PRT"].Value = dataTable6.Rows[0]["PowerEPronatorsRt"].ToString();
					DGMusclePower1.Rows[11].Cells["PLT"].Value = dataTable6.Rows[0]["PowerEPronatorsLt"].ToString();
					DGMusclePower1.Rows[12].Cells["PRT"].Value = dataTable6.Rows[0]["PowerESupinatorsRt"].ToString();
					DGMusclePower1.Rows[12].Cells["PLT"].Value = dataTable6.Rows[0]["PowerESupinatorsLt"].ToString();
					DGMusclePower1.Rows[14].Cells["PRT"].Value = dataTable6.Rows[0]["PowerWFlexorsRt"].ToString();
					DGMusclePower1.Rows[14].Cells["PLT"].Value = dataTable6.Rows[0]["PowerWFlexorsLt"].ToString();
					DGMusclePower1.Rows[15].Cells["PRT"].Value = dataTable6.Rows[0]["PowerWExtensorsRt"].ToString();
					DGMusclePower1.Rows[15].Cells["PLT"].Value = dataTable6.Rows[0]["PowerWExtensorsLt"].ToString();
					DGMusclePower1.Rows[16].Cells["PRT"].Value = dataTable6.Rows[0]["PowerWRadialDevRt"].ToString();
					DGMusclePower1.Rows[16].Cells["PLT"].Value = dataTable6.Rows[0]["PowerWRadialDevLt"].ToString();
					DGMusclePower1.Rows[17].Cells["PRT"].Value = dataTable6.Rows[0]["PowerWUlnarDevRt"].ToString();
					DGMusclePower1.Rows[17].Cells["PLT"].Value = dataTable6.Rows[0]["PowerWUlnarDevLt"].ToString();
					DGMusclePower1.Rows[19].Cells["PRT"].Value = dataTable6.Rows[0]["PowerHIntrinsicsRt"].ToString();
					DGMusclePower1.Rows[19].Cells["PLT"].Value = dataTable6.Rows[0]["PowerHIntrinsicsLt"].ToString();
					DGMusclePower1.Rows[20].Cells["PRT"].Value = dataTable6.Rows[0]["PowerEHxtrinsicsRt"].ToString();
					DGMusclePower1.Rows[20].Cells["PLT"].Value = dataTable6.Rows[0]["PowerHExtrinsicsLt"].ToString();
					DGMusclePower2.Rows[1].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerHIFlexorsRt"].ToString();
					DGMusclePower2.Rows[1].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerHIFlexorsLt"].ToString();
					DGMusclePower2.Rows[2].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerHIExtensorsRt"].ToString();
					DGMusclePower2.Rows[2].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerHIExtensorsLt"].ToString();
					DGMusclePower2.Rows[3].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerHIAbductorsRt"].ToString();
					DGMusclePower2.Rows[3].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerHIAbductorsLt"].ToString();
					DGMusclePower2.Rows[4].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerHIAdductorsRt"].ToString();
					DGMusclePower2.Rows[4].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerHIAdductorsLt"].ToString();
					DGMusclePower2.Rows[5].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerHIExternalRotRt"].ToString();
					DGMusclePower2.Rows[5].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerHIExternalRotLt"].ToString();
					DGMusclePower2.Rows[6].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerHIInternalRotRt"].ToString();
					DGMusclePower2.Rows[6].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerHIInternalRotLt"].ToString();
					DGMusclePower2.Rows[8].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerKFlexorsRt"].ToString();
					DGMusclePower2.Rows[8].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerKFlexorsLt"].ToString();
					DGMusclePower2.Rows[9].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerKExtensorsRt"].ToString();
					DGMusclePower2.Rows[9].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerKExtensorsLt"].ToString();
					DGMusclePower2.Rows[11].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerANDorsiflexorsRt"].ToString();
					DGMusclePower2.Rows[11].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerANDorsiflexorsLt"].ToString();
					DGMusclePower2.Rows[12].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerANPlantarflexorsRt"].ToString();
					DGMusclePower2.Rows[12].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerANPlantarflexorsLt"].ToString();
					DGMusclePower2.Rows[14].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerFInvertorsRt"].ToString();
					DGMusclePower2.Rows[14].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerFInvertorsLt"].ToString();
					DGMusclePower2.Rows[15].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerFEvertorsRt"].ToString();
					DGMusclePower2.Rows[15].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerFEvertorsLt"].ToString();
					DGMusclePower2.Rows[16].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerFIntrinsicsRt"].ToString();
					DGMusclePower2.Rows[16].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerFIntrinsicsLt"].ToString();
					DGMusclePower2.Rows[17].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerFExtrinsicsRt"].ToString();
					DGMusclePower2.Rows[17].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerFExtrinsicsLt"].ToString();
					DGMusclePower2.Rows[18].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerTrunkFlexorsRt"].ToString();
					DGMusclePower2.Rows[18].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerTrunkFlexorsLt"].ToString();
					DGMusclePower2.Rows[19].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerTrunkExtensorsRt"].ToString();
					DGMusclePower2.Rows[19].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerTrunkExtensorsLt"].ToString();
					DGMusclePower2.Rows[20].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerTrunkSideFlexorsRt"].ToString();
					DGMusclePower2.Rows[20].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerTrunkSideFlexorsLt"].ToString();
					DGMusclePower2.Rows[21].Cells["PRT2"].Value = dataTable6.Rows[0]["PowerTrunkRotatorsRt"].ToString();
					DGMusclePower2.Rows[21].Cells["PLT2"].Value = dataTable6.Rows[0]["PowerTrunkRotatorsLt"].ToString();
					DataTable dataTable7 = codes.Search2("select * from Coordination where neurologicalID = '" + num + "'");
					DGCoordination1.Rows[0].Cells["RT2"].Value = dataTable7.Rows[0]["FingernoseR"].ToString();
					DGCoordination1.Rows[0].Cells["LT2"].Value = dataTable7.Rows[0]["FingernoseT"].ToString();
					DGCoordination1.Rows[1].Cells["RT2"].Value = dataTable7.Rows[0]["FingeroppositionR"].ToString();
					DGCoordination1.Rows[1].Cells["LT2"].Value = dataTable7.Rows[0]["FingeroppositionT"].ToString();
					DGCoordination1.Rows[2].Cells["RT2"].Value = dataTable7.Rows[0]["MassGraspR"].ToString();
					DGCoordination1.Rows[2].Cells["LT2"].Value = dataTable7.Rows[0]["MassGraspT"].ToString();
					DGCoordination1.Rows[3].Cells["RT2"].Value = dataTable7.Rows[0]["PronationSupinationR"].ToString();
					DGCoordination1.Rows[3].Cells["LT2"].Value = dataTable7.Rows[0]["PronationSupinationT"].ToString();
					DGCoordination1.Rows[4].Cells["RT2"].Value = dataTable7.Rows[0]["ReboundtestR"].ToString();
					DGCoordination1.Rows[4].Cells["LT2"].Value = dataTable7.Rows[0]["ReboundtestT"].ToString();
					DGCoordination1.Rows[5].Cells["RT2"].Value = dataTable7.Rows[0]["TappingHandR"].ToString();
					DGCoordination1.Rows[5].Cells["LT2"].Value = dataTable7.Rows[0]["TappingHandT"].ToString();
					DGCoordination1.Rows[6].Cells["RT2"].Value = dataTable7.Rows[0]["TappingFootR"].ToString();
					DGCoordination1.Rows[6].Cells["LT2"].Value = dataTable7.Rows[0]["TappingFootT"].ToString();
					DGCoordination1.Rows[7].Cells["RT2"].Value = dataTable7.Rows[0]["HeeltokneeR"].ToString();
					DGCoordination1.Rows[7].Cells["LT2"].Value = dataTable7.Rows[0]["HeeltokneeT"].ToString();
					DGCoordination1.Rows[8].Cells["RT2"].Value = dataTable7.Rows[0]["circleHandR"].ToString();
					DGCoordination1.Rows[8].Cells["LT2"].Value = dataTable7.Rows[0]["circleHandT"].ToString();
					DGCoordination1.Rows[9].Cells["RT2"].Value = dataTable7.Rows[0]["circleFootR"].ToString();
					DGCoordination1.Rows[9].Cells["LT2"].Value = dataTable7.Rows[0]["circleFootT"].ToString();
					DGCoordination2.Rows[0].Cells["Grade"].Value = dataTable7.Rows[0]["StandNormal"].ToString();
					DGCoordination2.Rows[1].Cells["Grade"].Value = dataTable7.Rows[0]["StandNormalwithvision"].ToString();
					DGCoordination2.Rows[2].Cells["Grade"].Value = dataTable7.Rows[0]["StandingFeettogether"].ToString();
					DGCoordination2.Rows[3].Cells["Grade"].Value = dataTable7.Rows[0]["Standingononefoot"].ToString();
					DGCoordination2.Rows[4].Cells["Grade"].Value = dataTable7.Rows[0]["StandingLateraltrunkflexion"].ToString();
					DGCoordination2.Rows[5].Cells["Grade"].Value = dataTable7.Rows[0]["Tandemwalking"].ToString();
					DGCoordination2.Rows[6].Cells["Grade"].Value = dataTable7.Rows[0]["WalkSideways"].ToString();
					DGCoordination2.Rows[7].Cells["Grade"].Value = dataTable7.Rows[0]["WalkBackward"].ToString();
					DGCoordination2.Rows[8].Cells["Grade"].Value = dataTable7.Rows[0]["Walkcircle"].ToString();
					DGCoordination2.Rows[9].Cells["Grade"].Value = dataTable7.Rows[0]["Walkheels"].ToString();
					DGCoordination2.Rows[10].Cells["Grade"].Value = dataTable7.Rows[0]["Walktoes"].ToString();
					DataTable dataTable8 = codes.Search2("select * from SystemsReview where neurologicalID = '" + num + "'");
					IntegSystem.Text = dataTable8.Rows[0]["IntegSystem"].ToString();
					SkinStatus.Text = dataTable8.Rows[0]["SkinStatus"].ToString();
					PressureSoress.Text = dataTable8.Rows[0]["PressureSoress"].ToString();
					RESPIRATORYSYSTEM.Text = dataTable8.Rows[0]["RESPIRATORYSYSTEM"].ToString();
					RSStatus.Text = dataTable8.Rows[0]["RSStatus"].ToString();
					Secretions.Text = dataTable8.Rows[0]["Secretions"].ToString();
					Patternofbreathing.Text = dataTable8.Rows[0]["Patternofbreathing"].ToString();
					spinedeformity.Text = dataTable8.Rows[0]["spinedeformity"].ToString();
					CVSStatus.Text = dataTable8.Rows[0]["CVSStatus"].ToString();
					Thrombosis.Text = dataTable8.Rows[0]["Thrombosis"].ToString();
					Contractures.Text = dataTable8.Rows[0]["Contractures"].ToString();
					Subluxations.Text = dataTable8.Rows[0]["Subluxations"].ToString();
					Jointmobility.Text = dataTable8.Rows[0]["Jointmobility"].ToString();
					Otherpathology.Text = dataTable8.Rows[0]["Otherpathology"].ToString();
					Incontinence.Text = dataTable8.Rows[0]["Incontinence"].ToString();
					Status.Text = dataTable8.Rows[0]["Status"].ToString();
					Vasomotor.Text = dataTable8.Rows[0]["Vasomotor"].ToString();
					Pseudomotor.Text = dataTable8.Rows[0]["Pseudomotor"].ToString();
					TrophicChanges.Text = dataTable8.Rows[0]["TrophicChanges"].ToString();
					PosturalHypotension.Text = dataTable8.Rows[0]["PosturalHypotension"].ToString();
					ReflexSympatheticDystrophy.Text = dataTable8.Rows[0]["ReflexSympatheticDystrophy"].ToString();
					DataTable dataTable9 = codes.Search2("select * from Functional_Assessment where neurologicalID = '" + num + "'");
					Evaluation1.Text = dataTable9.Rows[0]["Evaluation1"].ToString();
					Item1.Text = dataTable9.Rows[0]["Item1"].ToString();
					Item2.Text = dataTable9.Rows[0]["Item2"].ToString();
					Item3.Text = dataTable9.Rows[0]["Item3"].ToString();
					Item4.Text = dataTable9.Rows[0]["Item4"].ToString();
					Item5.Text = dataTable9.Rows[0]["Item5"].ToString();
					Evaluation2.Text = dataTable9.Rows[0]["Evaluation2"].ToString();
					Item6.Text = dataTable9.Rows[0]["Item6"].ToString();
					Item7.Text = dataTable9.Rows[0]["Item7"].ToString();
					Evaluation3.Text = dataTable9.Rows[0]["Evaluation3"].ToString();
					Item8.Text = dataTable9.Rows[0]["Item8"].ToString();
					Item9.Text = dataTable9.Rows[0]["Item9"].ToString();
					Item10.Text = dataTable9.Rows[0]["Item10"].ToString();
					Evaluation4.Text = dataTable9.Rows[0]["Evaluation4"].ToString();
					Item11.Text = dataTable9.Rows[0]["Item11"].ToString();
					Item12.Text = dataTable9.Rows[0]["Item12"].ToString();
					Evaluation5.Text = dataTable9.Rows[0]["Evaluation5"].ToString();
					Item13.Text = dataTable9.Rows[0]["Item13"].ToString();
					Item14.Text = dataTable9.Rows[0]["Item14"].ToString();
					Evaluation6.Text = dataTable9.Rows[0]["Evaluation6"].ToString();
					Item15.Text = dataTable9.Rows[0]["Item15"].ToString();
					Item16.Text = dataTable9.Rows[0]["Item16"].ToString();
					Item17.Text = dataTable9.Rows[0]["Item17"].ToString();
					InvestigationFindings.Text = dataTable9.Rows[0]["InvestigationFindings"].ToString();
					DataTable dataTable10 = codes.Search2("select * from Problem_List where neurologicalID = '" + num + "'");
					for (int i = 0; i < dataTable10.Rows.Count; i++)
					{
						DGProblemList.Rows[i].Cells["Sl"].Value = dataTable10.Rows[i]["SI"].ToString();
						DGProblemList.Rows[i].Cells["Impairment"].Value = dataTable10.Rows[i]["Impairment"].ToString();
						DGProblemList.Rows[i].Cells["FunctionalLimitation"].Value = dataTable10.Rows[i]["FunctionalLimitation"].ToString();
					}
					update.Enabled = true;
					save.Enabled = false;
				}
				else
				{
					update.Enabled = false;
				}
			}
			catch
			{
			}
		}

		private void birthDateDateTimePicker_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				DateTime.Today.Subtract(birthDateDateTimePicker.Value);
				int day = DateTime.Now.Day;
				int month = DateTime.Now.Month;
				int year = DateTime.Now.Year;
				int day2 = birthDateDateTimePicker.Value.Day;
				int month2 = birthDateDateTimePicker.Value.Month;
				int year2 = birthDateDateTimePicker.Value.Year;
				if (month * 100 + day >= month2 * 100 + day2)
				{
					age.Text = (year - year2).ToString();
				}
				else
				{
					age.Text = (year - year2 - 1).ToString();
				}
			}
			catch
			{
			}
		}

		private void save_Click(object sender, EventArgs e)
		{
			try
			{
				if (PatientName.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter patient name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المريض");
					}
				}
				else
				{
					SaveData();
					MessageBox.Show("تم حفظ البيانات بنجاح");
					Print_Click(sender, e);
					clear();
					PatientName.SelectedIndex = -1;
				}
			}
			catch
			{
			}
		}

		private void update_Click(object sender, EventArgs e)
		{
			try
			{
				if (PatientName.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter patient name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المريض");
					}
				}
				else
				{
					DataTable dataTable = codes.Search2(string.Concat("select ID from neurological_physiotherapy where PatientID='", PatientName.SelectedValue, "'"));
					int num = Convert.ToInt32(dataTable.Rows[0][0].ToString());
					codes.Delete2(string.Concat("delete from neurological_physiotherapy  where PatientID='", PatientName.SelectedValue, "'"));
					codes.Delete2("delete from Range_of_Motion  where neurologicalID='" + num + "'");
					codes.Delete2("delete from Muscle_Tone  where neurologicalID='" + num + "'");
					codes.Delete2("delete from Muscle_Power  where neurologicalID='" + num + "'");
					codes.Delete2("delete from Coordination  where neurologicalID='" + num + "'");
					codes.Delete2("delete from SystemsReview  where neurologicalID='" + num + "'");
					codes.Delete2("delete from Functional_Assessment  where neurologicalID='" + num + "'");
					codes.Delete2("delete from Problem_List where neurologicalID='" + num + "'");
					codes.Delete2("delete from SENSORY_SYSTEM where neurologicalID='" + num + "'");
					SaveData();
					MessageBox.Show("تم تعديل البيانات بنجاح");
				}
				clear();
				PatientName.SelectedIndex = -1;
			}
			catch
			{
			}
		}

		private void FillDGV()
		{
			try
			{
				DGVitalSigns.Rows.Add("Temperature:", "", "Heart Rate:", "");
				DGVitalSigns.Rows.Add("Blood Pressure:", "", "Respiratory Rate:", "");
				DGNerves.Rows.Add("I - Olfactory:", "", "VII - Facial:", "");
				DGNerves.Rows.Add("II - Optic:", "", "VIII - VestibuloCochlear:", "");
				DGNerves.Rows.Add("III - Oculomotor:", "", "IX - Glossopharyngeal", "");
				DGNerves.Rows.Add("IV - Trochlear:", "", "X - Vagus: ", "");
				DGNerves.Rows.Add("V - Trigeminal: ", "", "XI - Accessory: ", "");
				DGNerves.Rows.Add("VI - Abducent: ", "", "XII - Hypoglossal: ", "");
				DGSENSORYSYS.Rows.Add("Superficial", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Pain", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Temperature", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Touch", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Pressure", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Deep", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Mov.Sense", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Pos.Sense", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Vibration", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Cortical", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Tactile Localization", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("2 pt.discrimination", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Stereognosis", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Barognosis", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Graphesthesia", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Texture Recognition", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Double Simultaneous Stimulation", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows[0].Cells[1].ReadOnly = true;
				DGSENSORYSYS.Rows[0].Cells[2].ReadOnly = true;
				DGSENSORYSYS.Rows[0].Cells[3].ReadOnly = true;
				DGSENSORYSYS.Rows[0].Cells[4].ReadOnly = true;
				DGSENSORYSYS.Rows[0].Cells[5].ReadOnly = true;
				DGSENSORYSYS.Rows[0].Cells[6].ReadOnly = true;
				DGSENSORYSYS.Rows[0].Cells[7].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[1].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[2].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[3].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[4].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[5].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[6].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[7].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[1].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[2].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[3].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[4].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[5].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[6].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[7].ReadOnly = true;
				DGMuscleGirth.Rows.Add("Arm", "", "");
				DGMuscleGirth.Rows.Add("Forearm", "", "");
				DGMuscleGirth.Rows.Add("Thigh", "", "");
				DGMuscleGirth.Rows.Add("Calf", "", "");
				DGVoluntaryControl.Rows.Add("Upper Limb", "", "");
				DGVoluntaryControl.Rows.Add("Lower Limb", "", "");
				DGRangeofMotion.Rows.Add("Shoulder", "", "", "", "");
				DGRangeofMotion.Rows.Add("Elbow", "", "", "", "");
				DGRangeofMotion.Rows.Add("Forearm", "", "", "", "");
				DGRangeofMotion.Rows.Add("Wrist", "", "", "", "");
				DGRangeofMotion.Rows.Add("Hand & Fingers", "", "", "", "");
				DGRangeofMotion.Rows.Add("Hip", "", "", "", "");
				DGRangeofMotion.Rows.Add("Knee", "", "", "", "");
				DGRangeofMotion.Rows.Add("Ankle & foot", "", "", "", "");
				DGRangeofMotion2.Rows.Add("Cervical Spine ", "", "", "", "");
				DGRangeofMotion2.Rows.Add("Thoracic Spine", "", "", "", "");
				DGRangeofMotion2.Rows.Add("Lumbar Spine", "", "", "", "");
				DGLimbLength.Rows.Add("True", "", "");
				DGLimbLength.Rows.Add("Apparent", "", "");
				DGMuscleTone1.Rows.Add("Shoulder", "", "");
				DGMuscleTone1.Rows.Add("Flexors", "", "");
				DGMuscleTone1.Rows.Add("Extensors", "", "");
				DGMuscleTone1.Rows.Add("Abductors", "", "");
				DGMuscleTone1.Rows.Add("Adductors", "", "");
				DGMuscleTone1.Rows.Add("External Rotators", "", "");
				DGMuscleTone1.Rows.Add("Internal Rotators", "", "");
				DGMuscleTone1.Rows.Add("Elbow", "", "");
				DGMuscleTone1.Rows.Add("Flexors", "", "");
				DGMuscleTone1.Rows.Add("Extensors", "", "");
				DGMuscleTone1.Rows.Add("Forearm", "", "");
				DGMuscleTone1.Rows.Add("Pronators", "", "");
				DGMuscleTone1.Rows.Add("Supinators", "", "");
				DGMuscleTone1.Rows.Add("Wrist", "", "");
				DGMuscleTone1.Rows.Add("Flexors", "", "");
				DGMuscleTone1.Rows.Add("Extensors", "", "");
				DGMuscleTone1.Rows.Add("Radial Deviators", "", "");
				DGMuscleTone1.Rows.Add("Ulnar Deviators", "", "");
				DGMuscleTone1.Rows.Add("Hand", "", "");
				DGMuscleTone1.Rows.Add("Intrinsics", "", "");
				DGMuscleTone1.Rows.Add("Extrinsics", "", "");
				DGMuscleTone1.Rows[0].Cells[1].ReadOnly = true;
				DGMuscleTone1.Rows[0].Cells[2].ReadOnly = true;
				DGMuscleTone1.Rows[7].Cells[1].ReadOnly = true;
				DGMuscleTone1.Rows[7].Cells[2].ReadOnly = true;
				DGMuscleTone1.Rows[10].Cells[1].ReadOnly = true;
				DGMuscleTone1.Rows[10].Cells[2].ReadOnly = true;
				DGMuscleTone1.Rows[13].Cells[1].ReadOnly = true;
				DGMuscleTone1.Rows[13].Cells[2].ReadOnly = true;
				DGMuscleTone1.Rows[18].Cells[1].ReadOnly = true;
				DGMuscleTone1.Rows[18].Cells[2].ReadOnly = true;
				DGMuscleTone2.Rows.Add("Hip", "", "");
				DGMuscleTone2.Rows.Add("Flexors", "", "");
				DGMuscleTone2.Rows.Add("Extensors", "", "");
				DGMuscleTone2.Rows.Add("Abductors", "", "");
				DGMuscleTone2.Rows.Add("Adductors", "", "");
				DGMuscleTone2.Rows.Add("External Rotators", "", "");
				DGMuscleTone2.Rows.Add("Internal Rotators", "", "");
				DGMuscleTone2.Rows.Add("Knee", "", "");
				DGMuscleTone2.Rows.Add("Flexors", "", "");
				DGMuscleTone2.Rows.Add("Extensors", "", "");
				DGMuscleTone2.Rows.Add("Ankle", "", "");
				DGMuscleTone2.Rows.Add("Dorsiflexors", "", "");
				DGMuscleTone2.Rows.Add("Plantarflexors", "", "");
				DGMuscleTone2.Rows.Add("Foot", "", "");
				DGMuscleTone2.Rows.Add("Invertors", "", "");
				DGMuscleTone2.Rows.Add("Evertors", "", "");
				DGMuscleTone2.Rows.Add("Intrinsics", "", "");
				DGMuscleTone2.Rows.Add("Extrinsics", "", "");
				DGMuscleTone2.Rows[0].Cells[1].ReadOnly = true;
				DGMuscleTone2.Rows[0].Cells[2].ReadOnly = true;
				DGMuscleTone2.Rows[7].Cells[1].ReadOnly = true;
				DGMuscleTone2.Rows[7].Cells[2].ReadOnly = true;
				DGMuscleTone2.Rows[10].Cells[1].ReadOnly = true;
				DGMuscleTone2.Rows[10].Cells[2].ReadOnly = true;
				DGMuscleTone2.Rows[13].Cells[1].ReadOnly = true;
				DGMuscleTone2.Rows[13].Cells[2].ReadOnly = true;
				DGMusclePower1.Rows.Add("Shoulder", "", "");
				DGMusclePower1.Rows.Add("Flexors", "", "");
				DGMusclePower1.Rows.Add("Extensors", "", "");
				DGMusclePower1.Rows.Add("Abductors", "", "");
				DGMusclePower1.Rows.Add("Adductors", "", "");
				DGMusclePower1.Rows.Add("External Rotators", "", "");
				DGMusclePower1.Rows.Add("Internal Rotators", "", "");
				DGMusclePower1.Rows.Add("Elbow", "", "");
				DGMusclePower1.Rows.Add("Flexors", "", "");
				DGMusclePower1.Rows.Add("Extensors", "", "");
				DGMusclePower1.Rows.Add("Forearm", "", "");
				DGMusclePower1.Rows.Add("Pronators", "", "");
				DGMusclePower1.Rows.Add("Supinators", "", "");
				DGMusclePower1.Rows.Add("Wrist", "", "");
				DGMusclePower1.Rows.Add("Flexors", "", "");
				DGMusclePower1.Rows.Add("Extensors", "", "");
				DGMusclePower1.Rows.Add("Radial Deviators", "", "");
				DGMusclePower1.Rows.Add("Ulnar Deviators", "", "");
				DGMusclePower1.Rows.Add("Hand", "", "");
				DGMusclePower1.Rows.Add("Intrinsics", "", "");
				DGMusclePower1.Rows.Add("Extrinsics", "", "");
				DGMusclePower1.Rows[0].Cells[1].ReadOnly = true;
				DGMusclePower1.Rows[0].Cells[2].ReadOnly = true;
				DGMusclePower1.Rows[7].Cells[1].ReadOnly = true;
				DGMusclePower1.Rows[7].Cells[2].ReadOnly = true;
				DGMusclePower1.Rows[10].Cells[1].ReadOnly = true;
				DGMusclePower1.Rows[10].Cells[2].ReadOnly = true;
				DGMusclePower1.Rows[13].Cells[1].ReadOnly = true;
				DGMusclePower1.Rows[13].Cells[2].ReadOnly = true;
				DGMusclePower1.Rows[18].Cells[1].ReadOnly = true;
				DGMusclePower1.Rows[18].Cells[2].ReadOnly = true;
				DGMusclePower2.Rows.Add("Hip", "", "");
				DGMusclePower2.Rows.Add("Flexors", "", "");
				DGMusclePower2.Rows.Add("Extensors", "", "");
				DGMusclePower2.Rows.Add("Abductors", "", "");
				DGMusclePower2.Rows.Add("Adductors", "", "");
				DGMusclePower2.Rows.Add("External Rotators", "", "");
				DGMusclePower2.Rows.Add("Internal Rotators", "", "");
				DGMusclePower2.Rows.Add("Knee", "", "");
				DGMusclePower2.Rows.Add("Flexors", "", "");
				DGMusclePower2.Rows.Add("Extensors", "", "");
				DGMusclePower2.Rows.Add("Ankle", "", "");
				DGMusclePower2.Rows.Add("Dorsiflexors", "", "");
				DGMusclePower2.Rows.Add("Plantarflexors", "", "");
				DGMusclePower2.Rows.Add("Foot", "", "");
				DGMusclePower2.Rows.Add("Invertors", "", "");
				DGMusclePower2.Rows.Add("Evertors", "", "");
				DGMusclePower2.Rows.Add("Intrinsics", "", "");
				DGMusclePower2.Rows.Add("Extrinsics", "", "");
				DGMusclePower2.Rows.Add("Trunk Flexors", "", "");
				DGMusclePower2.Rows.Add("Trunk Extensors", "", "");
				DGMusclePower2.Rows.Add("Trunk Side Flexors", "", "");
				DGMusclePower2.Rows.Add("Trunk Rotators", "", "");
				DGMusclePower2.Rows[0].Cells[1].ReadOnly = true;
				DGMusclePower2.Rows[0].Cells[2].ReadOnly = true;
				DGMusclePower2.Rows[7].Cells[1].ReadOnly = true;
				DGMusclePower2.Rows[7].Cells[2].ReadOnly = true;
				DGMusclePower2.Rows[10].Cells[1].ReadOnly = true;
				DGMusclePower2.Rows[10].Cells[2].ReadOnly = true;
				DGMusclePower2.Rows[13].Cells[1].ReadOnly = true;
				DGMusclePower2.Rows[13].Cells[2].ReadOnly = true;
				DGReflexes.Rows.Add("Abdominal", "", "");
				DGReflexes.Rows.Add("Plantar", "", "");
				DGReflexes.Rows.Add("Biceps", "", "");
				DGReflexes.Rows.Add("Brachioradialis", "", "");
				DGReflexes.Rows.Add("Triceps", "", "");
				DGReflexes.Rows.Add("Knee", "", "");
				DGReflexes.Rows.Add("Ankle", "", "");
				DGCoordination1.Rows.Add("Finger to nose", "", "");
				DGCoordination1.Rows.Add("Finger opposition", "", "");
				DGCoordination1.Rows.Add("Mass Grasp", "", "");
				DGCoordination1.Rows.Add("Pronation/Supination", "", "");
				DGCoordination1.Rows.Add("Rebound test", "", "");
				DGCoordination1.Rows.Add("Tapping (Hand) ", "", "");
				DGCoordination1.Rows.Add("Tapping (Foot) ", "", "");
				DGCoordination1.Rows.Add("Heel to knee", "", "");
				DGCoordination1.Rows.Add("Drawing a circle(Hand)", "", "");
				DGCoordination1.Rows.Add("Drawing a circle(Foot)", "", "");
				DGCoordination2.Rows.Add("Standing: Normal Posture", "", "");
				DGCoordination2.Rows.Add("Standing: Normal Posture with vision occluded", "", "");
				DGCoordination2.Rows.Add("Standing: Feet together", "", "");
				DGCoordination2.Rows.Add("Standing on one foot", "", "");
				DGCoordination2.Rows.Add("Standing: Lateral trunk flexion", "", "");
				DGCoordination2.Rows.Add("Tandem walking", "", "");
				DGCoordination2.Rows.Add("Walk: Sideways", "", "");
				DGCoordination2.Rows.Add("Walk: Backward", "", "");
				DGCoordination2.Rows.Add("Walk in a circle", "", "");
				DGCoordination2.Rows.Add("Walk on heels", "", "");
				DGCoordination2.Rows.Add("Walk on toes", "", "");
				DGProblemList.Rows.Add("", "", "");
				DGProblemList.Rows.Add("", "", "");
				DGProblemList.Rows.Add("", "", "");
				DGProblemList.Rows.Add("", "", "");
				DGProblemList.Rows.Add("", "", "");
				DGProblemList.Rows.Add("", "", "");
			}
			catch
			{
			}
		}

		private void SaveData()
		{
			try
			{
				codes.Add2(string.Concat("insert into neurological_physiotherapy (PatientID,IPOP,\r\nHandedness,\r\nOccupation,\r\nReferredby,\r\nChiefComplaints,\r\nPastMedicalHistory,\r\nPersonalHistory,\r\nFamilyHistory,\r\nSocioeconomicHistory,\r\nSymptomsHistory,\r\nSidee,\r\nSite,\r\nOnset,\r\nDuration,\r\nTypee,\r\nSeverity,\r\nAggravatingFactors,\r\nRelievingFactors,\r\nDGVTemperature,\r\nDGVBloodPressure,\r\nDGVHeartRate,\r\nDGVRespiratoryRate,\r\nAttitudeoflimbs,\r\nBuilt,\r\nPosture,\r\nGait,\r\nPatternofMovement,\r\nModeofVentilation,\r\nRespiration,\r\nOedema,\r\nMuscleWasting,\r\nPressureSores,\r\nDeformity,\r\nWounds,\r\nExternalAppliances,\r\nWarmth,\r\nTenderness,\r\nTone,\r\nSwelling,\r\nConsciousness,\r\nOrientation,\r\nPerson,\r\nPlace,\r\n[Time],\r\nMemory,\r\nImmediate,\r\nRecent,\r\n[Remote],\r\nVerbal,\r\nVisual,\r\nCommunication,\r\nCognition,\r\nFundofKnowledge,\r\nCalculation,\r\nProverbInterpretation,\r\nAttention,\r\nEmotionalStatus,\r\nPerception,\r\nImaging,\r\nAgnosiasApraxias,\r\nSpecialSenses,\r\nDGOlfactory ,\r\nDGOptic ,\r\nDGOculomotor,\r\nDGTrochlear ,\r\nDGTrigeminal, \r\nDGAbducent ,\r\nDGFacial,  \r\nDGVestibuloCochlear ,\r\nDGGlossopharyngeal , \r\nDGVagus,  \r\nDGAccessory,  \r\nDGHypoglossal, \r\nMOTORSYSTEM,\r\nDGArmR, \r\nDGArmL,\r\nDGForearmR,\r\nDGForearmL,\r\nDGThighR,\r\nDGThighL,\r\nDGCalfR,\r\nDGCalfL,\r\nDGUpperLimbR,\r\nDGUpperLimbL,\r\nDGLowerLimbR,\r\nDGLowerLimbL,\r\nDGTrueRt,\r\nDGTrueLt,\r\nDGApparentRt,\r\nDGApparentLt,\r\nDGReflexAbdominalL,\r\nDGReflexAbdominalR,\r\nDGReflexPlantarL ,\r\nDGReflexPlantarR ,\r\nDGReflexBicepsL ,\r\nDGReflexBicepsR,\r\nDGReflexBrachioradialisL ,\r\nDGReflexBrachioradialisR,\r\nDGReflexTricepsL ,\r\nDGReflexTricepsR,\r\nDGReflexKneeL ,\r\nDGReflexKneeR ,\r\nDGReflexAnkleL,\r\nDGReflexAnkleR,\r\nPathological,\r\nInvoluntaryMovements,\r\nBalance,\r\nSitting,\r\nStanding,\r\nBalanceReactions,\r\nPosturee,\r\nLying,\r\nSitting2,\r\nStanding2,\r\nStepLength,\r\nStrideLength,\r\nBasewidth,\r\nCadence,\r\nBiomechanicalDeviations,\r\nHandFunctions,\r\nReaching,\r\nGrasping,\r\nReleasing,\r\nAssisstiveDevices ,\r\n[Functional Diagnosis],\r\nGoals,\r\n[Short term],\r\n[Long term],\r\nTreatmentID) values ('", PatientName.SelectedValue.ToString(), "','", IPOP.Text, "','", Handedness.Text, "','", Occupation.Text, "','", Referredby.Text, "','", ChiefComplaints.Text, "','", PastMedicalHistory.Text, "','", PersonalHistory.Text, "','", FamilyHistory.Text, "','", SocioeconomicHistory.Text, "','", SymptomsHistory.Text, "','", Sidee.Text, "','", Site.Text, "','", Onset.Text, "','", Duration.Text, "','", Typee.Text, "','", Severity.Text, "','", AggravatingFactors.Text, "','", RelievingFactors.Text, "','", DGVitalSigns.Rows[0].Cells["Column2"].Value.ToString(), "','", DGVitalSigns.Rows[0].Cells["Column4"].Value.ToString(), "','", DGVitalSigns.Rows[1].Cells["Column2"].Value.ToString(), "','", DGVitalSigns.Rows[1].Cells["Column4"].Value.ToString(), "','", Attitudeoflimbs.Text, "','", Built.Text, "','", Posture.Text, "','", Gait.Text, "','", PatternofMovement.Text, "','", ModeofVentilation.Text, "','", Respiration.Text, "','", Oedema.Text, "','", MuscleWasting.Text, "','", PressureSores.Text, "','", Deformity.Text, "','", Wounds.Text, "','", ExternalAppliances.Text, "','", Warmth.Text, "','", Tenderness.Text, "','", Tone.Text, "','", Swelling.Text, "','", Consciousness.Text, "','", Orientation.Text, "','", Person.Text, "','", Place.Text, "','", Time.Text, "','", Memory.Text, "','", Immediate.Text, "','", Recent.Text, "','", Remote.Text, "','", Verbal.Text, "','", Visual.Text, "','", Communication.Text, "','", Cognition.Text, "','", FundofKnowledge.Text, "','", Calculation.Text, "','", ProverbInterpretation.Text, "','", Attention.Text, "','", EmotionalStatus.Text, "','", Perception.Text, "','", Imaging.Text, "','", AgnosiasApraxias.Text, "','", SpecialSenses.Text, "','", DGNerves.Rows[0].Cells["Comments"].Value.ToString(), "','", DGNerves.Rows[1].Cells["Comments"].Value.ToString(), "','", DGNerves.Rows[2].Cells["Comments"].Value.ToString(), "','", DGNerves.Rows[3].Cells["Comments"].Value.ToString(), "','", DGNerves.Rows[4].Cells["Comments"].Value.ToString(), "','", DGNerves.Rows[5].Cells["Comments"].Value.ToString(), "','", DGNerves.Rows[0].Cells["Comments2"].Value.ToString(), "','", DGNerves.Rows[1].Cells["Comments2"].Value.ToString(), "','", DGNerves.Rows[2].Cells["Comments2"].Value.ToString(), "','", DGNerves.Rows[3].Cells["Comments2"].Value.ToString(), "','", DGNerves.Rows[4].Cells["Comments2"].Value.ToString(), "','", DGNerves.Rows[5].Cells["Comments2"].Value.ToString(), "','", MOTORSYSTEM.Text, "','", DGMuscleGirth.Rows[0].Cells["Rt_cm"].Value.ToString(), "','", DGMuscleGirth.Rows[0].Cells["Lt_cm"].Value.ToString(), "','", DGMuscleGirth.Rows[1].Cells["Rt_cm"].Value.ToString(), "','", DGMuscleGirth.Rows[1].Cells["Lt_cm"].Value.ToString(), "','", DGMuscleGirth.Rows[2].Cells["Rt_cm"].Value.ToString(), "','", DGMuscleGirth.Rows[2].Cells["Lt_cm"].Value.ToString(), "','", DGMuscleGirth.Rows[3].Cells["Rt_cm"].Value.ToString(), "','", DGMuscleGirth.Rows[3].Cells["Lt_cm"].Value.ToString(), "','", DGVoluntaryControl.Rows[0].Cells["Rt_"].Value.ToString(), "','", DGVoluntaryControl.Rows[0].Cells["Lt_"].Value.ToString(), "','", DGVoluntaryControl.Rows[1].Cells["Rt_"].Value.ToString(), "','", DGVoluntaryControl.Rows[1].Cells["Lt_"].Value.ToString(), "','", DGLimbLength.Rows[0].Cells["LimbRt"].Value.ToString(), "','", DGLimbLength.Rows[0].Cells["LimbLt"].Value.ToString(), "','", DGLimbLength.Rows[1].Cells["LimbRt"].Value.ToString(), "','", DGLimbLength.Rows[1].Cells["LimbLt"].Value.ToString(), "','", DGReflexes.Rows[0].Cells["Left"].Value.ToString(), "','", DGReflexes.Rows[0].Cells["Right"].Value.ToString(), "','", DGReflexes.Rows[1].Cells["Left"].Value.ToString(), "','", DGReflexes.Rows[1].Cells["Right"].Value.ToString(), "','", DGReflexes.Rows[2].Cells["Left"].Value.ToString(), "','", DGReflexes.Rows[2].Cells["Right"].Value.ToString(), "','", DGReflexes.Rows[3].Cells["Left"].Value.ToString(), "','", DGReflexes.Rows[3].Cells["Right"].Value.ToString(), "','", DGReflexes.Rows[4].Cells["Left"].Value.ToString(), "','", DGReflexes.Rows[4].Cells["Right"].Value.ToString(), "','", DGReflexes.Rows[5].Cells["Left"].Value.ToString(), "','", DGReflexes.Rows[5].Cells["Right"].Value.ToString(), "','", DGReflexes.Rows[6].Cells["Left"].Value.ToString(), "','", DGReflexes.Rows[6].Cells["Right"].Value.ToString(), "','", Pathological.Text, "','", InvoluntaryMovements.Text, "','", Balance.Text, "','", Sitting.Text, "','", Standing.Text, "','", BalanceReactions.Text, "','", Posturee.Text, "','", Lying.Text, "','", Sitting2.Text, "','", Standing2.Text, "','", StepLength.Text, "','", StrideLength.Text, "','", Basewidth.Text, "','", Cadence.Text, "','", BiomechanicalDeviations.Text, "','", HandFunctions.Text, "','", Reaching.Text, "','", Grasping.Text, "','", Releasing.Text, "','", AssisstiveDevices.Text, "','", FunctionalDiagnosis.Text, "','", Goals.Text, "','", Shortterm.Text, "','", Longterm.Text, "','", Devicescomb.SelectedValue, "')"));
				DataTable dataTable = codes.Search2("select max(ID) from neurological_physiotherapy");
				int num = Convert.ToInt32(dataTable.Rows[0][0].ToString());
				codes.Add2("insert into SENSORY_SYSTEM (neurologicalID,DGPainUpR,\r\nDGPainUpL,\r\nDGPainLoR,\r\nDGPainLoL,\r\nDGPainTrR,\r\nDGPainTrL,\r\nDGPainnote,\r\nDGTemperatureUpR,\r\nDGTemperatureUpL,\r\nDGTemperatureLoR,\r\nDGTemperatureLoL,\r\nDGTemperatureTrR,\r\nDGTemperatureTrL,\r\nDGTemperaturenote,\r\nDGTouchUpR,\r\nDGTouchUpL,\r\nDGTouchLoR,\r\nDGTouchLoL,\r\nDGTouchTrR,\r\nDGTouchTrL,\r\nDGTouchnote,\r\nDGPressureUpR,\r\nDGPressureUpL,\r\nDGPressureLoR,\r\nDGPressureLoL,\r\nDGPressureTrR,\r\nDGPressureTrL,\r\nDGPressurenote,\r\nDGMovSenseUpR,\r\nDGMovSenseUpL,\r\nDGMovSenseLoR,\r\nDGMovSenseLoL,\r\nDGMovSenseTrR,\r\nDGMovSenseTrL,\r\nDGMovSensenote,\r\nDGPosSenseUpR,\r\nDGPosSenseUpL,\r\nDGPosSenseLoR,\r\nDGPosSenseLoL,\r\nDGPosSenseTrR,\r\nDGPosSenseTrL,\r\nDGPosSensenote,\r\nDGVibrationUpR,\r\nDGVibrationUpL,\r\nDGVibrationLoR,\r\nDGVibrationLoL,\r\nDGVibrationTrR,\r\nDGVibrationTrL,\r\nDGVibrationnote,\r\nDGTactileLocalizationUpR ,\r\nDGTactileLocalizationUpL ,\r\nDGTactileLocalizationLoR ,\r\nDGTactileLocalizationLoL ,\r\nDGTactileLocalizationTrR ,\r\nDGTactileLocalizationTrL ,\r\nDGTactileLocalizationnote ,\r\nDGptdiscriminationUpR ,\r\nDGptdiscriminationUpL ,\r\nDGptdiscriminationLoR ,\r\nDGptdiscriminationLoL ,\r\nDGptdiscriminationTrR ,\r\nDGptdiscriminationTrL ,\r\nDGptdiscriminationnote ,\r\nDGStereognosisUpR,\r\nDGStereognosisUpL,\r\nDGStereognosisLoR,\r\nDGStereognosisLoL,\r\nDGStereognosisTrR,\r\nDGStereognosisTrL,\r\nDGStereognosisnote,\r\nDGBarognosisUpR,\r\nDGBarognosisUpL,\r\nDGBarognosisLoR,\r\nDGBarognosisLoL ,\r\nDGBarognosisTrR ,\r\nDGBarognosisTrL ,\r\nDGBarognosisnote ,\r\nDGGraphesthesiaUpR,\r\nDGGraphesthesiaUpL,\r\nDGGraphesthesiaLoR,\r\nDGGraphesthesiaLoL ,\r\nDGGraphesthesiaTrR,\r\nDGGraphesthesiaTrL,\r\nDGGraphesthesianote,\r\nDGTextureRecognitionUpR,\r\nDGTextureRecognitionUpL,\r\nDGTextureRecognitionLoR,\r\nDGTextureRecognitionLoL,\r\nDGTextureRecognitionTrR,\r\nDGTextureRecognitionTrL,\r\nDGTextureRecognitionnote,\r\nDGStimulationUpR,\r\nDGStimulationUpL,\r\nDGStimulationLoR,\r\nDGStimulationLoL,\r\nDGStimulationTrR,\r\nDGStimulationTrL,\r\nDGStimulationnote) values ('" + num + "','" + DGSENSORYSYS.Rows[0].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[0].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[0].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[0].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[0].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[0].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[0].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[1].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[1].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[1].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[1].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[1].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[1].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[1].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[2].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[2].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[2].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[2].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[2].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[2].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[2].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[3].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[3].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[3].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[3].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[3].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[3].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[3].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[4].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[4].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[4].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[4].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[4].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[4].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[4].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[5].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[5].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[5].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[5].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[5].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[5].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[5].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[6].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[6].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[6].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[6].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[6].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[6].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[6].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[7].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[7].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[7].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[7].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[7].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[7].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[7].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[8].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[8].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[8].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[8].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[8].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[8].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[8].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[9].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[9].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[9].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[9].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[9].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[9].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[9].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[10].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[10].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[10].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[10].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[10].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[10].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[10].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[11].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[11].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[11].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[11].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[11].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[11].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[11].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[12].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[12].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[12].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[12].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[12].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[12].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[12].Cells["notes"].Value.ToString() + "','" + DGSENSORYSYS.Rows[13].Cells["Rt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[13].Cells["Lt1"].Value.ToString() + "','" + DGSENSORYSYS.Rows[13].Cells["Rt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[13].Cells["Lt22"].Value.ToString() + "','" + DGSENSORYSYS.Rows[13].Cells["Rt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[13].Cells["Lt3"].Value.ToString() + "','" + DGSENSORYSYS.Rows[13].Cells["notes"].Value.ToString() + "')");
				codes.Add2("insert into Range_of_Motion (neurologicalID,DGShoulderSide,\r\nDGShoulderMovement,\r\nDGShoulderLimitation,\r\nDGShoulderfactor,\r\nDGElbowSide,\r\nDGElbowMovement,\r\nDGElbowLimitation,\r\nDGElbowfactor,\r\nDGForearmSide,\r\nDGForearmMovement,\r\nDGForearmLimitation,\r\nDGForearmfactor,\r\nDGWristSide,\r\nDGWristMovement,\r\nDGWristLimitation,\r\nDGWristfactor,\r\nDGHandFingersSide,\r\nDGHandFingersMovement,\r\nDGHandFingersLimitation,\r\nDGHandFingersfactor,\r\nDGHipSide,\r\nDGHipMovement,\r\nDGHipLimitation,\r\nDGHipfactor,\r\nDGKneeSide,\r\nDGKneeMovement,\r\nDGKneeLimitation,\r\nDGKneefactor,\r\nDGAnklefootSide,\r\nDGAnklefootMovement,\r\nDGAnklefootLimitation,\r\nDGAnklefootfactor,\r\nDGCervicalSpineSide,\r\nDGCervicalSpineMovement,\r\nDGCervicalSpineLimitation,\r\nDGCervicalSpinefactor,\r\nDGThoracicSpineSide,\r\nDGThoracicSpineMovement,\r\nDGThoracicSpineLimitation,\r\nDGThoracicSpinefactor,\r\nDGLumbarSpineSide,\r\nDGLumbarSpineMovement,\r\nDGLumbarSpineLimitation,\r\nDGLumbarSpinefactor) values ('" + num + "','" + DGRangeofMotion.Rows[0].Cells["Side"].Value.ToString() + "','" + DGRangeofMotion.Rows[0].Cells["Movement"].Value.ToString() + "','" + DGRangeofMotion.Rows[0].Cells["Limitation"].Value.ToString() + "','" + DGRangeofMotion.Rows[0].Cells["Limitingfactor"].Value.ToString() + "','" + DGRangeofMotion.Rows[1].Cells["Side"].Value.ToString() + "','" + DGRangeofMotion.Rows[1].Cells["Movement"].Value.ToString() + "','" + DGRangeofMotion.Rows[1].Cells["Limitation"].Value.ToString() + "','" + DGRangeofMotion.Rows[1].Cells["Limitingfactor"].Value.ToString() + "','" + DGRangeofMotion.Rows[2].Cells["Side"].Value.ToString() + "','" + DGRangeofMotion.Rows[2].Cells["Movement"].Value.ToString() + "','" + DGRangeofMotion.Rows[2].Cells["Limitation"].Value.ToString() + "','" + DGRangeofMotion.Rows[2].Cells["Limitingfactor"].Value.ToString() + "','" + DGRangeofMotion.Rows[3].Cells["Side"].Value.ToString() + "','" + DGRangeofMotion.Rows[3].Cells["Movement"].Value.ToString() + "','" + DGRangeofMotion.Rows[3].Cells["Limitation"].Value.ToString() + "','" + DGRangeofMotion.Rows[3].Cells["Limitingfactor"].Value.ToString() + "','" + DGRangeofMotion.Rows[4].Cells["Side"].Value.ToString() + "','" + DGRangeofMotion.Rows[4].Cells["Movement"].Value.ToString() + "','" + DGRangeofMotion.Rows[4].Cells["Limitation"].Value.ToString() + "','" + DGRangeofMotion.Rows[4].Cells["Limitingfactor"].Value.ToString() + "','" + DGRangeofMotion.Rows[5].Cells["Side"].Value.ToString() + "','" + DGRangeofMotion.Rows[5].Cells["Movement"].Value.ToString() + "','" + DGRangeofMotion.Rows[5].Cells["Limitation"].Value.ToString() + "','" + DGRangeofMotion.Rows[5].Cells["Limitingfactor"].Value.ToString() + "','" + DGRangeofMotion.Rows[6].Cells["Side"].Value.ToString() + "','" + DGRangeofMotion.Rows[6].Cells["Movement"].Value.ToString() + "','" + DGRangeofMotion.Rows[6].Cells["Limitation"].Value.ToString() + "','" + DGRangeofMotion.Rows[6].Cells["Limitingfactor"].Value.ToString() + "','" + DGRangeofMotion.Rows[7].Cells["Side"].Value.ToString() + "','" + DGRangeofMotion.Rows[7].Cells["Movement"].Value.ToString() + "','" + DGRangeofMotion.Rows[7].Cells["Limitation"].Value.ToString() + "','" + DGRangeofMotion.Rows[7].Cells["Limitingfactor"].Value.ToString() + "','" + DGRangeofMotion2.Rows[0].Cells["Side2"].Value.ToString() + "','" + DGRangeofMotion2.Rows[0].Cells["Movement2"].Value.ToString() + "','" + DGRangeofMotion2.Rows[0].Cells["Limitation2"].Value.ToString() + "','" + DGRangeofMotion2.Rows[0].Cells["Limitingfactor2"].Value.ToString() + "','" + DGRangeofMotion2.Rows[1].Cells["Side2"].Value.ToString() + "','" + DGRangeofMotion2.Rows[1].Cells["Movement2"].Value.ToString() + "','" + DGRangeofMotion2.Rows[1].Cells["Limitation2"].Value.ToString() + "','" + DGRangeofMotion2.Rows[1].Cells["Limitingfactor2"].Value.ToString() + "','" + DGRangeofMotion2.Rows[2].Cells["Side2"].Value.ToString() + "','" + DGRangeofMotion2.Rows[2].Cells["Movement2"].Value.ToString() + "','" + DGRangeofMotion2.Rows[2].Cells["Limitation2"].Value.ToString() + "','" + DGRangeofMotion2.Rows[2].Cells["Limitingfactor2"].Value.ToString() + "')");
				codes.Add2("insert into Muscle_Tone (neurologicalID,DGToneSFlexorsRt,\r\nDGToneSFlexorsLt,\r\nDGToneSExtensorsRt,\r\nDGToneSExtensorsLt,\r\nDGToneSAbductorsRt,\r\nDGToneSAbductorsLt,\r\nDGToneSAdductorsRt,\r\nDGToneSAdductorsLt,\r\nDGToneSExternalRotRt,\r\nDGToneSExternalRotLt,\r\nDGToneSInternalRotRt,\r\nDGToneSInternalRotLt,\r\nDGToneEFlexorsRt,\r\nDGToneEFlexorsLt,\r\nDGToneEExtensorsRt,\r\nDGToneEExtensorsLt,\r\nDGToneEPronatorsRt,\r\nDGToneEPronatorsLt,\r\nDGToneESupinatorsRt,\r\nDGToneESupinatorsLt,\r\nDGToneWFlexorsRt,\r\nDGToneWFlexorsLt,\r\nDGToneWExtensorsRt,\r\nDGToneWExtensorsLt,\r\nDGToneWRadialDevRt,\r\nDGToneWRadialDevLt,\r\nDGToneWUlnarDevRt,\r\nDGToneWUlnarDevLt,\r\nDGToneHIntrinsicsRt,\r\nDGToneHIntrinsicsLt,\r\nDGToneEHxtrinsicsRt,\r\nDGToneHExtrinsicsLt,\r\nDGToneHIFlexorsRt,\r\nDGToneHIFlexorsLt,\r\nDGToneHIExtensorsRt,\r\nDGToneHIExtensorsLt,\r\nDGToneHIAbductorsRt,\r\nDGToneHIAbductorsLt,\r\nDGToneHIAdductorsRt,\r\nDGToneHIAdductorsLt,\r\nDGToneHIExternalRotRt,\r\nDGToneHIExternalRotLt,\r\nDGToneHIInternalRotRt,\r\nDGToneHIInternalRotLt,\r\nDGToneKFlexorsRt,\r\nDGToneKFlexorsLt,\r\nDGToneKExtensorsRt,\r\nDGToneKExtensorsLt,\r\nDGToneANDorsiflexorsRt,\r\nDGToneANDorsiflexorsLt,\r\nDGToneANPlantarflexorsRt,\r\nDGToneANPlantarflexorsLt,\r\nDGToneFInvertorsRt,\r\nDGToneFInvertorsLt,\r\nDGToneFEvertorsRt,\r\nDGToneFEvertorsLt,\r\nDGToneFIntrinsicsRt,\r\nDGToneFIntrinsicsLt,\r\nDGToneFExtrinsicsRt,\r\nDGToneFExtrinsicsLt) values ('" + num + "','" + DGMuscleTone1.Rows[1].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[1].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[2].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[2].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[3].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[3].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[4].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[4].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[5].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[5].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[6].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[6].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[8].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[8].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[9].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[9].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[11].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[11].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[12].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[12].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[14].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[14].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[15].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[15].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[16].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[16].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[17].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[17].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[19].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[19].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone1.Rows[20].Cells["TRT"].Value.ToString() + "','" + DGMuscleTone1.Rows[20].Cells["TLT"].Value.ToString() + "','" + DGMuscleTone2.Rows[1].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[1].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[2].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[2].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[3].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[3].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[4].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[4].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[5].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[5].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[6].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[6].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[8].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[8].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[9].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[9].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[11].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[11].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[12].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[12].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[14].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[14].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[15].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[15].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[16].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[16].Cells["TLT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[17].Cells["TRT2"].Value.ToString() + "','" + DGMuscleTone2.Rows[17].Cells["TLT2"].Value.ToString() + "')");
				codes.Add2("insert into Muscle_Power (neurologicalID,PowerSFlexorsRt,PowerSFlexorsLt,PowerSExtensorsRt,PowerSExtensorsLt,PowerSAbductorsRt,\r\nPowerSAbductorsLt,\r\nPowerSAdductorsRt,\r\nPowerSAdductorsLt,\r\nPowerExternalRotRt,\r\nPowerSExternalRotLt,\r\nPowerSInternalRotRt,\r\nPowerSInternalRotLt,\r\nPowerEFlexorsRt,\r\nPowerEFlexorsLt,\r\nPowerEExtensorsRt,\r\nPowerEExtensorsLt,\r\nPowerEPronatorsRt,\r\nPowerEPronatorsLt,\r\nPowerESupinatorsRt,\r\nPowerESupinatorsLt,\r\nPowerWFlexorsRt,\r\nPowerWFlexorsLt,\r\nPowerWExtensorsRt,\r\nPowerWExtensorsLt,\r\nPowerWRadialDevRt,\r\nPowerWRadialDevLt,\r\nPowerWUlnarDevRt,\r\nPowerWUlnarDevLt,\r\nPowerHIntrinsicsRt,\r\nPowerHIntrinsicsLt,\r\nPowerEHxtrinsicsRt,\r\nPowerHExtrinsicsLt,\r\nPowerHIFlexorsRt,\r\nPowerHIFlexorsLt,\r\nPowerHIExtensorsRt,\r\nPowerHIExtensorsLt,\r\nPowerHIAbductorsRt,\r\nPowerHIAbductorsLt,\r\nPowerHIAdductorsRt,\r\nPowerHIAdductorsLt,\r\nPowerHIExternalRotRt,\r\nPowerHIExternalRotLt,\r\nPowerHIInternalRotRt,\r\nPowerHIInternalRotLt,\r\nPowerKFlexorsRt,\r\nPowerKFlexorsLt,\r\nPowerKExtensorsRt,\r\nPowerKExtensorsLt,\r\nPowerANDorsiflexorsRt,\r\nPowerANDorsiflexorsLt,\r\nPowerANPlantarflexorsRt,\r\nPowerANPlantarflexorsLt,\r\nPowerFInvertorsRt,\r\nPowerFInvertorsLt,\r\nPowerFEvertorsRt,\r\nPowerFEvertorsLt,\r\nPowerFIntrinsicsRt,\r\nPowerFIntrinsicsLt,\r\nPowerFExtrinsicsRt,\r\nPowerFExtrinsicsLt,\r\nPowerTrunkFlexorsRt, \r\nPowerTrunkFlexorsLt,\r\nPowerTrunkExtensorsRt, \r\nPowerTrunkExtensorsLt,\r\nPowerTrunkSideFlexorsRt,\r\nPowerTrunkSideFlexorsLt,\r\nPowerTrunkRotatorsRt,\r\nPowerTrunkRotatorsLt) values ('" + num + "','" + DGMusclePower1.Rows[1].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[1].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[2].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[2].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[3].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[3].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[4].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[4].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[5].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[5].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[6].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[6].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[8].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[8].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[9].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[9].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[11].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[11].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[12].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[12].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[14].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[14].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[15].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[15].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[16].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[16].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[17].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[17].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[19].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[19].Cells["PLT"].Value.ToString() + "','" + DGMusclePower1.Rows[20].Cells["PRT"].Value.ToString() + "','" + DGMusclePower1.Rows[20].Cells["PLT"].Value.ToString() + "','" + DGMusclePower2.Rows[1].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[1].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[2].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[2].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[3].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[3].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[4].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[4].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[5].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[5].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[6].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[6].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[8].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[8].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[9].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[9].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[11].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[11].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[12].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[12].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[14].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[14].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[15].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[15].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[16].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[16].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[17].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[17].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[18].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[18].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[19].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[19].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[20].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[20].Cells["PLT2"].Value.ToString() + "','" + DGMusclePower2.Rows[21].Cells["PRT2"].Value.ToString() + "','" + DGMusclePower2.Rows[21].Cells["PLT2"].Value.ToString() + "')");
				codes.Add2("insert into Coordination (neurologicalID,FingernoseR,FingernoseT,FingeroppositionR,FingeroppositionT,MassGraspR,MassGraspT,PronationSupinationR,PronationSupinationT,ReboundtestR,ReboundtestT,TappingHandR,TappingHandT,TappingFootR,TappingFootT,HeeltokneeR,HeeltokneeT,circleHandR,circleHandT,circleFootR,circleFootT,StandNormal,StandNormalwithvision,StandingFeettogether,Standingononefoot,StandingLateraltrunkflexion,Tandemwalking,WalkSideways,WalkBackward,Walkcircle,Walkheels,Walktoes ) values ('" + num + "','" + DGCoordination1.Rows[0].Cells["RT2"].Value.ToString() + "','" + DGCoordination1.Rows[0].Cells["LT2"].Value.ToString() + "','" + DGCoordination1.Rows[1].Cells["RT2"].Value.ToString() + "','" + DGCoordination1.Rows[1].Cells["LT2"].Value.ToString() + "','" + DGCoordination1.Rows[2].Cells["RT2"].Value.ToString() + "','" + DGCoordination1.Rows[2].Cells["LT2"].Value.ToString() + "','" + DGCoordination1.Rows[3].Cells["RT2"].Value.ToString() + "','" + DGCoordination1.Rows[3].Cells["LT2"].Value.ToString() + "','" + DGCoordination1.Rows[4].Cells["RT2"].Value.ToString() + "','" + DGCoordination1.Rows[4].Cells["LT2"].Value.ToString() + "','" + DGCoordination1.Rows[5].Cells["RT2"].Value.ToString() + "','" + DGCoordination1.Rows[5].Cells["LT2"].Value.ToString() + "','" + DGCoordination1.Rows[6].Cells["RT2"].Value.ToString() + "','" + DGCoordination1.Rows[6].Cells["LT2"].Value.ToString() + "','" + DGCoordination1.Rows[7].Cells["RT2"].Value.ToString() + "','" + DGCoordination1.Rows[7].Cells["LT2"].Value.ToString() + "','" + DGCoordination1.Rows[8].Cells["RT2"].Value.ToString() + "','" + DGCoordination1.Rows[8].Cells["LT2"].Value.ToString() + "','" + DGCoordination1.Rows[9].Cells["RT2"].Value.ToString() + "','" + DGCoordination1.Rows[9].Cells["LT2"].Value.ToString() + "','" + DGCoordination2.Rows[0].Cells["Grade"].Value.ToString() + "','" + DGCoordination2.Rows[1].Cells["Grade"].Value.ToString() + "','" + DGCoordination2.Rows[2].Cells["Grade"].Value.ToString() + "','" + DGCoordination2.Rows[3].Cells["Grade"].Value.ToString() + "','" + DGCoordination2.Rows[4].Cells["Grade"].Value.ToString() + "','" + DGCoordination2.Rows[5].Cells["Grade"].Value.ToString() + "','" + DGCoordination2.Rows[6].Cells["Grade"].Value.ToString() + "','" + DGCoordination2.Rows[7].Cells["Grade"].Value.ToString() + "','" + DGCoordination2.Rows[8].Cells["Grade"].Value.ToString() + "','" + DGCoordination2.Rows[9].Cells["Grade"].Value.ToString() + "','" + DGCoordination2.Rows[10].Cells["Grade"].Value.ToString() + "')");
				codes.Add2("insert into SystemsReview (neurologicalID,IntegSystem,SkinStatus,PressureSoress,RESPIRATORYSYSTEM,RSStatus,Secretions,Patternofbreathing,spinedeformity,CVSStatus,Thrombosis,Contractures,Subluxations,Jointmobility,Otherpathology,Incontinence,Status,Vasomotor,Pseudomotor,TrophicChanges,PosturalHypotension,ReflexSympatheticDystrophy) values ('" + num + "','" + IntegSystem.Text + "','" + SkinStatus.Text + "','" + PressureSoress.Text + "','" + RESPIRATORYSYSTEM.Text + "','" + RSStatus.Text + "','" + Secretions.Text + "','" + Patternofbreathing.Text + "','" + spinedeformity.Text + "','" + CVSStatus.Text + "','" + Thrombosis.Text + "','" + Contractures.Text + "','" + Subluxations.Text + "','" + Jointmobility.Text + "','" + Otherpathology.Text + "','" + Incontinence.Text + "','" + Status.Text + "','" + Vasomotor.Text + "','" + Pseudomotor.Text + "','" + TrophicChanges.Text + "','" + PosturalHypotension.Text + "','" + ReflexSympatheticDystrophy.Text + "')");
				codes.Add2("insert into Functional_Assessment (neurologicalID,Evaluation1,Item1,Item2,Item3,Item4,Item5,Evaluation2,Item6,Item7,Evaluation3,Item8,Item9,Item10,Evaluation4,Item11,Item12,Evaluation5,Item13,Item14,Evaluation6,Item15,Item16,Item17,InvestigationFindings) values \r\n           ('" + num + "','" + Evaluation1.Text + "','" + Item1.Text + "','" + Item2.Text + "','" + Item3.Text + "','" + Item4.Text + "','" + Item5.Text + "','" + Evaluation2.Text + "','" + Item6.Text + "','" + Item7.Text + "','" + Evaluation3.Text + "','" + Item8.Text + "','" + Item9.Text + "','" + Item10.Text + "','" + Evaluation4.Text + "','" + Item11.Text + "','" + Item12.Text + "','" + Evaluation5.Text + "','" + Item13.Text + "','" + Item14.Text + "','" + Evaluation6.Text + "','" + Item15.Text + "','" + Item16.Text + "','" + Item17.Text + "','" + InvestigationFindings.Text + "')");
				for (int i = 0; i < DGProblemList.Rows.Count - 1; i++)
				{
					codes.Add2("insert into Problem_List (neurologicalID,SI,Impairment,FunctionalLimitation ) values ('" + num + "','" + DGProblemList.Rows[i].Cells["Sl"].Value.ToString() + "','" + DGProblemList.Rows[i].Cells["Impairment"].Value.ToString() + "','" + DGProblemList.Rows[i].Cells["FunctionalLimitation"].Value.ToString() + "')");
				}
			}
			catch
			{
			}
		}

		private void clear()
		{
			try
			{
				DGCoordination1.Rows.Clear();
				DGCoordination2.Rows.Clear();
				DGVitalSigns.Rows.Clear();
				DGNerves.Rows.Clear();
				DGMuscleGirth.Rows.Clear();
				DGVoluntaryControl.Rows.Clear();
				DGLimbLength.Rows.Clear();
				DGReflexes.Rows.Clear();
				DGMusclePower1.Rows.Clear();
				DGMusclePower2.Rows.Clear();
				DGMuscleTone1.Rows.Clear();
				DGMuscleTone2.Rows.Clear();
				DGProblemList.Rows.Clear();
				DGRangeofMotion.Rows.Clear();
				DGRangeofMotion2.Rows.Clear();
				DGSENSORYSYS.Rows.Clear();
				FillDGV();
				update.Enabled = false;
				save.Enabled = true;
				DataTable tableText = dc.GetTableText("select ID,Name from NaturalTherapy");
				Devicescomb.DataSource = null;
				Devicescomb.DataSource = tableText;
				Devicescomb.DisplayMember = tableText.Columns["Name"].ToString();
				Devicescomb.ValueMember = tableText.Columns["ID"].ToString();
				IPOP.Text = "";
				Handedness.Text = "";
				Occupation.Text = "";
				Referredby.Text = "";
				ChiefComplaints.Text = "";
				PastMedicalHistory.Text = "";
				PersonalHistory.Text = "";
				FamilyHistory.Text = "";
				SocioeconomicHistory.Text = "";
				SymptomsHistory.Text = "";
				Sidee.Text = "";
				Site.Text = "";
				Onset.Text = "";
				Duration.Text = "";
				Typee.Text = "";
				Severity.Text = "";
				AggravatingFactors.Text = "";
				RelievingFactors.Text = "";
				Attitudeoflimbs.Text = "";
				Built.Text = "";
				Posture.Text = "";
				Gait.Text = "";
				PatternofMovement.Text = "";
				ModeofVentilation.Text = "";
				Respiration.Text = "";
				Oedema.Text = "";
				MuscleWasting.Text = "";
				PressureSores.Text = "";
				Deformity.Text = "";
				Wounds.Text = "";
				ExternalAppliances.Text = "";
				Warmth.Text = "";
				Tenderness.Text = "";
				Tone.Text = "";
				Swelling.Text = "";
				Consciousness.Text = "";
				Orientation.Text = "";
				Person.Text = "";
				Place.Text = "";
				Time.Text = "";
				Memory.Text = "";
				Immediate.Text = "";
				Recent.Text = "";
				Remote.Text = "";
				Verbal.Text = "";
				Visual.Text = "";
				Communication.Text = "";
				Cognition.Text = "";
				FundofKnowledge.Text = "";
				Calculation.Text = "";
				ProverbInterpretation.Text = "";
				Attention.Text = "";
				EmotionalStatus.Text = "";
				Perception.Text = "";
				Imaging.Text = "";
				AgnosiasApraxias.Text = "";
				SpecialSenses.Text = "";
				MOTORSYSTEM.Text = "";
				Pathological.Text = "";
				InvoluntaryMovements.Text = "";
				Balance.Text = "";
				Sitting.Text = "";
				Standing.Text = "";
				BalanceReactions.Text = "";
				Posturee.Text = "";
				Lying.Text = "";
				Sitting2.Text = "";
				Standing2.Text = "";
				StepLength.Text = "";
				StrideLength.Text = "";
				Basewidth.Text = "";
				Cadence.Text = "";
				BiomechanicalDeviations.Text = "";
				HandFunctions.Text = "";
				Reaching.Text = "";
				Grasping.Text = "";
				Releasing.Text = "";
				AssisstiveDevices.Text = "";
				FunctionalDiagnosis.Text = "";
				Goals.Text = "";
				Shortterm.Text = "";
				Longterm.Text = "";
				Evaluation1.Text = "";
				Item1.Text = "";
				Item2.Text = "";
				Item3.Text = "";
				Item4.Text = "";
				Item5.Text = "";
				Evaluation2.Text = "";
				Item6.Text = "";
				Item7.Text = "";
				Evaluation3.Text = "";
				Item8.Text = "";
				Item9.Text = "";
				Item10.Text = "";
				Evaluation4.Text = "";
				Item11.Text = "";
				Item12.Text = "";
				Evaluation5.Text = "";
				Item13.Text = "";
				Item14.Text = "";
				Evaluation6.Text = "";
				Item15.Text = "";
				Item16.Text = "";
				Item17.Text = "";
				InvestigationFindings.Text = "";
				IntegSystem.Text = "";
				SkinStatus.Text = "";
				PressureSoress.Text = "";
				RESPIRATORYSYSTEM.Text = "";
				RSStatus.Text = "";
				Secretions.Text = "";
				Patternofbreathing.Text = "";
				spinedeformity.Text = "";
				CVSStatus.Text = "";
				Thrombosis.Text = "";
				Contractures.Text = "";
				Subluxations.Text = "";
				Jointmobility.Text = "";
				Otherpathology.Text = "";
				Incontinence.Text = "";
				Status.Text = "";
				Vasomotor.Text = "";
				Pseudomotor.Text = "";
				TrophicChanges.Text = "";
				PosturalHypotension.Text = "";
				ReflexSympatheticDystrophy.Text = "";
			}
			catch
			{
			}
		}

		private void Print_Click(object sender, EventArgs e)
		{
			try
			{
				if (PatientName.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter patient name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المريض");
					}
					return;
				}
				dataSet11.Clear();
				DataTable dataTable = codes.Search2(string.Concat("select ID from neurological_physiotherapy where PatientID='", PatientName.SelectedValue, "'"));
				int num = Convert.ToInt32(dataTable.Rows[0][0].ToString());
				sqlConnection1.ConnectionString = codes.ConnectionStr;
				sqlConnection2.ConnectionString = codes.ConnectionStr;
				sqlConnection3.ConnectionString = codes.ConnectionStr;
				sqlConnection4.ConnectionString = codes.ConnectionStr;
				sqlConnection5.ConnectionString = codes.ConnectionStr;
				sqlConnection6.ConnectionString = codes.ConnectionStr;
				sqlConnection7.ConnectionString = codes.ConnectionStr;
				sqlConnection8.ConnectionString = codes.ConnectionStr;
				sqlConnection9.ConnectionString = codes.ConnectionStr;
				sqlConnection10.ConnectionString = codes.ConnectionStr;
				sqlConnection11.ConnectionString = codes.ConnectionStr;
				sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter1.SelectCommand.CommandText = "select * from PatientData where ID = '" + PatientName.SelectedValue.ToString() + "'";
				sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter2.SelectCommand.CommandText = "select * from neurological_physiotherapy where PatientID = '" + PatientName.SelectedValue.ToString() + "'";
				sqlDataAdapter3.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter3.SelectCommand.CommandText = "select * from Coordination where neurologicalID = '" + num + "'";
				sqlDataAdapter4.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter4.SelectCommand.CommandText = "select * from Functional_Assessment where neurologicalID = '" + num + "'";
				sqlDataAdapter5.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter5.SelectCommand.CommandText = "select * from Muscle_Power where neurologicalID = '" + num + "'";
				sqlDataAdapter6.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter6.SelectCommand.CommandText = "select * from Muscle_Tone where neurologicalID = '" + num + "'";
				sqlDataAdapter7.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter7.SelectCommand.CommandText = "select * from Problem_List where neurologicalID = '" + num + "'";
				sqlDataAdapter8.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter8.SelectCommand.CommandText = "select * from Range_of_Motion where neurologicalID = '" + num + "'";
				sqlDataAdapter9.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter9.SelectCommand.CommandText = "select * from SENSORY_SYSTEM where neurologicalID = '" + num + "'";
				sqlDataAdapter10.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter10.SelectCommand.CommandText = "select * from SystemsReview where neurologicalID = '" + num + "'";
				sqlDataAdapter11.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter11.SelectCommand.CommandText = string.Concat("select * from NaturalTherapy where ID = '", Devicescomb.SelectedValue, "'");
				sqlDataAdapter1.Fill(dataSet11);
				sqlDataAdapter2.Fill(dataSet11);
				sqlDataAdapter3.Fill(dataSet11);
				sqlDataAdapter4.Fill(dataSet11);
				sqlDataAdapter5.Fill(dataSet11);
				sqlDataAdapter6.Fill(dataSet11);
				sqlDataAdapter7.Fill(dataSet11);
				sqlDataAdapter8.Fill(dataSet11);
				sqlDataAdapter9.Fill(dataSet11);
				sqlDataAdapter10.Fill(dataSet11);
				sqlDataAdapter11.Fill(dataSet11);
				NaturalTherapyRPT naturalTherapyRPT = new NaturalTherapyRPT(dataSet11, "N");
				naturalTherapyRPT.ShowDialog();
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (tabPage1.Focus())
			{
				IPOP.Text = "";
				Handedness.Text = "";
				Occupation.Text = "";
				Referredby.Text = "";
				ChiefComplaints.Text = "";
				PastMedicalHistory.Text = "";
				PersonalHistory.Text = "";
				FamilyHistory.Text = "";
				SocioeconomicHistory.Text = "";
				SymptomsHistory.Text = "";
				Sidee.Text = "";
				Site.Text = "";
				Onset.Text = "";
				Duration.Text = "";
				Typee.Text = "";
				Severity.Text = "";
				AggravatingFactors.Text = "";
				RelievingFactors.Text = "";
				DGVitalSigns.Rows.Clear();
				DGVitalSigns.Rows.Add("Temperature:", "", "Heart Rate:", "");
				DGVitalSigns.Rows.Add("Blood Pressure:", "", "Respiratory Rate:", "");
				address.Text = "";
				sex.Text = "";
				age.Text = "";
				PatientName.SelectedIndex = -1;
			}
			else if (tabPage2.Focus())
			{
				Attitudeoflimbs.Text = "";
				Built.Text = "";
				Posture.Text = "";
				Gait.Text = "";
				PatternofMovement.Text = "";
				ModeofVentilation.Text = "";
				Respiration.Text = "";
				Oedema.Text = "";
				MuscleWasting.Text = "";
				PressureSores.Text = "";
				Deformity.Text = "";
				Wounds.Text = "";
				ExternalAppliances.Text = "";
				Warmth.Text = "";
				Tenderness.Text = "";
				Tone.Text = "";
				Swelling.Text = "";
				Consciousness.Text = "";
				Orientation.Text = "";
				Person.Text = "";
				Place.Text = "";
				Time.Text = "";
			}
			else if (tabPage3.Focus())
			{
				Memory.Text = "";
				Immediate.Text = "";
				Recent.Text = "";
				Remote.Text = "";
				Verbal.Text = "";
				Visual.Text = "";
				Communication.Text = "";
				Cognition.Text = "";
				FundofKnowledge.Text = "";
				Calculation.Text = "";
				ProverbInterpretation.Text = "";
				Attention.Text = "";
				EmotionalStatus.Text = "";
				Perception.Text = "";
				Imaging.Text = "";
				AgnosiasApraxias.Text = "";
				SpecialSenses.Text = "";
				DGNerves.Rows.Clear();
				DGNerves.Rows.Add("I - Olfactory:", "", "VII - Facial:", "");
				DGNerves.Rows.Add("II - Optic:", "", "VIII - VestibuloCochlear:", "");
				DGNerves.Rows.Add("III - Oculomotor:", "", "IX - Glossopharyngeal", "");
				DGNerves.Rows.Add("IV - Trochlear:", "", "X - Vagus: ", "");
				DGNerves.Rows.Add("V - Trigeminal: ", "", "XI - Accessory: ", "");
				DGNerves.Rows.Add("VI - Abducent: ", "", "XII - Hypoglossal: ", "");
			}
			else if (tabPage4.Focus())
			{
				MOTORSYSTEM.Text = "";
				DGSENSORYSYS.Rows.Clear();
				DGSENSORYSYS.Rows.Add("Superficial", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Pain", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Temperature", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Touch", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Pressure", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Deep", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Mov.Sense", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Pos.Sense", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Vibration", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Cortical", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Tactile Localization", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("2 pt.discrimination", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Stereognosis", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Barognosis", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Graphesthesia", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Texture Recognition", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows.Add("Double Simultaneous Stimulation", "", "", "", "", "", "", "");
				DGSENSORYSYS.Rows[0].Cells[1].ReadOnly = true;
				DGSENSORYSYS.Rows[0].Cells[2].ReadOnly = true;
				DGSENSORYSYS.Rows[0].Cells[3].ReadOnly = true;
				DGSENSORYSYS.Rows[0].Cells[4].ReadOnly = true;
				DGSENSORYSYS.Rows[0].Cells[5].ReadOnly = true;
				DGSENSORYSYS.Rows[0].Cells[6].ReadOnly = true;
				DGSENSORYSYS.Rows[0].Cells[7].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[1].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[2].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[3].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[4].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[5].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[6].ReadOnly = true;
				DGSENSORYSYS.Rows[5].Cells[7].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[1].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[2].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[3].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[4].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[5].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[6].ReadOnly = true;
				DGSENSORYSYS.Rows[9].Cells[7].ReadOnly = true;
				DGMuscleGirth.Rows.Clear();
				DGMuscleGirth.Rows.Add("Arm", "", "");
				DGMuscleGirth.Rows.Add("Forearm", "", "");
				DGMuscleGirth.Rows.Add("Thigh", "", "");
				DGMuscleGirth.Rows.Add("Calf", "", "");
				DGVoluntaryControl.Rows.Clear();
				DGVoluntaryControl.Rows.Add("Upper Limb", "", "");
				DGVoluntaryControl.Rows.Add("Lower Limb", "", "");
			}
			else if (tabPage5.Focus())
			{
				DGRangeofMotion.Rows.Clear();
				DGRangeofMotion.Rows.Add("Shoulder", "", "", "", "");
				DGRangeofMotion.Rows.Add("Elbow", "", "", "", "");
				DGRangeofMotion.Rows.Add("Forearm", "", "", "", "");
				DGRangeofMotion.Rows.Add("Wrist", "", "", "", "");
				DGRangeofMotion.Rows.Add("Hand & Fingers", "", "", "", "");
				DGRangeofMotion.Rows.Add("Hip", "", "", "", "");
				DGRangeofMotion.Rows.Add("Knee", "", "", "", "");
				DGRangeofMotion.Rows.Add("Ankle & foot", "", "", "", "");
			}
			else if (tabPage6.Focus())
			{
				DGRangeofMotion2.Rows.Clear();
				DGRangeofMotion2.Rows.Add("Cervical Spine ", "", "", "", "");
				DGRangeofMotion2.Rows.Add("Thoracic Spine", "", "", "", "");
				DGRangeofMotion2.Rows.Add("Lumbar Spine", "", "", "", "");
				DGLimbLength.Rows.Clear();
				DGLimbLength.Rows.Add("True", "", "");
				DGLimbLength.Rows.Add("Apparent", "", "");
			}
			else if (tabPage7.Focus())
			{
				DGMuscleTone1.Rows.Clear();
				DGMuscleTone1.Rows.Add("Shoulder", "", "");
				DGMuscleTone1.Rows.Add("Flexors", "", "");
				DGMuscleTone1.Rows.Add("Extensors", "", "");
				DGMuscleTone1.Rows.Add("Abductors", "", "");
				DGMuscleTone1.Rows.Add("Adductors", "", "");
				DGMuscleTone1.Rows.Add("External Rotators", "", "");
				DGMuscleTone1.Rows.Add("Internal Rotators", "", "");
				DGMuscleTone1.Rows.Add("Elbow", "", "");
				DGMuscleTone1.Rows.Add("Flexors", "", "");
				DGMuscleTone1.Rows.Add("Extensors", "", "");
				DGMuscleTone1.Rows.Add("Forearm", "", "");
				DGMuscleTone1.Rows.Add("Pronators", "", "");
				DGMuscleTone1.Rows.Add("Supinators", "", "");
				DGMuscleTone1.Rows.Add("Wrist", "", "");
				DGMuscleTone1.Rows.Add("Flexors", "", "");
				DGMuscleTone1.Rows.Add("Extensors", "", "");
				DGMuscleTone1.Rows.Add("Radial Deviators", "", "");
				DGMuscleTone1.Rows.Add("Ulnar Deviators", "", "");
				DGMuscleTone1.Rows.Add("Hand", "", "");
				DGMuscleTone1.Rows.Add("Intrinsics", "", "");
				DGMuscleTone1.Rows.Add("Extrinsics", "", "");
				DGMuscleTone1.Rows[0].Cells[1].ReadOnly = true;
				DGMuscleTone1.Rows[0].Cells[2].ReadOnly = true;
				DGMuscleTone1.Rows[7].Cells[1].ReadOnly = true;
				DGMuscleTone1.Rows[7].Cells[2].ReadOnly = true;
				DGMuscleTone1.Rows[10].Cells[1].ReadOnly = true;
				DGMuscleTone1.Rows[10].Cells[2].ReadOnly = true;
				DGMuscleTone1.Rows[13].Cells[1].ReadOnly = true;
				DGMuscleTone1.Rows[13].Cells[2].ReadOnly = true;
				DGMuscleTone1.Rows[18].Cells[1].ReadOnly = true;
				DGMuscleTone1.Rows[18].Cells[2].ReadOnly = true;
				DGMuscleTone2.Rows.Clear();
				DGMuscleTone2.Rows.Add("Hip", "", "");
				DGMuscleTone2.Rows.Add("Flexors", "", "");
				DGMuscleTone2.Rows.Add("Extensors", "", "");
				DGMuscleTone2.Rows.Add("Abductors", "", "");
				DGMuscleTone2.Rows.Add("Adductors", "", "");
				DGMuscleTone2.Rows.Add("External Rotators", "", "");
				DGMuscleTone2.Rows.Add("Internal Rotators", "", "");
				DGMuscleTone2.Rows.Add("Knee", "", "");
				DGMuscleTone2.Rows.Add("Flexors", "", "");
				DGMuscleTone2.Rows.Add("Extensors", "", "");
				DGMuscleTone2.Rows.Add("Ankle", "", "");
				DGMuscleTone2.Rows.Add("Dorsiflexors", "", "");
				DGMuscleTone2.Rows.Add("Plantarflexors", "", "");
				DGMuscleTone2.Rows.Add("Foot", "", "");
				DGMuscleTone2.Rows.Add("Invertors", "", "");
				DGMuscleTone2.Rows.Add("Evertors", "", "");
				DGMuscleTone2.Rows.Add("Intrinsics", "", "");
				DGMuscleTone2.Rows.Add("Extrinsics", "", "");
				DGMuscleTone2.Rows[0].Cells[1].ReadOnly = true;
				DGMuscleTone2.Rows[0].Cells[2].ReadOnly = true;
				DGMuscleTone2.Rows[7].Cells[1].ReadOnly = true;
				DGMuscleTone2.Rows[7].Cells[2].ReadOnly = true;
				DGMuscleTone2.Rows[10].Cells[1].ReadOnly = true;
				DGMuscleTone2.Rows[10].Cells[2].ReadOnly = true;
				DGMuscleTone2.Rows[13].Cells[1].ReadOnly = true;
				DGMuscleTone2.Rows[13].Cells[2].ReadOnly = true;
			}
			else if (tabPage8.Focus())
			{
				DGMusclePower1.Rows.Clear();
				DGMusclePower1.Rows.Add("Shoulder", "", "");
				DGMusclePower1.Rows.Add("Flexors", "", "");
				DGMusclePower1.Rows.Add("Extensors", "", "");
				DGMusclePower1.Rows.Add("Abductors", "", "");
				DGMusclePower1.Rows.Add("Adductors", "", "");
				DGMusclePower1.Rows.Add("External Rotators", "", "");
				DGMusclePower1.Rows.Add("Internal Rotators", "", "");
				DGMusclePower1.Rows.Add("Elbow", "", "");
				DGMusclePower1.Rows.Add("Flexors", "", "");
				DGMusclePower1.Rows.Add("Extensors", "", "");
				DGMusclePower1.Rows.Add("Forearm", "", "");
				DGMusclePower1.Rows.Add("Pronators", "", "");
				DGMusclePower1.Rows.Add("Supinators", "", "");
				DGMusclePower1.Rows.Add("Wrist", "", "");
				DGMusclePower1.Rows.Add("Flexors", "", "");
				DGMusclePower1.Rows.Add("Extensors", "", "");
				DGMusclePower1.Rows.Add("Radial Deviators", "", "");
				DGMusclePower1.Rows.Add("Ulnar Deviators", "", "");
				DGMusclePower1.Rows.Add("Hand", "", "");
				DGMusclePower1.Rows.Add("Intrinsics", "", "");
				DGMusclePower1.Rows.Add("Extrinsics", "", "");
				DGMusclePower1.Rows[0].Cells[1].ReadOnly = true;
				DGMusclePower1.Rows[0].Cells[2].ReadOnly = true;
				DGMusclePower1.Rows[7].Cells[1].ReadOnly = true;
				DGMusclePower1.Rows[7].Cells[2].ReadOnly = true;
				DGMusclePower1.Rows[10].Cells[1].ReadOnly = true;
				DGMusclePower1.Rows[10].Cells[2].ReadOnly = true;
				DGMusclePower1.Rows[13].Cells[1].ReadOnly = true;
				DGMusclePower1.Rows[13].Cells[2].ReadOnly = true;
				DGMusclePower1.Rows[18].Cells[1].ReadOnly = true;
				DGMusclePower1.Rows[18].Cells[2].ReadOnly = true;
				DGMusclePower2.Rows.Clear();
				DGMusclePower2.Rows.Add("Hip", "", "");
				DGMusclePower2.Rows.Add("Flexors", "", "");
				DGMusclePower2.Rows.Add("Extensors", "", "");
				DGMusclePower2.Rows.Add("Abductors", "", "");
				DGMusclePower2.Rows.Add("Adductors", "", "");
				DGMusclePower2.Rows.Add("External Rotators", "", "");
				DGMusclePower2.Rows.Add("Internal Rotators", "", "");
				DGMusclePower2.Rows.Add("Knee", "", "");
				DGMusclePower2.Rows.Add("Flexors", "", "");
				DGMusclePower2.Rows.Add("Extensors", "", "");
				DGMusclePower2.Rows.Add("Ankle", "", "");
				DGMusclePower2.Rows.Add("Dorsiflexors", "", "");
				DGMusclePower2.Rows.Add("Plantarflexors", "", "");
				DGMusclePower2.Rows.Add("Foot", "", "");
				DGMusclePower2.Rows.Add("Invertors", "", "");
				DGMusclePower2.Rows.Add("Evertors", "", "");
				DGMusclePower2.Rows.Add("Intrinsics", "", "");
				DGMusclePower2.Rows.Add("Extrinsics", "", "");
				DGMusclePower2.Rows.Add("Trunk Flexors", "", "");
				DGMusclePower2.Rows.Add("Trunk Extensors", "", "");
				DGMusclePower2.Rows.Add("Trunk Side Flexors", "", "");
				DGMusclePower2.Rows.Add("Trunk Rotators", "", "");
				DGMusclePower2.Rows[0].Cells[1].ReadOnly = true;
				DGMusclePower2.Rows[0].Cells[2].ReadOnly = true;
				DGMusclePower2.Rows[7].Cells[1].ReadOnly = true;
				DGMusclePower2.Rows[7].Cells[2].ReadOnly = true;
				DGMusclePower2.Rows[10].Cells[1].ReadOnly = true;
				DGMusclePower2.Rows[10].Cells[2].ReadOnly = true;
				DGMusclePower2.Rows[13].Cells[1].ReadOnly = true;
				DGMusclePower2.Rows[13].Cells[2].ReadOnly = true;
			}
			else if (tabPage9.Focus())
			{
				DGReflexes.Rows.Clear();
				DGReflexes.Rows.Add("Abdominal", "", "");
				DGReflexes.Rows.Add("Plantar", "", "");
				DGReflexes.Rows.Add("Biceps", "", "");
				DGReflexes.Rows.Add("Brachioradialis", "", "");
				DGReflexes.Rows.Add("Triceps", "", "");
				DGReflexes.Rows.Add("Knee", "", "");
				DGReflexes.Rows.Add("Ankle", "", "");
				DGCoordination1.Rows.Clear();
				DGCoordination1.Rows.Add("Finger to nose", "", "");
				DGCoordination1.Rows.Add("Finger opposition", "", "");
				DGCoordination1.Rows.Add("Mass Grasp", "", "");
				DGCoordination1.Rows.Add("Pronation/Supination", "", "");
				DGCoordination1.Rows.Add("Rebound test", "", "");
				DGCoordination1.Rows.Add("Tapping (Hand) ", "", "");
				DGCoordination1.Rows.Add("Tapping (Foot) ", "", "");
				DGCoordination1.Rows.Add("Heel to knee", "", "");
				DGCoordination1.Rows.Add("Drawing a circle(Hand)", "", "");
				DGCoordination1.Rows.Add("Drawing a circle(Foot)", "", "");
				DGCoordination2.Rows.Clear();
				DGCoordination2.Rows.Add("Standing: Normal Posture", "", "");
				DGCoordination2.Rows.Add("Standing: Normal Posture with vision occluded", "", "");
				DGCoordination2.Rows.Add("Standing: Feet together", "", "");
				DGCoordination2.Rows.Add("Standing on one foot", "", "");
				DGCoordination2.Rows.Add("Standing: Lateral trunk flexion", "", "");
				DGCoordination2.Rows.Add("Tandem walking", "", "");
				DGCoordination2.Rows.Add("Walk: Sideways", "", "");
				DGCoordination2.Rows.Add("Walk: Backward", "", "");
				DGCoordination2.Rows.Add("Walk in a circle", "", "");
				DGCoordination2.Rows.Add("Walk on heels", "", "");
				DGCoordination2.Rows.Add("Walk on toes", "", "");
				Pathological.Text = "";
			}
			else if (tabPage10.Focus())
			{
				InvoluntaryMovements.Text = "";
				Balance.Text = "";
				Sitting.Text = "";
				Standing.Text = "";
				BalanceReactions.Text = "";
				Posturee.Text = "";
				Lying.Text = "";
				Sitting2.Text = "";
				Standing2.Text = "";
				StepLength.Text = "";
				StrideLength.Text = "";
				Basewidth.Text = "";
				Cadence.Text = "";
				BiomechanicalDeviations.Text = "";
				HandFunctions.Text = "";
				Reaching.Text = "";
				Grasping.Text = "";
				Releasing.Text = "";
				AssisstiveDevices.Text = "";
			}
			else if (tabPage11.Focus())
			{
				IntegSystem.Text = "";
				SkinStatus.Text = "";
				PressureSoress.Text = "";
				RESPIRATORYSYSTEM.Text = "";
				RSStatus.Text = "";
				Secretions.Text = "";
				Patternofbreathing.Text = "";
				spinedeformity.Text = "";
				CVSStatus.Text = "";
				Thrombosis.Text = "";
				Contractures.Text = "";
				Subluxations.Text = "";
				Jointmobility.Text = "";
				Otherpathology.Text = "";
				Incontinence.Text = "";
				Status.Text = "";
				Vasomotor.Text = "";
				Pseudomotor.Text = "";
				TrophicChanges.Text = "";
				PosturalHypotension.Text = "";
				ReflexSympatheticDystrophy.Text = "";
			}
			else if (tabPage12.Focus())
			{
				Evaluation1.Text = "";
				Item1.Text = "";
				Item2.Text = "";
				Item3.Text = "";
				Item4.Text = "";
				Item5.Text = "";
				Evaluation2.Text = "";
				Item6.Text = "";
				Item7.Text = "";
				Evaluation3.Text = "";
				Item8.Text = "";
				Item9.Text = "";
				Item10.Text = "";
				Evaluation4.Text = "";
				Item11.Text = "";
				Item12.Text = "";
				Evaluation5.Text = "";
				Item13.Text = "";
				Item14.Text = "";
				Evaluation6.Text = "";
				Item15.Text = "";
				Item16.Text = "";
				Item17.Text = "";
				InvestigationFindings.Text = "";
			}
			else if (tabPage13.Focus())
			{
				DGProblemList.Rows.Clear();
				DGProblemList.Rows.Add("", "", "");
				DGProblemList.Rows.Add("", "", "");
				DGProblemList.Rows.Add("", "", "");
				DGProblemList.Rows.Add("", "", "");
				DGProblemList.Rows.Add("", "", "");
				DGProblemList.Rows.Add("", "", "");
				FunctionalDiagnosis.Text = "";
				Goals.Text = "";
				Shortterm.Text = "";
				Longterm.Text = "";
			}
		}

		private void label91_Click(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.gender));
			groupBox4 = new System.Windows.Forms.GroupBox();
			this.label15 = new System.Windows.Forms.Label();
			tabControl1 = new System.Windows.Forms.TabControl();
			tabPage1 = new System.Windows.Forms.TabPage();
			Handedness = new System.Windows.Forms.TextBox();
			Sidee = new System.Windows.Forms.TextBox();
			Referredby = new System.Windows.Forms.TextBox();
			RelievingFactors = new System.Windows.Forms.TextBox();
			AggravatingFactors = new System.Windows.Forms.TextBox();
			Typee = new System.Windows.Forms.TextBox();
			SymptomsHistory = new System.Windows.Forms.TextBox();
			Onset = new System.Windows.Forms.TextBox();
			SocioeconomicHistory = new System.Windows.Forms.TextBox();
			Severity = new System.Windows.Forms.TextBox();
			Duration = new System.Windows.Forms.TextBox();
			Site = new System.Windows.Forms.TextBox();
			FamilyHistory = new System.Windows.Forms.TextBox();
			PersonalHistory = new System.Windows.Forms.TextBox();
			PastMedicalHistory = new System.Windows.Forms.TextBox();
			ChiefComplaints = new System.Windows.Forms.TextBox();
			Occupation = new System.Windows.Forms.TextBox();
			DGVitalSigns = new System.Windows.Forms.DataGridView();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			address = new System.Windows.Forms.TextBox();
			age = new FloatTextBox.FloatText();
			sex = new System.Windows.Forms.TextBox();
			IPOP = new System.Windows.Forms.TextBox();
			PatientName = new System.Windows.Forms.ComboBox();
			tabPage2 = new System.Windows.Forms.TabPage();
			Time = new System.Windows.Forms.TextBox();
			Place = new System.Windows.Forms.TextBox();
			Person = new System.Windows.Forms.TextBox();
			Orientation = new System.Windows.Forms.TextBox();
			Consciousness = new System.Windows.Forms.TextBox();
			Tenderness = new System.Windows.Forms.TextBox();
			Warmth = new System.Windows.Forms.TextBox();
			Tone = new System.Windows.Forms.TextBox();
			Swelling = new System.Windows.Forms.TextBox();
			ExternalAppliances = new System.Windows.Forms.TextBox();
			Wounds = new System.Windows.Forms.TextBox();
			Deformity = new System.Windows.Forms.TextBox();
			PressureSores = new System.Windows.Forms.TextBox();
			MuscleWasting = new System.Windows.Forms.TextBox();
			Oedema = new System.Windows.Forms.TextBox();
			Respiration = new System.Windows.Forms.TextBox();
			ModeofVentilation = new System.Windows.Forms.TextBox();
			PatternofMovement = new System.Windows.Forms.TextBox();
			Gait = new System.Windows.Forms.TextBox();
			Posture = new System.Windows.Forms.TextBox();
			Built = new System.Windows.Forms.TextBox();
			Attitudeoflimbs = new System.Windows.Forms.TextBox();
			tabPage3 = new System.Windows.Forms.TabPage();
			SpecialSenses = new System.Windows.Forms.TextBox();
			AgnosiasApraxias = new System.Windows.Forms.TextBox();
			Imaging = new System.Windows.Forms.TextBox();
			Perception = new System.Windows.Forms.TextBox();
			EmotionalStatus = new System.Windows.Forms.TextBox();
			Attention = new System.Windows.Forms.TextBox();
			ProverbInterpretation = new System.Windows.Forms.TextBox();
			Calculation = new System.Windows.Forms.TextBox();
			FundofKnowledge = new System.Windows.Forms.TextBox();
			Cognition = new System.Windows.Forms.TextBox();
			Communication = new System.Windows.Forms.TextBox();
			Visual = new System.Windows.Forms.TextBox();
			Verbal = new System.Windows.Forms.TextBox();
			Remote = new System.Windows.Forms.TextBox();
			Recent = new System.Windows.Forms.TextBox();
			Immediate = new System.Windows.Forms.TextBox();
			Memory = new System.Windows.Forms.TextBox();
			DGNerves = new System.Windows.Forms.DataGridView();
			Nerves = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Comments = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Nerves2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Comments2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			tabPage4 = new System.Windows.Forms.TabPage();
			MOTORSYSTEM = new System.Windows.Forms.TextBox();
			DGVoluntaryControl = new System.Windows.Forms.DataGridView();
			Sideee = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Rt_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Lt_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
			DGMuscleGirth = new System.Windows.Forms.DataGridView();
			Area = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Rt_cm = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Lt_cm = new System.Windows.Forms.DataGridViewTextBoxColumn();
			DGSENSORYSYS = new System.Windows.Forms.DataGridView();
			Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Rt1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Lt1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Rt22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Lt22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Rt3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Lt3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			notes = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			Location = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			tabPage5 = new System.Windows.Forms.TabPage();
			DGRangeofMotion = new System.Windows.Forms.DataGridView();
			Joint = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Side = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Movement = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Limitation = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Limitingfactor = new System.Windows.Forms.DataGridViewTextBoxColumn();
			tabPage6 = new System.Windows.Forms.TabPage();
			DGLimbLength = new System.Windows.Forms.DataGridView();
			dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			LimbRt = new System.Windows.Forms.DataGridViewTextBoxColumn();
			LimbLt = new System.Windows.Forms.DataGridViewTextBoxColumn();
			DGRangeofMotion2 = new System.Windows.Forms.DataGridView();
			dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Side2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Movement2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Limitation2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Limitingfactor2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			tabPage7 = new System.Windows.Forms.TabPage();
			DGMuscleTone2 = new System.Windows.Forms.DataGridView();
			dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			TRT2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			TLT2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			DGMuscleTone1 = new System.Windows.Forms.DataGridView();
			Muscles = new System.Windows.Forms.DataGridViewTextBoxColumn();
			TRT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			TLT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			tabPage8 = new System.Windows.Forms.TabPage();
			DGMusclePower2 = new System.Windows.Forms.DataGridView();
			dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			PRT2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			PLT2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			DGMusclePower1 = new System.Windows.Forms.DataGridView();
			dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			PRT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			PLT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			tabPage9 = new System.Windows.Forms.TabPage();
			Pathological = new System.Windows.Forms.TextBox();
			DGCoordination2 = new System.Windows.Forms.DataGridView();
			Equilibriumtests = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Grade = new System.Windows.Forms.DataGridViewTextBoxColumn();
			DGCoordination1 = new System.Windows.Forms.DataGridView();
			NonEquilibriumTests = new System.Windows.Forms.DataGridViewTextBoxColumn();
			RT2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			LT2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			DGReflexes = new System.Windows.Forms.DataGridView();
			Reflex = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Left = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Right = new System.Windows.Forms.DataGridViewTextBoxColumn();
			tabPage10 = new System.Windows.Forms.TabPage();
			Reaching = new System.Windows.Forms.TextBox();
			InvoluntaryMovements = new System.Windows.Forms.TextBox();
			AssisstiveDevices = new System.Windows.Forms.TextBox();
			BiomechanicalDeviations = new System.Windows.Forms.TextBox();
			HandFunctions = new System.Windows.Forms.TextBox();
			Grasping = new System.Windows.Forms.TextBox();
			Releasing = new System.Windows.Forms.TextBox();
			Sitting2 = new System.Windows.Forms.TextBox();
			Standing2 = new System.Windows.Forms.TextBox();
			StepLength = new System.Windows.Forms.TextBox();
			StrideLength = new System.Windows.Forms.TextBox();
			Basewidth = new System.Windows.Forms.TextBox();
			Cadence = new System.Windows.Forms.TextBox();
			Posturee = new System.Windows.Forms.TextBox();
			BalanceReactions = new System.Windows.Forms.TextBox();
			Lying = new System.Windows.Forms.TextBox();
			Standing = new System.Windows.Forms.TextBox();
			Sitting = new System.Windows.Forms.TextBox();
			Balance = new System.Windows.Forms.TextBox();
			tabPage11 = new System.Windows.Forms.TabPage();
			Thrombosis = new System.Windows.Forms.TextBox();
			CVSStatus = new System.Windows.Forms.TextBox();
			spinedeformity = new System.Windows.Forms.TextBox();
			Patternofbreathing = new System.Windows.Forms.TextBox();
			Secretions = new System.Windows.Forms.TextBox();
			RSStatus = new System.Windows.Forms.TextBox();
			RESPIRATORYSYSTEM = new System.Windows.Forms.TextBox();
			PressureSoress = new System.Windows.Forms.TextBox();
			IntegSystem = new System.Windows.Forms.TextBox();
			Status = new System.Windows.Forms.TextBox();
			Incontinence = new System.Windows.Forms.TextBox();
			ReflexSympatheticDystrophy = new System.Windows.Forms.TextBox();
			PosturalHypotension = new System.Windows.Forms.TextBox();
			TrophicChanges = new System.Windows.Forms.TextBox();
			Pseudomotor = new System.Windows.Forms.TextBox();
			Otherpathology = new System.Windows.Forms.TextBox();
			Jointmobility = new System.Windows.Forms.TextBox();
			Vasomotor = new System.Windows.Forms.TextBox();
			Subluxations = new System.Windows.Forms.TextBox();
			Contractures = new System.Windows.Forms.TextBox();
			SkinStatus = new System.Windows.Forms.TextBox();
			tabPage12 = new System.Windows.Forms.TabPage();
			InvestigationFindings = new System.Windows.Forms.TextBox();
			Item17 = new System.Windows.Forms.TextBox();
			Item16 = new System.Windows.Forms.TextBox();
			Item15 = new System.Windows.Forms.TextBox();
			Item10 = new System.Windows.Forms.TextBox();
			Item9 = new System.Windows.Forms.TextBox();
			Item8 = new System.Windows.Forms.TextBox();
			Item11 = new System.Windows.Forms.TextBox();
			Evaluation5 = new System.Windows.Forms.TextBox();
			Item13 = new System.Windows.Forms.TextBox();
			Item14 = new System.Windows.Forms.TextBox();
			Evaluation4 = new System.Windows.Forms.TextBox();
			Item2 = new System.Windows.Forms.TextBox();
			Item3 = new System.Windows.Forms.TextBox();
			Item5 = new System.Windows.Forms.TextBox();
			Evaluation2 = new System.Windows.Forms.TextBox();
			Item6 = new System.Windows.Forms.TextBox();
			Item7 = new System.Windows.Forms.TextBox();
			Evaluation3 = new System.Windows.Forms.TextBox();
			Evaluation6 = new System.Windows.Forms.TextBox();
			Item4 = new System.Windows.Forms.TextBox();
			Item12 = new System.Windows.Forms.TextBox();
			Item1 = new System.Windows.Forms.TextBox();
			Evaluation1 = new System.Windows.Forms.TextBox();
			tabPage13 = new System.Windows.Forms.TabPage();
			DGProblemList = new System.Windows.Forms.DataGridView();
			Sl = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Impairment = new System.Windows.Forms.DataGridViewTextBoxColumn();
			FunctionalLimitation = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Devicescomb = new System.Windows.Forms.ComboBox();
			Longterm = new System.Windows.Forms.TextBox();
			Goals = new System.Windows.Forms.TextBox();
			Shortterm = new System.Windows.Forms.TextBox();
			FunctionalDiagnosis = new System.Windows.Forms.TextBox();
			update = new System.Windows.Forms.Button();
			save = new System.Windows.Forms.Button();
			birthDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlDeleteCommand = new System.Data.SqlClient.SqlCommand();
			sqlInsertCommand = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection3 = new System.Data.SqlClient.SqlConnection();
			sqlCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlCommand5 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter4 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand6 = new System.Data.SqlClient.SqlCommand();
			sqlConnection4 = new System.Data.SqlClient.SqlConnection();
			sqlCommand7 = new System.Data.SqlClient.SqlCommand();
			sqlCommand8 = new System.Data.SqlClient.SqlCommand();
			sqlCommand9 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter5 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand10 = new System.Data.SqlClient.SqlCommand();
			sqlConnection5 = new System.Data.SqlClient.SqlConnection();
			sqlCommand11 = new System.Data.SqlClient.SqlCommand();
			sqlCommand12 = new System.Data.SqlClient.SqlCommand();
			sqlCommand13 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter6 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand14 = new System.Data.SqlClient.SqlCommand();
			sqlConnection6 = new System.Data.SqlClient.SqlConnection();
			sqlCommand15 = new System.Data.SqlClient.SqlCommand();
			sqlCommand16 = new System.Data.SqlClient.SqlCommand();
			sqlCommand17 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter7 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand18 = new System.Data.SqlClient.SqlCommand();
			sqlConnection7 = new System.Data.SqlClient.SqlConnection();
			sqlCommand19 = new System.Data.SqlClient.SqlCommand();
			sqlCommand20 = new System.Data.SqlClient.SqlCommand();
			sqlCommand21 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter8 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand22 = new System.Data.SqlClient.SqlCommand();
			sqlConnection8 = new System.Data.SqlClient.SqlConnection();
			sqlCommand23 = new System.Data.SqlClient.SqlCommand();
			sqlCommand24 = new System.Data.SqlClient.SqlCommand();
			sqlCommand25 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter9 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand26 = new System.Data.SqlClient.SqlCommand();
			sqlConnection9 = new System.Data.SqlClient.SqlConnection();
			sqlCommand27 = new System.Data.SqlClient.SqlCommand();
			sqlCommand28 = new System.Data.SqlClient.SqlCommand();
			sqlCommand29 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter10 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand30 = new System.Data.SqlClient.SqlCommand();
			sqlConnection10 = new System.Data.SqlClient.SqlConnection();
			sqlCommand31 = new System.Data.SqlClient.SqlCommand();
			sqlCommand32 = new System.Data.SqlClient.SqlCommand();
			sqlCommand33 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter11 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand34 = new System.Data.SqlClient.SqlCommand();
			sqlConnection11 = new System.Data.SqlClient.SqlConnection();
			sqlCommand35 = new System.Data.SqlClient.SqlCommand();
			sqlCommand36 = new System.Data.SqlClient.SqlCommand();
			sqlCommand37 = new System.Data.SqlClient.SqlCommand();
			dataSet11 = new DataSet1();
			Print = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label7 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label8 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label9 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label10 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label11 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label12 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label13 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label14 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label15 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label16 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label17 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label18 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label19 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label20 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label21 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label22 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label23 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label24 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label25 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label26 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label27 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label28 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label29 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label30 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label31 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label32 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label33 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label34 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label35 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label36 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label37 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label38 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label39 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label40 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label41 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label42 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label43 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label44 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label45 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label46 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label47 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label48 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label49 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label50 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label51 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label52 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label53 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label54 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label55 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label56 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label57 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label58 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label59 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label60 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label61 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label62 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label63 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label64 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label65 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label66 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label67 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label68 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label69 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label70 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label71 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label72 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label73 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label74 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label75 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label76 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label77 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label78 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label79 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label80 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label81 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label82 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label83 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label84 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label85 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label86 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label87 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label88 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label89 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label90 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label91 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label92 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label93 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label94 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label95 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label96 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label97 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label98 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label99 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label100 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label101 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label102 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label103 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label104 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label105 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label106 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label107 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label108 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label109 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label110 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label111 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label112 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label113 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label114 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label115 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label116 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label117 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label118 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label119 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label120 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label121 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label122 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label123 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label124 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label125 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label126 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label127 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label128 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label129 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label130 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label131 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label132 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label133 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label134 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label135 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label136 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label137 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label138 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label139 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label140 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label141 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label142 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label143 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label144 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label145 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label146 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label147 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label148 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label149 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label150 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label151 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label152 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label153 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label154 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label155 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label156 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label157 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label158 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label159 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label160 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label161 = new System.Windows.Forms.Label();
			groupBox4.SuspendLayout();
			tabControl1.SuspendLayout();
			tabPage1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)DGVitalSigns).BeginInit();
			tabPage2.SuspendLayout();
			tabPage3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)DGNerves).BeginInit();
			tabPage4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)DGVoluntaryControl).BeginInit();
			((System.ComponentModel.ISupportInitialize)DGMuscleGirth).BeginInit();
			((System.ComponentModel.ISupportInitialize)DGSENSORYSYS).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			tabPage5.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)DGRangeofMotion).BeginInit();
			tabPage6.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)DGLimbLength).BeginInit();
			((System.ComponentModel.ISupportInitialize)DGRangeofMotion2).BeginInit();
			tabPage7.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)DGMuscleTone2).BeginInit();
			((System.ComponentModel.ISupportInitialize)DGMuscleTone1).BeginInit();
			tabPage8.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)DGMusclePower2).BeginInit();
			((System.ComponentModel.ISupportInitialize)DGMusclePower1).BeginInit();
			tabPage9.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)DGCoordination2).BeginInit();
			((System.ComponentModel.ISupportInitialize)DGCoordination1).BeginInit();
			((System.ComponentModel.ISupportInitialize)DGReflexes).BeginInit();
			tabPage10.SuspendLayout();
			tabPage11.SuspendLayout();
			tabPage12.SuspendLayout();
			tabPage13.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)DGProblemList).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			label.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label.AutoSize = true;
			label.BackColor = System.Drawing.Color.Transparent;
			label.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label.Location = new System.Drawing.Point(65, 3);
			label.Name = "label1";
			label.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label.Size = new System.Drawing.Size(179, 19);
			label.TabIndex = 192;
			label.Text = "I. Subjective Assessment ";
			label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label2.AutoSize = true;
			label2.BackColor = System.Drawing.Color.Transparent;
			label2.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label2.Location = new System.Drawing.Point(379, 38);
			label2.Name = "label52";
			label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label2.Size = new System.Drawing.Size(41, 19);
			label2.TabIndex = 191;
			label2.Text = "Age:";
			label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label3.AutoSize = true;
			label3.BackColor = System.Drawing.Color.Transparent;
			label3.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label3.Location = new System.Drawing.Point(677, 35);
			label3.Name = "label48";
			label3.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label3.Size = new System.Drawing.Size(57, 19);
			label3.TabIndex = 189;
			label3.Text = "IP/OP :";
			label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label4.AutoSize = true;
			label4.BackColor = System.Drawing.Color.Transparent;
			label4.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label4.Location = new System.Drawing.Point(89, 38);
			label4.Name = "nameLabel";
			label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label4.Size = new System.Drawing.Size(54, 19);
			label4.TabIndex = 183;
			label4.Text = "Name:";
			label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label5.AutoSize = true;
			label5.BackColor = System.Drawing.Color.Transparent;
			label5.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label5.Location = new System.Drawing.Point(500, 38);
			label5.Name = "sexLabel";
			label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label5.Size = new System.Drawing.Size(97, 19);
			label5.TabIndex = 182;
			label5.Text = "Gender: M/F";
			label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label6.AutoSize = true;
			label6.BackColor = System.Drawing.Color.Transparent;
			label6.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label6.Location = new System.Drawing.Point(577, 73);
			label6.Name = "label2";
			label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label6.Size = new System.Drawing.Size(99, 19);
			label6.TabIndex = 194;
			label6.Text = "Referred by: ";
			label7.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label7.AutoSize = true;
			label7.BackColor = System.Drawing.Color.Transparent;
			label7.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label7.Location = new System.Drawing.Point(379, 71);
			label7.Name = "label3";
			label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label7.Size = new System.Drawing.Size(129, 19);
			label7.TabIndex = 195;
			label7.Text = "Handedness: R/L ";
			label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label8.AutoSize = true;
			label8.BackColor = System.Drawing.Color.Transparent;
			label8.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label8.Location = new System.Drawing.Point(91, 71);
			label8.Name = "label4";
			label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label8.Size = new System.Drawing.Size(93, 19);
			label8.TabIndex = 196;
			label8.Text = "Occupation: ";
			label9.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label9.AutoSize = true;
			label9.BackColor = System.Drawing.Color.Transparent;
			label9.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label9.Location = new System.Drawing.Point(577, 110);
			label9.Name = "label5";
			label9.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label9.Size = new System.Drawing.Size(133, 19);
			label9.TabIndex = 197;
			label9.Text = "Chief Complaints: ";
			label10.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label10.AutoSize = true;
			label10.BackColor = System.Drawing.Color.Transparent;
			label10.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label10.Location = new System.Drawing.Point(574, 189);
			label10.Name = "label6";
			label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label10.Size = new System.Drawing.Size(160, 19);
			label10.TabIndex = 198;
			label10.Text = "Past Medical History: ";
			label11.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label11.AutoSize = true;
			label11.BackColor = System.Drawing.Color.Transparent;
			label11.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label11.Location = new System.Drawing.Point(574, 273);
			label11.Name = "label7";
			label11.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label11.Size = new System.Drawing.Size(126, 19);
			label11.TabIndex = 199;
			label11.Text = "Personal History:";
			label12.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label12.AutoSize = true;
			label12.BackColor = System.Drawing.Color.Transparent;
			label12.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label12.Location = new System.Drawing.Point(94, 138);
			label12.Name = "label8";
			label12.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label12.Size = new System.Drawing.Size(113, 19);
			label12.TabIndex = 200;
			label12.Text = "Family History:";
			label13.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label13.AutoSize = true;
			label13.BackColor = System.Drawing.Color.Transparent;
			label13.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label13.Location = new System.Drawing.Point(92, 165);
			label13.Name = "label9";
			label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label13.Size = new System.Drawing.Size(170, 19);
			label13.TabIndex = 201;
			label13.Text = "Socioeconomic History: ";
			label14.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label14.AutoSize = true;
			label14.BackColor = System.Drawing.Color.Transparent;
			label14.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label14.Location = new System.Drawing.Point(92, 190);
			label14.Name = "label10";
			label14.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label14.Size = new System.Drawing.Size(141, 19);
			label14.TabIndex = 202;
			label14.Text = "Symptoms History: ";
			label15.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label15.AutoSize = true;
			label15.BackColor = System.Drawing.Color.Transparent;
			label15.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label15.Location = new System.Drawing.Point(89, 304);
			label15.Name = "label11";
			label15.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label15.Size = new System.Drawing.Size(51, 19);
			label15.TabIndex = 203;
			label15.Text = "Type: ";
			label16.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label16.AutoSize = true;
			label16.BackColor = System.Drawing.Color.Transparent;
			label16.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label16.Location = new System.Drawing.Point(310, 304);
			label16.Name = "label12";
			label16.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label16.Size = new System.Drawing.Size(74, 19);
			label16.TabIndex = 204;
			label16.Text = "Severity: ";
			label17.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label17.AutoSize = true;
			label17.BackColor = System.Drawing.Color.Transparent;
			label17.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label17.Location = new System.Drawing.Point(89, 271);
			label17.Name = "label13";
			label17.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label17.Size = new System.Drawing.Size(58, 19);
			label17.TabIndex = 205;
			label17.Text = "Onset: ";
			label18.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label18.AutoSize = true;
			label18.BackColor = System.Drawing.Color.Transparent;
			label18.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label18.Location = new System.Drawing.Point(310, 271);
			label18.Name = "label14";
			label18.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label18.Size = new System.Drawing.Size(77, 19);
			label18.TabIndex = 206;
			label18.Text = "Duration: ";
			label19.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label19.AutoSize = true;
			label19.BackColor = System.Drawing.Color.Transparent;
			label19.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label19.Location = new System.Drawing.Point(89, 233);
			label19.Name = "label16";
			label19.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label19.Size = new System.Drawing.Size(47, 19);
			label19.TabIndex = 207;
			label19.Text = "Side: ";
			label20.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label20.AutoSize = true;
			label20.BackColor = System.Drawing.Color.Transparent;
			label20.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label20.Location = new System.Drawing.Point(310, 233);
			label20.Name = "label17";
			label20.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label20.Size = new System.Drawing.Size(44, 19);
			label20.TabIndex = 208;
			label20.Text = "Site: ";
			label21.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label21.AutoSize = true;
			label21.BackColor = System.Drawing.Color.Transparent;
			label21.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label21.Location = new System.Drawing.Point(87, 339);
			label21.Name = "label18";
			label21.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label21.Size = new System.Drawing.Size(154, 19);
			label21.TabIndex = 209;
			label21.Text = "Aggravating Factors: ";
			label22.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label22.AutoSize = true;
			label22.BackColor = System.Drawing.Color.Transparent;
			label22.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label22.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label22.Location = new System.Drawing.Point(87, 377);
			label22.Name = "label19";
			label22.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label22.Size = new System.Drawing.Size(136, 19);
			label22.TabIndex = 210;
			label22.Text = "Relieving Factors: ";
			label23.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label23.AutoSize = true;
			label23.BackColor = System.Drawing.Color.Transparent;
			label23.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label23.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label23.Location = new System.Drawing.Point(118, 406);
			label23.Name = "label20";
			label23.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label23.Size = new System.Drawing.Size(89, 19);
			label23.TabIndex = 211;
			label23.Text = "Vital Signs: ";
			label24.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label24.AutoSize = true;
			label24.BackColor = System.Drawing.Color.Transparent;
			label24.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label24.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label24.Location = new System.Drawing.Point(52, 0);
			label24.Name = "label21";
			label24.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label24.Size = new System.Drawing.Size(184, 19);
			label24.TabIndex = 193;
			label24.Text = "II. Objective Examination ";
			label25.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label25.AutoSize = true;
			label25.BackColor = System.Drawing.Color.Transparent;
			label25.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label25.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label25.Location = new System.Drawing.Point(79, 30);
			label25.Name = "label22";
			label25.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label25.Size = new System.Drawing.Size(175, 19);
			label25.TabIndex = 194;
			label25.Text = "a) ON OBSERVATION: ";
			label26.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label26.AutoSize = true;
			label26.BackColor = System.Drawing.Color.Transparent;
			label26.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label26.Location = new System.Drawing.Point(113, 58);
			label26.Name = "label23";
			label26.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label26.Size = new System.Drawing.Size(128, 19);
			label26.TabIndex = 195;
			label26.Text = "Attitude of limbs: ";
			label27.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label27.AutoSize = true;
			label27.BackColor = System.Drawing.Color.Transparent;
			label27.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label27.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label27.Location = new System.Drawing.Point(113, 88);
			label27.Name = "label24";
			label27.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label27.Size = new System.Drawing.Size(50, 19);
			label27.TabIndex = 196;
			label27.Text = "Built: ";
			label28.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label28.AutoSize = true;
			label28.BackColor = System.Drawing.Color.Transparent;
			label28.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label28.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label28.Location = new System.Drawing.Point(556, 58);
			label28.Name = "label25";
			label28.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label28.Size = new System.Drawing.Size(69, 19);
			label28.TabIndex = 197;
			label28.Text = "Posture: ";
			label29.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label29.AutoSize = true;
			label29.BackColor = System.Drawing.Color.Transparent;
			label29.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label29.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label29.Location = new System.Drawing.Point(556, 87);
			label29.Name = "label26";
			label29.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label29.Size = new System.Drawing.Size(47, 19);
			label29.TabIndex = 198;
			label29.Text = "Gait: ";
			label30.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label30.AutoSize = true;
			label30.BackColor = System.Drawing.Color.Transparent;
			label30.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label30.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label30.Location = new System.Drawing.Point(113, 201);
			label30.Name = "label27";
			label30.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label30.Size = new System.Drawing.Size(161, 19);
			label30.TabIndex = 199;
			label30.Text = "Pattern of Movement: ";
			label31.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label31.AutoSize = true;
			label31.BackColor = System.Drawing.Color.Transparent;
			label31.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label31.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label31.Location = new System.Drawing.Point(113, 229);
			label31.Name = "label28";
			label31.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label31.Size = new System.Drawing.Size(151, 19);
			label31.TabIndex = 200;
			label31.Text = "Mode of Ventilation: ";
			label32.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label32.AutoSize = true;
			label32.BackColor = System.Drawing.Color.Transparent;
			label32.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label32.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label32.Location = new System.Drawing.Point(113, 254);
			label32.Name = "label29";
			label32.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label32.Size = new System.Drawing.Size(207, 19);
			label32.TabIndex = 201;
			label32.Text = "Type/ Pattern of Respiration: ";
			label33.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label33.AutoSize = true;
			label33.BackColor = System.Drawing.Color.Transparent;
			label33.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label33.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label33.Location = new System.Drawing.Point(556, 174);
			label33.Name = "label30";
			label33.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label33.Size = new System.Drawing.Size(74, 19);
			label33.TabIndex = 202;
			label33.Text = "Oedema: ";
			label34.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label34.AutoSize = true;
			label34.BackColor = System.Drawing.Color.Transparent;
			label34.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label34.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label34.Location = new System.Drawing.Point(113, 145);
			label34.Name = "label31";
			label34.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label34.Size = new System.Drawing.Size(126, 19);
			label34.TabIndex = 203;
			label34.Text = "Muscle Wasting: ";
			label35.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label35.AutoSize = true;
			label35.BackColor = System.Drawing.Color.Transparent;
			label35.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label35.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label35.Location = new System.Drawing.Point(113, 174);
			label35.Name = "label32";
			label35.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label35.Size = new System.Drawing.Size(119, 19);
			label35.TabIndex = 204;
			label35.Text = "Pressure Sores: ";
			label36.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label36.AutoSize = true;
			label36.BackColor = System.Drawing.Color.Transparent;
			label36.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label36.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label36.Location = new System.Drawing.Point(113, 116);
			label36.Name = "label33";
			label36.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label36.Size = new System.Drawing.Size(147, 19);
			label36.TabIndex = 205;
			label36.Text = "External Appliances:";
			label37.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label37.AutoSize = true;
			label37.BackColor = System.Drawing.Color.Transparent;
			label37.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label37.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label37.Location = new System.Drawing.Point(555, 116);
			label37.Name = "label34";
			label37.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label37.Size = new System.Drawing.Size(82, 19);
			label37.TabIndex = 205;
			label37.Text = "Deformity:";
			label38.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label38.AutoSize = true;
			label38.BackColor = System.Drawing.Color.Transparent;
			label38.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label38.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label38.Location = new System.Drawing.Point(556, 148);
			label38.Name = "label35";
			label38.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label38.Size = new System.Drawing.Size(71, 19);
			label38.TabIndex = 206;
			label38.Text = "Wounds: ";
			label39.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label39.AutoSize = true;
			label39.BackColor = System.Drawing.Color.Transparent;
			label39.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label39.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label39.Location = new System.Drawing.Point(79, 283);
			label39.Name = "label37";
			label39.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label39.Size = new System.Drawing.Size(145, 19);
			label39.TabIndex = 208;
			label39.Text = "b) ON PALPATION ";
			label40.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label40.AutoSize = true;
			label40.BackColor = System.Drawing.Color.Transparent;
			label40.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label40.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label40.Location = new System.Drawing.Point(556, 335);
			label40.Name = "label38";
			label40.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label40.Size = new System.Drawing.Size(73, 19);
			label40.TabIndex = 209;
			label40.Text = "Swelling: ";
			label41.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label41.AutoSize = true;
			label41.BackColor = System.Drawing.Color.Transparent;
			label41.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label41.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label41.Location = new System.Drawing.Point(556, 304);
			label41.Name = "label39";
			label41.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label41.Size = new System.Drawing.Size(51, 19);
			label41.TabIndex = 210;
			label41.Text = "Tone: ";
			label42.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label42.AutoSize = true;
			label42.BackColor = System.Drawing.Color.Transparent;
			label42.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label42.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label42.Location = new System.Drawing.Point(113, 334);
			label42.Name = "label40";
			label42.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label42.Size = new System.Drawing.Size(95, 19);
			label42.TabIndex = 211;
			label42.Text = "Tenderness: ";
			label43.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label43.AutoSize = true;
			label43.BackColor = System.Drawing.Color.Transparent;
			label43.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label43.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label43.Location = new System.Drawing.Point(113, 307);
			label43.Name = "label41";
			label43.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label43.Size = new System.Drawing.Size(71, 19);
			label43.TabIndex = 212;
			label43.Text = "Warmth: ";
			label44.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label44.AutoSize = true;
			label44.BackColor = System.Drawing.Color.Transparent;
			label44.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label44.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label44.Location = new System.Drawing.Point(72, 367);
			label44.Name = "label42";
			label44.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label44.Size = new System.Drawing.Size(169, 19);
			label44.TabIndex = 213;
			label44.Text = "c) ON EXAMINATION";
			label45.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label45.AutoSize = true;
			label45.BackColor = System.Drawing.Color.Transparent;
			label45.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label45.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label45.Location = new System.Drawing.Point(96, 392);
			label45.Name = "label43";
			label45.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label45.Size = new System.Drawing.Size(240, 19);
			label45.TabIndex = 214;
			label45.Text = "HIGHER MENTAL FUNCTIONS";
			label46.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label46.AutoSize = true;
			label46.BackColor = System.Drawing.Color.Transparent;
			label46.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label46.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label46.Location = new System.Drawing.Point(106, 419);
			label46.Name = "label44";
			label46.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label46.Size = new System.Drawing.Size(175, 19);
			label46.TabIndex = 215;
			label46.Text = "Level of Consciousness: ";
			label47.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label47.AutoSize = true;
			label47.BackColor = System.Drawing.Color.Transparent;
			label47.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label47.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label47.Location = new System.Drawing.Point(108, 448);
			label47.Name = "label45";
			label47.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label47.Size = new System.Drawing.Size(94, 19);
			label47.TabIndex = 216;
			label47.Text = "Orientation: ";
			label48.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label48.AutoSize = true;
			label48.BackColor = System.Drawing.Color.Transparent;
			label48.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label48.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label48.Location = new System.Drawing.Point(571, 476);
			label48.Name = "label46";
			label48.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label48.Size = new System.Drawing.Size(52, 19);
			label48.TabIndex = 217;
			label48.Text = "Time: ";
			label49.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label49.AutoSize = true;
			label49.BackColor = System.Drawing.Color.Transparent;
			label49.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label49.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label49.Location = new System.Drawing.Point(571, 448);
			label49.Name = "label47";
			label49.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label49.Size = new System.Drawing.Size(54, 19);
			label49.TabIndex = 218;
			label49.Text = "Place: ";
			label50.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label50.AutoSize = true;
			label50.BackColor = System.Drawing.Color.Transparent;
			label50.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label50.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label50.Location = new System.Drawing.Point(563, 418);
			label50.Name = "label49";
			label50.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label50.Size = new System.Drawing.Size(64, 19);
			label50.TabIndex = 219;
			label50.Text = "Person: ";
			label51.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label51.AutoSize = true;
			label51.BackColor = System.Drawing.Color.Transparent;
			label51.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label51.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label51.Location = new System.Drawing.Point(538, 284);
			label51.Name = "label36";
			label51.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label51.Size = new System.Drawing.Size(117, 19);
			label51.TabIndex = 230;
			label51.Text = "Special Senses: ";
			label52.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label52.AutoSize = true;
			label52.BackColor = System.Drawing.Color.Transparent;
			label52.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label52.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label52.Location = new System.Drawing.Point(75, 354);
			label52.Name = "label50";
			label52.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label52.Size = new System.Drawing.Size(120, 19);
			label52.TabIndex = 229;
			label52.Text = "Cranial Nerves: ";
			label53.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label53.AutoSize = true;
			label53.BackColor = System.Drawing.Color.Transparent;
			label53.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label53.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label53.Location = new System.Drawing.Point(70, 320);
			label53.Name = "label53";
			label53.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label53.Size = new System.Drawing.Size(146, 19);
			label53.TabIndex = 228;
			label53.Text = "Agnosias/ Apraxias: ";
			label54.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label54.AutoSize = true;
			label54.BackColor = System.Drawing.Color.Transparent;
			label54.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label54.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label54.Location = new System.Drawing.Point(540, 256);
			label54.Name = "label54";
			label54.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label54.Size = new System.Drawing.Size(89, 19);
			label54.TabIndex = 227;
			label54.Text = "Perception: ";
			label55.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label55.AutoSize = true;
			label55.BackColor = System.Drawing.Color.Transparent;
			label55.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label55.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label55.Location = new System.Drawing.Point(540, 232);
			label55.Name = "label55";
			label55.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label55.Size = new System.Drawing.Size(131, 19);
			label55.TabIndex = 225;
			label55.Text = "Emotional Status: ";
			label56.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label56.AutoSize = true;
			label56.BackColor = System.Drawing.Color.Transparent;
			label56.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label56.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label56.Location = new System.Drawing.Point(10, 285);
			label56.Name = "label56";
			label56.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label56.Size = new System.Drawing.Size(210, 19);
			label56.TabIndex = 226;
			label56.Text = "Body Scheme/ Body Imaging: ";
			label57.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label57.AutoSize = true;
			label57.BackColor = System.Drawing.Color.Transparent;
			label57.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label57.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label57.Location = new System.Drawing.Point(540, 193);
			label57.Name = "label57";
			label57.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label57.Size = new System.Drawing.Size(80, 19);
			label57.TabIndex = 224;
			label57.Text = "Attention: ";
			label58.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label58.AutoSize = true;
			label58.BackColor = System.Drawing.Color.Transparent;
			label58.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label58.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label58.Location = new System.Drawing.Point(48, 255);
			label58.Name = "label58";
			label58.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label58.Size = new System.Drawing.Size(168, 19);
			label58.TabIndex = 223;
			label58.Text = "Proverb Interpretation: ";
			label59.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label59.AutoSize = true;
			label59.BackColor = System.Drawing.Color.Transparent;
			label59.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label59.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label59.Location = new System.Drawing.Point(70, 228);
			label59.Name = "label59";
			label59.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label59.Size = new System.Drawing.Size(93, 19);
			label59.TabIndex = 222;
			label59.Text = "Calculation: ";
			label60.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label60.AutoSize = true;
			label60.BackColor = System.Drawing.Color.Transparent;
			label60.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label60.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label60.Location = new System.Drawing.Point(70, 193);
			label60.Name = "label60";
			label60.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label60.Size = new System.Drawing.Size(146, 19);
			label60.TabIndex = 221;
			label60.Text = "Fund of Knowledge: ";
			label61.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label61.AutoSize = true;
			label61.BackColor = System.Drawing.Color.Transparent;
			label61.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label61.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label61.Location = new System.Drawing.Point(59, 161);
			label61.Name = "label61";
			label61.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label61.Size = new System.Drawing.Size(82, 19);
			label61.TabIndex = 220;
			label61.Text = "Cognition: ";
			label62.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label62.AutoSize = true;
			label62.BackColor = System.Drawing.Color.Transparent;
			label62.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label62.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label62.Location = new System.Drawing.Point(33, 132);
			label62.Name = "label62";
			label62.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label62.Size = new System.Drawing.Size(121, 19);
			label62.TabIndex = 219;
			label62.Text = "Communication: ";
			label63.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label63.AutoSize = true;
			label63.BackColor = System.Drawing.Color.Transparent;
			label63.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label63.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label63.Location = new System.Drawing.Point(538, 73);
			label63.Name = "label63";
			label63.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label63.Size = new System.Drawing.Size(59, 19);
			label63.TabIndex = 218;
			label63.Text = "Visual: ";
			label64.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label64.AutoSize = true;
			label64.BackColor = System.Drawing.Color.Transparent;
			label64.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label64.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label64.Location = new System.Drawing.Point(538, 47);
			label64.Name = "label64";
			label64.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label64.Size = new System.Drawing.Size(62, 19);
			label64.TabIndex = 217;
			label64.Text = "Verbal: ";
			label65.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label65.AutoSize = true;
			label65.BackColor = System.Drawing.Color.Transparent;
			label65.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label65.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label65.Location = new System.Drawing.Point(75, 97);
			label65.Name = "label65";
			label65.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label65.Size = new System.Drawing.Size(71, 19);
			label65.TabIndex = 216;
			label65.Text = "Remote: ";
			label66.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label66.AutoSize = true;
			label66.BackColor = System.Drawing.Color.Transparent;
			label66.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label66.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label66.Location = new System.Drawing.Point(75, 74);
			label66.Name = "label66";
			label66.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label66.Size = new System.Drawing.Size(66, 19);
			label66.TabIndex = 215;
			label66.Text = "Recent: ";
			label67.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label67.AutoSize = true;
			label67.BackColor = System.Drawing.Color.Transparent;
			label67.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label67.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label67.Location = new System.Drawing.Point(75, 47);
			label67.Name = "label67";
			label67.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label67.Size = new System.Drawing.Size(89, 19);
			label67.TabIndex = 214;
			label67.Text = "Immediate: ";
			label68.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label68.AutoSize = true;
			label68.BackColor = System.Drawing.Color.Transparent;
			label68.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label68.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label68.Location = new System.Drawing.Point(33, 15);
			label68.Name = "label68";
			label68.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label68.Size = new System.Drawing.Size(76, 19);
			label68.TabIndex = 213;
			label68.Text = "Memory: ";
			label69.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label69.AutoSize = true;
			label69.BackColor = System.Drawing.Color.Transparent;
			label69.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label69.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label69.Location = new System.Drawing.Point(68, 350);
			label69.Name = "label70";
			label69.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label69.Size = new System.Drawing.Size(99, 19);
			label69.TabIndex = 217;
			label69.Text = "Limb Length:";
			label70.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label70.AutoSize = true;
			label70.BackColor = System.Drawing.Color.Transparent;
			label70.Font = new System.Drawing.Font("Times New Roman", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label70.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label70.Location = new System.Drawing.Point(68, 18);
			label70.Name = "label71";
			label70.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label70.Size = new System.Drawing.Size(124, 22);
			label70.TabIndex = 218;
			label70.Text = "Muscle Tone: ";
			label71.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label71.AutoSize = true;
			label71.BackColor = System.Drawing.Color.Transparent;
			label71.Font = new System.Drawing.Font("Times New Roman", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label71.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label71.Location = new System.Drawing.Point(76, 26);
			label71.Name = "label72";
			label71.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label71.Size = new System.Drawing.Size(137, 22);
			label71.TabIndex = 221;
			label71.Text = "Muscle Power: ";
			label72.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label72.AutoSize = true;
			label72.BackColor = System.Drawing.Color.Transparent;
			label72.Font = new System.Drawing.Font("Times New Roman", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label72.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label72.Location = new System.Drawing.Point(92, 23);
			label72.Name = "label73";
			label72.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label72.Size = new System.Drawing.Size(89, 22);
			label72.TabIndex = 224;
			label72.Text = "Reflexes: ";
			label73.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label73.AutoSize = true;
			label73.BackColor = System.Drawing.Color.Transparent;
			label73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			label73.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label73.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label73.Location = new System.Drawing.Point(149, 72);
			label73.Name = "label74";
			label73.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label73.Size = new System.Drawing.Size(82, 21);
			label73.TabIndex = 227;
			label73.Text = "Superficial";
			label74.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label74.AutoSize = true;
			label74.BackColor = System.Drawing.Color.Transparent;
			label74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			label74.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label74.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label74.Location = new System.Drawing.Point(184, 118);
			label74.Name = "label75";
			label74.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label74.Size = new System.Drawing.Size(47, 21);
			label74.TabIndex = 228;
			label74.Text = "Deep";
			label75.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label75.AutoSize = true;
			label75.BackColor = System.Drawing.Color.Transparent;
			label75.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label75.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label75.Location = new System.Drawing.Point(167, 245);
			label75.Name = "label76";
			label75.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label75.Size = new System.Drawing.Size(99, 19);
			label75.TabIndex = 229;
			label75.Text = "Pathological: ";
			label76.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label76.AutoSize = true;
			label76.BackColor = System.Drawing.Color.Transparent;
			label76.Font = new System.Drawing.Font("Times New Roman", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label76.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label76.Location = new System.Drawing.Point(78, 289);
			label76.Name = "label77";
			label76.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label76.Size = new System.Drawing.Size(123, 22);
			label76.TabIndex = 230;
			label76.Text = "Coordination:";
			label77.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label77.AutoSize = true;
			label77.BackColor = System.Drawing.Color.Transparent;
			label77.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label77.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label77.Location = new System.Drawing.Point(143, 473);
			label77.Name = "label80";
			label77.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label77.Size = new System.Drawing.Size(81, 19);
			label77.TabIndex = 234;
			label77.Text = "Reaching: ";
			label78.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label78.AutoSize = true;
			label78.BackColor = System.Drawing.Color.Transparent;
			label78.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label78.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label78.Location = new System.Drawing.Point(143, 501);
			label78.Name = "label81";
			label78.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label78.Size = new System.Drawing.Size(79, 19);
			label78.TabIndex = 233;
			label78.Text = "Grasping: ";
			label79.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label79.AutoSize = true;
			label79.BackColor = System.Drawing.Color.Transparent;
			label79.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label79.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label79.Location = new System.Drawing.Point(586, 469);
			label79.Name = "label82";
			label79.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label79.Size = new System.Drawing.Size(85, 19);
			label79.TabIndex = 232;
			label79.Text = "Releasing: ";
			label80.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label80.AutoSize = true;
			label80.BackColor = System.Drawing.Color.Transparent;
			label80.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label80.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label80.Location = new System.Drawing.Point(527, 501);
			label80.Name = "label83";
			label80.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label80.Size = new System.Drawing.Size(144, 19);
			label80.TabIndex = 231;
			label80.Text = "Assisstive Devices: ";
			label81.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label81.AutoSize = true;
			label81.BackColor = System.Drawing.Color.Transparent;
			label81.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label81.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label81.Location = new System.Drawing.Point(97, 441);
			label81.Name = "label84";
			label81.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label81.Size = new System.Drawing.Size(122, 19);
			label81.TabIndex = 230;
			label81.Text = "Hand Functions: ";
			label82.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label82.AutoSize = true;
			label82.BackColor = System.Drawing.Color.Transparent;
			label82.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label82.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label82.Location = new System.Drawing.Point(595, 339);
			label82.Name = "label85";
			label82.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label82.Size = new System.Drawing.Size(76, 19);
			label82.TabIndex = 229;
			label82.Text = "Cadence: ";
			label83.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label83.AutoSize = true;
			label83.BackColor = System.Drawing.Color.Transparent;
			label83.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label83.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label83.Location = new System.Drawing.Point(143, 404);
			label83.Name = "label86";
			label83.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label83.Size = new System.Drawing.Size(91, 19);
			label83.TabIndex = 227;
			label83.Text = "Base width: ";
			label84.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label84.AutoSize = true;
			label84.BackColor = System.Drawing.Color.Transparent;
			label84.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label84.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label84.Location = new System.Drawing.Point(484, 373);
			label84.Name = "label87";
			label84.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label84.Size = new System.Drawing.Size(187, 19);
			label84.TabIndex = 228;
			label84.Text = "Biomechanical Deviations:";
			label85.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label85.AutoSize = true;
			label85.BackColor = System.Drawing.Color.Transparent;
			label85.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label85.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label85.Location = new System.Drawing.Point(143, 373);
			label85.Name = "label88";
			label85.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label85.Size = new System.Drawing.Size(109, 19);
			label85.TabIndex = 226;
			label85.Text = "Stride Length: ";
			label86.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label86.AutoSize = true;
			label86.BackColor = System.Drawing.Color.Transparent;
			label86.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label86.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label86.Location = new System.Drawing.Point(143, 342);
			label86.Name = "label89";
			label86.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label86.Size = new System.Drawing.Size(99, 19);
			label86.TabIndex = 225;
			label86.Text = "Step Length: ";
			label87.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label87.AutoSize = true;
			label87.BackColor = System.Drawing.Color.Transparent;
			label87.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label87.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label87.Location = new System.Drawing.Point(121, 312);
			label87.Name = "label90";
			label87.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label87.Size = new System.Drawing.Size(42, 19);
			label87.TabIndex = 224;
			label87.Text = "Gait ";
			label88.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label88.AutoSize = true;
			label88.BackColor = System.Drawing.Color.Transparent;
			label88.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label88.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label88.Location = new System.Drawing.Point(595, 238);
			label88.Name = "label91";
			label88.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label88.Size = new System.Drawing.Size(76, 19);
			label88.TabIndex = 223;
			label88.Text = "Standing: ";
			label88.Click += new System.EventHandler(label91_Click);
			label89.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label89.AutoSize = true;
			label89.BackColor = System.Drawing.Color.Transparent;
			label89.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label89.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label89.Location = new System.Drawing.Point(144, 273);
			label89.Name = "label92";
			label89.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label89.Size = new System.Drawing.Size(61, 19);
			label89.TabIndex = 222;
			label89.Text = "Sitting: ";
			label90.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label90.AutoSize = true;
			label90.BackColor = System.Drawing.Color.Transparent;
			label90.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label90.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label90.Location = new System.Drawing.Point(144, 242);
			label90.Name = "label93";
			label90.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label90.Size = new System.Drawing.Size(55, 19);
			label90.TabIndex = 221;
			label90.Text = "Lying: ";
			label91.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label91.AutoSize = true;
			label91.BackColor = System.Drawing.Color.Transparent;
			label91.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label91.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label91.Location = new System.Drawing.Point(124, 210);
			label91.Name = "label94";
			label91.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label91.Size = new System.Drawing.Size(69, 19);
			label91.TabIndex = 220;
			label91.Text = "Posture: ";
			label92.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label92.AutoSize = true;
			label92.BackColor = System.Drawing.Color.Transparent;
			label92.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label92.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label92.Location = new System.Drawing.Point(143, 169);
			label92.Name = "label95";
			label92.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label92.Size = new System.Drawing.Size(143, 19);
			label92.TabIndex = 219;
			label92.Text = "Balance Reactions: ";
			label93.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label93.AutoSize = true;
			label93.BackColor = System.Drawing.Color.Transparent;
			label93.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label93.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label93.Location = new System.Drawing.Point(139, 140);
			label93.Name = "label96";
			label93.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label93.Size = new System.Drawing.Size(76, 19);
			label93.TabIndex = 218;
			label93.Text = "Standing: ";
			label94.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label94.AutoSize = true;
			label94.BackColor = System.Drawing.Color.Transparent;
			label94.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label94.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label94.Location = new System.Drawing.Point(141, 112);
			label94.Name = "label97";
			label94.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label94.Size = new System.Drawing.Size(61, 19);
			label94.TabIndex = 217;
			label94.Text = "Sitting: ";
			label95.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label95.AutoSize = true;
			label95.BackColor = System.Drawing.Color.Transparent;
			label95.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label95.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label95.Location = new System.Drawing.Point(121, 80);
			label95.Name = "label98";
			label95.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label95.Size = new System.Drawing.Size(72, 19);
			label95.TabIndex = 216;
			label95.Text = "Balance: ";
			label96.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label96.AutoSize = true;
			label96.BackColor = System.Drawing.Color.Transparent;
			label96.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label96.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label96.Location = new System.Drawing.Point(121, 21);
			label96.Name = "label99";
			label96.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label96.Size = new System.Drawing.Size(179, 19);
			label96.TabIndex = 215;
			label96.Text = "Involuntary Movements: ";
			label97.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label97.AutoSize = true;
			label97.BackColor = System.Drawing.Color.Transparent;
			label97.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label97.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label97.Location = new System.Drawing.Point(569, 295);
			label97.Name = "label78";
			label97.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label97.Size = new System.Drawing.Size(122, 19);
			label97.TabIndex = 254;
			label97.Text = "Other pathology:";
			label98.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label98.AutoSize = true;
			label98.BackColor = System.Drawing.Color.Transparent;
			label98.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label98.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label98.Location = new System.Drawing.Point(31, 327);
			label98.Name = "label79";
			label98.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label98.Size = new System.Drawing.Size(261, 19);
			label98.TabIndex = 253;
			label98.Text = "- BLADDER & BOWEL FUNCTIONS ";
			label99.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label99.AutoSize = true;
			label99.BackColor = System.Drawing.Color.Transparent;
			label99.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label99.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label99.Location = new System.Drawing.Point(302, 327);
			label99.Name = "label100";
			label99.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label99.Size = new System.Drawing.Size(103, 19);
			label99.TabIndex = 252;
			label99.Text = "Incontinence: ";
			label100.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label100.AutoSize = true;
			label100.BackColor = System.Drawing.Color.Transparent;
			label100.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label100.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label100.Location = new System.Drawing.Point(31, 358);
			label100.Name = "label101";
			label100.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label100.Size = new System.Drawing.Size(251, 19);
			label100.TabIndex = 251;
			label100.Text = "- GASTROINTESTINAL SYSTEM ";
			label101.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label101.AutoSize = true;
			label101.BackColor = System.Drawing.Color.Transparent;
			label101.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label101.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label101.Location = new System.Drawing.Point(583, 270);
			label101.Name = "label102";
			label101.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label101.Size = new System.Drawing.Size(108, 19);
			label101.TabIndex = 250;
			label101.Text = "Joint mobility: ";
			label102.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label102.AutoSize = true;
			label102.BackColor = System.Drawing.Color.Transparent;
			label102.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label102.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label102.Location = new System.Drawing.Point(120, 270);
			label102.Name = "label103";
			label102.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label102.Size = new System.Drawing.Size(105, 19);
			label102.TabIndex = 249;
			label102.Text = "Contractures: ";
			label103.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label103.AutoSize = true;
			label103.BackColor = System.Drawing.Color.Transparent;
			label103.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label103.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label103.Location = new System.Drawing.Point(31, 241);
			label103.Name = "label104";
			label103.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label103.Size = new System.Drawing.Size(250, 19);
			label103.TabIndex = 247;
			label103.Text = "- MUSCULOSKELETAL SYSTEM ";
			label104.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label104.AutoSize = true;
			label104.BackColor = System.Drawing.Color.Transparent;
			label104.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label104.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label104.Location = new System.Drawing.Point(122, 293);
			label104.Name = "label105";
			label104.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label104.Size = new System.Drawing.Size(103, 19);
			label104.TabIndex = 248;
			label104.Text = "Subluxations: ";
			label105.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label105.AutoSize = true;
			label105.BackColor = System.Drawing.Color.Transparent;
			label105.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label105.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label105.Location = new System.Drawing.Point(544, 211);
			label105.Name = "label106";
			label105.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label105.Size = new System.Drawing.Size(174, 19);
			label105.TabIndex = 246;
			label105.Text = " Deep Vein Thrombosis: ";
			label106.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label106.AutoSize = true;
			label106.BackColor = System.Drawing.Color.Transparent;
			label106.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label106.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label106.Location = new System.Drawing.Point(132, 212);
			label106.Name = "label107";
			label106.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label106.Size = new System.Drawing.Size(95, 19);
			label106.TabIndex = 245;
			label106.Text = "CVS Status: ";
			label107.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label107.AutoSize = true;
			label107.BackColor = System.Drawing.Color.Transparent;
			label107.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label107.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label107.Location = new System.Drawing.Point(31, 187);
			label107.Name = "label108";
			label107.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label107.Size = new System.Drawing.Size(238, 19);
			label107.TabIndex = 244;
			label107.Text = "- CARDIOVASCULAR SYSTEM ";
			label108.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label108.BackColor = System.Drawing.Color.Transparent;
			label108.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label108.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label108.Location = new System.Drawing.Point(474, 155);
			label108.Name = "label109";
			label108.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label108.Size = new System.Drawing.Size(256, 19);
			label108.TabIndex = 243;
			label108.Text = "Chest wall/Thoracic spine deformity: ";
			label109.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label109.AutoSize = true;
			label109.BackColor = System.Drawing.Color.Transparent;
			label109.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label109.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label109.Location = new System.Drawing.Point(548, 132);
			label109.Name = "label110";
			label109.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label109.Size = new System.Drawing.Size(151, 19);
			label109.TabIndex = 242;
			label109.Text = "Pattern of breathing: ";
			label110.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label110.AutoSize = true;
			label110.BackColor = System.Drawing.Color.Transparent;
			label110.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label110.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label110.Location = new System.Drawing.Point(126, 159);
			label110.Name = "label111";
			label110.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label110.Size = new System.Drawing.Size(88, 19);
			label110.TabIndex = 241;
			label110.Text = "Secretions: ";
			label111.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label111.AutoSize = true;
			label111.BackColor = System.Drawing.Color.Transparent;
			label111.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label111.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label111.Location = new System.Drawing.Point(126, 135);
			label111.Name = "label112";
			label111.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label111.Size = new System.Drawing.Size(85, 19);
			label111.TabIndex = 240;
			label111.Text = "RS Status: ";
			label112.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label112.AutoSize = true;
			label112.BackColor = System.Drawing.Color.Transparent;
			label112.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label112.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label112.Location = new System.Drawing.Point(39, 107);
			label112.Name = "label113";
			label112.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label112.Size = new System.Drawing.Size(205, 19);
			label112.TabIndex = 239;
			label112.Text = "- RESPIRATORY SYSTEM: ";
			label113.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label113.AutoSize = true;
			label113.BackColor = System.Drawing.Color.Transparent;
			label113.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label113.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label113.Location = new System.Drawing.Point(580, 64);
			label113.Name = "label114";
			label113.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label113.Size = new System.Drawing.Size(119, 19);
			label113.TabIndex = 238;
			label113.Text = "Pressure Sores: ";
			label114.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label114.AutoSize = true;
			label114.BackColor = System.Drawing.Color.Transparent;
			label114.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label114.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label114.Location = new System.Drawing.Point(126, 66);
			label114.Name = "label115";
			label114.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label114.Size = new System.Drawing.Size(94, 19);
			label114.TabIndex = 237;
			label114.Text = "Skin Status: ";
			label115.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label115.AutoSize = true;
			label115.BackColor = System.Drawing.Color.Transparent;
			label115.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label115.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label115.Location = new System.Drawing.Point(35, 37);
			label115.Name = "label116";
			label115.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label115.Size = new System.Drawing.Size(234, 19);
			label115.TabIndex = 236;
			label115.Text = "- INTEGUMENTARY SYSTEM: ";
			label116.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label116.AutoSize = true;
			label116.BackColor = System.Drawing.Color.Transparent;
			label116.Font = new System.Drawing.Font("Times New Roman", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label116.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label116.Location = new System.Drawing.Point(13, 6);
			label116.Name = "label117";
			label116.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label116.Size = new System.Drawing.Size(182, 22);
			label116.TabIndex = 235;
			label116.Text = "III. Systems Review: ";
			label117.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label117.AutoSize = true;
			label117.BackColor = System.Drawing.Color.Transparent;
			label117.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label117.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label117.Location = new System.Drawing.Point(294, 358);
			label117.Name = "label118";
			label117.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label117.Size = new System.Drawing.Size(60, 19);
			label117.TabIndex = 255;
			label117.Text = "Status: ";
			label118.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label118.AutoSize = true;
			label118.BackColor = System.Drawing.Color.Transparent;
			label118.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label118.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label118.Location = new System.Drawing.Point(35, 390);
			label118.Name = "label119";
			label118.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label118.Size = new System.Drawing.Size(190, 19);
			label118.TabIndex = 256;
			label118.Text = "- AUTONOMIC SYSTEM ";
			label119.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label119.AutoSize = true;
			label119.BackColor = System.Drawing.Color.Transparent;
			label119.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label119.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label119.Location = new System.Drawing.Point(464, 436);
			label119.Name = "label120";
			label119.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label119.Size = new System.Drawing.Size(223, 19);
			label119.TabIndex = 257;
			label119.Text = "Reflex Sympathetic Dystrophy: ";
			label120.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label120.AutoSize = true;
			label120.BackColor = System.Drawing.Color.Transparent;
			label120.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label120.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label120.Location = new System.Drawing.Point(125, 466);
			label120.Name = "label121";
			label120.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label120.Size = new System.Drawing.Size(130, 19);
			label120.TabIndex = 258;
			label120.Text = "Trophic Changes: ";
			label121.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label121.AutoSize = true;
			label121.BackColor = System.Drawing.Color.Transparent;
			label121.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label121.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label121.Location = new System.Drawing.Point(125, 438);
			label121.Name = "label122";
			label121.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label121.Size = new System.Drawing.Size(105, 19);
			label121.TabIndex = 259;
			label121.Text = "Pseudomotor: ";
			label122.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label122.AutoSize = true;
			label122.BackColor = System.Drawing.Color.Transparent;
			label122.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label122.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label122.Location = new System.Drawing.Point(526, 410);
			label122.Name = "label123";
			label122.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label122.Size = new System.Drawing.Size(161, 19);
			label122.TabIndex = 260;
			label122.Text = "Postural Hypotension: ";
			label123.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label123.AutoSize = true;
			label123.BackColor = System.Drawing.Color.Transparent;
			label123.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label123.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label123.Location = new System.Drawing.Point(125, 413);
			label123.Name = "label124";
			label123.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label123.Size = new System.Drawing.Size(90, 19);
			label123.TabIndex = 261;
			label123.Text = "Vasomotor: ";
			label124.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label124.AutoSize = true;
			label124.BackColor = System.Drawing.Color.Transparent;
			label124.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label124.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label124.Location = new System.Drawing.Point(186, 448);
			label124.Name = "label125";
			label124.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label124.Size = new System.Drawing.Size(251, 19);
			label124.TabIndex = 288;
			label124.Text = "Item 16. Resolution of the problems ";
			label125.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label125.AutoSize = true;
			label125.BackColor = System.Drawing.Color.Transparent;
			label125.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label125.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label125.Location = new System.Drawing.Point(186, 474);
			label125.Name = "label127";
			label125.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label125.Size = new System.Drawing.Size(130, 19);
			label125.TabIndex = 286;
			label125.Text = "Item 17. Memory ";
			label126.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label126.AutoSize = true;
			label126.BackColor = System.Drawing.Color.Transparent;
			label126.Font = new System.Drawing.Font("Times New Roman", 12.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label126.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label126.Location = new System.Drawing.Point(53, 516);
			label126.Name = "label128";
			label126.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label126.Size = new System.Drawing.Size(186, 19);
			label126.TabIndex = 285;
			label126.Text = "Investigation Findings: ";
			label127.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label127.AutoSize = true;
			label127.BackColor = System.Drawing.Color.Transparent;
			label127.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label127.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label127.Location = new System.Drawing.Point(46, 422);
			label127.Name = "label130";
			label127.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label127.Size = new System.Drawing.Size(393, 19);
			label127.TabIndex = 283;
			label127.Text = "Item 15. Capacity to interact and to socially communicate ";
			label128.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label128.AutoSize = true;
			label128.BackColor = System.Drawing.Color.Transparent;
			label128.Font = new System.Drawing.Font("Times New Roman", 12.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label128.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label128.Location = new System.Drawing.Point(46, 399);
			label128.Name = "label131";
			label128.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label128.Size = new System.Drawing.Size(341, 19);
			label128.TabIndex = 282;
			label128.Text = "Evaluation 6: Social adjustment/cooperation ";
			label129.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label129.AutoSize = true;
			label129.BackColor = System.Drawing.Color.Transparent;
			label129.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label129.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label129.Location = new System.Drawing.Point(550, 252);
			label129.Name = "label132";
			label129.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label129.Size = new System.Drawing.Size(141, 19);
			label129.TabIndex = 281;
			label129.Text = "Item 12. Staircases ";
			label130.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label130.AutoSize = true;
			label130.BackColor = System.Drawing.Color.Transparent;
			label130.Font = new System.Drawing.Font("Times New Roman", 12.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label130.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label130.Location = new System.Drawing.Point(48, 310);
			label130.Name = "label133";
			label130.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label130.Size = new System.Drawing.Size(235, 19);
			label130.TabIndex = 280;
			label130.Text = "Evaluation 5: Communication ";
			label131.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label131.AutoSize = true;
			label131.BackColor = System.Drawing.Color.Transparent;
			label131.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label131.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label131.Location = new System.Drawing.Point(64, 341);
			label131.Name = "label134";
			label131.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label131.Size = new System.Drawing.Size(231, 19);
			label131.TabIndex = 279;
			label131.Text = "Item 13. Auditive comprehension ";
			label132.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label132.AutoSize = true;
			label132.BackColor = System.Drawing.Color.Transparent;
			label132.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label132.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label132.Location = new System.Drawing.Point(64, 365);
			label132.Name = "label135";
			label132.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label132.Size = new System.Drawing.Size(192, 19);
			label132.TabIndex = 278;
			label132.Text = "Item 14. Verbal expression ";
			label133.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label133.AutoSize = true;
			label133.BackColor = System.Drawing.Color.Transparent;
			label133.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label133.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label133.Location = new System.Drawing.Point(546, 227);
			label133.Name = "label136";
			label133.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label133.Size = new System.Drawing.Size(174, 19);
			label133.TabIndex = 277;
			label133.Text = "Item 11. Go, wheel chair ";
			label134.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label134.AutoSize = true;
			label134.BackColor = System.Drawing.Color.Transparent;
			label134.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label134.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label134.Location = new System.Drawing.Point(76, 279);
			label134.Name = "label137";
			label134.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label134.Size = new System.Drawing.Size(185, 19);
			label134.TabIndex = 276;
			label134.Text = "Item 10. Bath-tub, shower ";
			label135.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label135.AutoSize = true;
			label135.BackColor = System.Drawing.Color.Transparent;
			label135.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label135.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label135.Location = new System.Drawing.Point(77, 251);
			label135.Name = "label138";
			label135.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label135.Size = new System.Drawing.Size(184, 19);
			label135.TabIndex = 274;
			label135.Text = "Item 9. To go to the toilets";
			label136.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label136.AutoSize = true;
			label136.BackColor = System.Drawing.Color.Transparent;
			label136.Font = new System.Drawing.Font("Times New Roman", 12.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label136.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label136.Location = new System.Drawing.Point(504, 194);
			label136.Name = "label139";
			label136.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label136.Size = new System.Drawing.Size(206, 19);
			label136.TabIndex = 275;
			label136.Text = "Evaluation 4: Locomotion ";
			label137.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label137.AutoSize = true;
			label137.BackColor = System.Drawing.Color.Transparent;
			label137.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label137.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label137.Location = new System.Drawing.Point(76, 226);
			label137.Name = "label140";
			label137.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label137.Size = new System.Drawing.Size(214, 19);
			label137.TabIndex = 273;
			label137.Text = "Item 8. Bed, chair, wheel chair ";
			label138.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label138.AutoSize = true;
			label138.BackColor = System.Drawing.Color.Transparent;
			label138.Font = new System.Drawing.Font("Times New Roman", 12.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label138.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label138.Location = new System.Drawing.Point(46, 197);
			label138.Name = "label141";
			label138.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label138.Size = new System.Drawing.Size(182, 19);
			label138.TabIndex = 272;
			label138.Text = "Evaluation 3: Mobility ";
			label139.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label139.AutoSize = true;
			label139.BackColor = System.Drawing.Color.Transparent;
			label139.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label139.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label139.Location = new System.Drawing.Point(483, 94);
			label139.Name = "label142";
			label139.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label139.Size = new System.Drawing.Size(249, 19);
			label139.TabIndex = 271;
			label139.Text = "Item 7. Control of bowel movements";
			label140.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label140.AutoSize = true;
			label140.BackColor = System.Drawing.Color.Transparent;
			label140.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label140.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label140.Location = new System.Drawing.Point(525, 70);
			label140.Name = "label143";
			label140.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label140.Size = new System.Drawing.Size(185, 19);
			label140.TabIndex = 270;
			label140.Text = "Item 6. Control of bladder ";
			label141.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label141.AutoSize = true;
			label141.BackColor = System.Drawing.Color.Transparent;
			label141.Font = new System.Drawing.Font("Times New Roman", 12.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label141.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label141.Location = new System.Drawing.Point(483, 41);
			label141.Name = "label144";
			label141.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label141.Size = new System.Drawing.Size(247, 19);
			label141.TabIndex = 269;
			label141.Text = "Evaluation 2: Sphincter control ";
			label142.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label142.AutoSize = true;
			label142.BackColor = System.Drawing.Color.Transparent;
			label142.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label142.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label142.Location = new System.Drawing.Point(84, 161);
			label142.Name = "label145";
			label142.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label142.Size = new System.Drawing.Size(200, 19);
			label142.TabIndex = 268;
			label142.Text = "Item 5. Dressing lower body ";
			label143.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label143.AutoSize = true;
			label143.BackColor = System.Drawing.Color.Transparent;
			label143.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label143.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label143.Location = new System.Drawing.Point(84, 136);
			label143.Name = "label146";
			label143.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label143.Size = new System.Drawing.Size(202, 19);
			label143.TabIndex = 267;
			label143.Text = "Item 4. Dressing upper body ";
			label144.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label144.AutoSize = true;
			label144.BackColor = System.Drawing.Color.Transparent;
			label144.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label144.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label144.Location = new System.Drawing.Point(84, 112);
			label144.Name = "label147";
			label144.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label144.Size = new System.Drawing.Size(120, 19);
			label144.TabIndex = 266;
			label144.Text = "Item 3. Hygiene ";
			label145.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label145.AutoSize = true;
			label145.BackColor = System.Drawing.Color.Transparent;
			label145.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label145.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label145.Location = new System.Drawing.Point(84, 86);
			label145.Name = "label148";
			label145.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label145.Size = new System.Drawing.Size(191, 19);
			label145.TabIndex = 265;
			label145.Text = "Item 2. Care of appearance";
			label146.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label146.AutoSize = true;
			label146.BackColor = System.Drawing.Color.Transparent;
			label146.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label146.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label146.Location = new System.Drawing.Point(84, 63);
			label146.Name = "label149";
			label146.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label146.Size = new System.Drawing.Size(97, 19);
			label146.TabIndex = 264;
			label146.Text = "Item 1. Food ";
			label147.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label147.AutoSize = true;
			label147.BackColor = System.Drawing.Color.Transparent;
			label147.Font = new System.Drawing.Font("Times New Roman", 12.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label147.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label147.Location = new System.Drawing.Point(46, 35);
			label147.Name = "label150";
			label147.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label147.Size = new System.Drawing.Size(172, 19);
			label147.TabIndex = 263;
			label147.Text = "Evaluation 1: Selfcare";
			label148.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label148.AutoSize = true;
			label148.BackColor = System.Drawing.Color.Transparent;
			label148.Font = new System.Drawing.Font("Times New Roman", 12.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label148.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label148.Location = new System.Drawing.Point(16, 12);
			label148.Name = "label151";
			label148.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label148.Size = new System.Drawing.Size(506, 19);
			label148.TabIndex = 262;
			label148.Text = "IV. Functional Assessment: (The Functional Independence Measure)";
			label149.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label149.AutoSize = true;
			label149.BackColor = System.Drawing.Color.Transparent;
			label149.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label149.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label149.Location = new System.Drawing.Point(108, 232);
			label149.Name = "label126";
			label149.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label149.Size = new System.Drawing.Size(153, 19);
			label149.TabIndex = 292;
			label149.Text = "Functional Diagnosis:";
			label150.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label150.AutoSize = true;
			label150.BackColor = System.Drawing.Color.Transparent;
			label150.Font = new System.Drawing.Font("Times New Roman", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label150.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label150.Location = new System.Drawing.Point(68, 285);
			label150.Name = "label129";
			label150.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label150.Size = new System.Drawing.Size(143, 22);
			label150.TabIndex = 291;
			label150.Text = "V. Management ";
			label151.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label151.AutoSize = true;
			label151.BackColor = System.Drawing.Color.Transparent;
			label151.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label151.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label151.Location = new System.Drawing.Point(101, 322);
			label151.Name = "label152";
			label151.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label151.Size = new System.Drawing.Size(57, 19);
			label151.TabIndex = 290;
			label151.Text = "Goals: ";
			label152.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label152.AutoSize = true;
			label152.BackColor = System.Drawing.Color.Transparent;
			label152.Font = new System.Drawing.Font("Times New Roman", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label152.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label152.Location = new System.Drawing.Point(75, 11);
			label152.Name = "label153";
			label152.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label152.Size = new System.Drawing.Size(125, 22);
			label152.TabIndex = 289;
			label152.Text = "Problem List: ";
			label153.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label153.AutoSize = true;
			label153.BackColor = System.Drawing.Color.Transparent;
			label153.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label153.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label153.Location = new System.Drawing.Point(397, 370);
			label153.Name = "label154";
			label153.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label153.Size = new System.Drawing.Size(87, 19);
			label153.TabIndex = 294;
			label153.Text = "Long term: ";
			label154.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label154.AutoSize = true;
			label154.BackColor = System.Drawing.Color.Transparent;
			label154.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label154.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label154.Location = new System.Drawing.Point(100, 370);
			label154.Name = "label155";
			label154.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label154.Size = new System.Drawing.Size(89, 19);
			label154.TabIndex = 295;
			label154.Text = "Short term: ";
			label155.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label155.AutoSize = true;
			label155.BackColor = System.Drawing.Color.Transparent;
			label155.Font = new System.Drawing.Font("Times New Roman", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label155.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label155.Location = new System.Drawing.Point(78, 454);
			label155.Name = "label156";
			label155.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label155.Size = new System.Drawing.Size(105, 22);
			label155.TabIndex = 296;
			label155.Text = "Treatment: ";
			label156.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label156.AutoSize = true;
			label156.BackColor = System.Drawing.Color.Transparent;
			label156.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label156.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label156.Location = new System.Drawing.Point(91, 101);
			label156.Name = "birthDateLabel";
			label156.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label156.Size = new System.Drawing.Size(69, 19);
			label156.TabIndex = 181;
			label156.Text = "Address:";
			label157.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label157.AutoSize = true;
			label157.BackColor = System.Drawing.Color.Transparent;
			label157.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label157.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label157.Location = new System.Drawing.Point(53, 16);
			label157.Name = "label51";
			label157.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label157.Size = new System.Drawing.Size(154, 19);
			label157.TabIndex = 214;
			label157.Text = "SENSORY SYSTEM:";
			label158.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label158.AutoSize = true;
			label158.BackColor = System.Drawing.Color.Transparent;
			label158.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label158.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label158.Location = new System.Drawing.Point(31, 312);
			label158.Name = "label157";
			label158.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label158.Size = new System.Drawing.Size(148, 19);
			label158.TabIndex = 215;
			label158.Text = "MOTOR SYSTEM: ";
			label159.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label159.AutoSize = true;
			label159.BackColor = System.Drawing.Color.Transparent;
			label159.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label159.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label159.Location = new System.Drawing.Point(53, 361);
			label159.Name = "label158";
			label159.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label159.Size = new System.Drawing.Size(103, 19);
			label159.TabIndex = 216;
			label159.Text = "Muscle Girth:";
			label160.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label160.AutoSize = true;
			label160.BackColor = System.Drawing.Color.Transparent;
			label160.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label160.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label160.Location = new System.Drawing.Point(461, 361);
			label160.Name = "label159";
			label160.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label160.Size = new System.Drawing.Size(133, 19);
			label160.TabIndex = 217;
			label160.Text = "Voluntary Control:";
			groupBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.Controls.Add(this.label15);
			groupBox4.Location = new System.Drawing.Point(230, -4);
			groupBox4.Name = "groupBox4";
			groupBox4.Size = new System.Drawing.Size(502, 43);
			groupBox4.TabIndex = 186;
			groupBox4.TabStop = false;
			this.label15.AutoSize = true;
			this.label15.Font = new System.Drawing.Font("Arial", 15.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label15.Location = new System.Drawing.Point(22, 12);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(457, 26);
			this.label15.TabIndex = 0;
			this.label15.Text = "Neurological Physiotherapy Evaluation Form";
			tabControl1.Anchor = System.Windows.Forms.AnchorStyles.Top;
			tabControl1.Controls.Add(tabPage1);
			tabControl1.Controls.Add(tabPage2);
			tabControl1.Controls.Add(tabPage3);
			tabControl1.Controls.Add(tabPage4);
			tabControl1.Controls.Add(tabPage5);
			tabControl1.Controls.Add(tabPage6);
			tabControl1.Controls.Add(tabPage7);
			tabControl1.Controls.Add(tabPage8);
			tabControl1.Controls.Add(tabPage9);
			tabControl1.Controls.Add(tabPage10);
			tabControl1.Controls.Add(tabPage11);
			tabControl1.Controls.Add(tabPage12);
			tabControl1.Controls.Add(tabPage13);
			tabControl1.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			tabControl1.Location = new System.Drawing.Point(14, 36);
			tabControl1.Name = "tabControl1";
			tabControl1.SelectedIndex = 0;
			tabControl1.Size = new System.Drawing.Size(950, 580);
			tabControl1.TabIndex = 187;
			tabPage1.Controls.Add(Handedness);
			tabPage1.Controls.Add(Sidee);
			tabPage1.Controls.Add(Referredby);
			tabPage1.Controls.Add(RelievingFactors);
			tabPage1.Controls.Add(AggravatingFactors);
			tabPage1.Controls.Add(Typee);
			tabPage1.Controls.Add(SymptomsHistory);
			tabPage1.Controls.Add(Onset);
			tabPage1.Controls.Add(SocioeconomicHistory);
			tabPage1.Controls.Add(Severity);
			tabPage1.Controls.Add(Duration);
			tabPage1.Controls.Add(Site);
			tabPage1.Controls.Add(FamilyHistory);
			tabPage1.Controls.Add(PersonalHistory);
			tabPage1.Controls.Add(PastMedicalHistory);
			tabPage1.Controls.Add(ChiefComplaints);
			tabPage1.Controls.Add(Occupation);
			tabPage1.Controls.Add(DGVitalSigns);
			tabPage1.Controls.Add(label23);
			tabPage1.Controls.Add(label22);
			tabPage1.Controls.Add(label21);
			tabPage1.Controls.Add(label20);
			tabPage1.Controls.Add(label19);
			tabPage1.Controls.Add(label18);
			tabPage1.Controls.Add(label17);
			tabPage1.Controls.Add(label16);
			tabPage1.Controls.Add(label15);
			tabPage1.Controls.Add(label14);
			tabPage1.Controls.Add(label13);
			tabPage1.Controls.Add(label12);
			tabPage1.Controls.Add(label11);
			tabPage1.Controls.Add(label10);
			tabPage1.Controls.Add(label9);
			tabPage1.Controls.Add(label8);
			tabPage1.Controls.Add(label7);
			tabPage1.Controls.Add(label6);
			tabPage1.Controls.Add(address);
			tabPage1.Controls.Add(label);
			tabPage1.Controls.Add(age);
			tabPage1.Controls.Add(label2);
			tabPage1.Controls.Add(sex);
			tabPage1.Controls.Add(label3);
			tabPage1.Controls.Add(label4);
			tabPage1.Controls.Add(IPOP);
			tabPage1.Controls.Add(PatientName);
			tabPage1.Controls.Add(label5);
			tabPage1.Controls.Add(label156);
			tabPage1.Location = new System.Drawing.Point(4, 25);
			tabPage1.Name = "tabPage1";
			tabPage1.Padding = new System.Windows.Forms.Padding(3);
			tabPage1.Size = new System.Drawing.Size(942, 551);
			tabPage1.TabIndex = 0;
			tabPage1.Text = "Page 1";
			tabPage1.UseVisualStyleBackColor = true;
			Handedness.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Handedness.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Handedness.Location = new System.Drawing.Point(504, 68);
			Handedness.Multiline = true;
			Handedness.Name = "Handedness";
			Handedness.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Handedness.Size = new System.Drawing.Size(55, 27);
			Handedness.TabIndex = 212;
			Sidee.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Sidee.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Sidee.Location = new System.Drawing.Point(143, 230);
			Sidee.Multiline = true;
			Sidee.Name = "Sidee";
			Sidee.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Sidee.Size = new System.Drawing.Size(161, 22);
			Sidee.TabIndex = 220;
			Referredby.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Referredby.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Referredby.Location = new System.Drawing.Point(672, 70);
			Referredby.Multiline = true;
			Referredby.Name = "Referredby";
			Referredby.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Referredby.Size = new System.Drawing.Size(210, 22);
			Referredby.TabIndex = 213;
			RelievingFactors.Anchor = System.Windows.Forms.AnchorStyles.Top;
			RelievingFactors.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			RelievingFactors.Location = new System.Drawing.Point(235, 374);
			RelievingFactors.Multiline = true;
			RelievingFactors.Name = "RelievingFactors";
			RelievingFactors.RightToLeft = System.Windows.Forms.RightToLeft.No;
			RelievingFactors.Size = new System.Drawing.Size(210, 22);
			RelievingFactors.TabIndex = 227;
			AggravatingFactors.Anchor = System.Windows.Forms.AnchorStyles.Top;
			AggravatingFactors.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			AggravatingFactors.Location = new System.Drawing.Point(235, 339);
			AggravatingFactors.Multiline = true;
			AggravatingFactors.Name = "AggravatingFactors";
			AggravatingFactors.RightToLeft = System.Windows.Forms.RightToLeft.No;
			AggravatingFactors.Size = new System.Drawing.Size(210, 22);
			AggravatingFactors.TabIndex = 226;
			Typee.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Typee.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Typee.Location = new System.Drawing.Point(143, 301);
			Typee.Multiline = true;
			Typee.Name = "Typee";
			Typee.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Typee.Size = new System.Drawing.Size(161, 22);
			Typee.TabIndex = 224;
			SymptomsHistory.Anchor = System.Windows.Forms.AnchorStyles.Top;
			SymptomsHistory.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			SymptomsHistory.Location = new System.Drawing.Point(268, 191);
			SymptomsHistory.Multiline = true;
			SymptomsHistory.Name = "SymptomsHistory";
			SymptomsHistory.RightToLeft = System.Windows.Forms.RightToLeft.No;
			SymptomsHistory.Size = new System.Drawing.Size(210, 22);
			SymptomsHistory.TabIndex = 219;
			Onset.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Onset.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Onset.Location = new System.Drawing.Point(143, 267);
			Onset.Multiline = true;
			Onset.Name = "Onset";
			Onset.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Onset.Size = new System.Drawing.Size(161, 22);
			Onset.TabIndex = 222;
			SocioeconomicHistory.Anchor = System.Windows.Forms.AnchorStyles.Top;
			SocioeconomicHistory.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			SocioeconomicHistory.Location = new System.Drawing.Point(268, 161);
			SocioeconomicHistory.Multiline = true;
			SocioeconomicHistory.Name = "SocioeconomicHistory";
			SocioeconomicHistory.RightToLeft = System.Windows.Forms.RightToLeft.No;
			SocioeconomicHistory.Size = new System.Drawing.Size(210, 22);
			SocioeconomicHistory.TabIndex = 218;
			Severity.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Severity.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Severity.Location = new System.Drawing.Point(383, 302);
			Severity.Multiline = true;
			Severity.Name = "Severity";
			Severity.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Severity.Size = new System.Drawing.Size(162, 22);
			Severity.TabIndex = 225;
			Duration.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Duration.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Duration.Location = new System.Drawing.Point(383, 269);
			Duration.Multiline = true;
			Duration.Name = "Duration";
			Duration.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Duration.Size = new System.Drawing.Size(162, 22);
			Duration.TabIndex = 223;
			Site.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Site.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Site.Location = new System.Drawing.Point(383, 229);
			Site.Multiline = true;
			Site.Name = "Site";
			Site.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Site.Size = new System.Drawing.Size(162, 22);
			Site.TabIndex = 221;
			FamilyHistory.Anchor = System.Windows.Forms.AnchorStyles.Top;
			FamilyHistory.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FamilyHistory.Location = new System.Drawing.Point(268, 133);
			FamilyHistory.Multiline = true;
			FamilyHistory.Name = "FamilyHistory";
			FamilyHistory.RightToLeft = System.Windows.Forms.RightToLeft.No;
			FamilyHistory.Size = new System.Drawing.Size(210, 22);
			FamilyHistory.TabIndex = 217;
			PersonalHistory.Anchor = System.Windows.Forms.AnchorStyles.Top;
			PersonalHistory.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			PersonalHistory.Location = new System.Drawing.Point(576, 295);
			PersonalHistory.Multiline = true;
			PersonalHistory.Name = "PersonalHistory";
			PersonalHistory.RightToLeft = System.Windows.Forms.RightToLeft.No;
			PersonalHistory.Size = new System.Drawing.Size(261, 44);
			PersonalHistory.TabIndex = 216;
			PastMedicalHistory.Anchor = System.Windows.Forms.AnchorStyles.Top;
			PastMedicalHistory.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			PastMedicalHistory.Location = new System.Drawing.Point(576, 213);
			PastMedicalHistory.Multiline = true;
			PastMedicalHistory.Name = "PastMedicalHistory";
			PastMedicalHistory.RightToLeft = System.Windows.Forms.RightToLeft.No;
			PastMedicalHistory.Size = new System.Drawing.Size(261, 48);
			PastMedicalHistory.TabIndex = 215;
			ChiefComplaints.Anchor = System.Windows.Forms.AnchorStyles.Top;
			ChiefComplaints.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			ChiefComplaints.Location = new System.Drawing.Point(581, 132);
			ChiefComplaints.Multiline = true;
			ChiefComplaints.Name = "ChiefComplaints";
			ChiefComplaints.RightToLeft = System.Windows.Forms.RightToLeft.No;
			ChiefComplaints.Size = new System.Drawing.Size(259, 52);
			ChiefComplaints.TabIndex = 214;
			Occupation.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Occupation.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Occupation.Location = new System.Drawing.Point(190, 68);
			Occupation.Multiline = true;
			Occupation.Name = "Occupation";
			Occupation.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Occupation.Size = new System.Drawing.Size(164, 27);
			Occupation.TabIndex = 211;
			DGVitalSigns.AllowUserToAddRows = false;
			DGVitalSigns.AllowUserToDeleteRows = false;
			DGVitalSigns.AllowUserToOrderColumns = true;
			DGVitalSigns.AllowUserToResizeColumns = false;
			DGVitalSigns.AllowUserToResizeRows = false;
			DGVitalSigns.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGVitalSigns.BackgroundColor = System.Drawing.Color.White;
			DGVitalSigns.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGVitalSigns.ColumnHeadersVisible = false;
			DGVitalSigns.Columns.AddRange(Column1, Column2, Column3, Column4);
			dataGridViewCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGVitalSigns.DefaultCellStyle = dataGridViewCellStyle;
			DGVitalSigns.Location = new System.Drawing.Point(134, 446);
			DGVitalSigns.Name = "DGVitalSigns";
			DGVitalSigns.RowHeadersVisible = false;
			DGVitalSigns.ScrollBars = System.Windows.Forms.ScrollBars.None;
			DGVitalSigns.Size = new System.Drawing.Size(602, 47);
			DGVitalSigns.TabIndex = 228;
			Column1.HeaderText = "Temperature: ";
			Column1.Name = "Column1";
			Column1.ReadOnly = true;
			Column1.Width = 170;
			Column2.HeaderText = "Column2";
			Column2.Name = "Column2";
			Column2.Width = 130;
			Column3.HeaderText = "Heart Rate: ";
			Column3.Name = "Column3";
			Column3.ReadOnly = true;
			Column3.Width = 170;
			Column4.HeaderText = "Column4";
			Column4.Name = "Column4";
			Column4.Width = 130;
			address.Anchor = System.Windows.Forms.AnchorStyles.Top;
			address.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			address.Location = new System.Drawing.Point(190, 98);
			address.Multiline = true;
			address.Name = "address";
			address.RightToLeft = System.Windows.Forms.RightToLeft.No;
			address.Size = new System.Drawing.Size(164, 22);
			address.TabIndex = 193;
			age.Anchor = System.Windows.Forms.AnchorStyles.Top;
			age.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			age.Enabled = false;
			age.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			age.Location = new System.Drawing.Point(420, 36);
			age.Name = "age";
			age.RightToLeft = System.Windows.Forms.RightToLeft.No;
			age.Size = new System.Drawing.Size(58, 26);
			age.TabIndex = 185;
			age.Text = "0";
			age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			sex.Anchor = System.Windows.Forms.AnchorStyles.Top;
			sex.BackColor = System.Drawing.SystemColors.Window;
			sex.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			sex.ForeColor = System.Drawing.Color.Maroon;
			sex.Location = new System.Drawing.Point(599, 34);
			sex.Name = "sex";
			sex.ReadOnly = true;
			sex.RightToLeft = System.Windows.Forms.RightToLeft.No;
			sex.Size = new System.Drawing.Size(68, 26);
			sex.TabIndex = 188;
			sex.Text = " ";
			IPOP.Anchor = System.Windows.Forms.AnchorStyles.Top;
			IPOP.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			IPOP.Location = new System.Drawing.Point(737, 32);
			IPOP.Multiline = true;
			IPOP.Name = "IPOP";
			IPOP.RightToLeft = System.Windows.Forms.RightToLeft.No;
			IPOP.Size = new System.Drawing.Size(142, 22);
			IPOP.TabIndex = 210;
			PatientName.Anchor = System.Windows.Forms.AnchorStyles.Top;
			PatientName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			PatientName.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			PatientName.FormattingEnabled = true;
			PatientName.ItemHeight = 19;
			PatientName.Location = new System.Drawing.Point(146, 35);
			PatientName.Name = "PatientName";
			PatientName.RightToLeft = System.Windows.Forms.RightToLeft.No;
			PatientName.Size = new System.Drawing.Size(208, 27);
			PatientName.TabIndex = 187;
			PatientName.SelectedIndexChanged += new System.EventHandler(PatientName_SelectedIndexChanged);
			tabPage2.Controls.Add(Time);
			tabPage2.Controls.Add(Place);
			tabPage2.Controls.Add(Person);
			tabPage2.Controls.Add(Orientation);
			tabPage2.Controls.Add(Consciousness);
			tabPage2.Controls.Add(Tenderness);
			tabPage2.Controls.Add(Warmth);
			tabPage2.Controls.Add(Tone);
			tabPage2.Controls.Add(Swelling);
			tabPage2.Controls.Add(ExternalAppliances);
			tabPage2.Controls.Add(Wounds);
			tabPage2.Controls.Add(Deformity);
			tabPage2.Controls.Add(PressureSores);
			tabPage2.Controls.Add(MuscleWasting);
			tabPage2.Controls.Add(Oedema);
			tabPage2.Controls.Add(Respiration);
			tabPage2.Controls.Add(ModeofVentilation);
			tabPage2.Controls.Add(PatternofMovement);
			tabPage2.Controls.Add(Gait);
			tabPage2.Controls.Add(Posture);
			tabPage2.Controls.Add(Built);
			tabPage2.Controls.Add(Attitudeoflimbs);
			tabPage2.Controls.Add(label50);
			tabPage2.Controls.Add(label49);
			tabPage2.Controls.Add(label48);
			tabPage2.Controls.Add(label47);
			tabPage2.Controls.Add(label46);
			tabPage2.Controls.Add(label45);
			tabPage2.Controls.Add(label44);
			tabPage2.Controls.Add(label43);
			tabPage2.Controls.Add(label42);
			tabPage2.Controls.Add(label41);
			tabPage2.Controls.Add(label40);
			tabPage2.Controls.Add(label39);
			tabPage2.Controls.Add(label38);
			tabPage2.Controls.Add(label37);
			tabPage2.Controls.Add(label36);
			tabPage2.Controls.Add(label35);
			tabPage2.Controls.Add(label34);
			tabPage2.Controls.Add(label33);
			tabPage2.Controls.Add(label32);
			tabPage2.Controls.Add(label31);
			tabPage2.Controls.Add(label30);
			tabPage2.Controls.Add(label29);
			tabPage2.Controls.Add(label28);
			tabPage2.Controls.Add(label27);
			tabPage2.Controls.Add(label26);
			tabPage2.Controls.Add(label25);
			tabPage2.Controls.Add(label24);
			tabPage2.Location = new System.Drawing.Point(4, 25);
			tabPage2.Name = "tabPage2";
			tabPage2.Padding = new System.Windows.Forms.Padding(3);
			tabPage2.Size = new System.Drawing.Size(942, 581);
			tabPage2.TabIndex = 1;
			tabPage2.Text = "Page 2";
			tabPage2.UseVisualStyleBackColor = true;
			Time.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Time.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Time.Location = new System.Drawing.Point(631, 476);
			Time.Multiline = true;
			Time.Name = "Time";
			Time.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Time.Size = new System.Drawing.Size(224, 22);
			Time.TabIndex = 249;
			Place.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Place.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Place.Location = new System.Drawing.Point(631, 448);
			Place.Multiline = true;
			Place.Name = "Place";
			Place.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Place.Size = new System.Drawing.Size(224, 22);
			Place.TabIndex = 248;
			Person.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Person.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Person.Location = new System.Drawing.Point(631, 416);
			Person.Multiline = true;
			Person.Name = "Person";
			Person.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Person.Size = new System.Drawing.Size(211, 22);
			Person.TabIndex = 247;
			Orientation.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Orientation.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Orientation.Location = new System.Drawing.Point(314, 445);
			Orientation.Multiline = true;
			Orientation.Name = "Orientation";
			Orientation.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Orientation.Size = new System.Drawing.Size(210, 22);
			Orientation.TabIndex = 246;
			Consciousness.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Consciousness.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Consciousness.Location = new System.Drawing.Point(314, 419);
			Consciousness.Multiline = true;
			Consciousness.Name = "Consciousness";
			Consciousness.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Consciousness.Size = new System.Drawing.Size(210, 22);
			Consciousness.TabIndex = 245;
			Tenderness.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Tenderness.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Tenderness.Location = new System.Drawing.Point(321, 332);
			Tenderness.Multiline = true;
			Tenderness.Name = "Tenderness";
			Tenderness.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Tenderness.Size = new System.Drawing.Size(211, 22);
			Tenderness.TabIndex = 242;
			Warmth.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Warmth.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Warmth.Location = new System.Drawing.Point(321, 304);
			Warmth.Multiline = true;
			Warmth.Name = "Warmth";
			Warmth.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Warmth.Size = new System.Drawing.Size(211, 22);
			Warmth.TabIndex = 241;
			Tone.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Tone.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Tone.Location = new System.Drawing.Point(631, 302);
			Tone.Multiline = true;
			Tone.Name = "Tone";
			Tone.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Tone.Size = new System.Drawing.Size(211, 22);
			Tone.TabIndex = 243;
			Swelling.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Swelling.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Swelling.Location = new System.Drawing.Point(631, 332);
			Swelling.Multiline = true;
			Swelling.Name = "Swelling";
			Swelling.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Swelling.Size = new System.Drawing.Size(211, 22);
			Swelling.TabIndex = 244;
			ExternalAppliances.Anchor = System.Windows.Forms.AnchorStyles.Top;
			ExternalAppliances.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			ExternalAppliances.Location = new System.Drawing.Point(631, 173);
			ExternalAppliances.Multiline = true;
			ExternalAppliances.Name = "ExternalAppliances";
			ExternalAppliances.RightToLeft = System.Windows.Forms.RightToLeft.No;
			ExternalAppliances.Size = new System.Drawing.Size(216, 22);
			ExternalAppliances.TabIndex = 240;
			Wounds.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Wounds.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Wounds.Location = new System.Drawing.Point(631, 145);
			Wounds.Multiline = true;
			Wounds.Name = "Wounds";
			Wounds.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Wounds.Size = new System.Drawing.Size(216, 22);
			Wounds.TabIndex = 239;
			Deformity.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Deformity.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Deformity.Location = new System.Drawing.Point(631, 113);
			Deformity.Multiline = true;
			Deformity.Name = "Deformity";
			Deformity.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Deformity.Size = new System.Drawing.Size(216, 22);
			Deformity.TabIndex = 238;
			PressureSores.Anchor = System.Windows.Forms.AnchorStyles.Top;
			PressureSores.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PressureSores.Location = new System.Drawing.Point(321, 173);
			PressureSores.Multiline = true;
			PressureSores.Name = "PressureSores";
			PressureSores.RightToLeft = System.Windows.Forms.RightToLeft.No;
			PressureSores.Size = new System.Drawing.Size(210, 22);
			PressureSores.TabIndex = 232;
			MuscleWasting.Anchor = System.Windows.Forms.AnchorStyles.Top;
			MuscleWasting.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			MuscleWasting.Location = new System.Drawing.Point(321, 145);
			MuscleWasting.Multiline = true;
			MuscleWasting.Name = "MuscleWasting";
			MuscleWasting.RightToLeft = System.Windows.Forms.RightToLeft.No;
			MuscleWasting.Size = new System.Drawing.Size(210, 22);
			MuscleWasting.TabIndex = 231;
			Oedema.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Oedema.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Oedema.Location = new System.Drawing.Point(321, 116);
			Oedema.Multiline = true;
			Oedema.Name = "Oedema";
			Oedema.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Oedema.Size = new System.Drawing.Size(210, 22);
			Oedema.TabIndex = 230;
			Respiration.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Respiration.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Respiration.Location = new System.Drawing.Point(321, 254);
			Respiration.Multiline = true;
			Respiration.Name = "Respiration";
			Respiration.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Respiration.Size = new System.Drawing.Size(211, 22);
			Respiration.TabIndex = 235;
			ModeofVentilation.Anchor = System.Windows.Forms.AnchorStyles.Top;
			ModeofVentilation.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			ModeofVentilation.Location = new System.Drawing.Point(321, 226);
			ModeofVentilation.Multiline = true;
			ModeofVentilation.Name = "ModeofVentilation";
			ModeofVentilation.RightToLeft = System.Windows.Forms.RightToLeft.No;
			ModeofVentilation.Size = new System.Drawing.Size(211, 22);
			ModeofVentilation.TabIndex = 234;
			PatternofMovement.Anchor = System.Windows.Forms.AnchorStyles.Top;
			PatternofMovement.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PatternofMovement.Location = new System.Drawing.Point(321, 201);
			PatternofMovement.Multiline = true;
			PatternofMovement.Name = "PatternofMovement";
			PatternofMovement.RightToLeft = System.Windows.Forms.RightToLeft.No;
			PatternofMovement.Size = new System.Drawing.Size(211, 22);
			PatternofMovement.TabIndex = 233;
			Gait.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Gait.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Gait.Location = new System.Drawing.Point(631, 82);
			Gait.Multiline = true;
			Gait.Name = "Gait";
			Gait.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Gait.Size = new System.Drawing.Size(216, 22);
			Gait.TabIndex = 237;
			Posture.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Posture.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Posture.Location = new System.Drawing.Point(631, 55);
			Posture.Multiline = true;
			Posture.Name = "Posture";
			Posture.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Posture.Size = new System.Drawing.Size(216, 22);
			Posture.TabIndex = 236;
			Built.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Built.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Built.Location = new System.Drawing.Point(322, 86);
			Built.Multiline = true;
			Built.Name = "Built";
			Built.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Built.Size = new System.Drawing.Size(210, 22);
			Built.TabIndex = 229;
			Attitudeoflimbs.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Attitudeoflimbs.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Attitudeoflimbs.Location = new System.Drawing.Point(321, 58);
			Attitudeoflimbs.Multiline = true;
			Attitudeoflimbs.Name = "Attitudeoflimbs";
			Attitudeoflimbs.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Attitudeoflimbs.Size = new System.Drawing.Size(210, 22);
			Attitudeoflimbs.TabIndex = 228;
			tabPage3.Controls.Add(SpecialSenses);
			tabPage3.Controls.Add(AgnosiasApraxias);
			tabPage3.Controls.Add(Imaging);
			tabPage3.Controls.Add(Perception);
			tabPage3.Controls.Add(EmotionalStatus);
			tabPage3.Controls.Add(Attention);
			tabPage3.Controls.Add(ProverbInterpretation);
			tabPage3.Controls.Add(Calculation);
			tabPage3.Controls.Add(FundofKnowledge);
			tabPage3.Controls.Add(Cognition);
			tabPage3.Controls.Add(Communication);
			tabPage3.Controls.Add(Visual);
			tabPage3.Controls.Add(Verbal);
			tabPage3.Controls.Add(Remote);
			tabPage3.Controls.Add(Recent);
			tabPage3.Controls.Add(Immediate);
			tabPage3.Controls.Add(Memory);
			tabPage3.Controls.Add(DGNerves);
			tabPage3.Controls.Add(label51);
			tabPage3.Controls.Add(label52);
			tabPage3.Controls.Add(label53);
			tabPage3.Controls.Add(label54);
			tabPage3.Controls.Add(label55);
			tabPage3.Controls.Add(label56);
			tabPage3.Controls.Add(label57);
			tabPage3.Controls.Add(label58);
			tabPage3.Controls.Add(label59);
			tabPage3.Controls.Add(label60);
			tabPage3.Controls.Add(label61);
			tabPage3.Controls.Add(label62);
			tabPage3.Controls.Add(label63);
			tabPage3.Controls.Add(label64);
			tabPage3.Controls.Add(label65);
			tabPage3.Controls.Add(label66);
			tabPage3.Controls.Add(label67);
			tabPage3.Controls.Add(label68);
			tabPage3.Location = new System.Drawing.Point(4, 25);
			tabPage3.Name = "tabPage3";
			tabPage3.Padding = new System.Windows.Forms.Padding(3);
			tabPage3.Size = new System.Drawing.Size(942, 581);
			tabPage3.TabIndex = 2;
			tabPage3.Text = "Page 3";
			tabPage3.UseVisualStyleBackColor = true;
			SpecialSenses.Anchor = System.Windows.Forms.AnchorStyles.Top;
			SpecialSenses.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			SpecialSenses.Location = new System.Drawing.Point(662, 284);
			SpecialSenses.Multiline = true;
			SpecialSenses.Name = "SpecialSenses";
			SpecialSenses.RightToLeft = System.Windows.Forms.RightToLeft.No;
			SpecialSenses.Size = new System.Drawing.Size(245, 22);
			SpecialSenses.TabIndex = 248;
			AgnosiasApraxias.Anchor = System.Windows.Forms.AnchorStyles.Top;
			AgnosiasApraxias.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			AgnosiasApraxias.Location = new System.Drawing.Point(212, 318);
			AgnosiasApraxias.Multiline = true;
			AgnosiasApraxias.Name = "AgnosiasApraxias";
			AgnosiasApraxias.RightToLeft = System.Windows.Forms.RightToLeft.No;
			AgnosiasApraxias.Size = new System.Drawing.Size(266, 22);
			AgnosiasApraxias.TabIndex = 247;
			Imaging.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Imaging.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Imaging.Location = new System.Drawing.Point(212, 285);
			Imaging.Multiline = true;
			Imaging.Name = "Imaging";
			Imaging.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Imaging.Size = new System.Drawing.Size(266, 22);
			Imaging.TabIndex = 246;
			Perception.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Perception.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Perception.Location = new System.Drawing.Point(662, 253);
			Perception.Multiline = true;
			Perception.Name = "Perception";
			Perception.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Perception.Size = new System.Drawing.Size(245, 22);
			Perception.TabIndex = 245;
			EmotionalStatus.Anchor = System.Windows.Forms.AnchorStyles.Top;
			EmotionalStatus.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			EmotionalStatus.Location = new System.Drawing.Point(662, 222);
			EmotionalStatus.Multiline = true;
			EmotionalStatus.Name = "EmotionalStatus";
			EmotionalStatus.RightToLeft = System.Windows.Forms.RightToLeft.No;
			EmotionalStatus.Size = new System.Drawing.Size(245, 22);
			EmotionalStatus.TabIndex = 244;
			Attention.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Attention.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Attention.Location = new System.Drawing.Point(659, 190);
			Attention.Multiline = true;
			Attention.Name = "Attention";
			Attention.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Attention.Size = new System.Drawing.Size(245, 22);
			Attention.TabIndex = 243;
			ProverbInterpretation.Anchor = System.Windows.Forms.AnchorStyles.Top;
			ProverbInterpretation.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			ProverbInterpretation.Location = new System.Drawing.Point(212, 255);
			ProverbInterpretation.Multiline = true;
			ProverbInterpretation.Name = "ProverbInterpretation";
			ProverbInterpretation.RightToLeft = System.Windows.Forms.RightToLeft.No;
			ProverbInterpretation.Size = new System.Drawing.Size(266, 22);
			ProverbInterpretation.TabIndex = 242;
			Calculation.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Calculation.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Calculation.Location = new System.Drawing.Point(212, 228);
			Calculation.Multiline = true;
			Calculation.Name = "Calculation";
			Calculation.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Calculation.Size = new System.Drawing.Size(266, 22);
			Calculation.TabIndex = 241;
			FundofKnowledge.Anchor = System.Windows.Forms.AnchorStyles.Top;
			FundofKnowledge.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			FundofKnowledge.Location = new System.Drawing.Point(212, 193);
			FundofKnowledge.Multiline = true;
			FundofKnowledge.Name = "FundofKnowledge";
			FundofKnowledge.RightToLeft = System.Windows.Forms.RightToLeft.No;
			FundofKnowledge.Size = new System.Drawing.Size(266, 22);
			FundofKnowledge.TabIndex = 240;
			Cognition.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Cognition.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Cognition.Location = new System.Drawing.Point(155, 159);
			Cognition.Multiline = true;
			Cognition.Name = "Cognition";
			Cognition.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Cognition.Size = new System.Drawing.Size(323, 22);
			Cognition.TabIndex = 239;
			Communication.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Communication.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Communication.Location = new System.Drawing.Point(155, 130);
			Communication.Multiline = true;
			Communication.Name = "Communication";
			Communication.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Communication.Size = new System.Drawing.Size(323, 22);
			Communication.TabIndex = 238;
			Visual.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Visual.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Visual.Location = new System.Drawing.Point(659, 73);
			Visual.Multiline = true;
			Visual.Name = "Visual";
			Visual.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Visual.Size = new System.Drawing.Size(236, 22);
			Visual.TabIndex = 237;
			Verbal.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Verbal.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Verbal.Location = new System.Drawing.Point(659, 47);
			Verbal.Multiline = true;
			Verbal.Name = "Verbal";
			Verbal.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Verbal.Size = new System.Drawing.Size(236, 22);
			Verbal.TabIndex = 236;
			Remote.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Remote.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Remote.Location = new System.Drawing.Point(212, 94);
			Remote.Multiline = true;
			Remote.Name = "Remote";
			Remote.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Remote.Size = new System.Drawing.Size(266, 22);
			Remote.TabIndex = 235;
			Recent.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Recent.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Recent.Location = new System.Drawing.Point(212, 71);
			Recent.Multiline = true;
			Recent.Name = "Recent";
			Recent.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Recent.Size = new System.Drawing.Size(266, 22);
			Recent.TabIndex = 234;
			Immediate.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Immediate.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Immediate.Location = new System.Drawing.Point(212, 44);
			Immediate.Multiline = true;
			Immediate.Name = "Immediate";
			Immediate.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Immediate.Size = new System.Drawing.Size(266, 22);
			Immediate.TabIndex = 233;
			Memory.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Memory.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Memory.Location = new System.Drawing.Point(155, 15);
			Memory.Multiline = true;
			Memory.Name = "Memory";
			Memory.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Memory.Size = new System.Drawing.Size(323, 22);
			Memory.TabIndex = 232;
			DGNerves.AllowUserToAddRows = false;
			DGNerves.AllowUserToDeleteRows = false;
			DGNerves.AllowUserToOrderColumns = true;
			DGNerves.AllowUserToResizeColumns = false;
			DGNerves.AllowUserToResizeRows = false;
			DGNerves.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGNerves.BackgroundColor = System.Drawing.Color.White;
			DGNerves.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGNerves.Columns.AddRange(Nerves, Comments, Nerves2, Comments2);
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGNerves.DefaultCellStyle = dataGridViewCellStyle2;
			DGNerves.EnableHeadersVisualStyles = false;
			DGNerves.Location = new System.Drawing.Point(79, 376);
			DGNerves.Name = "DGNerves";
			DGNerves.RowHeadersVisible = false;
			DGNerves.RowTemplate.Height = 30;
			DGNerves.Size = new System.Drawing.Size(823, 112);
			DGNerves.TabIndex = 249;
			Nerves.HeaderText = "Nerves";
			Nerves.Name = "Nerves";
			Nerves.ReadOnly = true;
			Nerves.Width = 150;
			Comments.HeaderText = "Comments";
			Comments.Name = "Comments";
			Comments.Width = 250;
			Nerves2.HeaderText = "Nerves";
			Nerves2.Name = "Nerves2";
			Nerves2.ReadOnly = true;
			Nerves2.Width = 170;
			Comments2.HeaderText = "Comments";
			Comments2.Name = "Comments2";
			Comments2.Width = 250;
			tabPage4.Controls.Add(MOTORSYSTEM);
			tabPage4.Controls.Add(DGVoluntaryControl);
			tabPage4.Controls.Add(DGMuscleGirth);
			tabPage4.Controls.Add(label160);
			tabPage4.Controls.Add(label159);
			tabPage4.Controls.Add(label158);
			tabPage4.Controls.Add(label157);
			tabPage4.Controls.Add(DGSENSORYSYS);
			tabPage4.Controls.Add(dataGridView1);
			tabPage4.Location = new System.Drawing.Point(4, 25);
			tabPage4.Name = "tabPage4";
			tabPage4.Padding = new System.Windows.Forms.Padding(3);
			tabPage4.Size = new System.Drawing.Size(942, 581);
			tabPage4.TabIndex = 3;
			tabPage4.Text = "Page 4";
			tabPage4.UseVisualStyleBackColor = true;
			MOTORSYSTEM.Anchor = System.Windows.Forms.AnchorStyles.Top;
			MOTORSYSTEM.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			MOTORSYSTEM.Location = new System.Drawing.Point(185, 309);
			MOTORSYSTEM.Multiline = true;
			MOTORSYSTEM.Name = "MOTORSYSTEM";
			MOTORSYSTEM.RightToLeft = System.Windows.Forms.RightToLeft.No;
			MOTORSYSTEM.Size = new System.Drawing.Size(365, 22);
			MOTORSYSTEM.TabIndex = 2;
			DGVoluntaryControl.AllowUserToAddRows = false;
			DGVoluntaryControl.AllowUserToDeleteRows = false;
			DGVoluntaryControl.AllowUserToOrderColumns = true;
			DGVoluntaryControl.AllowUserToResizeColumns = false;
			DGVoluntaryControl.AllowUserToResizeRows = false;
			DGVoluntaryControl.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGVoluntaryControl.BackgroundColor = System.Drawing.Color.White;
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			DGVoluntaryControl.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
			DGVoluntaryControl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGVoluntaryControl.Columns.AddRange(Sideee, Rt_, Lt_);
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle4.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.White;
			dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGVoluntaryControl.DefaultCellStyle = dataGridViewCellStyle4;
			DGVoluntaryControl.Location = new System.Drawing.Point(465, 383);
			DGVoluntaryControl.Name = "DGVoluntaryControl";
			DGVoluntaryControl.RowHeadersVisible = false;
			DGVoluntaryControl.RowTemplate.Height = 35;
			DGVoluntaryControl.ScrollBars = System.Windows.Forms.ScrollBars.None;
			DGVoluntaryControl.Size = new System.Drawing.Size(394, 96);
			DGVoluntaryControl.TabIndex = 4;
			Sideee.HeaderText = "Side";
			Sideee.Name = "Sideee";
			Sideee.ReadOnly = true;
			Sideee.Width = 130;
			Rt_.HeaderText = "Rt.";
			Rt_.Name = "Rt_";
			Rt_.Width = 130;
			Lt_.HeaderText = "Lt. ";
			Lt_.Name = "Lt_";
			Lt_.Width = 130;
			DGMuscleGirth.AllowUserToAddRows = false;
			DGMuscleGirth.AllowUserToDeleteRows = false;
			DGMuscleGirth.AllowUserToOrderColumns = true;
			DGMuscleGirth.AllowUserToResizeColumns = false;
			DGMuscleGirth.AllowUserToResizeRows = false;
			DGMuscleGirth.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGMuscleGirth.BackgroundColor = System.Drawing.Color.White;
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle5.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			DGMuscleGirth.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
			DGMuscleGirth.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGMuscleGirth.Columns.AddRange(Area, Rt_cm, Lt_cm);
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle6.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.White;
			dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGMuscleGirth.DefaultCellStyle = dataGridViewCellStyle6;
			DGMuscleGirth.Location = new System.Drawing.Point(57, 383);
			DGMuscleGirth.Name = "DGMuscleGirth";
			DGMuscleGirth.RowHeadersVisible = false;
			DGMuscleGirth.ScrollBars = System.Windows.Forms.ScrollBars.None;
			DGMuscleGirth.Size = new System.Drawing.Size(334, 116);
			DGMuscleGirth.TabIndex = 3;
			Area.HeaderText = "Area";
			Area.Name = "Area";
			Area.ReadOnly = true;
			Area.Width = 130;
			Rt_cm.HeaderText = "Rt.(cm.) ";
			Rt_cm.Name = "Rt_cm";
			Lt_cm.HeaderText = "Lt.(cm.)";
			Lt_cm.Name = "Lt_cm";
			DGSENSORYSYS.AllowUserToAddRows = false;
			DGSENSORYSYS.AllowUserToDeleteRows = false;
			DGSENSORYSYS.AllowUserToOrderColumns = true;
			DGSENSORYSYS.AllowUserToResizeColumns = false;
			DGSENSORYSYS.AllowUserToResizeRows = false;
			DGSENSORYSYS.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGSENSORYSYS.BackgroundColor = System.Drawing.Color.White;
			DGSENSORYSYS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGSENSORYSYS.Columns.AddRange(Column9, Rt1, Lt1, Rt22, Lt22, Rt3, Lt3, notes);
			dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle7.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.White;
			dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGSENSORYSYS.DefaultCellStyle = dataGridViewCellStyle7;
			DGSENSORYSYS.Location = new System.Drawing.Point(57, 88);
			DGSENSORYSYS.Name = "DGSENSORYSYS";
			DGSENSORYSYS.RowHeadersVisible = false;
			DGSENSORYSYS.RowTemplate.Height = 25;
			DGSENSORYSYS.Size = new System.Drawing.Size(765, 204);
			DGSENSORYSYS.TabIndex = 1;
			Column9.HeaderText = "Sensation";
			Column9.Name = "Column9";
			Column9.ReadOnly = true;
			Column9.Width = 250;
			Rt1.HeaderText = "Rt. ";
			Rt1.Name = "Rt1";
			Rt1.Width = 60;
			Lt1.HeaderText = "Lt ";
			Lt1.Name = "Lt1";
			Lt1.Width = 60;
			Rt22.HeaderText = "Rt. ";
			Rt22.Name = "Rt22";
			Rt22.Width = 60;
			Lt22.HeaderText = "Lt. ";
			Lt22.Name = "Lt22";
			Lt22.Width = 60;
			Rt3.HeaderText = "Rt.";
			Rt3.Name = "Rt3";
			Rt3.Width = 60;
			Lt3.HeaderText = "Lt. ";
			Lt3.Name = "Lt3";
			Lt3.Width = 60;
			notes.HeaderText = "";
			notes.Name = "notes";
			notes.Width = 150;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			dataGridView1.AllowUserToOrderColumns = true;
			dataGridView1.AllowUserToResizeColumns = false;
			dataGridView1.AllowUserToResizeRows = false;
			dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.Top;
			dataGridView1.BackgroundColor = System.Drawing.Color.White;
			dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle8.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(Location, Column5, Column6, Column7, Column8);
			dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle9.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			dataGridView1.DefaultCellStyle = dataGridViewCellStyle9;
			dataGridView1.Location = new System.Drawing.Point(57, 48);
			dataGridView1.Name = "dataGridView1";
			dataGridView1.RowHeadersVisible = false;
			dataGridView1.Size = new System.Drawing.Size(765, 44);
			dataGridView1.TabIndex = 0;
			Location.HeaderText = "Location";
			Location.Name = "Location";
			Location.Width = 250;
			Column5.HeaderText = "Upper Extremity";
			Column5.Name = "Column5";
			Column5.Width = 120;
			Column6.HeaderText = "Lower Extremity";
			Column6.Name = "Column6";
			Column6.Width = 120;
			Column7.HeaderText = "Trunk";
			Column7.Name = "Column7";
			Column7.Width = 120;
			Column8.HeaderText = "Comments";
			Column8.Name = "Column8";
			Column8.Width = 150;
			tabPage5.Controls.Add(label161);
			tabPage5.Controls.Add(DGRangeofMotion);
			tabPage5.Location = new System.Drawing.Point(4, 25);
			tabPage5.Name = "tabPage5";
			tabPage5.Padding = new System.Windows.Forms.Padding(3);
			tabPage5.Size = new System.Drawing.Size(942, 581);
			tabPage5.TabIndex = 4;
			tabPage5.Text = "Page 5";
			tabPage5.UseVisualStyleBackColor = true;
			DGRangeofMotion.AllowUserToAddRows = false;
			DGRangeofMotion.AllowUserToDeleteRows = false;
			DGRangeofMotion.AllowUserToOrderColumns = true;
			DGRangeofMotion.AllowUserToResizeColumns = false;
			DGRangeofMotion.AllowUserToResizeRows = false;
			DGRangeofMotion.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGRangeofMotion.BackgroundColor = System.Drawing.Color.White;
			dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle10.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			DGRangeofMotion.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
			DGRangeofMotion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGRangeofMotion.Columns.AddRange(Joint, Side, Movement, Limitation, Limitingfactor);
			dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle11.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGRangeofMotion.DefaultCellStyle = dataGridViewCellStyle11;
			DGRangeofMotion.Location = new System.Drawing.Point(58, 77);
			DGRangeofMotion.Name = "DGRangeofMotion";
			DGRangeofMotion.RowHeadersVisible = false;
			DGRangeofMotion.RowTemplate.Height = 80;
			DGRangeofMotion.Size = new System.Drawing.Size(823, 415);
			DGRangeofMotion.TabIndex = 215;
			Joint.HeaderText = "Joint";
			Joint.Name = "Joint";
			Joint.ReadOnly = true;
			Joint.Width = 150;
			Side.HeaderText = "Side";
			Side.Name = "Side";
			Movement.HeaderText = "Movement";
			Movement.Name = "Movement";
			Movement.Width = 170;
			Limitation.HeaderText = "Limitation";
			Limitation.Name = "Limitation";
			Limitation.Width = 200;
			Limitingfactor.HeaderText = "Limiting factor";
			Limitingfactor.Name = "Limitingfactor";
			Limitingfactor.Width = 200;
			tabPage6.Controls.Add(DGLimbLength);
			tabPage6.Controls.Add(DGRangeofMotion2);
			tabPage6.Controls.Add(label69);
			tabPage6.Location = new System.Drawing.Point(4, 25);
			tabPage6.Name = "tabPage6";
			tabPage6.Padding = new System.Windows.Forms.Padding(3);
			tabPage6.Size = new System.Drawing.Size(942, 581);
			tabPage6.TabIndex = 5;
			tabPage6.Text = "Page 6";
			tabPage6.UseVisualStyleBackColor = true;
			DGLimbLength.AllowUserToAddRows = false;
			DGLimbLength.AllowUserToDeleteRows = false;
			DGLimbLength.AllowUserToOrderColumns = true;
			DGLimbLength.AllowUserToResizeColumns = false;
			DGLimbLength.AllowUserToResizeRows = false;
			DGLimbLength.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGLimbLength.BackgroundColor = System.Drawing.Color.White;
			dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle12.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			DGLimbLength.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
			DGLimbLength.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGLimbLength.Columns.AddRange(dataGridViewTextBoxColumn1, LimbRt, LimbLt);
			dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle13.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.White;
			dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGLimbLength.DefaultCellStyle = dataGridViewCellStyle13;
			DGLimbLength.Location = new System.Drawing.Point(212, 341);
			DGLimbLength.Name = "DGLimbLength";
			DGLimbLength.RowHeadersVisible = false;
			DGLimbLength.RowTemplate.Height = 35;
			DGLimbLength.ScrollBars = System.Windows.Forms.ScrollBars.None;
			DGLimbLength.Size = new System.Drawing.Size(394, 97);
			DGLimbLength.TabIndex = 220;
			dataGridViewTextBoxColumn1.HeaderText = "Side";
			dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			dataGridViewTextBoxColumn1.ReadOnly = true;
			dataGridViewTextBoxColumn1.Width = 130;
			LimbRt.HeaderText = "Rt.(cm.) ";
			LimbRt.Name = "LimbRt";
			LimbRt.Width = 130;
			LimbLt.HeaderText = "Lt.(cm.) ";
			LimbLt.Name = "LimbLt";
			LimbLt.Width = 130;
			DGRangeofMotion2.AllowUserToAddRows = false;
			DGRangeofMotion2.AllowUserToDeleteRows = false;
			DGRangeofMotion2.AllowUserToOrderColumns = true;
			DGRangeofMotion2.AllowUserToResizeColumns = false;
			DGRangeofMotion2.AllowUserToResizeRows = false;
			DGRangeofMotion2.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGRangeofMotion2.BackgroundColor = System.Drawing.Color.White;
			dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle14.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			DGRangeofMotion2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
			DGRangeofMotion2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGRangeofMotion2.Columns.AddRange(dataGridViewTextBoxColumn15, Side2, Movement2, Limitation2, Limitingfactor2);
			dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle15.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGRangeofMotion2.DefaultCellStyle = dataGridViewCellStyle15;
			DGRangeofMotion2.Location = new System.Drawing.Point(63, 29);
			DGRangeofMotion2.Name = "DGRangeofMotion2";
			DGRangeofMotion2.RowHeadersVisible = false;
			DGRangeofMotion2.RowTemplate.Height = 80;
			DGRangeofMotion2.Size = new System.Drawing.Size(823, 267);
			DGRangeofMotion2.TabIndex = 219;
			dataGridViewTextBoxColumn15.HeaderText = "Joint";
			dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
			dataGridViewTextBoxColumn15.ReadOnly = true;
			dataGridViewTextBoxColumn15.Width = 150;
			Side2.HeaderText = "Side";
			Side2.Name = "Side2";
			Movement2.HeaderText = "Movement";
			Movement2.Name = "Movement2";
			Movement2.Width = 170;
			Limitation2.HeaderText = "Limitation";
			Limitation2.Name = "Limitation2";
			Limitation2.Width = 200;
			Limitingfactor2.HeaderText = "Limiting factor";
			Limitingfactor2.Name = "Limitingfactor2";
			Limitingfactor2.Width = 200;
			tabPage7.Controls.Add(DGMuscleTone2);
			tabPage7.Controls.Add(DGMuscleTone1);
			tabPage7.Controls.Add(label70);
			tabPage7.Location = new System.Drawing.Point(4, 25);
			tabPage7.Name = "tabPage7";
			tabPage7.Padding = new System.Windows.Forms.Padding(3);
			tabPage7.Size = new System.Drawing.Size(942, 581);
			tabPage7.TabIndex = 6;
			tabPage7.Text = "Page 7";
			tabPage7.UseVisualStyleBackColor = true;
			DGMuscleTone2.AllowUserToAddRows = false;
			DGMuscleTone2.AllowUserToDeleteRows = false;
			DGMuscleTone2.AllowUserToOrderColumns = true;
			DGMuscleTone2.AllowUserToResizeColumns = false;
			DGMuscleTone2.AllowUserToResizeRows = false;
			DGMuscleTone2.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGMuscleTone2.BackgroundColor = System.Drawing.Color.White;
			DGMuscleTone2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGMuscleTone2.Columns.AddRange(dataGridViewTextBoxColumn6, TRT2, TLT2);
			dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle16.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGMuscleTone2.DefaultCellStyle = dataGridViewCellStyle16;
			DGMuscleTone2.Location = new System.Drawing.Point(485, 65);
			DGMuscleTone2.Name = "DGMuscleTone2";
			DGMuscleTone2.RowHeadersVisible = false;
			DGMuscleTone2.RowTemplate.Height = 30;
			DGMuscleTone2.Size = new System.Drawing.Size(355, 345);
			DGMuscleTone2.TabIndex = 220;
			dataGridViewTextBoxColumn6.HeaderText = "Muscles";
			dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
			dataGridViewTextBoxColumn6.ReadOnly = true;
			dataGridViewTextBoxColumn6.Width = 150;
			TRT2.HeaderText = "Rt. ";
			TRT2.Name = "TRT2";
			TLT2.HeaderText = "Lt. ";
			TLT2.Name = "TLT2";
			DGMuscleTone1.AllowUserToAddRows = false;
			DGMuscleTone1.AllowUserToDeleteRows = false;
			DGMuscleTone1.AllowUserToOrderColumns = true;
			DGMuscleTone1.AllowUserToResizeColumns = false;
			DGMuscleTone1.AllowUserToResizeRows = false;
			DGMuscleTone1.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGMuscleTone1.BackgroundColor = System.Drawing.Color.White;
			DGMuscleTone1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGMuscleTone1.Columns.AddRange(Muscles, TRT, TLT);
			dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle17.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGMuscleTone1.DefaultCellStyle = dataGridViewCellStyle17;
			DGMuscleTone1.Location = new System.Drawing.Point(52, 65);
			DGMuscleTone1.Name = "DGMuscleTone1";
			DGMuscleTone1.RowHeadersVisible = false;
			DGMuscleTone1.RowTemplate.Height = 30;
			DGMuscleTone1.Size = new System.Drawing.Size(355, 396);
			DGMuscleTone1.TabIndex = 219;
			Muscles.HeaderText = "Muscles";
			Muscles.Name = "Muscles";
			Muscles.ReadOnly = true;
			Muscles.Width = 150;
			TRT.HeaderText = "Rt. ";
			TRT.Name = "TRT";
			TLT.HeaderText = "Lt. ";
			TLT.Name = "TLT";
			tabPage8.Controls.Add(DGMusclePower2);
			tabPage8.Controls.Add(DGMusclePower1);
			tabPage8.Controls.Add(label71);
			tabPage8.Location = new System.Drawing.Point(4, 25);
			tabPage8.Name = "tabPage8";
			tabPage8.Padding = new System.Windows.Forms.Padding(3);
			tabPage8.Size = new System.Drawing.Size(942, 581);
			tabPage8.TabIndex = 7;
			tabPage8.Text = "Page 8";
			tabPage8.UseVisualStyleBackColor = true;
			DGMusclePower2.AllowUserToAddRows = false;
			DGMusclePower2.AllowUserToDeleteRows = false;
			DGMusclePower2.AllowUserToOrderColumns = true;
			DGMusclePower2.AllowUserToResizeColumns = false;
			DGMusclePower2.AllowUserToResizeRows = false;
			DGMusclePower2.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGMusclePower2.BackgroundColor = System.Drawing.Color.White;
			DGMusclePower2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGMusclePower2.Columns.AddRange(dataGridViewTextBoxColumn12, PRT2, PLT2);
			dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle18.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGMusclePower2.DefaultCellStyle = dataGridViewCellStyle18;
			DGMusclePower2.Location = new System.Drawing.Point(494, 64);
			DGMusclePower2.Name = "DGMusclePower2";
			DGMusclePower2.RowHeadersVisible = false;
			DGMusclePower2.RowTemplate.Height = 30;
			DGMusclePower2.Size = new System.Drawing.Size(355, 395);
			DGMusclePower2.TabIndex = 225;
			dataGridViewTextBoxColumn12.HeaderText = "Muscles";
			dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
			dataGridViewTextBoxColumn12.ReadOnly = true;
			dataGridViewTextBoxColumn12.Width = 150;
			PRT2.HeaderText = "Rt. ";
			PRT2.Name = "PRT2";
			PLT2.HeaderText = "Lt. ";
			PLT2.Name = "PLT2";
			DGMusclePower1.AllowUserToAddRows = false;
			DGMusclePower1.AllowUserToDeleteRows = false;
			DGMusclePower1.AllowUserToOrderColumns = true;
			DGMusclePower1.AllowUserToResizeColumns = false;
			DGMusclePower1.AllowUserToResizeRows = false;
			DGMusclePower1.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGMusclePower1.BackgroundColor = System.Drawing.Color.White;
			DGMusclePower1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGMusclePower1.Columns.AddRange(dataGridViewTextBoxColumn4, PRT, PLT);
			dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle19.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGMusclePower1.DefaultCellStyle = dataGridViewCellStyle19;
			DGMusclePower1.Location = new System.Drawing.Point(80, 64);
			DGMusclePower1.Name = "DGMusclePower1";
			DGMusclePower1.RowHeadersVisible = false;
			DGMusclePower1.RowTemplate.Height = 30;
			DGMusclePower1.Size = new System.Drawing.Size(355, 347);
			DGMusclePower1.TabIndex = 224;
			dataGridViewTextBoxColumn4.HeaderText = "Muscles";
			dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			dataGridViewTextBoxColumn4.ReadOnly = true;
			dataGridViewTextBoxColumn4.Width = 150;
			PRT.HeaderText = "Rt. ";
			PRT.Name = "PRT";
			PLT.HeaderText = "Lt. ";
			PLT.Name = "PLT";
			tabPage9.Controls.Add(Pathological);
			tabPage9.Controls.Add(DGCoordination2);
			tabPage9.Controls.Add(label76);
			tabPage9.Controls.Add(label75);
			tabPage9.Controls.Add(label74);
			tabPage9.Controls.Add(label73);
			tabPage9.Controls.Add(DGCoordination1);
			tabPage9.Controls.Add(DGReflexes);
			tabPage9.Controls.Add(label72);
			tabPage9.Location = new System.Drawing.Point(4, 25);
			tabPage9.Name = "tabPage9";
			tabPage9.Padding = new System.Windows.Forms.Padding(3);
			tabPage9.Size = new System.Drawing.Size(942, 581);
			tabPage9.TabIndex = 8;
			tabPage9.Text = "Page 9";
			tabPage9.UseVisualStyleBackColor = true;
			Pathological.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Pathological.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			Pathological.Location = new System.Drawing.Point(272, 245);
			Pathological.Multiline = true;
			Pathological.Name = "Pathological";
			Pathological.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Pathological.Size = new System.Drawing.Size(365, 26);
			Pathological.TabIndex = 226;
			DGCoordination2.AllowUserToAddRows = false;
			DGCoordination2.AllowUserToDeleteRows = false;
			DGCoordination2.AllowUserToOrderColumns = true;
			DGCoordination2.AllowUserToResizeColumns = false;
			DGCoordination2.AllowUserToResizeRows = false;
			DGCoordination2.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGCoordination2.BackgroundColor = System.Drawing.Color.White;
			DGCoordination2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGCoordination2.Columns.AddRange(Equilibriumtests, Grade);
			dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle20.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGCoordination2.DefaultCellStyle = dataGridViewCellStyle20;
			DGCoordination2.Location = new System.Drawing.Point(449, 324);
			DGCoordination2.Name = "DGCoordination2";
			DGCoordination2.RowHeadersVisible = false;
			DGCoordination2.Size = new System.Drawing.Size(374, 185);
			DGCoordination2.TabIndex = 228;
			Equilibriumtests.HeaderText = "Equilibrium tests";
			Equilibriumtests.Name = "Equilibriumtests";
			Equilibriumtests.ReadOnly = true;
			Equilibriumtests.Width = 300;
			Grade.HeaderText = "Grade";
			Grade.Name = "Grade";
			Grade.Width = 70;
			DGCoordination1.AllowUserToAddRows = false;
			DGCoordination1.AllowUserToDeleteRows = false;
			DGCoordination1.AllowUserToOrderColumns = true;
			DGCoordination1.AllowUserToResizeColumns = false;
			DGCoordination1.AllowUserToResizeRows = false;
			DGCoordination1.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGCoordination1.BackgroundColor = System.Drawing.Color.White;
			DGCoordination1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGCoordination1.Columns.AddRange(NonEquilibriumTests, RT2, LT2);
			dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle21.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGCoordination1.DefaultCellStyle = dataGridViewCellStyle21;
			DGCoordination1.Location = new System.Drawing.Point(55, 324);
			DGCoordination1.Name = "DGCoordination1";
			DGCoordination1.RowHeadersVisible = false;
			DGCoordination1.Size = new System.Drawing.Size(344, 163);
			DGCoordination1.TabIndex = 227;
			NonEquilibriumTests.HeaderText = "Non Equilibrium Tests ";
			NonEquilibriumTests.Name = "NonEquilibriumTests";
			NonEquilibriumTests.ReadOnly = true;
			NonEquilibriumTests.Width = 200;
			RT2.HeaderText = "Rt";
			RT2.Name = "RT2";
			RT2.Width = 70;
			LT2.HeaderText = "Lt";
			LT2.Name = "LT2";
			LT2.Width = 70;
			DGReflexes.AllowUserToAddRows = false;
			DGReflexes.AllowUserToDeleteRows = false;
			DGReflexes.AllowUserToOrderColumns = true;
			DGReflexes.AllowUserToResizeColumns = false;
			DGReflexes.AllowUserToResizeRows = false;
			DGReflexes.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGReflexes.BackgroundColor = System.Drawing.Color.White;
			DGReflexes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGReflexes.Columns.AddRange(Reflex, Left, Right);
			dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle22.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGReflexes.DefaultCellStyle = dataGridViewCellStyle22;
			DGReflexes.Location = new System.Drawing.Point(231, 49);
			DGReflexes.Name = "DGReflexes";
			DGReflexes.RowHeadersVisible = false;
			DGReflexes.ScrollBars = System.Windows.Forms.ScrollBars.None;
			DGReflexes.Size = new System.Drawing.Size(365, 181);
			DGReflexes.TabIndex = 225;
			Reflex.HeaderText = "Reflex";
			Reflex.Name = "Reflex";
			Reflex.ReadOnly = true;
			Reflex.Width = 120;
			Left.HeaderText = "Left";
			Left.Name = "Left";
			Left.Width = 120;
			Right.HeaderText = "Right";
			Right.Name = "Right";
			Right.Width = 120;
			tabPage10.Controls.Add(Reaching);
			tabPage10.Controls.Add(InvoluntaryMovements);
			tabPage10.Controls.Add(AssisstiveDevices);
			tabPage10.Controls.Add(BiomechanicalDeviations);
			tabPage10.Controls.Add(HandFunctions);
			tabPage10.Controls.Add(Grasping);
			tabPage10.Controls.Add(Releasing);
			tabPage10.Controls.Add(Sitting2);
			tabPage10.Controls.Add(Standing2);
			tabPage10.Controls.Add(StepLength);
			tabPage10.Controls.Add(StrideLength);
			tabPage10.Controls.Add(Basewidth);
			tabPage10.Controls.Add(Cadence);
			tabPage10.Controls.Add(Posturee);
			tabPage10.Controls.Add(BalanceReactions);
			tabPage10.Controls.Add(Lying);
			tabPage10.Controls.Add(Standing);
			tabPage10.Controls.Add(Sitting);
			tabPage10.Controls.Add(Balance);
			tabPage10.Controls.Add(label77);
			tabPage10.Controls.Add(label78);
			tabPage10.Controls.Add(label79);
			tabPage10.Controls.Add(label80);
			tabPage10.Controls.Add(label81);
			tabPage10.Controls.Add(label82);
			tabPage10.Controls.Add(label83);
			tabPage10.Controls.Add(label84);
			tabPage10.Controls.Add(label85);
			tabPage10.Controls.Add(label86);
			tabPage10.Controls.Add(label87);
			tabPage10.Controls.Add(label88);
			tabPage10.Controls.Add(label89);
			tabPage10.Controls.Add(label90);
			tabPage10.Controls.Add(label91);
			tabPage10.Controls.Add(label92);
			tabPage10.Controls.Add(label93);
			tabPage10.Controls.Add(label94);
			tabPage10.Controls.Add(label95);
			tabPage10.Controls.Add(label96);
			tabPage10.Location = new System.Drawing.Point(4, 25);
			tabPage10.Name = "tabPage10";
			tabPage10.Padding = new System.Windows.Forms.Padding(3);
			tabPage10.Size = new System.Drawing.Size(942, 581);
			tabPage10.TabIndex = 9;
			tabPage10.Text = "Page 10";
			tabPage10.UseVisualStyleBackColor = true;
			Reaching.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Reaching.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Reaching.Location = new System.Drawing.Point(281, 470);
			Reaching.Multiline = true;
			Reaching.Name = "Reaching";
			Reaching.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Reaching.Size = new System.Drawing.Size(180, 22);
			Reaching.TabIndex = 249;
			InvoluntaryMovements.Anchor = System.Windows.Forms.AnchorStyles.Top;
			InvoluntaryMovements.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			InvoluntaryMovements.Location = new System.Drawing.Point(306, 21);
			InvoluntaryMovements.Multiline = true;
			InvoluntaryMovements.Name = "InvoluntaryMovements";
			InvoluntaryMovements.RightToLeft = System.Windows.Forms.RightToLeft.No;
			InvoluntaryMovements.Size = new System.Drawing.Size(404, 45);
			InvoluntaryMovements.TabIndex = 234;
			AssisstiveDevices.Anchor = System.Windows.Forms.AnchorStyles.Top;
			AssisstiveDevices.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			AssisstiveDevices.Location = new System.Drawing.Point(677, 499);
			AssisstiveDevices.Multiline = true;
			AssisstiveDevices.Name = "AssisstiveDevices";
			AssisstiveDevices.RightToLeft = System.Windows.Forms.RightToLeft.No;
			AssisstiveDevices.Size = new System.Drawing.Size(235, 22);
			AssisstiveDevices.TabIndex = 252;
			BiomechanicalDeviations.Anchor = System.Windows.Forms.AnchorStyles.Top;
			BiomechanicalDeviations.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			BiomechanicalDeviations.Location = new System.Drawing.Point(677, 373);
			BiomechanicalDeviations.Multiline = true;
			BiomechanicalDeviations.Name = "BiomechanicalDeviations";
			BiomechanicalDeviations.RightToLeft = System.Windows.Forms.RightToLeft.No;
			BiomechanicalDeviations.Size = new System.Drawing.Size(235, 22);
			BiomechanicalDeviations.TabIndex = 247;
			HandFunctions.Anchor = System.Windows.Forms.AnchorStyles.Top;
			HandFunctions.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			HandFunctions.Location = new System.Drawing.Point(212, 441);
			HandFunctions.Multiline = true;
			HandFunctions.Name = "HandFunctions";
			HandFunctions.RightToLeft = System.Windows.Forms.RightToLeft.No;
			HandFunctions.Size = new System.Drawing.Size(289, 22);
			HandFunctions.TabIndex = 248;
			Grasping.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Grasping.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Grasping.Location = new System.Drawing.Point(281, 498);
			Grasping.Multiline = true;
			Grasping.Name = "Grasping";
			Grasping.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Grasping.Size = new System.Drawing.Size(180, 22);
			Grasping.TabIndex = 250;
			Releasing.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Releasing.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Releasing.Location = new System.Drawing.Point(677, 467);
			Releasing.Multiline = true;
			Releasing.Name = "Releasing";
			Releasing.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Releasing.Size = new System.Drawing.Size(235, 22);
			Releasing.TabIndex = 251;
			Sitting2.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Sitting2.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Sitting2.Location = new System.Drawing.Point(282, 267);
			Sitting2.Multiline = true;
			Sitting2.Name = "Sitting2";
			Sitting2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Sitting2.Size = new System.Drawing.Size(180, 22);
			Sitting2.TabIndex = 241;
			Standing2.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Standing2.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Standing2.Location = new System.Drawing.Point(677, 238);
			Standing2.Multiline = true;
			Standing2.Name = "Standing2";
			Standing2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Standing2.Size = new System.Drawing.Size(224, 22);
			Standing2.TabIndex = 242;
			StepLength.Anchor = System.Windows.Forms.AnchorStyles.Top;
			StepLength.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			StepLength.Location = new System.Drawing.Point(279, 339);
			StepLength.Multiline = true;
			StepLength.Name = "StepLength";
			StepLength.RightToLeft = System.Windows.Forms.RightToLeft.No;
			StepLength.Size = new System.Drawing.Size(180, 22);
			StepLength.TabIndex = 243;
			StrideLength.Anchor = System.Windows.Forms.AnchorStyles.Top;
			StrideLength.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			StrideLength.Location = new System.Drawing.Point(279, 369);
			StrideLength.Multiline = true;
			StrideLength.Name = "StrideLength";
			StrideLength.RightToLeft = System.Windows.Forms.RightToLeft.No;
			StrideLength.Size = new System.Drawing.Size(180, 22);
			StrideLength.TabIndex = 244;
			Basewidth.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Basewidth.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Basewidth.Location = new System.Drawing.Point(279, 402);
			Basewidth.Multiline = true;
			Basewidth.Name = "Basewidth";
			Basewidth.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Basewidth.Size = new System.Drawing.Size(180, 22);
			Basewidth.TabIndex = 245;
			Cadence.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Cadence.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Cadence.Location = new System.Drawing.Point(677, 340);
			Cadence.Multiline = true;
			Cadence.Name = "Cadence";
			Cadence.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Cadence.Size = new System.Drawing.Size(235, 22);
			Cadence.TabIndex = 246;
			Posturee.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Posturee.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Posturee.Location = new System.Drawing.Point(211, 207);
			Posturee.Multiline = true;
			Posturee.Name = "Posturee";
			Posturee.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Posturee.Size = new System.Drawing.Size(289, 22);
			Posturee.TabIndex = 239;
			BalanceReactions.Anchor = System.Windows.Forms.AnchorStyles.Top;
			BalanceReactions.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			BalanceReactions.Location = new System.Drawing.Point(279, 166);
			BalanceReactions.Multiline = true;
			BalanceReactions.Name = "BalanceReactions";
			BalanceReactions.RightToLeft = System.Windows.Forms.RightToLeft.No;
			BalanceReactions.Size = new System.Drawing.Size(180, 22);
			BalanceReactions.TabIndex = 238;
			Lying.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Lying.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Lying.Location = new System.Drawing.Point(282, 239);
			Lying.Multiline = true;
			Lying.Name = "Lying";
			Lying.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Lying.Size = new System.Drawing.Size(180, 22);
			Lying.TabIndex = 240;
			Standing.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Standing.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Standing.Location = new System.Drawing.Point(279, 137);
			Standing.Multiline = true;
			Standing.Name = "Standing";
			Standing.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Standing.Size = new System.Drawing.Size(180, 22);
			Standing.TabIndex = 237;
			Sitting.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Sitting.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Sitting.Location = new System.Drawing.Point(279, 109);
			Sitting.Multiline = true;
			Sitting.Name = "Sitting";
			Sitting.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Sitting.Size = new System.Drawing.Size(180, 22);
			Sitting.TabIndex = 236;
			Balance.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Balance.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Balance.Location = new System.Drawing.Point(208, 77);
			Balance.Multiline = true;
			Balance.Name = "Balance";
			Balance.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Balance.Size = new System.Drawing.Size(289, 22);
			Balance.TabIndex = 235;
			tabPage11.Controls.Add(Thrombosis);
			tabPage11.Controls.Add(CVSStatus);
			tabPage11.Controls.Add(spinedeformity);
			tabPage11.Controls.Add(Patternofbreathing);
			tabPage11.Controls.Add(Secretions);
			tabPage11.Controls.Add(RSStatus);
			tabPage11.Controls.Add(RESPIRATORYSYSTEM);
			tabPage11.Controls.Add(PressureSoress);
			tabPage11.Controls.Add(IntegSystem);
			tabPage11.Controls.Add(Status);
			tabPage11.Controls.Add(Incontinence);
			tabPage11.Controls.Add(ReflexSympatheticDystrophy);
			tabPage11.Controls.Add(PosturalHypotension);
			tabPage11.Controls.Add(TrophicChanges);
			tabPage11.Controls.Add(Pseudomotor);
			tabPage11.Controls.Add(Otherpathology);
			tabPage11.Controls.Add(Jointmobility);
			tabPage11.Controls.Add(Vasomotor);
			tabPage11.Controls.Add(Subluxations);
			tabPage11.Controls.Add(Contractures);
			tabPage11.Controls.Add(SkinStatus);
			tabPage11.Controls.Add(label123);
			tabPage11.Controls.Add(label122);
			tabPage11.Controls.Add(label121);
			tabPage11.Controls.Add(label120);
			tabPage11.Controls.Add(label119);
			tabPage11.Controls.Add(label118);
			tabPage11.Controls.Add(label117);
			tabPage11.Controls.Add(label97);
			tabPage11.Controls.Add(label98);
			tabPage11.Controls.Add(label99);
			tabPage11.Controls.Add(label100);
			tabPage11.Controls.Add(label101);
			tabPage11.Controls.Add(label102);
			tabPage11.Controls.Add(label103);
			tabPage11.Controls.Add(label104);
			tabPage11.Controls.Add(label105);
			tabPage11.Controls.Add(label106);
			tabPage11.Controls.Add(label107);
			tabPage11.Controls.Add(label108);
			tabPage11.Controls.Add(label109);
			tabPage11.Controls.Add(label110);
			tabPage11.Controls.Add(label111);
			tabPage11.Controls.Add(label112);
			tabPage11.Controls.Add(label113);
			tabPage11.Controls.Add(label114);
			tabPage11.Controls.Add(label115);
			tabPage11.Controls.Add(label116);
			tabPage11.Location = new System.Drawing.Point(4, 25);
			tabPage11.Name = "tabPage11";
			tabPage11.Padding = new System.Windows.Forms.Padding(3);
			tabPage11.Size = new System.Drawing.Size(942, 581);
			tabPage11.TabIndex = 10;
			tabPage11.Text = "Page 11";
			tabPage11.UseVisualStyleBackColor = true;
			Thrombosis.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Thrombosis.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Thrombosis.Location = new System.Drawing.Point(724, 209);
			Thrombosis.Multiline = true;
			Thrombosis.Name = "Thrombosis";
			Thrombosis.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Thrombosis.Size = new System.Drawing.Size(194, 22);
			Thrombosis.TabIndex = 288;
			CVSStatus.Anchor = System.Windows.Forms.AnchorStyles.Top;
			CVSStatus.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			CVSStatus.Location = new System.Drawing.Point(266, 209);
			CVSStatus.Multiline = true;
			CVSStatus.Name = "CVSStatus";
			CVSStatus.RightToLeft = System.Windows.Forms.RightToLeft.No;
			CVSStatus.Size = new System.Drawing.Size(194, 22);
			CVSStatus.TabIndex = 287;
			spinedeformity.Anchor = System.Windows.Forms.AnchorStyles.Top;
			spinedeformity.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			spinedeformity.Location = new System.Drawing.Point(724, 156);
			spinedeformity.Multiline = true;
			spinedeformity.Name = "spinedeformity";
			spinedeformity.RightToLeft = System.Windows.Forms.RightToLeft.No;
			spinedeformity.Size = new System.Drawing.Size(194, 22);
			spinedeformity.TabIndex = 286;
			Patternofbreathing.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Patternofbreathing.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Patternofbreathing.Location = new System.Drawing.Point(724, 129);
			Patternofbreathing.Multiline = true;
			Patternofbreathing.Name = "Patternofbreathing";
			Patternofbreathing.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Patternofbreathing.Size = new System.Drawing.Size(194, 22);
			Patternofbreathing.TabIndex = 285;
			Secretions.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Secretions.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Secretions.Location = new System.Drawing.Point(270, 156);
			Secretions.Multiline = true;
			Secretions.Name = "Secretions";
			Secretions.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Secretions.Size = new System.Drawing.Size(194, 22);
			Secretions.TabIndex = 284;
			RSStatus.Anchor = System.Windows.Forms.AnchorStyles.Top;
			RSStatus.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			RSStatus.Location = new System.Drawing.Point(270, 132);
			RSStatus.Multiline = true;
			RSStatus.Name = "RSStatus";
			RSStatus.RightToLeft = System.Windows.Forms.RightToLeft.No;
			RSStatus.Size = new System.Drawing.Size(194, 22);
			RSStatus.TabIndex = 283;
			RESPIRATORYSYSTEM.Anchor = System.Windows.Forms.AnchorStyles.Top;
			RESPIRATORYSYSTEM.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			RESPIRATORYSYSTEM.Location = new System.Drawing.Point(270, 105);
			RESPIRATORYSYSTEM.Multiline = true;
			RESPIRATORYSYSTEM.Name = "RESPIRATORYSYSTEM";
			RESPIRATORYSYSTEM.RightToLeft = System.Windows.Forms.RightToLeft.No;
			RESPIRATORYSYSTEM.Size = new System.Drawing.Size(194, 22);
			RESPIRATORYSYSTEM.TabIndex = 282;
			PressureSoress.Anchor = System.Windows.Forms.AnchorStyles.Top;
			PressureSoress.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PressureSoress.Location = new System.Drawing.Point(724, 63);
			PressureSoress.Multiline = true;
			PressureSoress.Name = "PressureSoress";
			PressureSoress.RightToLeft = System.Windows.Forms.RightToLeft.No;
			PressureSoress.Size = new System.Drawing.Size(194, 22);
			PressureSoress.TabIndex = 281;
			IntegSystem.Anchor = System.Windows.Forms.AnchorStyles.Top;
			IntegSystem.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			IntegSystem.Location = new System.Drawing.Point(270, 37);
			IntegSystem.Multiline = true;
			IntegSystem.Name = "IntegSystem";
			IntegSystem.RightToLeft = System.Windows.Forms.RightToLeft.No;
			IntegSystem.Size = new System.Drawing.Size(194, 22);
			IntegSystem.TabIndex = 279;
			Status.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Status.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Status.Location = new System.Drawing.Point(411, 358);
			Status.Multiline = true;
			Status.Name = "Status";
			Status.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Status.Size = new System.Drawing.Size(194, 22);
			Status.TabIndex = 294;
			Incontinence.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Incontinence.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Incontinence.Location = new System.Drawing.Point(411, 329);
			Incontinence.Multiline = true;
			Incontinence.Name = "Incontinence";
			Incontinence.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Incontinence.Size = new System.Drawing.Size(194, 22);
			Incontinence.TabIndex = 293;
			ReflexSympatheticDystrophy.Anchor = System.Windows.Forms.AnchorStyles.Top;
			ReflexSympatheticDystrophy.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			ReflexSympatheticDystrophy.Location = new System.Drawing.Point(701, 434);
			ReflexSympatheticDystrophy.Multiline = true;
			ReflexSympatheticDystrophy.Name = "ReflexSympatheticDystrophy";
			ReflexSympatheticDystrophy.RightToLeft = System.Windows.Forms.RightToLeft.No;
			ReflexSympatheticDystrophy.Size = new System.Drawing.Size(194, 22);
			ReflexSympatheticDystrophy.TabIndex = 299;
			PosturalHypotension.Anchor = System.Windows.Forms.AnchorStyles.Top;
			PosturalHypotension.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			PosturalHypotension.Location = new System.Drawing.Point(701, 406);
			PosturalHypotension.Multiline = true;
			PosturalHypotension.Name = "PosturalHypotension";
			PosturalHypotension.RightToLeft = System.Windows.Forms.RightToLeft.No;
			PosturalHypotension.Size = new System.Drawing.Size(194, 22);
			PosturalHypotension.TabIndex = 298;
			TrophicChanges.Anchor = System.Windows.Forms.AnchorStyles.Top;
			TrophicChanges.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			TrophicChanges.Location = new System.Drawing.Point(256, 463);
			TrophicChanges.Multiline = true;
			TrophicChanges.Name = "TrophicChanges";
			TrophicChanges.RightToLeft = System.Windows.Forms.RightToLeft.No;
			TrophicChanges.Size = new System.Drawing.Size(194, 22);
			TrophicChanges.TabIndex = 297;
			Pseudomotor.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Pseudomotor.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Pseudomotor.Location = new System.Drawing.Point(256, 438);
			Pseudomotor.Multiline = true;
			Pseudomotor.Name = "Pseudomotor";
			Pseudomotor.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Pseudomotor.Size = new System.Drawing.Size(194, 22);
			Pseudomotor.TabIndex = 296;
			Otherpathology.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Otherpathology.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Otherpathology.Location = new System.Drawing.Point(730, 292);
			Otherpathology.Multiline = true;
			Otherpathology.Name = "Otherpathology";
			Otherpathology.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Otherpathology.Size = new System.Drawing.Size(194, 22);
			Otherpathology.TabIndex = 292;
			Jointmobility.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Jointmobility.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Jointmobility.Location = new System.Drawing.Point(730, 267);
			Jointmobility.Multiline = true;
			Jointmobility.Name = "Jointmobility";
			Jointmobility.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Jointmobility.Size = new System.Drawing.Size(194, 22);
			Jointmobility.TabIndex = 291;
			Vasomotor.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Vasomotor.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Vasomotor.Location = new System.Drawing.Point(256, 410);
			Vasomotor.Multiline = true;
			Vasomotor.Name = "Vasomotor";
			Vasomotor.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Vasomotor.Size = new System.Drawing.Size(194, 22);
			Vasomotor.TabIndex = 295;
			Subluxations.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Subluxations.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Subluxations.Location = new System.Drawing.Point(266, 292);
			Subluxations.Multiline = true;
			Subluxations.Name = "Subluxations";
			Subluxations.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Subluxations.Size = new System.Drawing.Size(194, 22);
			Subluxations.TabIndex = 290;
			Contractures.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Contractures.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Contractures.Location = new System.Drawing.Point(266, 267);
			Contractures.Multiline = true;
			Contractures.Name = "Contractures";
			Contractures.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Contractures.Size = new System.Drawing.Size(194, 22);
			Contractures.TabIndex = 289;
			SkinStatus.Anchor = System.Windows.Forms.AnchorStyles.Top;
			SkinStatus.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			SkinStatus.Location = new System.Drawing.Point(270, 65);
			SkinStatus.Multiline = true;
			SkinStatus.Name = "SkinStatus";
			SkinStatus.RightToLeft = System.Windows.Forms.RightToLeft.No;
			SkinStatus.Size = new System.Drawing.Size(194, 22);
			SkinStatus.TabIndex = 280;
			tabPage12.Controls.Add(InvestigationFindings);
			tabPage12.Controls.Add(Item17);
			tabPage12.Controls.Add(Item16);
			tabPage12.Controls.Add(Item15);
			tabPage12.Controls.Add(Item10);
			tabPage12.Controls.Add(Item9);
			tabPage12.Controls.Add(Item8);
			tabPage12.Controls.Add(Item11);
			tabPage12.Controls.Add(Evaluation5);
			tabPage12.Controls.Add(Item13);
			tabPage12.Controls.Add(Item14);
			tabPage12.Controls.Add(Evaluation4);
			tabPage12.Controls.Add(Item2);
			tabPage12.Controls.Add(Item3);
			tabPage12.Controls.Add(Item5);
			tabPage12.Controls.Add(Evaluation2);
			tabPage12.Controls.Add(Item6);
			tabPage12.Controls.Add(Item7);
			tabPage12.Controls.Add(Evaluation3);
			tabPage12.Controls.Add(Evaluation6);
			tabPage12.Controls.Add(Item4);
			tabPage12.Controls.Add(Item12);
			tabPage12.Controls.Add(Item1);
			tabPage12.Controls.Add(Evaluation1);
			tabPage12.Controls.Add(label124);
			tabPage12.Controls.Add(label125);
			tabPage12.Controls.Add(label126);
			tabPage12.Controls.Add(label127);
			tabPage12.Controls.Add(label128);
			tabPage12.Controls.Add(label129);
			tabPage12.Controls.Add(label130);
			tabPage12.Controls.Add(label131);
			tabPage12.Controls.Add(label132);
			tabPage12.Controls.Add(label133);
			tabPage12.Controls.Add(label134);
			tabPage12.Controls.Add(label135);
			tabPage12.Controls.Add(label136);
			tabPage12.Controls.Add(label137);
			tabPage12.Controls.Add(label138);
			tabPage12.Controls.Add(label139);
			tabPage12.Controls.Add(label140);
			tabPage12.Controls.Add(label141);
			tabPage12.Controls.Add(label142);
			tabPage12.Controls.Add(label143);
			tabPage12.Controls.Add(label144);
			tabPage12.Controls.Add(label145);
			tabPage12.Controls.Add(label146);
			tabPage12.Controls.Add(label147);
			tabPage12.Controls.Add(label148);
			tabPage12.Font = new System.Drawing.Font("Times New Roman", 12.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			tabPage12.Location = new System.Drawing.Point(4, 25);
			tabPage12.Name = "tabPage12";
			tabPage12.Padding = new System.Windows.Forms.Padding(3);
			tabPage12.Size = new System.Drawing.Size(942, 581);
			tabPage12.TabIndex = 11;
			tabPage12.Text = "Page 12";
			tabPage12.UseVisualStyleBackColor = true;
			InvestigationFindings.Anchor = System.Windows.Forms.AnchorStyles.Top;
			InvestigationFindings.Location = new System.Drawing.Point(258, 515);
			InvestigationFindings.Multiline = true;
			InvestigationFindings.Name = "InvestigationFindings";
			InvestigationFindings.Size = new System.Drawing.Size(544, 22);
			InvestigationFindings.TabIndex = 312;
			Item17.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item17.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item17.Location = new System.Drawing.Point(434, 476);
			Item17.Multiline = true;
			Item17.Name = "Item17";
			Item17.Size = new System.Drawing.Size(178, 22);
			Item17.TabIndex = 311;
			Item16.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item16.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item16.Location = new System.Drawing.Point(434, 450);
			Item16.Multiline = true;
			Item16.Name = "Item16";
			Item16.Size = new System.Drawing.Size(178, 22);
			Item16.TabIndex = 310;
			Item15.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item15.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item15.Location = new System.Drawing.Point(445, 422);
			Item15.Multiline = true;
			Item15.Name = "Item15";
			Item15.Size = new System.Drawing.Size(155, 22);
			Item15.TabIndex = 309;
			Item10.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item10.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item10.Location = new System.Drawing.Point(285, 281);
			Item10.Multiline = true;
			Item10.Name = "Item10";
			Item10.Size = new System.Drawing.Size(193, 22);
			Item10.TabIndex = 301;
			Item9.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item9.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item9.Location = new System.Drawing.Point(285, 253);
			Item9.Multiline = true;
			Item9.Name = "Item9";
			Item9.Size = new System.Drawing.Size(193, 22);
			Item9.TabIndex = 300;
			Item8.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item8.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item8.Location = new System.Drawing.Point(285, 225);
			Item8.Multiline = true;
			Item8.Name = "Item8";
			Item8.Size = new System.Drawing.Size(191, 22);
			Item8.TabIndex = 299;
			Item11.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item11.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item11.Location = new System.Drawing.Point(734, 226);
			Item11.Multiline = true;
			Item11.Name = "Item11";
			Item11.Size = new System.Drawing.Size(193, 22);
			Item11.TabIndex = 303;
			Evaluation5.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Evaluation5.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Evaluation5.Location = new System.Drawing.Point(286, 309);
			Evaluation5.Multiline = true;
			Evaluation5.Name = "Evaluation5";
			Evaluation5.Size = new System.Drawing.Size(195, 22);
			Evaluation5.TabIndex = 305;
			Item13.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item13.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item13.Location = new System.Drawing.Point(288, 343);
			Item13.Multiline = true;
			Item13.Name = "Item13";
			Item13.Size = new System.Drawing.Size(193, 22);
			Item13.TabIndex = 306;
			Item14.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item14.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item14.Location = new System.Drawing.Point(286, 369);
			Item14.Multiline = true;
			Item14.Name = "Item14";
			Item14.Size = new System.Drawing.Size(195, 22);
			Item14.TabIndex = 307;
			Evaluation4.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Evaluation4.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Evaluation4.Location = new System.Drawing.Point(734, 196);
			Evaluation4.Multiline = true;
			Evaluation4.Name = "Evaluation4";
			Evaluation4.Size = new System.Drawing.Size(193, 22);
			Evaluation4.TabIndex = 302;
			Item2.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item2.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item2.Location = new System.Drawing.Point(281, 94);
			Item2.Multiline = true;
			Item2.Name = "Item2";
			Item2.Size = new System.Drawing.Size(191, 22);
			Item2.TabIndex = 291;
			Item3.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item3.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item3.Location = new System.Drawing.Point(281, 117);
			Item3.Multiline = true;
			Item3.Name = "Item3";
			Item3.Size = new System.Drawing.Size(191, 22);
			Item3.TabIndex = 292;
			Item5.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item5.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item5.Location = new System.Drawing.Point(281, 166);
			Item5.Multiline = true;
			Item5.Name = "Item5";
			Item5.Size = new System.Drawing.Size(191, 22);
			Item5.TabIndex = 294;
			Evaluation2.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Evaluation2.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Evaluation2.Location = new System.Drawing.Point(736, 43);
			Evaluation2.Multiline = true;
			Evaluation2.Name = "Evaluation2";
			Evaluation2.Size = new System.Drawing.Size(191, 22);
			Evaluation2.TabIndex = 295;
			Item6.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item6.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item6.Location = new System.Drawing.Point(736, 72);
			Item6.Multiline = true;
			Item6.Name = "Item6";
			Item6.Size = new System.Drawing.Size(193, 22);
			Item6.TabIndex = 296;
			Item7.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item7.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item7.Location = new System.Drawing.Point(734, 100);
			Item7.Multiline = true;
			Item7.Name = "Item7";
			Item7.Size = new System.Drawing.Size(195, 22);
			Item7.TabIndex = 297;
			Evaluation3.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Evaluation3.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Evaluation3.Location = new System.Drawing.Point(283, 196);
			Evaluation3.Multiline = true;
			Evaluation3.Name = "Evaluation3";
			Evaluation3.Size = new System.Drawing.Size(195, 22);
			Evaluation3.TabIndex = 298;
			Evaluation6.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Evaluation6.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Evaluation6.Location = new System.Drawing.Point(422, 397);
			Evaluation6.Multiline = true;
			Evaluation6.Name = "Evaluation6";
			Evaluation6.Size = new System.Drawing.Size(178, 22);
			Evaluation6.TabIndex = 308;
			Item4.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item4.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item4.Location = new System.Drawing.Point(281, 142);
			Item4.Multiline = true;
			Item4.Name = "Item4";
			Item4.Size = new System.Drawing.Size(191, 22);
			Item4.TabIndex = 293;
			Item12.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item12.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item12.Location = new System.Drawing.Point(736, 253);
			Item12.Multiline = true;
			Item12.Name = "Item12";
			Item12.Size = new System.Drawing.Size(193, 22);
			Item12.TabIndex = 304;
			Item1.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Item1.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Item1.Location = new System.Drawing.Point(281, 68);
			Item1.Multiline = true;
			Item1.Name = "Item1";
			Item1.Size = new System.Drawing.Size(191, 22);
			Item1.TabIndex = 290;
			Evaluation1.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Evaluation1.Font = new System.Drawing.Font("Times New Roman", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Evaluation1.Location = new System.Drawing.Point(281, 43);
			Evaluation1.Multiline = true;
			Evaluation1.Name = "Evaluation1";
			Evaluation1.Size = new System.Drawing.Size(191, 22);
			Evaluation1.TabIndex = 289;
			tabPage13.Controls.Add(DGProblemList);
			tabPage13.Controls.Add(Devicescomb);
			tabPage13.Controls.Add(Longterm);
			tabPage13.Controls.Add(Goals);
			tabPage13.Controls.Add(Shortterm);
			tabPage13.Controls.Add(FunctionalDiagnosis);
			tabPage13.Controls.Add(label155);
			tabPage13.Controls.Add(label154);
			tabPage13.Controls.Add(label153);
			tabPage13.Controls.Add(label149);
			tabPage13.Controls.Add(label150);
			tabPage13.Controls.Add(label151);
			tabPage13.Controls.Add(label152);
			tabPage13.Location = new System.Drawing.Point(4, 25);
			tabPage13.Name = "tabPage13";
			tabPage13.Padding = new System.Windows.Forms.Padding(3);
			tabPage13.Size = new System.Drawing.Size(942, 581);
			tabPage13.TabIndex = 12;
			tabPage13.Text = "Page 13";
			tabPage13.UseVisualStyleBackColor = true;
			DGProblemList.AllowUserToAddRows = false;
			DGProblemList.AllowUserToDeleteRows = false;
			DGProblemList.AllowUserToOrderColumns = true;
			DGProblemList.AllowUserToResizeColumns = false;
			DGProblemList.AllowUserToResizeRows = false;
			DGProblemList.Anchor = System.Windows.Forms.AnchorStyles.Top;
			DGProblemList.BackgroundColor = System.Drawing.Color.White;
			DGProblemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			DGProblemList.Columns.AddRange(Sl, Impairment, FunctionalLimitation);
			dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle23.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.ControlLightLight;
			dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			DGProblemList.DefaultCellStyle = dataGridViewCellStyle23;
			DGProblemList.Location = new System.Drawing.Point(96, 50);
			DGProblemList.Name = "DGProblemList";
			DGProblemList.RowHeadersVisible = false;
			DGProblemList.ScrollBars = System.Windows.Forms.ScrollBars.None;
			DGProblemList.Size = new System.Drawing.Size(652, 164);
			DGProblemList.TabIndex = 302;
			Sl.HeaderText = "Sl";
			Sl.Name = "Sl";
			Sl.Width = 50;
			Impairment.HeaderText = "Impairment";
			Impairment.Name = "Impairment";
			Impairment.Width = 300;
			FunctionalLimitation.HeaderText = "Functional Limitation";
			FunctionalLimitation.Name = "FunctionalLimitation";
			FunctionalLimitation.Width = 300;
			Devicescomb.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Devicescomb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			Devicescomb.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			Devicescomb.FormattingEnabled = true;
			Devicescomb.ItemHeight = 19;
			Devicescomb.Location = new System.Drawing.Point(178, 453);
			Devicescomb.Name = "Devicescomb";
			Devicescomb.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Devicescomb.Size = new System.Drawing.Size(208, 27);
			Devicescomb.TabIndex = 306;
			Longterm.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Longterm.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			Longterm.Location = new System.Drawing.Point(401, 394);
			Longterm.Multiline = true;
			Longterm.Name = "Longterm";
			Longterm.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Longterm.Size = new System.Drawing.Size(248, 39);
			Longterm.TabIndex = 307;
			Goals.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Goals.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			Goals.Location = new System.Drawing.Point(154, 322);
			Goals.Multiline = true;
			Goals.Name = "Goals";
			Goals.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Goals.Size = new System.Drawing.Size(222, 35);
			Goals.TabIndex = 305;
			Shortterm.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Shortterm.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			Shortterm.Location = new System.Drawing.Point(104, 392);
			Shortterm.Multiline = true;
			Shortterm.Name = "Shortterm";
			Shortterm.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Shortterm.Size = new System.Drawing.Size(248, 41);
			Shortterm.TabIndex = 306;
			FunctionalDiagnosis.Anchor = System.Windows.Forms.AnchorStyles.Top;
			FunctionalDiagnosis.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			FunctionalDiagnosis.Location = new System.Drawing.Point(267, 229);
			FunctionalDiagnosis.Multiline = true;
			FunctionalDiagnosis.Name = "FunctionalDiagnosis";
			FunctionalDiagnosis.RightToLeft = System.Windows.Forms.RightToLeft.No;
			FunctionalDiagnosis.Size = new System.Drawing.Size(522, 34);
			FunctionalDiagnosis.TabIndex = 304;
			update.Anchor = System.Windows.Forms.AnchorStyles.None;
			update.Enabled = false;
			update.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			update.Location = new System.Drawing.Point(360, 763);
			update.Name = "update";
			update.Size = new System.Drawing.Size(109, 33);
			update.TabIndex = 189;
			update.Text = "Update";
			update.UseVisualStyleBackColor = true;
			update.Click += new System.EventHandler(update_Click);
			save.Anchor = System.Windows.Forms.AnchorStyles.None;
			save.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			save.Location = new System.Drawing.Point(401, 618);
			save.Name = "save";
			save.Size = new System.Drawing.Size(118, 34);
			save.TabIndex = 188;
			save.Text = "Save";
			save.UseVisualStyleBackColor = true;
			save.Click += new System.EventHandler(save_Click);
			birthDateDateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
			birthDateDateTimePicker.CustomFormat = "dd/MM/yyyy";
			birthDateDateTimePicker.Enabled = false;
			birthDateDateTimePicker.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			birthDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			birthDateDateTimePicker.Location = new System.Drawing.Point(796, -119);
			birthDateDateTimePicker.Name = "birthDateDateTimePicker";
			birthDateDateTimePicker.RightToLeft = System.Windows.Forms.RightToLeft.No;
			birthDateDateTimePicker.RightToLeftLayout = true;
			birthDateDateTimePicker.Size = new System.Drawing.Size(51, 26);
			birthDateDateTimePicker.TabIndex = 184;
			birthDateDateTimePicker.Visible = false;
			birthDateDateTimePicker.ValueChanged += new System.EventHandler(birthDateDateTimePicker_ValueChanged);
			sqlSelectCommand1.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[53]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
					new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
					new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
					new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
					new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
					new System.Data.Common.DataColumnMapping("Implant", "Implant"),
					new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
					new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers"),
					new System.Data.Common.DataColumnMapping("DoctoreName", "DoctoreName"),
					new System.Data.Common.DataColumnMapping("NextVisit", "NextVisit"),
					new System.Data.Common.DataColumnMapping("Accept", "Accept"),
					new System.Data.Common.DataColumnMapping("Taqweem", "Taqweem"),
					new System.Data.Common.DataColumnMapping("Photo", "Photo"),
					new System.Data.Common.DataColumnMapping("BloodType", "BloodType"),
					new System.Data.Common.DataColumnMapping("Active", "Active"),
					new System.Data.Common.DataColumnMapping("FileNo", "FileNo"),
					new System.Data.Common.DataColumnMapping("Patient", "Patient"),
					new System.Data.Common.DataColumnMapping("Facebook", "Facebook"),
					new System.Data.Common.DataColumnMapping("Adv", "Adv"),
					new System.Data.Common.DataColumnMapping("FormerPatient", "FormerPatient"),
					new System.Data.Common.DataColumnMapping("Discount", "Discount"),
					new System.Data.Common.DataColumnMapping("Without", "Without"),
					new System.Data.Common.DataColumnMapping("Doctor", "Doctor"),
					new System.Data.Common.DataColumnMapping("DoctorId", "DoctorId"),
					new System.Data.Common.DataColumnMapping("nationalID", "nationalID"),
					new System.Data.Common.DataColumnMapping("Dariba", "Dariba")
				})
			});
			sqlCommand1.CommandText = "SELECT        neurological_physiotherapy.*\r\nFROM            neurological_physiotherapy";
			sqlCommand1.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlDataAdapter2.DeleteCommand = sqlDeleteCommand;
			sqlDataAdapter2.InsertCommand = sqlInsertCommand;
			sqlDataAdapter2.SelectCommand = sqlCommand1;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "neurological_physiotherapy", new System.Data.Common.DataColumnMapping[131]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("PatientID", "PatientID"),
					new System.Data.Common.DataColumnMapping("IPOP", "IPOP"),
					new System.Data.Common.DataColumnMapping("Handedness", "Handedness"),
					new System.Data.Common.DataColumnMapping("Occupation", "Occupation"),
					new System.Data.Common.DataColumnMapping("Referredby", "Referredby"),
					new System.Data.Common.DataColumnMapping("ChiefComplaints", "ChiefComplaints"),
					new System.Data.Common.DataColumnMapping("PastMedicalHistory", "PastMedicalHistory"),
					new System.Data.Common.DataColumnMapping("PersonalHistory", "PersonalHistory"),
					new System.Data.Common.DataColumnMapping("FamilyHistory", "FamilyHistory"),
					new System.Data.Common.DataColumnMapping("SocioeconomicHistory", "SocioeconomicHistory"),
					new System.Data.Common.DataColumnMapping("SymptomsHistory", "SymptomsHistory"),
					new System.Data.Common.DataColumnMapping("Sidee", "Sidee"),
					new System.Data.Common.DataColumnMapping("Site", "Site"),
					new System.Data.Common.DataColumnMapping("Onset", "Onset"),
					new System.Data.Common.DataColumnMapping("Duration", "Duration"),
					new System.Data.Common.DataColumnMapping("Typee", "Typee"),
					new System.Data.Common.DataColumnMapping("Severity", "Severity"),
					new System.Data.Common.DataColumnMapping("AggravatingFactors", "AggravatingFactors"),
					new System.Data.Common.DataColumnMapping("RelievingFactors", "RelievingFactors"),
					new System.Data.Common.DataColumnMapping("DGVTemperature", "DGVTemperature"),
					new System.Data.Common.DataColumnMapping("DGVBloodPressure", "DGVBloodPressure"),
					new System.Data.Common.DataColumnMapping("DGVHeartRate", "DGVHeartRate"),
					new System.Data.Common.DataColumnMapping("DGVRespiratoryRate", "DGVRespiratoryRate"),
					new System.Data.Common.DataColumnMapping("Attitudeoflimbs", "Attitudeoflimbs"),
					new System.Data.Common.DataColumnMapping("Built", "Built"),
					new System.Data.Common.DataColumnMapping("Posture", "Posture"),
					new System.Data.Common.DataColumnMapping("Gait", "Gait"),
					new System.Data.Common.DataColumnMapping("PatternofMovement", "PatternofMovement"),
					new System.Data.Common.DataColumnMapping("ModeofVentilation", "ModeofVentilation"),
					new System.Data.Common.DataColumnMapping("Respiration", "Respiration"),
					new System.Data.Common.DataColumnMapping("Oedema", "Oedema"),
					new System.Data.Common.DataColumnMapping("MuscleWasting", "MuscleWasting"),
					new System.Data.Common.DataColumnMapping("PressureSores", "PressureSores"),
					new System.Data.Common.DataColumnMapping("Deformity", "Deformity"),
					new System.Data.Common.DataColumnMapping("Wounds", "Wounds"),
					new System.Data.Common.DataColumnMapping("ExternalAppliances", "ExternalAppliances"),
					new System.Data.Common.DataColumnMapping("Warmth", "Warmth"),
					new System.Data.Common.DataColumnMapping("Tenderness", "Tenderness"),
					new System.Data.Common.DataColumnMapping("Tone", "Tone"),
					new System.Data.Common.DataColumnMapping("Swelling", "Swelling"),
					new System.Data.Common.DataColumnMapping("Consciousness", "Consciousness"),
					new System.Data.Common.DataColumnMapping("Orientation", "Orientation"),
					new System.Data.Common.DataColumnMapping("Person", "Person"),
					new System.Data.Common.DataColumnMapping("Place", "Place"),
					new System.Data.Common.DataColumnMapping("Time", "Time"),
					new System.Data.Common.DataColumnMapping("Memory", "Memory"),
					new System.Data.Common.DataColumnMapping("Immediate", "Immediate"),
					new System.Data.Common.DataColumnMapping("Recent", "Recent"),
					new System.Data.Common.DataColumnMapping("Remote", "Remote"),
					new System.Data.Common.DataColumnMapping("Verbal", "Verbal"),
					new System.Data.Common.DataColumnMapping("Visual", "Visual"),
					new System.Data.Common.DataColumnMapping("Communication", "Communication"),
					new System.Data.Common.DataColumnMapping("Cognition", "Cognition"),
					new System.Data.Common.DataColumnMapping("FundofKnowledge", "FundofKnowledge"),
					new System.Data.Common.DataColumnMapping("Calculation", "Calculation"),
					new System.Data.Common.DataColumnMapping("ProverbInterpretation", "ProverbInterpretation"),
					new System.Data.Common.DataColumnMapping("Attention", "Attention"),
					new System.Data.Common.DataColumnMapping("EmotionalStatus", "EmotionalStatus"),
					new System.Data.Common.DataColumnMapping("Perception", "Perception"),
					new System.Data.Common.DataColumnMapping("Imaging", "Imaging"),
					new System.Data.Common.DataColumnMapping("AgnosiasApraxias", "AgnosiasApraxias"),
					new System.Data.Common.DataColumnMapping("SpecialSenses", "SpecialSenses"),
					new System.Data.Common.DataColumnMapping("DGOlfactory", "DGOlfactory"),
					new System.Data.Common.DataColumnMapping("DGOptic", "DGOptic"),
					new System.Data.Common.DataColumnMapping("DGOculomotor", "DGOculomotor"),
					new System.Data.Common.DataColumnMapping("DGTrochlear", "DGTrochlear"),
					new System.Data.Common.DataColumnMapping("DGTrigeminal", "DGTrigeminal"),
					new System.Data.Common.DataColumnMapping("DGAbducent", "DGAbducent"),
					new System.Data.Common.DataColumnMapping("DGFacial", "DGFacial"),
					new System.Data.Common.DataColumnMapping("DGVestibuloCochlear", "DGVestibuloCochlear"),
					new System.Data.Common.DataColumnMapping("DGGlossopharyngeal", "DGGlossopharyngeal"),
					new System.Data.Common.DataColumnMapping("DGVagus", "DGVagus"),
					new System.Data.Common.DataColumnMapping("DGAccessory", "DGAccessory"),
					new System.Data.Common.DataColumnMapping("DGHypoglossal", "DGHypoglossal"),
					new System.Data.Common.DataColumnMapping("MOTORSYSTEM", "MOTORSYSTEM"),
					new System.Data.Common.DataColumnMapping("DGArmR", "DGArmR"),
					new System.Data.Common.DataColumnMapping("DGArmL", "DGArmL"),
					new System.Data.Common.DataColumnMapping("DGForearmR", "DGForearmR"),
					new System.Data.Common.DataColumnMapping("DGForearmL", "DGForearmL"),
					new System.Data.Common.DataColumnMapping("DGThighR", "DGThighR"),
					new System.Data.Common.DataColumnMapping("DGThighL", "DGThighL"),
					new System.Data.Common.DataColumnMapping("DGCalfR", "DGCalfR"),
					new System.Data.Common.DataColumnMapping("DGCalfL", "DGCalfL"),
					new System.Data.Common.DataColumnMapping("DGUpperLimbR", "DGUpperLimbR"),
					new System.Data.Common.DataColumnMapping("DGUpperLimbL", "DGUpperLimbL"),
					new System.Data.Common.DataColumnMapping("DGLowerLimbR", "DGLowerLimbR"),
					new System.Data.Common.DataColumnMapping("DGLowerLimbL", "DGLowerLimbL"),
					new System.Data.Common.DataColumnMapping("DGTrueRt", "DGTrueRt"),
					new System.Data.Common.DataColumnMapping("DGTrueLt", "DGTrueLt"),
					new System.Data.Common.DataColumnMapping("DGApparentRt", "DGApparentRt"),
					new System.Data.Common.DataColumnMapping("DGApparentLt", "DGApparentLt"),
					new System.Data.Common.DataColumnMapping("DGReflexAbdominalL", "DGReflexAbdominalL"),
					new System.Data.Common.DataColumnMapping("DGReflexAbdominalR", "DGReflexAbdominalR"),
					new System.Data.Common.DataColumnMapping("DGReflexPlantarL", "DGReflexPlantarL"),
					new System.Data.Common.DataColumnMapping("DGReflexPlantarR", "DGReflexPlantarR"),
					new System.Data.Common.DataColumnMapping("DGReflexBicepsL", "DGReflexBicepsL"),
					new System.Data.Common.DataColumnMapping("DGReflexBicepsR", "DGReflexBicepsR"),
					new System.Data.Common.DataColumnMapping("DGReflexBrachioradialisL", "DGReflexBrachioradialisL"),
					new System.Data.Common.DataColumnMapping("DGReflexBrachioradialisR", "DGReflexBrachioradialisR"),
					new System.Data.Common.DataColumnMapping("DGReflexTricepsL", "DGReflexTricepsL"),
					new System.Data.Common.DataColumnMapping("DGReflexTricepsR", "DGReflexTricepsR"),
					new System.Data.Common.DataColumnMapping("DGReflexKneeL", "DGReflexKneeL"),
					new System.Data.Common.DataColumnMapping("DGReflexKneeR", "DGReflexKneeR"),
					new System.Data.Common.DataColumnMapping("DGReflexAnkleL", "DGReflexAnkleL"),
					new System.Data.Common.DataColumnMapping("DGReflexAnkleR", "DGReflexAnkleR"),
					new System.Data.Common.DataColumnMapping("Pathological", "Pathological"),
					new System.Data.Common.DataColumnMapping("InvoluntaryMovements", "InvoluntaryMovements"),
					new System.Data.Common.DataColumnMapping("Balance", "Balance"),
					new System.Data.Common.DataColumnMapping("Sitting", "Sitting"),
					new System.Data.Common.DataColumnMapping("Standing", "Standing"),
					new System.Data.Common.DataColumnMapping("BalanceReactions", "BalanceReactions"),
					new System.Data.Common.DataColumnMapping("Posturee", "Posturee"),
					new System.Data.Common.DataColumnMapping("Lying", "Lying"),
					new System.Data.Common.DataColumnMapping("Sitting2", "Sitting2"),
					new System.Data.Common.DataColumnMapping("Standing2", "Standing2"),
					new System.Data.Common.DataColumnMapping("StepLength", "StepLength"),
					new System.Data.Common.DataColumnMapping("StrideLength", "StrideLength"),
					new System.Data.Common.DataColumnMapping("Basewidth", "Basewidth"),
					new System.Data.Common.DataColumnMapping("Cadence", "Cadence"),
					new System.Data.Common.DataColumnMapping("BiomechanicalDeviations", "BiomechanicalDeviations"),
					new System.Data.Common.DataColumnMapping("HandFunctions", "HandFunctions"),
					new System.Data.Common.DataColumnMapping("Reaching", "Reaching"),
					new System.Data.Common.DataColumnMapping("Grasping", "Grasping"),
					new System.Data.Common.DataColumnMapping("Releasing", "Releasing"),
					new System.Data.Common.DataColumnMapping("AssisstiveDevices", "AssisstiveDevices"),
					new System.Data.Common.DataColumnMapping("Functional Diagnosis", "Functional Diagnosis"),
					new System.Data.Common.DataColumnMapping("Goals", "Goals"),
					new System.Data.Common.DataColumnMapping("Short term", "Short term"),
					new System.Data.Common.DataColumnMapping("Long term", "Long term"),
					new System.Data.Common.DataColumnMapping("TreatmentID", "TreatmentID")
				})
			});
			sqlDataAdapter2.UpdateCommand = sqlUpdateCommand;
			sqlDeleteCommand.CommandText = "DELETE FROM [neurological_physiotherapy] WHERE (([ID] = @Original_ID) AND ([PatientID] = @Original_PatientID))";
			sqlDeleteCommand.Connection = sqlConnection2;
			sqlDeleteCommand.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientID", System.Data.DataRowVersion.Original, null)
			});
			sqlInsertCommand.CommandText = resources.GetString("sqlInsertCommand.CommandText");
			sqlInsertCommand.Connection = sqlConnection2;
			sqlInsertCommand.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[130]
			{
				new System.Data.SqlClient.SqlParameter("@PatientID", System.Data.SqlDbType.Int, 0, "PatientID"),
				new System.Data.SqlClient.SqlParameter("@IPOP", System.Data.SqlDbType.NVarChar, 0, "IPOP"),
				new System.Data.SqlClient.SqlParameter("@Handedness", System.Data.SqlDbType.NVarChar, 0, "Handedness"),
				new System.Data.SqlClient.SqlParameter("@Occupation", System.Data.SqlDbType.NVarChar, 0, "Occupation"),
				new System.Data.SqlClient.SqlParameter("@Referredby", System.Data.SqlDbType.NVarChar, 0, "Referredby"),
				new System.Data.SqlClient.SqlParameter("@ChiefComplaints", System.Data.SqlDbType.NVarChar, 0, "ChiefComplaints"),
				new System.Data.SqlClient.SqlParameter("@PastMedicalHistory", System.Data.SqlDbType.NVarChar, 0, "PastMedicalHistory"),
				new System.Data.SqlClient.SqlParameter("@PersonalHistory", System.Data.SqlDbType.NVarChar, 0, "PersonalHistory"),
				new System.Data.SqlClient.SqlParameter("@FamilyHistory", System.Data.SqlDbType.NVarChar, 0, "FamilyHistory"),
				new System.Data.SqlClient.SqlParameter("@SocioeconomicHistory", System.Data.SqlDbType.NVarChar, 0, "SocioeconomicHistory"),
				new System.Data.SqlClient.SqlParameter("@SymptomsHistory", System.Data.SqlDbType.NVarChar, 0, "SymptomsHistory"),
				new System.Data.SqlClient.SqlParameter("@Sidee", System.Data.SqlDbType.NVarChar, 0, "Sidee"),
				new System.Data.SqlClient.SqlParameter("@Site", System.Data.SqlDbType.NVarChar, 0, "Site"),
				new System.Data.SqlClient.SqlParameter("@Onset", System.Data.SqlDbType.NVarChar, 0, "Onset"),
				new System.Data.SqlClient.SqlParameter("@Duration", System.Data.SqlDbType.NVarChar, 0, "Duration"),
				new System.Data.SqlClient.SqlParameter("@Typee", System.Data.SqlDbType.NVarChar, 0, "Typee"),
				new System.Data.SqlClient.SqlParameter("@Severity", System.Data.SqlDbType.NVarChar, 0, "Severity"),
				new System.Data.SqlClient.SqlParameter("@AggravatingFactors", System.Data.SqlDbType.NVarChar, 0, "AggravatingFactors"),
				new System.Data.SqlClient.SqlParameter("@RelievingFactors", System.Data.SqlDbType.NVarChar, 0, "RelievingFactors"),
				new System.Data.SqlClient.SqlParameter("@DGVTemperature", System.Data.SqlDbType.NVarChar, 0, "DGVTemperature"),
				new System.Data.SqlClient.SqlParameter("@DGVBloodPressure", System.Data.SqlDbType.NVarChar, 0, "DGVBloodPressure"),
				new System.Data.SqlClient.SqlParameter("@DGVHeartRate", System.Data.SqlDbType.NVarChar, 0, "DGVHeartRate"),
				new System.Data.SqlClient.SqlParameter("@DGVRespiratoryRate", System.Data.SqlDbType.NVarChar, 0, "DGVRespiratoryRate"),
				new System.Data.SqlClient.SqlParameter("@Attitudeoflimbs", System.Data.SqlDbType.NVarChar, 0, "Attitudeoflimbs"),
				new System.Data.SqlClient.SqlParameter("@Built", System.Data.SqlDbType.NVarChar, 0, "Built"),
				new System.Data.SqlClient.SqlParameter("@Posture", System.Data.SqlDbType.NVarChar, 0, "Posture"),
				new System.Data.SqlClient.SqlParameter("@Gait", System.Data.SqlDbType.NVarChar, 0, "Gait"),
				new System.Data.SqlClient.SqlParameter("@PatternofMovement", System.Data.SqlDbType.NVarChar, 0, "PatternofMovement"),
				new System.Data.SqlClient.SqlParameter("@ModeofVentilation", System.Data.SqlDbType.NVarChar, 0, "ModeofVentilation"),
				new System.Data.SqlClient.SqlParameter("@Respiration", System.Data.SqlDbType.NVarChar, 0, "Respiration"),
				new System.Data.SqlClient.SqlParameter("@Oedema", System.Data.SqlDbType.NVarChar, 0, "Oedema"),
				new System.Data.SqlClient.SqlParameter("@MuscleWasting", System.Data.SqlDbType.NVarChar, 0, "MuscleWasting"),
				new System.Data.SqlClient.SqlParameter("@PressureSores", System.Data.SqlDbType.NVarChar, 0, "PressureSores"),
				new System.Data.SqlClient.SqlParameter("@Deformity", System.Data.SqlDbType.NVarChar, 0, "Deformity"),
				new System.Data.SqlClient.SqlParameter("@Wounds", System.Data.SqlDbType.NVarChar, 0, "Wounds"),
				new System.Data.SqlClient.SqlParameter("@ExternalAppliances", System.Data.SqlDbType.NVarChar, 0, "ExternalAppliances"),
				new System.Data.SqlClient.SqlParameter("@Warmth", System.Data.SqlDbType.NVarChar, 0, "Warmth"),
				new System.Data.SqlClient.SqlParameter("@Tenderness", System.Data.SqlDbType.NVarChar, 0, "Tenderness"),
				new System.Data.SqlClient.SqlParameter("@Tone", System.Data.SqlDbType.NVarChar, 0, "Tone"),
				new System.Data.SqlClient.SqlParameter("@Swelling", System.Data.SqlDbType.NVarChar, 0, "Swelling"),
				new System.Data.SqlClient.SqlParameter("@Consciousness", System.Data.SqlDbType.NVarChar, 0, "Consciousness"),
				new System.Data.SqlClient.SqlParameter("@Orientation", System.Data.SqlDbType.NVarChar, 0, "Orientation"),
				new System.Data.SqlClient.SqlParameter("@Person", System.Data.SqlDbType.NVarChar, 0, "Person"),
				new System.Data.SqlClient.SqlParameter("@Place", System.Data.SqlDbType.NVarChar, 0, "Place"),
				new System.Data.SqlClient.SqlParameter("@Time", System.Data.SqlDbType.NVarChar, 0, "Time"),
				new System.Data.SqlClient.SqlParameter("@Memory", System.Data.SqlDbType.NVarChar, 0, "Memory"),
				new System.Data.SqlClient.SqlParameter("@Immediate", System.Data.SqlDbType.NVarChar, 0, "Immediate"),
				new System.Data.SqlClient.SqlParameter("@Recent", System.Data.SqlDbType.NVarChar, 0, "Recent"),
				new System.Data.SqlClient.SqlParameter("@Remote", System.Data.SqlDbType.NVarChar, 0, "Remote"),
				new System.Data.SqlClient.SqlParameter("@Verbal", System.Data.SqlDbType.NVarChar, 0, "Verbal"),
				new System.Data.SqlClient.SqlParameter("@Visual", System.Data.SqlDbType.NVarChar, 0, "Visual"),
				new System.Data.SqlClient.SqlParameter("@Communication", System.Data.SqlDbType.NVarChar, 0, "Communication"),
				new System.Data.SqlClient.SqlParameter("@Cognition", System.Data.SqlDbType.NVarChar, 0, "Cognition"),
				new System.Data.SqlClient.SqlParameter("@FundofKnowledge", System.Data.SqlDbType.NVarChar, 0, "FundofKnowledge"),
				new System.Data.SqlClient.SqlParameter("@Calculation", System.Data.SqlDbType.NVarChar, 0, "Calculation"),
				new System.Data.SqlClient.SqlParameter("@ProverbInterpretation", System.Data.SqlDbType.NVarChar, 0, "ProverbInterpretation"),
				new System.Data.SqlClient.SqlParameter("@Attention", System.Data.SqlDbType.NVarChar, 0, "Attention"),
				new System.Data.SqlClient.SqlParameter("@EmotionalStatus", System.Data.SqlDbType.NVarChar, 0, "EmotionalStatus"),
				new System.Data.SqlClient.SqlParameter("@Perception", System.Data.SqlDbType.NVarChar, 0, "Perception"),
				new System.Data.SqlClient.SqlParameter("@Imaging", System.Data.SqlDbType.NVarChar, 0, "Imaging"),
				new System.Data.SqlClient.SqlParameter("@AgnosiasApraxias", System.Data.SqlDbType.NVarChar, 0, "AgnosiasApraxias"),
				new System.Data.SqlClient.SqlParameter("@SpecialSenses", System.Data.SqlDbType.NVarChar, 0, "SpecialSenses"),
				new System.Data.SqlClient.SqlParameter("@DGOlfactory", System.Data.SqlDbType.NVarChar, 0, "DGOlfactory"),
				new System.Data.SqlClient.SqlParameter("@DGOptic", System.Data.SqlDbType.NVarChar, 0, "DGOptic"),
				new System.Data.SqlClient.SqlParameter("@DGOculomotor", System.Data.SqlDbType.NVarChar, 0, "DGOculomotor"),
				new System.Data.SqlClient.SqlParameter("@DGTrochlear", System.Data.SqlDbType.NVarChar, 0, "DGTrochlear"),
				new System.Data.SqlClient.SqlParameter("@DGTrigeminal", System.Data.SqlDbType.NVarChar, 0, "DGTrigeminal"),
				new System.Data.SqlClient.SqlParameter("@DGAbducent", System.Data.SqlDbType.NVarChar, 0, "DGAbducent"),
				new System.Data.SqlClient.SqlParameter("@DGFacial", System.Data.SqlDbType.NVarChar, 0, "DGFacial"),
				new System.Data.SqlClient.SqlParameter("@DGVestibuloCochlear", System.Data.SqlDbType.NVarChar, 0, "DGVestibuloCochlear"),
				new System.Data.SqlClient.SqlParameter("@DGGlossopharyngeal", System.Data.SqlDbType.NVarChar, 0, "DGGlossopharyngeal"),
				new System.Data.SqlClient.SqlParameter("@DGVagus", System.Data.SqlDbType.NVarChar, 0, "DGVagus"),
				new System.Data.SqlClient.SqlParameter("@DGAccessory", System.Data.SqlDbType.NVarChar, 0, "DGAccessory"),
				new System.Data.SqlClient.SqlParameter("@DGHypoglossal", System.Data.SqlDbType.NVarChar, 0, "DGHypoglossal"),
				new System.Data.SqlClient.SqlParameter("@MOTORSYSTEM", System.Data.SqlDbType.NVarChar, 0, "MOTORSYSTEM"),
				new System.Data.SqlClient.SqlParameter("@DGArmR", System.Data.SqlDbType.NVarChar, 0, "DGArmR"),
				new System.Data.SqlClient.SqlParameter("@DGArmL", System.Data.SqlDbType.NVarChar, 0, "DGArmL"),
				new System.Data.SqlClient.SqlParameter("@DGForearmR", System.Data.SqlDbType.NVarChar, 0, "DGForearmR"),
				new System.Data.SqlClient.SqlParameter("@DGForearmL", System.Data.SqlDbType.NVarChar, 0, "DGForearmL"),
				new System.Data.SqlClient.SqlParameter("@DGThighR", System.Data.SqlDbType.NVarChar, 0, "DGThighR"),
				new System.Data.SqlClient.SqlParameter("@DGThighL", System.Data.SqlDbType.NVarChar, 0, "DGThighL"),
				new System.Data.SqlClient.SqlParameter("@DGCalfR", System.Data.SqlDbType.NVarChar, 0, "DGCalfR"),
				new System.Data.SqlClient.SqlParameter("@DGCalfL", System.Data.SqlDbType.NVarChar, 0, "DGCalfL"),
				new System.Data.SqlClient.SqlParameter("@DGUpperLimbR", System.Data.SqlDbType.NVarChar, 0, "DGUpperLimbR"),
				new System.Data.SqlClient.SqlParameter("@DGUpperLimbL", System.Data.SqlDbType.NVarChar, 0, "DGUpperLimbL"),
				new System.Data.SqlClient.SqlParameter("@DGLowerLimbR", System.Data.SqlDbType.NVarChar, 0, "DGLowerLimbR"),
				new System.Data.SqlClient.SqlParameter("@DGLowerLimbL", System.Data.SqlDbType.NVarChar, 0, "DGLowerLimbL"),
				new System.Data.SqlClient.SqlParameter("@DGTrueRt", System.Data.SqlDbType.NVarChar, 0, "DGTrueRt"),
				new System.Data.SqlClient.SqlParameter("@DGTrueLt", System.Data.SqlDbType.NVarChar, 0, "DGTrueLt"),
				new System.Data.SqlClient.SqlParameter("@DGApparentRt", System.Data.SqlDbType.NVarChar, 0, "DGApparentRt"),
				new System.Data.SqlClient.SqlParameter("@DGApparentLt", System.Data.SqlDbType.NVarChar, 0, "DGApparentLt"),
				new System.Data.SqlClient.SqlParameter("@DGReflexAbdominalL", System.Data.SqlDbType.NVarChar, 0, "DGReflexAbdominalL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexAbdominalR", System.Data.SqlDbType.NVarChar, 0, "DGReflexAbdominalR"),
				new System.Data.SqlClient.SqlParameter("@DGReflexPlantarL", System.Data.SqlDbType.NVarChar, 0, "DGReflexPlantarL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexPlantarR", System.Data.SqlDbType.NVarChar, 0, "DGReflexPlantarR"),
				new System.Data.SqlClient.SqlParameter("@DGReflexBicepsL", System.Data.SqlDbType.NVarChar, 0, "DGReflexBicepsL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexBicepsR", System.Data.SqlDbType.NVarChar, 0, "DGReflexBicepsR"),
				new System.Data.SqlClient.SqlParameter("@DGReflexBrachioradialisL", System.Data.SqlDbType.NVarChar, 0, "DGReflexBrachioradialisL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexBrachioradialisR", System.Data.SqlDbType.NVarChar, 0, "DGReflexBrachioradialisR"),
				new System.Data.SqlClient.SqlParameter("@DGReflexTricepsL", System.Data.SqlDbType.NVarChar, 0, "DGReflexTricepsL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexTricepsR", System.Data.SqlDbType.NVarChar, 0, "DGReflexTricepsR"),
				new System.Data.SqlClient.SqlParameter("@DGReflexKneeL", System.Data.SqlDbType.NVarChar, 0, "DGReflexKneeL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexKneeR", System.Data.SqlDbType.NVarChar, 0, "DGReflexKneeR"),
				new System.Data.SqlClient.SqlParameter("@DGReflexAnkleL", System.Data.SqlDbType.NVarChar, 0, "DGReflexAnkleL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexAnkleR", System.Data.SqlDbType.NVarChar, 0, "DGReflexAnkleR"),
				new System.Data.SqlClient.SqlParameter("@Pathological", System.Data.SqlDbType.NVarChar, 0, "Pathological"),
				new System.Data.SqlClient.SqlParameter("@InvoluntaryMovements", System.Data.SqlDbType.NVarChar, 0, "InvoluntaryMovements"),
				new System.Data.SqlClient.SqlParameter("@Balance", System.Data.SqlDbType.NVarChar, 0, "Balance"),
				new System.Data.SqlClient.SqlParameter("@Sitting", System.Data.SqlDbType.NVarChar, 0, "Sitting"),
				new System.Data.SqlClient.SqlParameter("@Standing", System.Data.SqlDbType.NVarChar, 0, "Standing"),
				new System.Data.SqlClient.SqlParameter("@BalanceReactions", System.Data.SqlDbType.NVarChar, 0, "BalanceReactions"),
				new System.Data.SqlClient.SqlParameter("@Posturee", System.Data.SqlDbType.NVarChar, 0, "Posturee"),
				new System.Data.SqlClient.SqlParameter("@Lying", System.Data.SqlDbType.NVarChar, 0, "Lying"),
				new System.Data.SqlClient.SqlParameter("@Sitting2", System.Data.SqlDbType.NVarChar, 0, "Sitting2"),
				new System.Data.SqlClient.SqlParameter("@Standing2", System.Data.SqlDbType.NVarChar, 0, "Standing2"),
				new System.Data.SqlClient.SqlParameter("@StepLength", System.Data.SqlDbType.NVarChar, 0, "StepLength"),
				new System.Data.SqlClient.SqlParameter("@StrideLength", System.Data.SqlDbType.NVarChar, 0, "StrideLength"),
				new System.Data.SqlClient.SqlParameter("@Basewidth", System.Data.SqlDbType.NVarChar, 0, "Basewidth"),
				new System.Data.SqlClient.SqlParameter("@Cadence", System.Data.SqlDbType.NVarChar, 0, "Cadence"),
				new System.Data.SqlClient.SqlParameter("@BiomechanicalDeviations", System.Data.SqlDbType.NVarChar, 0, "BiomechanicalDeviations"),
				new System.Data.SqlClient.SqlParameter("@HandFunctions", System.Data.SqlDbType.NVarChar, 0, "HandFunctions"),
				new System.Data.SqlClient.SqlParameter("@Reaching", System.Data.SqlDbType.NVarChar, 0, "Reaching"),
				new System.Data.SqlClient.SqlParameter("@Grasping", System.Data.SqlDbType.NVarChar, 0, "Grasping"),
				new System.Data.SqlClient.SqlParameter("@Releasing", System.Data.SqlDbType.NVarChar, 0, "Releasing"),
				new System.Data.SqlClient.SqlParameter("@AssisstiveDevices", System.Data.SqlDbType.NVarChar, 0, "AssisstiveDevices"),
				new System.Data.SqlClient.SqlParameter("@Functional_Diagnosis", System.Data.SqlDbType.NVarChar, 0, "Functional Diagnosis"),
				new System.Data.SqlClient.SqlParameter("@Goals", System.Data.SqlDbType.NVarChar, 0, "Goals"),
				new System.Data.SqlClient.SqlParameter("@Short_term", System.Data.SqlDbType.NVarChar, 0, "Short term"),
				new System.Data.SqlClient.SqlParameter("@Long_term", System.Data.SqlDbType.NVarChar, 0, "Long term"),
				new System.Data.SqlClient.SqlParameter("@TreatmentID", System.Data.SqlDbType.NVarChar, 0, "TreatmentID")
			});
			sqlUpdateCommand.CommandText = resources.GetString("sqlUpdateCommand.CommandText");
			sqlUpdateCommand.Connection = sqlConnection2;
			sqlUpdateCommand.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[133]
			{
				new System.Data.SqlClient.SqlParameter("@PatientID", System.Data.SqlDbType.Int, 0, "PatientID"),
				new System.Data.SqlClient.SqlParameter("@IPOP", System.Data.SqlDbType.NVarChar, 0, "IPOP"),
				new System.Data.SqlClient.SqlParameter("@Handedness", System.Data.SqlDbType.NVarChar, 0, "Handedness"),
				new System.Data.SqlClient.SqlParameter("@Occupation", System.Data.SqlDbType.NVarChar, 0, "Occupation"),
				new System.Data.SqlClient.SqlParameter("@Referredby", System.Data.SqlDbType.NVarChar, 0, "Referredby"),
				new System.Data.SqlClient.SqlParameter("@ChiefComplaints", System.Data.SqlDbType.NVarChar, 0, "ChiefComplaints"),
				new System.Data.SqlClient.SqlParameter("@PastMedicalHistory", System.Data.SqlDbType.NVarChar, 0, "PastMedicalHistory"),
				new System.Data.SqlClient.SqlParameter("@PersonalHistory", System.Data.SqlDbType.NVarChar, 0, "PersonalHistory"),
				new System.Data.SqlClient.SqlParameter("@FamilyHistory", System.Data.SqlDbType.NVarChar, 0, "FamilyHistory"),
				new System.Data.SqlClient.SqlParameter("@SocioeconomicHistory", System.Data.SqlDbType.NVarChar, 0, "SocioeconomicHistory"),
				new System.Data.SqlClient.SqlParameter("@SymptomsHistory", System.Data.SqlDbType.NVarChar, 0, "SymptomsHistory"),
				new System.Data.SqlClient.SqlParameter("@Sidee", System.Data.SqlDbType.NVarChar, 0, "Sidee"),
				new System.Data.SqlClient.SqlParameter("@Site", System.Data.SqlDbType.NVarChar, 0, "Site"),
				new System.Data.SqlClient.SqlParameter("@Onset", System.Data.SqlDbType.NVarChar, 0, "Onset"),
				new System.Data.SqlClient.SqlParameter("@Duration", System.Data.SqlDbType.NVarChar, 0, "Duration"),
				new System.Data.SqlClient.SqlParameter("@Typee", System.Data.SqlDbType.NVarChar, 0, "Typee"),
				new System.Data.SqlClient.SqlParameter("@Severity", System.Data.SqlDbType.NVarChar, 0, "Severity"),
				new System.Data.SqlClient.SqlParameter("@AggravatingFactors", System.Data.SqlDbType.NVarChar, 0, "AggravatingFactors"),
				new System.Data.SqlClient.SqlParameter("@RelievingFactors", System.Data.SqlDbType.NVarChar, 0, "RelievingFactors"),
				new System.Data.SqlClient.SqlParameter("@DGVTemperature", System.Data.SqlDbType.NVarChar, 0, "DGVTemperature"),
				new System.Data.SqlClient.SqlParameter("@DGVBloodPressure", System.Data.SqlDbType.NVarChar, 0, "DGVBloodPressure"),
				new System.Data.SqlClient.SqlParameter("@DGVHeartRate", System.Data.SqlDbType.NVarChar, 0, "DGVHeartRate"),
				new System.Data.SqlClient.SqlParameter("@DGVRespiratoryRate", System.Data.SqlDbType.NVarChar, 0, "DGVRespiratoryRate"),
				new System.Data.SqlClient.SqlParameter("@Attitudeoflimbs", System.Data.SqlDbType.NVarChar, 0, "Attitudeoflimbs"),
				new System.Data.SqlClient.SqlParameter("@Built", System.Data.SqlDbType.NVarChar, 0, "Built"),
				new System.Data.SqlClient.SqlParameter("@Posture", System.Data.SqlDbType.NVarChar, 0, "Posture"),
				new System.Data.SqlClient.SqlParameter("@Gait", System.Data.SqlDbType.NVarChar, 0, "Gait"),
				new System.Data.SqlClient.SqlParameter("@PatternofMovement", System.Data.SqlDbType.NVarChar, 0, "PatternofMovement"),
				new System.Data.SqlClient.SqlParameter("@ModeofVentilation", System.Data.SqlDbType.NVarChar, 0, "ModeofVentilation"),
				new System.Data.SqlClient.SqlParameter("@Respiration", System.Data.SqlDbType.NVarChar, 0, "Respiration"),
				new System.Data.SqlClient.SqlParameter("@Oedema", System.Data.SqlDbType.NVarChar, 0, "Oedema"),
				new System.Data.SqlClient.SqlParameter("@MuscleWasting", System.Data.SqlDbType.NVarChar, 0, "MuscleWasting"),
				new System.Data.SqlClient.SqlParameter("@PressureSores", System.Data.SqlDbType.NVarChar, 0, "PressureSores"),
				new System.Data.SqlClient.SqlParameter("@Deformity", System.Data.SqlDbType.NVarChar, 0, "Deformity"),
				new System.Data.SqlClient.SqlParameter("@Wounds", System.Data.SqlDbType.NVarChar, 0, "Wounds"),
				new System.Data.SqlClient.SqlParameter("@ExternalAppliances", System.Data.SqlDbType.NVarChar, 0, "ExternalAppliances"),
				new System.Data.SqlClient.SqlParameter("@Warmth", System.Data.SqlDbType.NVarChar, 0, "Warmth"),
				new System.Data.SqlClient.SqlParameter("@Tenderness", System.Data.SqlDbType.NVarChar, 0, "Tenderness"),
				new System.Data.SqlClient.SqlParameter("@Tone", System.Data.SqlDbType.NVarChar, 0, "Tone"),
				new System.Data.SqlClient.SqlParameter("@Swelling", System.Data.SqlDbType.NVarChar, 0, "Swelling"),
				new System.Data.SqlClient.SqlParameter("@Consciousness", System.Data.SqlDbType.NVarChar, 0, "Consciousness"),
				new System.Data.SqlClient.SqlParameter("@Orientation", System.Data.SqlDbType.NVarChar, 0, "Orientation"),
				new System.Data.SqlClient.SqlParameter("@Person", System.Data.SqlDbType.NVarChar, 0, "Person"),
				new System.Data.SqlClient.SqlParameter("@Place", System.Data.SqlDbType.NVarChar, 0, "Place"),
				new System.Data.SqlClient.SqlParameter("@Time", System.Data.SqlDbType.NVarChar, 0, "Time"),
				new System.Data.SqlClient.SqlParameter("@Memory", System.Data.SqlDbType.NVarChar, 0, "Memory"),
				new System.Data.SqlClient.SqlParameter("@Immediate", System.Data.SqlDbType.NVarChar, 0, "Immediate"),
				new System.Data.SqlClient.SqlParameter("@Recent", System.Data.SqlDbType.NVarChar, 0, "Recent"),
				new System.Data.SqlClient.SqlParameter("@Remote", System.Data.SqlDbType.NVarChar, 0, "Remote"),
				new System.Data.SqlClient.SqlParameter("@Verbal", System.Data.SqlDbType.NVarChar, 0, "Verbal"),
				new System.Data.SqlClient.SqlParameter("@Visual", System.Data.SqlDbType.NVarChar, 0, "Visual"),
				new System.Data.SqlClient.SqlParameter("@Communication", System.Data.SqlDbType.NVarChar, 0, "Communication"),
				new System.Data.SqlClient.SqlParameter("@Cognition", System.Data.SqlDbType.NVarChar, 0, "Cognition"),
				new System.Data.SqlClient.SqlParameter("@FundofKnowledge", System.Data.SqlDbType.NVarChar, 0, "FundofKnowledge"),
				new System.Data.SqlClient.SqlParameter("@Calculation", System.Data.SqlDbType.NVarChar, 0, "Calculation"),
				new System.Data.SqlClient.SqlParameter("@ProverbInterpretation", System.Data.SqlDbType.NVarChar, 0, "ProverbInterpretation"),
				new System.Data.SqlClient.SqlParameter("@Attention", System.Data.SqlDbType.NVarChar, 0, "Attention"),
				new System.Data.SqlClient.SqlParameter("@EmotionalStatus", System.Data.SqlDbType.NVarChar, 0, "EmotionalStatus"),
				new System.Data.SqlClient.SqlParameter("@Perception", System.Data.SqlDbType.NVarChar, 0, "Perception"),
				new System.Data.SqlClient.SqlParameter("@Imaging", System.Data.SqlDbType.NVarChar, 0, "Imaging"),
				new System.Data.SqlClient.SqlParameter("@AgnosiasApraxias", System.Data.SqlDbType.NVarChar, 0, "AgnosiasApraxias"),
				new System.Data.SqlClient.SqlParameter("@SpecialSenses", System.Data.SqlDbType.NVarChar, 0, "SpecialSenses"),
				new System.Data.SqlClient.SqlParameter("@DGOlfactory", System.Data.SqlDbType.NVarChar, 0, "DGOlfactory"),
				new System.Data.SqlClient.SqlParameter("@DGOptic", System.Data.SqlDbType.NVarChar, 0, "DGOptic"),
				new System.Data.SqlClient.SqlParameter("@DGOculomotor", System.Data.SqlDbType.NVarChar, 0, "DGOculomotor"),
				new System.Data.SqlClient.SqlParameter("@DGTrochlear", System.Data.SqlDbType.NVarChar, 0, "DGTrochlear"),
				new System.Data.SqlClient.SqlParameter("@DGTrigeminal", System.Data.SqlDbType.NVarChar, 0, "DGTrigeminal"),
				new System.Data.SqlClient.SqlParameter("@DGAbducent", System.Data.SqlDbType.NVarChar, 0, "DGAbducent"),
				new System.Data.SqlClient.SqlParameter("@DGFacial", System.Data.SqlDbType.NVarChar, 0, "DGFacial"),
				new System.Data.SqlClient.SqlParameter("@DGVestibuloCochlear", System.Data.SqlDbType.NVarChar, 0, "DGVestibuloCochlear"),
				new System.Data.SqlClient.SqlParameter("@DGGlossopharyngeal", System.Data.SqlDbType.NVarChar, 0, "DGGlossopharyngeal"),
				new System.Data.SqlClient.SqlParameter("@DGVagus", System.Data.SqlDbType.NVarChar, 0, "DGVagus"),
				new System.Data.SqlClient.SqlParameter("@DGAccessory", System.Data.SqlDbType.NVarChar, 0, "DGAccessory"),
				new System.Data.SqlClient.SqlParameter("@DGHypoglossal", System.Data.SqlDbType.NVarChar, 0, "DGHypoglossal"),
				new System.Data.SqlClient.SqlParameter("@MOTORSYSTEM", System.Data.SqlDbType.NVarChar, 0, "MOTORSYSTEM"),
				new System.Data.SqlClient.SqlParameter("@DGArmR", System.Data.SqlDbType.NVarChar, 0, "DGArmR"),
				new System.Data.SqlClient.SqlParameter("@DGArmL", System.Data.SqlDbType.NVarChar, 0, "DGArmL"),
				new System.Data.SqlClient.SqlParameter("@DGForearmR", System.Data.SqlDbType.NVarChar, 0, "DGForearmR"),
				new System.Data.SqlClient.SqlParameter("@DGForearmL", System.Data.SqlDbType.NVarChar, 0, "DGForearmL"),
				new System.Data.SqlClient.SqlParameter("@DGThighR", System.Data.SqlDbType.NVarChar, 0, "DGThighR"),
				new System.Data.SqlClient.SqlParameter("@DGThighL", System.Data.SqlDbType.NVarChar, 0, "DGThighL"),
				new System.Data.SqlClient.SqlParameter("@DGCalfR", System.Data.SqlDbType.NVarChar, 0, "DGCalfR"),
				new System.Data.SqlClient.SqlParameter("@DGCalfL", System.Data.SqlDbType.NVarChar, 0, "DGCalfL"),
				new System.Data.SqlClient.SqlParameter("@DGUpperLimbR", System.Data.SqlDbType.NVarChar, 0, "DGUpperLimbR"),
				new System.Data.SqlClient.SqlParameter("@DGUpperLimbL", System.Data.SqlDbType.NVarChar, 0, "DGUpperLimbL"),
				new System.Data.SqlClient.SqlParameter("@DGLowerLimbR", System.Data.SqlDbType.NVarChar, 0, "DGLowerLimbR"),
				new System.Data.SqlClient.SqlParameter("@DGLowerLimbL", System.Data.SqlDbType.NVarChar, 0, "DGLowerLimbL"),
				new System.Data.SqlClient.SqlParameter("@DGTrueRt", System.Data.SqlDbType.NVarChar, 0, "DGTrueRt"),
				new System.Data.SqlClient.SqlParameter("@DGTrueLt", System.Data.SqlDbType.NVarChar, 0, "DGTrueLt"),
				new System.Data.SqlClient.SqlParameter("@DGApparentRt", System.Data.SqlDbType.NVarChar, 0, "DGApparentRt"),
				new System.Data.SqlClient.SqlParameter("@DGApparentLt", System.Data.SqlDbType.NVarChar, 0, "DGApparentLt"),
				new System.Data.SqlClient.SqlParameter("@DGReflexAbdominalL", System.Data.SqlDbType.NVarChar, 0, "DGReflexAbdominalL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexAbdominalR", System.Data.SqlDbType.NVarChar, 0, "DGReflexAbdominalR"),
				new System.Data.SqlClient.SqlParameter("@DGReflexPlantarL", System.Data.SqlDbType.NVarChar, 0, "DGReflexPlantarL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexPlantarR", System.Data.SqlDbType.NVarChar, 0, "DGReflexPlantarR"),
				new System.Data.SqlClient.SqlParameter("@DGReflexBicepsL", System.Data.SqlDbType.NVarChar, 0, "DGReflexBicepsL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexBicepsR", System.Data.SqlDbType.NVarChar, 0, "DGReflexBicepsR"),
				new System.Data.SqlClient.SqlParameter("@DGReflexBrachioradialisL", System.Data.SqlDbType.NVarChar, 0, "DGReflexBrachioradialisL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexBrachioradialisR", System.Data.SqlDbType.NVarChar, 0, "DGReflexBrachioradialisR"),
				new System.Data.SqlClient.SqlParameter("@DGReflexTricepsL", System.Data.SqlDbType.NVarChar, 0, "DGReflexTricepsL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexTricepsR", System.Data.SqlDbType.NVarChar, 0, "DGReflexTricepsR"),
				new System.Data.SqlClient.SqlParameter("@DGReflexKneeL", System.Data.SqlDbType.NVarChar, 0, "DGReflexKneeL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexKneeR", System.Data.SqlDbType.NVarChar, 0, "DGReflexKneeR"),
				new System.Data.SqlClient.SqlParameter("@DGReflexAnkleL", System.Data.SqlDbType.NVarChar, 0, "DGReflexAnkleL"),
				new System.Data.SqlClient.SqlParameter("@DGReflexAnkleR", System.Data.SqlDbType.NVarChar, 0, "DGReflexAnkleR"),
				new System.Data.SqlClient.SqlParameter("@Pathological", System.Data.SqlDbType.NVarChar, 0, "Pathological"),
				new System.Data.SqlClient.SqlParameter("@InvoluntaryMovements", System.Data.SqlDbType.NVarChar, 0, "InvoluntaryMovements"),
				new System.Data.SqlClient.SqlParameter("@Balance", System.Data.SqlDbType.NVarChar, 0, "Balance"),
				new System.Data.SqlClient.SqlParameter("@Sitting", System.Data.SqlDbType.NVarChar, 0, "Sitting"),
				new System.Data.SqlClient.SqlParameter("@Standing", System.Data.SqlDbType.NVarChar, 0, "Standing"),
				new System.Data.SqlClient.SqlParameter("@BalanceReactions", System.Data.SqlDbType.NVarChar, 0, "BalanceReactions"),
				new System.Data.SqlClient.SqlParameter("@Posturee", System.Data.SqlDbType.NVarChar, 0, "Posturee"),
				new System.Data.SqlClient.SqlParameter("@Lying", System.Data.SqlDbType.NVarChar, 0, "Lying"),
				new System.Data.SqlClient.SqlParameter("@Sitting2", System.Data.SqlDbType.NVarChar, 0, "Sitting2"),
				new System.Data.SqlClient.SqlParameter("@Standing2", System.Data.SqlDbType.NVarChar, 0, "Standing2"),
				new System.Data.SqlClient.SqlParameter("@StepLength", System.Data.SqlDbType.NVarChar, 0, "StepLength"),
				new System.Data.SqlClient.SqlParameter("@StrideLength", System.Data.SqlDbType.NVarChar, 0, "StrideLength"),
				new System.Data.SqlClient.SqlParameter("@Basewidth", System.Data.SqlDbType.NVarChar, 0, "Basewidth"),
				new System.Data.SqlClient.SqlParameter("@Cadence", System.Data.SqlDbType.NVarChar, 0, "Cadence"),
				new System.Data.SqlClient.SqlParameter("@BiomechanicalDeviations", System.Data.SqlDbType.NVarChar, 0, "BiomechanicalDeviations"),
				new System.Data.SqlClient.SqlParameter("@HandFunctions", System.Data.SqlDbType.NVarChar, 0, "HandFunctions"),
				new System.Data.SqlClient.SqlParameter("@Reaching", System.Data.SqlDbType.NVarChar, 0, "Reaching"),
				new System.Data.SqlClient.SqlParameter("@Grasping", System.Data.SqlDbType.NVarChar, 0, "Grasping"),
				new System.Data.SqlClient.SqlParameter("@Releasing", System.Data.SqlDbType.NVarChar, 0, "Releasing"),
				new System.Data.SqlClient.SqlParameter("@AssisstiveDevices", System.Data.SqlDbType.NVarChar, 0, "AssisstiveDevices"),
				new System.Data.SqlClient.SqlParameter("@Functional_Diagnosis", System.Data.SqlDbType.NVarChar, 0, "Functional Diagnosis"),
				new System.Data.SqlClient.SqlParameter("@Goals", System.Data.SqlDbType.NVarChar, 0, "Goals"),
				new System.Data.SqlClient.SqlParameter("@Short_term", System.Data.SqlDbType.NVarChar, 0, "Short term"),
				new System.Data.SqlClient.SqlParameter("@Long_term", System.Data.SqlDbType.NVarChar, 0, "Long term"),
				new System.Data.SqlClient.SqlParameter("@TreatmentID", System.Data.SqlDbType.NVarChar, 0, "TreatmentID"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDataAdapter3.DeleteCommand = sqlCommand2;
			sqlDataAdapter3.InsertCommand = sqlCommand3;
			sqlDataAdapter3.SelectCommand = sqlCommand4;
			sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Coordination", new System.Data.Common.DataColumnMapping[33]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("neurologicalID", "neurologicalID"),
					new System.Data.Common.DataColumnMapping("FingernoseR", "FingernoseR"),
					new System.Data.Common.DataColumnMapping("FingernoseT", "FingernoseT"),
					new System.Data.Common.DataColumnMapping("FingeroppositionR", "FingeroppositionR"),
					new System.Data.Common.DataColumnMapping("FingeroppositionT", "FingeroppositionT"),
					new System.Data.Common.DataColumnMapping("MassGraspR", "MassGraspR"),
					new System.Data.Common.DataColumnMapping("MassGraspT", "MassGraspT"),
					new System.Data.Common.DataColumnMapping("PronationSupinationR", "PronationSupinationR"),
					new System.Data.Common.DataColumnMapping("PronationSupinationT", "PronationSupinationT"),
					new System.Data.Common.DataColumnMapping("ReboundtestR", "ReboundtestR"),
					new System.Data.Common.DataColumnMapping("ReboundtestT", "ReboundtestT"),
					new System.Data.Common.DataColumnMapping("TappingHandR", "TappingHandR"),
					new System.Data.Common.DataColumnMapping("TappingHandT", "TappingHandT"),
					new System.Data.Common.DataColumnMapping("TappingFootR", "TappingFootR"),
					new System.Data.Common.DataColumnMapping("TappingFootT", "TappingFootT"),
					new System.Data.Common.DataColumnMapping("HeeltokneeR", "HeeltokneeR"),
					new System.Data.Common.DataColumnMapping("HeeltokneeT", "HeeltokneeT"),
					new System.Data.Common.DataColumnMapping("circleHandR", "circleHandR"),
					new System.Data.Common.DataColumnMapping("circleHandT", "circleHandT"),
					new System.Data.Common.DataColumnMapping("circleFootR", "circleFootR"),
					new System.Data.Common.DataColumnMapping("circleFootT", "circleFootT"),
					new System.Data.Common.DataColumnMapping("StandNormal", "StandNormal"),
					new System.Data.Common.DataColumnMapping("StandNormalwithvision", "StandNormalwithvision"),
					new System.Data.Common.DataColumnMapping("StandingFeettogether", "StandingFeettogether"),
					new System.Data.Common.DataColumnMapping("Standingononefoot", "Standingononefoot"),
					new System.Data.Common.DataColumnMapping("StandingLateraltrunkflexion", "StandingLateraltrunkflexion"),
					new System.Data.Common.DataColumnMapping("Tandemwalking", "Tandemwalking"),
					new System.Data.Common.DataColumnMapping("WalkSideways", "WalkSideways"),
					new System.Data.Common.DataColumnMapping("WalkBackward", "WalkBackward"),
					new System.Data.Common.DataColumnMapping("Walkcircle", "Walkcircle"),
					new System.Data.Common.DataColumnMapping("Walkheels", "Walkheels"),
					new System.Data.Common.DataColumnMapping("Walktoes", "Walktoes")
				})
			});
			sqlDataAdapter3.UpdateCommand = sqlCommand5;
			sqlCommand2.CommandText = "DELETE FROM [Coordination] WHERE (([ID] = @Original_ID) AND ([neurologicalID] = @Original_neurologicalID))";
			sqlCommand2.Connection = sqlConnection3;
			sqlCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection3.FireInfoMessageEventOnUserErrors = false;
			sqlCommand3.CommandText = resources.GetString("sqlCommand3.CommandText");
			sqlCommand3.Connection = sqlConnection3;
			sqlCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[32]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@FingernoseR", System.Data.SqlDbType.NVarChar, 0, "FingernoseR"),
				new System.Data.SqlClient.SqlParameter("@FingernoseT", System.Data.SqlDbType.NVarChar, 0, "FingernoseT"),
				new System.Data.SqlClient.SqlParameter("@FingeroppositionR", System.Data.SqlDbType.NVarChar, 0, "FingeroppositionR"),
				new System.Data.SqlClient.SqlParameter("@FingeroppositionT", System.Data.SqlDbType.NVarChar, 0, "FingeroppositionT"),
				new System.Data.SqlClient.SqlParameter("@MassGraspR", System.Data.SqlDbType.NVarChar, 0, "MassGraspR"),
				new System.Data.SqlClient.SqlParameter("@MassGraspT", System.Data.SqlDbType.NVarChar, 0, "MassGraspT"),
				new System.Data.SqlClient.SqlParameter("@PronationSupinationR", System.Data.SqlDbType.NVarChar, 0, "PronationSupinationR"),
				new System.Data.SqlClient.SqlParameter("@PronationSupinationT", System.Data.SqlDbType.NVarChar, 0, "PronationSupinationT"),
				new System.Data.SqlClient.SqlParameter("@ReboundtestR", System.Data.SqlDbType.NVarChar, 0, "ReboundtestR"),
				new System.Data.SqlClient.SqlParameter("@ReboundtestT", System.Data.SqlDbType.NVarChar, 0, "ReboundtestT"),
				new System.Data.SqlClient.SqlParameter("@TappingHandR", System.Data.SqlDbType.NVarChar, 0, "TappingHandR"),
				new System.Data.SqlClient.SqlParameter("@TappingHandT", System.Data.SqlDbType.NVarChar, 0, "TappingHandT"),
				new System.Data.SqlClient.SqlParameter("@TappingFootR", System.Data.SqlDbType.NVarChar, 0, "TappingFootR"),
				new System.Data.SqlClient.SqlParameter("@TappingFootT", System.Data.SqlDbType.NVarChar, 0, "TappingFootT"),
				new System.Data.SqlClient.SqlParameter("@HeeltokneeR", System.Data.SqlDbType.NVarChar, 0, "HeeltokneeR"),
				new System.Data.SqlClient.SqlParameter("@HeeltokneeT", System.Data.SqlDbType.NVarChar, 0, "HeeltokneeT"),
				new System.Data.SqlClient.SqlParameter("@circleHandR", System.Data.SqlDbType.NVarChar, 0, "circleHandR"),
				new System.Data.SqlClient.SqlParameter("@circleHandT", System.Data.SqlDbType.NVarChar, 0, "circleHandT"),
				new System.Data.SqlClient.SqlParameter("@circleFootR", System.Data.SqlDbType.NVarChar, 0, "circleFootR"),
				new System.Data.SqlClient.SqlParameter("@circleFootT", System.Data.SqlDbType.NVarChar, 0, "circleFootT"),
				new System.Data.SqlClient.SqlParameter("@StandNormal", System.Data.SqlDbType.NVarChar, 0, "StandNormal"),
				new System.Data.SqlClient.SqlParameter("@StandNormalwithvision", System.Data.SqlDbType.NVarChar, 0, "StandNormalwithvision"),
				new System.Data.SqlClient.SqlParameter("@StandingFeettogether", System.Data.SqlDbType.NVarChar, 0, "StandingFeettogether"),
				new System.Data.SqlClient.SqlParameter("@Standingononefoot", System.Data.SqlDbType.NVarChar, 0, "Standingononefoot"),
				new System.Data.SqlClient.SqlParameter("@StandingLateraltrunkflexion", System.Data.SqlDbType.NVarChar, 0, "StandingLateraltrunkflexion"),
				new System.Data.SqlClient.SqlParameter("@Tandemwalking", System.Data.SqlDbType.NVarChar, 0, "Tandemwalking"),
				new System.Data.SqlClient.SqlParameter("@WalkSideways", System.Data.SqlDbType.NVarChar, 0, "WalkSideways"),
				new System.Data.SqlClient.SqlParameter("@WalkBackward", System.Data.SqlDbType.NVarChar, 0, "WalkBackward"),
				new System.Data.SqlClient.SqlParameter("@Walkcircle", System.Data.SqlDbType.NVarChar, 0, "Walkcircle"),
				new System.Data.SqlClient.SqlParameter("@Walkheels", System.Data.SqlDbType.NVarChar, 0, "Walkheels"),
				new System.Data.SqlClient.SqlParameter("@Walktoes", System.Data.SqlDbType.NVarChar, 0, "Walktoes")
			});
			sqlCommand4.CommandText = "SELECT        Coordination.*\r\nFROM            Coordination";
			sqlCommand4.Connection = sqlConnection3;
			sqlCommand5.CommandText = resources.GetString("sqlCommand5.CommandText");
			sqlCommand5.Connection = sqlConnection3;
			sqlCommand5.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[35]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@FingernoseR", System.Data.SqlDbType.NVarChar, 0, "FingernoseR"),
				new System.Data.SqlClient.SqlParameter("@FingernoseT", System.Data.SqlDbType.NVarChar, 0, "FingernoseT"),
				new System.Data.SqlClient.SqlParameter("@FingeroppositionR", System.Data.SqlDbType.NVarChar, 0, "FingeroppositionR"),
				new System.Data.SqlClient.SqlParameter("@FingeroppositionT", System.Data.SqlDbType.NVarChar, 0, "FingeroppositionT"),
				new System.Data.SqlClient.SqlParameter("@MassGraspR", System.Data.SqlDbType.NVarChar, 0, "MassGraspR"),
				new System.Data.SqlClient.SqlParameter("@MassGraspT", System.Data.SqlDbType.NVarChar, 0, "MassGraspT"),
				new System.Data.SqlClient.SqlParameter("@PronationSupinationR", System.Data.SqlDbType.NVarChar, 0, "PronationSupinationR"),
				new System.Data.SqlClient.SqlParameter("@PronationSupinationT", System.Data.SqlDbType.NVarChar, 0, "PronationSupinationT"),
				new System.Data.SqlClient.SqlParameter("@ReboundtestR", System.Data.SqlDbType.NVarChar, 0, "ReboundtestR"),
				new System.Data.SqlClient.SqlParameter("@ReboundtestT", System.Data.SqlDbType.NVarChar, 0, "ReboundtestT"),
				new System.Data.SqlClient.SqlParameter("@TappingHandR", System.Data.SqlDbType.NVarChar, 0, "TappingHandR"),
				new System.Data.SqlClient.SqlParameter("@TappingHandT", System.Data.SqlDbType.NVarChar, 0, "TappingHandT"),
				new System.Data.SqlClient.SqlParameter("@TappingFootR", System.Data.SqlDbType.NVarChar, 0, "TappingFootR"),
				new System.Data.SqlClient.SqlParameter("@TappingFootT", System.Data.SqlDbType.NVarChar, 0, "TappingFootT"),
				new System.Data.SqlClient.SqlParameter("@HeeltokneeR", System.Data.SqlDbType.NVarChar, 0, "HeeltokneeR"),
				new System.Data.SqlClient.SqlParameter("@HeeltokneeT", System.Data.SqlDbType.NVarChar, 0, "HeeltokneeT"),
				new System.Data.SqlClient.SqlParameter("@circleHandR", System.Data.SqlDbType.NVarChar, 0, "circleHandR"),
				new System.Data.SqlClient.SqlParameter("@circleHandT", System.Data.SqlDbType.NVarChar, 0, "circleHandT"),
				new System.Data.SqlClient.SqlParameter("@circleFootR", System.Data.SqlDbType.NVarChar, 0, "circleFootR"),
				new System.Data.SqlClient.SqlParameter("@circleFootT", System.Data.SqlDbType.NVarChar, 0, "circleFootT"),
				new System.Data.SqlClient.SqlParameter("@StandNormal", System.Data.SqlDbType.NVarChar, 0, "StandNormal"),
				new System.Data.SqlClient.SqlParameter("@StandNormalwithvision", System.Data.SqlDbType.NVarChar, 0, "StandNormalwithvision"),
				new System.Data.SqlClient.SqlParameter("@StandingFeettogether", System.Data.SqlDbType.NVarChar, 0, "StandingFeettogether"),
				new System.Data.SqlClient.SqlParameter("@Standingononefoot", System.Data.SqlDbType.NVarChar, 0, "Standingononefoot"),
				new System.Data.SqlClient.SqlParameter("@StandingLateraltrunkflexion", System.Data.SqlDbType.NVarChar, 0, "StandingLateraltrunkflexion"),
				new System.Data.SqlClient.SqlParameter("@Tandemwalking", System.Data.SqlDbType.NVarChar, 0, "Tandemwalking"),
				new System.Data.SqlClient.SqlParameter("@WalkSideways", System.Data.SqlDbType.NVarChar, 0, "WalkSideways"),
				new System.Data.SqlClient.SqlParameter("@WalkBackward", System.Data.SqlDbType.NVarChar, 0, "WalkBackward"),
				new System.Data.SqlClient.SqlParameter("@Walkcircle", System.Data.SqlDbType.NVarChar, 0, "Walkcircle"),
				new System.Data.SqlClient.SqlParameter("@Walkheels", System.Data.SqlDbType.NVarChar, 0, "Walkheels"),
				new System.Data.SqlClient.SqlParameter("@Walktoes", System.Data.SqlDbType.NVarChar, 0, "Walktoes"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDataAdapter4.DeleteCommand = sqlCommand6;
			sqlDataAdapter4.InsertCommand = sqlCommand7;
			sqlDataAdapter4.SelectCommand = sqlCommand8;
			sqlDataAdapter4.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Functional_Assessment", new System.Data.Common.DataColumnMapping[26]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("neurologicalID", "neurologicalID"),
					new System.Data.Common.DataColumnMapping("Evaluation1", "Evaluation1"),
					new System.Data.Common.DataColumnMapping("Item1", "Item1"),
					new System.Data.Common.DataColumnMapping("Item2", "Item2"),
					new System.Data.Common.DataColumnMapping("Item3", "Item3"),
					new System.Data.Common.DataColumnMapping("Item4", "Item4"),
					new System.Data.Common.DataColumnMapping("Item5", "Item5"),
					new System.Data.Common.DataColumnMapping("Evaluation2", "Evaluation2"),
					new System.Data.Common.DataColumnMapping("Item6", "Item6"),
					new System.Data.Common.DataColumnMapping("Item7", "Item7"),
					new System.Data.Common.DataColumnMapping("Evaluation3", "Evaluation3"),
					new System.Data.Common.DataColumnMapping("Item8", "Item8"),
					new System.Data.Common.DataColumnMapping("Item9", "Item9"),
					new System.Data.Common.DataColumnMapping("Item10", "Item10"),
					new System.Data.Common.DataColumnMapping("Evaluation4", "Evaluation4"),
					new System.Data.Common.DataColumnMapping("Item11", "Item11"),
					new System.Data.Common.DataColumnMapping("Item12", "Item12"),
					new System.Data.Common.DataColumnMapping("Evaluation5", "Evaluation5"),
					new System.Data.Common.DataColumnMapping("Item13", "Item13"),
					new System.Data.Common.DataColumnMapping("Item14", "Item14"),
					new System.Data.Common.DataColumnMapping("Evaluation6", "Evaluation6"),
					new System.Data.Common.DataColumnMapping("Item15", "Item15"),
					new System.Data.Common.DataColumnMapping("Item16", "Item16"),
					new System.Data.Common.DataColumnMapping("Item17", "Item17"),
					new System.Data.Common.DataColumnMapping("InvestigationFindings", "InvestigationFindings")
				})
			});
			sqlDataAdapter4.UpdateCommand = sqlCommand9;
			sqlCommand6.CommandText = "DELETE FROM [Functional_Assessment] WHERE (([ID] = @Original_ID) AND ([neurologicalID] = @Original_neurologicalID))";
			sqlCommand6.Connection = sqlConnection4;
			sqlCommand6.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection4.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection4.FireInfoMessageEventOnUserErrors = false;
			sqlCommand7.CommandText = resources.GetString("sqlCommand7.CommandText");
			sqlCommand7.Connection = sqlConnection4;
			sqlCommand7.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[25]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@Evaluation1", System.Data.SqlDbType.NVarChar, 0, "Evaluation1"),
				new System.Data.SqlClient.SqlParameter("@Item1", System.Data.SqlDbType.NVarChar, 0, "Item1"),
				new System.Data.SqlClient.SqlParameter("@Item2", System.Data.SqlDbType.NVarChar, 0, "Item2"),
				new System.Data.SqlClient.SqlParameter("@Item3", System.Data.SqlDbType.NVarChar, 0, "Item3"),
				new System.Data.SqlClient.SqlParameter("@Item4", System.Data.SqlDbType.NVarChar, 0, "Item4"),
				new System.Data.SqlClient.SqlParameter("@Item5", System.Data.SqlDbType.NVarChar, 0, "Item5"),
				new System.Data.SqlClient.SqlParameter("@Evaluation2", System.Data.SqlDbType.NVarChar, 0, "Evaluation2"),
				new System.Data.SqlClient.SqlParameter("@Item6", System.Data.SqlDbType.NVarChar, 0, "Item6"),
				new System.Data.SqlClient.SqlParameter("@Item7", System.Data.SqlDbType.NVarChar, 0, "Item7"),
				new System.Data.SqlClient.SqlParameter("@Evaluation3", System.Data.SqlDbType.NVarChar, 0, "Evaluation3"),
				new System.Data.SqlClient.SqlParameter("@Item8", System.Data.SqlDbType.NVarChar, 0, "Item8"),
				new System.Data.SqlClient.SqlParameter("@Item9", System.Data.SqlDbType.NVarChar, 0, "Item9"),
				new System.Data.SqlClient.SqlParameter("@Item10", System.Data.SqlDbType.NVarChar, 0, "Item10"),
				new System.Data.SqlClient.SqlParameter("@Evaluation4", System.Data.SqlDbType.NVarChar, 0, "Evaluation4"),
				new System.Data.SqlClient.SqlParameter("@Item11", System.Data.SqlDbType.NVarChar, 0, "Item11"),
				new System.Data.SqlClient.SqlParameter("@Item12", System.Data.SqlDbType.NVarChar, 0, "Item12"),
				new System.Data.SqlClient.SqlParameter("@Evaluation5", System.Data.SqlDbType.NVarChar, 0, "Evaluation5"),
				new System.Data.SqlClient.SqlParameter("@Item13", System.Data.SqlDbType.NVarChar, 0, "Item13"),
				new System.Data.SqlClient.SqlParameter("@Item14", System.Data.SqlDbType.NVarChar, 0, "Item14"),
				new System.Data.SqlClient.SqlParameter("@Evaluation6", System.Data.SqlDbType.NVarChar, 0, "Evaluation6"),
				new System.Data.SqlClient.SqlParameter("@Item15", System.Data.SqlDbType.NVarChar, 0, "Item15"),
				new System.Data.SqlClient.SqlParameter("@Item16", System.Data.SqlDbType.NVarChar, 0, "Item16"),
				new System.Data.SqlClient.SqlParameter("@Item17", System.Data.SqlDbType.NVarChar, 0, "Item17"),
				new System.Data.SqlClient.SqlParameter("@InvestigationFindings", System.Data.SqlDbType.NVarChar, 0, "InvestigationFindings")
			});
			sqlCommand8.CommandText = "SELECT        Functional_Assessment.*\r\nFROM            Functional_Assessment";
			sqlCommand8.Connection = sqlConnection4;
			sqlCommand9.CommandText = resources.GetString("sqlCommand9.CommandText");
			sqlCommand9.Connection = sqlConnection4;
			sqlCommand9.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[28]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@Evaluation1", System.Data.SqlDbType.NVarChar, 0, "Evaluation1"),
				new System.Data.SqlClient.SqlParameter("@Item1", System.Data.SqlDbType.NVarChar, 0, "Item1"),
				new System.Data.SqlClient.SqlParameter("@Item2", System.Data.SqlDbType.NVarChar, 0, "Item2"),
				new System.Data.SqlClient.SqlParameter("@Item3", System.Data.SqlDbType.NVarChar, 0, "Item3"),
				new System.Data.SqlClient.SqlParameter("@Item4", System.Data.SqlDbType.NVarChar, 0, "Item4"),
				new System.Data.SqlClient.SqlParameter("@Item5", System.Data.SqlDbType.NVarChar, 0, "Item5"),
				new System.Data.SqlClient.SqlParameter("@Evaluation2", System.Data.SqlDbType.NVarChar, 0, "Evaluation2"),
				new System.Data.SqlClient.SqlParameter("@Item6", System.Data.SqlDbType.NVarChar, 0, "Item6"),
				new System.Data.SqlClient.SqlParameter("@Item7", System.Data.SqlDbType.NVarChar, 0, "Item7"),
				new System.Data.SqlClient.SqlParameter("@Evaluation3", System.Data.SqlDbType.NVarChar, 0, "Evaluation3"),
				new System.Data.SqlClient.SqlParameter("@Item8", System.Data.SqlDbType.NVarChar, 0, "Item8"),
				new System.Data.SqlClient.SqlParameter("@Item9", System.Data.SqlDbType.NVarChar, 0, "Item9"),
				new System.Data.SqlClient.SqlParameter("@Item10", System.Data.SqlDbType.NVarChar, 0, "Item10"),
				new System.Data.SqlClient.SqlParameter("@Evaluation4", System.Data.SqlDbType.NVarChar, 0, "Evaluation4"),
				new System.Data.SqlClient.SqlParameter("@Item11", System.Data.SqlDbType.NVarChar, 0, "Item11"),
				new System.Data.SqlClient.SqlParameter("@Item12", System.Data.SqlDbType.NVarChar, 0, "Item12"),
				new System.Data.SqlClient.SqlParameter("@Evaluation5", System.Data.SqlDbType.NVarChar, 0, "Evaluation5"),
				new System.Data.SqlClient.SqlParameter("@Item13", System.Data.SqlDbType.NVarChar, 0, "Item13"),
				new System.Data.SqlClient.SqlParameter("@Item14", System.Data.SqlDbType.NVarChar, 0, "Item14"),
				new System.Data.SqlClient.SqlParameter("@Evaluation6", System.Data.SqlDbType.NVarChar, 0, "Evaluation6"),
				new System.Data.SqlClient.SqlParameter("@Item15", System.Data.SqlDbType.NVarChar, 0, "Item15"),
				new System.Data.SqlClient.SqlParameter("@Item16", System.Data.SqlDbType.NVarChar, 0, "Item16"),
				new System.Data.SqlClient.SqlParameter("@Item17", System.Data.SqlDbType.NVarChar, 0, "Item17"),
				new System.Data.SqlClient.SqlParameter("@InvestigationFindings", System.Data.SqlDbType.NVarChar, 0, "InvestigationFindings"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDataAdapter5.DeleteCommand = sqlCommand10;
			sqlDataAdapter5.InsertCommand = sqlCommand11;
			sqlDataAdapter5.SelectCommand = sqlCommand12;
			sqlDataAdapter5.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Muscle_Power", new System.Data.Common.DataColumnMapping[72]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("neurologicalID", "neurologicalID"),
					new System.Data.Common.DataColumnMapping("PowerSFlexorsRt", "PowerSFlexorsRt"),
					new System.Data.Common.DataColumnMapping("PowerSFlexorsLt", "PowerSFlexorsLt"),
					new System.Data.Common.DataColumnMapping("PowerSExtensorsRt", "PowerSExtensorsRt"),
					new System.Data.Common.DataColumnMapping("PowerSExtensorsLt", "PowerSExtensorsLt"),
					new System.Data.Common.DataColumnMapping("PowerSAbductorsRt", "PowerSAbductorsRt"),
					new System.Data.Common.DataColumnMapping("PowerSAbductorsLt", "PowerSAbductorsLt"),
					new System.Data.Common.DataColumnMapping("PowerSAdductorsRt", "PowerSAdductorsRt"),
					new System.Data.Common.DataColumnMapping("PowerSAdductorsLt", "PowerSAdductorsLt"),
					new System.Data.Common.DataColumnMapping("PowerExternalRotRt", "PowerExternalRotRt"),
					new System.Data.Common.DataColumnMapping("PowerSExternalRotLt", "PowerSExternalRotLt"),
					new System.Data.Common.DataColumnMapping("PowerSInternalRotRt", "PowerSInternalRotRt"),
					new System.Data.Common.DataColumnMapping("PowerSInternalRotLt", "PowerSInternalRotLt"),
					new System.Data.Common.DataColumnMapping("PowerEFlexorsRt", "PowerEFlexorsRt"),
					new System.Data.Common.DataColumnMapping("PowerEFlexorsLt", "PowerEFlexorsLt"),
					new System.Data.Common.DataColumnMapping("PowerEExtensorsRt", "PowerEExtensorsRt"),
					new System.Data.Common.DataColumnMapping("PowerEExtensorsLt", "PowerEExtensorsLt"),
					new System.Data.Common.DataColumnMapping("PowerEForearmRt", "PowerEForearmRt"),
					new System.Data.Common.DataColumnMapping("PowerEForearmLt", "PowerEForearmLt"),
					new System.Data.Common.DataColumnMapping("PowerEPronatorsRt", "PowerEPronatorsRt"),
					new System.Data.Common.DataColumnMapping("PowerEPronatorsLt", "PowerEPronatorsLt"),
					new System.Data.Common.DataColumnMapping("PowerESupinatorsRt", "PowerESupinatorsRt"),
					new System.Data.Common.DataColumnMapping("PowerESupinatorsLt", "PowerESupinatorsLt"),
					new System.Data.Common.DataColumnMapping("PowerWFlexorsRt", "PowerWFlexorsRt"),
					new System.Data.Common.DataColumnMapping("PowerWFlexorsLt", "PowerWFlexorsLt"),
					new System.Data.Common.DataColumnMapping("PowerWExtensorsRt", "PowerWExtensorsRt"),
					new System.Data.Common.DataColumnMapping("PowerWExtensorsLt", "PowerWExtensorsLt"),
					new System.Data.Common.DataColumnMapping("PowerWRadialDevRt", "PowerWRadialDevRt"),
					new System.Data.Common.DataColumnMapping("PowerWRadialDevLt", "PowerWRadialDevLt"),
					new System.Data.Common.DataColumnMapping("PowerWUlnarDevRt", "PowerWUlnarDevRt"),
					new System.Data.Common.DataColumnMapping("PowerWUlnarDevLt", "PowerWUlnarDevLt"),
					new System.Data.Common.DataColumnMapping("PowerHIntrinsicsRt", "PowerHIntrinsicsRt"),
					new System.Data.Common.DataColumnMapping("PowerHIntrinsicsLt", "PowerHIntrinsicsLt"),
					new System.Data.Common.DataColumnMapping("PowerEHxtrinsicsRt", "PowerEHxtrinsicsRt"),
					new System.Data.Common.DataColumnMapping("PowerHExtrinsicsLt", "PowerHExtrinsicsLt"),
					new System.Data.Common.DataColumnMapping("PowerHIFlexorsRt", "PowerHIFlexorsRt"),
					new System.Data.Common.DataColumnMapping("PowerHIFlexorsLt", "PowerHIFlexorsLt"),
					new System.Data.Common.DataColumnMapping("PowerHIExtensorsRt", "PowerHIExtensorsRt"),
					new System.Data.Common.DataColumnMapping("PowerHIExtensorsLt", "PowerHIExtensorsLt"),
					new System.Data.Common.DataColumnMapping("PowerHIAbductorsRt", "PowerHIAbductorsRt"),
					new System.Data.Common.DataColumnMapping("PowerHIAbductorsLt", "PowerHIAbductorsLt"),
					new System.Data.Common.DataColumnMapping("PowerHIAdductorsRt", "PowerHIAdductorsRt"),
					new System.Data.Common.DataColumnMapping("PowerHIAdductorsLt", "PowerHIAdductorsLt"),
					new System.Data.Common.DataColumnMapping("PowerHIExternalRotRt", "PowerHIExternalRotRt"),
					new System.Data.Common.DataColumnMapping("PowerHIExternalRotLt", "PowerHIExternalRotLt"),
					new System.Data.Common.DataColumnMapping("PowerHIInternalRotRt", "PowerHIInternalRotRt"),
					new System.Data.Common.DataColumnMapping("PowerHIInternalRotLt", "PowerHIInternalRotLt"),
					new System.Data.Common.DataColumnMapping("PowerKFlexorsRt", "PowerKFlexorsRt"),
					new System.Data.Common.DataColumnMapping("PowerKFlexorsLt", "PowerKFlexorsLt"),
					new System.Data.Common.DataColumnMapping("PowerKExtensorsRt", "PowerKExtensorsRt"),
					new System.Data.Common.DataColumnMapping("PowerKExtensorsLt", "PowerKExtensorsLt"),
					new System.Data.Common.DataColumnMapping("PowerANDorsiflexorsRt", "PowerANDorsiflexorsRt"),
					new System.Data.Common.DataColumnMapping("PowerANDorsiflexorsLt", "PowerANDorsiflexorsLt"),
					new System.Data.Common.DataColumnMapping("PowerANPlantarflexorsRt", "PowerANPlantarflexorsRt"),
					new System.Data.Common.DataColumnMapping("PowerANPlantarflexorsLt", "PowerANPlantarflexorsLt"),
					new System.Data.Common.DataColumnMapping("PowerFInvertorsRt", "PowerFInvertorsRt"),
					new System.Data.Common.DataColumnMapping("PowerFInvertorsLt", "PowerFInvertorsLt"),
					new System.Data.Common.DataColumnMapping("PowerFEvertorsRt", "PowerFEvertorsRt"),
					new System.Data.Common.DataColumnMapping("PowerFEvertorsLt", "PowerFEvertorsLt"),
					new System.Data.Common.DataColumnMapping("PowerFIntrinsicsRt", "PowerFIntrinsicsRt"),
					new System.Data.Common.DataColumnMapping("PowerFIntrinsicsLt", "PowerFIntrinsicsLt"),
					new System.Data.Common.DataColumnMapping("PowerFExtrinsicsRt", "PowerFExtrinsicsRt"),
					new System.Data.Common.DataColumnMapping("PowerFExtrinsicsLt", "PowerFExtrinsicsLt"),
					new System.Data.Common.DataColumnMapping("PowerTrunkFlexorsRt", "PowerTrunkFlexorsRt"),
					new System.Data.Common.DataColumnMapping("PowerTrunkFlexorsLt", "PowerTrunkFlexorsLt"),
					new System.Data.Common.DataColumnMapping("PowerTrunkExtensorsRt", "PowerTrunkExtensorsRt"),
					new System.Data.Common.DataColumnMapping("PowerTrunkExtensorsLt", "PowerTrunkExtensorsLt"),
					new System.Data.Common.DataColumnMapping("PowerTrunkSideFlexorsRt", "PowerTrunkSideFlexorsRt"),
					new System.Data.Common.DataColumnMapping("PowerTrunkSideFlexorsLt", "PowerTrunkSideFlexorsLt"),
					new System.Data.Common.DataColumnMapping("PowerTrunkRotatorsRt", "PowerTrunkRotatorsRt"),
					new System.Data.Common.DataColumnMapping("PowerTrunkRotatorsLt", "PowerTrunkRotatorsLt")
				})
			});
			sqlDataAdapter5.UpdateCommand = sqlCommand13;
			sqlCommand10.CommandText = "DELETE FROM [Muscle_Power] WHERE (([ID] = @Original_ID) AND ([neurologicalID] = @Original_neurologicalID))";
			sqlCommand10.Connection = sqlConnection5;
			sqlCommand10.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection5.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection5.FireInfoMessageEventOnUserErrors = false;
			sqlCommand11.CommandText = resources.GetString("sqlCommand11.CommandText");
			sqlCommand11.Connection = sqlConnection5;
			sqlCommand11.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[71]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@PowerSFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerSFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerSFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerSFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerSExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerSExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerSExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerSExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerSAbductorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerSAbductorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerSAbductorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerSAbductorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerSAdductorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerSAdductorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerSAdductorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerSAdductorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerExternalRotRt", System.Data.SqlDbType.NVarChar, 0, "PowerExternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@PowerSExternalRotLt", System.Data.SqlDbType.NVarChar, 0, "PowerSExternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@PowerSInternalRotRt", System.Data.SqlDbType.NVarChar, 0, "PowerSInternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@PowerSInternalRotLt", System.Data.SqlDbType.NVarChar, 0, "PowerSInternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@PowerEFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerEFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerEFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerEFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerEExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerEExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerEExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerEExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerEForearmRt", System.Data.SqlDbType.NVarChar, 0, "PowerEForearmRt"),
				new System.Data.SqlClient.SqlParameter("@PowerEForearmLt", System.Data.SqlDbType.NVarChar, 0, "PowerEForearmLt"),
				new System.Data.SqlClient.SqlParameter("@PowerEPronatorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerEPronatorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerEPronatorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerEPronatorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerESupinatorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerESupinatorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerESupinatorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerESupinatorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerWFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerWFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerWFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerWFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerWExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerWExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerWExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerWExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerWRadialDevRt", System.Data.SqlDbType.NVarChar, 0, "PowerWRadialDevRt"),
				new System.Data.SqlClient.SqlParameter("@PowerWRadialDevLt", System.Data.SqlDbType.NVarChar, 0, "PowerWRadialDevLt"),
				new System.Data.SqlClient.SqlParameter("@PowerWUlnarDevRt", System.Data.SqlDbType.NVarChar, 0, "PowerWUlnarDevRt"),
				new System.Data.SqlClient.SqlParameter("@PowerWUlnarDevLt", System.Data.SqlDbType.NVarChar, 0, "PowerWUlnarDevLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIntrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIntrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIntrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIntrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerEHxtrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "PowerEHxtrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHExtrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "PowerHExtrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIAbductorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIAbductorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIAbductorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIAbductorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIAdductorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIAdductorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIAdductorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIAdductorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIExternalRotRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIExternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIExternalRotLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIExternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIInternalRotRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIInternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIInternalRotLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIInternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@PowerKFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerKFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerKFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerKFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerKExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerKExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerKExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerKExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerANDorsiflexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerANDorsiflexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerANDorsiflexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerANDorsiflexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerANPlantarflexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerANPlantarflexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerANPlantarflexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerANPlantarflexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerFInvertorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerFInvertorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerFInvertorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerFInvertorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerFEvertorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerFEvertorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerFEvertorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerFEvertorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerFIntrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "PowerFIntrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerFIntrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "PowerFIntrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerFExtrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "PowerFExtrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerFExtrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "PowerFExtrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkSideFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkSideFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkSideFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkSideFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkRotatorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkRotatorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkRotatorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkRotatorsLt")
			});
			sqlCommand12.CommandText = "SELECT        Muscle_Power.*\r\nFROM            Muscle_Power";
			sqlCommand12.Connection = sqlConnection5;
			sqlCommand13.CommandText = resources.GetString("sqlCommand13.CommandText");
			sqlCommand13.Connection = sqlConnection5;
			sqlCommand13.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[74]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@PowerSFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerSFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerSFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerSFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerSExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerSExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerSExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerSExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerSAbductorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerSAbductorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerSAbductorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerSAbductorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerSAdductorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerSAdductorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerSAdductorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerSAdductorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerExternalRotRt", System.Data.SqlDbType.NVarChar, 0, "PowerExternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@PowerSExternalRotLt", System.Data.SqlDbType.NVarChar, 0, "PowerSExternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@PowerSInternalRotRt", System.Data.SqlDbType.NVarChar, 0, "PowerSInternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@PowerSInternalRotLt", System.Data.SqlDbType.NVarChar, 0, "PowerSInternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@PowerEFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerEFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerEFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerEFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerEExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerEExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerEExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerEExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerEForearmRt", System.Data.SqlDbType.NVarChar, 0, "PowerEForearmRt"),
				new System.Data.SqlClient.SqlParameter("@PowerEForearmLt", System.Data.SqlDbType.NVarChar, 0, "PowerEForearmLt"),
				new System.Data.SqlClient.SqlParameter("@PowerEPronatorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerEPronatorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerEPronatorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerEPronatorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerESupinatorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerESupinatorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerESupinatorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerESupinatorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerWFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerWFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerWFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerWFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerWExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerWExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerWExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerWExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerWRadialDevRt", System.Data.SqlDbType.NVarChar, 0, "PowerWRadialDevRt"),
				new System.Data.SqlClient.SqlParameter("@PowerWRadialDevLt", System.Data.SqlDbType.NVarChar, 0, "PowerWRadialDevLt"),
				new System.Data.SqlClient.SqlParameter("@PowerWUlnarDevRt", System.Data.SqlDbType.NVarChar, 0, "PowerWUlnarDevRt"),
				new System.Data.SqlClient.SqlParameter("@PowerWUlnarDevLt", System.Data.SqlDbType.NVarChar, 0, "PowerWUlnarDevLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIntrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIntrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIntrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIntrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerEHxtrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "PowerEHxtrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHExtrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "PowerHExtrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIAbductorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIAbductorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIAbductorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIAbductorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIAdductorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIAdductorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIAdductorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIAdductorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIExternalRotRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIExternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIExternalRotLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIExternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIInternalRotRt", System.Data.SqlDbType.NVarChar, 0, "PowerHIInternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@PowerHIInternalRotLt", System.Data.SqlDbType.NVarChar, 0, "PowerHIInternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@PowerKFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerKFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerKFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerKFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerKExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerKExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerKExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerKExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerANDorsiflexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerANDorsiflexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerANDorsiflexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerANDorsiflexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerANPlantarflexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerANPlantarflexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerANPlantarflexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerANPlantarflexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerFInvertorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerFInvertorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerFInvertorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerFInvertorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerFEvertorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerFEvertorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerFEvertorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerFEvertorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerFIntrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "PowerFIntrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerFIntrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "PowerFIntrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerFExtrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "PowerFExtrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerFExtrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "PowerFExtrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkSideFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkSideFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkSideFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkSideFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkRotatorsRt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkRotatorsRt"),
				new System.Data.SqlClient.SqlParameter("@PowerTrunkRotatorsLt", System.Data.SqlDbType.NVarChar, 0, "PowerTrunkRotatorsLt"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDataAdapter6.DeleteCommand = sqlCommand14;
			sqlDataAdapter6.InsertCommand = sqlCommand15;
			sqlDataAdapter6.SelectCommand = sqlCommand16;
			sqlDataAdapter6.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Muscle_Tone", new System.Data.Common.DataColumnMapping[64]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("neurologicalID", "neurologicalID"),
					new System.Data.Common.DataColumnMapping("DGToneSFlexorsRt", "DGToneSFlexorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneSFlexorsLt", "DGToneSFlexorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneSExtensorsRt", "DGToneSExtensorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneSExtensorsLt", "DGToneSExtensorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneSAbductorsRt", "DGToneSAbductorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneSAbductorsLt", "DGToneSAbductorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneSAdductorsRt", "DGToneSAdductorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneSAdductorsLt", "DGToneSAdductorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneSExternalRotRt", "DGToneSExternalRotRt"),
					new System.Data.Common.DataColumnMapping("DGToneSExternalRotLt", "DGToneSExternalRotLt"),
					new System.Data.Common.DataColumnMapping("DGToneSInternalRotRt", "DGToneSInternalRotRt"),
					new System.Data.Common.DataColumnMapping("DGToneSInternalRotLt", "DGToneSInternalRotLt"),
					new System.Data.Common.DataColumnMapping("DGToneEFlexorsRt", "DGToneEFlexorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneEFlexorsLt", "DGToneEFlexorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneEExtensorsRt", "DGToneEExtensorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneEExtensorsLt", "DGToneEExtensorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneEForearmRt", "DGToneEForearmRt"),
					new System.Data.Common.DataColumnMapping("DGToneEForearmLt", "DGToneEForearmLt"),
					new System.Data.Common.DataColumnMapping("DGToneEPronatorsRt", "DGToneEPronatorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneEPronatorsLt", "DGToneEPronatorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneESupinatorsRt", "DGToneESupinatorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneESupinatorsLt", "DGToneESupinatorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneWFlexorsRt", "DGToneWFlexorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneWFlexorsLt", "DGToneWFlexorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneWExtensorsRt", "DGToneWExtensorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneWExtensorsLt", "DGToneWExtensorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneWRadialDevRt", "DGToneWRadialDevRt"),
					new System.Data.Common.DataColumnMapping("DGToneWRadialDevLt", "DGToneWRadialDevLt"),
					new System.Data.Common.DataColumnMapping("DGToneWUlnarDevRt", "DGToneWUlnarDevRt"),
					new System.Data.Common.DataColumnMapping("DGToneWUlnarDevLt", "DGToneWUlnarDevLt"),
					new System.Data.Common.DataColumnMapping("DGToneHIntrinsicsRt", "DGToneHIntrinsicsRt"),
					new System.Data.Common.DataColumnMapping("DGToneHIntrinsicsLt", "DGToneHIntrinsicsLt"),
					new System.Data.Common.DataColumnMapping("DGToneEHxtrinsicsRt", "DGToneEHxtrinsicsRt"),
					new System.Data.Common.DataColumnMapping("DGToneHExtrinsicsLt", "DGToneHExtrinsicsLt"),
					new System.Data.Common.DataColumnMapping("DGToneHIFlexorsRt", "DGToneHIFlexorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneHIFlexorsLt", "DGToneHIFlexorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneHIExtensorsRt", "DGToneHIExtensorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneHIExtensorsLt", "DGToneHIExtensorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneHIAbductorsRt", "DGToneHIAbductorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneHIAbductorsLt", "DGToneHIAbductorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneHIAdductorsRt", "DGToneHIAdductorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneHIAdductorsLt", "DGToneHIAdductorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneHIExternalRotRt", "DGToneHIExternalRotRt"),
					new System.Data.Common.DataColumnMapping("DGToneHIExternalRotLt", "DGToneHIExternalRotLt"),
					new System.Data.Common.DataColumnMapping("DGToneHIInternalRotRt", "DGToneHIInternalRotRt"),
					new System.Data.Common.DataColumnMapping("DGToneHIInternalRotLt", "DGToneHIInternalRotLt"),
					new System.Data.Common.DataColumnMapping("DGToneKFlexorsRt", "DGToneKFlexorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneKFlexorsLt", "DGToneKFlexorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneKExtensorsRt", "DGToneKExtensorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneKExtensorsLt", "DGToneKExtensorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneANDorsiflexorsRt", "DGToneANDorsiflexorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneANDorsiflexorsLt", "DGToneANDorsiflexorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneANPlantarflexorsRt", "DGToneANPlantarflexorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneANPlantarflexorsLt", "DGToneANPlantarflexorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneFInvertorsRt", "DGToneFInvertorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneFInvertorsLt", "DGToneFInvertorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneFEvertorsRt", "DGToneFEvertorsRt"),
					new System.Data.Common.DataColumnMapping("DGToneFEvertorsLt", "DGToneFEvertorsLt"),
					new System.Data.Common.DataColumnMapping("DGToneFIntrinsicsRt", "DGToneFIntrinsicsRt"),
					new System.Data.Common.DataColumnMapping("DGToneFIntrinsicsLt", "DGToneFIntrinsicsLt"),
					new System.Data.Common.DataColumnMapping("DGToneFExtrinsicsRt", "DGToneFExtrinsicsRt"),
					new System.Data.Common.DataColumnMapping("DGToneFExtrinsicsLt", "DGToneFExtrinsicsLt")
				})
			});
			sqlDataAdapter6.UpdateCommand = sqlCommand17;
			sqlCommand14.CommandText = "DELETE FROM [Muscle_Tone] WHERE (([ID] = @Original_ID) AND ([neurologicalID] = @Original_neurologicalID))";
			sqlCommand14.Connection = sqlConnection6;
			sqlCommand14.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection6.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection6.FireInfoMessageEventOnUserErrors = false;
			sqlCommand15.CommandText = resources.GetString("sqlCommand15.CommandText");
			sqlCommand15.Connection = sqlConnection6;
			sqlCommand15.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[63]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@DGToneSFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneSFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneSFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneSExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneSExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSAbductorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneSAbductorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSAbductorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneSAbductorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSAdductorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneSAdductorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSAdductorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneSAdductorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSExternalRotRt", System.Data.SqlDbType.NVarChar, 0, "DGToneSExternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSExternalRotLt", System.Data.SqlDbType.NVarChar, 0, "DGToneSExternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSInternalRotRt", System.Data.SqlDbType.NVarChar, 0, "DGToneSInternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSInternalRotLt", System.Data.SqlDbType.NVarChar, 0, "DGToneSInternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneEFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneEFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneEExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneEExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEForearmRt", System.Data.SqlDbType.NVarChar, 0, "DGToneEForearmRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEForearmLt", System.Data.SqlDbType.NVarChar, 0, "DGToneEForearmLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEPronatorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneEPronatorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEPronatorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneEPronatorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneESupinatorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneESupinatorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneESupinatorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneESupinatorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneWFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneWFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneWExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneWExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWRadialDevRt", System.Data.SqlDbType.NVarChar, 0, "DGToneWRadialDevRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWRadialDevLt", System.Data.SqlDbType.NVarChar, 0, "DGToneWRadialDevLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWUlnarDevRt", System.Data.SqlDbType.NVarChar, 0, "DGToneWUlnarDevRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWUlnarDevLt", System.Data.SqlDbType.NVarChar, 0, "DGToneWUlnarDevLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIntrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIntrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIntrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIntrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEHxtrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneEHxtrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHExtrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHExtrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIAbductorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIAbductorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIAbductorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIAbductorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIAdductorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIAdductorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIAdductorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIAdductorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIExternalRotRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIExternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIExternalRotLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIExternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIInternalRotRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIInternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIInternalRotLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIInternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneKFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneKFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneKFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneKFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneKExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneKExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneKExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneKExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneANDorsiflexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneANDorsiflexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneANDorsiflexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneANDorsiflexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneANPlantarflexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneANPlantarflexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneANPlantarflexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneANPlantarflexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFInvertorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneFInvertorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFInvertorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneFInvertorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFEvertorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneFEvertorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFEvertorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneFEvertorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFIntrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneFIntrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFIntrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneFIntrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFExtrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneFExtrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFExtrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneFExtrinsicsLt")
			});
			sqlCommand16.CommandText = "SELECT        Muscle_Tone.*\r\nFROM            Muscle_Tone";
			sqlCommand16.Connection = sqlConnection6;
			sqlCommand17.CommandText = resources.GetString("sqlCommand17.CommandText");
			sqlCommand17.Connection = sqlConnection6;
			sqlCommand17.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[66]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@DGToneSFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneSFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneSFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneSExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneSExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSAbductorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneSAbductorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSAbductorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneSAbductorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSAdductorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneSAdductorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSAdductorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneSAdductorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSExternalRotRt", System.Data.SqlDbType.NVarChar, 0, "DGToneSExternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSExternalRotLt", System.Data.SqlDbType.NVarChar, 0, "DGToneSExternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSInternalRotRt", System.Data.SqlDbType.NVarChar, 0, "DGToneSInternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneSInternalRotLt", System.Data.SqlDbType.NVarChar, 0, "DGToneSInternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneEFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneEFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneEExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneEExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEForearmRt", System.Data.SqlDbType.NVarChar, 0, "DGToneEForearmRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEForearmLt", System.Data.SqlDbType.NVarChar, 0, "DGToneEForearmLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEPronatorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneEPronatorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEPronatorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneEPronatorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneESupinatorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneESupinatorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneESupinatorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneESupinatorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneWFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneWFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneWExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneWExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWRadialDevRt", System.Data.SqlDbType.NVarChar, 0, "DGToneWRadialDevRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWRadialDevLt", System.Data.SqlDbType.NVarChar, 0, "DGToneWRadialDevLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWUlnarDevRt", System.Data.SqlDbType.NVarChar, 0, "DGToneWUlnarDevRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneWUlnarDevLt", System.Data.SqlDbType.NVarChar, 0, "DGToneWUlnarDevLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIntrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIntrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIntrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIntrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneEHxtrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneEHxtrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHExtrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHExtrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIAbductorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIAbductorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIAbductorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIAbductorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIAdductorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIAdductorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIAdductorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIAdductorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIExternalRotRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIExternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIExternalRotLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIExternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIInternalRotRt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIInternalRotRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneHIInternalRotLt", System.Data.SqlDbType.NVarChar, 0, "DGToneHIInternalRotLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneKFlexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneKFlexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneKFlexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneKFlexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneKExtensorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneKExtensorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneKExtensorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneKExtensorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneANDorsiflexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneANDorsiflexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneANDorsiflexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneANDorsiflexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneANPlantarflexorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneANPlantarflexorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneANPlantarflexorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneANPlantarflexorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFInvertorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneFInvertorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFInvertorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneFInvertorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFEvertorsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneFEvertorsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFEvertorsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneFEvertorsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFIntrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneFIntrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFIntrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneFIntrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFExtrinsicsRt", System.Data.SqlDbType.NVarChar, 0, "DGToneFExtrinsicsRt"),
				new System.Data.SqlClient.SqlParameter("@DGToneFExtrinsicsLt", System.Data.SqlDbType.NVarChar, 0, "DGToneFExtrinsicsLt"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDataAdapter7.DeleteCommand = sqlCommand18;
			sqlDataAdapter7.InsertCommand = sqlCommand19;
			sqlDataAdapter7.SelectCommand = sqlCommand20;
			sqlDataAdapter7.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Problem_List", new System.Data.Common.DataColumnMapping[5]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("neurologicalID", "neurologicalID"),
					new System.Data.Common.DataColumnMapping("SI", "SI"),
					new System.Data.Common.DataColumnMapping("Impairment", "Impairment"),
					new System.Data.Common.DataColumnMapping("FunctionalLimitation", "FunctionalLimitation")
				})
			});
			sqlDataAdapter7.UpdateCommand = sqlCommand21;
			sqlCommand18.CommandText = "DELETE FROM [Problem_List] WHERE (([ID] = @Original_ID) AND ([neurologicalID] = @Original_neurologicalID))";
			sqlCommand18.Connection = sqlConnection7;
			sqlCommand18.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection7.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection7.FireInfoMessageEventOnUserErrors = false;
			sqlCommand19.CommandText = resources.GetString("sqlCommand19.CommandText");
			sqlCommand19.Connection = sqlConnection7;
			sqlCommand19.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[4]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@SI", System.Data.SqlDbType.NVarChar, 0, "SI"),
				new System.Data.SqlClient.SqlParameter("@Impairment", System.Data.SqlDbType.NVarChar, 0, "Impairment"),
				new System.Data.SqlClient.SqlParameter("@FunctionalLimitation", System.Data.SqlDbType.NVarChar, 0, "FunctionalLimitation")
			});
			sqlCommand20.CommandText = "SELECT        Problem_List.*\r\nFROM            Problem_List";
			sqlCommand20.Connection = sqlConnection7;
			sqlCommand21.CommandText = resources.GetString("sqlCommand21.CommandText");
			sqlCommand21.Connection = sqlConnection7;
			sqlCommand21.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@SI", System.Data.SqlDbType.NVarChar, 0, "SI"),
				new System.Data.SqlClient.SqlParameter("@Impairment", System.Data.SqlDbType.NVarChar, 0, "Impairment"),
				new System.Data.SqlClient.SqlParameter("@FunctionalLimitation", System.Data.SqlDbType.NVarChar, 0, "FunctionalLimitation"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDataAdapter8.DeleteCommand = sqlCommand22;
			sqlDataAdapter8.InsertCommand = sqlCommand23;
			sqlDataAdapter8.SelectCommand = sqlCommand24;
			sqlDataAdapter8.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Range_of_Motion", new System.Data.Common.DataColumnMapping[46]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("neurologicalID", "neurologicalID"),
					new System.Data.Common.DataColumnMapping("DGShoulderSide", "DGShoulderSide"),
					new System.Data.Common.DataColumnMapping("DGShoulderMovement", "DGShoulderMovement"),
					new System.Data.Common.DataColumnMapping("DGShoulderLimitation", "DGShoulderLimitation"),
					new System.Data.Common.DataColumnMapping("DGShoulderfactor", "DGShoulderfactor"),
					new System.Data.Common.DataColumnMapping("DGElbowSide", "DGElbowSide"),
					new System.Data.Common.DataColumnMapping("DGElbowMovement", "DGElbowMovement"),
					new System.Data.Common.DataColumnMapping("DGElbowLimitation", "DGElbowLimitation"),
					new System.Data.Common.DataColumnMapping("DGElbowfactor", "DGElbowfactor"),
					new System.Data.Common.DataColumnMapping("DGForearmSide", "DGForearmSide"),
					new System.Data.Common.DataColumnMapping("DGForearmMovement", "DGForearmMovement"),
					new System.Data.Common.DataColumnMapping("DGForearmLimitation", "DGForearmLimitation"),
					new System.Data.Common.DataColumnMapping("DGForearmfactor", "DGForearmfactor"),
					new System.Data.Common.DataColumnMapping("DGWristSide", "DGWristSide"),
					new System.Data.Common.DataColumnMapping("DGWristMovement", "DGWristMovement"),
					new System.Data.Common.DataColumnMapping("DGWristLimitation", "DGWristLimitation"),
					new System.Data.Common.DataColumnMapping("DGWristfactor", "DGWristfactor"),
					new System.Data.Common.DataColumnMapping("DGHandFingersSide", "DGHandFingersSide"),
					new System.Data.Common.DataColumnMapping("DGHandFingersMovement", "DGHandFingersMovement"),
					new System.Data.Common.DataColumnMapping("DGHandFingersLimitation", "DGHandFingersLimitation"),
					new System.Data.Common.DataColumnMapping("DGHandFingersfactor", "DGHandFingersfactor"),
					new System.Data.Common.DataColumnMapping("DGHipSide", "DGHipSide"),
					new System.Data.Common.DataColumnMapping("DGHipMovement", "DGHipMovement"),
					new System.Data.Common.DataColumnMapping("DGHipLimitation", "DGHipLimitation"),
					new System.Data.Common.DataColumnMapping("DGHipfactor", "DGHipfactor"),
					new System.Data.Common.DataColumnMapping("DGKneeSide", "DGKneeSide"),
					new System.Data.Common.DataColumnMapping("DGKneeMovement", "DGKneeMovement"),
					new System.Data.Common.DataColumnMapping("DGKneeLimitation", "DGKneeLimitation"),
					new System.Data.Common.DataColumnMapping("DGKneefactor", "DGKneefactor"),
					new System.Data.Common.DataColumnMapping("DGAnklefootSide", "DGAnklefootSide"),
					new System.Data.Common.DataColumnMapping("DGAnklefootMovement", "DGAnklefootMovement"),
					new System.Data.Common.DataColumnMapping("DGAnklefootLimitation", "DGAnklefootLimitation"),
					new System.Data.Common.DataColumnMapping("DGAnklefootfactor", "DGAnklefootfactor"),
					new System.Data.Common.DataColumnMapping("DGCervicalSpineSide", "DGCervicalSpineSide"),
					new System.Data.Common.DataColumnMapping("DGCervicalSpineMovement", "DGCervicalSpineMovement"),
					new System.Data.Common.DataColumnMapping("DGCervicalSpineLimitation", "DGCervicalSpineLimitation"),
					new System.Data.Common.DataColumnMapping("DGCervicalSpinefactor", "DGCervicalSpinefactor"),
					new System.Data.Common.DataColumnMapping("DGThoracicSpineSide", "DGThoracicSpineSide"),
					new System.Data.Common.DataColumnMapping("DGThoracicSpineMovement", "DGThoracicSpineMovement"),
					new System.Data.Common.DataColumnMapping("DGThoracicSpineLimitation", "DGThoracicSpineLimitation"),
					new System.Data.Common.DataColumnMapping("DGThoracicSpinefactor", "DGThoracicSpinefactor"),
					new System.Data.Common.DataColumnMapping("DGLumbarSpineSide", "DGLumbarSpineSide"),
					new System.Data.Common.DataColumnMapping("DGLumbarSpineMovement", "DGLumbarSpineMovement"),
					new System.Data.Common.DataColumnMapping("DGLumbarSpineLimitation", "DGLumbarSpineLimitation"),
					new System.Data.Common.DataColumnMapping("DGLumbarSpinefactor", "DGLumbarSpinefactor")
				})
			});
			sqlDataAdapter8.UpdateCommand = sqlCommand25;
			sqlCommand22.CommandText = "DELETE FROM [Range_of_Motion] WHERE (([ID] = @Original_ID) AND ([neurologicalID] = @Original_neurologicalID))";
			sqlCommand22.Connection = sqlConnection8;
			sqlCommand22.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection8.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection8.FireInfoMessageEventOnUserErrors = false;
			sqlCommand23.CommandText = resources.GetString("sqlCommand23.CommandText");
			sqlCommand23.Connection = sqlConnection8;
			sqlCommand23.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[45]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@DGShoulderSide", System.Data.SqlDbType.NVarChar, 0, "DGShoulderSide"),
				new System.Data.SqlClient.SqlParameter("@DGShoulderMovement", System.Data.SqlDbType.NVarChar, 0, "DGShoulderMovement"),
				new System.Data.SqlClient.SqlParameter("@DGShoulderLimitation", System.Data.SqlDbType.NVarChar, 0, "DGShoulderLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGShoulderfactor", System.Data.SqlDbType.NVarChar, 0, "DGShoulderfactor"),
				new System.Data.SqlClient.SqlParameter("@DGElbowSide", System.Data.SqlDbType.NVarChar, 0, "DGElbowSide"),
				new System.Data.SqlClient.SqlParameter("@DGElbowMovement", System.Data.SqlDbType.NVarChar, 0, "DGElbowMovement"),
				new System.Data.SqlClient.SqlParameter("@DGElbowLimitation", System.Data.SqlDbType.NVarChar, 0, "DGElbowLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGElbowfactor", System.Data.SqlDbType.NVarChar, 0, "DGElbowfactor"),
				new System.Data.SqlClient.SqlParameter("@DGForearmSide", System.Data.SqlDbType.NVarChar, 0, "DGForearmSide"),
				new System.Data.SqlClient.SqlParameter("@DGForearmMovement", System.Data.SqlDbType.NVarChar, 0, "DGForearmMovement"),
				new System.Data.SqlClient.SqlParameter("@DGForearmLimitation", System.Data.SqlDbType.NVarChar, 0, "DGForearmLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGForearmfactor", System.Data.SqlDbType.NVarChar, 0, "DGForearmfactor"),
				new System.Data.SqlClient.SqlParameter("@DGWristSide", System.Data.SqlDbType.NVarChar, 0, "DGWristSide"),
				new System.Data.SqlClient.SqlParameter("@DGWristMovement", System.Data.SqlDbType.NVarChar, 0, "DGWristMovement"),
				new System.Data.SqlClient.SqlParameter("@DGWristLimitation", System.Data.SqlDbType.NVarChar, 0, "DGWristLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGWristfactor", System.Data.SqlDbType.NVarChar, 0, "DGWristfactor"),
				new System.Data.SqlClient.SqlParameter("@DGHandFingersSide", System.Data.SqlDbType.NVarChar, 0, "DGHandFingersSide"),
				new System.Data.SqlClient.SqlParameter("@DGHandFingersMovement", System.Data.SqlDbType.NVarChar, 0, "DGHandFingersMovement"),
				new System.Data.SqlClient.SqlParameter("@DGHandFingersLimitation", System.Data.SqlDbType.NVarChar, 0, "DGHandFingersLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGHandFingersfactor", System.Data.SqlDbType.NVarChar, 0, "DGHandFingersfactor"),
				new System.Data.SqlClient.SqlParameter("@DGHipSide", System.Data.SqlDbType.NVarChar, 0, "DGHipSide"),
				new System.Data.SqlClient.SqlParameter("@DGHipMovement", System.Data.SqlDbType.NVarChar, 0, "DGHipMovement"),
				new System.Data.SqlClient.SqlParameter("@DGHipLimitation", System.Data.SqlDbType.NVarChar, 0, "DGHipLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGHipfactor", System.Data.SqlDbType.NVarChar, 0, "DGHipfactor"),
				new System.Data.SqlClient.SqlParameter("@DGKneeSide", System.Data.SqlDbType.NVarChar, 0, "DGKneeSide"),
				new System.Data.SqlClient.SqlParameter("@DGKneeMovement", System.Data.SqlDbType.NVarChar, 0, "DGKneeMovement"),
				new System.Data.SqlClient.SqlParameter("@DGKneeLimitation", System.Data.SqlDbType.NVarChar, 0, "DGKneeLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGKneefactor", System.Data.SqlDbType.NVarChar, 0, "DGKneefactor"),
				new System.Data.SqlClient.SqlParameter("@DGAnklefootSide", System.Data.SqlDbType.NVarChar, 0, "DGAnklefootSide"),
				new System.Data.SqlClient.SqlParameter("@DGAnklefootMovement", System.Data.SqlDbType.NVarChar, 0, "DGAnklefootMovement"),
				new System.Data.SqlClient.SqlParameter("@DGAnklefootLimitation", System.Data.SqlDbType.NVarChar, 0, "DGAnklefootLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGAnklefootfactor", System.Data.SqlDbType.NVarChar, 0, "DGAnklefootfactor"),
				new System.Data.SqlClient.SqlParameter("@DGCervicalSpineSide", System.Data.SqlDbType.NVarChar, 0, "DGCervicalSpineSide"),
				new System.Data.SqlClient.SqlParameter("@DGCervicalSpineMovement", System.Data.SqlDbType.NVarChar, 0, "DGCervicalSpineMovement"),
				new System.Data.SqlClient.SqlParameter("@DGCervicalSpineLimitation", System.Data.SqlDbType.NVarChar, 0, "DGCervicalSpineLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGCervicalSpinefactor", System.Data.SqlDbType.NVarChar, 0, "DGCervicalSpinefactor"),
				new System.Data.SqlClient.SqlParameter("@DGThoracicSpineSide", System.Data.SqlDbType.NVarChar, 0, "DGThoracicSpineSide"),
				new System.Data.SqlClient.SqlParameter("@DGThoracicSpineMovement", System.Data.SqlDbType.NVarChar, 0, "DGThoracicSpineMovement"),
				new System.Data.SqlClient.SqlParameter("@DGThoracicSpineLimitation", System.Data.SqlDbType.NVarChar, 0, "DGThoracicSpineLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGThoracicSpinefactor", System.Data.SqlDbType.NVarChar, 0, "DGThoracicSpinefactor"),
				new System.Data.SqlClient.SqlParameter("@DGLumbarSpineSide", System.Data.SqlDbType.NVarChar, 0, "DGLumbarSpineSide"),
				new System.Data.SqlClient.SqlParameter("@DGLumbarSpineMovement", System.Data.SqlDbType.NVarChar, 0, "DGLumbarSpineMovement"),
				new System.Data.SqlClient.SqlParameter("@DGLumbarSpineLimitation", System.Data.SqlDbType.NVarChar, 0, "DGLumbarSpineLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGLumbarSpinefactor", System.Data.SqlDbType.NVarChar, 0, "DGLumbarSpinefactor")
			});
			sqlCommand24.CommandText = "SELECT        Range_of_Motion.*\r\nFROM            Range_of_Motion";
			sqlCommand24.Connection = sqlConnection8;
			sqlCommand25.CommandText = resources.GetString("sqlCommand25.CommandText");
			sqlCommand25.Connection = sqlConnection8;
			sqlCommand25.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[48]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@DGShoulderSide", System.Data.SqlDbType.NVarChar, 0, "DGShoulderSide"),
				new System.Data.SqlClient.SqlParameter("@DGShoulderMovement", System.Data.SqlDbType.NVarChar, 0, "DGShoulderMovement"),
				new System.Data.SqlClient.SqlParameter("@DGShoulderLimitation", System.Data.SqlDbType.NVarChar, 0, "DGShoulderLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGShoulderfactor", System.Data.SqlDbType.NVarChar, 0, "DGShoulderfactor"),
				new System.Data.SqlClient.SqlParameter("@DGElbowSide", System.Data.SqlDbType.NVarChar, 0, "DGElbowSide"),
				new System.Data.SqlClient.SqlParameter("@DGElbowMovement", System.Data.SqlDbType.NVarChar, 0, "DGElbowMovement"),
				new System.Data.SqlClient.SqlParameter("@DGElbowLimitation", System.Data.SqlDbType.NVarChar, 0, "DGElbowLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGElbowfactor", System.Data.SqlDbType.NVarChar, 0, "DGElbowfactor"),
				new System.Data.SqlClient.SqlParameter("@DGForearmSide", System.Data.SqlDbType.NVarChar, 0, "DGForearmSide"),
				new System.Data.SqlClient.SqlParameter("@DGForearmMovement", System.Data.SqlDbType.NVarChar, 0, "DGForearmMovement"),
				new System.Data.SqlClient.SqlParameter("@DGForearmLimitation", System.Data.SqlDbType.NVarChar, 0, "DGForearmLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGForearmfactor", System.Data.SqlDbType.NVarChar, 0, "DGForearmfactor"),
				new System.Data.SqlClient.SqlParameter("@DGWristSide", System.Data.SqlDbType.NVarChar, 0, "DGWristSide"),
				new System.Data.SqlClient.SqlParameter("@DGWristMovement", System.Data.SqlDbType.NVarChar, 0, "DGWristMovement"),
				new System.Data.SqlClient.SqlParameter("@DGWristLimitation", System.Data.SqlDbType.NVarChar, 0, "DGWristLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGWristfactor", System.Data.SqlDbType.NVarChar, 0, "DGWristfactor"),
				new System.Data.SqlClient.SqlParameter("@DGHandFingersSide", System.Data.SqlDbType.NVarChar, 0, "DGHandFingersSide"),
				new System.Data.SqlClient.SqlParameter("@DGHandFingersMovement", System.Data.SqlDbType.NVarChar, 0, "DGHandFingersMovement"),
				new System.Data.SqlClient.SqlParameter("@DGHandFingersLimitation", System.Data.SqlDbType.NVarChar, 0, "DGHandFingersLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGHandFingersfactor", System.Data.SqlDbType.NVarChar, 0, "DGHandFingersfactor"),
				new System.Data.SqlClient.SqlParameter("@DGHipSide", System.Data.SqlDbType.NVarChar, 0, "DGHipSide"),
				new System.Data.SqlClient.SqlParameter("@DGHipMovement", System.Data.SqlDbType.NVarChar, 0, "DGHipMovement"),
				new System.Data.SqlClient.SqlParameter("@DGHipLimitation", System.Data.SqlDbType.NVarChar, 0, "DGHipLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGHipfactor", System.Data.SqlDbType.NVarChar, 0, "DGHipfactor"),
				new System.Data.SqlClient.SqlParameter("@DGKneeSide", System.Data.SqlDbType.NVarChar, 0, "DGKneeSide"),
				new System.Data.SqlClient.SqlParameter("@DGKneeMovement", System.Data.SqlDbType.NVarChar, 0, "DGKneeMovement"),
				new System.Data.SqlClient.SqlParameter("@DGKneeLimitation", System.Data.SqlDbType.NVarChar, 0, "DGKneeLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGKneefactor", System.Data.SqlDbType.NVarChar, 0, "DGKneefactor"),
				new System.Data.SqlClient.SqlParameter("@DGAnklefootSide", System.Data.SqlDbType.NVarChar, 0, "DGAnklefootSide"),
				new System.Data.SqlClient.SqlParameter("@DGAnklefootMovement", System.Data.SqlDbType.NVarChar, 0, "DGAnklefootMovement"),
				new System.Data.SqlClient.SqlParameter("@DGAnklefootLimitation", System.Data.SqlDbType.NVarChar, 0, "DGAnklefootLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGAnklefootfactor", System.Data.SqlDbType.NVarChar, 0, "DGAnklefootfactor"),
				new System.Data.SqlClient.SqlParameter("@DGCervicalSpineSide", System.Data.SqlDbType.NVarChar, 0, "DGCervicalSpineSide"),
				new System.Data.SqlClient.SqlParameter("@DGCervicalSpineMovement", System.Data.SqlDbType.NVarChar, 0, "DGCervicalSpineMovement"),
				new System.Data.SqlClient.SqlParameter("@DGCervicalSpineLimitation", System.Data.SqlDbType.NVarChar, 0, "DGCervicalSpineLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGCervicalSpinefactor", System.Data.SqlDbType.NVarChar, 0, "DGCervicalSpinefactor"),
				new System.Data.SqlClient.SqlParameter("@DGThoracicSpineSide", System.Data.SqlDbType.NVarChar, 0, "DGThoracicSpineSide"),
				new System.Data.SqlClient.SqlParameter("@DGThoracicSpineMovement", System.Data.SqlDbType.NVarChar, 0, "DGThoracicSpineMovement"),
				new System.Data.SqlClient.SqlParameter("@DGThoracicSpineLimitation", System.Data.SqlDbType.NVarChar, 0, "DGThoracicSpineLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGThoracicSpinefactor", System.Data.SqlDbType.NVarChar, 0, "DGThoracicSpinefactor"),
				new System.Data.SqlClient.SqlParameter("@DGLumbarSpineSide", System.Data.SqlDbType.NVarChar, 0, "DGLumbarSpineSide"),
				new System.Data.SqlClient.SqlParameter("@DGLumbarSpineMovement", System.Data.SqlDbType.NVarChar, 0, "DGLumbarSpineMovement"),
				new System.Data.SqlClient.SqlParameter("@DGLumbarSpineLimitation", System.Data.SqlDbType.NVarChar, 0, "DGLumbarSpineLimitation"),
				new System.Data.SqlClient.SqlParameter("@DGLumbarSpinefactor", System.Data.SqlDbType.NVarChar, 0, "DGLumbarSpinefactor"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDataAdapter9.DeleteCommand = sqlCommand26;
			sqlDataAdapter9.InsertCommand = sqlCommand27;
			sqlDataAdapter9.SelectCommand = sqlCommand28;
			sqlDataAdapter9.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "SENSORY_SYSTEM", new System.Data.Common.DataColumnMapping[100]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("neurologicalID", "neurologicalID"),
					new System.Data.Common.DataColumnMapping("DGPainUpR", "DGPainUpR"),
					new System.Data.Common.DataColumnMapping("DGPainUpL", "DGPainUpL"),
					new System.Data.Common.DataColumnMapping("DGPainLoR", "DGPainLoR"),
					new System.Data.Common.DataColumnMapping("DGPainLoL", "DGPainLoL"),
					new System.Data.Common.DataColumnMapping("DGPainTrR", "DGPainTrR"),
					new System.Data.Common.DataColumnMapping("DGPainTrL", "DGPainTrL"),
					new System.Data.Common.DataColumnMapping("DGPainnote", "DGPainnote"),
					new System.Data.Common.DataColumnMapping("DGTemperatureUpR", "DGTemperatureUpR"),
					new System.Data.Common.DataColumnMapping("DGTemperatureUpL", "DGTemperatureUpL"),
					new System.Data.Common.DataColumnMapping("DGTemperatureLoR", "DGTemperatureLoR"),
					new System.Data.Common.DataColumnMapping("DGTemperatureLoL", "DGTemperatureLoL"),
					new System.Data.Common.DataColumnMapping("DGTemperatureTrR", "DGTemperatureTrR"),
					new System.Data.Common.DataColumnMapping("DGTemperatureTrL", "DGTemperatureTrL"),
					new System.Data.Common.DataColumnMapping("DGTemperaturenote", "DGTemperaturenote"),
					new System.Data.Common.DataColumnMapping("DGTouchUpR", "DGTouchUpR"),
					new System.Data.Common.DataColumnMapping("DGTouchUpL", "DGTouchUpL"),
					new System.Data.Common.DataColumnMapping("DGTouchLoR", "DGTouchLoR"),
					new System.Data.Common.DataColumnMapping("DGTouchLoL", "DGTouchLoL"),
					new System.Data.Common.DataColumnMapping("DGTouchTrR", "DGTouchTrR"),
					new System.Data.Common.DataColumnMapping("DGTouchTrL", "DGTouchTrL"),
					new System.Data.Common.DataColumnMapping("DGTouchnote", "DGTouchnote"),
					new System.Data.Common.DataColumnMapping("DGPressureUpR", "DGPressureUpR"),
					new System.Data.Common.DataColumnMapping("DGPressureUpL", "DGPressureUpL"),
					new System.Data.Common.DataColumnMapping("DGPressureLoR", "DGPressureLoR"),
					new System.Data.Common.DataColumnMapping("DGPressureLoL", "DGPressureLoL"),
					new System.Data.Common.DataColumnMapping("DGPressureTrR", "DGPressureTrR"),
					new System.Data.Common.DataColumnMapping("DGPressureTrL", "DGPressureTrL"),
					new System.Data.Common.DataColumnMapping("DGPressurenote", "DGPressurenote"),
					new System.Data.Common.DataColumnMapping("DGMovSenseUpR", "DGMovSenseUpR"),
					new System.Data.Common.DataColumnMapping("DGMovSenseUpL", "DGMovSenseUpL"),
					new System.Data.Common.DataColumnMapping("DGMovSenseLoR", "DGMovSenseLoR"),
					new System.Data.Common.DataColumnMapping("DGMovSenseLoL", "DGMovSenseLoL"),
					new System.Data.Common.DataColumnMapping("DGMovSenseTrR", "DGMovSenseTrR"),
					new System.Data.Common.DataColumnMapping("DGMovSenseTrL", "DGMovSenseTrL"),
					new System.Data.Common.DataColumnMapping("DGMovSensenote", "DGMovSensenote"),
					new System.Data.Common.DataColumnMapping("DGPosSenseUpR", "DGPosSenseUpR"),
					new System.Data.Common.DataColumnMapping("DGPosSenseUpL", "DGPosSenseUpL"),
					new System.Data.Common.DataColumnMapping("DGPosSenseLoR", "DGPosSenseLoR"),
					new System.Data.Common.DataColumnMapping("DGPosSenseLoL", "DGPosSenseLoL"),
					new System.Data.Common.DataColumnMapping("DGPosSenseTrR", "DGPosSenseTrR"),
					new System.Data.Common.DataColumnMapping("DGPosSenseTrL", "DGPosSenseTrL"),
					new System.Data.Common.DataColumnMapping("DGPosSensenote", "DGPosSensenote"),
					new System.Data.Common.DataColumnMapping("DGVibrationUpR", "DGVibrationUpR"),
					new System.Data.Common.DataColumnMapping("DGVibrationUpL", "DGVibrationUpL"),
					new System.Data.Common.DataColumnMapping("DGVibrationLoR", "DGVibrationLoR"),
					new System.Data.Common.DataColumnMapping("DGVibrationLoL", "DGVibrationLoL"),
					new System.Data.Common.DataColumnMapping("DGVibrationTrR", "DGVibrationTrR"),
					new System.Data.Common.DataColumnMapping("DGVibrationTrL", "DGVibrationTrL"),
					new System.Data.Common.DataColumnMapping("DGVibrationnote", "DGVibrationnote"),
					new System.Data.Common.DataColumnMapping("DGTactileLocalizationUpR", "DGTactileLocalizationUpR"),
					new System.Data.Common.DataColumnMapping("DGTactileLocalizationUpL", "DGTactileLocalizationUpL"),
					new System.Data.Common.DataColumnMapping("DGTactileLocalizationLoR", "DGTactileLocalizationLoR"),
					new System.Data.Common.DataColumnMapping("DGTactileLocalizationLoL", "DGTactileLocalizationLoL"),
					new System.Data.Common.DataColumnMapping("DGTactileLocalizationTrR", "DGTactileLocalizationTrR"),
					new System.Data.Common.DataColumnMapping("DGTactileLocalizationTrL", "DGTactileLocalizationTrL"),
					new System.Data.Common.DataColumnMapping("DGTactileLocalizationnote", "DGTactileLocalizationnote"),
					new System.Data.Common.DataColumnMapping("DGptdiscriminationUpR", "DGptdiscriminationUpR"),
					new System.Data.Common.DataColumnMapping("DGptdiscriminationUpL", "DGptdiscriminationUpL"),
					new System.Data.Common.DataColumnMapping("DGptdiscriminationLoR", "DGptdiscriminationLoR"),
					new System.Data.Common.DataColumnMapping("DGptdiscriminationLoL", "DGptdiscriminationLoL"),
					new System.Data.Common.DataColumnMapping("DGptdiscriminationTrR", "DGptdiscriminationTrR"),
					new System.Data.Common.DataColumnMapping("DGptdiscriminationTrL", "DGptdiscriminationTrL"),
					new System.Data.Common.DataColumnMapping("DGptdiscriminationnote", "DGptdiscriminationnote"),
					new System.Data.Common.DataColumnMapping("DGStereognosisUpR", "DGStereognosisUpR"),
					new System.Data.Common.DataColumnMapping("DGStereognosisUpL", "DGStereognosisUpL"),
					new System.Data.Common.DataColumnMapping("DGStereognosisLoR", "DGStereognosisLoR"),
					new System.Data.Common.DataColumnMapping("DGStereognosisLoL", "DGStereognosisLoL"),
					new System.Data.Common.DataColumnMapping("DGStereognosisTrR", "DGStereognosisTrR"),
					new System.Data.Common.DataColumnMapping("DGStereognosisTrL", "DGStereognosisTrL"),
					new System.Data.Common.DataColumnMapping("DGStereognosisnote", "DGStereognosisnote"),
					new System.Data.Common.DataColumnMapping("DGBarognosisUpR", "DGBarognosisUpR"),
					new System.Data.Common.DataColumnMapping("DGBarognosisUpL", "DGBarognosisUpL"),
					new System.Data.Common.DataColumnMapping("DGBarognosisLoR", "DGBarognosisLoR"),
					new System.Data.Common.DataColumnMapping("DGBarognosisLoL", "DGBarognosisLoL"),
					new System.Data.Common.DataColumnMapping("DGBarognosisTrR", "DGBarognosisTrR"),
					new System.Data.Common.DataColumnMapping("DGBarognosisTrL", "DGBarognosisTrL"),
					new System.Data.Common.DataColumnMapping("DGBarognosisnote", "DGBarognosisnote"),
					new System.Data.Common.DataColumnMapping("DGGraphesthesiaUpR", "DGGraphesthesiaUpR"),
					new System.Data.Common.DataColumnMapping("DGGraphesthesiaUpL", "DGGraphesthesiaUpL"),
					new System.Data.Common.DataColumnMapping("DGGraphesthesiaLoR", "DGGraphesthesiaLoR"),
					new System.Data.Common.DataColumnMapping("DGGraphesthesiaLoL", "DGGraphesthesiaLoL"),
					new System.Data.Common.DataColumnMapping("DGGraphesthesiaTrR", "DGGraphesthesiaTrR"),
					new System.Data.Common.DataColumnMapping("DGGraphesthesiaTrL", "DGGraphesthesiaTrL"),
					new System.Data.Common.DataColumnMapping("DGGraphesthesianote", "DGGraphesthesianote"),
					new System.Data.Common.DataColumnMapping("DGTextureRecognitionUpR", "DGTextureRecognitionUpR"),
					new System.Data.Common.DataColumnMapping("DGTextureRecognitionUpL", "DGTextureRecognitionUpL"),
					new System.Data.Common.DataColumnMapping("DGTextureRecognitionLoR", "DGTextureRecognitionLoR"),
					new System.Data.Common.DataColumnMapping("DGTextureRecognitionLoL", "DGTextureRecognitionLoL"),
					new System.Data.Common.DataColumnMapping("DGTextureRecognitionTrR", "DGTextureRecognitionTrR"),
					new System.Data.Common.DataColumnMapping("DGTextureRecognitionTrL", "DGTextureRecognitionTrL"),
					new System.Data.Common.DataColumnMapping("DGTextureRecognitionnote", "DGTextureRecognitionnote"),
					new System.Data.Common.DataColumnMapping("DGStimulationUpR", "DGStimulationUpR"),
					new System.Data.Common.DataColumnMapping("DGStimulationUpL", "DGStimulationUpL"),
					new System.Data.Common.DataColumnMapping("DGStimulationLoR", "DGStimulationLoR"),
					new System.Data.Common.DataColumnMapping("DGStimulationLoL", "DGStimulationLoL"),
					new System.Data.Common.DataColumnMapping("DGStimulationTrR", "DGStimulationTrR"),
					new System.Data.Common.DataColumnMapping("DGStimulationTrL", "DGStimulationTrL"),
					new System.Data.Common.DataColumnMapping("DGStimulationnote", "DGStimulationnote")
				})
			});
			sqlDataAdapter9.UpdateCommand = sqlCommand29;
			sqlCommand26.CommandText = "DELETE FROM [SENSORY_SYSTEM] WHERE (([ID] = @Original_ID) AND ([neurologicalID] = @Original_neurologicalID))";
			sqlCommand26.Connection = sqlConnection9;
			sqlCommand26.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection9.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection9.FireInfoMessageEventOnUserErrors = false;
			sqlCommand27.CommandText = resources.GetString("sqlCommand27.CommandText");
			sqlCommand27.Connection = sqlConnection9;
			sqlCommand27.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[99]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@DGPainUpR", System.Data.SqlDbType.NVarChar, 0, "DGPainUpR"),
				new System.Data.SqlClient.SqlParameter("@DGPainUpL", System.Data.SqlDbType.NVarChar, 0, "DGPainUpL"),
				new System.Data.SqlClient.SqlParameter("@DGPainLoR", System.Data.SqlDbType.NVarChar, 0, "DGPainLoR"),
				new System.Data.SqlClient.SqlParameter("@DGPainLoL", System.Data.SqlDbType.NVarChar, 0, "DGPainLoL"),
				new System.Data.SqlClient.SqlParameter("@DGPainTrR", System.Data.SqlDbType.NVarChar, 0, "DGPainTrR"),
				new System.Data.SqlClient.SqlParameter("@DGPainTrL", System.Data.SqlDbType.NVarChar, 0, "DGPainTrL"),
				new System.Data.SqlClient.SqlParameter("@DGPainnote", System.Data.SqlDbType.NVarChar, 0, "DGPainnote"),
				new System.Data.SqlClient.SqlParameter("@DGTemperatureUpR", System.Data.SqlDbType.NVarChar, 0, "DGTemperatureUpR"),
				new System.Data.SqlClient.SqlParameter("@DGTemperatureUpL", System.Data.SqlDbType.NVarChar, 0, "DGTemperatureUpL"),
				new System.Data.SqlClient.SqlParameter("@DGTemperatureLoR", System.Data.SqlDbType.NVarChar, 0, "DGTemperatureLoR"),
				new System.Data.SqlClient.SqlParameter("@DGTemperatureLoL", System.Data.SqlDbType.NVarChar, 0, "DGTemperatureLoL"),
				new System.Data.SqlClient.SqlParameter("@DGTemperatureTrR", System.Data.SqlDbType.NVarChar, 0, "DGTemperatureTrR"),
				new System.Data.SqlClient.SqlParameter("@DGTemperatureTrL", System.Data.SqlDbType.NVarChar, 0, "DGTemperatureTrL"),
				new System.Data.SqlClient.SqlParameter("@DGTemperaturenote", System.Data.SqlDbType.NVarChar, 0, "DGTemperaturenote"),
				new System.Data.SqlClient.SqlParameter("@DGTouchUpR", System.Data.SqlDbType.NVarChar, 0, "DGTouchUpR"),
				new System.Data.SqlClient.SqlParameter("@DGTouchUpL", System.Data.SqlDbType.NVarChar, 0, "DGTouchUpL"),
				new System.Data.SqlClient.SqlParameter("@DGTouchLoR", System.Data.SqlDbType.NVarChar, 0, "DGTouchLoR"),
				new System.Data.SqlClient.SqlParameter("@DGTouchLoL", System.Data.SqlDbType.NVarChar, 0, "DGTouchLoL"),
				new System.Data.SqlClient.SqlParameter("@DGTouchTrR", System.Data.SqlDbType.NVarChar, 0, "DGTouchTrR"),
				new System.Data.SqlClient.SqlParameter("@DGTouchTrL", System.Data.SqlDbType.NVarChar, 0, "DGTouchTrL"),
				new System.Data.SqlClient.SqlParameter("@DGTouchnote", System.Data.SqlDbType.NVarChar, 0, "DGTouchnote"),
				new System.Data.SqlClient.SqlParameter("@DGPressureUpR", System.Data.SqlDbType.NVarChar, 0, "DGPressureUpR"),
				new System.Data.SqlClient.SqlParameter("@DGPressureUpL", System.Data.SqlDbType.NVarChar, 0, "DGPressureUpL"),
				new System.Data.SqlClient.SqlParameter("@DGPressureLoR", System.Data.SqlDbType.NVarChar, 0, "DGPressureLoR"),
				new System.Data.SqlClient.SqlParameter("@DGPressureLoL", System.Data.SqlDbType.NVarChar, 0, "DGPressureLoL"),
				new System.Data.SqlClient.SqlParameter("@DGPressureTrR", System.Data.SqlDbType.NVarChar, 0, "DGPressureTrR"),
				new System.Data.SqlClient.SqlParameter("@DGPressureTrL", System.Data.SqlDbType.NVarChar, 0, "DGPressureTrL"),
				new System.Data.SqlClient.SqlParameter("@DGPressurenote", System.Data.SqlDbType.NVarChar, 0, "DGPressurenote"),
				new System.Data.SqlClient.SqlParameter("@DGMovSenseUpR", System.Data.SqlDbType.NVarChar, 0, "DGMovSenseUpR"),
				new System.Data.SqlClient.SqlParameter("@DGMovSenseUpL", System.Data.SqlDbType.NVarChar, 0, "DGMovSenseUpL"),
				new System.Data.SqlClient.SqlParameter("@DGMovSenseLoR", System.Data.SqlDbType.NVarChar, 0, "DGMovSenseLoR"),
				new System.Data.SqlClient.SqlParameter("@DGMovSenseLoL", System.Data.SqlDbType.NVarChar, 0, "DGMovSenseLoL"),
				new System.Data.SqlClient.SqlParameter("@DGMovSenseTrR", System.Data.SqlDbType.NVarChar, 0, "DGMovSenseTrR"),
				new System.Data.SqlClient.SqlParameter("@DGMovSenseTrL", System.Data.SqlDbType.NVarChar, 0, "DGMovSenseTrL"),
				new System.Data.SqlClient.SqlParameter("@DGMovSensenote", System.Data.SqlDbType.NVarChar, 0, "DGMovSensenote"),
				new System.Data.SqlClient.SqlParameter("@DGPosSenseUpR", System.Data.SqlDbType.NVarChar, 0, "DGPosSenseUpR"),
				new System.Data.SqlClient.SqlParameter("@DGPosSenseUpL", System.Data.SqlDbType.NVarChar, 0, "DGPosSenseUpL"),
				new System.Data.SqlClient.SqlParameter("@DGPosSenseLoR", System.Data.SqlDbType.NVarChar, 0, "DGPosSenseLoR"),
				new System.Data.SqlClient.SqlParameter("@DGPosSenseLoL", System.Data.SqlDbType.NVarChar, 0, "DGPosSenseLoL"),
				new System.Data.SqlClient.SqlParameter("@DGPosSenseTrR", System.Data.SqlDbType.NVarChar, 0, "DGPosSenseTrR"),
				new System.Data.SqlClient.SqlParameter("@DGPosSenseTrL", System.Data.SqlDbType.NVarChar, 0, "DGPosSenseTrL"),
				new System.Data.SqlClient.SqlParameter("@DGPosSensenote", System.Data.SqlDbType.NVarChar, 0, "DGPosSensenote"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationUpR", System.Data.SqlDbType.NVarChar, 0, "DGVibrationUpR"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationUpL", System.Data.SqlDbType.NVarChar, 0, "DGVibrationUpL"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationLoR", System.Data.SqlDbType.NVarChar, 0, "DGVibrationLoR"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationLoL", System.Data.SqlDbType.NVarChar, 0, "DGVibrationLoL"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationTrR", System.Data.SqlDbType.NVarChar, 0, "DGVibrationTrR"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationTrL", System.Data.SqlDbType.NVarChar, 0, "DGVibrationTrL"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationnote", System.Data.SqlDbType.NVarChar, 0, "DGVibrationnote"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationUpR", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationUpR"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationUpL", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationUpL"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationLoR", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationLoR"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationLoL", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationLoL"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationTrR", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationTrR"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationTrL", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationTrL"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationnote", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationnote"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationUpR", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationUpR"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationUpL", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationUpL"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationLoR", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationLoR"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationLoL", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationLoL"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationTrR", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationTrR"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationTrL", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationTrL"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationnote", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationnote"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisUpR", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisUpR"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisUpL", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisUpL"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisLoR", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisLoR"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisLoL", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisLoL"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisTrR", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisTrR"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisTrL", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisTrL"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisnote", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisnote"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisUpR", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisUpR"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisUpL", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisUpL"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisLoR", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisLoR"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisLoL", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisLoL"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisTrR", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisTrR"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisTrL", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisTrL"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisnote", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisnote"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesiaUpR", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesiaUpR"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesiaUpL", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesiaUpL"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesiaLoR", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesiaLoR"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesiaLoL", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesiaLoL"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesiaTrR", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesiaTrR"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesiaTrL", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesiaTrL"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesianote", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesianote"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionUpR", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionUpR"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionUpL", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionUpL"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionLoR", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionLoR"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionLoL", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionLoL"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionTrR", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionTrR"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionTrL", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionTrL"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionnote", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionnote"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationUpR", System.Data.SqlDbType.NVarChar, 0, "DGStimulationUpR"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationUpL", System.Data.SqlDbType.NVarChar, 0, "DGStimulationUpL"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationLoR", System.Data.SqlDbType.NVarChar, 0, "DGStimulationLoR"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationLoL", System.Data.SqlDbType.NVarChar, 0, "DGStimulationLoL"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationTrR", System.Data.SqlDbType.NVarChar, 0, "DGStimulationTrR"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationTrL", System.Data.SqlDbType.NVarChar, 0, "DGStimulationTrL"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationnote", System.Data.SqlDbType.NVarChar, 0, "DGStimulationnote")
			});
			sqlCommand28.CommandText = "SELECT        SENSORY_SYSTEM.*\r\nFROM            SENSORY_SYSTEM";
			sqlCommand28.Connection = sqlConnection9;
			sqlCommand29.CommandText = resources.GetString("sqlCommand29.CommandText");
			sqlCommand29.Connection = sqlConnection9;
			sqlCommand29.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[102]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@DGPainUpR", System.Data.SqlDbType.NVarChar, 0, "DGPainUpR"),
				new System.Data.SqlClient.SqlParameter("@DGPainUpL", System.Data.SqlDbType.NVarChar, 0, "DGPainUpL"),
				new System.Data.SqlClient.SqlParameter("@DGPainLoR", System.Data.SqlDbType.NVarChar, 0, "DGPainLoR"),
				new System.Data.SqlClient.SqlParameter("@DGPainLoL", System.Data.SqlDbType.NVarChar, 0, "DGPainLoL"),
				new System.Data.SqlClient.SqlParameter("@DGPainTrR", System.Data.SqlDbType.NVarChar, 0, "DGPainTrR"),
				new System.Data.SqlClient.SqlParameter("@DGPainTrL", System.Data.SqlDbType.NVarChar, 0, "DGPainTrL"),
				new System.Data.SqlClient.SqlParameter("@DGPainnote", System.Data.SqlDbType.NVarChar, 0, "DGPainnote"),
				new System.Data.SqlClient.SqlParameter("@DGTemperatureUpR", System.Data.SqlDbType.NVarChar, 0, "DGTemperatureUpR"),
				new System.Data.SqlClient.SqlParameter("@DGTemperatureUpL", System.Data.SqlDbType.NVarChar, 0, "DGTemperatureUpL"),
				new System.Data.SqlClient.SqlParameter("@DGTemperatureLoR", System.Data.SqlDbType.NVarChar, 0, "DGTemperatureLoR"),
				new System.Data.SqlClient.SqlParameter("@DGTemperatureLoL", System.Data.SqlDbType.NVarChar, 0, "DGTemperatureLoL"),
				new System.Data.SqlClient.SqlParameter("@DGTemperatureTrR", System.Data.SqlDbType.NVarChar, 0, "DGTemperatureTrR"),
				new System.Data.SqlClient.SqlParameter("@DGTemperatureTrL", System.Data.SqlDbType.NVarChar, 0, "DGTemperatureTrL"),
				new System.Data.SqlClient.SqlParameter("@DGTemperaturenote", System.Data.SqlDbType.NVarChar, 0, "DGTemperaturenote"),
				new System.Data.SqlClient.SqlParameter("@DGTouchUpR", System.Data.SqlDbType.NVarChar, 0, "DGTouchUpR"),
				new System.Data.SqlClient.SqlParameter("@DGTouchUpL", System.Data.SqlDbType.NVarChar, 0, "DGTouchUpL"),
				new System.Data.SqlClient.SqlParameter("@DGTouchLoR", System.Data.SqlDbType.NVarChar, 0, "DGTouchLoR"),
				new System.Data.SqlClient.SqlParameter("@DGTouchLoL", System.Data.SqlDbType.NVarChar, 0, "DGTouchLoL"),
				new System.Data.SqlClient.SqlParameter("@DGTouchTrR", System.Data.SqlDbType.NVarChar, 0, "DGTouchTrR"),
				new System.Data.SqlClient.SqlParameter("@DGTouchTrL", System.Data.SqlDbType.NVarChar, 0, "DGTouchTrL"),
				new System.Data.SqlClient.SqlParameter("@DGTouchnote", System.Data.SqlDbType.NVarChar, 0, "DGTouchnote"),
				new System.Data.SqlClient.SqlParameter("@DGPressureUpR", System.Data.SqlDbType.NVarChar, 0, "DGPressureUpR"),
				new System.Data.SqlClient.SqlParameter("@DGPressureUpL", System.Data.SqlDbType.NVarChar, 0, "DGPressureUpL"),
				new System.Data.SqlClient.SqlParameter("@DGPressureLoR", System.Data.SqlDbType.NVarChar, 0, "DGPressureLoR"),
				new System.Data.SqlClient.SqlParameter("@DGPressureLoL", System.Data.SqlDbType.NVarChar, 0, "DGPressureLoL"),
				new System.Data.SqlClient.SqlParameter("@DGPressureTrR", System.Data.SqlDbType.NVarChar, 0, "DGPressureTrR"),
				new System.Data.SqlClient.SqlParameter("@DGPressureTrL", System.Data.SqlDbType.NVarChar, 0, "DGPressureTrL"),
				new System.Data.SqlClient.SqlParameter("@DGPressurenote", System.Data.SqlDbType.NVarChar, 0, "DGPressurenote"),
				new System.Data.SqlClient.SqlParameter("@DGMovSenseUpR", System.Data.SqlDbType.NVarChar, 0, "DGMovSenseUpR"),
				new System.Data.SqlClient.SqlParameter("@DGMovSenseUpL", System.Data.SqlDbType.NVarChar, 0, "DGMovSenseUpL"),
				new System.Data.SqlClient.SqlParameter("@DGMovSenseLoR", System.Data.SqlDbType.NVarChar, 0, "DGMovSenseLoR"),
				new System.Data.SqlClient.SqlParameter("@DGMovSenseLoL", System.Data.SqlDbType.NVarChar, 0, "DGMovSenseLoL"),
				new System.Data.SqlClient.SqlParameter("@DGMovSenseTrR", System.Data.SqlDbType.NVarChar, 0, "DGMovSenseTrR"),
				new System.Data.SqlClient.SqlParameter("@DGMovSenseTrL", System.Data.SqlDbType.NVarChar, 0, "DGMovSenseTrL"),
				new System.Data.SqlClient.SqlParameter("@DGMovSensenote", System.Data.SqlDbType.NVarChar, 0, "DGMovSensenote"),
				new System.Data.SqlClient.SqlParameter("@DGPosSenseUpR", System.Data.SqlDbType.NVarChar, 0, "DGPosSenseUpR"),
				new System.Data.SqlClient.SqlParameter("@DGPosSenseUpL", System.Data.SqlDbType.NVarChar, 0, "DGPosSenseUpL"),
				new System.Data.SqlClient.SqlParameter("@DGPosSenseLoR", System.Data.SqlDbType.NVarChar, 0, "DGPosSenseLoR"),
				new System.Data.SqlClient.SqlParameter("@DGPosSenseLoL", System.Data.SqlDbType.NVarChar, 0, "DGPosSenseLoL"),
				new System.Data.SqlClient.SqlParameter("@DGPosSenseTrR", System.Data.SqlDbType.NVarChar, 0, "DGPosSenseTrR"),
				new System.Data.SqlClient.SqlParameter("@DGPosSenseTrL", System.Data.SqlDbType.NVarChar, 0, "DGPosSenseTrL"),
				new System.Data.SqlClient.SqlParameter("@DGPosSensenote", System.Data.SqlDbType.NVarChar, 0, "DGPosSensenote"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationUpR", System.Data.SqlDbType.NVarChar, 0, "DGVibrationUpR"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationUpL", System.Data.SqlDbType.NVarChar, 0, "DGVibrationUpL"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationLoR", System.Data.SqlDbType.NVarChar, 0, "DGVibrationLoR"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationLoL", System.Data.SqlDbType.NVarChar, 0, "DGVibrationLoL"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationTrR", System.Data.SqlDbType.NVarChar, 0, "DGVibrationTrR"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationTrL", System.Data.SqlDbType.NVarChar, 0, "DGVibrationTrL"),
				new System.Data.SqlClient.SqlParameter("@DGVibrationnote", System.Data.SqlDbType.NVarChar, 0, "DGVibrationnote"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationUpR", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationUpR"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationUpL", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationUpL"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationLoR", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationLoR"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationLoL", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationLoL"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationTrR", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationTrR"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationTrL", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationTrL"),
				new System.Data.SqlClient.SqlParameter("@DGTactileLocalizationnote", System.Data.SqlDbType.NVarChar, 0, "DGTactileLocalizationnote"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationUpR", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationUpR"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationUpL", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationUpL"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationLoR", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationLoR"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationLoL", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationLoL"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationTrR", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationTrR"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationTrL", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationTrL"),
				new System.Data.SqlClient.SqlParameter("@DGptdiscriminationnote", System.Data.SqlDbType.NVarChar, 0, "DGptdiscriminationnote"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisUpR", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisUpR"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisUpL", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisUpL"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisLoR", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisLoR"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisLoL", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisLoL"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisTrR", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisTrR"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisTrL", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisTrL"),
				new System.Data.SqlClient.SqlParameter("@DGStereognosisnote", System.Data.SqlDbType.NVarChar, 0, "DGStereognosisnote"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisUpR", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisUpR"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisUpL", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisUpL"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisLoR", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisLoR"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisLoL", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisLoL"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisTrR", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisTrR"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisTrL", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisTrL"),
				new System.Data.SqlClient.SqlParameter("@DGBarognosisnote", System.Data.SqlDbType.NVarChar, 0, "DGBarognosisnote"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesiaUpR", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesiaUpR"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesiaUpL", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesiaUpL"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesiaLoR", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesiaLoR"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesiaLoL", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesiaLoL"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesiaTrR", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesiaTrR"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesiaTrL", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesiaTrL"),
				new System.Data.SqlClient.SqlParameter("@DGGraphesthesianote", System.Data.SqlDbType.NVarChar, 0, "DGGraphesthesianote"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionUpR", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionUpR"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionUpL", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionUpL"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionLoR", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionLoR"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionLoL", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionLoL"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionTrR", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionTrR"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionTrL", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionTrL"),
				new System.Data.SqlClient.SqlParameter("@DGTextureRecognitionnote", System.Data.SqlDbType.NVarChar, 0, "DGTextureRecognitionnote"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationUpR", System.Data.SqlDbType.NVarChar, 0, "DGStimulationUpR"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationUpL", System.Data.SqlDbType.NVarChar, 0, "DGStimulationUpL"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationLoR", System.Data.SqlDbType.NVarChar, 0, "DGStimulationLoR"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationLoL", System.Data.SqlDbType.NVarChar, 0, "DGStimulationLoL"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationTrR", System.Data.SqlDbType.NVarChar, 0, "DGStimulationTrR"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationTrL", System.Data.SqlDbType.NVarChar, 0, "DGStimulationTrL"),
				new System.Data.SqlClient.SqlParameter("@DGStimulationnote", System.Data.SqlDbType.NVarChar, 0, "DGStimulationnote"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDataAdapter10.DeleteCommand = sqlCommand30;
			sqlDataAdapter10.InsertCommand = sqlCommand31;
			sqlDataAdapter10.SelectCommand = sqlCommand32;
			sqlDataAdapter10.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "SystemsReview", new System.Data.Common.DataColumnMapping[23]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("neurologicalID", "neurologicalID"),
					new System.Data.Common.DataColumnMapping("IntegSystem", "IntegSystem"),
					new System.Data.Common.DataColumnMapping("SkinStatus", "SkinStatus"),
					new System.Data.Common.DataColumnMapping("PressureSoress", "PressureSoress"),
					new System.Data.Common.DataColumnMapping("RESPIRATORYSYSTEM", "RESPIRATORYSYSTEM"),
					new System.Data.Common.DataColumnMapping("RSStatus", "RSStatus"),
					new System.Data.Common.DataColumnMapping("Secretions", "Secretions"),
					new System.Data.Common.DataColumnMapping("Patternofbreathing", "Patternofbreathing"),
					new System.Data.Common.DataColumnMapping("spinedeformity", "spinedeformity"),
					new System.Data.Common.DataColumnMapping("CVSStatus", "CVSStatus"),
					new System.Data.Common.DataColumnMapping("Thrombosis", "Thrombosis"),
					new System.Data.Common.DataColumnMapping("Contractures", "Contractures"),
					new System.Data.Common.DataColumnMapping("Subluxations", "Subluxations"),
					new System.Data.Common.DataColumnMapping("Jointmobility", "Jointmobility"),
					new System.Data.Common.DataColumnMapping("Otherpathology", "Otherpathology"),
					new System.Data.Common.DataColumnMapping("Incontinence", "Incontinence"),
					new System.Data.Common.DataColumnMapping("Status", "Status"),
					new System.Data.Common.DataColumnMapping("Vasomotor", "Vasomotor"),
					new System.Data.Common.DataColumnMapping("Pseudomotor", "Pseudomotor"),
					new System.Data.Common.DataColumnMapping("TrophicChanges", "TrophicChanges"),
					new System.Data.Common.DataColumnMapping("PosturalHypotension", "PosturalHypotension"),
					new System.Data.Common.DataColumnMapping("ReflexSympatheticDystrophy", "ReflexSympatheticDystrophy")
				})
			});
			sqlDataAdapter10.UpdateCommand = sqlCommand33;
			sqlCommand30.CommandText = "DELETE FROM [SystemsReview] WHERE (([ID] = @Original_ID) AND ([neurologicalID] = @Original_neurologicalID))";
			sqlCommand30.Connection = sqlConnection10;
			sqlCommand30.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection10.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection10.FireInfoMessageEventOnUserErrors = false;
			sqlCommand31.CommandText = resources.GetString("sqlCommand31.CommandText");
			sqlCommand31.Connection = sqlConnection10;
			sqlCommand31.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[22]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@IntegSystem", System.Data.SqlDbType.NVarChar, 0, "IntegSystem"),
				new System.Data.SqlClient.SqlParameter("@SkinStatus", System.Data.SqlDbType.NVarChar, 0, "SkinStatus"),
				new System.Data.SqlClient.SqlParameter("@PressureSoress", System.Data.SqlDbType.NVarChar, 0, "PressureSoress"),
				new System.Data.SqlClient.SqlParameter("@RESPIRATORYSYSTEM", System.Data.SqlDbType.NVarChar, 0, "RESPIRATORYSYSTEM"),
				new System.Data.SqlClient.SqlParameter("@RSStatus", System.Data.SqlDbType.NVarChar, 0, "RSStatus"),
				new System.Data.SqlClient.SqlParameter("@Secretions", System.Data.SqlDbType.NVarChar, 0, "Secretions"),
				new System.Data.SqlClient.SqlParameter("@Patternofbreathing", System.Data.SqlDbType.NVarChar, 0, "Patternofbreathing"),
				new System.Data.SqlClient.SqlParameter("@spinedeformity", System.Data.SqlDbType.NVarChar, 0, "spinedeformity"),
				new System.Data.SqlClient.SqlParameter("@CVSStatus", System.Data.SqlDbType.NVarChar, 0, "CVSStatus"),
				new System.Data.SqlClient.SqlParameter("@Thrombosis", System.Data.SqlDbType.NVarChar, 0, "Thrombosis"),
				new System.Data.SqlClient.SqlParameter("@Contractures", System.Data.SqlDbType.NVarChar, 0, "Contractures"),
				new System.Data.SqlClient.SqlParameter("@Subluxations", System.Data.SqlDbType.NVarChar, 0, "Subluxations"),
				new System.Data.SqlClient.SqlParameter("@Jointmobility", System.Data.SqlDbType.NVarChar, 0, "Jointmobility"),
				new System.Data.SqlClient.SqlParameter("@Otherpathology", System.Data.SqlDbType.NVarChar, 0, "Otherpathology"),
				new System.Data.SqlClient.SqlParameter("@Incontinence", System.Data.SqlDbType.NVarChar, 0, "Incontinence"),
				new System.Data.SqlClient.SqlParameter("@Status", System.Data.SqlDbType.NVarChar, 0, "Status"),
				new System.Data.SqlClient.SqlParameter("@Vasomotor", System.Data.SqlDbType.NVarChar, 0, "Vasomotor"),
				new System.Data.SqlClient.SqlParameter("@Pseudomotor", System.Data.SqlDbType.NVarChar, 0, "Pseudomotor"),
				new System.Data.SqlClient.SqlParameter("@TrophicChanges", System.Data.SqlDbType.NVarChar, 0, "TrophicChanges"),
				new System.Data.SqlClient.SqlParameter("@PosturalHypotension", System.Data.SqlDbType.NVarChar, 0, "PosturalHypotension"),
				new System.Data.SqlClient.SqlParameter("@ReflexSympatheticDystrophy", System.Data.SqlDbType.NVarChar, 0, "ReflexSympatheticDystrophy")
			});
			sqlCommand32.CommandText = "SELECT        SystemsReview.*\r\nFROM            SystemsReview";
			sqlCommand32.Connection = sqlConnection10;
			sqlCommand33.CommandText = resources.GetString("sqlCommand33.CommandText");
			sqlCommand33.Connection = sqlConnection10;
			sqlCommand33.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[25]
			{
				new System.Data.SqlClient.SqlParameter("@neurologicalID", System.Data.SqlDbType.Int, 0, "neurologicalID"),
				new System.Data.SqlClient.SqlParameter("@IntegSystem", System.Data.SqlDbType.NVarChar, 0, "IntegSystem"),
				new System.Data.SqlClient.SqlParameter("@SkinStatus", System.Data.SqlDbType.NVarChar, 0, "SkinStatus"),
				new System.Data.SqlClient.SqlParameter("@PressureSoress", System.Data.SqlDbType.NVarChar, 0, "PressureSoress"),
				new System.Data.SqlClient.SqlParameter("@RESPIRATORYSYSTEM", System.Data.SqlDbType.NVarChar, 0, "RESPIRATORYSYSTEM"),
				new System.Data.SqlClient.SqlParameter("@RSStatus", System.Data.SqlDbType.NVarChar, 0, "RSStatus"),
				new System.Data.SqlClient.SqlParameter("@Secretions", System.Data.SqlDbType.NVarChar, 0, "Secretions"),
				new System.Data.SqlClient.SqlParameter("@Patternofbreathing", System.Data.SqlDbType.NVarChar, 0, "Patternofbreathing"),
				new System.Data.SqlClient.SqlParameter("@spinedeformity", System.Data.SqlDbType.NVarChar, 0, "spinedeformity"),
				new System.Data.SqlClient.SqlParameter("@CVSStatus", System.Data.SqlDbType.NVarChar, 0, "CVSStatus"),
				new System.Data.SqlClient.SqlParameter("@Thrombosis", System.Data.SqlDbType.NVarChar, 0, "Thrombosis"),
				new System.Data.SqlClient.SqlParameter("@Contractures", System.Data.SqlDbType.NVarChar, 0, "Contractures"),
				new System.Data.SqlClient.SqlParameter("@Subluxations", System.Data.SqlDbType.NVarChar, 0, "Subluxations"),
				new System.Data.SqlClient.SqlParameter("@Jointmobility", System.Data.SqlDbType.NVarChar, 0, "Jointmobility"),
				new System.Data.SqlClient.SqlParameter("@Otherpathology", System.Data.SqlDbType.NVarChar, 0, "Otherpathology"),
				new System.Data.SqlClient.SqlParameter("@Incontinence", System.Data.SqlDbType.NVarChar, 0, "Incontinence"),
				new System.Data.SqlClient.SqlParameter("@Status", System.Data.SqlDbType.NVarChar, 0, "Status"),
				new System.Data.SqlClient.SqlParameter("@Vasomotor", System.Data.SqlDbType.NVarChar, 0, "Vasomotor"),
				new System.Data.SqlClient.SqlParameter("@Pseudomotor", System.Data.SqlDbType.NVarChar, 0, "Pseudomotor"),
				new System.Data.SqlClient.SqlParameter("@TrophicChanges", System.Data.SqlDbType.NVarChar, 0, "TrophicChanges"),
				new System.Data.SqlClient.SqlParameter("@PosturalHypotension", System.Data.SqlDbType.NVarChar, 0, "PosturalHypotension"),
				new System.Data.SqlClient.SqlParameter("@ReflexSympatheticDystrophy", System.Data.SqlDbType.NVarChar, 0, "ReflexSympatheticDystrophy"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_neurologicalID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "neurologicalID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDataAdapter11.DeleteCommand = sqlCommand34;
			sqlDataAdapter11.InsertCommand = sqlCommand35;
			sqlDataAdapter11.SelectCommand = sqlCommand36;
			sqlDataAdapter11.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "NaturalTherapy", new System.Data.Common.DataColumnMapping[3]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Name", "Name"),
					new System.Data.Common.DataColumnMapping("Notes", "Notes")
				})
			});
			sqlDataAdapter11.UpdateCommand = sqlCommand37;
			sqlCommand34.CommandText = "DELETE FROM [NaturalTherapy] WHERE (([ID] = @Original_ID))";
			sqlCommand34.Connection = sqlConnection11;
			sqlCommand34.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[1]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection11.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection11.FireInfoMessageEventOnUserErrors = false;
			sqlCommand35.CommandText = "INSERT INTO [NaturalTherapy] ([Name], [Notes]) VALUES (@Name, @Notes);\r\nSELECT ID, Name, Notes FROM NaturalTherapy WHERE (ID = SCOPE_IDENTITY())";
			sqlCommand35.Connection = sqlConnection11;
			sqlCommand35.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Notes", System.Data.SqlDbType.NVarChar, 0, "Notes")
			});
			sqlCommand36.CommandText = "SELECT        NaturalTherapy.*\r\nFROM            NaturalTherapy";
			sqlCommand36.Connection = sqlConnection11;
			sqlCommand37.CommandText = "UPDATE [NaturalTherapy] SET [Name] = @Name, [Notes] = @Notes WHERE (([ID] = @Original_ID));\r\nSELECT ID, Name, Notes FROM NaturalTherapy WHERE (ID = @ID)";
			sqlCommand37.Connection = sqlConnection11;
			sqlCommand37.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[4]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Notes", System.Data.SqlDbType.NVarChar, 0, "Notes"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			Print.Anchor = System.Windows.Forms.AnchorStyles.None;
			Print.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Print.Location = new System.Drawing.Point(12, 618);
			Print.Name = "Print";
			Print.Size = new System.Drawing.Size(109, 33);
			Print.TabIndex = 190;
			Print.Text = "Print Report";
			Print.UseVisualStyleBackColor = true;
			Print.Click += new System.EventHandler(Print_Click);
			button1.Anchor = System.Windows.Forms.AnchorStyles.None;
			button1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button1.Location = new System.Drawing.Point(535, 618);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(118, 34);
			button1.TabIndex = 194;
			button1.Text = "Back";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			label161.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label161.AutoSize = true;
			label161.BackColor = System.Drawing.Color.Transparent;
			label161.Font = new System.Drawing.Font("Times New Roman", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label161.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label161.Location = new System.Drawing.Point(44, 25);
			label161.Name = "label160";
			label161.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label161.Size = new System.Drawing.Size(158, 22);
			label161.TabIndex = 222;
			label161.Text = "Range of Motion: ";
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(987, 657);
			base.Controls.Add(button1);
			base.Controls.Add(Print);
			base.Controls.Add(update);
			base.Controls.Add(save);
			base.Controls.Add(tabControl1);
			base.Controls.Add(groupBox4);
			base.Controls.Add(birthDateDateTimePicker);
			base.MaximizeBox = true;
			base.Name = "gender";
			Text = "Neurological – physiotherapy ";
			base.Load += new System.EventHandler(gender_Load);
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			tabControl1.ResumeLayout(false);
			tabPage1.ResumeLayout(false);
			tabPage1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)DGVitalSigns).EndInit();
			tabPage2.ResumeLayout(false);
			tabPage2.PerformLayout();
			tabPage3.ResumeLayout(false);
			tabPage3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)DGNerves).EndInit();
			tabPage4.ResumeLayout(false);
			tabPage4.PerformLayout();
			((System.ComponentModel.ISupportInitialize)DGVoluntaryControl).EndInit();
			((System.ComponentModel.ISupportInitialize)DGMuscleGirth).EndInit();
			((System.ComponentModel.ISupportInitialize)DGSENSORYSYS).EndInit();
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			tabPage5.ResumeLayout(false);
			tabPage5.PerformLayout();
			((System.ComponentModel.ISupportInitialize)DGRangeofMotion).EndInit();
			tabPage6.ResumeLayout(false);
			tabPage6.PerformLayout();
			((System.ComponentModel.ISupportInitialize)DGLimbLength).EndInit();
			((System.ComponentModel.ISupportInitialize)DGRangeofMotion2).EndInit();
			tabPage7.ResumeLayout(false);
			tabPage7.PerformLayout();
			((System.ComponentModel.ISupportInitialize)DGMuscleTone2).EndInit();
			((System.ComponentModel.ISupportInitialize)DGMuscleTone1).EndInit();
			tabPage8.ResumeLayout(false);
			tabPage8.PerformLayout();
			((System.ComponentModel.ISupportInitialize)DGMusclePower2).EndInit();
			((System.ComponentModel.ISupportInitialize)DGMusclePower1).EndInit();
			tabPage9.ResumeLayout(false);
			tabPage9.PerformLayout();
			((System.ComponentModel.ISupportInitialize)DGCoordination2).EndInit();
			((System.ComponentModel.ISupportInitialize)DGCoordination1).EndInit();
			((System.ComponentModel.ISupportInitialize)DGReflexes).EndInit();
			tabPage10.ResumeLayout(false);
			tabPage10.PerformLayout();
			tabPage11.ResumeLayout(false);
			tabPage11.PerformLayout();
			tabPage12.ResumeLayout(false);
			tabPage12.PerformLayout();
			tabPage13.ResumeLayout(false);
			tabPage13.PerformLayout();
			((System.ComponentModel.ISupportInitialize)DGProblemList).EndInit();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}
	}
}
