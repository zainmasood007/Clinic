using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class NetDailyClinicRptFrm2 : ReportBaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox2;

		private CrystalReportViewer crystalReportViewer1;

		private DataSet1 dataSet11;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private DateTime date1;

		private DateTime date2;

		private string StockId;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			groupBox2 = new System.Windows.Forms.GroupBox();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			dataSet11 = new DataSet1();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Location = new System.Drawing.Point(9, 1);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(796, 662);
			groupBox2.TabIndex = 3;
			groupBox2.TabStop = false;
			crystalReportViewer1.ActiveViewIndex = -1;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
			crystalReportViewer1.Location = new System.Drawing.Point(3, 16);
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ShowGroupTreeButton = false;
			crystalReportViewer1.Size = new System.Drawing.Size(790, 643);
			crystalReportViewer1.TabIndex = 0;
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(809, 666);
			base.Controls.Add(groupBox2);
			base.Location = new System.Drawing.Point(0, 0);
			base.Name = "NetDailyClinicRptFrm2";
			Text = "رسم بياني";
			base.Load += new System.EventHandler(NetDailyClinicRptFrm2_Load);
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}

		public NetDailyClinicRptFrm2(DateTime Date1, DateTime Date2, string StockID)
		{
			InitializeComponent();
			date1 = Date1;
			date2 = Date2;
			StockId = StockID;
		}

		private void NetDailyClinicRptFrm2_Load(object sender, EventArgs e)
		{
			try
			{
				dataSet11.Clear();
				DataTable dataTable;
				if (StockId == "")
				{
					dataTable = Codes.Search2("select distinct date from StokeMove where Date between'" + date1.ToString("MM/dd/yyyy") + "' and '" + date2.ToString("MM/dd/yyyy") + "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='" + Main.userId + "')");
					if (dataTable.Rows.Count > 0)
					{
						for (int i = 0; i < dataTable.Rows.Count; i++)
						{
							decimal num = 0m;
							decimal num2 = 0m;
							decimal num3 = 0m;
							DataTable dataTable2 = Codes.Search2(string.Concat("SELECT isnull(sum(Price),0) as Expenses FROM StokeMove where (type='حذف كشف' or type='حساب طبيب' or type='مصروفات' or type='فاتورة مشتريات' or type='مدفوعات للمورد' or type='حذف إيرادات أخرى' or type='حذف خدمات و مدفوعات مريض' or type = 'حساب مساعد' or type='تحويل الى خزينة' or type='حذف أشعة' or type='حذف تحليل') and date = '", Convert.ToDateTime(dataTable.Rows[i][0]), "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='", Main.userId, "')"));
							DataTable dataTable3 = Codes.Search2(string.Concat("select isnull(sum(price),0) as Revenues  from StokeMove where (type != 'حذف كشف' and type!='حساب طبيب' and type!='مصروفات' and type!='فاتورة مشتريات' and type!='مدفوعات للمورد' and type!='حذف إيرادات أخرى' and type!='حذف خدمات و مدفوعات مريض' and type != 'حساب مساعد' and type != 'تحويل الى خزينة' and type !='حذف أشعة' and type !='حذف تحليل' and date = '", Convert.ToDateTime(dataTable.Rows[i][0]), "' and StokeMove.StockId in (SELECT  StockId FROM  UserStock where Status='True' and UserId='", Main.userId, "'))"));
							try
							{
								num2 = Convert.ToDecimal(dataTable2.Rows[0][0]);
							}
							catch
							{
							}
							try
							{
								num3 = Convert.ToDecimal(dataTable3.Rows[0][0]);
							}
							catch
							{
							}
							num = num3 - num2;
							((DataTable)(object)dataSet11.NetDailyClinic2).Rows.Add(Convert.ToDateTime(dataTable.Rows[i][0].ToString()), num, 0);
						}
						((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1, date2);
						NetDailyClincRpt2 netDailyClincRpt = new NetDailyClincRpt2();
						netDailyClincRpt.SetDataSource(dataSet11);
						crystalReportViewer1.ReportSource = netDailyClincRpt;
					}
					else
					{
						MessageBox.Show("لا يوجد بيانات");
					}
					return;
				}
				dataTable = Codes.Search2("select distinct date from StokeMove where Date between'" + date1.ToString("MM/dd/yyyy") + "' and '" + date2.ToString("MM/dd/yyyy") + "' and StockId = '" + Convert.ToInt32(StockId) + "'");
				if (dataTable.Rows.Count > 0)
				{
					for (int i = 0; i < dataTable.Rows.Count; i++)
					{
						decimal num = 0m;
						decimal num2 = 0m;
						decimal num3 = 0m;
						DataTable dataTable2 = Codes.Search2(string.Concat("SELECT isnull(sum(Price),0) as Expenses FROM  StokeMove where (type='حذف كشف' or type='حساب طبيب' or type='مصروفات' or type='فاتورة مشتريات' or type='مدفوعات للمورد' or type='حذف إيرادات أخرى' or type='حذف خدمات و مدفوعات مريض' or type = 'حساب مساعد' or type='تحويل الى خزينة' or type='حذف أشعة') and date = '", Convert.ToDateTime(dataTable.Rows[i][0]), "' and StockId = '", Convert.ToInt32(StockId), "'"));
						DataTable dataTable3 = Codes.Search2(string.Concat("select isnull(sum(price),0) as Revenues  from StokeMove where (type != 'حذف كشف' and type!='حساب طبيب' and type!='مصروفات' and type!='فاتورة مشتريات' and type!='مدفوعات للمورد' and type!='حذف إيرادات أخرى' and type!='حذف خدمات و مدفوعات مريض' and type != 'تحويل الى خزينة' and type !='حذف أشعة' and date = '", Convert.ToDateTime(dataTable.Rows[i][0]), "' and StockId = '", Convert.ToInt32(StockId), "')"));
						try
						{
							num2 = Convert.ToDecimal(dataTable2.Rows[0][0]);
						}
						catch
						{
						}
						try
						{
							num3 = Convert.ToDecimal(dataTable3.Rows[0][0]);
						}
						catch
						{
						}
						num = num3 - num2;
						((DataTable)(object)dataSet11.NetDailyClinic2).Rows.Add(Convert.ToDateTime(dataTable.Rows[i][0].ToString()), num, 0);
					}
					((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1, date2);
					NetDailyClincRpt2 netDailyClincRpt = new NetDailyClincRpt2();
					netDailyClincRpt.SetDataSource(dataSet11);
					crystalReportViewer1.ReportSource = netDailyClincRpt;
				}
				else
				{
					MessageBox.Show("لا يوجد بيانات");
				}
			}
			catch
			{
			}
		}
	}
}
