using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FmSearchPatient : BaseForm
	{
		private ClassDataBase dc;

		private dataClass codes;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private IContainer components = null;

		private GroupBox groupBox1;

		private GroupBox groupBox2;

		private DataGridView dataGridView1;

		private ComboBox searchTypeCombo;

		private Label label1;

		private ComboBox searchCombo;

		private Button SearchBtn;

		private Label label2;

		private Button deleteBtn;

		private Button EditBtn;

		private Button button7;

		private GroupBox searchGrop;

		private TextBox textBox9;

		private ListBox listBox1;

		private Button button10;

		private Label label21;

		public FmSearchPatient()
		{
			try
			{
				InitializeComponent();
				dc = new ClassDataBase(".\\sqlExpress");
				codes = new dataClass(".\\sqlExpress");
			}
			catch (Exception ex)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Error");
				}
				else
				{
					MessageBox.Show(ex.Message, "حدث خطأ");
				}
			}
		}

		public void RefreshCombo()
		{
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = ((!Convert.ToBoolean(codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString())) ? dc.GetTableText("select * from PatientData") : dc.GetTableText("select * from PatientData order by PName"));
				searchCombo.DataSource = dataTable;
				if (searchTypeCombo.SelectedIndex == 0)
				{
					searchCombo.DisplayMember = dataTable.Columns["PName"].ToString();
					searchCombo.ValueMember = dataTable.Columns[0].ToString();
				}
				else if (searchTypeCombo.SelectedIndex == 1)
				{
					searchCombo.DisplayMember = dataTable.Columns["FileNo"].ToString();
					searchCombo.ValueMember = dataTable.Columns[0].ToString();
				}
				else if (searchTypeCombo.SelectedIndex == 2)
				{
					DataTable tableText = dc.GetTableText("select * from Company");
					searchCombo.DataSource = tableText;
					searchCombo.DisplayMember = tableText.Columns[1].ToString();
					searchCombo.ValueMember = tableText.Columns[0].ToString();
				}
				else if (searchTypeCombo.SelectedIndex == 3)
				{
					searchCombo.DataSource = null;
				}
				else if (searchTypeCombo.SelectedIndex == 4)
				{
					searchCombo.DisplayMember = dataTable.Columns["nationalID"].ToString();
					searchCombo.ValueMember = dataTable.Columns[0].ToString();
				}
			}
			catch
			{
			}
		}

		public void RefreshDataGrid()
		{
			try
			{
				if (searchTypeCombo.SelectedIndex == 0)
				{
					DataTable tableText = dc.GetTableText("SELECT     dbo.PatientData.ID, dbo.PatientData.Titel, dbo.PatientData.PName, dbo.PatientData.PAddress, dbo.PatientData.City, dbo.PatientData.Tel, dbo.PatientData.Mob, \r\n                      dbo.PatientData.Email, dbo.PatientData.BirthDate, dbo.PatientData.Sex, dbo.PatientData.Nationality, dbo.PatientData.Statue, dbo.Company.Name, \r\n                      dbo.PatientData.cardNum, dbo.PatientData.LastVistDate, dbo.PatientData.Allergies, dbo.PatientData.CardiacDisease, dbo.PatientData.KidneyDesease, \r\n                      dbo.PatientData.Diabetes, dbo.PatientData.RheumaticFever, dbo.PatientData.Asthma, dbo.PatientData.BloodDyscrasias, dbo.PatientData.Lactating, \r\n                      dbo.PatientData.Pregnant, dbo.PatientData.HepatitisB, dbo.PatientData.Hepatitisc, dbo.PatientData.HistoryOther, dbo.PatientData.Extraction, \r\n                      dbo.PatientData.PeriodontalTherpy, dbo.PatientData.Endodontics, dbo.PatientData.Fixed, dbo.PatientData.Implant, dbo.PatientData.Opretive, \r\n                      dbo.PatientData.Bleaching, dbo.PatientData.PrviousHistoryOthers, dbo.PatientData.DoctoreName, dbo.PatientData.NextVisit, dbo.PatientData.Accept, \r\n                      dbo.PatientData.Taqweem, dbo.PatientData.Photo, dbo.PatientData.BloodType, dbo.PatientData.Active, dbo.PatientData.FileNo, dbo.PatientData.Patient, \r\n                      dbo.PatientData.Facebook, dbo.PatientData.Adv, dbo.PatientData.FormerPatient, dbo.PatientData.Discount, dbo.PatientData.Without, dbo.PatientData.Doctor, \r\n                      dbo.PatientData.DoctorId, dbo.PatientData.nationalID, dbo.PatientData.Dariba\r\nFROM         dbo.Company INNER JOIN\r\n                      dbo.PatientData ON dbo.Company.ID = dbo.PatientData.company where PName='" + searchCombo.Text + "'");
					if (tableText.Rows.Count > 0)
					{
						dataGridView1.DataSource = tableText;
						DataGrid();
						return;
					}
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Valid Patient Name", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم مريض صحيح", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					dataGridView1.DataSource = null;
				}
				else if (searchTypeCombo.SelectedIndex == 1)
				{
					DataTable tableText2 = dc.GetTableText("SELECT     dbo.PatientData.ID, dbo.PatientData.Titel, dbo.PatientData.PName, dbo.PatientData.PAddress, dbo.PatientData.City, dbo.PatientData.Tel, dbo.PatientData.Mob, \r\n                      dbo.PatientData.Email, dbo.PatientData.BirthDate, dbo.PatientData.Sex, dbo.PatientData.Nationality, dbo.PatientData.Statue, dbo.Company.Name, \r\n                      dbo.PatientData.cardNum, dbo.PatientData.LastVistDate, dbo.PatientData.Allergies, dbo.PatientData.CardiacDisease, dbo.PatientData.KidneyDesease, \r\n                      dbo.PatientData.Diabetes, dbo.PatientData.RheumaticFever, dbo.PatientData.Asthma, dbo.PatientData.BloodDyscrasias, dbo.PatientData.Lactating, \r\n                      dbo.PatientData.Pregnant, dbo.PatientData.HepatitisB, dbo.PatientData.Hepatitisc, dbo.PatientData.HistoryOther, dbo.PatientData.Extraction, \r\n                      dbo.PatientData.PeriodontalTherpy, dbo.PatientData.Endodontics, dbo.PatientData.Fixed, dbo.PatientData.Implant, dbo.PatientData.Opretive, \r\n                      dbo.PatientData.Bleaching, dbo.PatientData.PrviousHistoryOthers, dbo.PatientData.DoctoreName, dbo.PatientData.NextVisit, dbo.PatientData.Accept, \r\n                      dbo.PatientData.Taqweem, dbo.PatientData.Photo, dbo.PatientData.BloodType, dbo.PatientData.Active, dbo.PatientData.FileNo, dbo.PatientData.Patient, \r\n                      dbo.PatientData.Facebook, dbo.PatientData.Adv, dbo.PatientData.FormerPatient, dbo.PatientData.Discount, dbo.PatientData.Without, dbo.PatientData.Doctor, \r\n                      dbo.PatientData.DoctorId, dbo.PatientData.nationalID, dbo.PatientData.Dariba\r\nFROM         dbo.Company INNER JOIN\r\n                      dbo.PatientData ON dbo.Company.ID = dbo.PatientData.company where PatientData.FileNo='" + searchCombo.Text + "'");
					if (tableText2.Rows.Count > 0)
					{
						dataGridView1.DataSource = tableText2;
						DataGrid();
						return;
					}
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Valid Patient Code", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك ادخل كود صحيح", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					dataGridView1.DataSource = null;
				}
				else if (searchTypeCombo.SelectedIndex == 2)
				{
					DataTable tableText2 = dc.GetTableText(string.Concat("SELECT     dbo.PatientData.ID, dbo.PatientData.Titel, dbo.PatientData.PName, dbo.PatientData.PAddress, dbo.PatientData.City, dbo.PatientData.Tel, dbo.PatientData.Mob, \r\n                      dbo.PatientData.Email, dbo.PatientData.BirthDate, dbo.PatientData.Sex, dbo.PatientData.Nationality, dbo.PatientData.Statue, dbo.Company.Name, \r\n                      dbo.PatientData.cardNum, dbo.PatientData.LastVistDate, dbo.PatientData.Allergies, dbo.PatientData.CardiacDisease, dbo.PatientData.KidneyDesease, \r\n                      dbo.PatientData.Diabetes, dbo.PatientData.RheumaticFever, dbo.PatientData.Asthma, dbo.PatientData.BloodDyscrasias, dbo.PatientData.Lactating, \r\n                      dbo.PatientData.Pregnant, dbo.PatientData.HepatitisB, dbo.PatientData.Hepatitisc, dbo.PatientData.HistoryOther, dbo.PatientData.Extraction, \r\n                      dbo.PatientData.PeriodontalTherpy, dbo.PatientData.Endodontics, dbo.PatientData.Fixed, dbo.PatientData.Implant, dbo.PatientData.Opretive, \r\n                      dbo.PatientData.Bleaching, dbo.PatientData.PrviousHistoryOthers, dbo.PatientData.DoctoreName, dbo.PatientData.NextVisit, dbo.PatientData.Accept, \r\n                      dbo.PatientData.Taqweem, dbo.PatientData.Photo, dbo.PatientData.BloodType, dbo.PatientData.Active, dbo.PatientData.FileNo, dbo.PatientData.Patient, \r\n                      dbo.PatientData.Facebook, dbo.PatientData.Adv, dbo.PatientData.FormerPatient, dbo.PatientData.Discount, dbo.PatientData.Without, dbo.PatientData.Doctor, \r\n                      dbo.PatientData.DoctorId, dbo.PatientData.nationalID, dbo.PatientData.Dariba\r\nFROM         dbo.Company INNER JOIN\r\n                      dbo.PatientData ON dbo.Company.ID = dbo.PatientData.company where PatientData.company='", searchCombo.SelectedValue, "'"));
					if (tableText2.Rows.Count > 0)
					{
						dataGridView1.DataSource = tableText2;
						DataGrid();
						MethodsClass.UserMove("البحث عن مريض");
						return;
					}
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Valid Company Name", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم شركة صحيح", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					dataGridView1.DataSource = null;
				}
				else if (searchTypeCombo.SelectedIndex == 3)
				{
					DataTable tableText2 = dc.GetTableText("SELECT     dbo.PatientData.ID, dbo.PatientData.Titel, dbo.PatientData.PName, dbo.PatientData.PAddress, dbo.PatientData.City, dbo.PatientData.Tel, dbo.PatientData.Mob, \r\n                      dbo.PatientData.Email, dbo.PatientData.BirthDate, dbo.PatientData.Sex, dbo.PatientData.Nationality, dbo.PatientData.Statue, dbo.Company.Name, \r\n                      dbo.PatientData.cardNum, dbo.PatientData.LastVistDate, dbo.PatientData.Allergies, dbo.PatientData.CardiacDisease, dbo.PatientData.KidneyDesease, \r\n                      dbo.PatientData.Diabetes, dbo.PatientData.RheumaticFever, dbo.PatientData.Asthma, dbo.PatientData.BloodDyscrasias, dbo.PatientData.Lactating, \r\n                      dbo.PatientData.Pregnant, dbo.PatientData.HepatitisB, dbo.PatientData.Hepatitisc, dbo.PatientData.HistoryOther, dbo.PatientData.Extraction, \r\n                      dbo.PatientData.PeriodontalTherpy, dbo.PatientData.Endodontics, dbo.PatientData.Fixed, dbo.PatientData.Implant, dbo.PatientData.Opretive, \r\n                      dbo.PatientData.Bleaching, dbo.PatientData.PrviousHistoryOthers, dbo.PatientData.DoctoreName, dbo.PatientData.NextVisit, dbo.PatientData.Accept, \r\n                      dbo.PatientData.Taqweem, dbo.PatientData.Photo, dbo.PatientData.BloodType, dbo.PatientData.Active, dbo.PatientData.FileNo, dbo.PatientData.Patient, \r\n                      dbo.PatientData.Facebook, dbo.PatientData.Adv, dbo.PatientData.FormerPatient, dbo.PatientData.Discount, dbo.PatientData.Without, dbo.PatientData.Doctor, \r\n                      dbo.PatientData.DoctorId, dbo.PatientData.nationalID, dbo.PatientData.Dariba\r\nFROM         dbo.Company INNER JOIN\r\n                      dbo.PatientData ON dbo.Company.ID = dbo.PatientData.company where PatientData.Mob like '%" + searchCombo.Text + "%'");
					if (tableText2.Rows.Count > 0)
					{
						dataGridView1.DataSource = tableText2;
						DataGrid();
						return;
					}
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Valid number", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك ادخل رقم صحيح", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					dataGridView1.DataSource = null;
				}
				else
				{
					if (searchTypeCombo.SelectedIndex != 4)
					{
						return;
					}
					DataTable tableText2 = dc.GetTableText("SELECT     dbo.PatientData.ID, dbo.PatientData.Titel, dbo.PatientData.PName, dbo.PatientData.PAddress, dbo.PatientData.City, dbo.PatientData.Tel, dbo.PatientData.Mob, \r\n                      dbo.PatientData.Email, dbo.PatientData.BirthDate, dbo.PatientData.Sex, dbo.PatientData.Nationality, dbo.PatientData.Statue, dbo.Company.Name, \r\n                      dbo.PatientData.cardNum, dbo.PatientData.LastVistDate, dbo.PatientData.Allergies, dbo.PatientData.CardiacDisease, dbo.PatientData.KidneyDesease, \r\n                      dbo.PatientData.Diabetes, dbo.PatientData.RheumaticFever, dbo.PatientData.Asthma, dbo.PatientData.BloodDyscrasias, dbo.PatientData.Lactating, \r\n                      dbo.PatientData.Pregnant, dbo.PatientData.HepatitisB, dbo.PatientData.Hepatitisc, dbo.PatientData.HistoryOther, dbo.PatientData.Extraction, \r\n                      dbo.PatientData.PeriodontalTherpy, dbo.PatientData.Endodontics, dbo.PatientData.Fixed, dbo.PatientData.Implant, dbo.PatientData.Opretive, \r\n                      dbo.PatientData.Bleaching, dbo.PatientData.PrviousHistoryOthers, dbo.PatientData.DoctoreName, dbo.PatientData.NextVisit, dbo.PatientData.Accept, \r\n                      dbo.PatientData.Taqweem, dbo.PatientData.Photo, dbo.PatientData.BloodType, dbo.PatientData.Active, dbo.PatientData.FileNo, dbo.PatientData.Patient, \r\n                      dbo.PatientData.Facebook, dbo.PatientData.Adv, dbo.PatientData.FormerPatient, dbo.PatientData.Discount, dbo.PatientData.Without, dbo.PatientData.Doctor, \r\n                      dbo.PatientData.DoctorId, dbo.PatientData.nationalID, dbo.PatientData.Dariba\r\nFROM         dbo.Company INNER JOIN\r\n                      dbo.PatientData ON dbo.Company.ID = dbo.PatientData.company where PatientData.nationalID= '" + searchCombo.Text + "'");
					if (tableText2.Rows.Count > 0)
					{
						dataGridView1.DataSource = tableText2;
						DataGrid();
						return;
					}
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Valid nationalID", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك ادخل رقم هوية صحيح", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					dataGridView1.DataSource = null;
					return;
				}
			}
			catch
			{
			}
		}

		private void searchTypeCombo_SelectedIndexChanged(object sender, EventArgs e)
		{
			RefreshCombo();
		}

		public void DataGrid()
		{
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].HeaderText = "Social Status";
				dataGridView1.Columns[2].HeaderText = "Patient Name";
				dataGridView1.Columns[3].HeaderText = "Patient Address";
				dataGridView1.Columns[4].HeaderText = "City";
				dataGridView1.Columns[5].HeaderText = "Phone";
				dataGridView1.Columns[6].HeaderText = "Mobile";
				dataGridView1.Columns[7].HeaderText = "Email";
				dataGridView1.Columns[8].HeaderText = "Birth Date";
				dataGridView1.Columns[9].HeaderText = "Gender";
				dataGridView1.Columns[10].HeaderText = "Nationality";
				dataGridView1.Columns[11].Visible = false;
				dataGridView1.Columns[12].HeaderText = "Company Name";
				dataGridView1.Columns[13].HeaderText = "Card Number";
				dataGridView1.Columns[14].HeaderText = "Last Visit Date";
			}
			else
			{
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].HeaderText = "الحالة الاجتماعية";
				dataGridView1.Columns[2].HeaderText = "اسم المريض";
				dataGridView1.Columns[3].HeaderText = "العنوان";
				dataGridView1.Columns[4].HeaderText = "المدينة";
				dataGridView1.Columns[5].HeaderText = "التليفون";
				dataGridView1.Columns[6].HeaderText = "الموبايل";
				dataGridView1.Columns[7].HeaderText = "الايميل";
				dataGridView1.Columns[8].HeaderText = "تاريخ الميلاد";
				dataGridView1.Columns[9].HeaderText = "النوع";
				dataGridView1.Columns[10].HeaderText = "الجنسية";
				dataGridView1.Columns[11].Visible = false;
				dataGridView1.Columns[12].HeaderText = "اسم الشركة";
				dataGridView1.Columns[13].HeaderText = "رقم الكارت";
				dataGridView1.Columns[14].HeaderText = "تاريخ آخر زيارة";
			}
			dataGridView1.Columns[3].Width = 200;
			dataGridView1.Columns[25].Width = 150;
			dataGridView1.Columns[2].Width = 200;
			dataGridView1.Columns[26].Width = 150;
			dataGridView1.Columns[12].Width = 150;
			dataGridView1.Columns[27].Width = 150;
			dataGridView1.Columns[4].Width = 200;
			dataGridView1.Columns[28].Width = 150;
			dataGridView1.Columns[5].Width = 150;
			dataGridView1.Columns[29].Width = 150;
			dataGridView1.Columns[6].Width = 150;
			dataGridView1.Columns[30].Width = 150;
			dataGridView1.Columns[7].Width = 150;
			dataGridView1.Columns[31].Width = 150;
			dataGridView1.Columns[8].Width = 150;
			dataGridView1.Columns[32].Width = 150;
			dataGridView1.Columns[9].Width = 150;
			dataGridView1.Columns[33].Width = 150;
			dataGridView1.Columns[10].Width = 150;
			dataGridView1.Columns[34].Width = 150;
			dataGridView1.Columns[11].Width = 150;
			dataGridView1.Columns[20].Width = 150;
			dataGridView1.Columns[21].Width = 150;
			dataGridView1.Columns[19].Width = 150;
			dataGridView1.Columns[22].Width = 150;
			dataGridView1.Columns[17].Width = 150;
			dataGridView1.Columns[18].Width = 150;
			dataGridView1.Columns[16].Width = 150;
			dataGridView1.Columns[23].Width = 150;
			dataGridView1.Columns[15].Width = 150;
			dataGridView1.Columns[24].Width = 150;
			dataGridView1.Columns[13].Width = 150;
			dataGridView1.Columns[12].Width = 150;
			dataGridView1.Columns[14].Width = 150;
			dataGridView1.Columns[15].Visible = false;
			dataGridView1.Columns[16].Visible = false;
			dataGridView1.Columns[17].Visible = false;
			dataGridView1.Columns[18].Visible = false;
			dataGridView1.Columns[19].Visible = false;
			dataGridView1.Columns[20].Visible = false;
			dataGridView1.Columns[21].Visible = false;
			dataGridView1.Columns[22].Visible = false;
			dataGridView1.Columns[23].Visible = false;
			dataGridView1.Columns[24].Visible = false;
			dataGridView1.Columns[25].Visible = false;
			dataGridView1.Columns[26].Visible = false;
			dataGridView1.Columns[27].Visible = false;
			dataGridView1.Columns[28].Visible = false;
			dataGridView1.Columns[29].Visible = false;
			dataGridView1.Columns[30].Visible = false;
			dataGridView1.Columns[31].Visible = false;
			dataGridView1.Columns[32].Visible = false;
			dataGridView1.Columns[33].Visible = false;
			dataGridView1.Columns[34].Visible = false;
			dataGridView1.Columns[35].Visible = false;
			dataGridView1.Columns[36].Visible = false;
			dataGridView1.Columns[37].Visible = false;
			dataGridView1.Columns[38].Visible = false;
			dataGridView1.Columns[39].Visible = false;
			dataGridView1.Columns[40].Visible = false;
			dataGridView1.Columns["Patient"].Visible = false;
			dataGridView1.Columns["Facebook"].Visible = false;
			dataGridView1.Columns["Adv"].Visible = false;
			dataGridView1.Columns["FormerPatient"].Visible = false;
			dataGridView1.Columns["Discount"].Visible = false;
			dataGridView1.Columns["Without"].Visible = false;
			dataGridView1.Columns["Doctor"].Visible = false;
			dataGridView1.Columns["DoctorId"].Visible = false;
		}

		private void SearchBtn_Click(object sender, EventArgs e)
		{
			RefreshDataGrid();
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					PationtInfo pationtInfo = new PationtInfo(Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString()));
					pationtInfo.ShowDialog();
					RefreshCombo();
					DataTable tableText = dc.GetTableText("select * from PatientData");
					dataGridView1.DataSource = tableText;
					DataGrid();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Select Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اختر البيانات أولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void deleteBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					DialogResult dialogResult = DialogResult.None;
					dialogResult = ((!(Settings.Default.Language == "en-GB")) ? MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) : MessageBox.Show("Are You Sure You Want To Delete This Patient?", "", MessageBoxButtons.OKCancel, MessageBoxIcon.Question));
					if (dialogResult != DialogResult.OK)
					{
						return;
					}
					string[] fields = new string[1] { "ID" };
					if (dc.Delete("deletepatient", fields, Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString())))
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Patient Deleted Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove("حذف مريض");
						searchCombo.Text = "";
						RefreshCombo();
						RefreshDataGrid();
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("An Error Occurred During The Deletion Process ", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Select Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اختر البيانات أولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void FmSearchPatient_Load(object sender, EventArgs e)
		{
			searchTypeCombo.SelectedIndex = 0;
		}

		private void FmSearchPatient_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					PationtInfo pationtInfo = new PationtInfo(Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString()));
					pationtInfo.ShowDialog();
					RefreshCombo();
					DataTable tableText = dc.GetTableText("select * from PatientData");
					dataGridView1.DataSource = tableText;
					DataGrid();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Select Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("اختر البيانات أولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void button7_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				try
				{
					dataTable = dc.Select("SelectAllPatient");
					listBox1.DataSource = dataTable;
					listBox1.DisplayMember = dataTable.Columns[1].ToString();
					listBox1.ValueMember = dataTable.Columns[0].ToString();
				}
				catch
				{
				}
				searchGrop.Visible = true;
			}
			catch
			{
			}
		}

		private void textBox9_TextChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = ((!(textBox9.Text == "")) ? codes.Search2("select * from PatientData where PName like '%" + textBox9.Text + "%'") : dc.Select("SelectAllPatient"));
				listBox1.DataSource = dataTable;
				listBox1.DisplayMember = dataTable.Columns[2].ToString();
				listBox1.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
		{
			try
			{
				DataTable tableText = dc.GetTableText("select * from PatientData");
				searchCombo.DataSource = tableText;
				searchTypeCombo.Text = "بحث باسم المريض";
				searchCombo.DisplayMember = tableText.Columns["PName"].ToString();
				searchCombo.ValueMember = tableText.Columns[0].ToString();
				searchCombo.SelectedValue = listBox1.SelectedValue;
				textBox9.Text = "";
				searchGrop.Visible = false;
				RefreshDataGrid();
			}
			catch
			{
			}
		}

		private void button10_Click(object sender, EventArgs e)
		{
			textBox9.Text = "";
			searchGrop.Visible = false;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FmSearchPatient));
			groupBox1 = new System.Windows.Forms.GroupBox();
			button7 = new System.Windows.Forms.Button();
			SearchBtn = new System.Windows.Forms.Button();
			label2 = new System.Windows.Forms.Label();
			searchCombo = new System.Windows.Forms.ComboBox();
			searchTypeCombo = new System.Windows.Forms.ComboBox();
			label1 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			deleteBtn = new System.Windows.Forms.Button();
			EditBtn = new System.Windows.Forms.Button();
			searchGrop = new System.Windows.Forms.GroupBox();
			textBox9 = new System.Windows.Forms.TextBox();
			listBox1 = new System.Windows.Forms.ListBox();
			button10 = new System.Windows.Forms.Button();
			label21 = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			searchGrop.SuspendLayout();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(button7);
			groupBox1.Controls.Add(SearchBtn);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(searchCombo);
			groupBox1.Controls.Add(searchTypeCombo);
			groupBox1.Controls.Add(label1);
			groupBox1.ForeColor = System.Drawing.Color.Black;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			button7.AccessibleDescription = null;
			button7.AccessibleName = null;
			resources.ApplyResources(button7, "button7");
			button7.BackColor = System.Drawing.Color.Gainsboro;
			button7.BackgroundImage = null;
			button7.Name = "button7";
			button7.UseVisualStyleBackColor = false;
			button7.Click += new System.EventHandler(button7_Click);
			SearchBtn.AccessibleDescription = null;
			SearchBtn.AccessibleName = null;
			resources.ApplyResources(SearchBtn, "SearchBtn");
			SearchBtn.BackColor = System.Drawing.Color.Gainsboro;
			SearchBtn.BackgroundImage = null;
			SearchBtn.ForeColor = System.Drawing.Color.Black;
			SearchBtn.Name = "SearchBtn";
			SearchBtn.UseVisualStyleBackColor = false;
			SearchBtn.Click += new System.EventHandler(SearchBtn_Click);
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Font = null;
			label2.ForeColor = System.Drawing.Color.Maroon;
			label2.Name = "label2";
			searchCombo.AccessibleDescription = null;
			searchCombo.AccessibleName = null;
			resources.ApplyResources(searchCombo, "searchCombo");
			searchCombo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			searchCombo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			searchCombo.BackgroundImage = null;
			searchCombo.Font = null;
			searchCombo.FormattingEnabled = true;
			searchCombo.Name = "searchCombo";
			searchTypeCombo.AccessibleDescription = null;
			searchTypeCombo.AccessibleName = null;
			resources.ApplyResources(searchTypeCombo, "searchTypeCombo");
			searchTypeCombo.BackgroundImage = null;
			searchTypeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			searchTypeCombo.Font = null;
			searchTypeCombo.FormattingEnabled = true;
			searchTypeCombo.Items.AddRange(new object[5]
			{
				resources.GetString("searchTypeCombo.Items"),
				resources.GetString("searchTypeCombo.Items1"),
				resources.GetString("searchTypeCombo.Items2"),
				resources.GetString("searchTypeCombo.Items3"),
				resources.GetString("searchTypeCombo.Items4")
			});
			searchTypeCombo.Name = "searchTypeCombo";
			searchTypeCombo.SelectedIndexChanged += new System.EventHandler(searchTypeCombo_SelectedIndexChanged);
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.ForeColor = System.Drawing.Color.Maroon;
			label1.Name = "label1";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(dataGridView1);
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			deleteBtn.AccessibleDescription = null;
			deleteBtn.AccessibleName = null;
			resources.ApplyResources(deleteBtn, "deleteBtn");
			deleteBtn.BackColor = System.Drawing.Color.Gainsboro;
			deleteBtn.BackgroundImage = null;
			deleteBtn.ForeColor = System.Drawing.Color.Black;
			deleteBtn.Name = "deleteBtn";
			deleteBtn.UseVisualStyleBackColor = false;
			deleteBtn.Click += new System.EventHandler(deleteBtn_Click);
			EditBtn.AccessibleDescription = null;
			EditBtn.AccessibleName = null;
			resources.ApplyResources(EditBtn, "EditBtn");
			EditBtn.BackColor = System.Drawing.Color.Gainsboro;
			EditBtn.BackgroundImage = null;
			EditBtn.ForeColor = System.Drawing.Color.Black;
			EditBtn.Name = "EditBtn";
			EditBtn.UseVisualStyleBackColor = false;
			EditBtn.Click += new System.EventHandler(EditBtn_Click);
			searchGrop.AccessibleDescription = null;
			searchGrop.AccessibleName = null;
			resources.ApplyResources(searchGrop, "searchGrop");
			searchGrop.BackColor = System.Drawing.Color.Transparent;
			searchGrop.BackgroundImage = null;
			searchGrop.Controls.Add(textBox9);
			searchGrop.Controls.Add(listBox1);
			searchGrop.Controls.Add(button10);
			searchGrop.Controls.Add(label21);
			searchGrop.Font = null;
			searchGrop.Name = "searchGrop";
			searchGrop.TabStop = false;
			textBox9.AccessibleDescription = null;
			textBox9.AccessibleName = null;
			resources.ApplyResources(textBox9, "textBox9");
			textBox9.BackgroundImage = null;
			textBox9.Font = null;
			textBox9.Name = "textBox9";
			textBox9.TextChanged += new System.EventHandler(textBox9_TextChanged);
			listBox1.AccessibleDescription = null;
			listBox1.AccessibleName = null;
			resources.ApplyResources(listBox1, "listBox1");
			listBox1.BackgroundImage = null;
			listBox1.Font = null;
			listBox1.FormattingEnabled = true;
			listBox1.Name = "listBox1";
			listBox1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(listBox1_MouseDoubleClick);
			button10.AccessibleDescription = null;
			button10.AccessibleName = null;
			resources.ApplyResources(button10, "button10");
			button10.BackColor = System.Drawing.Color.Gainsboro;
			button10.BackgroundImage = null;
			button10.Name = "button10";
			button10.UseVisualStyleBackColor = false;
			button10.Click += new System.EventHandler(button10_Click);
			label21.AccessibleDescription = null;
			label21.AccessibleName = null;
			resources.ApplyResources(label21, "label21");
			label21.BackColor = System.Drawing.Color.Transparent;
			label21.Name = "label21";
			base.AcceptButton = SearchBtn;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(searchGrop);
			base.Controls.Add(deleteBtn);
			base.Controls.Add(EditBtn);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FmSearchPatient";
			base.Load += new System.EventHandler(FmSearchPatient_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(FmSearchPatient_KeyDown);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			searchGrop.ResumeLayout(false);
			searchGrop.PerformLayout();
			ResumeLayout(false);
		}
	}
}
