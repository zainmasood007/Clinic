using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using VistaButtonTest;

namespace DentistClinic
{
	public class PatientAccountFrm : BaseForm
	{
		private IContainer components = null;

		private DateTimePicker appdateTimePicker1;

		private GroupBox groupBox1;

		private DataGridView dataGridView1;

		private Button saveBtn;

		private Button ADDBtn;

		private GroupBox groupBox5;

		private ComboBox doctorcomboBox;

		private TextBox PricetextBox;

		private TextBox tottextBox;

		private GroupBox groupBox4;

		private ComboBox PatientComboBox;

		private GroupBox groupBox2;

		private Label label7;

		private DateTimePicker dateTimePicker1;

		private ComboBox commentTextBox;

		private Label label9;

		private Label label8;

		private Label label6;

		private Label label5;

		private GroupBox groupBox6;

		private GroupBox groupBox7;

		private VistaButton vistaButton24;

		private VistaButton vistaButton17;

		private VistaButton vistaButton23;

		private VistaButton vistaButton18;

		private VistaButton vistaButton22;

		private VistaButton vistaButton19;

		private VistaButton vistaButton21;

		private VistaButton vistaButton20;

		private GroupBox groupBox3;

		private GroupBox groupBox8;

		private VistaButton vistaButton9;

		private VistaButton vistaButton10;

		private VistaButton vistaButton11;

		private VistaButton vistaButton12;

		private VistaButton vistaButton13;

		private VistaButton vistaButton14;

		private VistaButton vistaButton15;

		private VistaButton vistaButton16;

		private VistaButton U26;

		private VistaButton U29;

		private VistaButton U32;

		private VistaButton U30;

		private VistaButton U28;

		private VistaButton U31;

		private VistaButton U24;

		private VistaButton U22;

		private VistaButton U27;

		private VistaButton U23;

		private VistaButton U9;

		private VistaButton U16;

		private VistaButton U11;

		private VistaButton U10;

		private VistaButton U12;

		private VistaButton U13;

		private VistaButton U14;

		private VistaButton U15;

		private VistaButton U1;

		private VistaButton U8;

		private VistaButton U25;

		private VistaButton U3;

		private VistaButton U2;

		private VistaButton U18;

		private VistaButton U17;

		private VistaButton U4;

		private VistaButton U5;

		private VistaButton U6;

		private VistaButton U7;

		private VistaButton U19;

		private VistaButton U21;

		private VistaButton U20;

		private ComboBox NextVisitCom;

		private Button button1;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Column2;

		private DataGridViewTextBoxColumn ServiceDate;

		private DataGridViewTextBoxColumn Teethn;

		private DataGridViewTextBoxColumn Column3;

		private GroupBox groupBox9;

		private CheckBox checkBox1;

		private TextBox textBox1;

		private GroupBox groupBox10;

		private CheckBox checkBox2;

		private RadioButton radioButton2;

		private RadioButton radioButton1;

		private TextBox textBox2;

		private ComboBox comboBox1;

		private Button button2;

		private Panel panel1;

		private Panel panel2;

		private Label label22;

		private Label label23;

		private Label label24;

		private NumericUpDown numericUpDown13;

		private Label label18;

		private TableLayoutPanel tableLayoutPanel1;

		private NumericUpDown numericUpDown1;

		private Label label19;

		private Label label20;

		private NumericUpDown numericUpDown5;

		private Label label21;

		private NumericUpDown numericUpDown6;

		private NumericUpDown numericUpDown2;

		private NumericUpDown numericUpDown4;

		private NumericUpDown numericUpDown3;

		private Label label12;

		private NumericUpDown numericUpDown14;

		private Label label13;

		private TableLayoutPanel tableLayoutPanel2;

		private Label label14;

		private Label label15;

		private Label label16;

		private NumericUpDown numericUpDown7;

		private NumericUpDown numericUpDown8;

		private NumericUpDown numericUpDown11;

		private NumericUpDown numericUpDown12;

		private NumericUpDown numericUpDown9;

		private NumericUpDown numericUpDown10;

		private Label label17;

		private Label label25;

		private Button button6;

		private Button button5;

		private Button button4;

		private GroupBox groupBox11;

		private bool b;

		private int appointid;

		private ClassDataBase dc;

		private bool done = false;

		private int PationtID;

		private double total;

		private dataClass codes;

		private GUI gui = new GUI();

		private int patient;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			appdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			groupBox1 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ServiceDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Teethn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			saveBtn = new System.Windows.Forms.Button();
			ADDBtn = new System.Windows.Forms.Button();
			groupBox5 = new System.Windows.Forms.GroupBox();
			button4 = new System.Windows.Forms.Button();
			button6 = new System.Windows.Forms.Button();
			button5 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			PricetextBox = new System.Windows.Forms.TextBox();
			tottextBox = new System.Windows.Forms.TextBox();
			groupBox4 = new System.Windows.Forms.GroupBox();
			textBox1 = new System.Windows.Forms.TextBox();
			groupBox9 = new System.Windows.Forms.GroupBox();
			checkBox1 = new System.Windows.Forms.CheckBox();
			commentTextBox = new System.Windows.Forms.ComboBox();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			PatientComboBox = new System.Windows.Forms.ComboBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			this.label7 = new System.Windows.Forms.Label();
			panel1 = new System.Windows.Forms.Panel();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			groupBox6 = new System.Windows.Forms.GroupBox();
			groupBox7 = new System.Windows.Forms.GroupBox();
			vistaButton24 = new VistaButtonTest.VistaButton();
			vistaButton17 = new VistaButtonTest.VistaButton();
			vistaButton23 = new VistaButtonTest.VistaButton();
			vistaButton18 = new VistaButtonTest.VistaButton();
			vistaButton22 = new VistaButtonTest.VistaButton();
			vistaButton19 = new VistaButtonTest.VistaButton();
			vistaButton21 = new VistaButtonTest.VistaButton();
			vistaButton20 = new VistaButtonTest.VistaButton();
			this.label5 = new System.Windows.Forms.Label();
			groupBox3 = new System.Windows.Forms.GroupBox();
			groupBox8 = new System.Windows.Forms.GroupBox();
			vistaButton9 = new VistaButtonTest.VistaButton();
			vistaButton10 = new VistaButtonTest.VistaButton();
			vistaButton11 = new VistaButtonTest.VistaButton();
			vistaButton12 = new VistaButtonTest.VistaButton();
			vistaButton13 = new VistaButtonTest.VistaButton();
			vistaButton14 = new VistaButtonTest.VistaButton();
			vistaButton15 = new VistaButtonTest.VistaButton();
			vistaButton16 = new VistaButtonTest.VistaButton();
			U9 = new VistaButtonTest.VistaButton();
			U17 = new VistaButtonTest.VistaButton();
			U16 = new VistaButtonTest.VistaButton();
			U20 = new VistaButtonTest.VistaButton();
			U18 = new VistaButtonTest.VistaButton();
			U11 = new VistaButtonTest.VistaButton();
			U24 = new VistaButtonTest.VistaButton();
			U10 = new VistaButtonTest.VistaButton();
			U21 = new VistaButtonTest.VistaButton();
			U15 = new VistaButtonTest.VistaButton();
			U26 = new VistaButtonTest.VistaButton();
			U14 = new VistaButtonTest.VistaButton();
			U1 = new VistaButtonTest.VistaButton();
			U13 = new VistaButtonTest.VistaButton();
			U7 = new VistaButtonTest.VistaButton();
			U12 = new VistaButtonTest.VistaButton();
			U19 = new VistaButtonTest.VistaButton();
			U6 = new VistaButtonTest.VistaButton();
			U29 = new VistaButtonTest.VistaButton();
			U5 = new VistaButtonTest.VistaButton();
			U23 = new VistaButtonTest.VistaButton();
			U4 = new VistaButtonTest.VistaButton();
			U22 = new VistaButtonTest.VistaButton();
			U2 = new VistaButtonTest.VistaButton();
			U28 = new VistaButtonTest.VistaButton();
			U3 = new VistaButtonTest.VistaButton();
			U27 = new VistaButtonTest.VistaButton();
			U30 = new VistaButtonTest.VistaButton();
			U8 = new VistaButtonTest.VistaButton();
			U32 = new VistaButtonTest.VistaButton();
			U25 = new VistaButtonTest.VistaButton();
			U31 = new VistaButtonTest.VistaButton();
			NextVisitCom = new System.Windows.Forms.ComboBox();
			groupBox10 = new System.Windows.Forms.GroupBox();
			checkBox2 = new System.Windows.Forms.CheckBox();
			radioButton2 = new System.Windows.Forms.RadioButton();
			radioButton1 = new System.Windows.Forms.RadioButton();
			textBox2 = new System.Windows.Forms.TextBox();
			comboBox1 = new System.Windows.Forms.ComboBox();
			panel2 = new System.Windows.Forms.Panel();
			label22 = new System.Windows.Forms.Label();
			label23 = new System.Windows.Forms.Label();
			label24 = new System.Windows.Forms.Label();
			numericUpDown13 = new System.Windows.Forms.NumericUpDown();
			label18 = new System.Windows.Forms.Label();
			tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			label19 = new System.Windows.Forms.Label();
			label20 = new System.Windows.Forms.Label();
			numericUpDown5 = new System.Windows.Forms.NumericUpDown();
			label21 = new System.Windows.Forms.Label();
			numericUpDown6 = new System.Windows.Forms.NumericUpDown();
			numericUpDown2 = new System.Windows.Forms.NumericUpDown();
			numericUpDown4 = new System.Windows.Forms.NumericUpDown();
			numericUpDown3 = new System.Windows.Forms.NumericUpDown();
			label12 = new System.Windows.Forms.Label();
			numericUpDown14 = new System.Windows.Forms.NumericUpDown();
			label13 = new System.Windows.Forms.Label();
			tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			label14 = new System.Windows.Forms.Label();
			label15 = new System.Windows.Forms.Label();
			label16 = new System.Windows.Forms.Label();
			numericUpDown7 = new System.Windows.Forms.NumericUpDown();
			numericUpDown8 = new System.Windows.Forms.NumericUpDown();
			numericUpDown11 = new System.Windows.Forms.NumericUpDown();
			numericUpDown12 = new System.Windows.Forms.NumericUpDown();
			numericUpDown9 = new System.Windows.Forms.NumericUpDown();
			numericUpDown10 = new System.Windows.Forms.NumericUpDown();
			label17 = new System.Windows.Forms.Label();
			label25 = new System.Windows.Forms.Label();
			groupBox11 = new System.Windows.Forms.GroupBox();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label7 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label8 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label9 = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox5.SuspendLayout();
			groupBox4.SuspendLayout();
			groupBox9.SuspendLayout();
			groupBox2.SuspendLayout();
			panel1.SuspendLayout();
			groupBox7.SuspendLayout();
			groupBox3.SuspendLayout();
			groupBox10.SuspendLayout();
			panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown13).BeginInit();
			tableLayoutPanel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown5).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown6).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown4).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown3).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown14).BeginInit();
			tableLayoutPanel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown7).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown8).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown11).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown12).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown9).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown10).BeginInit();
			groupBox11.SuspendLayout();
			SuspendLayout();
			label.AutoSize = true;
			label.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label.Location = new System.Drawing.Point(544, 73);
			label.Name = "addressLabel";
			label.Size = new System.Drawing.Size(73, 16);
			label.TabIndex = 36;
			label.Text = "تاريخ الكشف :";
			label2.AutoSize = true;
			label2.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label2.Location = new System.Drawing.Point(544, 42);
			label2.Name = "nameLabel";
			label2.Size = new System.Drawing.Size(65, 16);
			label2.TabIndex = 9;
			label2.Text = "اسم الطبيب :";
			label3.AutoSize = true;
			label3.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label3.Location = new System.Drawing.Point(544, 226);
			label3.Name = "label2";
			label3.Size = new System.Drawing.Size(41, 16);
			label3.TabIndex = 2;
			label3.Text = "السعر :";
			label4.AutoSize = true;
			label4.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label4.Location = new System.Drawing.Point(544, 104);
			label4.Name = "titelLabel";
			label4.Size = new System.Drawing.Size(71, 16);
			label4.TabIndex = 0;
			label4.Text = "اسم المريض :";
			label5.AutoSize = true;
			label5.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label5.ForeColor = System.Drawing.Color.Firebrick;
			label5.Location = new System.Drawing.Point(420, 536);
			label5.Name = "label3";
			label5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			label5.Size = new System.Drawing.Size(52, 16);
			label5.TabIndex = 86;
			label5.Text = "الإجمالي :";
			label6.AutoSize = true;
			label6.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label6.Location = new System.Drawing.Point(544, 201);
			label6.Name = "label4";
			label6.Size = new System.Drawing.Size(71, 16);
			label6.TabIndex = 41;
			label6.Text = "تاريخ الخدمة :";
			label7.AutoSize = true;
			label7.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label7.Location = new System.Drawing.Point(542, 163);
			label7.Name = "label1";
			label7.Size = new System.Drawing.Size(43, 16);
			label7.TabIndex = 42;
			label7.Text = "الخدمة :";
			label8.AutoSize = true;
			label8.BackColor = System.Drawing.Color.Transparent;
			label8.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label8.Location = new System.Drawing.Point(456, 570);
			label8.Name = "label10";
			label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			label8.Size = new System.Drawing.Size(76, 16);
			label8.TabIndex = 105;
			label8.Text = "الزيارة القادمة :";
			label9.AutoSize = true;
			label9.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label9.Location = new System.Drawing.Point(541, 133);
			label9.Name = "label11";
			label9.Size = new System.Drawing.Size(66, 16);
			label9.TabIndex = 47;
			label9.Text = "اسم الشركة :";
			appdateTimePicker1.CustomFormat = "dd/MM/yyyy";
			appdateTimePicker1.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			appdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			appdateTimePicker1.Location = new System.Drawing.Point(178, 67);
			appdateTimePicker1.Name = "appdateTimePicker1";
			appdateTimePicker1.RightToLeftLayout = true;
			appdateTimePicker1.Size = new System.Drawing.Size(360, 25);
			appdateTimePicker1.TabIndex = 37;
			appdateTimePicker1.ValueChanged += new System.EventHandler(doctorcomboBox_SelectedIndexChanged);
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(dataGridView1);
			groupBox1.Location = new System.Drawing.Point(6, 312);
			groupBox1.Name = "groupBox1";
			groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox1.Size = new System.Drawing.Size(653, 217);
			groupBox1.TabIndex = 84;
			groupBox1.TabStop = false;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(Column1, Column2, ServiceDate, Teethn, Column3);
			dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
			dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			dataGridView1.Location = new System.Drawing.Point(3, 16);
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.Size = new System.Drawing.Size(647, 198);
			dataGridView1.TabIndex = 0;
			dataGridView1.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(dataGridView1_RowsRemoved);
			Column1.HeaderText = "الخدمة";
			Column1.Name = "Column1";
			Column1.ReadOnly = true;
			Column1.Width = 230;
			Column2.HeaderText = "السعر";
			Column2.Name = "Column2";
			Column2.ReadOnly = true;
			Column2.Width = 150;
			ServiceDate.HeaderText = "تاريخ الخدمة";
			ServiceDate.Name = "ServiceDate";
			ServiceDate.ReadOnly = true;
			ServiceDate.Width = 150;
			Teethn.HeaderText = "السنة";
			Teethn.Name = "Teethn";
			Teethn.ReadOnly = true;
			Column3.HeaderText = "Column3";
			Column3.Name = "Column3";
			Column3.ReadOnly = true;
			Column3.Visible = false;
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			saveBtn.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			saveBtn.Location = new System.Drawing.Point(401, 12);
			saveBtn.Name = "saveBtn";
			saveBtn.Size = new System.Drawing.Size(156, 37);
			saveBtn.TabIndex = 34;
			saveBtn.Text = "حفظ";
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			ADDBtn.BackColor = System.Drawing.Color.Gainsboro;
			ADDBtn.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			ADDBtn.Location = new System.Drawing.Point(39, 206);
			ADDBtn.Name = "ADDBtn";
			ADDBtn.Size = new System.Drawing.Size(109, 37);
			ADDBtn.TabIndex = 35;
			ADDBtn.Text = "إضافة";
			ADDBtn.UseVisualStyleBackColor = false;
			ADDBtn.Click += new System.EventHandler(ADDBtn_Click);
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.Controls.Add(button4);
			groupBox5.Controls.Add(button6);
			groupBox5.Controls.Add(button5);
			groupBox5.Controls.Add(button2);
			groupBox5.Controls.Add(button1);
			groupBox5.Location = new System.Drawing.Point(6, 651);
			groupBox5.Name = "groupBox5";
			groupBox5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox5.Size = new System.Drawing.Size(950, 55);
			groupBox5.TabIndex = 85;
			groupBox5.TabStop = false;
			button4.BackColor = System.Drawing.Color.Gainsboro;
			button4.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button4.Location = new System.Drawing.Point(401, 12);
			button4.Name = "button4";
			button4.Size = new System.Drawing.Size(156, 37);
			button4.TabIndex = 105;
			button4.Text = "الأشعة";
			button4.UseVisualStyleBackColor = false;
			button4.Click += new System.EventHandler(button4_Click);
			button6.BackColor = System.Drawing.Color.Gainsboro;
			button6.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button6.Location = new System.Drawing.Point(563, 12);
			button6.Name = "button6";
			button6.Size = new System.Drawing.Size(156, 37);
			button6.TabIndex = 104;
			button6.Text = "الملاحظات";
			button6.UseVisualStyleBackColor = false;
			button6.Click += new System.EventHandler(button6_Click);
			button5.BackColor = System.Drawing.Color.Gainsboro;
			button5.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button5.Location = new System.Drawing.Point(725, 12);
			button5.Name = "button5";
			button5.Size = new System.Drawing.Size(156, 37);
			button5.TabIndex = 103;
			button5.Text = "الروشتات";
			button5.UseVisualStyleBackColor = false;
			button5.Click += new System.EventHandler(button5_Click);
			button2.BackColor = System.Drawing.Color.Gainsboro;
			button2.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button2.Location = new System.Drawing.Point(77, 12);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(156, 37);
			button2.TabIndex = 36;
			button2.Text = "خدمات المرضى";
			button2.UseVisualStyleBackColor = false;
			button2.Click += new System.EventHandler(button2_Click);
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button1.Location = new System.Drawing.Point(239, 12);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(156, 37);
			button1.TabIndex = 35;
			button1.Text = "مدفوعات المرضى";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.Enabled = false;
			doctorcomboBox.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Location = new System.Drawing.Point(178, 37);
			doctorcomboBox.Name = "doctorcomboBox";
			doctorcomboBox.Size = new System.Drawing.Size(360, 24);
			doctorcomboBox.TabIndex = 10;
			doctorcomboBox.SelectionChangeCommitted += new System.EventHandler(doctorcomboBox_SelectedIndexChanged);
			doctorcomboBox.SelectedIndexChanged += new System.EventHandler(doctorcomboBox_SelectedIndexChanged);
			PricetextBox.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			PricetextBox.Location = new System.Drawing.Point(178, 225);
			PricetextBox.Name = "PricetextBox";
			PricetextBox.Size = new System.Drawing.Size(360, 22);
			PricetextBox.TabIndex = 8;
			PricetextBox.Text = "0";
			PricetextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			PricetextBox.Leave += new System.EventHandler(PricetextBox_Leave);
			PricetextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(PricetextBox_KeyPress);
			tottextBox.ForeColor = System.Drawing.Color.Maroon;
			tottextBox.Location = new System.Drawing.Point(303, 535);
			tottextBox.Name = "tottextBox";
			tottextBox.ReadOnly = true;
			tottextBox.Size = new System.Drawing.Size(111, 20);
			tottextBox.TabIndex = 87;
			tottextBox.Text = "0";
			tottextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.Controls.Add(label9);
			groupBox4.Controls.Add(textBox1);
			groupBox4.Controls.Add(groupBox9);
			groupBox4.Controls.Add(commentTextBox);
			groupBox4.Controls.Add(label7);
			groupBox4.Controls.Add(label6);
			groupBox4.Controls.Add(dateTimePicker1);
			groupBox4.Controls.Add(appdateTimePicker1);
			groupBox4.Controls.Add(label);
			groupBox4.Controls.Add(ADDBtn);
			groupBox4.Controls.Add(doctorcomboBox);
			groupBox4.Controls.Add(label2);
			groupBox4.Controls.Add(PricetextBox);
			groupBox4.Controls.Add(label3);
			groupBox4.Controls.Add(label4);
			groupBox4.Controls.Add(PatientComboBox);
			groupBox4.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			groupBox4.ForeColor = System.Drawing.Color.Black;
			groupBox4.Location = new System.Drawing.Point(6, 52);
			groupBox4.Name = "groupBox4";
			groupBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox4.Size = new System.Drawing.Size(653, 254);
			groupBox4.TabIndex = 83;
			groupBox4.TabStop = false;
			textBox1.BackColor = System.Drawing.Color.White;
			textBox1.ForeColor = System.Drawing.Color.Maroon;
			textBox1.Location = new System.Drawing.Point(178, 129);
			textBox1.Name = "textBox1";
			textBox1.ReadOnly = true;
			textBox1.Size = new System.Drawing.Size(360, 25);
			textBox1.TabIndex = 46;
			groupBox9.Controls.Add(checkBox1);
			groupBox9.Location = new System.Drawing.Point(10, 29);
			groupBox9.Name = "groupBox9";
			groupBox9.Size = new System.Drawing.Size(162, 62);
			groupBox9.TabIndex = 45;
			groupBox9.TabStop = false;
			checkBox1.AutoSize = true;
			checkBox1.Enabled = false;
			checkBox1.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			checkBox1.Location = new System.Drawing.Point(41, 25);
			checkBox1.Name = "checkBox1";
			checkBox1.Size = new System.Drawing.Size(81, 22);
			checkBox1.TabIndex = 0;
			checkBox1.Text = "تم الموافقة";
			checkBox1.UseVisualStyleBackColor = true;
			commentTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			commentTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			commentTextBox.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			commentTextBox.FormattingEnabled = true;
			commentTextBox.Location = new System.Drawing.Point(178, 161);
			commentTextBox.Name = "commentTextBox";
			commentTextBox.Size = new System.Drawing.Size(360, 24);
			commentTextBox.TabIndex = 44;
			commentTextBox.SelectedIndexChanged += new System.EventHandler(commentTextBox_SelectedIndexChanged);
			commentTextBox.SelectedValueChanged += new System.EventHandler(PatientComboBox_SelectedValueChanged);
			dateTimePicker1.CustomFormat = "dd/MM/yyyy";
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Location = new System.Drawing.Point(178, 192);
			dateTimePicker1.Name = "dateTimePicker1";
			dateTimePicker1.RightToLeftLayout = true;
			dateTimePicker1.Size = new System.Drawing.Size(360, 25);
			dateTimePicker1.TabIndex = 40;
			PatientComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			PatientComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientComboBox.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			PatientComboBox.FormattingEnabled = true;
			PatientComboBox.Location = new System.Drawing.Point(178, 99);
			PatientComboBox.Name = "PatientComboBox";
			PatientComboBox.Size = new System.Drawing.Size(360, 24);
			PatientComboBox.TabIndex = 0;
			PatientComboBox.SelectedIndexChanged += new System.EventHandler(PatientComboBox_SelectedIndexChanged);
			PatientComboBox.SelectedValueChanged += new System.EventHandler(PatientComboBox_SelectedValueChanged);
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(this.label7);
			groupBox2.Location = new System.Drawing.Point(214, 46);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(235, 35);
			groupBox2.TabIndex = 92;
			groupBox2.TabStop = false;
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			this.label7.Location = new System.Drawing.Point(66, 11);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(95, 18);
			this.label7.TabIndex = 0;
			this.label7.Text = "حساب المريض";
			panel1.BackColor = System.Drawing.Color.RosyBrown;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			panel1.Controls.Add(this.label9);
			panel1.Controls.Add(this.label8);
			panel1.Controls.Add(this.label6);
			panel1.Controls.Add(groupBox6);
			panel1.Controls.Add(groupBox7);
			panel1.Controls.Add(this.label5);
			panel1.Controls.Add(groupBox3);
			panel1.Controls.Add(U9);
			panel1.Controls.Add(U17);
			panel1.Controls.Add(U16);
			panel1.Controls.Add(U20);
			panel1.Controls.Add(U18);
			panel1.Controls.Add(U11);
			panel1.Controls.Add(U24);
			panel1.Controls.Add(U10);
			panel1.Controls.Add(U21);
			panel1.Controls.Add(U15);
			panel1.Controls.Add(U26);
			panel1.Controls.Add(U14);
			panel1.Controls.Add(U1);
			panel1.Controls.Add(U13);
			panel1.Controls.Add(U7);
			panel1.Controls.Add(U12);
			panel1.Controls.Add(U19);
			panel1.Controls.Add(U6);
			panel1.Controls.Add(U29);
			panel1.Controls.Add(U5);
			panel1.Controls.Add(U23);
			panel1.Controls.Add(U4);
			panel1.Controls.Add(U22);
			panel1.Controls.Add(U2);
			panel1.Controls.Add(U28);
			panel1.Controls.Add(U3);
			panel1.Controls.Add(U27);
			panel1.Controls.Add(U30);
			panel1.Controls.Add(U8);
			panel1.Controls.Add(U32);
			panel1.Controls.Add(U25);
			panel1.Controls.Add(U31);
			panel1.Location = new System.Drawing.Point(665, 62);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(291, 442);
			panel1.TabIndex = 104;
			panel1.Visible = false;
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(83, 264);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(61, 13);
			this.label9.TabIndex = 37;
			this.label9.Text = "down Right";
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(163, 293);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(55, 13);
			this.label8.TabIndex = 36;
			this.label8.Text = "down Left";
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(156, 101);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(58, 13);
			this.label6.TabIndex = 35;
			this.label6.Text = "Upper Left";
			groupBox6.Location = new System.Drawing.Point(47, 214);
			groupBox6.Name = "groupBox6";
			groupBox6.Size = new System.Drawing.Size(200, 2);
			groupBox6.TabIndex = 33;
			groupBox6.TabStop = false;
			groupBox6.Text = "groupBox6";
			groupBox7.Controls.Add(vistaButton24);
			groupBox7.Controls.Add(vistaButton17);
			groupBox7.Controls.Add(vistaButton23);
			groupBox7.Controls.Add(vistaButton18);
			groupBox7.Controls.Add(vistaButton22);
			groupBox7.Controls.Add(vistaButton19);
			groupBox7.Controls.Add(vistaButton21);
			groupBox7.Controls.Add(vistaButton20);
			groupBox7.Location = new System.Drawing.Point(150, 42);
			groupBox7.Name = "groupBox7";
			groupBox7.Size = new System.Drawing.Size(2, 349);
			groupBox7.TabIndex = 32;
			groupBox7.TabStop = false;
			vistaButton24.BackColor = System.Drawing.Color.Maroon;
			vistaButton24.BaseColor = System.Drawing.Color.White;
			vistaButton24.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton24.ButtonText = "7";
			vistaButton24.CornerRadius = 20;
			vistaButton24.ForeColor = System.Drawing.Color.Black;
			vistaButton24.Location = new System.Drawing.Point(70, 103);
			vistaButton24.Name = "vistaButton24";
			vistaButton24.Size = new System.Drawing.Size(30, 29);
			vistaButton24.TabIndex = 0;
			vistaButton17.BackColor = System.Drawing.Color.Maroon;
			vistaButton17.BaseColor = System.Drawing.Color.White;
			vistaButton17.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton17.ButtonText = "1";
			vistaButton17.CornerRadius = 20;
			vistaButton17.ForeColor = System.Drawing.Color.Black;
			vistaButton17.Location = new System.Drawing.Point(1, -35);
			vistaButton17.Name = "vistaButton17";
			vistaButton17.Size = new System.Drawing.Size(30, 29);
			vistaButton17.TabIndex = 7;
			vistaButton23.BackColor = System.Drawing.Color.Maroon;
			vistaButton23.BaseColor = System.Drawing.Color.White;
			vistaButton23.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton23.ButtonText = "6";
			vistaButton23.CornerRadius = 20;
			vistaButton23.ForeColor = System.Drawing.Color.Black;
			vistaButton23.Location = new System.Drawing.Point(68, 72);
			vistaButton23.Name = "vistaButton23";
			vistaButton23.Size = new System.Drawing.Size(30, 29);
			vistaButton23.TabIndex = 1;
			vistaButton18.BackColor = System.Drawing.Color.Maroon;
			vistaButton18.BaseColor = System.Drawing.Color.White;
			vistaButton18.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton18.ButtonText = "8";
			vistaButton18.CornerRadius = 20;
			vistaButton18.ForeColor = System.Drawing.Color.Black;
			vistaButton18.Location = new System.Drawing.Point(70, 134);
			vistaButton18.Name = "vistaButton18";
			vistaButton18.Size = new System.Drawing.Size(30, 29);
			vistaButton18.TabIndex = 6;
			vistaButton22.BackColor = System.Drawing.Color.Maroon;
			vistaButton22.BaseColor = System.Drawing.Color.White;
			vistaButton22.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton22.ButtonText = "5";
			vistaButton22.CornerRadius = 20;
			vistaButton22.ForeColor = System.Drawing.Color.Black;
			vistaButton22.Location = new System.Drawing.Point(64, 45);
			vistaButton22.Name = "vistaButton22";
			vistaButton22.Size = new System.Drawing.Size(30, 29);
			vistaButton22.TabIndex = 2;
			vistaButton19.BackColor = System.Drawing.Color.Maroon;
			vistaButton19.BaseColor = System.Drawing.Color.White;
			vistaButton19.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton19.ButtonText = "3";
			vistaButton19.CornerRadius = 20;
			vistaButton19.ForeColor = System.Drawing.Color.Black;
			vistaButton19.Location = new System.Drawing.Point(48, -11);
			vistaButton19.Name = "vistaButton19";
			vistaButton19.Size = new System.Drawing.Size(30, 29);
			vistaButton19.TabIndex = 5;
			vistaButton21.BackColor = System.Drawing.Color.Maroon;
			vistaButton21.BaseColor = System.Drawing.Color.White;
			vistaButton21.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton21.ButtonText = "4";
			vistaButton21.CornerRadius = 20;
			vistaButton21.ForeColor = System.Drawing.Color.Black;
			vistaButton21.Location = new System.Drawing.Point(58, 16);
			vistaButton21.Name = "vistaButton21";
			vistaButton21.Size = new System.Drawing.Size(30, 29);
			vistaButton21.TabIndex = 3;
			vistaButton20.BackColor = System.Drawing.Color.Maroon;
			vistaButton20.BaseColor = System.Drawing.Color.White;
			vistaButton20.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton20.ButtonText = "2";
			vistaButton20.CornerRadius = 20;
			vistaButton20.ForeColor = System.Drawing.Color.Black;
			vistaButton20.Location = new System.Drawing.Point(26, -29);
			vistaButton20.Name = "vistaButton20";
			vistaButton20.Size = new System.Drawing.Size(30, 29);
			vistaButton20.TabIndex = 4;
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(84, 149);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(64, 13);
			this.label5.TabIndex = 34;
			this.label5.Text = "Upper Right";
			groupBox3.Controls.Add(groupBox8);
			groupBox3.Controls.Add(vistaButton9);
			groupBox3.Controls.Add(vistaButton10);
			groupBox3.Controls.Add(vistaButton11);
			groupBox3.Controls.Add(vistaButton12);
			groupBox3.Controls.Add(vistaButton13);
			groupBox3.Controls.Add(vistaButton14);
			groupBox3.Controls.Add(vistaButton15);
			groupBox3.Controls.Add(vistaButton16);
			groupBox3.Location = new System.Drawing.Point(150, 42);
			groupBox3.Name = "groupBox3";
			groupBox3.Size = new System.Drawing.Size(2, 349);
			groupBox3.TabIndex = 32;
			groupBox3.TabStop = false;
			groupBox8.Location = new System.Drawing.Point(0, 0);
			groupBox8.Name = "groupBox8";
			groupBox8.Size = new System.Drawing.Size(2, 349);
			groupBox8.TabIndex = 32;
			groupBox8.TabStop = false;
			vistaButton9.BackColor = System.Drawing.Color.Maroon;
			vistaButton9.BaseColor = System.Drawing.Color.White;
			vistaButton9.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton9.ButtonText = "7";
			vistaButton9.CornerRadius = 20;
			vistaButton9.ForeColor = System.Drawing.Color.Black;
			vistaButton9.Location = new System.Drawing.Point(70, 103);
			vistaButton9.Name = "vistaButton9";
			vistaButton9.Size = new System.Drawing.Size(30, 29);
			vistaButton9.TabIndex = 0;
			vistaButton10.BackColor = System.Drawing.Color.Maroon;
			vistaButton10.BaseColor = System.Drawing.Color.White;
			vistaButton10.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton10.ButtonText = "6";
			vistaButton10.CornerRadius = 20;
			vistaButton10.ForeColor = System.Drawing.Color.Black;
			vistaButton10.Location = new System.Drawing.Point(68, 72);
			vistaButton10.Name = "vistaButton10";
			vistaButton10.Size = new System.Drawing.Size(30, 29);
			vistaButton10.TabIndex = 1;
			vistaButton11.BackColor = System.Drawing.Color.Maroon;
			vistaButton11.BaseColor = System.Drawing.Color.White;
			vistaButton11.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton11.ButtonText = "5";
			vistaButton11.CornerRadius = 20;
			vistaButton11.ForeColor = System.Drawing.Color.Black;
			vistaButton11.Location = new System.Drawing.Point(64, 45);
			vistaButton11.Name = "vistaButton11";
			vistaButton11.Size = new System.Drawing.Size(30, 29);
			vistaButton11.TabIndex = 2;
			vistaButton12.BackColor = System.Drawing.Color.Maroon;
			vistaButton12.BaseColor = System.Drawing.Color.White;
			vistaButton12.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton12.ButtonText = "4";
			vistaButton12.CornerRadius = 20;
			vistaButton12.ForeColor = System.Drawing.Color.Black;
			vistaButton12.Location = new System.Drawing.Point(58, 16);
			vistaButton12.Name = "vistaButton12";
			vistaButton12.Size = new System.Drawing.Size(30, 29);
			vistaButton12.TabIndex = 3;
			vistaButton13.BackColor = System.Drawing.Color.Maroon;
			vistaButton13.BaseColor = System.Drawing.Color.White;
			vistaButton13.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton13.ButtonText = "2";
			vistaButton13.CornerRadius = 20;
			vistaButton13.ForeColor = System.Drawing.Color.Black;
			vistaButton13.Location = new System.Drawing.Point(26, -29);
			vistaButton13.Name = "vistaButton13";
			vistaButton13.Size = new System.Drawing.Size(30, 29);
			vistaButton13.TabIndex = 4;
			vistaButton14.BackColor = System.Drawing.Color.Maroon;
			vistaButton14.BaseColor = System.Drawing.Color.White;
			vistaButton14.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton14.ButtonText = "3";
			vistaButton14.CornerRadius = 20;
			vistaButton14.ForeColor = System.Drawing.Color.Black;
			vistaButton14.Location = new System.Drawing.Point(48, -11);
			vistaButton14.Name = "vistaButton14";
			vistaButton14.Size = new System.Drawing.Size(30, 29);
			vistaButton14.TabIndex = 5;
			vistaButton15.BackColor = System.Drawing.Color.Maroon;
			vistaButton15.BaseColor = System.Drawing.Color.White;
			vistaButton15.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton15.ButtonText = "8";
			vistaButton15.CornerRadius = 20;
			vistaButton15.ForeColor = System.Drawing.Color.Black;
			vistaButton15.Location = new System.Drawing.Point(70, 134);
			vistaButton15.Name = "vistaButton15";
			vistaButton15.Size = new System.Drawing.Size(30, 29);
			vistaButton15.TabIndex = 6;
			vistaButton16.BackColor = System.Drawing.Color.Maroon;
			vistaButton16.BaseColor = System.Drawing.Color.White;
			vistaButton16.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton16.ButtonText = "1";
			vistaButton16.CornerRadius = 20;
			vistaButton16.ForeColor = System.Drawing.Color.Black;
			vistaButton16.Location = new System.Drawing.Point(1, -35);
			vistaButton16.Name = "vistaButton16";
			vistaButton16.Size = new System.Drawing.Size(30, 29);
			vistaButton16.TabIndex = 7;
			U9.BackColor = System.Drawing.Color.Maroon;
			U9.BaseColor = System.Drawing.Color.White;
			U9.ButtonColor = System.Drawing.Color.LightGray;
			U9.ButtonText = "1";
			U9.CornerRadius = 20;
			U9.ForeColor = System.Drawing.Color.Black;
			U9.Location = new System.Drawing.Point(156, 3);
			U9.Name = "U9";
			U9.Size = new System.Drawing.Size(30, 29);
			U9.TabIndex = 15;
			U9.Click += new System.EventHandler(U9_Click);
			U17.BackColor = System.Drawing.Color.Maroon;
			U17.BaseColor = System.Drawing.Color.White;
			U17.ButtonColor = System.Drawing.Color.LightGray;
			U17.ButtonText = "1";
			U17.CornerRadius = 20;
			U17.ForeColor = System.Drawing.Color.Black;
			U17.Location = new System.Drawing.Point(114, 391);
			U17.Name = "U17";
			U17.Size = new System.Drawing.Size(30, 29);
			U17.TabIndex = 20;
			U17.Click += new System.EventHandler(U17_Click);
			U16.BackColor = System.Drawing.Color.Maroon;
			U16.BaseColor = System.Drawing.Color.White;
			U16.ButtonColor = System.Drawing.Color.LightGray;
			U16.ButtonText = "8";
			U16.CornerRadius = 20;
			U16.ForeColor = System.Drawing.Color.Black;
			U16.Location = new System.Drawing.Point(220, 180);
			U16.Name = "U16";
			U16.Size = new System.Drawing.Size(30, 29);
			U16.TabIndex = 14;
			U16.Click += new System.EventHandler(U16_Click);
			U20.BackColor = System.Drawing.Color.Maroon;
			U20.BaseColor = System.Drawing.Color.White;
			U20.ButtonColor = System.Drawing.Color.LightGray;
			U20.ButtonText = "4";
			U20.CornerRadius = 20;
			U20.ForeColor = System.Drawing.Color.Black;
			U20.Location = new System.Drawing.Point(57, 338);
			U20.Name = "U20";
			U20.Size = new System.Drawing.Size(30, 29);
			U20.TabIndex = 18;
			U20.Click += new System.EventHandler(U20_Click);
			U18.BackColor = System.Drawing.Color.Maroon;
			U18.BaseColor = System.Drawing.Color.White;
			U18.ButtonColor = System.Drawing.Color.LightGray;
			U18.ButtonText = "2";
			U18.CornerRadius = 20;
			U18.ForeColor = System.Drawing.Color.Black;
			U18.Location = new System.Drawing.Point(86, 385);
			U18.Name = "U18";
			U18.Size = new System.Drawing.Size(30, 29);
			U18.TabIndex = 21;
			U18.Click += new System.EventHandler(U18_Click);
			U11.BackColor = System.Drawing.Color.Maroon;
			U11.BaseColor = System.Drawing.Color.White;
			U11.ButtonColor = System.Drawing.Color.LightGray;
			U11.ButtonText = "3";
			U11.CornerRadius = 20;
			U11.ForeColor = System.Drawing.Color.Black;
			U11.Location = new System.Drawing.Point(207, 29);
			U11.Name = "U11";
			U11.Size = new System.Drawing.Size(30, 29);
			U11.TabIndex = 13;
			U11.Click += new System.EventHandler(U11_Click);
			U24.BackColor = System.Drawing.Color.Maroon;
			U24.BaseColor = System.Drawing.Color.White;
			U24.ButtonColor = System.Drawing.Color.LightGray;
			U24.ButtonText = "8";
			U24.CornerRadius = 20;
			U24.ForeColor = System.Drawing.Color.Black;
			U24.Location = new System.Drawing.Point(47, 219);
			U24.Name = "U24";
			U24.Size = new System.Drawing.Size(30, 29);
			U24.TabIndex = 25;
			U24.Click += new System.EventHandler(U24_Click);
			U10.BackColor = System.Drawing.Color.Maroon;
			U10.BaseColor = System.Drawing.Color.White;
			U10.ButtonColor = System.Drawing.Color.LightGray;
			U10.ButtonText = "2";
			U10.CornerRadius = 20;
			U10.ForeColor = System.Drawing.Color.Black;
			U10.Location = new System.Drawing.Point(188, 9);
			U10.Name = "U10";
			U10.Size = new System.Drawing.Size(30, 29);
			U10.TabIndex = 12;
			U10.Click += new System.EventHandler(U10_Click);
			U21.BackColor = System.Drawing.Color.Maroon;
			U21.BaseColor = System.Drawing.Color.White;
			U21.ButtonColor = System.Drawing.Color.LightGray;
			U21.ButtonText = "5";
			U21.CornerRadius = 20;
			U21.ForeColor = System.Drawing.Color.Black;
			U21.Location = new System.Drawing.Point(52, 309);
			U21.Name = "U21";
			U21.Size = new System.Drawing.Size(30, 29);
			U21.TabIndex = 17;
			U21.Click += new System.EventHandler(U21_Click);
			U15.BackColor = System.Drawing.Color.Maroon;
			U15.BaseColor = System.Drawing.Color.White;
			U15.ButtonColor = System.Drawing.Color.LightGray;
			U15.ButtonText = "7";
			U15.CornerRadius = 20;
			U15.ForeColor = System.Drawing.Color.Black;
			U15.Location = new System.Drawing.Point(220, 149);
			U15.Name = "U15";
			U15.Size = new System.Drawing.Size(30, 29);
			U15.TabIndex = 8;
			U15.Click += new System.EventHandler(U15_Click);
			U26.BackColor = System.Drawing.Color.Maroon;
			U26.BaseColor = System.Drawing.Color.White;
			U26.ButtonColor = System.Drawing.Color.LightGray;
			U26.ButtonText = "2";
			U26.CornerRadius = 20;
			U26.ForeColor = System.Drawing.Color.Black;
			U26.Location = new System.Drawing.Point(184, 379);
			U26.Name = "U26";
			U26.Size = new System.Drawing.Size(30, 29);
			U26.TabIndex = 31;
			U26.Click += new System.EventHandler(U26_Click);
			U14.BackColor = System.Drawing.Color.Maroon;
			U14.BaseColor = System.Drawing.Color.White;
			U14.ButtonColor = System.Drawing.Color.LightGray;
			U14.ButtonText = "6";
			U14.CornerRadius = 20;
			U14.ForeColor = System.Drawing.Color.Black;
			U14.Location = new System.Drawing.Point(220, 118);
			U14.Name = "U14";
			U14.Size = new System.Drawing.Size(30, 29);
			U14.TabIndex = 9;
			U14.Click += new System.EventHandler(U14_Click);
			U1.BackColor = System.Drawing.Color.Maroon;
			U1.BaseColor = System.Drawing.Color.White;
			U1.ButtonColor = System.Drawing.Color.LightGray;
			U1.ButtonText = "1";
			U1.CornerRadius = 20;
			U1.ForeColor = System.Drawing.Color.Black;
			U1.Location = new System.Drawing.Point(114, 3);
			U1.Name = "U1";
			U1.Size = new System.Drawing.Size(30, 29);
			U1.TabIndex = 7;
			U1.Click += new System.EventHandler(U1_Click);
			U13.BackColor = System.Drawing.Color.Maroon;
			U13.BaseColor = System.Drawing.Color.White;
			U13.ButtonColor = System.Drawing.Color.LightGray;
			U13.ButtonText = "5";
			U13.CornerRadius = 20;
			U13.ForeColor = System.Drawing.Color.Black;
			U13.Location = new System.Drawing.Point(220, 91);
			U13.Name = "U13";
			U13.Size = new System.Drawing.Size(30, 29);
			U13.TabIndex = 10;
			U13.Click += new System.EventHandler(U13_Click);
			U7.BackColor = System.Drawing.Color.Maroon;
			U7.BaseColor = System.Drawing.Color.White;
			U7.ButtonColor = System.Drawing.Color.LightGray;
			U7.ButtonText = "7";
			U7.CornerRadius = 20;
			U7.ForeColor = System.Drawing.Color.Black;
			U7.Location = new System.Drawing.Point(47, 149);
			U7.Name = "U7";
			U7.Size = new System.Drawing.Size(30, 29);
			U7.TabIndex = 0;
			U7.Click += new System.EventHandler(U7_Click);
			U12.BackColor = System.Drawing.Color.Maroon;
			U12.BaseColor = System.Drawing.Color.White;
			U12.ButtonColor = System.Drawing.Color.LightGray;
			U12.ButtonText = "4";
			U12.CornerRadius = 20;
			U12.ForeColor = System.Drawing.Color.Black;
			U12.Location = new System.Drawing.Point(217, 56);
			U12.Name = "U12";
			U12.Size = new System.Drawing.Size(30, 29);
			U12.TabIndex = 11;
			U12.Click += new System.EventHandler(U12_Click);
			U19.BackColor = System.Drawing.Color.Maroon;
			U19.BaseColor = System.Drawing.Color.White;
			U19.ButtonColor = System.Drawing.Color.LightGray;
			U19.ButtonText = "3";
			U19.CornerRadius = 20;
			U19.ForeColor = System.Drawing.Color.Black;
			U19.Location = new System.Drawing.Point(68, 365);
			U19.Name = "U19";
			U19.Size = new System.Drawing.Size(30, 29);
			U19.TabIndex = 19;
			U19.Click += new System.EventHandler(U19_Click);
			U6.BackColor = System.Drawing.Color.Maroon;
			U6.BaseColor = System.Drawing.Color.White;
			U6.ButtonColor = System.Drawing.Color.LightGray;
			U6.ButtonText = "6";
			U6.CornerRadius = 20;
			U6.ForeColor = System.Drawing.Color.Black;
			U6.Location = new System.Drawing.Point(47, 115);
			U6.Name = "U6";
			U6.Size = new System.Drawing.Size(30, 29);
			U6.TabIndex = 1;
			U6.Click += new System.EventHandler(U6_Click);
			U29.BackColor = System.Drawing.Color.Maroon;
			U29.BaseColor = System.Drawing.Color.White;
			U29.ButtonColor = System.Drawing.Color.LightGray;
			U29.ButtonText = "5";
			U29.CornerRadius = 20;
			U29.ForeColor = System.Drawing.Color.Black;
			U29.Location = new System.Drawing.Point(221, 307);
			U29.Name = "U29";
			U29.Size = new System.Drawing.Size(30, 29);
			U29.TabIndex = 30;
			U29.Click += new System.EventHandler(U29_Click);
			U5.BackColor = System.Drawing.Color.Maroon;
			U5.BaseColor = System.Drawing.Color.White;
			U5.ButtonColor = System.Drawing.Color.LightGray;
			U5.ButtonText = "5";
			U5.CornerRadius = 20;
			U5.ForeColor = System.Drawing.Color.Black;
			U5.Location = new System.Drawing.Point(47, 85);
			U5.Name = "U5";
			U5.Size = new System.Drawing.Size(30, 29);
			U5.TabIndex = 2;
			U5.Click += new System.EventHandler(U5_Click);
			U23.BackColor = System.Drawing.Color.Maroon;
			U23.BaseColor = System.Drawing.Color.White;
			U23.ButtonColor = System.Drawing.Color.LightGray;
			U23.ButtonText = "7";
			U23.CornerRadius = 20;
			U23.ForeColor = System.Drawing.Color.Black;
			U23.Location = new System.Drawing.Point(47, 250);
			U23.Name = "U23";
			U23.Size = new System.Drawing.Size(30, 29);
			U23.TabIndex = 16;
			U23.Click += new System.EventHandler(U23_Click);
			U4.BackColor = System.Drawing.Color.Maroon;
			U4.BaseColor = System.Drawing.Color.White;
			U4.ButtonColor = System.Drawing.Color.LightGray;
			U4.ButtonText = "4";
			U4.CornerRadius = 20;
			U4.ForeColor = System.Drawing.Color.Black;
			U4.Location = new System.Drawing.Point(49, 54);
			U4.Name = "U4";
			U4.Size = new System.Drawing.Size(30, 29);
			U4.TabIndex = 3;
			U4.Click += new System.EventHandler(U4_Click);
			U22.BackColor = System.Drawing.Color.Maroon;
			U22.BaseColor = System.Drawing.Color.White;
			U22.ButtonColor = System.Drawing.Color.LightGray;
			U22.ButtonText = "6";
			U22.CornerRadius = 20;
			U22.ForeColor = System.Drawing.Color.Black;
			U22.Location = new System.Drawing.Point(49, 280);
			U22.Name = "U22";
			U22.Size = new System.Drawing.Size(30, 29);
			U22.TabIndex = 22;
			U22.Click += new System.EventHandler(U22_Click);
			U2.BackColor = System.Drawing.Color.Maroon;
			U2.BaseColor = System.Drawing.Color.White;
			U2.ButtonColor = System.Drawing.Color.LightGray;
			U2.ButtonText = "2";
			U2.CornerRadius = 20;
			U2.ForeColor = System.Drawing.Color.Black;
			U2.Location = new System.Drawing.Point(84, 10);
			U2.Name = "U2";
			U2.Size = new System.Drawing.Size(30, 29);
			U2.TabIndex = 4;
			U2.Click += new System.EventHandler(U2_Click);
			U28.BackColor = System.Drawing.Color.Maroon;
			U28.BaseColor = System.Drawing.Color.White;
			U28.ButtonColor = System.Drawing.Color.LightGray;
			U28.ButtonText = "4";
			U28.CornerRadius = 20;
			U28.ForeColor = System.Drawing.Color.Black;
			U28.Location = new System.Drawing.Point(215, 335);
			U28.Name = "U28";
			U28.Size = new System.Drawing.Size(30, 29);
			U28.TabIndex = 27;
			U28.Click += new System.EventHandler(U28_Click);
			U3.BackColor = System.Drawing.Color.Maroon;
			U3.BaseColor = System.Drawing.Color.White;
			U3.ButtonColor = System.Drawing.Color.LightGray;
			U3.ButtonText = "3";
			U3.CornerRadius = 20;
			U3.ForeColor = System.Drawing.Color.Black;
			U3.Location = new System.Drawing.Point(59, 27);
			U3.Name = "U3";
			U3.Size = new System.Drawing.Size(30, 29);
			U3.TabIndex = 5;
			U3.Click += new System.EventHandler(U3_Click);
			U27.BackColor = System.Drawing.Color.Maroon;
			U27.BaseColor = System.Drawing.Color.White;
			U27.ButtonColor = System.Drawing.Color.LightGray;
			U27.ButtonText = "3";
			U27.CornerRadius = 20;
			U27.ForeColor = System.Drawing.Color.Black;
			U27.Location = new System.Drawing.Point(202, 358);
			U27.Name = "U27";
			U27.Size = new System.Drawing.Size(30, 29);
			U27.TabIndex = 28;
			U27.Click += new System.EventHandler(U27_Click);
			U30.BackColor = System.Drawing.Color.Maroon;
			U30.BaseColor = System.Drawing.Color.White;
			U30.ButtonColor = System.Drawing.Color.LightGray;
			U30.ButtonText = "6";
			U30.CornerRadius = 20;
			U30.ForeColor = System.Drawing.Color.Black;
			U30.Location = new System.Drawing.Point(222, 277);
			U30.Name = "U30";
			U30.Size = new System.Drawing.Size(30, 29);
			U30.TabIndex = 24;
			U30.Click += new System.EventHandler(U30_Click);
			U8.BackColor = System.Drawing.Color.Maroon;
			U8.BaseColor = System.Drawing.Color.White;
			U8.ButtonColor = System.Drawing.Color.LightGray;
			U8.ButtonText = "8";
			U8.CornerRadius = 20;
			U8.ForeColor = System.Drawing.Color.Black;
			U8.Location = new System.Drawing.Point(47, 180);
			U8.Name = "U8";
			U8.Size = new System.Drawing.Size(30, 29);
			U8.TabIndex = 6;
			U8.Click += new System.EventHandler(U8_Click);
			U32.BackColor = System.Drawing.Color.Maroon;
			U32.BaseColor = System.Drawing.Color.White;
			U32.ButtonColor = System.Drawing.Color.LightGray;
			U32.ButtonText = "8";
			U32.CornerRadius = 20;
			U32.ForeColor = System.Drawing.Color.Black;
			U32.Location = new System.Drawing.Point(223, 217);
			U32.Name = "U32";
			U32.Size = new System.Drawing.Size(30, 29);
			U32.TabIndex = 29;
			U32.Click += new System.EventHandler(U32_Click);
			U25.BackColor = System.Drawing.Color.Maroon;
			U25.BaseColor = System.Drawing.Color.White;
			U25.ButtonColor = System.Drawing.Color.LightGray;
			U25.ButtonText = "1";
			U25.CornerRadius = 20;
			U25.ForeColor = System.Drawing.Color.Black;
			U25.Location = new System.Drawing.Point(156, 389);
			U25.Name = "U25";
			U25.Size = new System.Drawing.Size(30, 29);
			U25.TabIndex = 23;
			U25.Click += new System.EventHandler(U25_Click);
			U31.BackColor = System.Drawing.Color.Maroon;
			U31.BaseColor = System.Drawing.Color.White;
			U31.ButtonColor = System.Drawing.Color.LightGray;
			U31.ButtonText = "7";
			U31.CornerRadius = 20;
			U31.ForeColor = System.Drawing.Color.Black;
			U31.Location = new System.Drawing.Point(222, 248);
			U31.Name = "U31";
			U31.Size = new System.Drawing.Size(30, 29);
			U31.TabIndex = 26;
			U31.Click += new System.EventHandler(U31_Click);
			NextVisitCom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			NextVisitCom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			NextVisitCom.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			NextVisitCom.FormattingEnabled = true;
			NextVisitCom.Location = new System.Drawing.Point(90, 565);
			NextVisitCom.Name = "NextVisitCom";
			NextVisitCom.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			NextVisitCom.Size = new System.Drawing.Size(360, 24);
			NextVisitCom.TabIndex = 106;
			groupBox10.BackColor = System.Drawing.Color.Transparent;
			groupBox10.Controls.Add(checkBox2);
			groupBox10.Controls.Add(radioButton2);
			groupBox10.Controls.Add(radioButton1);
			groupBox10.Controls.Add(textBox2);
			groupBox10.Controls.Add(comboBox1);
			groupBox10.Location = new System.Drawing.Point(7, -1);
			groupBox10.Name = "groupBox10";
			groupBox10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox10.Size = new System.Drawing.Size(949, 50);
			groupBox10.TabIndex = 107;
			groupBox10.TabStop = false;
			checkBox2.AutoSize = true;
			checkBox2.Location = new System.Drawing.Point(692, 19);
			checkBox2.Name = "checkBox2";
			checkBox2.Size = new System.Drawing.Size(112, 17);
			checkBox2.TabIndex = 8;
			checkBox2.Text = "البحث عن المرضى";
			checkBox2.UseVisualStyleBackColor = true;
			checkBox2.CheckedChanged += new System.EventHandler(checkBox2_CheckedChanged);
			radioButton2.AutoSize = true;
			radioButton2.Checked = true;
			radioButton2.Location = new System.Drawing.Point(526, 17);
			radioButton2.Name = "radioButton2";
			radioButton2.Size = new System.Drawing.Size(110, 17);
			radioButton2.TabIndex = 7;
			radioButton2.TabStop = true;
			radioButton2.Text = "بحث باسم الشركة";
			radioButton2.UseVisualStyleBackColor = true;
			radioButton1.AutoSize = true;
			radioButton1.Location = new System.Drawing.Point(154, 17);
			radioButton1.Name = "radioButton1";
			radioButton1.Size = new System.Drawing.Size(107, 17);
			radioButton1.TabIndex = 6;
			radioButton1.TabStop = true;
			radioButton1.Text = "بحث برقم الموبايل";
			radioButton1.UseVisualStyleBackColor = true;
			textBox2.Location = new System.Drawing.Point(22, 15);
			textBox2.Name = "textBox2";
			textBox2.Size = new System.Drawing.Size(128, 20);
			textBox2.TabIndex = 5;
			textBox2.TextChanged += new System.EventHandler(textBox2_TextChanged);
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			comboBox1.FormattingEnabled = true;
			comboBox1.Location = new System.Drawing.Point(282, 13);
			comboBox1.Name = "comboBox1";
			comboBox1.Size = new System.Drawing.Size(240, 24);
			comboBox1.TabIndex = 3;
			comboBox1.SelectedIndexChanged += new System.EventHandler(comboBox1_SelectedIndexChanged);
			panel2.BackColor = System.Drawing.Color.Transparent;
			panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			panel2.Controls.Add(label22);
			panel2.Controls.Add(label23);
			panel2.Controls.Add(label24);
			panel2.Controls.Add(numericUpDown13);
			panel2.Controls.Add(label18);
			panel2.Controls.Add(tableLayoutPanel1);
			panel2.Controls.Add(label12);
			panel2.Controls.Add(numericUpDown14);
			panel2.Controls.Add(label13);
			panel2.Controls.Add(tableLayoutPanel2);
			panel2.Controls.Add(label17);
			panel2.Controls.Add(label25);
			panel2.Location = new System.Drawing.Point(665, 61);
			panel2.Name = "panel2";
			panel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			panel2.Size = new System.Drawing.Size(291, 443);
			panel2.TabIndex = 110;
			panel2.Visible = false;
			label22.AutoSize = true;
			label22.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label22.Location = new System.Drawing.Point(23, 161);
			label22.Name = "label22";
			label22.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label22.Size = new System.Drawing.Size(38, 16);
			label22.TabIndex = 46;
			label22.Text = "I.P.D";
			label23.AutoSize = true;
			label23.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label23.Location = new System.Drawing.Point(23, 125);
			label23.Name = "label23";
			label23.Size = new System.Drawing.Size(41, 16);
			label23.TabIndex = 45;
			label23.Text = "Read";
			label24.AutoSize = true;
			label24.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label24.Location = new System.Drawing.Point(23, 90);
			label24.Name = "label24";
			label24.Size = new System.Drawing.Size(33, 16);
			label24.TabIndex = 44;
			label24.Text = "Dist";
			numericUpDown13.DecimalPlaces = 2;
			numericUpDown13.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown13.Location = new System.Drawing.Point(140, 160);
			numericUpDown13.Maximum = new decimal(new int[4] { 25, 0, 0, 0 });
			numericUpDown13.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown13.Name = "numericUpDown13";
			numericUpDown13.Size = new System.Drawing.Size(58, 20);
			numericUpDown13.TabIndex = 43;
			label18.AutoSize = true;
			label18.Font = new System.Drawing.Font("Tahoma", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label18.Location = new System.Drawing.Point(155, 28);
			label18.Name = "label18";
			label18.Size = new System.Drawing.Size(21, 19);
			label18.TabIndex = 42;
			label18.Text = "R";
			tableLayoutPanel1.BackColor = System.Drawing.Color.WhiteSmoke;
			tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			tableLayoutPanel1.ColumnCount = 3;
			tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333f));
			tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333f));
			tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333f));
			tableLayoutPanel1.Controls.Add(numericUpDown1, 2, 1);
			tableLayoutPanel1.Controls.Add(label19, 0, 0);
			tableLayoutPanel1.Controls.Add(label20, 2, 0);
			tableLayoutPanel1.Controls.Add(numericUpDown5, 1, 2);
			tableLayoutPanel1.Controls.Add(label21, 1, 0);
			tableLayoutPanel1.Controls.Add(numericUpDown6, 0, 2);
			tableLayoutPanel1.Controls.Add(numericUpDown2, 1, 1);
			tableLayoutPanel1.Controls.Add(numericUpDown4, 2, 2);
			tableLayoutPanel1.Controls.Add(numericUpDown3, 0, 1);
			tableLayoutPanel1.Location = new System.Drawing.Point(69, 50);
			tableLayoutPanel1.Name = "tableLayoutPanel1";
			tableLayoutPanel1.RowCount = 3;
			tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333f));
			tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333f));
			tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333f));
			tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20f));
			tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20f));
			tableLayoutPanel1.Size = new System.Drawing.Size(197, 104);
			tableLayoutPanel1.TabIndex = 41;
			numericUpDown1.DecimalPlaces = 2;
			numericUpDown1.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown1.Location = new System.Drawing.Point(4, 38);
			numericUpDown1.Maximum = new decimal(new int[4] { 25, 0, 0, 0 });
			numericUpDown1.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown1.Name = "numericUpDown1";
			numericUpDown1.Size = new System.Drawing.Size(59, 20);
			numericUpDown1.TabIndex = 30;
			label19.Location = new System.Drawing.Point(142, 1);
			label19.Name = "label19";
			label19.Size = new System.Drawing.Size(51, 29);
			label19.TabIndex = 2;
			label19.Text = "AX";
			label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label20.Location = new System.Drawing.Point(4, 1);
			label20.Name = "label20";
			label20.Size = new System.Drawing.Size(59, 30);
			label20.TabIndex = 0;
			label20.Text = "SPH";
			label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			numericUpDown5.DecimalPlaces = 2;
			numericUpDown5.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown5.Location = new System.Drawing.Point(70, 72);
			numericUpDown5.Maximum = new decimal(new int[4] { 25, 0, 0, 0 });
			numericUpDown5.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown5.Name = "numericUpDown5";
			numericUpDown5.Size = new System.Drawing.Size(58, 20);
			numericUpDown5.TabIndex = 30;
			label21.Location = new System.Drawing.Point(77, 1);
			label21.Name = "label21";
			label21.Size = new System.Drawing.Size(51, 29);
			label21.TabIndex = 1;
			label21.Text = "CYL";
			label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			numericUpDown6.Location = new System.Drawing.Point(135, 72);
			numericUpDown6.Maximum = new decimal(new int[4] { 180, 0, 0, 0 });
			numericUpDown6.Name = "numericUpDown6";
			numericUpDown6.Size = new System.Drawing.Size(58, 20);
			numericUpDown6.TabIndex = 30;
			numericUpDown2.DecimalPlaces = 2;
			numericUpDown2.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown2.Location = new System.Drawing.Point(70, 38);
			numericUpDown2.Maximum = new decimal(new int[4] { 25, 0, 0, 0 });
			numericUpDown2.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown2.Name = "numericUpDown2";
			numericUpDown2.Size = new System.Drawing.Size(58, 20);
			numericUpDown2.TabIndex = 30;
			numericUpDown4.DecimalPlaces = 2;
			numericUpDown4.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown4.Location = new System.Drawing.Point(4, 72);
			numericUpDown4.Maximum = new decimal(new int[4] { 25, 0, 0, 0 });
			numericUpDown4.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown4.Name = "numericUpDown4";
			numericUpDown4.Size = new System.Drawing.Size(59, 20);
			numericUpDown4.TabIndex = 30;
			numericUpDown3.Location = new System.Drawing.Point(135, 38);
			numericUpDown3.Maximum = new decimal(new int[4] { 180, 0, 0, 0 });
			numericUpDown3.Name = "numericUpDown3";
			numericUpDown3.Size = new System.Drawing.Size(58, 20);
			numericUpDown3.TabIndex = 30;
			label12.AutoSize = true;
			label12.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label12.Location = new System.Drawing.Point(23, 389);
			label12.Name = "label12";
			label12.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label12.Size = new System.Drawing.Size(38, 16);
			label12.TabIndex = 40;
			label12.Text = "I.P.D";
			numericUpDown14.DecimalPlaces = 2;
			numericUpDown14.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown14.Location = new System.Drawing.Point(140, 390);
			numericUpDown14.Maximum = new decimal(new int[4] { 25, 0, 0, 0 });
			numericUpDown14.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown14.Name = "numericUpDown14";
			numericUpDown14.Size = new System.Drawing.Size(58, 20);
			numericUpDown14.TabIndex = 39;
			label13.AutoSize = true;
			label13.Font = new System.Drawing.Font("Tahoma", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label13.Location = new System.Drawing.Point(155, 258);
			label13.Name = "label13";
			label13.Size = new System.Drawing.Size(18, 19);
			label13.TabIndex = 38;
			label13.Text = "L";
			tableLayoutPanel2.BackColor = System.Drawing.Color.WhiteSmoke;
			tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			tableLayoutPanel2.ColumnCount = 3;
			tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333f));
			tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333f));
			tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333f));
			tableLayoutPanel2.Controls.Add(label14, 0, 0);
			tableLayoutPanel2.Controls.Add(label15, 2, 0);
			tableLayoutPanel2.Controls.Add(label16, 1, 0);
			tableLayoutPanel2.Controls.Add(numericUpDown7, 2, 1);
			tableLayoutPanel2.Controls.Add(numericUpDown8, 1, 1);
			tableLayoutPanel2.Controls.Add(numericUpDown11, 1, 2);
			tableLayoutPanel2.Controls.Add(numericUpDown12, 0, 2);
			tableLayoutPanel2.Controls.Add(numericUpDown9, 0, 1);
			tableLayoutPanel2.Controls.Add(numericUpDown10, 2, 2);
			tableLayoutPanel2.Location = new System.Drawing.Point(69, 280);
			tableLayoutPanel2.Name = "tableLayoutPanel2";
			tableLayoutPanel2.RowCount = 3;
			tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333f));
			tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333f));
			tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333f));
			tableLayoutPanel2.Size = new System.Drawing.Size(197, 104);
			tableLayoutPanel2.TabIndex = 37;
			label14.Location = new System.Drawing.Point(142, 1);
			label14.Name = "label14";
			label14.Size = new System.Drawing.Size(51, 29);
			label14.TabIndex = 2;
			label14.Text = "AX";
			label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label15.Location = new System.Drawing.Point(4, 1);
			label15.Name = "label15";
			label15.Size = new System.Drawing.Size(59, 30);
			label15.TabIndex = 0;
			label15.Text = "SPH";
			label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			label16.Location = new System.Drawing.Point(77, 1);
			label16.Name = "label16";
			label16.Size = new System.Drawing.Size(51, 29);
			label16.TabIndex = 1;
			label16.Text = "CYL";
			label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			numericUpDown7.DecimalPlaces = 2;
			numericUpDown7.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown7.Location = new System.Drawing.Point(5, 38);
			numericUpDown7.Maximum = new decimal(new int[4] { 25, 0, 0, 0 });
			numericUpDown7.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown7.Name = "numericUpDown7";
			numericUpDown7.Size = new System.Drawing.Size(58, 20);
			numericUpDown7.TabIndex = 30;
			numericUpDown8.DecimalPlaces = 2;
			numericUpDown8.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown8.Location = new System.Drawing.Point(70, 38);
			numericUpDown8.Maximum = new decimal(new int[4] { 25, 0, 0, 0 });
			numericUpDown8.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown8.Name = "numericUpDown8";
			numericUpDown8.Size = new System.Drawing.Size(58, 20);
			numericUpDown8.TabIndex = 30;
			numericUpDown11.DecimalPlaces = 2;
			numericUpDown11.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown11.Location = new System.Drawing.Point(70, 72);
			numericUpDown11.Maximum = new decimal(new int[4] { 25, 0, 0, 0 });
			numericUpDown11.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown11.Name = "numericUpDown11";
			numericUpDown11.Size = new System.Drawing.Size(58, 20);
			numericUpDown11.TabIndex = 30;
			numericUpDown12.Location = new System.Drawing.Point(135, 72);
			numericUpDown12.Maximum = new decimal(new int[4] { 180, 0, 0, 0 });
			numericUpDown12.Name = "numericUpDown12";
			numericUpDown12.Size = new System.Drawing.Size(58, 20);
			numericUpDown12.TabIndex = 30;
			numericUpDown9.Location = new System.Drawing.Point(135, 38);
			numericUpDown9.Maximum = new decimal(new int[4] { 180, 0, 0, 0 });
			numericUpDown9.Name = "numericUpDown9";
			numericUpDown9.Size = new System.Drawing.Size(58, 20);
			numericUpDown9.TabIndex = 30;
			numericUpDown10.DecimalPlaces = 2;
			numericUpDown10.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown10.Location = new System.Drawing.Point(5, 72);
			numericUpDown10.Maximum = new decimal(new int[4] { 25, 0, 0, 0 });
			numericUpDown10.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown10.Name = "numericUpDown10";
			numericUpDown10.Size = new System.Drawing.Size(58, 20);
			numericUpDown10.TabIndex = 30;
			label17.AutoSize = true;
			label17.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label17.Location = new System.Drawing.Point(23, 353);
			label17.Name = "label17";
			label17.Size = new System.Drawing.Size(41, 16);
			label17.TabIndex = 36;
			label17.Text = "Read";
			label25.AutoSize = true;
			label25.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label25.Location = new System.Drawing.Point(23, 318);
			label25.Name = "label25";
			label25.Size = new System.Drawing.Size(33, 16);
			label25.TabIndex = 35;
			label25.Text = "Dist";
			groupBox11.BackColor = System.Drawing.Color.Transparent;
			groupBox11.Controls.Add(saveBtn);
			groupBox11.Location = new System.Drawing.Point(6, 595);
			groupBox11.Name = "groupBox11";
			groupBox11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox11.Size = new System.Drawing.Size(950, 55);
			groupBox11.TabIndex = 111;
			groupBox11.TabStop = false;
			base.AcceptButton = ADDBtn;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			base.ClientSize = new System.Drawing.Size(969, 709);
			base.Controls.Add(groupBox11);
			base.Controls.Add(panel2);
			base.Controls.Add(groupBox10);
			base.Controls.Add(NextVisitCom);
			base.Controls.Add(label8);
			base.Controls.Add(panel1);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox5);
			base.Controls.Add(tottextBox);
			base.Controls.Add(label5);
			base.Controls.Add(groupBox4);
			base.KeyPreview = true;
			base.Name = "PatientAccountFrm";
			Text = "حسابات المرضى";
			base.Load += new System.EventHandler(PatientAccountSecretary_Load);
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(PatientAccountSecretary_FormClosing);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(PatientAccountSecretary_KeyDown);
			groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox5.ResumeLayout(false);
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			groupBox9.ResumeLayout(false);
			groupBox9.PerformLayout();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			groupBox7.ResumeLayout(false);
			groupBox3.ResumeLayout(false);
			groupBox10.ResumeLayout(false);
			groupBox10.PerformLayout();
			panel2.ResumeLayout(false);
			panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown13).EndInit();
			tableLayoutPanel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown5).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown6).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown4).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown3).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown14).EndInit();
			tableLayoutPanel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)numericUpDown7).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown8).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown11).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown12).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown9).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown10).EndInit();
			groupBox11.ResumeLayout(false);
			ResumeLayout(false);
			PerformLayout();
		}

		public PatientAccountFrm()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
		}

		public PatientAccountFrm(int PationtId)
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
			PationtID = PationtId;
		}

		public void GetNextVisit()
		{
			try
			{
				DataTable dataTable = codes.Search2("select distinct(NextVisit) from PatientData where ID='" + PatientComboBox.SelectedValue.ToString() + "'");
				NextVisitCom.DataSource = null;
				NextVisitCom.DataSource = dataTable;
				NextVisitCom.DisplayMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		public void GetBean()
		{
			try
			{
				string text = codes.Search2("select ServiceName from Properties ").Rows[0][0].ToString();
				DataTable dataTable = codes.Search2("select distinct(Service) from CompanyService where Service != '" + text + "' ");
				commentTextBox.DataSource = dataTable;
				commentTextBox.DisplayMember = dataTable.Columns[0].ToString();
				commentTextBox.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void PatientAccountSecretary_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select ChangeServicePrice from users where userName ='" + Main.usernames + "' and userPassward ='" + Main.passward + "'");
				PricetextBox.Enabled = Convert.ToBoolean(dataTable.Rows[0][0].ToString());
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = codes.Search2("select * from Company");
				comboBox1.DataSource = dataTable2;
				comboBox1.ValueMember = dataTable2.Columns[0].ToString();
				comboBox1.DisplayMember = dataTable2.Columns[1].ToString();
			}
			catch
			{
			}
			DataTable dataTable3 = new DataTable();
			try
			{
				dataTable3 = dc.Select("SelectAllDoctor");
				gui.loadComboBox(doctorcomboBox, dataTable3);
			}
			catch
			{
			}
			if (PationtID != 0)
			{
				try
				{
					DataTable dataTable4 = codes.Search2("SELECT DISTINCT PatientData.ID, PatientData.PName\r\nFROM            Appointments INNER JOIN\r\n                         PatientData ON Appointments.PatuentID = PatientData.ID where PatientData.ID ='" + PationtID + "' ");
					PatientComboBox.DataSource = dataTable4;
					PatientComboBox.ValueMember = dataTable4.Columns[0].ToString();
					PatientComboBox.DisplayMember = dataTable4.Columns[1].ToString();
				}
				catch
				{
				}
			}
			if (PationtID == 0)
			{
				try
				{
					DataTable dataTable4 = codes.Search2("SELECT DISTINCT PatientData.ID, PatientData.PName\r\nFROM            Appointments INNER JOIN\r\n                         PatientData ON Appointments.PatuentID = PatientData.ID ");
					PatientComboBox.DataSource = dataTable4;
					PatientComboBox.ValueMember = dataTable4.Columns[0].ToString();
					PatientComboBox.DisplayMember = dataTable4.Columns[1].ToString();
				}
				catch
				{
				}
			}
			GetBean();
			GetNextVisit();
			DisplayImag();
		}

		public void DisplayImag()
		{
			try
			{
				DataTable tableText = dc.GetTableText("select ClinicType,EyeClinic from DentalData ");
				panel1.Visible = Convert.ToBoolean(tableText.Rows[0][0].ToString());
				panel2.Visible = Convert.ToBoolean(tableText.Rows[0][1].ToString());
			}
			catch
			{
			}
		}

		private void commentTextBox_TextChanged(object sender, EventArgs e)
		{
			try
			{
				string text = commentTextBox.Text;
				if (text.StartsWith(" "))
				{
					MessageBox.Show("لا يمكن ترك فراغ في بداية الإسم", "تنبيه");
					commentTextBox.Text = "";
				}
			}
			catch
			{
			}
		}

		private void PricetextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				char keyChar = e.KeyChar;
				if (!char.IsDigit(keyChar) && keyChar != '\b')
				{
					e.Handled = true;
					MessageBox.Show("من فضلك ادخل ارقام فقط");
				}
			}
			catch
			{
			}
		}

		private void PricetextBox_Leave(object sender, EventArgs e)
		{
			try
			{
				if (PricetextBox.Text == "")
				{
					PricetextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void ADDBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = dc.GetTableText("select * from Empdata where Name='" + doctorcomboBox.Text + "'");
				if (tableText.Rows.Count > 0)
				{
					DataTable tableText2 = dc.GetTableText("select * from PatientData where PName='" + PatientComboBox.Text + "'");
					if (tableText2.Rows.Count > 0)
					{
						if (PricetextBox.Text != "0")
						{
							bool flag = false;
							foreach (Control control in panel1.Controls)
							{
								if (control is VistaButton && control.BackColor == Color.Red)
								{
									string text = control.Name.ToString();
									int num = Convert.ToInt32(text.Remove(0, 1));
									DataTable dataTable = codes.Search2("select Name from Teath where Id='" + num + "'");
									dataGridView1.Rows.Add(commentTextBox.Text, PricetextBox.Text, dateTimePicker1.Value.ToString("MM/dd/yyyy"), dataTable.Rows[0][0].ToString(), num);
									flag = true;
									total = Convert.ToDouble(tottextBox.Text);
									total += Convert.ToDouble(PricetextBox.Text);
									tottextBox.Text = total.ToString();
									commentTextBox.Text = "";
									PricetextBox.Text = "0";
								}
							}
							if (!flag)
							{
								dataGridView1.Rows.Add(commentTextBox.Text, PricetextBox.Text, dateTimePicker1.Value.ToString("MM/dd/yyyy"), "General", "33");
								flag = true;
								total = Convert.ToDouble(tottextBox.Text);
								total += Convert.ToDouble(PricetextBox.Text);
								tottextBox.Text = total.ToString();
								commentTextBox.Text = "";
								PricetextBox.Text = "0";
							}
						}
						else
						{
							MessageBox.Show("من فضلك ادخل الخدمة", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم مريض صحيح");
					}
				}
				else
				{
					MessageBox.Show("من فضلك اختر اسم طبيب صحيح");
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
			try
			{
				total = 0.0;
				if (dataGridView1.Rows.Count > 1)
				{
					for (int i = 1; i < dataGridView1.Rows.Count; i++)
					{
						total += Convert.ToDouble(dataGridView1.Rows[i - 1].Cells[1].Value.ToString());
						tottextBox.Text = total.ToString();
					}
				}
				else
				{
					tottextBox.Text = total.ToString();
				}
			}
			catch
			{
			}
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = dc.GetTableText("select ID from Appointments where PatuentID = " + PatientComboBox.SelectedValue.ToString());
				if (dataTable.Rows.Count <= 0)
				{
					return;
				}
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					appointid = Convert.ToInt32(dataTable.Rows[i][0].ToString());
				}
				string[] fields = new string[7] { "PatientId", "DoctorID", "Bean", "Price", "Date", "BeanDate", "TeathId" };
				if (dataGridView1.Rows.Count > 1)
				{
					for (int i = 1; i < dataGridView1.Rows.Count; i++)
					{
						b = dc.Insert("AddPatientAccount", fields, Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), dataGridView1.Rows[i - 1].Cells[0].Value.ToString(), dataGridView1.Rows[i - 1].Cells[1].Value.ToString(), appdateTimePicker1.Value.ToString("MM/dd/yyyy"), dataGridView1.Rows[i - 1].Cells[2].Value.ToString(), dataGridView1.Rows[i - 1].Cells[4].Value.ToString());
					}
					if (b)
					{
						Codes.Add2("insert into Detect (ClientID,DRsph,DRcyl,DRax,RRsph,RRcyl,RRax,DLsph,DLcyl,DLax,RLsph,RLcyl,Rlax,DateDetect,IPDR,IPDL) values ('" + PatientComboBox.SelectedValue.ToString() + "','" + numericUpDown1.Text + "','" + numericUpDown2.Text + "','" + numericUpDown3.Text + "','" + numericUpDown4.Text + "','" + numericUpDown5.Text + "','" + numericUpDown6.Text + "','" + numericUpDown7.Text + "','" + numericUpDown8.Text + "','" + numericUpDown9.Text + "','" + numericUpDown10.Text + "','" + numericUpDown11.Text + "','" + numericUpDown12.Text + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + numericUpDown13.Value + "','" + numericUpDown14.Value + "')");
						MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						dataGridView1.Rows.Clear();
						try
						{
							string[] fields2 = new string[1] { "ID" };
							dc.Update("updateTrueAppoint", fields2, appointid, true);
						}
						catch
						{
						}
						done = true;
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				else
				{
					MessageBox.Show("لا يوجد بيانات للحفظ", "تنبيه");
				}
				codes.Edit2("UPDATE    PatientData SET    NextVisit ='" + NextVisitCom.Text + "' where ID='" + PatientComboBox.SelectedValue.ToString() + "'");
				GetBean();
			}
			catch
			{
			}
		}

		private void PatientAccountSecretary_FormClosing(object sender, FormClosingEventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = dc.GetTableText("select ID from Appointments where PatientID = " + PatientComboBox.SelectedValue.ToString());
				if (dataTable.Rows.Count > 0)
				{
					if (MessageBox.Show("تم الفحص", "تنبيه", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
					{
						for (int i = 0; i < dataTable.Rows.Count; i++)
						{
							appointid = Convert.ToInt32(dataTable.Rows[i][0].ToString());
						}
						if (done)
						{
							return;
						}
						if (dataGridView1.Rows.Count > 1)
						{
							string[] fields = new string[6] { "PatientId", "DoctorID", "Bean", "Price", "Date", "BeanDate" };
							for (int i = 1; i < dataGridView1.Rows.Count; i++)
							{
								b = dc.Insert("AddPatientAccount", fields, Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), dataGridView1.Rows[i - 1].Cells[0].Value.ToString(), dataGridView1.Rows[i - 1].Cells[1].Value.ToString(), appdateTimePicker1.Value.ToString("MM/dd/yyyy"), dataGridView1.Rows[i - 1].Cells[2].Value.ToString());
							}
							if (b)
							{
								MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								dataGridView1.Rows.Clear();
								try
								{
									string[] fields2 = new string[1] { "ID" };
									dc.Update("updateTrueAppoint", fields2, appointid, true);
								}
								catch
								{
								}
								done = true;
							}
							else
							{
								MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							}
						}
						else
						{
							string[] fields2 = new string[1] { "ID" };
							b = dc.Update("updateTrueAppoint", fields2, appointid);
							if (b)
							{
								MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							else
							{
								MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							}
						}
						return;
					}
					e.Cancel = false;
				}
				else
				{
					e.Cancel = false;
				}
			}
			catch
			{
			}
		}

		private void doctorcomboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

		private void PatientAccountSecretary_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		public void VistaColor(VistaButton vis)
		{
			foreach (Control control in panel1.Controls)
			{
				if (control is VistaButton && control.BackColor == Color.Red)
				{
					U1.ButtonColor = Color.LightGray;
					U2.ButtonColor = Color.LightGray;
					U3.ButtonColor = Color.LightGray;
					U4.ButtonColor = Color.LightGray;
					U5.ButtonColor = Color.LightGray;
					U6.ButtonColor = Color.LightGray;
					U7.ButtonColor = Color.LightGray;
					U8.ButtonColor = Color.LightGray;
					U9.ButtonColor = Color.LightGray;
					U10.ButtonColor = Color.LightGray;
					U11.ButtonColor = Color.LightGray;
					U12.ButtonColor = Color.LightGray;
					U13.ButtonColor = Color.LightGray;
					U14.ButtonColor = Color.LightGray;
					U15.ButtonColor = Color.LightGray;
					U16.ButtonColor = Color.LightGray;
					U32.ButtonColor = Color.LightGray;
					U31.ButtonColor = Color.LightGray;
					U30.ButtonColor = Color.LightGray;
					U29.ButtonColor = Color.LightGray;
					U28.ButtonColor = Color.LightGray;
					U27.ButtonColor = Color.LightGray;
					U26.ButtonColor = Color.LightGray;
					U25.ButtonColor = Color.LightGray;
					U17.ButtonColor = Color.LightGray;
					U18.ButtonColor = Color.LightGray;
					U19.ButtonColor = Color.LightGray;
					U20.ButtonColor = Color.LightGray;
					U21.ButtonColor = Color.LightGray;
					U22.ButtonColor = Color.LightGray;
					U23.ButtonColor = Color.LightGray;
					U24.ButtonColor = Color.LightGray;
					control.BackColor = Color.Maroon;
				}
			}
			if (vis.ButtonColor == Color.Red)
			{
				vis.ButtonColor = Color.LightGray;
				vis.BackColor = Color.Maroon;
			}
			else
			{
				vis.ButtonColor = Color.Red;
				vis.BackColor = Color.Red;
			}
		}

		private void U32_Click(object sender, EventArgs e)
		{
			VistaColor(U32);
		}

		private void U17_Click(object sender, EventArgs e)
		{
			VistaColor(U17);
		}

		private void U20_Click(object sender, EventArgs e)
		{
			VistaColor(U20);
		}

		private void U23_Click(object sender, EventArgs e)
		{
			VistaColor(U23);
		}

		private void U19_Click(object sender, EventArgs e)
		{
			VistaColor(U19);
		}

		private void U21_Click(object sender, EventArgs e)
		{
			VistaColor(U21);
		}

		private void U18_Click(object sender, EventArgs e)
		{
			VistaColor(U18);
		}

		private void U22_Click(object sender, EventArgs e)
		{
			VistaColor(U22);
		}

		private void U24_Click(object sender, EventArgs e)
		{
			VistaColor(U24);
		}

		private void U30_Click(object sender, EventArgs e)
		{
			VistaColor(U30);
		}

		private void U31_Click(object sender, EventArgs e)
		{
			VistaColor(U31);
		}

		private void U26_Click(object sender, EventArgs e)
		{
			VistaColor(U26);
		}

		private void U25_Click(object sender, EventArgs e)
		{
			VistaColor(U25);
		}

		private void U27_Click(object sender, EventArgs e)
		{
			VistaColor(U27);
		}

		private void U29_Click(object sender, EventArgs e)
		{
			VistaColor(U29);
		}

		private void U28_Click(object sender, EventArgs e)
		{
			VistaColor(U28);
		}

		private void U8_Click(object sender, EventArgs e)
		{
			VistaColor(U8);
		}

		private void U2_Click(object sender, EventArgs e)
		{
			VistaColor(U2);
		}

		private void U3_Click(object sender, EventArgs e)
		{
			VistaColor(U3);
		}

		private void U4_Click(object sender, EventArgs e)
		{
			VistaColor(U4);
		}

		private void U5_Click(object sender, EventArgs e)
		{
			VistaColor(U5);
		}

		private void U6_Click(object sender, EventArgs e)
		{
			VistaColor(U6);
		}

		private void U7_Click(object sender, EventArgs e)
		{
			VistaColor(U7);
		}

		private void U1_Click(object sender, EventArgs e)
		{
			VistaColor(U1);
		}

		private void U16_Click(object sender, EventArgs e)
		{
			VistaColor(U16);
		}

		private void U10_Click(object sender, EventArgs e)
		{
			VistaColor(U10);
		}

		private void U11_Click(object sender, EventArgs e)
		{
			VistaColor(U11);
		}

		private void U12_Click(object sender, EventArgs e)
		{
			VistaColor(U12);
		}

		private void U13_Click(object sender, EventArgs e)
		{
			VistaColor(U13);
		}

		private void U14_Click(object sender, EventArgs e)
		{
			VistaColor(U14);
		}

		private void U15_Click(object sender, EventArgs e)
		{
			VistaColor(U15);
		}

		private void U9_Click(object sender, EventArgs e)
		{
			VistaColor(U9);
		}

		private void button1_Click(object sender, EventArgs e)
		{
			PatientPayAccount patientPayAccount = new PatientPayAccount(Convert.ToInt32(PatientComboBox.SelectedValue));
			patientPayAccount.ShowDialog();
		}

		private void PatientComboBox_SelectedValueChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2(string.Concat("select company from PatientData where id='", PatientComboBox.SelectedValue, "'"));
				DataTable dataTable2 = codes.Search2(string.Concat("select Price from CompanyService where CompanyID='", dataTable.Rows[0][0].ToString(), "' and Service='", commentTextBox.SelectedValue, "'"));
				if (dataTable2.Rows.Count > 0)
				{
					PricetextBox.Text = dataTable2.Rows[0][0].ToString();
					DataTable dataTable3 = codes.Search2("select ChangeServicePrice from users where userName ='" + Main.usernames + "' and userPassward ='" + Main.passward + "'");
					PricetextBox.Enabled = Convert.ToBoolean(dataTable3.Rows[0][0].ToString());
				}
				else
				{
					PricetextBox.Text = "0";
					PricetextBox.Enabled = true;
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable4 = codes.Search2(string.Concat("select top 1 * from detect where ClientiD= '", PatientComboBox.SelectedValue, "' order by ID desc"));
				if (dataTable4.Rows.Count > 0)
				{
					numericUpDown1.Value = Convert.ToDecimal(dataTable4.Rows[0][2].ToString());
					numericUpDown2.Value = Convert.ToDecimal(dataTable4.Rows[0][3].ToString());
					numericUpDown3.Value = Convert.ToDecimal(dataTable4.Rows[0][4].ToString());
					numericUpDown4.Value = Convert.ToDecimal(dataTable4.Rows[0][5].ToString());
					numericUpDown5.Value = Convert.ToDecimal(dataTable4.Rows[0][6].ToString());
					numericUpDown6.Value = Convert.ToDecimal(dataTable4.Rows[0][7].ToString());
					numericUpDown7.Value = Convert.ToDecimal(dataTable4.Rows[0][8].ToString());
					numericUpDown8.Value = Convert.ToDecimal(dataTable4.Rows[0][9].ToString());
					numericUpDown9.Value = Convert.ToDecimal(dataTable4.Rows[0][10].ToString());
					numericUpDown10.Value = Convert.ToDecimal(dataTable4.Rows[0][11].ToString());
					numericUpDown11.Value = Convert.ToDecimal(dataTable4.Rows[0][12].ToString());
					numericUpDown12.Value = Convert.ToDecimal(dataTable4.Rows[0][13].ToString());
					numericUpDown13.Value = Convert.ToDecimal(dataTable4.Rows[0][15].ToString());
					numericUpDown14.Value = Convert.ToDecimal(dataTable4.Rows[0][16].ToString());
				}
				else
				{
					numericUpDown1.Value = 0m;
					numericUpDown2.Value = 0m;
					numericUpDown3.Value = 0m;
					numericUpDown4.Value = 0m;
					numericUpDown5.Value = 0m;
					numericUpDown6.Value = 0m;
					numericUpDown7.Value = 0m;
					numericUpDown8.Value = 0m;
					numericUpDown9.Value = 0m;
					numericUpDown10.Value = 0m;
					numericUpDown11.Value = 0m;
					numericUpDown12.Value = 0m;
					numericUpDown13.Value = 0m;
					numericUpDown14.Value = 0m;
				}
			}
			catch
			{
			}
		}

		private void PatientComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			Accepted();
			try
			{
				DataTable dataTable = codes.Search2(string.Concat("SELECT Company.Name,PatientData.DoctoreName FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID WHERE (PatientData.ID ='", PatientComboBox.SelectedValue, "')"));
				textBox1.Text = dataTable.Rows[0][0].ToString();
			}
			catch
			{
			}
		}

		private void Accepted()
		{
			try
			{
				DataTable dataTable = codes.Search2(string.Concat(" select Accepted,DoctorID from Appointments where PatuentID='", PatientComboBox.SelectedValue, "' order by ID desc "));
				checkBox1.Checked = Convert.ToBoolean(dataTable.Rows[0][0].ToString());
				doctorcomboBox.SelectedValue = dataTable.Rows[0][1].ToString();
			}
			catch
			{
				checkBox1.Checked = false;
			}
		}

		private void checkBox2_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (!checkBox2.Checked)
				{
					DataTable dataTable = codes.Search2("SELECT DISTINCT PatientData.ID, PatientData.PName\r\nFROM            Appointments INNER JOIN\r\n                         PatientData ON Appointments.PatuentID = PatientData.ID");
					PatientComboBox.DataSource = dataTable;
					PatientComboBox.ValueMember = dataTable.Columns[0].ToString();
					PatientComboBox.DisplayMember = dataTable.Columns[1].ToString();
				}
			}
			catch
			{
			}
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBox2.Checked)
				{
					DataTable dataTable = codes.Search2(string.Concat("SELECT DISTINCT PatientData.ID, PatientData.PName\r\nFROM            Appointments INNER JOIN\r\n                         PatientData ON Appointments.PatuentID = PatientData.ID where PatientData.company='", comboBox1.SelectedValue, "'"));
					PatientComboBox.DataSource = dataTable;
					PatientComboBox.ValueMember = dataTable.Columns[0].ToString();
					PatientComboBox.DisplayMember = dataTable.Columns[1].ToString();
				}
			}
			catch
			{
			}
		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBox2.Checked)
				{
					DataTable dataTable = codes.Search2("SELECT DISTINCT PatientData.ID, PatientData.PName\r\nFROM            Appointments INNER JOIN\r\n                         PatientData ON Appointments.PatuentID = PatientData.ID where PatientData.Mob like '%" + textBox2.Text + "%'");
					PatientComboBox.DataSource = dataTable;
					PatientComboBox.ValueMember = dataTable.Columns[0].ToString();
					PatientComboBox.DisplayMember = dataTable.Columns[1].ToString();
				}
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			FrmPatientServices frmPatientServices = new FrmPatientServices();
			frmPatientServices.Show();
		}

		private void commentTextBox_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

		private void button5_Click(object sender, EventArgs e)
		{
			PrescriptionFrm prescriptionFrm = new PrescriptionFrm(Convert.ToInt32(PatientComboBox.SelectedValue));
			prescriptionFrm.Show();
		}

		private void button6_Click(object sender, EventArgs e)
		{
			CommentFrm commentFrm = new CommentFrm(Convert.ToInt32(PatientComboBox.SelectedValue));
			commentFrm.Show();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			FrmImage frmImage = new FrmImage(Convert.ToInt32(PatientComboBox.SelectedValue));
			frmImage.Show();
		}
	}
}
