using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Properties;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmSearchMedicine : ReportBaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox2;

		private CrystalReportViewer crystalReportViewer1;

		private GroupBox groupBox1;

		private DateTimePicker date2;

		private DateTimePicker date1;

		private Button ViewRptBtn;

		private Label label3;

		private ComboBox MedicinecomboBox;

		private Label label2;

		private Label label1;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand3;

		private SqlConnection sqlConnection3;

		private SqlCommand sqlInsertCommand3;

		private SqlCommand sqlUpdateCommand3;

		private SqlCommand sqlDeleteCommand3;

		private SqlDataAdapter sqlDataAdapter3;

		private ClassDataBase dc;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GUI gui = new GUI();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmSearchMedicine));
			groupBox2 = new System.Windows.Forms.GroupBox();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			groupBox1 = new System.Windows.Forms.GroupBox();
			date2 = new System.Windows.Forms.DateTimePicker();
			date1 = new System.Windows.Forms.DateTimePicker();
			ViewRptBtn = new System.Windows.Forms.Button();
			label3 = new System.Windows.Forms.Label();
			MedicinecomboBox = new System.Windows.Forms.ComboBox();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			dataSet11 = new DataSet1();
			sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlConnection3 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
			groupBox2.SuspendLayout();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(date2);
			groupBox1.Controls.Add(date1);
			groupBox1.Controls.Add(ViewRptBtn);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(MedicinecomboBox);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(label1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			date2.AccessibleDescription = null;
			date2.AccessibleName = null;
			resources.ApplyResources(date2, "date2");
			date2.BackgroundImage = null;
			date2.CalendarFont = null;
			date2.Font = null;
			date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date2.Name = "date2";
			date1.AccessibleDescription = null;
			date1.AccessibleName = null;
			resources.ApplyResources(date1, "date1");
			date1.BackgroundImage = null;
			date1.CalendarFont = null;
			date1.Font = null;
			date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date1.Name = "date1";
			ViewRptBtn.AccessibleDescription = null;
			ViewRptBtn.AccessibleName = null;
			resources.ApplyResources(ViewRptBtn, "ViewRptBtn");
			ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
			ViewRptBtn.BackgroundImage = null;
			ViewRptBtn.Name = "ViewRptBtn";
			ViewRptBtn.UseVisualStyleBackColor = false;
			ViewRptBtn.Click += new System.EventHandler(ViewRptBtn_Click);
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			MedicinecomboBox.AccessibleDescription = null;
			MedicinecomboBox.AccessibleName = null;
			resources.ApplyResources(MedicinecomboBox, "MedicinecomboBox");
			MedicinecomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			MedicinecomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			MedicinecomboBox.BackgroundImage = null;
			MedicinecomboBox.Font = null;
			MedicinecomboBox.FormattingEnabled = true;
			MedicinecomboBox.Name = "MedicinecomboBox";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlSelectCommand3.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand3.Connection = sqlConnection3;
			sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True";
			sqlConnection3.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand3.CommandText = resources.GetString("sqlInsertCommand3.CommandText");
			sqlInsertCommand3.Connection = sqlConnection3;
			sqlInsertCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo")
			});
			sqlUpdateCommand3.CommandText = resources.GetString("sqlUpdateCommand3.CommandText");
			sqlUpdateCommand3.Connection = sqlConnection3;
			sqlUpdateCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand3.CommandText = resources.GetString("sqlDeleteCommand3.CommandText");
			sqlDeleteCommand3.Connection = sqlConnection3;
			sqlDeleteCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DentalName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter3.DeleteCommand = sqlDeleteCommand3;
			sqlDataAdapter3.InsertCommand = sqlInsertCommand3;
			sqlDataAdapter3.SelectCommand = sqlSelectCommand3;
			sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[8]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo")
				})
			});
			sqlDataAdapter3.UpdateCommand = sqlUpdateCommand3;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox2);
			Font = null;
			base.Name = "FrmSearchMedicine";
			base.Load += new System.EventHandler(FrmSearchMedicine_Load);
			groupBox2.ResumeLayout(false);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}

		public FrmSearchMedicine()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		private void FrmSearchMedicine_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select Id,MedecineName from Medicine");
				DataRow dataRow = dataTable.NewRow();
				if (Settings.Default.Language == "en-GB")
				{
					dataRow["MedecineName"] = "All Medicines";
				}
				else
				{
					dataRow["MedecineName"] = "كل الأدوية";
				}
				dataTable.Rows.InsertAt(dataRow, 0);
				MedicinecomboBox.DataSource = dataTable;
				MedicinecomboBox.ValueMember = "Id";
				MedicinecomboBox.DisplayMember = "MedecineName";
			}
			catch
			{
			}
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			try
			{
				dataSet11.Clear();
				DataTable dataTable = new DataTable();
				dataTable = ((MedicinecomboBox.SelectedIndex != 0) ? dc.GetTableText(string.Concat("SELECT dbo.Medicine.MedecineName, COUNT(dbo.Prescription.MedicineId) AS num FROM dbo.Medicine INNER JOIN dbo.Prescription ON dbo.Medicine.Id = dbo.Prescription.MedicineId where dbo.Prescription.MedicineId = '", MedicinecomboBox.SelectedValue, "' and Date Between'", date1.Value.ToString("MM/dd/yyyy"), "'and'", date2.Value.ToString("MM/dd/yyyy"), "'GROUP BY dbo.Prescription.MedicineId, dbo.Medicine.MedecineName")) : dc.GetTableText("SELECT dbo.Medicine.MedecineName, COUNT(dbo.Prescription.MedicineId) AS num FROM dbo.Medicine INNER JOIN dbo.Prescription ON dbo.Medicine.Id = dbo.Prescription.MedicineId  where dbo.Prescription.Date Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "' GROUP BY dbo.Prescription.MedicineId, dbo.Medicine.MedecineName"));
				if (dataTable.Rows.Count > 0)
				{
					sqlConnection3.ConnectionString = dc.ConnectionStr;
					sqlDataAdapter3.Fill(dataSet11);
					for (int i = 0; i < dataTable.Rows.Count; i++)
					{
						((DataTable)(object)dataSet11.CountMedicine).Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString());
					}
					((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value.ToString("MM/dd/yyyy"), date2.Value.ToString("MM/dd/yyyy"));
					RptFrmSearchMedicine rptFrmSearchMedicine = new RptFrmSearchMedicine();
					rptFrmSearchMedicine.SetDataSource(dataSet11);
					crystalReportViewer1.ReportSource = rptFrmSearchMedicine;
				}
				else
				{
					crystalReportViewer1.ReportSource = null;
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("No Data");
					}
					else
					{
						MessageBox.Show("لا يوجد بيانات في هذه الفترة");
					}
				}
			}
			catch
			{
			}
		}
	}
}
