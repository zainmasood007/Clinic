using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class UseServiceRptFrm : ReportBaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private Button SearchBtn;

		private Panel panel1;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private Label label3;

		private ComboBox comboBox1;

		private Label label2;

		private Label label1;

		private ComboBox comboBox2;

		private Label label4;

		private TextBox textBox1;

		private DataGridView dataGridView1;

		private Button button1;

		private DataGridViewTextBoxColumn TableID;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Column2;

		private DataGridViewTextBoxColumn Idpatient;

		private DataGridViewTextBoxColumn Column3;

		private DataGridViewTextBoxColumn Column4;

		private DataGridViewTextBoxColumn CategoryID;

		private DataGridViewTextBoxColumn ServiceID;

		private DataGridViewTextBoxColumn Column5;

		private DataGridViewTextBoxColumn Column6;

		private DataGridViewTextBoxColumn Column8;

		private DataGridViewCheckBoxColumn Connect;

		private DataGridViewTextBoxColumn Column9;

		private DataGridViewTextBoxColumn Column7;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private ClassDataBase dc = new ClassDataBase(".\\sqlExpress");

		private string sqlCommand = "";

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.UseServiceRptFrm));
			groupBox1 = new System.Windows.Forms.GroupBox();
			label4 = new System.Windows.Forms.Label();
			textBox1 = new System.Windows.Forms.TextBox();
			label3 = new System.Windows.Forms.Label();
			comboBox1 = new System.Windows.Forms.ComboBox();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			comboBox2 = new System.Windows.Forms.ComboBox();
			SearchBtn = new System.Windows.Forms.Button();
			panel1 = new System.Windows.Forms.Panel();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			TableID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Idpatient = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			CategoryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ServiceID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Connect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataSet11 = new DataSet1();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			button1 = new System.Windows.Forms.Button();
			groupBox1.SuspendLayout();
			panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(textBox1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(comboBox1);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(comboBox2);
			groupBox1.Controls.Add(SearchBtn);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			groupBox1.Enter += new System.EventHandler(groupBox1_Enter);
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Name = "label4";
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Font = null;
			textBox1.Name = "textBox1";
			textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(textBox1_KeyPress);
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Name = "comboBox1";
			comboBox1.SelectedIndexChanged += new System.EventHandler(comboBox1_SelectedIndexChanged);
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			comboBox2.AccessibleDescription = null;
			comboBox2.AccessibleName = null;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.BackgroundImage = null;
			comboBox2.Font = null;
			comboBox2.FormattingEnabled = true;
			comboBox2.Name = "comboBox2";
			SearchBtn.AccessibleDescription = null;
			SearchBtn.AccessibleName = null;
			resources.ApplyResources(SearchBtn, "SearchBtn");
			SearchBtn.BackColor = System.Drawing.Color.Gainsboro;
			SearchBtn.BackgroundImage = null;
			SearchBtn.ForeColor = System.Drawing.Color.Black;
			SearchBtn.Name = "SearchBtn";
			SearchBtn.UseVisualStyleBackColor = false;
			SearchBtn.Click += new System.EventHandler(SearchBtn_Click);
			panel1.AccessibleDescription = null;
			panel1.AccessibleName = null;
			resources.ApplyResources(panel1, "panel1");
			panel1.BackColor = System.Drawing.Color.Transparent;
			panel1.BackgroundImage = null;
			panel1.Controls.Add(dataGridView1);
			panel1.Font = null;
			panel1.Name = "panel1";
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(TableID, Column1, Column2, Idpatient, Column3, Column4, CategoryID, ServiceID, Column5, Column6, Column8, Connect, Column9, Column7);
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.RowHeadersVisible = false;
			dataGridView1.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(dataGridView1_CellValueChanged);
			dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(dataGridView1_CellContentClick);
			resources.ApplyResources(TableID, "TableID");
			TableID.Name = "TableID";
			resources.ApplyResources(Column1, "Column1");
			Column1.Name = "Column1";
			Column1.ReadOnly = true;
			resources.ApplyResources(Column2, "Column2");
			Column2.Name = "Column2";
			Column2.ReadOnly = true;
			resources.ApplyResources(Idpatient, "Idpatient");
			Idpatient.Name = "Idpatient";
			resources.ApplyResources(Column3, "Column3");
			Column3.Name = "Column3";
			Column3.ReadOnly = true;
			resources.ApplyResources(Column4, "Column4");
			Column4.Name = "Column4";
			Column4.ReadOnly = true;
			resources.ApplyResources(CategoryID, "CategoryID");
			CategoryID.Name = "CategoryID";
			resources.ApplyResources(ServiceID, "ServiceID");
			ServiceID.Name = "ServiceID";
			resources.ApplyResources(Column5, "Column5");
			Column5.Name = "Column5";
			Column5.ReadOnly = true;
			resources.ApplyResources(Column6, "Column6");
			Column6.Name = "Column6";
			Column6.ReadOnly = true;
			resources.ApplyResources(Column8, "Column8");
			Column8.Name = "Column8";
			Column8.ReadOnly = true;
			resources.ApplyResources(Connect, "Connect");
			Connect.Name = "Connect";
			resources.ApplyResources(Column9, "Column9");
			Column9.Name = "Column9";
			Column9.ReadOnly = true;
			resources.ApplyResources(Column7, "Column7");
			Column7.Name = "Column7";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlSelectCommand1.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[15]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
				new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
				new System.Data.SqlClient.SqlParameter("@GeneralClinic", System.Data.SqlDbType.Bit, 0, "GeneralClinic")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[37]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
				new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
				new System.Data.SqlClient.SqlParameter("@GeneralClinic", System.Data.SqlDbType.Bit, 0, "GeneralClinic"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_GeneralClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_GeneralClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_GeneralClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_GeneralClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[16]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData"),
					new System.Data.Common.DataColumnMapping("Powred", "Powred"),
					new System.Data.Common.DataColumnMapping("ClinicType", "ClinicType"),
					new System.Data.Common.DataColumnMapping("EyeClinic", "EyeClinic"),
					new System.Data.Common.DataColumnMapping("FemaleClinic", "FemaleClinic"),
					new System.Data.Common.DataColumnMapping("NaturalClinic", "NaturalClinic"),
					new System.Data.Common.DataColumnMapping("EnName", "EnName"),
					new System.Data.Common.DataColumnMapping("GeneralClinic", "GeneralClinic")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.BackgroundImage = null;
			button1.ForeColor = System.Drawing.Color.Black;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(button1);
			base.Controls.Add(panel1);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "UseServiceRptFrm";
			base.Load += new System.EventHandler(OldServicesRptFrm_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}

		public UseServiceRptFrm()
		{
			InitializeComponent();
		}

		private void SearchBtn_Click(object sender, EventArgs e)
		{
			try
			{
				dataGridView1.Rows.Clear();
				DataTable dataTable = new DataTable();
				if (comboBox1.SelectedIndex == -1)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Choose Service Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الخدمة");
					}
					return;
				}
				if (textBox1.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Duration");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل المدة");
					}
					return;
				}
				if (comboBox1.Text == "الكل")
				{
					dataTable = Codes.Search2("SELECT        dbo.PatientAccount.ID, dbo.PatientData.FileNo, dbo.PatientAccount.PatientId, dbo.PatientData.PName, dbo.PatientData.Mob, dbo.CompanyService.CompanyID, dbo.CompanyService.ID AS Expr1, dbo.CompanyService.Service, \r\n                         dbo.PatientAccount.BeanDate\r\nFROM            dbo.Categories INNER JOIN\r\n                         dbo.CompanyService ON dbo.Categories.ID = dbo.CompanyService.CompanyID INNER JOIN\r\n                         dbo.PatientAccount INNER JOIN\r\n                         dbo.PatientData ON dbo.PatientAccount.PatientId = dbo.PatientData.ID ON dbo.CompanyService.Service COLLATE SQL_Latin1_General_CP1_CI_AS = dbo.PatientAccount.Bean\r\n where DATEDIFF(d,BeanDate, GETDATE()) =" + textBox1.Text);
					sqlCommand = "SELECT   PatientAccount .*   FROM            dbo.Categories INNER JOIN\r\n                         dbo.CompanyService ON dbo.Categories.ID = dbo.CompanyService.CompanyID INNER JOIN\r\n                         dbo.PatientAccount INNER JOIN\r\n                         dbo.PatientData ON dbo.PatientAccount.PatientId = dbo.PatientData.ID ON dbo.CompanyService.Service COLLATE SQL_Latin1_General_CP1_CI_AS = dbo.PatientAccount.Bean\r\nwhere DATEDIFF(d,BeanDate, GETDATE()) =" + textBox1.Text;
				}
				else if (comboBox2.Text == "")
				{
					dataTable = Codes.Search2("SELECT   SELECT        dbo.PatientAccount.ID, dbo.PatientData.FileNo, dbo.PatientAccount.PatientId, dbo.PatientData.PName, dbo.PatientData.Mob, dbo.CompanyService.CompanyID, dbo.CompanyService.ID AS Expr1, dbo.CompanyService.Service, \r\n                         dbo.PatientAccount.BeanDate\r\nFROM            dbo.Categories INNER JOIN\r\n                         dbo.CompanyService ON dbo.Categories.ID = dbo.CompanyService.CompanyID INNER JOIN\r\n                         dbo.PatientAccount INNER JOIN\r\n                         dbo.PatientData ON dbo.PatientAccount.PatientId = dbo.PatientData.ID ON dbo.CompanyService.Service COLLATE SQL_Latin1_General_CP1_CI_AS = dbo.PatientAccount.Bean\r\n where DATEDIFF(d,BeanDate, GETDATE()) =" + textBox1.Text + " and Categories.ID='" + comboBox1.SelectedValue.ToString() + "'");
					sqlCommand = "SELECT   PatientAccount .*   FROM            dbo.Categories INNER JOIN\r\n                         dbo.CompanyService ON dbo.Categories.ID = dbo.CompanyService.CompanyID INNER JOIN\r\n                         dbo.PatientAccount INNER JOIN\r\n                         dbo.PatientData ON dbo.PatientAccount.PatientId = dbo.PatientData.ID ON dbo.CompanyService.Service COLLATE SQL_Latin1_General_CP1_CI_AS = dbo.PatientAccount.Bean\r\nwhere DATEDIFF(d,BeanDate, GETDATE()) =" + textBox1.Text + " and Categories.ID='" + comboBox1.SelectedValue.ToString() + "'";
				}
				else
				{
					dataTable = Codes.Search2("SELECT        dbo.PatientAccount.ID, dbo.PatientData.FileNo, dbo.PatientAccount.PatientId, dbo.PatientData.PName, dbo.PatientData.Mob, dbo.CompanyService.CompanyID, dbo.CompanyService.ID AS Expr1, dbo.CompanyService.Service, \r\n                         dbo.PatientAccount.BeanDate\r\nFROM            dbo.Categories INNER JOIN\r\n                         dbo.CompanyService ON dbo.Categories.ID = dbo.CompanyService.CompanyID INNER JOIN\r\n                         dbo.PatientAccount INNER JOIN\r\n                         dbo.PatientData ON dbo.PatientAccount.PatientId = dbo.PatientData.ID ON dbo.CompanyService.Service COLLATE SQL_Latin1_General_CP1_CI_AS = dbo.PatientAccount.Bean\r\n where DATEDIFF(d,BeanDate, GETDATE()) =" + textBox1.Text + " and Categories.ID='" + comboBox1.SelectedValue.ToString() + "' and CompanyService.Service ='" + comboBox2.Text.ToString() + "'");
					sqlCommand = "SELECT   PatientAccount .*   FROM            dbo.Categories INNER JOIN\r\n                         dbo.CompanyService ON dbo.Categories.ID = dbo.CompanyService.CompanyID INNER JOIN\r\n                         dbo.PatientAccount INNER JOIN\r\n                         dbo.PatientData ON dbo.PatientAccount.PatientId = dbo.PatientData.ID ON dbo.CompanyService.Service COLLATE SQL_Latin1_General_CP1_CI_AS = dbo.PatientAccount.Bean\r\nwhere DATEDIFF(d,BeanDate, GETDATE()) =" + textBox1.Text + " and Categories.ID='" + comboBox1.SelectedValue.ToString() + "' and CompanyService.Service ='" + comboBox2.Text.ToString() + "'";
				}
				if (dataTable.Rows.Count > 0)
				{
					for (int i = 0; i < dataTable.Rows.Count; i++)
					{
						DataTable dataTable2 = Codes.Search2("SELECT    ServicesUse.ID,    dbo.ServicesUse.ConnectDate\r\nFROM            dbo.PatientAccount INNER JOIN\r\n                         dbo.ServicesUse ON dbo.PatientAccount.ID = dbo.ServicesUse.PatientAccID where PatientAccount.ID='" + dataTable.Rows[i][0].ToString() + "'");
						if (dataTable2.Rows.Count > 0)
						{
							dataGridView1.Rows.Add(dataTable2.Rows[0][0].ToString(), i + 1, dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString(), dataTable.Rows[i][4].ToString(), dataTable.Rows[i][5].ToString(), dataTable.Rows[i][6].ToString(), dataTable.Rows[i][7].ToString(), dataTable.Rows[i][8].ToString(), textBox1.Text, true, dataTable2.Rows[0][1].ToString(), dataTable.Rows[i][0].ToString());
						}
						else
						{
							dataGridView1.Rows.Add(0, i + 1, dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString(), dataTable.Rows[i][4].ToString(), dataTable.Rows[i][5].ToString(), dataTable.Rows[i][6].ToString(), dataTable.Rows[i][7].ToString(), dataTable.Rows[i][8].ToString(), textBox1.Text, false, "", dataTable.Rows[i][0].ToString());
						}
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("No Data");
				}
				else
				{
					MessageBox.Show("لا يوجد بيانات");
				}
			}
			catch
			{
			}
		}

		private void OldServicesRptFrm_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("select id,name from Categories");
				DataRow dataRow = dataTable.NewRow();
				dataRow["name"] = "الكل";
				dataTable.Rows.InsertAt(dataRow, 0);
				comboBox1.DataSource = dataTable;
				comboBox1.ValueMember = "id";
				comboBox1.DisplayMember = "name";
			}
			catch
			{
			}
		}

		private void groupBox1_Enter(object sender, EventArgs e)
		{
		}

		private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && textBox1.Text.Contains("."))
					{
						e.Handled = true;
					}
				}
				else
				{
					e.Handled = true;
					MessageBox.Show("من فضلك أدخل المدة بالارقام");
				}
			}
			catch
			{
			}
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("select distinct(Service),ID from CompanyService where CompanyID = '" + comboBox1.SelectedValue.ToString() + "' ");
				comboBox2.DataSource = dataTable;
				comboBox2.DisplayMember = dataTable.Columns[0].ToString();
				comboBox2.ValueMember = dataTable.Columns[1].ToString();
				if (comboBox1.Text == "الكل")
				{
					comboBox2.Text = "الكل";
				}
				else if (dataTable.Rows.Count == 0)
				{
					comboBox2.Text = "";
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			dataGridView1.CommitEdit(DataGridViewDataErrorContexts.Commit);
		}

		private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
		{
			try
			{
				if (Convert.ToBoolean(dataGridView1.CurrentRow.Cells["Connect"].Value))
				{
					dataGridView1.CurrentRow.Cells["Column9"].Value = DateTime.Now.ToString("MM/dd/yyyy");
				}
				else if (!Convert.ToBoolean(dataGridView1.CurrentRow.Cells["Connect"].Value))
				{
					dataGridView1.CurrentRow.Cells["Column9"].Value = "";
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				bool flag = false;
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					if (Convert.ToString(dataGridView1.Rows[i].Cells[0].Value) == "0" && Convert.ToBoolean(dataGridView1.Rows[i].Cells["Connect"].Value))
					{
						Codes.Add2(string.Concat("insert into ServicesUse ([PatientID],[CategoryID],[ServiceID],[PatientAccID],[Duration] ,[DoneConnect],[ConnectDate]) VALUES (", dataGridView1.Rows[i].Cells[3].Value.ToString(), ",", dataGridView1.Rows[i].Cells[6].Value.ToString(), ",", dataGridView1.Rows[i].Cells[7].Value.ToString(), ",", dataGridView1.Rows[i].Cells[13].Value.ToString(), ",", dataGridView1.Rows[i].Cells[10].Value.ToString(), ",'true','", Convert.ToDateTime(dataGridView1.Rows[i].Cells[12].Value), "')"));
						flag = true;
					}
				}
				if (flag)
				{
					MessageBox.Show("تم حفظ البيانات بنجاح");
				}
				PatientConnectRPT patientConnectRPT = new PatientConnectRPT(sqlCommand);
				patientConnectRPT.ShowDialog();
				dataGridView1.Rows.Clear();
				comboBox1.Text = "الكل";
				comboBox2.Text = "";
				textBox1.Text = "";
			}
			catch
			{
			}
		}
	}
}
