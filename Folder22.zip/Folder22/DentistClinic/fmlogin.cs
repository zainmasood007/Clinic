using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class fmlogin : BaseForm
	{
		private IContainer components = null;

		private Label label2;

		private TextBox passwardText;

		private Button loginBtn;

		private Label label1;

		private Panel panel1;

		private PictureBox pictureBox2;

		private Button vistaButton1;

		private Label label3;

		private Label label4;

		private ComboBox CmbLanguage;

		private ComboBox userNameText;

		private ClassDataBase dc;

		public static bool Exit = false;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.fmlogin));
			loginBtn = new System.Windows.Forms.Button();
			panel1 = new System.Windows.Forms.Panel();
			label4 = new System.Windows.Forms.Label();
			userNameText = new System.Windows.Forms.ComboBox();
			CmbLanguage = new System.Windows.Forms.ComboBox();
			label3 = new System.Windows.Forms.Label();
			vistaButton1 = new System.Windows.Forms.Button();
			pictureBox2 = new System.Windows.Forms.PictureBox();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			passwardText = new System.Windows.Forms.TextBox();
			panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
			SuspendLayout();
			loginBtn.BackColor = System.Drawing.Color.Transparent;
			loginBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			loginBtn.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
			loginBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
			loginBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
			resources.ApplyResources(loginBtn, "loginBtn");
			loginBtn.ForeColor = System.Drawing.Color.Black;
			loginBtn.Name = "loginBtn";
			loginBtn.UseVisualStyleBackColor = false;
			loginBtn.Click += new System.EventHandler(loginBtn_Click_1);
			panel1.BackColor = System.Drawing.Color.Transparent;
			panel1.BackgroundImage = DentistClinic.Properties.Resources.clinic_login2;
			resources.ApplyResources(panel1, "panel1");
			panel1.Controls.Add(label4);
			panel1.Controls.Add(userNameText);
			panel1.Controls.Add(CmbLanguage);
			panel1.Controls.Add(label3);
			panel1.Controls.Add(vistaButton1);
			panel1.Controls.Add(pictureBox2);
			panel1.Controls.Add(label2);
			panel1.Controls.Add(loginBtn);
			panel1.Controls.Add(label1);
			panel1.Controls.Add(passwardText);
			panel1.Name = "panel1";
			panel1.Paint += new System.Windows.Forms.PaintEventHandler(panel1_Paint);
			label4.BackColor = System.Drawing.Color.Transparent;
			resources.ApplyResources(label4, "label4");
			label4.ForeColor = System.Drawing.Color.Black;
			label4.Name = "label4";
			userNameText.FormattingEnabled = true;
			resources.ApplyResources(userNameText, "userNameText");
			userNameText.Name = "userNameText";
			CmbLanguage.FormattingEnabled = true;
			resources.ApplyResources(CmbLanguage, "CmbLanguage");
			CmbLanguage.Name = "CmbLanguage";
			CmbLanguage.SelectedIndexChanged += new System.EventHandler(CmbLanguage_SelectedIndexChanged);
			resources.ApplyResources(label3, "label3");
			label3.BackColor = System.Drawing.Color.Transparent;
			label3.Cursor = System.Windows.Forms.Cursors.Hand;
			label3.ForeColor = System.Drawing.Color.DarkGray;
			label3.Name = "label3";
			label3.MouseLeave += new System.EventHandler(label3_MouseLeave);
			label3.Click += new System.EventHandler(label3_Click);
			label3.MouseHover += new System.EventHandler(label3_MouseHover);
			vistaButton1.BackColor = System.Drawing.Color.Transparent;
			vistaButton1.Cursor = System.Windows.Forms.Cursors.Hand;
			resources.ApplyResources(vistaButton1, "vistaButton1");
			vistaButton1.ForeColor = System.Drawing.Color.Red;
			vistaButton1.Name = "vistaButton1";
			vistaButton1.UseVisualStyleBackColor = false;
			vistaButton1.Click += new System.EventHandler(vistaButton1_Click);
			pictureBox2.BackColor = System.Drawing.Color.Transparent;
			pictureBox2.BackgroundImage = DentistClinic.Properties.Resources.signup_2;
			resources.ApplyResources(pictureBox2, "pictureBox2");
			pictureBox2.Name = "pictureBox2";
			pictureBox2.TabStop = false;
			resources.ApplyResources(label2, "label2");
			label2.BackColor = System.Drawing.Color.Transparent;
			label2.ForeColor = System.Drawing.Color.Black;
			label2.Name = "label2";
			resources.ApplyResources(label1, "label1");
			label1.BackColor = System.Drawing.Color.Transparent;
			label1.ForeColor = System.Drawing.Color.Black;
			label1.Name = "label1";
			resources.ApplyResources(passwardText, "passwardText");
			passwardText.Name = "passwardText";
			base.AcceptButton = loginBtn;
			resources.ApplyResources(this, "$this");
			BackColor = System.Drawing.Color.White;
			base.Controls.Add(panel1);
			DoubleBuffered = true;
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "fmlogin";
			base.TransparencyKey = System.Drawing.Color.Maroon;
			base.Load += new System.EventHandler(fmlogin_Load);
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
			ResumeLayout(false);
		}

		public fmlogin()
		{
			try
			{
				InitializeComponent();
				dc = new ClassDataBase(".\\sqlExpress");
			}
			catch (Exception ex)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Error");
				}
				else
				{
					MessageBox.Show(ex.Message, "حدث خطأ");
				}
			}
		}

		private void loginBtn_Click_1(object sender, EventArgs e)
		{
			DataTable tableText = dc.GetTableText("select * from users where userName ='" + userNameText.Text + "'and userPassward ='" + passwardText.Text + "'");
			if (tableText.Rows.Count > 0)
			{
				Main.usernames = userNameText.Text;
				Main.passward = passwardText.Text;
				base.Visible = false;
				UsersClass.EmpId = Convert.ToInt32(tableText.Rows[0][1].ToString());
				UsersClass.ChangeServicePrice = Convert.ToBoolean(tableText.Rows[0]["ChangeServicePrice"].ToString());
				try
				{
					DataTable tableText2 = dc.GetTableText("select * from Properties");
					UsersClass.AutoEsal = Convert.ToBoolean(tableText2.Rows[0]["AutoEsal"]);
					UsersClass.BillPrinter = tableText2.Rows[0]["BillPrinter"].ToString();
					UsersClass.EsalPrinterName = tableText2.Rows[0]["EsalPrinterName"].ToString();
				}
				catch
				{
				}
				Main main = new Main();
				main.ShowDialog();
				Close();
			}
			else
			{
				MessageBox.Show(" Invalid User Name Or Passward");
			}
		}

		private void vistaButton1_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void label3_MouseHover(object sender, EventArgs e)
		{
			label3.ForeColor = Color.White;
		}

		private void label3_MouseLeave(object sender, EventArgs e)
		{
			label3.ForeColor = Color.DarkGray;
		}

		private void label3_Click(object sender, EventArgs e)
		{
			FrmSplash frmSplash = new FrmSplash();
			frmSplash.ShowDialog();
		}

		private void fmlogin_Load(object sender, EventArgs e)
		{
			_ = Settings.Default.Language;
			DataTable dataTable = new DataTable("Language");
			try
			{
				DataColumn[] columns = new DataColumn[2]
				{
					new DataColumn("Value", typeof(string)),
					new DataColumn("Display", typeof(string))
				};
				dataTable.Columns.AddRange(columns);
				DataRow dataRow = dataTable.NewRow();
				if (Settings.Default.Language == "ar-EG")
				{
					DataRowCollection rows = dataTable.Rows;
					object[] array = new object[2];
					object obj2 = (array[0] = (dataRow["Value"] = "ar-EG"));
					obj2 = (array[1] = (dataRow["Display"] = "عربى (Arabic)"));
					rows.Add(array);
					DataRowCollection rows2 = dataTable.Rows;
					array = new object[2];
					obj2 = (array[0] = (dataRow["Value"] = "en-GB"));
					obj2 = (array[1] = (dataRow["Display"] = "انجليزى (English)"));
					rows2.Add(array);
				}
				else
				{
					DataRowCollection rows3 = dataTable.Rows;
					object[] array = new object[2];
					object obj2 = (array[0] = (dataRow["Value"] = "ar-EG"));
					obj2 = (array[1] = (dataRow["Display"] = "Arabic (عربى)"));
					rows3.Add(array);
					DataRowCollection rows4 = dataTable.Rows;
					array = new object[2];
					obj2 = (array[0] = (dataRow["Value"] = "en-GB"));
					obj2 = (array[1] = (dataRow["Display"] = "English (انجليزى)"));
					rows4.Add(array);
				}
				CmbLanguage.DataSource = dataTable;
				CmbLanguage.DisplayMember = "Display";
				CmbLanguage.ValueMember = "Value";
				if (Settings.Default.Language == "en-GB")
				{
					CmbLanguage.SelectedIndex = 1;
				}
				else
				{
					CmbLanguage.SelectedIndex = 0;
				}
			}
			catch (Exception)
			{
			}
			try
			{
				DataTable tableText = dc.GetTableText("select userName from users");
				userNameText.DataSource = tableText;
				userNameText.DisplayMember = "userName";
			}
			catch
			{
			}
		}

		private void ChangeLanguage(string lang)
		{
			foreach (Control control in panel1.Controls)
			{
				ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(fmlogin));
				componentResourceManager.ApplyResources(control, control.Name, new CultureInfo(lang));
			}
		}

		private void CmbLanguage_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				string text = null;
				if (CmbLanguage.SelectedValue.ToString() == "ar-EG")
				{
					text = "ar-EG";
					goto IL_004f;
				}
				if (CmbLanguage.SelectedValue.ToString() == "en-GB")
				{
					text = "en-GB";
					goto IL_004f;
				}
				goto end_IL_0001;
				IL_004f:
				Settings.Default.Language = text;
				Settings.Default.Save();
				Thread.Sleep(500);
				CultureInfo currentUICulture = CultureInfo.CreateSpecificCulture(text);
				Thread.CurrentThread.CurrentUICulture = currentUICulture;
				ChangeLanguage(text);
				end_IL_0001:;
			}
			catch (Exception)
			{
			}
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
		}
	}
}
