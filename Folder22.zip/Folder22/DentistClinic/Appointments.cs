using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class Appointments : BaseForm
	{
		private GeneralMethods MethodsClass = new GeneralMethods();

		private int appid;

		private int AppointementID = 0;

		private int PatientID = 0;

		private bool clinic;

		private decimal Total;

		private string stockId;

		private string CompanyPrice;

		private string companyId;

		public static bool AddAppointment = true;

		private ClassDataBase dc;

		public static decimal TotalPrice;

		public static DataTable dtPackDate = new DataTable();

		private GUI gui = new GUI();

		private bool flag;

		private double oldpric = 0.0;

		private dataClass codes;

		private string Patient = "";

		private bool b = true;

		private IContainer components = null;

		private GroupBox groupBox4;

		private TextBox priceTextBox;

		private ComboBox PatientComboBox;

		private TextBox ChairTextBox;

		private GroupBox groupBox5;

		private Button DeletBtn;

		private Button Searchbtn;

		private Button EditBtn;

		private Button saveBtn;

		private ComboBox doctorcomboBox;

		private TextBox apptextBox;

		private DateTimePicker regdateTimePicker1;

		private DateTimePicker recalldateTimePicker2;

		private Label label1;

		private GroupBox groupBox1;

		private DataGridView dataGridView1;

		private GroupBox groupBox2;

		private Label label3;

		private DataSet1 dataSet11;

		private ComboBox StatusCom;

		private Panel StatusPanel;

		private Button button1;

		private TextBox textBox1;

		private GroupBox groupBox3;

		private TextBox textBox2;

		private ComboBox comboBox1;

		private RadioButton radioButton2;

		private RadioButton radioButton1;

		private CheckBox checkBox1;

		private CheckBox checkBox2;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private GroupBox groupBox6;

		private Label label6;

		private ComboBox comboBox2;

		private CheckBox checkBox3;

		private TextBox textBox3;

		private Label label9;

		private Button button2;

		private GroupBox groupBox7;

		private Button button3;

		private ComboBox commentTextBox;

		private GroupBox groupBox8;

		private DataGridView dataGridView2;

		private TextBox textBox4;

		private TextBox textBox5;

		private Label label69;

		private ComboBox comboBox7;

		private ComboBox comboCategory;

		private Button button4;

		private RadioButton radioButton3;

		private Panel panel1;

		private RadioButton radioButton4;

		private Button button5;

		private DateTimePicker FromTextBox;

		private DateTimePicker TOTextBox;

		private MaskedTextBox maskedTextBox1;

		private MaskedTextBox maskedTextBox2;

		private Button button6;

		private TextBox txtUserName;

		private Panel PaidPanel;

		private TextBox EsalNoTxt;

		private Label label45;

		private TextBox AfterDariba;

		private Label label13;

		private TextBox Dariba;

		private Label label15;

		private Label label16;

		private TextBox textBox6;

		private Label label17;

		private TextBox textBox7;

		private DateTimePicker appdateTimePicker1;

		private Label label19;

		private Label label18;

		private Label label105;

		private TextBox textBoxDiscount;

		private TextBox textBox8;

		private Label label14;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Column2;

		private DataGridViewTextBoxColumn CompanyCost;

		private DataGridViewTextBoxColumn Column3;

		private DataGridViewTextBoxColumn Column4;

		private Label label20;

		private Button button7;

		private GroupBox searchGrop;

		private Button button10;

		private ListBox listBox1;

		private TextBox textBox9;

		private Label label21;

		private RadioButton radioButton5;

		private TextBox textBox10;

		private TextBox Rased;

		private RadioButton PayNaqdy;

		private RadioButton PayBefore;

		private SqlConnection sqlConnection2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlCommand2;
		private Label label10;
		private Label label12;
		private Label label11;
		private Label label;
		private Label label2;
		private Label label4;
		private Label label5;
		private Label label7;
		private Label label8;
		private SqlCommand sqlCommand3;

		public Appointments()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
		}

		public Appointments(string patient)
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
			Patient = patient;
		}

		public Appointments(int patientID)
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
			PatientID = patientID;
		}

		public Appointments(decimal appointementID)
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
			AppointementID = Convert.ToInt32(appointementID);
		}

		private void AppointCount()
		{
			DataTable dataTable = codes.Search2(string.Concat("select AppointCount, BacksCount from Empdata where ID='", doctorcomboBox.SelectedValue, "'"));
			int num = Convert.ToInt32(dataTable.Rows[0][0].ToString());
			int num2 = Convert.ToInt32(dataTable.Rows[0][1].ToString());
			DataTable dataTable2 = codes.Search2(string.Concat("select count(ID) from Appointments where DoctorID='", doctorcomboBox.SelectedValue, "' and detectDate='", appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "'"));
			int num3 = Convert.ToInt32(dataTable2.Rows[0][0].ToString());
			if (num3 < num)
			{
				DataTable dataTable3 = codes.Search2(string.Concat("select count(ID) from Appointments where DoctorID='", doctorcomboBox.SelectedValue, "' and packDate='", recalldateTimePicker2.Value.ToString("MM/dd/yyyy"), "'"));
				int num4 = Convert.ToInt32(dataTable3.Rows[0][0].ToString());
				if (num4 >= num2)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Doctor Backs reached the maximum limit");
					}
					else
					{
						MessageBox.Show("عدد حالات اعادة الكشف لهذا الطبيب وصلت الحد الأقصى");
					}
					b = false;
				}
				else
				{
					b = true;
				}
			}
			else
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Doctor Appointments reached the maximum limit");
				}
				else
				{
					MessageBox.Show("عدد الكشوفات لهذا الطبيب وصلت الحد الأقصى");
				}
				b = false;
			}
		}

		private void Appointments_Load(object sender, EventArgs e)
		{
			decimal num = 0m;
			decimal num2 = 0m;
			string text = "";
			try
			{
				if (Convert.ToBoolean(codes.Search2("select HideService from users where userId='" + Main.userId + "'").Rows[0][0].ToString()))
				{
					groupBox7.Visible = false;
				}
			}
			catch
			{
			}
			try
			{
				if (Convert.ToBoolean(codes.Search2("select AvoidPay1 from Properties").Rows[0][0].ToString()))
				{
					checkBox3.Enabled = false;
				}
			}
			catch
			{
			}
			try
			{
				flag = true;
				if (UsersClass.AutoEsal)
				{
					EsalNoTxt.Text = codes.Search2("select isnull(max(Code)+1,1) from AppointEsal").Rows[0][0].ToString();
					EsalNoTxt.Enabled = false;
				}
				else
				{
					EsalNoTxt.Text = "";
					EsalNoTxt.Enabled = true;
				}
			}
			catch
			{
			}
			try
			{
				txtUserName.Text = Main.usernames;
			}
			catch
			{
			}
			try
			{
				dtPackDate.Columns.Add("DatePack", typeof(DateTime));
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select AppointFrom from Properties");
				string text2 = "";
				text2 = ((Convert.ToDateTime(dataTable.Rows[0][0]).Hour <= 12) ? Convert.ToDateTime(dataTable.Rows[0][0]).Hour.ToString() : (Convert.ToDateTime(dataTable.Rows[0][0]).Hour - 12).ToString());
				if (Convert.ToInt32(text2) < 10)
				{
					text2 = "0" + text2;
				}
				maskedTextBox1.Text = text2 + ":00";
				FromTextBox.Text = text2 + ":00";
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = codes.Search2("select PaidState,AutoDetect from Properties");
				if (Convert.ToBoolean(dataTable2.Rows[0][1].ToString()))
				{
					panel1.Visible = false;
				}
				else
				{
					panel1.Visible = true;
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable3 = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				comboBox7.DataSource = null;
				comboBox7.DataSource = dataTable3;
				comboBox7.DisplayMember = dataTable3.Columns[1].ToString();
				comboBox7.ValueMember = dataTable3.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable4 = codes.Search2("SELECT distinct dbo.Categories.ID, dbo.Categories.Name\r\nFROM         dbo.CompanyService INNER JOIN\r\n                      dbo.Categories ON dbo.CompanyService.CompanyID = dbo.Categories.ID");
				comboCategory.ValueMember = dataTable4.Columns[0].ToString();
				comboCategory.DisplayMember = dataTable4.Columns[1].ToString();
				comboCategory.DataSource = dataTable4;
			}
			catch
			{
			}
			try
			{
				DataTable dataTable5 = codes.Search2("select company from PatientData where id='" + PatientComboBox.SelectedValue.ToString() + "'");
				DataTable dataTable6 = codes.Search2("select Price from CompanyService where CompanyID='" + dataTable5.Rows[0][0].ToString() + "' and Service='" + commentTextBox.Text + "'");
				if (dataTable6.Rows.Count > 0)
				{
					textBox4.Text = dataTable6.Rows[0][0].ToString();
					DataTable dataTable2 = codes.Search2("select ChangeServicePrice from users where userName ='" + Main.usernames + "' and userPassward ='" + Main.passward + "'");
					textBox4.Enabled = Convert.ToBoolean(dataTable2.Rows[0][0].ToString());
				}
				else
				{
					textBox4.Text = "0";
					textBox4.Enabled = true;
				}
			}
			catch
			{
			}
			try
			{
				loaddata();
				StatusCom.SelectedIndex = 0;
				comboBox2.SelectedIndex = 0;
			}
			catch
			{
			}
			try
			{
				DataTable dataTable6 = codes.Search2("select * from Company");
				comboBox1.DataSource = dataTable6;
				comboBox1.ValueMember = dataTable6.Columns[0].ToString();
				comboBox1.DisplayMember = dataTable6.Columns[1].ToString();
			}
			catch
			{
			}
			if (Patient == "" && PatientID == 0)
			{
				textBox1.Text = "";
				doctorcomboBox.Text = "";
			}
			else if (PatientID == 0)
			{
				PatientComboBox.Text = Patient;
			}
			else
			{
				PatientComboBox.SelectedValue = PatientID;
			}
			try
			{
				priceTextBox.Text = "0";
				DataTable dataTable6 = codes.Search2(string.Concat("SELECT Company.Name,PatientData.Accept,DoctoreName FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID WHERE (PatientData.ID ='", PatientComboBox.SelectedValue, "')"));
				textBox1.Text = dataTable6.Rows[0][0].ToString();
				try
				{
					groupBox6.Visible = Convert.ToBoolean(dataTable6.Rows[0][1].ToString());
				}
				catch
				{
					groupBox6.Visible = false;
				}
				try
				{
					codes.Search2("select id from Empdata where name='" + dataTable6.Rows[0][2].ToString() + "' and Designation='Doctor'");
				}
				catch
				{
				}
				if (radioButton3.Checked)
				{
					DataTable dataTable7 = codes.Search2("select ServiceName from Properties");
					text = dataTable7.Rows[0][0].ToString();
				}
				else
				{
					DataTable dataTable7 = codes.Search2("select ServiceDetect from Properties");
					text = dataTable7.Rows[0][0].ToString();
				}
				DataTable dataTable8 = codes.Search2("SELECT dbo.CompanyService.Price , dbo.CompanyService.Dariba FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + textBox1.Text + "' and Service = '" + text + "' ");
				if (dataTable8.Rows.Count != 0)
				{
					priceTextBox.Text = dataTable8.Rows[0][0].ToString();
					textBox6.Text = dataTable8.Rows[0][1].ToString();
					num = Math.Round(Convert.ToDecimal(priceTextBox.Text) + Convert.ToDecimal(priceTextBox.Text) * Convert.ToDecimal(textBox6.Text) / 100m, 2);
				}
				else
				{
					priceTextBox.Text = "0";
				}
				try
				{
					DataTable dataTable9 = codes.Search2("select dbo.CompanyService.DiscountNesba,dbo.CompanyService.DiscountValue FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + textBox1.Text + "' and Service = '" + text + "' ");
					if (dataTable9.Rows.Count != 0)
					{
						if (Convert.ToDecimal(dataTable9.Rows[0][0].ToString()) != 0m)
						{
							num2 = Math.Round(num - num * Convert.ToDecimal(dataTable9.Rows[0][0].ToString()) / 100m);
							if (Settings.Default.Language == "en-GB")
							{
								label105.Text = "Discount Per";
							}
							else
							{
								label105.Text = "نسبة الخصم";
							}
							textBoxDiscount.Text = dataTable9.Rows[0][0].ToString();
							textBox7.Text = num2.ToString();
						}
						else if (Convert.ToDecimal(dataTable9.Rows[0][1].ToString()) != 0m)
						{
							num2 = Math.Round(num - Convert.ToDecimal(dataTable9.Rows[0][1].ToString()));
							if (Settings.Default.Language == "en-GB")
							{
								label105.Text = "Discount Value";
							}
							else
							{
								label105.Text = "قيمة الخصم";
							}
							textBoxDiscount.Text = dataTable9.Rows[0][1].ToString();
							textBox7.Text = num2.ToString();
						}
						else
						{
							if (Settings.Default.Language == "en-GB")
							{
								label105.Text = "Discount Value";
							}
							else
							{
								label105.Text = "قيمة الخصم";
							}
							textBoxDiscount.Text = "0";
							textBox7.Text = num.ToString();
						}
					}
					else
					{
						if (Settings.Default.Language == "en-GB")
						{
							label105.Text = "Discount Value";
						}
						else
						{
							label105.Text = "قيمة الخصم";
						}
						textBoxDiscount.Text = "0";
						textBox7.Text = num.ToString();
					}
				}
				catch
				{
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable10 = codes.Search2("select * from users where userName = '" + Main.usernames + "'");
				button2.Visible = Convert.ToBoolean(dataTable10.Rows[0]["Company"].ToString());
				button6.Visible = Convert.ToBoolean(dataTable10.Rows[0]["SurgeryDate"].ToString());
			}
			catch
			{
			}
			try
			{
				DataTable dataTable11 = codes.Search2("select ServiceName,ServiceDetect from Properties");
				radioButton3.Text = dataTable11.Rows[0][0].ToString();
				radioButton4.Text = dataTable11.Rows[0][1].ToString();
			}
			catch
			{
			}
			priceTextBox.Enabled = UsersClass.ChangeServicePrice;
			textBox4.Enabled = UsersClass.ChangeServicePrice;
			PatientComboBox_SelectedIndexChanged(sender, e);
			flag = false;
			priceTextBox_TextChanged(sender, e);
			if (AppointementID == 0)
			{
				return;
			}
			try
			{
				DataTable dt = codes.Search2("SELECT     Appointments.ID , Appointments.AppointNum AS [رقم الحجز], PatientData.PName AS [اسم المريض], Empdata.Name AS [اسم الطبيب], \r\n                      Appointments.detectDate AS [تاريخ الحجز], Appointments.detectStartTime AS [من], Appointments.detectEndTime AS [الى], Appointments.packDate AS [تاريخ إعادة الكشف], \r\n                      Appointments.ExpDate AS [تاريخ انتهاء الحجز], Appointments.ChairNum AS [رقم الكرسى], Appointments.Price AS [المبلغ],Appointments.Status AS [الحالة],Appointments.Accepted AS [تم الموافقة],Appointments.Period\r\nFROM         Appointments INNER JOIN\r\n                      PatientData ON Appointments.PatuentID = PatientData.ID INNER JOIN\r\n                      Empdata ON Appointments.DoctorID = Empdata.ID\r\nWHERE     (Appointments.Done = 0) and Appointments.ID=" + AppointementID);
				gui.loadDataGrid(dataGridView1, dt);
				dataGridView1.Columns[13].Visible = false;
				dataGridView1.Rows[0].Selected = true;
				DataGrid();
				try
				{
					textBox4.Text = "0";
					EditBtn.Enabled = true;
					saveBtn.Enabled = false;
					DeletBtn.Enabled = true;
					button5.Enabled = false;
					appid = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
					apptextBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
					PatientComboBox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
					PatientComboBox.Enabled = false;
					doctorcomboBox.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
					appdateTimePicker1.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[4].Value.ToString());
					try
					{
						FromTextBox.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
						TOTextBox.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
					}
					catch
					{
					}
					recalldateTimePicker2.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[7].Value.ToString());
					regdateTimePicker1.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[8].Value.ToString());
					ChairTextBox.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
					priceTextBox.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
					oldpric = Convert.ToDouble(dataGridView1.CurrentRow.Cells[10].Value.ToString());
					StatusCom.Text = dataGridView1.CurrentRow.Cells[11].Value.ToString();
					checkBox3.Checked = false;
					checkBox3.Visible = false;
					if (Convert.ToBoolean(dataGridView1.CurrentRow.Cells[13].Value.ToString()))
					{
						comboBox2.SelectedIndex = 1;
					}
					else
					{
						comboBox2.SelectedIndex = 0;
					}
					checkBox2.Checked = Convert.ToBoolean(dataGridView1.CurrentRow.Cells[12].Value.ToString());
					textBox4.Text = "0";
					DataTable dataTable6 = codes.Search2("select PricePay,StockId from PatientAccount where AppointNum = '" + appid + "'");
					textBox3.Text = dataTable6.Rows[0][0].ToString();
					stockId = dataTable6.Rows[0][1].ToString();
					label9.Visible = true;
					textBox3.Visible = true;
				}
				catch
				{
				}
				try
				{
					dataGridView2.Rows.Clear();
					DataTable dataTable7 = codes.Search2("select ServiceName from Properties ");
					text = dataTable7.Rows[0][0].ToString();
					DataTable dataTable6 = dc.GetTableText("select Pay from PatientAccount where PatientId = '" + PatientComboBox.SelectedValue.ToString() + "' and DoctorID = '" + doctorcomboBox.SelectedValue.ToString() + "' and Bean = '" + text + "' and Date = '" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "'");
					checkBox3.Checked = Convert.ToBoolean(dataTable6.Rows[0][0].ToString());
					DataTable dataTable12 = codes.Search2("select Bean,Price,Dariba, PriceBeforeDariba from ReserveService where AppointNum = '" + appid + "' ");
					decimal num3 = 0m;
					for (int i = 0; i < dataTable12.Rows.Count; i++)
					{
						dataGridView2.Rows.Add();
						dataGridView2.Rows[i].Cells[0].Value = dataTable12.Rows[i][0].ToString();
						dataGridView2.Rows[i].Cells[1].Value = dataTable12.Rows[i][3].ToString();
						dataGridView2.Rows[i].Cells[3].Value = dataTable12.Rows[i][2].ToString();
						dataGridView2.Rows[i].Cells[4].Value = dataTable12.Rows[i][1].ToString();
						num3 += Convert.ToDecimal(dataGridView2.Rows[i].Cells[1].Value.ToString());
					}
					textBox5.Text = num3.ToString();
				}
				catch
				{
				}
				try
				{
					DataTable dataTable12 = codes.Search2("select * from PatientAccount where AppointNum = '" + appid + "'");
				}
				catch
				{
				}
				try
				{
					string text3 = FromTextBox.Value.ToString("HH:mm");
					maskedTextBox1.Text = text3;
					text3 = TOTextBox.Value.ToString("HH:mm");
					maskedTextBox2.Text = text3;
				}
				catch
				{
				}
				try
				{
					string text4 = codes.Search2("select ID from PatientAccount where AppointNum = '" + appid + "'").Rows[0][0].ToString();
					EsalNoTxt.Text = codes.Search2("select Code from AppointEsal where PatientAcountId = '" + text4 + "'").Rows[0][0].ToString();
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void DataGrid()
		{
			try
			{
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns[1].HeaderText = "Appointment Number";
					dataGridView1.Columns[2].HeaderText = "Patient Name";
					dataGridView1.Columns[3].HeaderText = "Doctor Name";
					dataGridView1.Columns[4].HeaderText = "Attend Date";
					dataGridView1.Columns[5].HeaderText = "From";
					dataGridView1.Columns[6].HeaderText = "To";
					dataGridView1.Columns[7].HeaderText = "Re-Detection Date";
					dataGridView1.Columns[8].HeaderText = "End Appointment Date";
					dataGridView1.Columns[9].HeaderText = "Chair NO";
					dataGridView1.Columns[10].HeaderText = "Price";
					dataGridView1.Columns[11].HeaderText = "Statues";
					dataGridView1.Columns[12].HeaderText = "Accept";
				}
				else
				{
					dataGridView1.Columns[1].HeaderText = "رقم الحجز";
					dataGridView1.Columns[2].HeaderText = "اسم المريض";
					dataGridView1.Columns[3].HeaderText = "اسم الطبيب";
					dataGridView1.Columns[4].HeaderText = "تاريخ الحجز";
					dataGridView1.Columns[5].HeaderText = "من";
					dataGridView1.Columns[6].HeaderText = "الى";
					dataGridView1.Columns[7].HeaderText = "تاريخ إعادة الكشف";
					dataGridView1.Columns[8].HeaderText = "تاريخ انتهاء الحجز";
					dataGridView1.Columns[9].HeaderText = "رقم الكرسى";
					dataGridView1.Columns[10].HeaderText = "المبلغ";
					dataGridView1.Columns[11].HeaderText = "الحالة";
					dataGridView1.Columns[12].HeaderText = "تم الموافقة";
				}
			}
			catch
			{
			}
		}

		private void loaddata()
		{
			try
			{
				DataTable dataTable = codes.Search2("select ServiceName from Properties where ServiceName IS NOT NULL");
				if (dataTable.Rows.Count > 0)
				{
					string text = dataTable.Rows[0][0].ToString();
					DataTable dataTable2 = new DataTable();
					string[] fields = new string[1] { "Date" };
					dataTable2 = dc.Select("SelectAllAppointmentBydate", fields, appdateTimePicker1.Value.ToString("MM/dd/yyyy"));
					if (dataTable2.Rows.Count > 0)
					{
						apptextBox.Text = (dataTable2.Rows.Count + 1).ToString();
					}
					else
					{
						apptextBox.Text = "1";
					}
					try
					{
						dataTable2 = dc.Select("SelectAllAppointment");
						gui.loadDataGrid(dataGridView1, dataTable2);
						dataGridView1.Columns[13].Visible = false;
						DataGrid();
					}
					catch
					{
					}
					try
					{
						dataTable2 = dc.Select("SelectAllDoctor");
						gui.loadComboBox(doctorcomboBox, dataTable2);
					}
					catch
					{
					}
					try
					{
						if (Convert.ToBoolean(codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString()))
						{
							DataTable tableText = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True' order by PName");
							PatientComboBox.DataSource = tableText;
							PatientComboBox.DisplayMember = tableText.Columns[1].ToString();
							PatientComboBox.ValueMember = tableText.Columns[0].ToString();
						}
						else
						{
							dataTable2 = dc.Select("SelectAllPatient");
							gui.loadComboBox(PatientComboBox, dataTable2);
						}
					}
					catch
					{
					}
					try
					{
						doctorcomboBox.SelectedItem = doctorcomboBox.Items[0];
						PatientComboBox.SelectedItem = PatientComboBox.Items[0];
					}
					catch
					{
					}
					DataTable dataTable3 = codes.Search2(string.Concat("SELECT Company.Name,PatientData.Accept,DoctoreName FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID WHERE (PatientData.ID ='", PatientComboBox.SelectedValue, "')"));
					textBox1.Text = dataTable3.Rows[0][0].ToString();
					DataTable dataTable4 = codes.Search2("SELECT dbo.CompanyService.Price FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + textBox1.Text + "' and Service = '" + text + "' ");
					if (dataTable4.Rows.Count != 0)
					{
						priceTextBox.Text = dataTable4.Rows[0][0].ToString();
					}
					else
					{
						priceTextBox.Text = "0";
					}
				}
				else
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter the Appointment service from the General Properties");
					}
					else
					{
						MessageBox.Show(" من فضلك ادخل خدمة الحجز من شاشة خصائص عامة");
					}
					Close();
					FrmProperties frmProperties = new FrmProperties();
					frmProperties.ShowDialog();
				}
			}
			catch
			{
			}
		}

		private void clear()
		{
			ChairTextBox.Text = "";
			priceTextBox.Text = "0";
			appdateTimePicker1.Value = DateTime.Now;
			recalldateTimePicker2.Value = DateTime.Now;
			regdateTimePicker1.Value = DateTime.Now;
			EditBtn.Enabled = false;
			saveBtn.Enabled = true;
			DeletBtn.Enabled = false;
			checkBox2.Checked = false;
			checkBox3.Checked = false;
			loaddata();
			PatientComboBox.Enabled = true;
			checkBox3.Visible = true;
			label9.Visible = false;
			textBox3.Visible = false;
			textBox3.Text = "0";
			dataGridView2.DataSource = null;
			dataGridView2.Rows.Clear();
			dtPackDate.Rows.Clear();
			button5.Enabled = true;
			Dariba.Text = "0";
			AfterDariba.Text = "";
			try
			{
				DataTable dataTable = codes.Search2("select AppointFrom from Properties");
				string text = "";
				text = ((Convert.ToDateTime(dataTable.Rows[0][0]).Hour <= 12) ? Convert.ToDateTime(dataTable.Rows[0][0]).Hour.ToString() : (Convert.ToDateTime(dataTable.Rows[0][0]).Hour - 12).ToString());
				if (Convert.ToInt32(text) < 10)
				{
					text = "0" + text;
				}
				maskedTextBox1.Text = text + ":00";
				FromTextBox.Text = text + ":00";
			}
			catch
			{
			}
			try
			{
				if (UsersClass.AutoEsal)
				{
					EsalNoTxt.Text = codes.Search2("select isnull(max(Code)+1,1) from AppointEsal").Rows[0][0].ToString();
					EsalNoTxt.Enabled = false;
				}
				else
				{
					EsalNoTxt.Text = "";
					EsalNoTxt.Enabled = true;
				}
			}
			catch
			{
			}
			decimal num = 0m;
			decimal num2 = 0m;
			DataTable dataTable2 = codes.Search2("select ServiceName from Properties");
			string text2 = dataTable2.Rows[0][0].ToString();
			try
			{
				Convert.ToDecimal(priceTextBox.Text);
			}
			catch
			{
				priceTextBox.Text = "0";
			}
			if (priceTextBox.Text == "" || priceTextBox.Text == "0")
			{
				DataTable dataTable3 = codes.Search2("SELECT dbo.CompanyService.Price , dbo.CompanyService.Dariba FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + textBox1.Text + "' and Service = '" + text2 + "' ");
				if (dataTable3.Rows.Count != 0)
				{
					priceTextBox.Text = dataTable3.Rows[0][0].ToString();
				}
			}
			else
			{
				num = Math.Round(Convert.ToDecimal(priceTextBox.Text) + Convert.ToDecimal(priceTextBox.Text) * Convert.ToDecimal(textBox6.Text) / 100m, 2);
			}
			try
			{
				DataTable dataTable4 = codes.Search2("select dbo.CompanyService.DiscountNesba,dbo.CompanyService.DiscountValue FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + textBox1.Text + "' and Service = '" + text2 + "' ");
				if (dataTable4.Rows.Count > 0)
				{
					if (Convert.ToDecimal(dataTable4.Rows[0][0].ToString()) != 0m)
					{
						num2 = Math.Round(num - num * Convert.ToDecimal(dataTable4.Rows[0][0].ToString()) / 100m);
						if (Settings.Default.Language == "en-GB")
						{
							label105.Text = "Discount%";
						}
						else
						{
							label105.Text = "نسبة الخصم";
						}
						textBoxDiscount.Text = dataTable4.Rows[0][0].ToString();
						textBox7.Text = num2.ToString();
					}
					else if (Convert.ToDecimal(dataTable4.Rows[0][1].ToString()) != 0m)
					{
						num2 = Math.Round(num - Convert.ToDecimal(dataTable4.Rows[0][1].ToString()));
						if (Settings.Default.Language == "en-GB")
						{
							label105.Text = "Discount";
						}
						else
						{
							label105.Text = "قيمة الخصم";
						}
						textBoxDiscount.Text = dataTable4.Rows[0][1].ToString();
						textBox7.Text = num2.ToString();
					}
				}
				else
				{
					if (Settings.Default.Language == "en-GB")
					{
						label105.Text = "Discount";
					}
					else
					{
						label105.Text = "قيمة الخصم";
					}
					textBoxDiscount.Text = "0";
					textBox7.Text = num.ToString();
				}
			}
			catch
			{
			}
		}

		private void priceTextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && priceTextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك أدخل أرقام فقط");
				}
				e.Handled = true;
			}
			catch
			{
			}
		}

		private void priceTextBox_Leave(object sender, EventArgs e)
		{
		}

		private void addAccountPatient()
		{
			DataTable dataTable = codes.Search2("select ServiceName from Properties ");
			string text = dataTable.Rows[0][0].ToString();
			string[] fields = new string[7] { "PatientId", "DoctorID", "Bean", "Price", "Date", "BeanDate", "Assistant" };
			dc.Insert("AddPatientAccountApp", fields, Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), text, priceTextBox.Text, appdateTimePicker1.Value.ToString("MM/dd/yyyy"), appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "");
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				int num = Convert.ToInt32(codes.Search2("select count(id) from Appointments").Rows[0][0].ToString());
				if (num >= 20)
				{
					MessageBox.Show("انتهت المدة المحددة لتشغيل البرنامج إذا أردت النسخة الكاملة الرجاء الإتصال بالشركة", "تحذير", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return;
				}
				DataTable dataTable = codes.Search2("select AppointFrom, AppointTo from Properties");
				DateTime dateTime = Convert.ToDateTime(dataTable.Rows[0][0].ToString());
				DateTime dateTime2 = Convert.ToDateTime(dataTable.Rows[0][1].ToString());
				int num2 = 0;
				int num3 = 0;
				int num4 = 0;
				int num5 = 0;
				if ((!(comboBox2.Text == "الفترة الصباحية") || (TimeSpan.Compare(dateTime2.TimeOfDay, TOTextBox.Value.TimeOfDay) != 1 && TimeSpan.Compare(FromTextBox.Value.TimeOfDay, dateTime.TimeOfDay) != 1)) && (!(comboBox2.Text == "الفترة المسائية") || (TimeSpan.Compare(TOTextBox.Value.TimeOfDay, dateTime2.TimeOfDay) != 1 && TimeSpan.Compare(dateTime.TimeOfDay, FromTextBox.Value.TimeOfDay) != 1)))
				{
					num2 = ((dateTime.Hour < 12) ? dateTime.Hour : (dateTime.Hour - 12));
					num3 = ((dateTime2.Hour < 12) ? dateTime2.Hour : (dateTime2.Hour - 12));
					num4 = ((FromTextBox.Value.Hour < 12) ? FromTextBox.Value.Hour : (FromTextBox.Value.Hour - 12));
					num5 = ((TOTextBox.Value.Hour < 12) ? TOTextBox.Value.Hour : (TOTextBox.Value.Hour - 12));
					if (comboBox2.Text == "الفترة الصباحية" && num2 > num4)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Cannot Reserve when Clinic Not open");
						}
						else
						{
							MessageBox.Show("برجاء حجز الكشف في موعد عمل العيادة");
						}
						return;
					}
					if (comboBox2.Text == "الفترة المسائية" && (num2 < num4 || num3 < num5 || num3 == num4))
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Cannot Reserve when Clinic Not open");
						}
						else
						{
							MessageBox.Show("برجاء حجز الكشف في موعد عمل العيادة");
						}
						return;
					}
				}
				if (groupBox6.Visible && !checkBox2.Checked)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Cannot Reserve for this patient Without Approvement");
					}
					else
					{
						MessageBox.Show("لا يمكن الحجز لهذا المريض بدون موافقة");
					}
					return;
				}
				if (codes.Search2("select AppointSystem from Properties").Rows[0][0].ToString() == "1")
				{
					bool flag = false;
					if (comboBox2.SelectedIndex == 1)
					{
						flag = true;
					}
					DataTable dataTable2 = codes.Search2("select * from Appointments where DoctorID=" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "  and Period = '" + flag + "' and detectDate ='" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "' and Appointments.detectStartTime='" + FromTextBox.Value.ToString("hh:mm") + "' and Appointments.detectEndTime='" + TOTextBox.Value.ToString("hh:mm") + "'");
					if (dataTable2.Rows.Count > 0 && TOTextBox.Value.ToString("hh:mm") == dataTable2.Rows[0][6].ToString() && FromTextBox.Value.ToString("hh:mm") == dataTable2.Rows[0][5].ToString())
					{
						MessageBox.Show("لا يمكن الحجز تم تسجيل حجز بنفس الميعاد من قبل");
						return;
					}
					int num6 = Convert.ToInt32(codes.Search2("select AppointPeriod from Properties").Rows[0][0]);
					double totalMinutes = (TOTextBox.Value - FromTextBox.Value).TotalMinutes;
					int num7 = Convert.ToInt32(Math.Truncate(totalMinutes));
					if (num7 != num6)
					{
						MessageBox.Show(" لا يمكن الحجز لان مدة الكشف " + num6 + " دقيقة ");
						return;
					}
				}
				if (b)
				{
					if (doctorcomboBox.SelectedItem != null)
					{
						dataSet11.Clear();
						if (checkBox3.Checked)
						{
							if (PayNaqdy.Checked)
							{
								if (EsalNoTxt.Text == "")
								{
									MessageBox.Show("من فضلك ادخل رقم الايصال");
									return;
								}
								DataTable dataTable3 = codes.Search2("select Code from AppointEsal where Code ='" + EsalNoTxt.Text + "'");
								if (dataTable3.Rows.Count > 0)
								{
									MessageBox.Show("رقم الايصال مسجل من قبل");
									EsalNoTxt.Text = codes.Search2("select isnull(max(Code)+1,1) from AppointEsal").Rows[0][0].ToString();
								}
							}
							else
							{
								if (Rased.Text == "0.00" || Rased.Text == "0")
								{
									MessageBox.Show("لا يمكن الدفع من مدفوعات سابقة لان الحساب السابق للمريض بصفر");
									return;
								}
								if (Convert.ToDecimal(textBox7.Text) > Convert.ToDecimal(Rased.Text))
								{
									MessageBox.Show("لا يمكن الدفع من مدفوعات سابقة لان الحساب السابق للمريض أقل من اجمالي الكشف");
									return;
								}
							}
						}
						sqlConnection1.ConnectionString = dc.ConnectionStr;
						sqlDataAdapter1.Fill(dataSet11);
						if (PatientComboBox.SelectedItem != null)
						{
							string value = codes.Search("select isnull(sum(Madeen),0) -  isnull(sum(Daen),0) from Company5 where CompanyId = '" + companyId + "'").Rows[0][0].ToString();
							DataTable dataTable4 = new DataTable();
							double num8;
							try
							{
								dataTable4 = dc.GetTableText("select * from Stock  where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
								num8 = Convert.ToDouble(dataTable4.Rows[0][1].ToString());
							}
							catch
							{
								num8 = 0.0;
							}
							string[] fields = new string[15]
							{
								"AppointNum", "PatuentID", "DoctorID", "detectDate", "detectStartTime", "detectEndTime", "packDate", "ExpDate", "ChairNum", "Price",
								"Status", "Accepted", "Period", "Dariba", "PriceBeforeDariba"
							};
							bool flag2 = false;
							if (comboBox2.SelectedIndex == 1)
							{
								flag2 = true;
							}
							bool flag3 = false;
							if (dtPackDate.Rows.Count == 1)
							{
								flag3 = dc.Insert("AddAppointment", fields, apptextBox.Text, Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), appdateTimePicker1.Value.ToString("MM/dd/yyyy"), FromTextBox.Value.ToString("hh:mm"), TOTextBox.Value.ToString("hh:mm"), Convert.ToDateTime(dtPackDate.Rows[0][0]).ToString("MM/dd/yyyy"), regdateTimePicker1.Value.ToString("MM/dd/yyyy"), ChairTextBox.Text, textBox7.Text, StatusCom.Text, checkBox2.Checked, flag2, textBox6.Text, priceTextBox.Text);
							}
							if (dtPackDate.Rows.Count == 0 || dtPackDate.Rows.Count > 1)
							{
								flag3 = dc.Insert("AddAppointment", fields, apptextBox.Text, Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), appdateTimePicker1.Value.ToString("MM/dd/yyyy"), FromTextBox.Value.ToString("hh:mm"), TOTextBox.Value.ToString("hh:mm"), recalldateTimePicker2.Value.ToString("MM/dd/yyyy"), regdateTimePicker1.Value.ToString("MM/dd/yyyy"), ChairTextBox.Text, textBox7.Text, StatusCom.Text, checkBox2.Checked, flag2, textBox6.Text, priceTextBox.Text);
							}
							string text = codes.Search2("select max(id) from Appointments").Rows[0][0].ToString();
							if (dtPackDate.Rows.Count > 1)
							{
								codes.Edit2("update Appointments set PackDone = 1 where id = '" + text + "'");
								for (int i = 0; i < dtPackDate.Rows.Count; i++)
								{
									codes.Add2("INSERT INTO Appointments\r\n                      (AppointNum, PatuentID, DoctorID, detectDate, detectStartTime, detectEndTime, packDate, ExpDate, ChairNum, Price, Done, PackDone, packprice,Status,Accepted,Period,Dariba, PriceBeforeDariba)\r\nVALUES     (0,'" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + FromTextBox.Value.ToString("hh:mm") + "','" + TOTextBox.Value.ToString("hh:mm") + "','" + Convert.ToDateTime(dtPackDate.Rows[i][0]).ToString("MM/dd/yyyy") + "','" + regdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + ChairTextBox.Text + "',0, 1, 0, 0,'" + StatusCom.Text + "','" + checkBox2.Checked + "','" + flag2 + "',0,0)");
								}
							}
							if (flag3)
							{
								string[] fields2 = new string[11]
								{
									"PatientId", "DoctorID", "Bean", "Price", "Date", "PricePay", "BeanDate", "AppointNum", "Dariba", "PriceBeforeDariba",
									"Assistant"
								};
								for (int i = 0; i < dataGridView2.Rows.Count; i++)
								{
									codes.Add2("insert into ReserveService (Bean, Price, AppointNum ,Dariba, PriceBeforeDariba) values('" + dataGridView2.Rows[i].Cells[0].Value.ToString() + "','" + Convert.ToDecimal(dataGridView2.Rows[i].Cells[4].Value.ToString()) + "','" + text + "','" + Convert.ToDecimal(dataGridView2.Rows[i].Cells[3].Value.ToString()) + "','" + Convert.ToDecimal(dataGridView2.Rows[i].Cells[1].Value.ToString()) + "')");
								}
								codes.Search2("select ServiceName from Properties ");
								string text2 = "";
								text2 = ((!panel1.Visible) ? codes.Search2("select ServiceName from Properties ").Rows[0][0].ToString() : ((!radioButton3.Checked) ? codes.Search2("select ServiceDetect from Properties ").Rows[0][0].ToString() : codes.Search2("select ServiceName from Properties ").Rows[0][0].ToString()));
								string text3 = EsalNoTxt.Text;
								if (checkBox3.Checked)
								{
									codes.Add2("INSERT INTO PatientAccount\r\n                      (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay,BeanDate,AppointNum,StockId,Dariba, PriceBeforeDariba,Assistant)\r\nVALUES     ('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','" + text2 + "','" + textBox7.Text + "', 1,'" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "', '" + textBox7.Text + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + text + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "','" + textBox6.Text + "','" + priceTextBox.Text + "','')");
									DataTable dataTable5 = codes.Search2("select max(ID) from PatientAccount");
									codes.Add2("insert into AccountDetails (PatientId, DoctorId, Date, Bean, Price, PricePay, PatientAcountId, StockId) values('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + text2 + "','" + textBox7.Text + "','" + textBox7.Text + "','" + Convert.ToInt32(dataTable5.Rows[0][0].ToString()) + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
									string text4 = "0";
									if (checkBox3.Checked)
									{
										text4 = textBox7.Text;
									}
									codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + CompanyPrice + "','" + (Convert.ToDouble(value) + Convert.ToDouble(CompanyPrice)) + "','" + text2 + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(dataTable5.Rows[0][0].ToString()) + "')");
									codes.Add2("insert into AppointEsal (Code, Doctor, Patient, Date, Company, TimeFrom, TimeTo,UserName, Price, Pay, PatientAcountId) values ('" + text3 + "','" + doctorcomboBox.Text + "','" + PatientComboBox.Text + "', '" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "', '" + textBox1.Text + "','" + FromTextBox.Text + "', '" + TOTextBox.Text + "' , '" + Main.usernames + "', '" + textBox7.Text + "','" + text4 + "','" + Convert.ToInt32(dataTable5.Rows[0][0].ToString()) + "')");
									double num9 = Convert.ToDouble(textBox7.Text);
									double num10 = num8 + num9;
									codes.Edit2(string.Concat("update PatientData set Accept='False' where ID='", PatientComboBox.SelectedValue, "'"));
									if (PayNaqdy.Checked)
									{
										codes.Edit2("update Stock Set Value='" + num10.ToString() + "' where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
										codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('كشف' ," + Convert.ToDecimal(textBox7.Text) + ",'" + PatientComboBox.Text + " إيصال حجز رقم: " + EsalNoTxt.Text + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
									}
									else
									{
										DataTable dataTable6 = codes.Search2("select max(ID) from AppointEsal");
										decimal num11 = Convert.ToDecimal(Rased.Text) - Convert.ToDecimal(textBox7.Text);
										codes.Search2(string.Concat("insert into PatientBeforePay (PatientID,Daen,Madeen,Raseed,Bayan,[Date],EsalNum,StockID,Type) values (", PatientComboBox.SelectedValue, ",", Convert.ToDecimal(textBox7.Text) * -1m, ",0,", num11, ",'حجز كشف مدفوع من رصيد سابق','", appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "','", dataTable6.Rows[0][0].ToString(), "','0','false')"));
									}
									if (StatusCom.Text == "تم التأكيد" || StatusCom.Text == "Confirmed")
									{
										string text5 = codes.Search2("select max(id) from Appointments").Rows[0][0].ToString();
										codes.Edit2(string.Concat("update Appointments set AcceptDate ='", DateTime.Now, "' where id = '", text5, "'"));
									}
									if (Settings.Default.Language == "en-GB")
									{
										MessageBox.Show("Data Save Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
									}
									else
									{
										MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
									}
									MethodsClass.UserMove("حجز كشف لمريض");
									AddAppointment = false;
									((DataTable)(object)dataSet11.AppointmentEsal).Rows.Add(text3, PatientComboBox.Text, doctorcomboBox.Text, appdateTimePicker1.Value, FromTextBox.Value.ToString("hh:mm"), TOTextBox.Value.ToString("hh:mm"), textBox1.Text, Main.usernames, textBox7.Text);
									sqlConnection2.ConnectionString = codes.ConnectionStr;
									sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
									sqlDataAdapter2.SelectCommand.CommandText = "select * from PatientData where PName ='" + PatientComboBox.Text + "'";
									sqlDataAdapter2.Fill(dataSet11);
									if (Convert.ToBoolean(codes.Search2("select ShowEsal from Properties").Rows[0][0]))
									{
										AppointEsalRptFrm appointEsalRptFrm = new AppointEsalRptFrm(dataSet11);
										appointEsalRptFrm.ShowDialog();
									}
									loaddata();
									clear();
								}
								else
								{
									dc.Insert("AddPatientAccountApp", fields2, Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), text2, textBox7.Text, appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "0", appdateTimePicker1.Value.ToString("MM/dd/yyyy"), text, textBox6.Text, priceTextBox.Text, "");
									double num9 = Convert.ToDouble(priceTextBox.Text);
									double num10 = num8 + num9;
									codes.Edit2(string.Concat("update PatientData set Accept='False' where ID='", PatientComboBox.SelectedValue, "'"));
									if (StatusCom.Text == "تم التأكيد" || StatusCom.Text == "Confirmed")
									{
										string text5 = codes.Search2("select max(id) from Appointments").Rows[0][0].ToString();
										codes.Edit2(string.Concat("update Appointments set AcceptDate ='", DateTime.Now, "' where id = '", text5, "'"));
									}
									DataTable dataTable5 = codes.Search2("select max(ID) from PatientAccount");
									codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + CompanyPrice + "','" + (Convert.ToDouble(value) + Convert.ToDouble(CompanyPrice)) + "','" + text2 + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(dataTable5.Rows[0][0].ToString()) + "')");
									if (Settings.Default.Language == "en-GB")
									{
										MessageBox.Show("Data Save Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
									}
									else
									{
										MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
									}
									MethodsClass.UserMove("حجز كشف لمريض");
									AddAppointment = false;
									loaddata();
									clear();
								}
							}
							else if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							}
							else
							{
								MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							}
						}
						else if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("please choose patient name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("من فضلك اختر اسم المريض", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("please choose Doctor name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم الطبيب", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Doctor Appointments or backs reached the maximum limit");
				}
				else
				{
					MessageBox.Show("عدد الكشوفات او إعادة الكشف لهذا الطبيب وصلت الحد الأقصى");
				}
			}
			catch
			{
			}
			PatientComboBox_SelectedIndexChanged(sender, e);
		}

		private void appdateTimePicker1_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				AppointCount();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = new DataTable();
				string[] fields = new string[1] { "Date" };
				dataTable = dc.Select("SelectAllAppointmentBydate", fields, appdateTimePicker1.Value.ToString("MM/dd/yyyy"));
				if (!EditBtn.Enabled)
				{
					if (dataTable.Rows.Count > 0)
					{
						apptextBox.Text = (dataTable.Rows.Count + 1).ToString();
					}
					else
					{
						apptextBox.Text = "1";
					}
				}
			}
			catch
			{
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				string text;
				if (b)
				{
					if (doctorcomboBox.SelectedItem != null)
					{
						if (PatientComboBox.SelectedItem != null)
						{
							text = codes.Search2("select ID from PatientAccount where AppointNum = '" + appid + "'").Rows[0][0].ToString();
							if (!checkBox3.Checked)
							{
								goto IL_0147;
							}
							if (!(EsalNoTxt.Text == ""))
							{
								DataTable dataTable = codes.Search2("select Code from AppointEsal where Code ='" + EsalNoTxt.Text + "' and PatientAcountId <> '" + text + "'");
								if (dataTable.Rows.Count > 0)
								{
									MessageBox.Show("رقم الايصال مسجل من قبل");
									EsalNoTxt.Text = codes.Search2("select isnull(max(Code)+1,1) from AppointEsal").Rows[0][0].ToString();
								}
								goto IL_0147;
							}
							MessageBox.Show("من فضلك ادخل رقم الايصال");
						}
						else if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("please choose patient name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("من فضلك اختر اسم المريض", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("please choose Doctor name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم الطبيب", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Doctor Appointments or backs reached the maximum limit");
				}
				else
				{
					MessageBox.Show("عدد الكشوفات او إعادة الكشف لهذا الطبيب وصلت الحد الأقصى");
				}
				goto end_IL_0001;
				IL_0147:
				string text2 = "";
				string[] array = new string[1] { "Date" };
				DataTable dataTable2 = codes.Search2("select * from Appointments where detectDate='" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "' and ID<>'" + appid + "' and AppointNum='" + apptextBox.Text + "'");
				if (dataTable2.Rows.Count > 0)
				{
					DataTable dataTable3 = codes.Search2("select max (AppointNum) from Appointments where detectDate='" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "'");
					text2 = ((dataTable3.Rows.Count <= 0) ? "1" : (Convert.ToInt32(dataTable3.Rows[0][0].ToString()) + 1).ToString());
				}
				else
				{
					text2 = apptextBox.Text;
				}
				bool flag = false;
				if (Convert.ToDecimal(priceTextBox.Text) == Convert.ToDecimal(textBox3.Text))
				{
					flag = true;
				}
				DataTable dataTable4 = codes.Search2("select ServiceName from Properties ");
				string text3 = dataTable4.Rows[0][0].ToString();
				codes.Edit2(string.Concat("update PatientAccount set DoctorID = '", doctorcomboBox.SelectedValue, "' , Price = '", textBox7.Text, "' , Pay = '", flag, "' , Date = '", appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "',BeanDate = '", appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "' , Dariba = '", textBox6.Text, "' , PriceBeforeDariba = '", priceTextBox.Text, "' where AppointNum = '", appid, "' and Bean = '", text3, "'"));
				codes.Delete2("delete from ReserveService where AppointNum = '" + appid + "'");
				array = new string[9] { "PatientId", "DoctorID", "Bean", "Price", "Date", "PricePay", "BeanDate", "AppointNum", "Assistant" };
				for (int i = 0; i < dataGridView2.Rows.Count; i++)
				{
					codes.Add2("insert into ReserveService (Bean, Price, AppointNum ,Dariba, PriceBeforeDariba) values('" + dataGridView2.Rows[i].Cells[0].Value.ToString() + "','" + Convert.ToDecimal(dataGridView2.Rows[i].Cells[4].Value.ToString()) + "','" + appid + "','" + Convert.ToDecimal(dataGridView2.Rows[i].Cells[3].Value.ToString()) + "','" + Convert.ToDecimal(dataGridView2.Rows[i].Cells[1].Value.ToString()) + "')");
				}
				bool flag2 = false;
				if (comboBox2.SelectedIndex == 1)
				{
					flag2 = true;
				}
				DataTable dataTable5 = codes.Search2("select Status from Appointments where ID ='" + appid + "'");
				if ((StatusCom.Text == "تم التأكيد" || StatusCom.Text == "Confirmed") && (dataTable5.Rows[0][0].ToString() == "لم يؤكد" || dataTable5.Rows[0][0].ToString() == "Not Confirmed"))
				{
					codes.Edit2(string.Concat("UPDATE Appointments SET AppointNum='", text2, "',PatuentID='", Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), "',DoctorID='", Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), "',detectDate='", appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "',detectStartTime='", maskedTextBox1.Text, "',detectEndTime='", maskedTextBox2.Text, "',packDate='", recalldateTimePicker2.Value.ToString("MM/dd/yyyy"), "',ExpDate='", regdateTimePicker1.Value.ToString("MM/dd/yyyy"), "',ChairNum='", ChairTextBox.Text, "',Price='", textBox7.Text, "',Status='", StatusCom.Text, "',Accepted='", checkBox2.Checked, "',Period ='", flag2, "',Dariba='", textBox6.Text, "',PriceBeforeDariba='", priceTextBox.Text, "', AcceptDate ='", DateTime.Now, "' where ID ='", appid, "'"));
				}
				else
				{
					codes.Edit2("UPDATE Appointments SET AppointNum='" + text2 + "',PatuentID='" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "',DoctorID='" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "',detectDate='" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "',detectStartTime='" + maskedTextBox1.Text + "',detectEndTime='" + maskedTextBox2.Text + "',packDate='" + recalldateTimePicker2.Value.ToString("MM/dd/yyyy") + "',ExpDate='" + regdateTimePicker1.Value.ToString("MM/dd/yyyy") + "',ChairNum='" + ChairTextBox.Text + "',Price='" + textBox7.Text + "',Status='" + StatusCom.Text + "',Accepted='" + checkBox2.Checked + "',Period ='" + flag2 + "',Dariba='" + textBox6.Text + "',PriceBeforeDariba='" + priceTextBox.Text + "' where ID ='" + appid + "'");
				}
				codes.Edit2("update AppointEsal set Code='" + EsalNoTxt.Text + "',Doctor = '" + doctorcomboBox.Text + "', Patient = '" + PatientComboBox.Text + "', Date = '" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "', Company = '" + textBox1.Text + "', TimeFrom = '" + FromTextBox.Text + "', TimeTo='" + TOTextBox.Text + "',Price = '" + textBox7.Text + "' where PatientAcountId = '" + text + "'");
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Save Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				MethodsClass.UserMove("تعديل كشف لمريض");
				loaddata();
				clear();
				end_IL_0001:;
			}
			catch
			{
			}
		}

		private void DeletBtn_Click(object sender, EventArgs e)
		{
			try
			{
				string text = "";
				bool flag = false;
				string[] fields;
				if (Settings.Default.Language == "en-GB")
				{
					if (MessageBox.Show("Are you Sure You Want To Delete", "Notes", MessageBoxButtons.OKCancel) != DialogResult.OK)
					{
						return;
					}
					try
					{
						text = codes.Search2("select ID from PatientAccount where AppointNum = '" + appid + "'").Rows[0][0].ToString();
						DataTable dataTable = codes.Search2("select ID from AppointEsal where PatientAcountId = '" + text + "'");
						if (dataTable.Rows.Count > 0)
						{
							DataTable dataTable2 = codes.Search2("select ID from PatientBeforePay where EsalNum='" + dataTable.Rows[0][0].ToString() + "' and Type='false'");
							if (dataTable2.Rows.Count > 0)
							{
								codes.Edit2("delete from PatientBeforePay where ID = '" + Convert.ToInt32(dataTable2.Rows[0][0].ToString()) + "'");
								flag = true;
							}
							else
							{
								flag = false;
							}
						}
					}
					catch
					{
					}
					fields = new string[1] { "id" };
					if (dc.Delete("DeleteAppointment", fields, appid))
					{
						codes.Delete2("delete from PatientAccount where AppointNum = '" + appid + "'");
						codes.Delete2("delete from AppointEsal where PatientAcountId = '" + text + "'");
						if (!flag)
						{
							if (Convert.ToDecimal(textBox3.Text) > 0m)
							{
								codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('حذف كشف' ," + textBox3.Text + ",'" + PatientComboBox.Text + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','" + stockId + "')");
							}
							codes.Edit2("update Stock Set Value = Value - '" + textBox3.Text + "' where ID = '" + stockId + "'");
						}
						MessageBox.Show("Data Delete Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						loaddata();
						clear();
					}
					else
					{
						MessageBox.Show("Error Happend While Delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					return;
				}
				if (MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.OKCancel) != DialogResult.OK)
				{
					return;
				}
				try
				{
					text = codes.Search2("select ID from PatientAccount where AppointNum = '" + appid + "'").Rows[0][0].ToString();
					DataTable dataTable = codes.Search2("select ID from AppointEsal where PatientAcountId = '" + text + "'");
					if (dataTable.Rows.Count > 0)
					{
						DataTable dataTable2 = codes.Search2("select ID from PatientBeforePay where EsalNum='" + dataTable.Rows[0][0].ToString() + "' and Type='false'");
						if (dataTable2.Rows.Count > 0)
						{
							codes.Edit2("delete from PatientBeforePay where ID = '" + Convert.ToInt32(dataTable2.Rows[0][0].ToString()) + "'");
							flag = true;
						}
						else
						{
							flag = false;
						}
					}
				}
				catch
				{
				}
				fields = new string[1] { "id" };
				if (dc.Delete("DeleteAppointment", fields, appid))
				{
					codes.Delete2("delete from PatientAccount where AppointNum = '" + appid + "'");
					codes.Delete2("delete from AppointEsal where PatientAcountId = '" + text + "'");
					if (!flag)
					{
						if (Convert.ToDecimal(textBox3.Text) > 0m)
						{
							codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('حذف كشف' ," + textBox3.Text + ",'" + PatientComboBox.Text + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','" + stockId + "')");
						}
						codes.Edit2("update Stock Set Value = Value - '" + textBox3.Text + "' where ID = '" + stockId + "'");
					}
					MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					loaddata();
					clear();
				}
				else
				{
					MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select DeleteUpdateApp from users where userId='" + Main.userId + "'");
				if (!Convert.ToBoolean(dataTable.Rows[0][0]))
				{
					MessageBox.Show("عفوا\u064b هذا المستخدم لا يمتلك صلاحية الحذف او التعديل ");
					return;
				}
				textBox4.Text = "0";
				EditBtn.Enabled = true;
				saveBtn.Enabled = false;
				DeletBtn.Enabled = true;
				button5.Enabled = false;
				appid = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
				apptextBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
				PatientComboBox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
				PatientComboBox.Enabled = false;
				doctorcomboBox.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
				appdateTimePicker1.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[4].Value.ToString());
				try
				{
					FromTextBox.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
					TOTextBox.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
				}
				catch
				{
				}
				recalldateTimePicker2.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[7].Value.ToString());
				regdateTimePicker1.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[8].Value.ToString());
				ChairTextBox.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
				priceTextBox.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
				oldpric = Convert.ToDouble(dataGridView1.CurrentRow.Cells[10].Value.ToString());
				StatusCom.Text = dataGridView1.CurrentRow.Cells[11].Value.ToString();
				checkBox3.Checked = false;
				checkBox3.Visible = false;
				if (Convert.ToBoolean(dataGridView1.CurrentRow.Cells[13].Value.ToString()))
				{
					comboBox2.SelectedIndex = 1;
				}
				else
				{
					comboBox2.SelectedIndex = 0;
				}
				checkBox2.Checked = Convert.ToBoolean(dataGridView1.CurrentRow.Cells[12].Value.ToString());
				textBox4.Text = "0";
				DataTable dataTable2 = codes.Search2("select PricePay,StockId from PatientAccount where AppointNum = '" + appid + "'");
				textBox3.Text = dataTable2.Rows[0][0].ToString();
				stockId = dataTable2.Rows[0][1].ToString();
				label9.Visible = true;
				textBox3.Visible = true;
			}
			catch
			{
			}
			try
			{
				dataGridView2.Rows.Clear();
				DataTable dataTable3 = codes.Search2("select ServiceName from Properties ");
				string text = dataTable3.Rows[0][0].ToString();
				DataTable dataTable2 = dc.GetTableText("select Pay from PatientAccount where PatientId = '" + PatientComboBox.SelectedValue.ToString() + "' and DoctorID = '" + doctorcomboBox.SelectedValue.ToString() + "' and Bean = '" + text + "' and Date = '" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "'");
				checkBox3.Checked = Convert.ToBoolean(dataTable2.Rows[0][0].ToString());
				DataTable dataTable4 = codes.Search2("select Bean,Price,Dariba, PriceBeforeDariba from ReserveService where AppointNum = '" + appid + "' ");
				decimal num = 0m;
				for (int i = 0; i < dataTable4.Rows.Count; i++)
				{
					dataGridView2.Rows.Add();
					dataGridView2.Rows[i].Cells[0].Value = dataTable4.Rows[i][0].ToString();
					dataGridView2.Rows[i].Cells[1].Value = dataTable4.Rows[i][3].ToString();
					dataGridView2.Rows[i].Cells[3].Value = dataTable4.Rows[i][2].ToString();
					dataGridView2.Rows[i].Cells[4].Value = dataTable4.Rows[i][1].ToString();
					num += Convert.ToDecimal(dataGridView2.Rows[i].Cells[1].Value.ToString());
				}
				textBox5.Text = num.ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable4 = codes.Search2("select * from PatientAccount where AppointNum = '" + appid + "'");
			}
			catch
			{
			}
			try
			{
				string text2 = FromTextBox.Value.ToString("HH:mm");
				maskedTextBox1.Text = text2;
				text2 = TOTextBox.Value.ToString("HH:mm");
				maskedTextBox2.Text = text2;
			}
			catch
			{
			}
			try
			{
				string text3 = codes.Search2("select ID from PatientAccount where AppointNum = '" + appid + "'").Rows[0][0].ToString();
				EsalNoTxt.Text = codes.Search2("select Code from AppointEsal where PatientAcountId = '" + text3 + "'").Rows[0][0].ToString();
			}
			catch
			{
			}
		}

		private void Searchbtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = ((!(Settings.Default.Language == "en-GB")) ? dc.GetTableText("SELECT     Appointments.ID, Appointments.AppointNum AS [رقم الحجز], PatientData.PName AS [اسم المريض], Empdata.Name AS [اسم الطبيب], \r\n                      Appointments.detectDate AS [تاريخ الحجز], Appointments.detectStartTime AS [من], Appointments.detectEndTime AS [الى], Appointments.packDate AS [تاريخ إعادة الكشف], \r\n                      Appointments.ExpDate AS [تاريخ انتهاء الحجز], Appointments.ChairNum AS [رقم الكرسى], Appointments.Price AS [المبلغ],Appointments.Status as [الحالة],Appointments.Accepted AS [تم الموافقة],Appointments.Period\r\nFROM         Appointments INNER JOIN\r\n                      PatientData ON Appointments.PatuentID = PatientData.ID INNER JOIN\r\n                      Empdata ON Appointments.DoctorID = Empdata.ID\r\nWHERE     (Appointments.Done = 0) and PatientData.PName like '%" + codes.SearchText("اسم المريض") + "%'") : dc.GetTableText("SELECT     Appointments.ID, Appointments.AppointNum AS [Appointment No.], PatientData.PName AS [Patient Name], Empdata.Name AS [Doctor Name], \r\n                      Appointments.detectDate AS [Date], Appointments.detectStartTime AS [From], Appointments.detectEndTime AS [TO], Appointments.packDate AS [Recall Due], \r\n                      Appointments.ExpDate AS [Reg.Expires], Appointments.ChairNum AS [Chair Number], Appointments.Price AS [Price],Appointments.Status as [Status],Appointments.Accepted AS [Approved],Appointments.Period\r\nFROM         Appointments INNER JOIN\r\n                      PatientData ON Appointments.PatuentID = PatientData.ID INNER JOIN\r\n                      Empdata ON Appointments.DoctorID = Empdata.ID\r\nWHERE     (Appointments.Done = 0) and PatientData.PName like '%" + codes.SearchText("Patient Name") + "%'"));
				gui.loadDataGrid(dataGridView1, dataTable);
				dataGridView1.Columns[13].Visible = false;
				DataGrid();
			}
			catch
			{
			}
		}

		private void PatientComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				try
				{
					DataTable dataTable = codes.Search2("select isnull(sum(Daen),0) from PatientBeforePay where PatientID=" + PatientComboBox.SelectedValue);
					Rased.Text = Math.Round(Convert.ToDecimal(dataTable.Rows[0][0]), 2).ToString();
				}
				catch
				{
				}
				dataGridView2.DataSource = null;
				dataGridView2.Rows.Clear();
				priceTextBox.Text = "0";
				DataTable dataTable2 = codes.Search2(string.Concat("SELECT Company.Name,PatientData.Accept,PatientData.DoctoreName FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID WHERE (PatientData.ID ='", PatientComboBox.SelectedValue, "')"));
				textBox1.Text = dataTable2.Rows[0][0].ToString();
				doctorcomboBox.Text = dataTable2.Rows[0][2].ToString();
				dataTable2.Rows[0][1].ToString();
				try
				{
					groupBox6.Visible = Convert.ToBoolean(dataTable2.Rows[0][1].ToString());
				}
				catch
				{
					groupBox6.Visible = false;
				}
				try
				{
					DataTable dataTable3 = codes.Search2("select id from Empdata where name='" + dataTable2.Rows[0][2].ToString() + "' and Designation='Doctor'");
					doctorcomboBox.SelectedValue = dataTable3.Rows[0][0].ToString();
				}
				catch
				{
				}
				DataTable tableText = dc.GetTableText(string.Concat("select Dariba from PatientData where ID = '", PatientComboBox.SelectedValue, "'"));
				if (tableText.Rows[0][0].ToString() == "" || !Convert.ToBoolean(tableText.Rows[0][0].ToString()))
				{
					textBox6.Text = "0";
					AfterDariba.Text = "0";
					Dariba.Text = "0";
					priceTextBox_TextChanged(sender, e);
				}
				else
				{
					textBox7.Visible = true;
					AfterDariba.Visible = true;
					string text = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
					DataTable dataTable4 = codes.Search2("SELECT dbo.CompanyService.Price , dbo.CompanyService.Dariba FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + textBox1.Text + "' and Service = '" + text + "' ");
					if (dataTable4.Rows.Count != 0)
					{
						priceTextBox.Text = dataTable4.Rows[0][0].ToString();
						textBox6.Text = dataTable4.Rows[0][1].ToString();
						priceTextBox_TextChanged(sender, e);
					}
				}
				commentTextBox_SelectedIndexChanged(sender, e);
			}
			catch
			{
			}
			try
			{
				string text = "";
				if (radioButton3.Checked)
				{
					try
					{
						text = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
					}
					catch
					{
					}
				}
				else
				{
					text = codes.Search2("select ServiceDetect from Properties").Rows[0][0].ToString();
				}
				DataTable dataTable = codes.Search2("SELECT dbo.Company.Name,dbo.Company.ID,dbo.Company.Status,dbo.Company.Discount,dbo.Company.Nesba\r\nFROM         dbo.Company INNER JOIN\r\n                      dbo.PatientData ON dbo.Company.ID = dbo.PatientData.company where PatientData.ID='" + PatientComboBox.SelectedValue.ToString() + "'");
				string text2 = dataTable.Rows[0][2].ToString();
				companyId = dataTable.Rows[0][1].ToString();
				DataTable dataTable5 = codes.Search2("select Price from CompanyService where Service='" + text + "'");
				priceTextBox.Text = dataTable5.Rows[0][0].ToString();
				if (dataTable5.Rows.Count > 0)
				{
					if (text2 == "1")
					{
						if (Convert.ToBoolean(dataTable.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable5.Rows[0][0]) * Convert.ToDouble(dataTable.Rows[0][3]) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = Convert.ToDouble(dataTable.Rows[0][3]).ToString();
						}
						priceTextBox.Text = (Convert.ToDouble(dataTable5.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text2 == "2")
					{
						string text3 = codes.Search2("SELECT distinct isnull(dbo.DiscountCategory.Discount,0)\r\nFROM         dbo.CompanyService INNER JOIN\r\n                      dbo.Categories ON dbo.CompanyService.CompanyID = dbo.Categories.ID INNER JOIN\r\n                      dbo.DiscountCategory ON dbo.Categories.Name = dbo.DiscountCategory.Category where CompanyService.Service = '" + text + "'").Rows[0][0].ToString();
						if (Convert.ToBoolean(dataTable.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable5.Rows[0][0]) * Convert.ToDouble(text3) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = text3;
						}
						priceTextBox.Text = (Convert.ToDouble(dataTable5.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text2 == "3")
					{
						string text3 = codes.Search2("SELECT     isnull(Discount,0)\r\nFROM         dbo.DiscountService where Service = '" + text + "'").Rows[0][0].ToString();
						if (Convert.ToBoolean(dataTable.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable5.Rows[0][0]) * Convert.ToDouble(text3) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = text3;
						}
						priceTextBox.Text = (Convert.ToDouble(dataTable5.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text2 == "4")
					{
						priceTextBox.Text = dataTable5.Rows[0][0].ToString();
						CompanyPrice = "0";
					}
				}
				else
				{
					priceTextBox.Text = "0";
				}
			}
			catch
			{
			}
			commentTextBox_SelectedIndexChanged(sender, e);
			try
			{
				DataTable dataTable6 = codes.Search2("select isnull(sum(Price-PricePay),0) from PatientAccount where PatientId=" + PatientComboBox.SelectedValue);
				label20.Text = "الرصيد السابق: " + Math.Round(Convert.ToDecimal(dataTable6.Rows[0][0]), 2);
			}
			catch
			{
			}
		}

		private void Appointments_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void StatusCom_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (StatusCom.SelectedIndex == 0)
			{
				StatusPanel.BackColor = Color.FromArgb(143, 213, 245);
			}
			else if (StatusCom.SelectedIndex == 1)
			{
				StatusPanel.BackColor = Color.YellowGreen;
			}
			else if (StatusCom.SelectedIndex == 2)
			{
				StatusPanel.BackColor = Color.Transparent;
			}
			else if (StatusCom.SelectedIndex == 3)
			{
				StatusPanel.BackColor = Color.FromArgb(230, 119, 96);
			}
			else if (StatusCom.SelectedIndex == 4)
			{
				StatusPanel.BackColor = Color.BlueViolet;
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dt = dc.Select("SelectAllAppointment");
				gui.loadDataGrid(dataGridView1, dt);
				dataGridView1.Columns[13].Visible = false;
				DataGrid();
			}
			catch
			{
			}
			clear();
			try
			{
				priceTextBox.Text = "0";
				DataTable dt = codes.Search2(string.Concat("SELECT Company.Name,PatientData.Accept,DoctoreName FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID WHERE (PatientData.ID ='", PatientComboBox.SelectedValue, "')"));
				textBox1.Text = dt.Rows[0][0].ToString();
				doctorcomboBox.Text = dt.Rows[0][2].ToString();
				try
				{
					groupBox6.Visible = Convert.ToBoolean(dt.Rows[0][1].ToString());
				}
				catch
				{
					groupBox6.Visible = false;
				}
				try
				{
					DataTable dataTable = codes.Search2("select id from Empdata where name='" + dt.Rows[0][2].ToString() + "' and Designation='Doctor'");
					doctorcomboBox.SelectedValue = dataTable.Rows[0][0].ToString();
				}
				catch
				{
				}
				DataTable dataTable2 = codes.Search2("select ServiceName from Properties ");
				string text = dataTable2.Rows[0][0].ToString();
				DataTable dataTable3 = codes.Search2("SELECT dbo.CompanyService.Price FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + textBox1.Text + "' and Service = '" + text + "' ");
				if (dt.Rows.Count != 0)
				{
					priceTextBox.Text = dataTable3.Rows[0][0].ToString();
				}
				else
				{
					priceTextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void groupBox5_Enter(object sender, EventArgs e)
		{
		}

		private void doctorcomboBox_SelectedValueChanged(object sender, EventArgs e)
		{
			try
			{
				if (!flag)
				{
					AppointCount();
				}
			}
			catch
			{
			}
		}

		private void recalldateTimePicker2_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				AppointCount();
			}
			catch
			{
			}
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBox1.Checked)
				{
					DataTable dataTable = codes.Search2(string.Concat("select id,pname from PatientData where company='", comboBox1.SelectedValue, "' and Active = 'True'"));
					PatientComboBox.DataSource = dataTable;
					PatientComboBox.ValueMember = dataTable.Columns[0].ToString();
					PatientComboBox.DisplayMember = dataTable.Columns[1].ToString();
				}
			}
			catch
			{
			}
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (!checkBox1.Checked)
				{
					DataTable dt = dc.Select("SelectAllPatient");
					gui.loadComboBox(PatientComboBox, dt);
				}
			}
			catch
			{
			}
		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBox1.Checked && radioButton1.Checked)
				{
					DataTable dataTable = codes.Search2("select id,pname from PatientData where Mob like '%" + textBox2.Text + "%' and Active = 'True'");
					PatientComboBox.DataSource = dataTable;
					PatientComboBox.ValueMember = dataTable.Columns[0].ToString();
					PatientComboBox.DisplayMember = dataTable.Columns[1].ToString();
				}
			}
			catch
			{
			}
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
		}

		private void PatientComboBox_TextChanged(object sender, EventArgs e)
		{
		}

		private void button2_Click(object sender, EventArgs e)
		{
			if (PatientComboBox.SelectedItem != null && PatientComboBox.Text != "")
			{
				FrmCompaniesServicesPrices frmCompaniesServicesPrices = new FrmCompaniesServicesPrices();
				frmCompaniesServicesPrices.ShowDialog();
				try
				{
					DataTable dataTable = codes.Search2("SELECT distinct dbo.Categories.ID, dbo.Categories.Name\r\nFROM         dbo.CompanyService INNER JOIN\r\n                      dbo.Categories ON dbo.CompanyService.CompanyID = dbo.Categories.ID");
					comboCategory.DataSource = dataTable;
					comboCategory.ValueMember = dataTable.Columns[0].ToString();
					comboCategory.DisplayMember = dataTable.Columns[1].ToString();
				}
				catch
				{
				}
				comboCategory_SelectedIndexChanged(sender, e);
			}
			else if (Settings.Default.Language == "en-GB")
			{
				MessageBox.Show("please choose patient name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else
			{
				MessageBox.Show("من فضلك اختر اسم المريض", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		}

		private void textBox4_TextChanged(object sender, EventArgs e)
		{
			try
			{
				Convert.ToDecimal(textBox4.Text);
			}
			catch
			{
				textBox4.Text = "0.000";
			}
			if (textBox4.Text == "" || textBox4.Text == "0.000")
			{
				commentTextBox_SelectedIndexChanged(sender, e);
			}
			else
			{
				AfterDariba.Text = Convert.ToString(Math.Round(Convert.ToDecimal(textBox4.Text) + Convert.ToDecimal(textBox4.Text) * Convert.ToDecimal(Dariba.Text) / 100m, 2));
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("SELECT     dbo.Appointments.DoctorID, dbo.Appointments.detectDate, dbo.Appointments.detectStartTime, dbo.Appointments.detectEndTime, dbo.ReserveService.Bean\r\nFROM         dbo.Appointments INNER JOIN\r\n                      dbo.ReserveService ON dbo.Appointments.ID = dbo.ReserveService.AppointNum where dbo.Appointments.detectDate = '" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "' and  dbo.Appointments.detectStartTime = '" + FromTextBox.Text + "' and dbo.Appointments.detectEndTime = '" + TOTextBox.Text + "' and dbo.ReserveService.Bean ='" + commentTextBox.Text + "' and dbo.Appointments.DoctorID ='" + doctorcomboBox.SelectedIndex + "'");
				if (doctorcomboBox.SelectedItem == null)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please choose Doctor name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم الطبيب", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					return;
				}
				if (commentTextBox.Text == "" || commentTextBox.SelectedItem == null)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Service name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الخدمة");
					}
					return;
				}
				if (dataTable.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Done This Service Before");
					}
					else
					{
						MessageBox.Show("تم عمل حجز لهذه الخدمة من قبل");
					}
					return;
				}
				if (dataGridView2.Rows.Count == 0)
				{
					dataGridView2.Rows.Add(commentTextBox.Text, textBox4.Text, CompanyPrice, Dariba.Text, AfterDariba.Text);
					Total = Convert.ToDecimal(textBox5.Text);
					Total += Convert.ToDecimal(textBox4.Text);
					textBox5.Text = Total.ToString();
					commentTextBox.Text = "";
					textBox4.Text = "0";
					return;
				}
				int num = 0;
				while (true)
				{
					if (num >= dataGridView2.Rows.Count)
					{
						return;
					}
					string text = commentTextBox.Text;
					string value = dataGridView2.Rows[num].Cells[0].Value.ToString();
					if (!text.Equals(value))
					{
						if (num == dataGridView2.Rows.Count - 1)
						{
							break;
						}
						num++;
						continue;
					}
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Entered This Service Before");
					}
					else
					{
						MessageBox.Show("هذه الخدمة تم ادخاله من قبل");
					}
					commentTextBox.Text = "";
					textBox4.Text = "0";
					return;
				}
				dataGridView2.Rows.Add(commentTextBox.Text, textBox4.Text, CompanyPrice, Dariba.Text, AfterDariba.Text);
				Total = Convert.ToDecimal(textBox5.Text);
				Total += Convert.ToDecimal(textBox4.Text);
				textBox5.Text = Total.ToString();
				commentTextBox.Text = "";
				textBox4.Text = "0";
			}
			catch
			{
			}
		}

		private void dataGridView2_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
			try
			{
				Total = 0m;
				if (dataGridView2.Rows.Count > 0)
				{
					for (int i = 0; i < dataGridView2.Rows.Count; i++)
					{
						Total += Convert.ToDecimal(dataGridView2.Rows[i].Cells[4].Value.ToString());
						textBox5.Text = Total.ToString();
					}
				}
				else
				{
					textBox5.Text = Total.ToString();
				}
			}
			catch
			{
			}
		}

		private void commentTextBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			decimal num = 0m;
			decimal num2 = 0m;
			try
			{
				DataTable dataTable = codes.Search2("SELECT dbo.Company.Name,dbo.Company.ID,dbo.Company.Status,dbo.Company.Discount,dbo.Company.Nesba\r\nFROM         dbo.Company INNER JOIN\r\n                      dbo.PatientData ON dbo.Company.ID = dbo.PatientData.company where PatientData.ID='" + PatientComboBox.SelectedValue.ToString() + "'");
				string text = dataTable.Rows[0][2].ToString();
				DataTable dataTable2 = codes.Search2(string.Concat("select Price,Dariba from CompanyService where Service='", commentTextBox.Text, "' and CompanyID = '", comboCategory.SelectedValue, "'"));
				textBox4.Text = dataTable2.Rows[0][0].ToString();
				if (dataTable2.Rows.Count > 0)
				{
					if (text == "1")
					{
						if (Convert.ToBoolean(dataTable.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(dataTable.Rows[0][3]) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = Convert.ToDouble(dataTable.Rows[0][3]).ToString();
						}
						textBox4.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text == "2")
					{
						string text2 = codes.Search2("SELECT dbo.DiscountCategory.Discount FROM DiscountCategory where Category = '" + comboCategory.Text + "'").Rows[0][0].ToString();
						if (Convert.ToBoolean(dataTable.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(text2) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = text2;
						}
						textBox4.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text == "3")
					{
						DataTable dataTable3 = codes.Search2("SELECT     Discount\r\nFROM         dbo.DiscountService where Service = '" + commentTextBox.Text + "'");
						if (dataTable3.Rows.Count > 0)
						{
							string text2 = dataTable3.Rows[0][0].ToString();
							if (Convert.ToBoolean(dataTable.Rows[0]["Nesba"].ToString()))
							{
								CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(text2) / 100.0).ToString();
							}
							else
							{
								CompanyPrice = text2;
							}
							textBox4.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
						}
						else
						{
							textBox4.Text = dataTable2.Rows[0][0].ToString();
							textBox4.Enabled = true;
							CompanyPrice = "0";
						}
					}
					if (text == "4")
					{
						textBox4.Text = dataTable2.Rows[0][0].ToString();
						CompanyPrice = "0";
						DataTable dataTable4 = codes.Search2("select ChangeServicePrice from users where userName ='" + Main.usernames + "' and userPassward ='" + Main.passward + "'");
						textBox4.Enabled = Convert.ToBoolean(dataTable4.Rows[0][0].ToString());
					}
				}
				else
				{
					textBox4.Text = dataTable2.Rows[0][0].ToString();
					textBox4.Enabled = true;
				}
				DataTable tableText = dc.GetTableText(string.Concat("select Dariba from PatientData where ID = '", PatientComboBox.SelectedValue, "'"));
				if (tableText.Rows.Count > 0)
				{
					if (tableText.Rows[0][0].ToString() == "" || !Convert.ToBoolean(tableText.Rows[0][0].ToString()))
					{
						AfterDariba.Text = "0";
						Dariba.Text = "0";
						num = Math.Round(Convert.ToDecimal(textBox4.Text) + Convert.ToDecimal(textBox4.Text) * Convert.ToDecimal(Dariba.Text) / 100m, 2);
					}
					else
					{
						Dariba.Text = dataTable2.Rows[0][1].ToString();
						num = Math.Round(Convert.ToDecimal(textBox4.Text) + Convert.ToDecimal(textBox4.Text) * Convert.ToDecimal(Dariba.Text) / 100m, 2);
					}
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable5 = codes.Search2(string.Concat("select DiscountNesba,DiscountValue from CompanyService where Service='", commentTextBox.Text, "' and CompanyID = '", comboCategory.SelectedValue, "'"));
				if (Convert.ToDecimal(dataTable5.Rows[0][0].ToString()) != 0m)
				{
					num2 = Math.Round(num - num * Convert.ToDecimal(dataTable5.Rows[0][0].ToString()) / 100m);
					if (Settings.Default.Language == "en-GB")
					{
						label14.Text = "Discount%";
					}
					else
					{
						label14.Text = "نسبة الخصم";
					}
					textBox8.Text = dataTable5.Rows[0][0].ToString();
					AfterDariba.Text = num2.ToString();
				}
				else if (Convert.ToDecimal(dataTable5.Rows[0][1].ToString()) != 0m)
				{
					num2 = Math.Round(num - Convert.ToDecimal(dataTable5.Rows[0][1].ToString()));
					if (Settings.Default.Language == "en-GB")
					{
						label14.Text = "Discount";
					}
					else
					{
						label14.Text = "قيمة الخصم";
					}
					textBox8.Text = dataTable5.Rows[0][1].ToString();
					AfterDariba.Text = num2.ToString();
				}
				else
				{
					if (Settings.Default.Language == "en-GB")
					{
						label14.Text = "Discount";
					}
					else
					{
						label14.Text = "الخصم";
					}
					textBox8.Text = "0";
					AfterDariba.Text = num.ToString();
				}
			}
			catch
			{
			}
		}

		private void commentTextBox_Click(object sender, EventArgs e)
		{
		}

		private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && priceTextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك أدخل أرقام فقط");
				}
				e.Handled = true;
			}
			catch
			{
			}
		}

		private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && priceTextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك أدخل أرقام فقط");
				}
				e.Handled = true;
			}
			catch
			{
			}
		}

		private void checkBox3_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox3.Checked)
			{
				PaidPanel.Visible = true;
				PayNaqdy.Visible = true;
				PayBefore.Visible = true;
			}
			else
			{
				label69.Visible = false;
				PaidPanel.Visible = false;
				PayNaqdy.Visible = false;
				PayBefore.Visible = false;
			}
		}

		private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				commentTextBox.DataSource = null;
				string text = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
				string text2 = codes.Search2("select ServiceDetect from Properties").Rows[0][0].ToString();
				DataTable dataTable = codes.Search2(string.Concat("select Service from CompanyService where CompanyID = '", comboCategory.SelectedValue, "' and Service != '", text, "' and Service != '", text2, "'"));
				commentTextBox.DataSource = dataTable;
				commentTextBox.DisplayMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void button4_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = ((!(Settings.Default.Language == "en-GB")) ? dc.GetTableText("SELECT     Appointments.ID, Appointments.AppointNum AS [رقم الحجز], PatientData.PName AS [اسم المريض], Empdata.Name AS [اسم الطبيب], \r\n                      Appointments.detectDate AS [تاريخ الحجز], Appointments.detectStartTime AS [من], Appointments.detectEndTime AS [الى], Appointments.packDate AS [تاريخ إعادة الكشف], \r\n                      Appointments.ExpDate AS [تاريخ انتهاء الحجز], Appointments.ChairNum AS [رقم الكرسى], Appointments.Price AS [المبلغ],Appointments.Status as [الحالة],Appointments.Accepted AS [تم الموافقة],Appointments.Period\r\nFROM         Appointments INNER JOIN\r\n                      PatientData ON Appointments.PatuentID = PatientData.ID INNER JOIN\r\n                      Empdata ON Appointments.DoctorID = Empdata.ID\r\nWHERE     (Appointments.Done = 0) and PatientData.FileNo = '" + codes.SearchText("كود المريض") + "'") : dc.GetTableText("SELECT     Appointments.ID, Appointments.AppointNum AS [Appointment No.], PatientData.PName AS [Patient Name], Empdata.Name AS [Doctor Name], \r\n                      Appointments.detectDate AS [Date], Appointments.detectStartTime AS [From], Appointments.detectEndTime AS [TO], Appointments.packDate AS [Recall Due], \r\n                      Appointments.ExpDate AS [Reg.Expires], Appointments.ChairNum AS [Chair Number], Appointments.Price AS [Price],Appointments.Status as [Status],Appointments.Accepted AS [Approved],Appointments.Period\r\nFROM         Appointments INNER JOIN\r\n                      PatientData ON Appointments.PatuentID = PatientData.ID INNER JOIN\r\n                      Empdata ON Appointments.DoctorID = Empdata.ID\r\nWHERE     (Appointments.Done = 0) and PatientData.FileNo like '" + codes.SearchText("Patient Code") + "'"));
				gui.loadDataGrid(dataGridView1, dataTable);
				dataGridView1.Columns[13].Visible = false;
				DataGrid();
			}
			catch
			{
			}
		}

		private void radioButton3_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				string text = "";
				if (radioButton3.Checked)
				{
					DataTable dataTable = codes.Search2("select ServiceName from Properties");
					text = dataTable.Rows[0][0].ToString();
				}
				else
				{
					DataTable dataTable = codes.Search2("select ServiceDetect from Properties");
					text = dataTable.Rows[0][0].ToString();
				}
				DataTable dataTable2 = codes.Search2("SELECT dbo.CompanyService.Price FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + textBox1.Text + "' and Service = '" + text + "' ");
				if (dataTable2.Rows.Count != 0)
				{
					priceTextBox.Text = dataTable2.Rows[0][0].ToString();
				}
				else
				{
					priceTextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			try
			{
				FrmPackDate frmPackDate = new FrmPackDate(dtPackDate);
				frmPackDate.ShowDialog();
			}
			catch
			{
			}
		}

		private void FromTextBox_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select AppointSystem,AppointPeriod from Properties");
				if (dataTable.Rows[0][0].ToString() == "1")
				{
					TOTextBox.Value = FromTextBox.Value.AddMinutes(Convert.ToInt32(dataTable.Rows[0][1].ToString()));
					string text = TOTextBox.Value.ToString("HH:mm");
					try
					{
						maskedTextBox2.Text = text;
					}
					catch
					{
					}
				}
			}
			catch
			{
			}
		}

		private void maskedTextBox1_TextChanged(object sender, EventArgs e)
		{
			try
			{
				FromTextBox.Text = maskedTextBox1.Text;
			}
			catch
			{
			}
		}

		private void maskedTextBox2_TextChanged(object sender, EventArgs e)
		{
			try
			{
				TOTextBox.Text = maskedTextBox2.Text;
			}
			catch
			{
			}
		}

		private void button6_Click(object sender, EventArgs e)
		{
			try
			{
				FrmSurgeryDate frmSurgeryDate = new FrmSurgeryDate(PatientComboBox.SelectedValue.ToString(), doctorcomboBox.SelectedValue.ToString());
				frmSurgeryDate.Show();
			}
			catch
			{
			}
		}

		private void EsalNoTxt_KeyPress(object sender, KeyPressEventArgs e)
		{
			if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
			{
				if (e.KeyChar == '.' && EsalNoTxt.Text.Contains("."))
				{
					e.Handled = true;
				}
			}
			else
			{
				e.Handled = true;
				MessageBox.Show("من فضلك أدخل رقم الإيصال بالارقام");
			}
		}

		private void priceTextBox_TextChanged(object sender, EventArgs e)
		{
			try
			{
				decimal num = 0m;
				decimal num2 = 0m;
				DataTable dataTable = codes.Search2("select ServiceName from Properties");
				string text = dataTable.Rows[0][0].ToString();
				if (priceTextBox.Text == "" || priceTextBox.Text == "0")
				{
					DataTable dataTable2 = codes.Search2("SELECT dbo.CompanyService.Price , dbo.CompanyService.Dariba FROM dbo.Company INNER JOIN dbo.CompanyService ON dbo.Company.ID = dbo.CompanyService.CompanyID where dbo.Company.Name = '" + textBox1.Text + "' and Service = '" + text + "' ");
					if (dataTable2.Rows.Count != 0)
					{
						priceTextBox.Text = dataTable2.Rows[0][0].ToString();
					}
				}
				num = Math.Round(Convert.ToDecimal(priceTextBox.Text) + Convert.ToDecimal(priceTextBox.Text) * Convert.ToDecimal(textBox6.Text) / 100m, 2);
				if (label105.Text == "Discount%" || label105.Text == "نسبة الخصم")
				{
					num2 = Math.Round(num - num * Convert.ToDecimal(textBoxDiscount.Text) / 100m);
					textBox7.Text = num2.ToString();
				}
				else if (label105.Text == "Discount" || label105.Text == "قيمة الخصم")
				{
					num2 = Math.Round(num - Convert.ToDecimal(textBoxDiscount.Text));
					textBox7.Text = num2.ToString();
				}
			}
			catch
			{
			}
		}

		private void textBoxDiscount_TextChanged(object sender, EventArgs e)
		{
			try
			{
				if (Convert.ToDecimal(priceTextBox.Text) == 0m)
				{
					MessageBox.Show("لا يمكن عمل خصم والمبلغ = صفر");
					return;
				}
				if (textBoxDiscount.Text == "")
				{
					textBoxDiscount.Text = "0";
				}
				decimal num = 0m;
				decimal num2 = 0m;
				num = Math.Round(Convert.ToDecimal(priceTextBox.Text) + Convert.ToDecimal(priceTextBox.Text) * Convert.ToDecimal(textBox6.Text) / 100m, 2);
				if (label105.Text == "Discount%" || label105.Text == "نسبة الخصم")
				{
					num2 = Math.Round(num - num * Convert.ToDecimal(textBoxDiscount.Text) / 100m);
					textBox7.Text = num2.ToString();
				}
				else if (label105.Text == "Discount" || label105.Text == "قيمة الخصم")
				{
					num2 = Math.Round(num - Convert.ToDecimal(textBoxDiscount.Text));
					textBox7.Text = num2.ToString();
				}
			}
			catch
			{
			}
		}

		private void button7_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				try
				{
					dataTable = dc.Select("SelectAllPatient");
					listBox1.DataSource = dataTable;
					listBox1.DisplayMember = dataTable.Columns[1].ToString();
					listBox1.ValueMember = dataTable.Columns[0].ToString();
				}
				catch
				{
				}
				searchGrop.Visible = true;
			}
			catch
			{
			}
		}

		private void button8_Click(object sender, EventArgs e)
		{
		}

		private void button10_Click(object sender, EventArgs e)
		{
			textBox9.Text = "";
			searchGrop.Visible = false;
		}

		private void textBox9_TextChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = ((!(textBox9.Text == "")) ? codes.Search2("select * from PatientData where PName like '%" + textBox9.Text + "%'") : dc.Select("SelectAllPatient"));
				listBox1.DataSource = dataTable;
				listBox1.DisplayMember = dataTable.Columns[2].ToString();
				listBox1.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void textBox9_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
		{
			if (e.KeyCode == Keys.Down)
			{
				listBox1.Focus();
			}
		}

		private void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
		{
			try
			{
				PatientComboBox.SelectedValue = listBox1.SelectedValue;
				textBox9.Text = "";
				searchGrop.Visible = false;
			}
			catch
			{
			}
		}

		private void textBox10_TextChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBox1.Checked && radioButton5.Checked)
				{
					DataTable dataTable = codes.Search2("select id,pname from PatientData where FileNo like '%" + textBox10.Text + "%' and Active = 'True'");
					PatientComboBox.DataSource = dataTable;
					PatientComboBox.ValueMember = dataTable.Columns[0].ToString();
					PatientComboBox.DisplayMember = dataTable.Columns[1].ToString();
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_SelectionChanged(object sender, EventArgs e)
		{
		}

		private void PayNaqdy_CheckedChanged(object sender, EventArgs e)
		{
			if (PayNaqdy.Checked)
			{
				DataTable dataTable = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				if (dataTable.Rows.Count > 0)
				{
					label69.Visible = true;
					comboBox7.Visible = true;
					PaidPanel.Visible = true;
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please add Treasury validity");
				}
				else
				{
					MessageBox.Show("من فضلك اضف صلاحية للخزينة");
				}
			}
		}

		private void PayBefore_CheckedChanged(object sender, EventArgs e)
		{
			if (PayBefore.Checked && (Rased.Text == "0.00" || Rased.Text == "0"))
			{
				MessageBox.Show("لا يمكن الدفع من رصيد سابق لان الرصيد السابق للمريض بصفر");
			}
		}

		private void label110_Click(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Appointments));
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.PayNaqdy = new System.Windows.Forms.RadioButton();
            this.PayBefore = new System.Windows.Forms.RadioButton();
            this.label18 = new System.Windows.Forms.Label();
            this.Rased = new System.Windows.Forms.TextBox();
            this.StatusPanel = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.StatusCom = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.textBoxDiscount = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.appdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.PaidPanel = new System.Windows.Forms.Panel();
            this.EsalNoTxt = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.TOTextBox = new System.Windows.Forms.DateTimePicker();
            this.FromTextBox = new System.Windows.Forms.DateTimePicker();
            this.button5 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.label69 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.apptextBox = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.recalldateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.regdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.ChairTextBox = new System.Windows.Forms.TextBox();
            this.doctorcomboBox = new System.Windows.Forms.ComboBox();
            this.label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PatientComboBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.searchGrop = new System.Windows.Forms.GroupBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button10 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.EditBtn = new System.Windows.Forms.Button();
            this.saveBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.DeletBtn = new System.Windows.Forms.Button();
            this.Searchbtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
            this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Dariba = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.AfterDariba = new System.Windows.Forms.TextBox();
            this.comboCategory = new System.Windows.Forms.ComboBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CompanyCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.commentTextBox = new System.Windows.Forms.ComboBox();
            this.dataSet11 = new DataSet1();
            this.sqlConnection2 = new System.Data.SqlClient.SqlConnection();
            this.sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
            this.sqlCommand2 = new System.Data.SqlClient.SqlCommand();
            this.sqlCommand3 = new System.Data.SqlClient.SqlCommand();
            this.groupBox4.SuspendLayout();
            this.PaidPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.searchGrop.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).BeginInit();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Firebrick;
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(122, 292);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 16);
            this.label9.TabIndex = 35;
            this.label9.Text = "المدفوع :";
            this.label9.Visible = false;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.PayNaqdy);
            this.groupBox4.Controls.Add(this.PayBefore);
            this.groupBox4.Controls.Add(this.Rased);
            this.groupBox4.Controls.Add(this.StatusPanel);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.button7);
            this.groupBox4.Controls.Add(this.StatusCom);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label105);
            this.groupBox4.Controls.Add(this.textBoxDiscount);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.appdateTimePicker1);
            this.groupBox4.Controls.Add(this.textBox7);
            this.groupBox4.Controls.Add(this.PaidPanel);
            this.groupBox4.Controls.Add(this.textBox6);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.txtUserName);
            this.groupBox4.Controls.Add(this.maskedTextBox2);
            this.groupBox4.Controls.Add(this.maskedTextBox1);
            this.groupBox4.Controls.Add(this.TOTextBox);
            this.groupBox4.Controls.Add(this.FromTextBox);
            this.groupBox4.Controls.Add(this.button5);
            this.groupBox4.Controls.Add(this.panel1);
            this.groupBox4.Controls.Add(this.label69);
            this.groupBox4.Controls.Add(this.comboBox7);
            this.groupBox4.Controls.Add(this.textBox3);
            this.groupBox4.Controls.Add(this.checkBox3);
            this.groupBox4.Controls.Add(this.comboBox2);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.checkBox2);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.apptextBox);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.textBox1);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.recalldateTimePicker2);
            this.groupBox4.Controls.Add(this.priceTextBox);
            this.groupBox4.Controls.Add(this.regdateTimePicker1);
            this.groupBox4.Controls.Add(this.ChairTextBox);
            this.groupBox4.Controls.Add(this.doctorcomboBox);
            this.groupBox4.Controls.Add(this.label);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.PatientComboBox);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Font = new System.Drawing.Font("Arial", 11.25F);
            this.groupBox4.ForeColor = System.Drawing.Color.Black;
            this.groupBox4.Location = new System.Drawing.Point(12, 48);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox4.Size = new System.Drawing.Size(759, 334);
            this.groupBox4.TabIndex = 76;
            this.groupBox4.TabStop = false;
            // 
            // PayNaqdy
            // 
            this.PayNaqdy.AutoSize = true;
            this.PayNaqdy.BackColor = System.Drawing.Color.Transparent;
            this.PayNaqdy.Checked = true;
            this.PayNaqdy.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.PayNaqdy.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PayNaqdy.Location = new System.Drawing.Point(151, 238);
            this.PayNaqdy.Name = "PayNaqdy";
            this.PayNaqdy.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.PayNaqdy.Size = new System.Drawing.Size(76, 20);
            this.PayNaqdy.TabIndex = 176;
            this.PayNaqdy.TabStop = true;
            this.PayNaqdy.Text = "مدفوع نقدي";
            this.PayNaqdy.UseVisualStyleBackColor = false;
            this.PayNaqdy.Visible = false;
            this.PayNaqdy.CheckedChanged += new System.EventHandler(this.PayNaqdy_CheckedChanged);
            // 
            // PayBefore
            // 
            this.PayBefore.AutoSize = true;
            this.PayBefore.BackColor = System.Drawing.Color.Transparent;
            this.PayBefore.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.PayBefore.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PayBefore.Location = new System.Drawing.Point(19, 238);
            this.PayBefore.Name = "PayBefore";
            this.PayBefore.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.PayBefore.Size = new System.Drawing.Size(123, 20);
            this.PayBefore.TabIndex = 175;
            this.PayBefore.Text = "مدفوع من رصيد سابق";
            this.PayBefore.UseVisualStyleBackColor = false;
            this.PayBefore.Visible = false;
            this.PayBefore.CheckedChanged += new System.EventHandler(this.PayBefore_CheckedChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label18.Location = new System.Drawing.Point(175, 55);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(72, 16);
            this.label18.TabIndex = 140;
            this.label18.Text = "السعر النهائي:";
            this.label18.Click += new System.EventHandler(this.label110_Click);
            // 
            // Rased
            // 
            this.Rased.BackColor = System.Drawing.Color.White;
            this.Rased.ForeColor = System.Drawing.Color.Black;
            this.Rased.Location = new System.Drawing.Point(508, 77);
            this.Rased.Name = "Rased";
            this.Rased.ReadOnly = true;
            this.Rased.Size = new System.Drawing.Size(161, 25);
            this.Rased.TabIndex = 173;
            this.Rased.Text = "0";
            this.Rased.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // StatusPanel
            // 
            this.StatusPanel.BackColor = System.Drawing.Color.LightCoral;
            this.StatusPanel.Location = new System.Drawing.Point(434, 284);
            this.StatusPanel.Name = "StatusPanel";
            this.StatusPanel.Size = new System.Drawing.Size(43, 22);
            this.StatusPanel.TabIndex = 27;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(676, 287);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 16);
            this.label10.TabIndex = 25;
            this.label10.Text = "الحالة :";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Gainsboro;
            this.button7.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.button7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button7.Location = new System.Drawing.Point(162, 44);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(118, 26);
            this.button7.TabIndex = 164;
            this.button7.Text = "بحث بجزء من إسم المريض";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // StatusCom
            // 
            this.StatusCom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.StatusCom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.StatusCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StatusCom.Font = new System.Drawing.Font("Arial", 9.75F);
            this.StatusCom.FormattingEnabled = true;
            this.StatusCom.Items.AddRange(new object[] {
            "لم يؤكد",
            "تم التأكيد",
            "تم تعديله",
            "تم إلغاؤه",
            "تم الكشف"});
            this.StatusCom.Location = new System.Drawing.Point(483, 284);
            this.StatusCom.Name = "StatusCom";
            this.StatusCom.Size = new System.Drawing.Size(186, 24);
            this.StatusCom.TabIndex = 26;
            this.StatusCom.SelectedIndexChanged += new System.EventHandler(this.StatusCom_SelectedIndexChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(289, 49);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(52, 16);
            this.label20.TabIndex = 163;
            this.label20.Text = "label20";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label20.Visible = false;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.BackColor = System.Drawing.Color.Transparent;
            this.label105.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label105.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label105.Location = new System.Drawing.Point(297, 203);
            this.label105.Name = "label105";
            this.label105.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label105.Size = new System.Drawing.Size(40, 16);
            this.label105.TabIndex = 162;
            this.label105.Text = "الخصم:";
            // 
            // textBoxDiscount
            // 
            this.textBoxDiscount.Font = new System.Drawing.Font("Arial", 8.25F);
            this.textBoxDiscount.Location = new System.Drawing.Point(202, 200);
            this.textBoxDiscount.Name = "textBoxDiscount";
            this.textBoxDiscount.Size = new System.Drawing.Size(87, 20);
            this.textBoxDiscount.TabIndex = 161;
            this.textBoxDiscount.Text = "0";
            this.textBoxDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxDiscount.TextChanged += new System.EventHandler(this.textBoxDiscount_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label19.Location = new System.Drawing.Point(119, 204);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 16);
            this.label19.TabIndex = 139;
            this.label19.Text = "السعر النهائي:";
            // 
            // appdateTimePicker1
            // 
            this.appdateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.appdateTimePicker1.Font = new System.Drawing.Font("Arial", 11.25F);
            this.appdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.appdateTimePicker1.Location = new System.Drawing.Point(418, 165);
            this.appdateTimePicker1.Name = "appdateTimePicker1";
            this.appdateTimePicker1.RightToLeftLayout = true;
            this.appdateTimePicker1.Size = new System.Drawing.Size(248, 25);
            this.appdateTimePicker1.TabIndex = 138;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Arial", 11.25F);
            this.textBox7.Location = new System.Drawing.Point(32, 195);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(87, 25);
            this.textBox7.TabIndex = 96;
            this.textBox7.Text = "0";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(31, 171);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(21, 14);
            this.label16.TabIndex = 97;
            this.label16.Text = "%";
            // 
            // PaidPanel
            // 
            this.PaidPanel.BackColor = System.Drawing.Color.Transparent;
            this.PaidPanel.Controls.Add(this.EsalNoTxt);
            this.PaidPanel.Controls.Add(this.label45);
            this.PaidPanel.Location = new System.Drawing.Point(177, 264);
            this.PaidPanel.Name = "PaidPanel";
            this.PaidPanel.Size = new System.Drawing.Size(217, 27);
            this.PaidPanel.TabIndex = 88;
            this.PaidPanel.Visible = false;
            // 
            // EsalNoTxt
            // 
            this.EsalNoTxt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.EsalNoTxt.Enabled = false;
            this.EsalNoTxt.Location = new System.Drawing.Point(5, 1);
            this.EsalNoTxt.Name = "EsalNoTxt";
            this.EsalNoTxt.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.EsalNoTxt.Size = new System.Drawing.Size(146, 25);
            this.EsalNoTxt.TabIndex = 147;
            this.EsalNoTxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.EsalNoTxt_KeyPress);
            // 
            // label45
            // 
            this.label45.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Transparent;
            this.label45.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label45.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label45.Location = new System.Drawing.Point(156, 6);
            this.label45.Name = "label45";
            this.label45.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label45.Size = new System.Drawing.Size(59, 16);
            this.label45.TabIndex = 146;
            this.label45.Text = "رقم الايصال";
            // 
            // textBox6
            // 
            this.textBox6.Enabled = false;
            this.textBox6.Font = new System.Drawing.Font("Arial", 11.25F);
            this.textBox6.Location = new System.Drawing.Point(54, 164);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(63, 25);
            this.textBox6.TabIndex = 96;
            this.textBox6.Text = "0";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label17.Location = new System.Drawing.Point(117, 171);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(51, 16);
            this.label17.TabIndex = 95;
            this.label17.Text = "الضريبة :";
            // 
            // txtUserName
            // 
            this.txtUserName.BackColor = System.Drawing.Color.White;
            this.txtUserName.ForeColor = System.Drawing.Color.Maroon;
            this.txtUserName.Location = new System.Drawing.Point(177, 291);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.ReadOnly = true;
            this.txtUserName.Size = new System.Drawing.Size(151, 25);
            this.txtUserName.TabIndex = 136;
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold);
            this.maskedTextBox2.Location = new System.Drawing.Point(418, 194);
            this.maskedTextBox2.Mask = "00:00";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(90, 29);
            this.maskedTextBox2.TabIndex = 135;
            this.maskedTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.maskedTextBox2.ValidatingType = typeof(System.DateTime);
            this.maskedTextBox2.TextChanged += new System.EventHandler(this.maskedTextBox2_TextChanged);
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold);
            this.maskedTextBox1.Location = new System.Drawing.Point(579, 194);
            this.maskedTextBox1.Mask = "00:00";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(90, 29);
            this.maskedTextBox1.TabIndex = 134;
            this.maskedTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.maskedTextBox1.ValidatingType = typeof(System.DateTime);
            this.maskedTextBox1.TextChanged += new System.EventHandler(this.maskedTextBox1_TextChanged);
            // 
            // TOTextBox
            // 
            this.TOTextBox.CustomFormat = "hh:mm";
            this.TOTextBox.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.TOTextBox.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold);
            this.TOTextBox.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TOTextBox.Location = new System.Drawing.Point(22, 134);
            this.TOTextBox.Name = "TOTextBox";
            this.TOTextBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TOTextBox.Size = new System.Drawing.Size(78, 29);
            this.TOTextBox.TabIndex = 133;
            this.TOTextBox.Value = new System.DateTime(2018, 8, 28, 12, 0, 0, 0);
            this.TOTextBox.Visible = false;
            // 
            // FromTextBox
            // 
            this.FromTextBox.CustomFormat = "hh:mm";
            this.FromTextBox.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold);
            this.FromTextBox.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.FromTextBox.Location = new System.Drawing.Point(23, 100);
            this.FromTextBox.Name = "FromTextBox";
            this.FromTextBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.FromTextBox.Size = new System.Drawing.Size(78, 29);
            this.FromTextBox.TabIndex = 132;
            this.FromTextBox.Value = new System.DateTime(2018, 8, 28, 12, 0, 0, 0);
            this.FromTextBox.Visible = false;
            this.FromTextBox.ValueChanged += new System.EventHandler(this.FromTextBox_ValueChanged);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Gainsboro;
            this.button5.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.button5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button5.Location = new System.Drawing.Point(42, 82);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(128, 26);
            this.button5.TabIndex = 131;
            this.button5.Text = "تحديد مواعيد المتابعة";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioButton4);
            this.panel1.Controls.Add(this.radioButton3);
            this.panel1.Location = new System.Drawing.Point(7, 42);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(153, 27);
            this.panel1.TabIndex = 130;
            this.panel1.Visible = false;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioButton4.Location = new System.Drawing.Point(2, 3);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(79, 21);
            this.radioButton4.TabIndex = 130;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "اعادة كشف";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioButton3.AutoSize = true;
            this.radioButton3.Checked = true;
            this.radioButton3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioButton3.Location = new System.Drawing.Point(84, 3);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(52, 21);
            this.radioButton3.TabIndex = 129;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "كشف";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // label69
            // 
            this.label69.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.Transparent;
            this.label69.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label69.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label69.Location = new System.Drawing.Point(675, 257);
            this.label69.Name = "label69";
            this.label69.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label69.Size = new System.Drawing.Size(68, 16);
            this.label69.TabIndex = 128;
            this.label69.Text = "اسم الخزينة :";
            this.label69.Visible = false;
            // 
            // comboBox7
            // 
            this.comboBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox7.Font = new System.Drawing.Font("Arial", 9.75F);
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(418, 254);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboBox7.Size = new System.Drawing.Size(251, 24);
            this.comboBox7.TabIndex = 127;
            this.comboBox7.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.Font = new System.Drawing.Font("Arial", 11.25F);
            this.textBox3.Location = new System.Drawing.Point(19, 287);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(103, 25);
            this.textBox3.TabIndex = 36;
            this.textBox3.Text = "0";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3.Visible = false;
            this.textBox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox3_KeyPress);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.checkBox3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.checkBox3.Location = new System.Drawing.Point(233, 237);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(65, 22);
            this.checkBox3.TabIndex = 33;
            this.checkBox3.Text = "تم الدفع";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.Font = new System.Drawing.Font("Arial", 9.75F);
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "الفترة الصباحية",
            "الفترة المسائية"});
            this.comboBox2.Location = new System.Drawing.Point(418, 227);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(251, 24);
            this.comboBox2.TabIndex = 32;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label12.Location = new System.Drawing.Point(672, 230);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 16);
            this.label12.TabIndex = 31;
            this.label12.Text = "الفترة :";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.checkBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.checkBox2.Location = new System.Drawing.Point(304, 236);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(81, 22);
            this.checkBox2.TabIndex = 30;
            this.checkBox2.Text = "تم الموافقة";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(672, 113);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 16);
            this.label11.TabIndex = 29;
            this.label11.Text = "اسم الشركة :";
            // 
            // apptextBox
            // 
            this.apptextBox.BackColor = System.Drawing.Color.White;
            this.apptextBox.ForeColor = System.Drawing.Color.Maroon;
            this.apptextBox.Location = new System.Drawing.Point(558, 13);
            this.apptextBox.Name = "apptextBox";
            this.apptextBox.ReadOnly = true;
            this.apptextBox.Size = new System.Drawing.Size(111, 25);
            this.apptextBox.TabIndex = 18;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.ForeColor = System.Drawing.Color.Maroon;
            this.textBox1.Location = new System.Drawing.Point(418, 109);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(251, 25);
            this.textBox1.TabIndex = 28;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(295, 171);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 24;
            this.label1.Text = "المبلغ :";
            // 
            // recalldateTimePicker2
            // 
            this.recalldateTimePicker2.CustomFormat = "dd/MM/yyyy";
            this.recalldateTimePicker2.Font = new System.Drawing.Font("Arial", 11.25F);
            this.recalldateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.recalldateTimePicker2.Location = new System.Drawing.Point(174, 82);
            this.recalldateTimePicker2.Name = "recalldateTimePicker2";
            this.recalldateTimePicker2.RightToLeftLayout = true;
            this.recalldateTimePicker2.Size = new System.Drawing.Size(119, 25);
            this.recalldateTimePicker2.TabIndex = 5;
            this.recalldateTimePicker2.ValueChanged += new System.EventHandler(this.recalldateTimePicker2_ValueChanged);
            // 
            // priceTextBox
            // 
            this.priceTextBox.Font = new System.Drawing.Font("Arial", 11.25F);
            this.priceTextBox.Location = new System.Drawing.Point(174, 167);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(119, 25);
            this.priceTextBox.TabIndex = 8;
            this.priceTextBox.Text = "0";
            this.priceTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.priceTextBox.TextChanged += new System.EventHandler(this.priceTextBox_TextChanged);
            this.priceTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.priceTextBox_KeyPress);
            this.priceTextBox.Leave += new System.EventHandler(this.priceTextBox_Leave);
            // 
            // regdateTimePicker1
            // 
            this.regdateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.regdateTimePicker1.Font = new System.Drawing.Font("Arial", 11.25F);
            this.regdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.regdateTimePicker1.Location = new System.Drawing.Point(107, 111);
            this.regdateTimePicker1.Name = "regdateTimePicker1";
            this.regdateTimePicker1.RightToLeftLayout = true;
            this.regdateTimePicker1.Size = new System.Drawing.Size(186, 25);
            this.regdateTimePicker1.TabIndex = 6;
            // 
            // ChairTextBox
            // 
            this.ChairTextBox.Font = new System.Drawing.Font("Arial", 11.25F);
            this.ChairTextBox.Location = new System.Drawing.Point(141, 139);
            this.ChairTextBox.Name = "ChairTextBox";
            this.ChairTextBox.Size = new System.Drawing.Size(152, 25);
            this.ChairTextBox.TabIndex = 7;
            // 
            // doctorcomboBox
            // 
            this.doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.doctorcomboBox.Font = new System.Drawing.Font("Arial", 9.75F);
            this.doctorcomboBox.FormattingEnabled = true;
            this.doctorcomboBox.Location = new System.Drawing.Point(418, 138);
            this.doctorcomboBox.Name = "doctorcomboBox";
            this.doctorcomboBox.Size = new System.Drawing.Size(251, 24);
            this.doctorcomboBox.TabIndex = 1;
            this.doctorcomboBox.SelectedValueChanged += new System.EventHandler(this.doctorcomboBox_SelectedValueChanged);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label.Location = new System.Drawing.Point(672, 52);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(71, 16);
            this.label.TabIndex = 0;
            this.label.Text = "اسم المريض :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(297, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "رقم الكرسي :";
            // 
            // PatientComboBox
            // 
            this.PatientComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.PatientComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.PatientComboBox.Font = new System.Drawing.Font("Arial", 9.75F);
            this.PatientComboBox.FormattingEnabled = true;
            this.PatientComboBox.Location = new System.Drawing.Point(418, 47);
            this.PatientComboBox.Name = "PatientComboBox";
            this.PatientComboBox.Size = new System.Drawing.Size(251, 24);
            this.PatientComboBox.TabIndex = 0;
            this.PatientComboBox.SelectedIndexChanged += new System.EventHandler(this.PatientComboBox_SelectedIndexChanged);
            this.PatientComboBox.TextChanged += new System.EventHandler(this.PatientComboBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(67, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "حجز كشف لمريض";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(672, 172);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "تاريخ الحجز :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(297, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "تاريخ أعادة الكشف :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label6.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(2, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(148, 18);
            this.label6.TabIndex = 0;
            this.label6.Text = "مطلوب موافقة لهذا المريض";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(519, 202);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "إلى :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(297, 116);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 16);
            this.label8.TabIndex = 0;
            this.label8.Text = "تاريخ انتهاء الحجز :";
            // 
            // searchGrop
            // 
            this.searchGrop.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.searchGrop.BackColor = System.Drawing.Color.Transparent;
            this.searchGrop.Controls.Add(this.textBox9);
            this.searchGrop.Controls.Add(this.listBox1);
            this.searchGrop.Controls.Add(this.button10);
            this.searchGrop.Controls.Add(this.label21);
            this.searchGrop.Location = new System.Drawing.Point(243, 357);
            this.searchGrop.Name = "searchGrop";
            this.searchGrop.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.searchGrop.Size = new System.Drawing.Size(311, 311);
            this.searchGrop.TabIndex = 165;
            this.searchGrop.TabStop = false;
            this.searchGrop.Visible = false;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(10, 26);
            this.textBox9.Name = "textBox9";
            this.textBox9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox9.Size = new System.Drawing.Size(220, 20);
            this.textBox9.TabIndex = 13;
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            this.textBox9.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.textBox9_PreviewKeyDown);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(11, 58);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(280, 212);
            this.listBox1.TabIndex = 12;
            this.listBox1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listBox1_MouseDoubleClick);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Gainsboro;
            this.button10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.button10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button10.Location = new System.Drawing.Point(126, 279);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(68, 23);
            this.button10.TabIndex = 10;
            this.button10.Text = "تراجع";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label21.Location = new System.Drawing.Point(234, 28);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(63, 16);
            this.label21.TabIndex = 1;
            this.label21.Text = "اسم المريض";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gainsboro;
            this.button2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.button2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button2.Location = new System.Drawing.Point(54, 14);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(35, 28);
            this.button2.TabIndex = 81;
            this.button2.Text = "..";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Arial", 11.25F);
            this.textBox4.Location = new System.Drawing.Point(565, 53);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(105, 25);
            this.textBox4.TabIndex = 83;
            this.textBox4.Text = "0";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            this.textBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox4_KeyPress);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.Controls.Add(this.button6);
            this.groupBox5.Controls.Add(this.button4);
            this.groupBox5.Controls.Add(this.EditBtn);
            this.groupBox5.Controls.Add(this.saveBtn);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.DeletBtn);
            this.groupBox5.Controls.Add(this.Searchbtn);
            this.groupBox5.Location = new System.Drawing.Point(13, 574);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(759, 49);
            this.groupBox5.TabIndex = 78;
            this.groupBox5.TabStop = false;
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Gainsboro;
            this.button6.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.button6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button6.Location = new System.Drawing.Point(149, 11);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(111, 32);
            this.button6.TabIndex = 80;
            this.button6.Text = "تحديد ميعاد العملية";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Gainsboro;
            this.button4.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.button4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button4.Location = new System.Drawing.Point(462, 11);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(111, 32);
            this.button4.TabIndex = 79;
            this.button4.Text = "بحث بكود المريض";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // EditBtn
            // 
            this.EditBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.EditBtn.Enabled = false;
            this.EditBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.EditBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.EditBtn.Location = new System.Drawing.Point(574, 11);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(84, 32);
            this.EditBtn.TabIndex = 75;
            this.EditBtn.Text = "تعديل";
            this.EditBtn.UseVisualStyleBackColor = false;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.saveBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.saveBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.saveBtn.Location = new System.Drawing.Point(663, 11);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(90, 32);
            this.saveBtn.TabIndex = 34;
            this.saveBtn.Text = "حفظ";
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gainsboro;
            this.button1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.button1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button1.Location = new System.Drawing.Point(6, 11);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 32);
            this.button1.TabIndex = 78;
            this.button1.Text = "تراجع";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // DeletBtn
            // 
            this.DeletBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.DeletBtn.Enabled = false;
            this.DeletBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.DeletBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.DeletBtn.Location = new System.Drawing.Point(263, 11);
            this.DeletBtn.Name = "DeletBtn";
            this.DeletBtn.Size = new System.Drawing.Size(91, 32);
            this.DeletBtn.TabIndex = 77;
            this.DeletBtn.Text = "حذف";
            this.DeletBtn.UseVisualStyleBackColor = false;
            this.DeletBtn.Click += new System.EventHandler(this.DeletBtn_Click);
            // 
            // Searchbtn
            // 
            this.Searchbtn.BackColor = System.Drawing.Color.Gainsboro;
            this.Searchbtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.Searchbtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Searchbtn.Location = new System.Drawing.Point(357, 11);
            this.Searchbtn.Name = "Searchbtn";
            this.Searchbtn.Size = new System.Drawing.Size(103, 32);
            this.Searchbtn.TabIndex = 76;
            this.Searchbtn.Text = "بحث بالاسم";
            this.Searchbtn.UseVisualStyleBackColor = false;
            this.Searchbtn.Click += new System.EventHandler(this.Searchbtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Location = new System.Drawing.Point(12, 623);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(759, 133);
            this.groupBox1.TabIndex = 79;
            this.groupBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 16);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(753, 114);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(322, 40);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(235, 35);
            this.groupBox2.TabIndex = 80;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.radioButton5);
            this.groupBox3.Controls.Add(this.textBox10);
            this.groupBox3.Controls.Add(this.radioButton2);
            this.groupBox3.Controls.Add(this.checkBox1);
            this.groupBox3.Controls.Add(this.radioButton1);
            this.groupBox3.Controls.Add(this.comboBox1);
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Location = new System.Drawing.Point(12, -4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox3.Size = new System.Drawing.Size(759, 44);
            this.groupBox3.TabIndex = 79;
            this.groupBox3.TabStop = false;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioButton5.Location = new System.Drawing.Point(98, 17);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(103, 17);
            this.radioButton5.TabIndex = 10;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "بحث بكود المريض";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(7, 15);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(87, 20);
            this.textBox10.TabIndex = 9;
            this.textBox10.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Checked = true;
            this.radioButton2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioButton2.Location = new System.Drawing.Point(596, 17);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(104, 17);
            this.radioButton2.TabIndex = 7;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "بحث باسم الشركة";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.checkBox1.Location = new System.Drawing.Point(704, 19);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(45, 17);
            this.checkBox1.TabIndex = 8;
            this.checkBox1.Text = "بحث";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.radioButton1.Location = new System.Drawing.Point(340, 17);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(106, 17);
            this.radioButton1.TabIndex = 6;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "بحث برقم الموبايل";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox1.Font = new System.Drawing.Font("Arial", 9.75F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(451, 13);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(145, 24);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(211, 15);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(128, 20);
            this.textBox2.TabIndex = 5;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // sqlSelectCommand1
            // 
            this.sqlSelectCommand1.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
            this.sqlSelectCommand1.Connection = this.sqlConnection1;
            // 
            // sqlConnection1
            // 
            this.sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrat" +
    "ed Security=True;Connect Timeout=30;User Instance=True";
            this.sqlConnection1.FireInfoMessageEventOnUserErrors = false;
            // 
            // sqlInsertCommand1
            // 
            this.sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
            this.sqlInsertCommand1.Connection = this.sqlConnection1;
            this.sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
            new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
            new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
            new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
            new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
            new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
            new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
            new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData")});
            // 
            // sqlUpdateCommand1
            // 
            this.sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
            this.sqlUpdateCommand1.Connection = this.sqlConnection1;
            this.sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
            new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
            new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
            new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
            new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
            new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
            new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
            new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
            new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ID", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DentalName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")});
            // 
            // sqlDeleteCommand1
            // 
            this.sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
            this.sqlDeleteCommand1.Connection = this.sqlConnection1;
            this.sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ID", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DentalName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, null)});
            // 
            // sqlDataAdapter1
            // 
            this.sqlDataAdapter1.DeleteCommand = this.sqlDeleteCommand1;
            this.sqlDataAdapter1.InsertCommand = this.sqlInsertCommand1;
            this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
            this.sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("ID", "ID"),
                        new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
                        new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
                        new System.Data.Common.DataColumnMapping("DTel", "DTel"),
                        new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
                        new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
                        new System.Data.Common.DataColumnMapping("DSite", "DSite"),
                        new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
                        new System.Data.Common.DataColumnMapping("WorkData", "WorkData")})});
            this.sqlDataAdapter1.UpdateCommand = this.sqlUpdateCommand1;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Transparent;
            this.groupBox6.Controls.Add(this.label6);
            this.groupBox6.Location = new System.Drawing.Point(67, 45);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(235, 26);
            this.groupBox6.TabIndex = 81;
            this.groupBox6.TabStop = false;
            this.groupBox6.Visible = false;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Transparent;
            this.groupBox7.Controls.Add(this.textBox8);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.Dariba);
            this.groupBox7.Controls.Add(this.AfterDariba);
            this.groupBox7.Controls.Add(this.comboCategory);
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Controls.Add(this.textBox5);
            this.groupBox7.Controls.Add(this.label15);
            this.groupBox7.Controls.Add(this.button2);
            this.groupBox7.Controls.Add(this.textBox4);
            this.groupBox7.Controls.Add(this.button3);
            this.groupBox7.Controls.Add(this.label13);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.commentTextBox);
            this.groupBox7.Location = new System.Drawing.Point(24, 383);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox7.Size = new System.Drawing.Size(739, 185);
            this.groupBox7.TabIndex = 82;
            this.groupBox7.TabStop = false;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Arial", 11.25F);
            this.textBox8.Location = new System.Drawing.Point(259, 50);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(63, 25);
            this.textBox8.TabIndex = 165;
            this.textBox8.Text = "0";
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(324, 55);
            this.label14.Name = "label14";
            this.label14.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label14.Size = new System.Drawing.Size(40, 16);
            this.label14.TabIndex = 164;
            this.label14.Text = "الخصم:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label13.Location = new System.Drawing.Point(401, 57);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(21, 14);
            this.label13.TabIndex = 94;
            this.label13.Text = "%";
            // 
            // Dariba
            // 
            this.Dariba.Font = new System.Drawing.Font("Arial", 11.25F);
            this.Dariba.Location = new System.Drawing.Point(424, 50);
            this.Dariba.Name = "Dariba";
            this.Dariba.ReadOnly = true;
            this.Dariba.Size = new System.Drawing.Size(63, 25);
            this.Dariba.TabIndex = 93;
            this.Dariba.Text = "0";
            this.Dariba.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label15.Location = new System.Drawing.Point(486, 57);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 16);
            this.label15.TabIndex = 92;
            this.label15.Text = "الضريبة :";
            this.label15.Visible = false;
            // 
            // AfterDariba
            // 
            this.AfterDariba.Font = new System.Drawing.Font("Arial", 11.25F);
            this.AfterDariba.Location = new System.Drawing.Point(95, 50);
            this.AfterDariba.Name = "AfterDariba";
            this.AfterDariba.ReadOnly = true;
            this.AfterDariba.Size = new System.Drawing.Size(80, 25);
            this.AfterDariba.TabIndex = 91;
            this.AfterDariba.Text = "0";
            this.AfterDariba.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboCategory
            // 
            this.comboCategory.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboCategory.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboCategory.Font = new System.Drawing.Font("Arial", 9.75F);
            this.comboCategory.FormattingEnabled = true;
            this.comboCategory.Location = new System.Drawing.Point(406, 16);
            this.comboCategory.Name = "comboCategory";
            this.comboCategory.Size = new System.Drawing.Size(264, 24);
            this.comboCategory.TabIndex = 87;
            this.comboCategory.SelectedIndexChanged += new System.EventHandler(this.comboCategory_SelectedIndexChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.Transparent;
            this.groupBox8.Controls.Add(this.dataGridView2);
            this.groupBox8.Location = new System.Drawing.Point(20, 78);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox8.Size = new System.Drawing.Size(699, 100);
            this.groupBox8.TabIndex = 84;
            this.groupBox8.TabStop = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.CompanyCost,
            this.Column3,
            this.Column4});
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 16);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(693, 81);
            this.dataGridView2.TabIndex = 0;
            this.dataGridView2.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dataGridView2_RowsRemoved);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "الخدمة";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "السعر";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // CompanyCost
            // 
            this.CompanyCost.HeaderText = "التكلفة على الشركة";
            this.CompanyCost.Name = "CompanyCost";
            this.CompanyCost.ReadOnly = true;
            this.CompanyCost.Visible = false;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "الضريبة";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "السعر النهائي";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Arial", 9.75F);
            this.textBox5.Location = new System.Drawing.Point(30, 108);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(214, 22);
            this.textBox5.TabIndex = 85;
            this.textBox5.Text = "0";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5.Visible = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gainsboro;
            this.button3.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.button3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button3.Location = new System.Drawing.Point(6, 48);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(76, 28);
            this.button3.TabIndex = 82;
            this.button3.Text = "إضافة  ";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // commentTextBox
            // 
            this.commentTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.commentTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.commentTextBox.Font = new System.Drawing.Font("Arial", 9.75F);
            this.commentTextBox.FormattingEnabled = true;
            this.commentTextBox.Location = new System.Drawing.Point(95, 17);
            this.commentTextBox.Name = "commentTextBox";
            this.commentTextBox.Size = new System.Drawing.Size(233, 24);
            this.commentTextBox.TabIndex = 44;
            this.commentTextBox.SelectedIndexChanged += new System.EventHandler(this.commentTextBox_SelectedIndexChanged);
            this.commentTextBox.Click += new System.EventHandler(this.commentTextBox_Click);
            // 
            // dataSet11
            // 
            this.dataSet11.DataSetName = "DataSet1";
            this.dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sqlConnection2
            // 
            this.sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrat" +
    "ed Security=True;Connect Timeout=30;User Instance=True";
            this.sqlConnection2.FireInfoMessageEventOnUserErrors = false;
            // 
            // sqlDataAdapter2
            // 
            this.sqlDataAdapter2.InsertCommand = this.sqlCommand2;
            this.sqlDataAdapter2.SelectCommand = this.sqlCommand3;
            this.sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("ID", "ID"),
                        new System.Data.Common.DataColumnMapping("Titel", "Titel"),
                        new System.Data.Common.DataColumnMapping("PName", "PName"),
                        new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
                        new System.Data.Common.DataColumnMapping("City", "City"),
                        new System.Data.Common.DataColumnMapping("Tel", "Tel"),
                        new System.Data.Common.DataColumnMapping("Mob", "Mob"),
                        new System.Data.Common.DataColumnMapping("Email", "Email"),
                        new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
                        new System.Data.Common.DataColumnMapping("Sex", "Sex"),
                        new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
                        new System.Data.Common.DataColumnMapping("Statue", "Statue"),
                        new System.Data.Common.DataColumnMapping("company", "company"),
                        new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
                        new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
                        new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
                        new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
                        new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
                        new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
                        new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
                        new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
                        new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
                        new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
                        new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
                        new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
                        new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
                        new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
                        new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
                        new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
                        new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
                        new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
                        new System.Data.Common.DataColumnMapping("Implant", "Implant"),
                        new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
                        new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
                        new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers"),
                        new System.Data.Common.DataColumnMapping("DoctoreName", "DoctoreName"),
                        new System.Data.Common.DataColumnMapping("NextVisit", "NextVisit"),
                        new System.Data.Common.DataColumnMapping("Accept", "Accept"),
                        new System.Data.Common.DataColumnMapping("Taqweem", "Taqweem"),
                        new System.Data.Common.DataColumnMapping("Photo", "Photo"),
                        new System.Data.Common.DataColumnMapping("BloodType", "BloodType"),
                        new System.Data.Common.DataColumnMapping("Active", "Active"),
                        new System.Data.Common.DataColumnMapping("FileNo", "FileNo"),
                        new System.Data.Common.DataColumnMapping("Patient", "Patient"),
                        new System.Data.Common.DataColumnMapping("Facebook", "Facebook"),
                        new System.Data.Common.DataColumnMapping("Adv", "Adv"),
                        new System.Data.Common.DataColumnMapping("FormerPatient", "FormerPatient"),
                        new System.Data.Common.DataColumnMapping("Discount", "Discount"),
                        new System.Data.Common.DataColumnMapping("Without", "Without"),
                        new System.Data.Common.DataColumnMapping("Doctor", "Doctor"),
                        new System.Data.Common.DataColumnMapping("DoctorId", "DoctorId"),
                        new System.Data.Common.DataColumnMapping("nationalID", "nationalID"),
                        new System.Data.Common.DataColumnMapping("Dariba", "Dariba"),
                        new System.Data.Common.DataColumnMapping("NextvisitTXT", "NextvisitTXT")})});
            // 
            // sqlCommand2
            // 
            this.sqlCommand2.CommandText = resources.GetString("sqlCommand2.CommandText");
            this.sqlCommand2.Connection = this.sqlConnection2;
            this.sqlCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
            new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
            new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
            new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
            new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
            new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
            new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
            new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
            new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
            new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
            new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
            new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
            new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
            new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
            new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
            new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
            new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
            new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
            new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
            new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
            new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
            new System.Data.SqlClient.SqlParameter("@Lactating", System.Data.SqlDbType.Bit, 0, "Lactating"),
            new System.Data.SqlClient.SqlParameter("@Pregnant", System.Data.SqlDbType.Bit, 0, "Pregnant"),
            new System.Data.SqlClient.SqlParameter("@HepatitisB", System.Data.SqlDbType.Bit, 0, "HepatitisB"),
            new System.Data.SqlClient.SqlParameter("@Hepatitisc", System.Data.SqlDbType.Bit, 0, "Hepatitisc"),
            new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
            new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
            new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
            new System.Data.SqlClient.SqlParameter("@Endodontics", System.Data.SqlDbType.Bit, 0, "Endodontics"),
            new System.Data.SqlClient.SqlParameter("@Fixed", System.Data.SqlDbType.Bit, 0, "Fixed"),
            new System.Data.SqlClient.SqlParameter("@Implant", System.Data.SqlDbType.Bit, 0, "Implant"),
            new System.Data.SqlClient.SqlParameter("@Opretive", System.Data.SqlDbType.Bit, 0, "Opretive"),
            new System.Data.SqlClient.SqlParameter("@Bleaching", System.Data.SqlDbType.Bit, 0, "Bleaching"),
            new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers"),
            new System.Data.SqlClient.SqlParameter("@DoctoreName", System.Data.SqlDbType.NVarChar, 0, "DoctoreName"),
            new System.Data.SqlClient.SqlParameter("@NextVisit", System.Data.SqlDbType.NVarChar, 0, "NextVisit"),
            new System.Data.SqlClient.SqlParameter("@Accept", System.Data.SqlDbType.Bit, 0, "Accept"),
            new System.Data.SqlClient.SqlParameter("@Taqweem", System.Data.SqlDbType.Bit, 0, "Taqweem"),
            new System.Data.SqlClient.SqlParameter("@Photo", System.Data.SqlDbType.Image, 0, "Photo"),
            new System.Data.SqlClient.SqlParameter("@BloodType", System.Data.SqlDbType.NVarChar, 0, "BloodType"),
            new System.Data.SqlClient.SqlParameter("@Active", System.Data.SqlDbType.Bit, 0, "Active"),
            new System.Data.SqlClient.SqlParameter("@FileNo", System.Data.SqlDbType.Int, 0, "FileNo"),
            new System.Data.SqlClient.SqlParameter("@Patient", System.Data.SqlDbType.Bit, 0, "Patient"),
            new System.Data.SqlClient.SqlParameter("@Facebook", System.Data.SqlDbType.Bit, 0, "Facebook"),
            new System.Data.SqlClient.SqlParameter("@Adv", System.Data.SqlDbType.Bit, 0, "Adv"),
            new System.Data.SqlClient.SqlParameter("@FormerPatient", System.Data.SqlDbType.NVarChar, 0, "FormerPatient"),
            new System.Data.SqlClient.SqlParameter("@Discount", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, ((byte)(18)), ((byte)(2)), "Discount", System.Data.DataRowVersion.Current, null),
            new System.Data.SqlClient.SqlParameter("@Without", System.Data.SqlDbType.Bit, 0, "Without"),
            new System.Data.SqlClient.SqlParameter("@Doctor", System.Data.SqlDbType.Bit, 0, "Doctor"),
            new System.Data.SqlClient.SqlParameter("@DoctorId", System.Data.SqlDbType.NVarChar, 0, "DoctorId"),
            new System.Data.SqlClient.SqlParameter("@nationalID", System.Data.SqlDbType.VarChar, 0, "nationalID"),
            new System.Data.SqlClient.SqlParameter("@Dariba", System.Data.SqlDbType.Bit, 0, "Dariba"),
            new System.Data.SqlClient.SqlParameter("@NextvisitTXT", System.Data.SqlDbType.NVarChar, 0, "NextvisitTXT")});
            // 
            // sqlCommand3
            // 
            this.sqlCommand3.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
            this.sqlCommand3.Connection = this.sqlConnection2;
            // 
            // Appointments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(783, 745);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.searchGrop);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "Appointments";
            this.Text = "حجز كشف لمريض";
            this.Load += new System.EventHandler(this.Appointments_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Appointments_KeyDown);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.PaidPanel.ResumeLayout(false);
            this.PaidPanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.searchGrop.ResumeLayout(false);
            this.searchGrop.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).EndInit();
            this.ResumeLayout(false);

		}
	}
}
