using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace DentistClinic
{
	public class FrmPatientServices : FrmBase
	{
		private IContainer components = null;

		private GroupBox groupBox4;

		private Button button1;

		private DateTimePicker dateTimePicker2;

		private DateTimePicker dateTimePicker1;

		private ComboBox PatientComboBox;

		private GroupBox groupBox1;

		private DataGridView dataGridView1;

		private GroupBox groupBox2;

		private Button button2;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Column2;

		private DataGridViewCheckBoxColumn Column3;

		private dataClass codes = new dataClass(".\\sqlExpress");

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmPatientServices));
			groupBox4 = new System.Windows.Forms.GroupBox();
			button1 = new System.Windows.Forms.Button();
			dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			PatientComboBox = new System.Windows.Forms.ComboBox();
			groupBox1 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			groupBox2 = new System.Windows.Forms.GroupBox();
			button2 = new System.Windows.Forms.Button();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			groupBox4.SuspendLayout();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox2.SuspendLayout();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "addressLabel");
			label.Name = "addressLabel";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "titelLabel");
			label2.Name = "titelLabel";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label1");
			label3.Name = "label1";
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(button1);
			groupBox4.Controls.Add(dateTimePicker2);
			groupBox4.Controls.Add(label3);
			groupBox4.Controls.Add(dateTimePicker1);
			groupBox4.Controls.Add(label);
			groupBox4.Controls.Add(label2);
			groupBox4.Controls.Add(PatientComboBox);
			groupBox4.ForeColor = System.Drawing.Color.Black;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			dateTimePicker2.AccessibleDescription = null;
			dateTimePicker2.AccessibleName = null;
			resources.ApplyResources(dateTimePicker2, "dateTimePicker2");
			dateTimePicker2.BackgroundImage = null;
			dateTimePicker2.CalendarFont = null;
			dateTimePicker2.Font = null;
			dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker2.Name = "dateTimePicker2";
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.Font = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			PatientComboBox.AccessibleDescription = null;
			PatientComboBox.AccessibleName = null;
			resources.ApplyResources(PatientComboBox, "PatientComboBox");
			PatientComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			PatientComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientComboBox.BackgroundImage = null;
			PatientComboBox.FormattingEnabled = true;
			PatientComboBox.Name = "PatientComboBox";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(dataGridView1);
			groupBox1.ForeColor = System.Drawing.Color.Black;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(Column1, Column2, Column3);
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			resources.ApplyResources(Column1, "Column1");
			Column1.Name = "Column1";
			resources.ApplyResources(Column2, "Column2");
			Column2.Name = "Column2";
			Column2.ReadOnly = true;
			resources.ApplyResources(Column3, "Column3");
			Column3.Name = "Column3";
			Column3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(button2);
			groupBox2.ForeColor = System.Drawing.Color.Black;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox4);
			Font = null;
			base.Name = "FrmPatientServices";
			base.Load += new System.EventHandler(FrmPatientServices_Load);
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox2.ResumeLayout(false);
			ResumeLayout(false);
		}

		public FrmPatientServices()
		{
			InitializeComponent();
		}

		private void FrmPatientServices_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataSource = codes.Search2("select id,pname from PatientData");
				PatientComboBox.DataSource = dataSource;
				PatientComboBox.ValueMember = "id";
				PatientComboBox.DisplayMember = "pname";
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				dataGridView1.Rows.Clear();
				DataTable dataTable = codes.Search2(string.Concat("SELECT        PatientAccount.ID, PatientAccount.Bean, Teath.Name,PatientAccount.Appears\r\nFROM            PatientAccount INNER JOIN\r\n                         Teath ON PatientAccount.TeathId = Teath.Id where PatientAccount.PatientId='", PatientComboBox.SelectedValue, "' and date between '", dateTimePicker1.Value.ToShortDateString(), "' and  '", dateTimePicker2.Value.ToShortDateString(), "'"));
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					dataGridView1.Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString() + " " + dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString());
				}
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					codes.Edit2("update PatientAccount set Appears='" + Convert.ToBoolean(dataGridView1.Rows[i].Cells[2].Value.ToString()) + "' where id='" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "'");
				}
				MessageBox.Show("تم تعديل البيانات بنجاح");
				dataGridView1.Rows.Clear();
			}
			catch
			{
			}
		}
	}
}
