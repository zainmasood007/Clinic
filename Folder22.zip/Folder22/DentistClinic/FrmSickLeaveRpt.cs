using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmSickLeaveRpt : ReportBaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private Label label1;

		private ComboBox PatientCombo;

		private Label label3;

		private DateTimePicker date2;

		private DateTimePicker date1;

		private Button ViewRptBtn;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlSelectCommand4;

		private SqlConnection sqlConnection4;

		private SqlCommand sqlInsertCommand4;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter4;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlCommand1;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlCommand2;

		private SqlCommand sqlDeleteCommand;

		private SqlCommand sqlUpdateCommand;

		private CrystalReportViewer crystalReportViewer1;

		private GroupBox groupBox2;

		private Label label4;

		private GroupBox groupBox3;

		private CrystalReportViewer crystalReportViewer2;

		private ClassDataBase dc;

		private dataClass codes;

		private GUI gui = new GUI();

		private int TableID = 0;

		private int PatientID = 0;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmSickLeaveRpt));
			groupBox1 = new System.Windows.Forms.GroupBox();
			label4 = new System.Windows.Forms.Label();
			date2 = new System.Windows.Forms.DateTimePicker();
			ViewRptBtn = new System.Windows.Forms.Button();
			date1 = new System.Windows.Forms.DateTimePicker();
			label3 = new System.Windows.Forms.Label();
			PatientCombo = new System.Windows.Forms.ComboBox();
			label1 = new System.Windows.Forms.Label();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlConnection4 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter4 = new System.Data.SqlClient.SqlDataAdapter();
			dataSet11 = new DataSet1();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlDeleteCommand = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand = new System.Data.SqlClient.SqlCommand();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			groupBox2 = new System.Windows.Forms.GroupBox();
			groupBox3 = new System.Windows.Forms.GroupBox();
			crystalReportViewer2 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			groupBox2.SuspendLayout();
			groupBox3.SuspendLayout();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(date2);
			groupBox1.Controls.Add(ViewRptBtn);
			groupBox1.Controls.Add(date1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(PatientCombo);
			groupBox1.Controls.Add(label1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Name = "label4";
			date2.AccessibleDescription = null;
			date2.AccessibleName = null;
			resources.ApplyResources(date2, "date2");
			date2.BackgroundImage = null;
			date2.CalendarFont = null;
			date2.Font = null;
			date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date2.Name = "date2";
			ViewRptBtn.AccessibleDescription = null;
			ViewRptBtn.AccessibleName = null;
			resources.ApplyResources(ViewRptBtn, "ViewRptBtn");
			ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
			ViewRptBtn.BackgroundImage = null;
			ViewRptBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			ViewRptBtn.Name = "ViewRptBtn";
			ViewRptBtn.UseVisualStyleBackColor = false;
			ViewRptBtn.Click += new System.EventHandler(ViewRptBtn_Click);
			date1.AccessibleDescription = null;
			date1.AccessibleName = null;
			resources.ApplyResources(date1, "date1");
			date1.BackgroundImage = null;
			date1.CalendarFont = null;
			date1.Font = null;
			date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date1.Name = "date1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			PatientCombo.AccessibleDescription = null;
			PatientCombo.AccessibleName = null;
			resources.ApplyResources(PatientCombo, "PatientCombo");
			PatientCombo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			PatientCombo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientCombo.BackgroundImage = null;
			PatientCombo.Font = null;
			PatientCombo.FormattingEnabled = true;
			PatientCombo.Name = "PatientCombo";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			sqlSelectCommand1.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[40]
			{
				new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
				new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
				new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
				new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
				new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
				new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
				new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
				new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
				new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
				new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
				new System.Data.SqlClient.SqlParameter("@pain", System.Data.SqlDbType.Bit, 0, "pain"),
				new System.Data.SqlClient.SqlParameter("@Caries", System.Data.SqlDbType.Bit, 0, "Caries"),
				new System.Data.SqlClient.SqlParameter("@CheckUp", System.Data.SqlDbType.Bit, 0, "CheckUp"),
				new System.Data.SqlClient.SqlParameter("@Swelling", System.Data.SqlDbType.Bit, 0, "Swelling"),
				new System.Data.SqlClient.SqlParameter("@Esthetics", System.Data.SqlDbType.Bit, 0, "Esthetics"),
				new System.Data.SqlClient.SqlParameter("@Others", System.Data.SqlDbType.NVarChar, 0, "Others"),
				new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
				new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
				new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
				new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
				new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
				new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
				new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
				new System.Data.SqlClient.SqlParameter("@Lactating", System.Data.SqlDbType.Bit, 0, "Lactating"),
				new System.Data.SqlClient.SqlParameter("@Pregnant", System.Data.SqlDbType.Bit, 0, "Pregnant"),
				new System.Data.SqlClient.SqlParameter("@HepatitisB", System.Data.SqlDbType.Bit, 0, "HepatitisB"),
				new System.Data.SqlClient.SqlParameter("@Hepatitisc", System.Data.SqlDbType.Bit, 0, "Hepatitisc"),
				new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
				new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
				new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
				new System.Data.SqlClient.SqlParameter("@Endodontics", System.Data.SqlDbType.Bit, 0, "Endodontics"),
				new System.Data.SqlClient.SqlParameter("@Fixed", System.Data.SqlDbType.Bit, 0, "Fixed"),
				new System.Data.SqlClient.SqlParameter("@Implant", System.Data.SqlDbType.Bit, 0, "Implant"),
				new System.Data.SqlClient.SqlParameter("@Opretive", System.Data.SqlDbType.Bit, 0, "Opretive"),
				new System.Data.SqlClient.SqlParameter("@Bleaching", System.Data.SqlDbType.Bit, 0, "Bleaching"),
				new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers")
			});
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[41]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("pain", "pain"),
					new System.Data.Common.DataColumnMapping("Caries", "Caries"),
					new System.Data.Common.DataColumnMapping("CheckUp", "CheckUp"),
					new System.Data.Common.DataColumnMapping("Swelling", "Swelling"),
					new System.Data.Common.DataColumnMapping("Esthetics", "Esthetics"),
					new System.Data.Common.DataColumnMapping("Others", "Others"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
					new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
					new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
					new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
					new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
					new System.Data.Common.DataColumnMapping("Implant", "Implant"),
					new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
					new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers")
				})
			});
			sqlSelectCommand4.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand4.Connection = sqlConnection4;
			sqlConnection4.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection4.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand4.CommandText = resources.GetString("sqlInsertCommand4.CommandText");
			sqlInsertCommand4.Connection = sqlConnection4;
			sqlInsertCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[16]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
				new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
				new System.Data.SqlClient.SqlParameter("@GeneralClinic", System.Data.SqlDbType.Bit, 0, "GeneralClinic"),
				new System.Data.SqlClient.SqlParameter("@HeartClinic", System.Data.SqlDbType.Bit, 0, "HeartClinic")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection4;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[40]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
				new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
				new System.Data.SqlClient.SqlParameter("@GeneralClinic", System.Data.SqlDbType.Bit, 0, "GeneralClinic"),
				new System.Data.SqlClient.SqlParameter("@HeartClinic", System.Data.SqlDbType.Bit, 0, "HeartClinic"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_GeneralClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_GeneralClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_HeartClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "HeartClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_HeartClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "HeartClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection4;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[23]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_GeneralClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_GeneralClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_HeartClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "HeartClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_HeartClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "HeartClinic", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter4.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter4.InsertCommand = sqlInsertCommand4;
			sqlDataAdapter4.SelectCommand = sqlSelectCommand4;
			sqlDataAdapter4.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[17]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData"),
					new System.Data.Common.DataColumnMapping("Powred", "Powred"),
					new System.Data.Common.DataColumnMapping("ClinicType", "ClinicType"),
					new System.Data.Common.DataColumnMapping("EyeClinic", "EyeClinic"),
					new System.Data.Common.DataColumnMapping("FemaleClinic", "FemaleClinic"),
					new System.Data.Common.DataColumnMapping("NaturalClinic", "NaturalClinic"),
					new System.Data.Common.DataColumnMapping("EnName", "EnName"),
					new System.Data.Common.DataColumnMapping("GeneralClinic", "GeneralClinic"),
					new System.Data.Common.DataColumnMapping("HeartClinic", "HeartClinic")
				})
			});
			sqlDataAdapter4.UpdateCommand = sqlUpdateCommand1;
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlDataAdapter2.DeleteCommand = sqlDeleteCommand;
			sqlDataAdapter2.InsertCommand = sqlCommand1;
			sqlDataAdapter2.SelectCommand = sqlCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "SickLeave", new System.Data.Common.DataColumnMapping[6]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("PatientID", "PatientID"),
					new System.Data.Common.DataColumnMapping("Date", "Date"),
					new System.Data.Common.DataColumnMapping("Reason", "Reason"),
					new System.Data.Common.DataColumnMapping("StartDate", "StartDate"),
					new System.Data.Common.DataColumnMapping("EndDate", "EndDate")
				})
			});
			sqlDataAdapter2.UpdateCommand = sqlUpdateCommand;
			sqlDeleteCommand.CommandText = resources.GetString("sqlDeleteCommand.CommandText");
			sqlDeleteCommand.Connection = sqlConnection2;
			sqlDeleteCommand.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[9]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Date", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Date", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Date", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Date", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_StartDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "StartDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_StartDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "StartDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EndDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EndDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EndDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EndDate", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlCommand1.CommandText = resources.GetString("sqlCommand1.CommandText");
			sqlCommand1.Connection = sqlConnection2;
			sqlCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[5]
			{
				new System.Data.SqlClient.SqlParameter("@PatientID", System.Data.SqlDbType.Int, 0, "PatientID"),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
				new System.Data.SqlClient.SqlParameter("@Reason", System.Data.SqlDbType.NVarChar, 0, "Reason"),
				new System.Data.SqlClient.SqlParameter("@StartDate", System.Data.SqlDbType.DateTime, 0, "StartDate"),
				new System.Data.SqlClient.SqlParameter("@EndDate", System.Data.SqlDbType.DateTime, 0, "EndDate")
			});
			sqlCommand2.CommandText = "SELECT        SickLeave.*\r\nFROM            SickLeave";
			sqlCommand2.Connection = sqlConnection2;
			sqlUpdateCommand.CommandText = resources.GetString("sqlUpdateCommand.CommandText");
			sqlUpdateCommand.Connection = sqlConnection2;
			sqlUpdateCommand.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[15]
			{
				new System.Data.SqlClient.SqlParameter("@PatientID", System.Data.SqlDbType.Int, 0, "PatientID"),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
				new System.Data.SqlClient.SqlParameter("@Reason", System.Data.SqlDbType.NVarChar, 0, "Reason"),
				new System.Data.SqlClient.SqlParameter("@StartDate", System.Data.SqlDbType.DateTime, 0, "StartDate"),
				new System.Data.SqlClient.SqlParameter("@EndDate", System.Data.SqlDbType.DateTime, 0, "EndDate"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Date", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Date", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Date", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Date", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_StartDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "StartDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_StartDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "StartDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EndDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EndDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EndDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EndDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(crystalReportViewer2);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			crystalReportViewer2.AccessibleDescription = null;
			crystalReportViewer2.AccessibleName = null;
			crystalReportViewer2.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer2, "crystalReportViewer2");
			crystalReportViewer2.BackgroundImage = null;
			crystalReportViewer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer2.Font = null;
			crystalReportViewer2.Name = "crystalReportViewer2";
			crystalReportViewer2.SelectionFormula = "";
			crystalReportViewer2.ViewTimeSelectionFormula = "";
			base.AcceptButton = ViewRptBtn;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox3);
			Font = null;
			base.Name = "FrmSickLeaveRpt";
			base.Load += new System.EventHandler(FrmPatientAcountbyDateRpt_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox3.ResumeLayout(false);
			ResumeLayout(false);
		}

		public FrmSickLeaveRpt()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
		}

		public FrmSickLeaveRpt(int ID, int Patient)
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
			TableID = ID;
			PatientID = Patient;
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable tableText = dc.GetTableText("select * from PatientData where PName='" + PatientCombo.Text + "'");
				if (tableText.Rows.Count > 0)
				{
					DataTable tableText2 = dc.GetTableText("select * from SickLeave where PatientID='" + Convert.ToInt32(PatientCombo.SelectedValue.ToString()) + "'and StartDate Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "' and EndDate Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "'");
					if (tableText2.Rows.Count == 0)
					{
						MessageBox.Show("لا يوجد بيانات لهذا المريض في هذه الفترة");
						return;
					}
					sqlConnection1.ConnectionString = dc.ConnectionStr;
					sqlConnection2.ConnectionString = dc.ConnectionStr;
					sqlConnection4.ConnectionString = dc.ConnectionStr;
					dataSet11.Clear();
					sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
					sqlDataAdapter1.SelectCommand.CommandText = "select * from PatientData where ID='" + Convert.ToInt32(PatientCombo.SelectedValue.ToString()) + "'";
					sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
					sqlDataAdapter2.SelectCommand.CommandText = "select * from SickLeave where PatientID='" + Convert.ToInt32(PatientCombo.SelectedValue.ToString()) + "' and StartDate Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "' and EndDate Between'" + date1.Value.ToString("MM/dd/yyyy") + "'and'" + date2.Value.ToString("MM/dd/yyyy") + "'";
					DataTable dataTable = codes.Search2("select * from PatientData where PName='" + PatientCombo.Text + "'");
					DateTime.Today.Subtract(Convert.ToDateTime(dataTable.Rows[0]["BirthDate"].ToString()));
					int day = DateTime.Now.Day;
					int month = DateTime.Now.Month;
					int year = DateTime.Now.Year;
					int day2 = Convert.ToDateTime(dataTable.Rows[0]["BirthDate"].ToString()).Day;
					int month2 = Convert.ToDateTime(dataTable.Rows[0]["BirthDate"].ToString()).Month;
					int year2 = Convert.ToDateTime(dataTable.Rows[0]["BirthDate"].ToString()).Year;
					int num = 0;
					num = ((month * 100 + day < month2 * 100 + day2) ? (year - year2 - 1) : (year - year2));
					sqlDataAdapter4.Fill(dataSet11);
					sqlDataAdapter1.Fill(dataSet11);
					sqlDataAdapter2.Fill(dataSet11);
					((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value, date2.Value);
					ReportDocument reportDocument = new ReportDocument();
					reportDocument.Load(Application.StartupPath + "\\Reports\\SickLeaveRPT.rpt");
					reportDocument.SetDataSource(dataSet11);
					reportDocument.SetParameterValue("Age", num);
					crystalReportViewer1.ReportSource = reportDocument;
				}
				else
				{
					crystalReportViewer1.ReportSource = null;
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Valid Patient Name");
					}
					else
					{
						MessageBox.Show("من فضلك أختر أسم مريض صحيح");
					}
				}
			}
			catch
			{
			}
		}

		private void FrmPatientAcountbyDateRpt_Load(object sender, EventArgs e)
		{
			DataTable dataTable = new DataTable();
			try
			{
				dataTable = dc.GetTableText("SELECT ID, PName FROM PatientData where Active = 'True' ORDER BY PName");
				gui.loadComboBox(PatientCombo, dataTable);
			}
			catch
			{
			}
			try
			{
				if (TableID == 0)
				{
					groupBox1.Visible = true;
					groupBox2.Visible = true;
					groupBox3.Visible = false;
					return;
				}
				groupBox1.Visible = false;
				groupBox2.Visible = false;
				groupBox3.Visible = true;
				sqlConnection1.ConnectionString = dc.ConnectionStr;
				sqlConnection2.ConnectionString = dc.ConnectionStr;
				sqlConnection4.ConnectionString = dc.ConnectionStr;
				dataSet11.Clear();
				sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter1.SelectCommand.CommandText = "select * from PatientData where ID='" + PatientID + "'";
				sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter2.SelectCommand.CommandText = "select * from SickLeave where ID='" + TableID + "'";
				DataTable dataTable2 = codes.Search2("select * from PatientData where ID='" + PatientID + "'");
				DateTime.Today.Subtract(Convert.ToDateTime(dataTable2.Rows[0]["BirthDate"].ToString()));
				int day = DateTime.Now.Day;
				int month = DateTime.Now.Month;
				int year = DateTime.Now.Year;
				int day2 = Convert.ToDateTime(dataTable2.Rows[0]["BirthDate"].ToString()).Day;
				int month2 = Convert.ToDateTime(dataTable2.Rows[0]["BirthDate"].ToString()).Month;
				int year2 = Convert.ToDateTime(dataTable2.Rows[0]["BirthDate"].ToString()).Year;
				int num = 0;
				num = ((month * 100 + day < month2 * 100 + day2) ? (year - year2 - 1) : (year - year2));
				sqlDataAdapter4.Fill(dataSet11);
				sqlDataAdapter1.Fill(dataSet11);
				sqlDataAdapter2.Fill(dataSet11);
				((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value, date2.Value);
				ReportDocument reportDocument = new ReportDocument();
				reportDocument.Load(Application.StartupPath + "\\Reports\\SickLeaveRPT.rpt");
				reportDocument.SetDataSource(dataSet11);
				reportDocument.SetParameterValue("Age", num);
				crystalReportViewer2.ReportSource = reportDocument;
			}
			catch
			{
			}
		}
	}
}
