using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace DentistClinic
{
	public class FrmBase : Form
	{
		private IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmBase));
			SuspendLayout();
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(599, 241);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.Name = "FrmBase";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "FrmBase";
			base.Load += new System.EventHandler(FrmBase_Load);
			base.Paint += new System.Windows.Forms.PaintEventHandler(FrmBase_Paint);
			ResumeLayout(false);
		}

		public FrmBase()
		{
			InitializeComponent();
			base.Paint += FrmBase_Paint;
		}

		private void FrmBase_Paint(object sender, PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			Brush brush = new LinearGradientBrush(new Rectangle(0, 0, base.Width, base.Height), Color.SteelBlue, Color.LightSteelBlue, 270f);
			graphics.FillRectangle(brush, 0, 0, base.Width, base.Height);
		}

		private void FrmBase_Load(object sender, EventArgs e)
		{
		}
	}
}
