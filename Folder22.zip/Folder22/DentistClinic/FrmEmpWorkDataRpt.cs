using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmEmpWorkDataRpt : BaseForm
	{
		private ClassDataBase dc;

		private dataClass Codes;

		private IContainer components = null;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private GroupBox groupBox2;

		private CrystalReportViewer crystalReportViewer1;

		private SqlCommand sqlSelectCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlInsertCommand2;

		private SqlCommand sqlUpdateCommand2;

		private SqlCommand sqlDeleteCommand2;

		private SqlDataAdapter sqlDataAdapter2;

		public FrmEmpWorkDataRpt()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			Codes = new dataClass(".\\sqlExpress");
		}

		private void FrmLimitOrderRpt_Load(object sender, EventArgs e)
		{
			try
			{
				dataSet11.Clear();
				sqlConnection1.ConnectionString = Codes.ConnectionStr;
				sqlConnection2.ConnectionString = Codes.ConnectionStr;
				sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter2.SelectCommand.CommandText = "select * from Empdata where Designation='Doctor'";
				sqlDataAdapter1.Fill(dataSet11);
				sqlDataAdapter2.Fill(dataSet11);
				EmpWorkDataRpt empWorkDataRpt = new EmpWorkDataRpt();
				empWorkDataRpt.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = empWorkDataRpt;
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmEmpWorkDataRpt));
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			groupBox2 = new System.Windows.Forms.GroupBox();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			dataSet11 = new DataSet1();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			sqlSelectCommand1.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[33]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[19]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[14]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData"),
					new System.Data.Common.DataColumnMapping("Powred", "Powred"),
					new System.Data.Common.DataColumnMapping("ClinicType", "ClinicType"),
					new System.Data.Common.DataColumnMapping("EyeClinic", "EyeClinic"),
					new System.Data.Common.DataColumnMapping("FemaleClinic", "FemaleClinic"),
					new System.Data.Common.DataColumnMapping("NaturalClinic", "NaturalClinic")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			sqlSelectCommand2.CommandText = "SELECT        Empdata.*\r\nFROM            Empdata";
			sqlSelectCommand2.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.CommandText = resources.GetString("sqlInsertCommand2.CommandText");
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[15]
			{
				new System.Data.SqlClient.SqlParameter("@Designation", System.Data.SqlDbType.NVarChar, 0, "Designation"),
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 0, "Address"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@Salary", System.Data.SqlDbType.Money, 0, "Salary"),
				new System.Data.SqlClient.SqlParameter("@Percentage", System.Data.SqlDbType.NVarChar, 0, "Percentage"),
				new System.Data.SqlClient.SqlParameter("@Specialty", System.Data.SqlDbType.NVarChar, 0, "Specialty"),
				new System.Data.SqlClient.SqlParameter("@Signature", System.Data.SqlDbType.NVarChar, 0, "Signature"),
				new System.Data.SqlClient.SqlParameter("@AppointCount", System.Data.SqlDbType.Int, 0, "AppointCount"),
				new System.Data.SqlClient.SqlParameter("@BacksCount", System.Data.SqlDbType.Int, 0, "BacksCount"),
				new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
				new System.Data.SqlClient.SqlParameter("@EnSpecialty", System.Data.SqlDbType.NVarChar, 0, "EnSpecialty"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData")
			});
			sqlUpdateCommand2.CommandText = resources.GetString("sqlUpdateCommand2.CommandText");
			sqlUpdateCommand2.Connection = sqlConnection2;
			sqlUpdateCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[33]
			{
				new System.Data.SqlClient.SqlParameter("@Designation", System.Data.SqlDbType.NVarChar, 0, "Designation"),
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 0, "Address"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@Salary", System.Data.SqlDbType.Money, 0, "Salary"),
				new System.Data.SqlClient.SqlParameter("@Percentage", System.Data.SqlDbType.NVarChar, 0, "Percentage"),
				new System.Data.SqlClient.SqlParameter("@Specialty", System.Data.SqlDbType.NVarChar, 0, "Specialty"),
				new System.Data.SqlClient.SqlParameter("@Signature", System.Data.SqlDbType.NVarChar, 0, "Signature"),
				new System.Data.SqlClient.SqlParameter("@AppointCount", System.Data.SqlDbType.Int, 0, "AppointCount"),
				new System.Data.SqlClient.SqlParameter("@BacksCount", System.Data.SqlDbType.Int, 0, "BacksCount"),
				new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
				new System.Data.SqlClient.SqlParameter("@EnSpecialty", System.Data.SqlDbType.NVarChar, 0, "EnSpecialty"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Designation", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Designation", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Designation", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Designation", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mob", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mob", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mob", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mob", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Email", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Email", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Email", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Email", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Salary", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Salary", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Salary", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Salary", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Percentage", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Percentage", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Percentage", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Percentage", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AppointCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AppointCount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AppointCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AppointCount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BacksCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BacksCount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BacksCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BacksCount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand2.CommandText = resources.GetString("sqlDeleteCommand2.CommandText");
			sqlDeleteCommand2.Connection = sqlConnection2;
			sqlDeleteCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[17]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Designation", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Designation", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Designation", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Designation", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mob", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mob", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mob", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mob", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Email", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Email", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Email", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Email", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Salary", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Salary", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Salary", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Salary", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Percentage", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Percentage", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Percentage", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Percentage", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AppointCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AppointCount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AppointCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AppointCount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BacksCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BacksCount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BacksCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BacksCount", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter2.DeleteCommand = sqlDeleteCommand2;
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Empdata", new System.Data.Common.DataColumnMapping[16]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Designation", "Designation"),
					new System.Data.Common.DataColumnMapping("Name", "Name"),
					new System.Data.Common.DataColumnMapping("Address", "Address"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("Salary", "Salary"),
					new System.Data.Common.DataColumnMapping("Percentage", "Percentage"),
					new System.Data.Common.DataColumnMapping("Specialty", "Specialty"),
					new System.Data.Common.DataColumnMapping("Signature", "Signature"),
					new System.Data.Common.DataColumnMapping("AppointCount", "AppointCount"),
					new System.Data.Common.DataColumnMapping("BacksCount", "BacksCount"),
					new System.Data.Common.DataColumnMapping("EnName", "EnName"),
					new System.Data.Common.DataColumnMapping("EnSpecialty", "EnSpecialty"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData")
				})
			});
			sqlDataAdapter2.UpdateCommand = sqlUpdateCommand2;
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox2);
			Font = null;
			base.MaximizeBox = true;
			base.Name = "FrmEmpWorkDataRpt";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.Load += new System.EventHandler(FrmLimitOrderRpt_Load);
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}
	}
}
