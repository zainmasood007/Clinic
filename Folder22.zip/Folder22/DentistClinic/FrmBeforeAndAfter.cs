using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmBeforeAndAfter : BaseForm
	{
		private IContainer components = null;

		private PictureBox pictureBox1;

		private GroupBox groupBox3;

		private GroupBox groupBox1;

		private PictureBox pictureBox2;

		private Label label3;

		private ComboBox PatientcomboBox;

		private DateTimePicker dateTimePicker2;

		private Label label2;

		private DateTimePicker dateTimePicker1;

		private Label label1;

		private Button SaveBtn;

		private Button button2;

		private Button button1;

		private OpenFileDialog openFileDialog1;

		private OpenFileDialog openFileDialog2;

		private GroupBox groupBox2;

		private DataGridView dataGridView1;

		private ComboBox nameTextBox;

		private Label label5;

		private Button button3;

		private DataGridViewTextBoxColumn Column3;

		private DataGridViewTextBoxColumn Column1;

		private GroupBox groupBox5;

		private RadioButton radioButton3;

		private TextBox textBox1;

		private CheckBox checkBox2;

		private RadioButton radioButton6;

		private TextBox textBox3;

		private GUI gui = new GUI();

		private ClassDataBase dc = new ClassDataBase(".\\sqlExpress");

		private dataClass codes = new dataClass(".\\sqlExpress");

		private byte[] image1;

		private byte[] image2;

		private bool check = true;

		private int ID = 0;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmBeforeAndAfter));
			groupBox3 = new System.Windows.Forms.GroupBox();
			button2 = new System.Windows.Forms.Button();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label2 = new System.Windows.Forms.Label();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			groupBox1 = new System.Windows.Forms.GroupBox();
			button1 = new System.Windows.Forms.Button();
			label1 = new System.Windows.Forms.Label();
			pictureBox2 = new System.Windows.Forms.PictureBox();
			label3 = new System.Windows.Forms.Label();
			PatientcomboBox = new System.Windows.Forms.ComboBox();
			SaveBtn = new System.Windows.Forms.Button();
			openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
			groupBox2 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			nameTextBox = new System.Windows.Forms.ComboBox();
			label5 = new System.Windows.Forms.Label();
			button3 = new System.Windows.Forms.Button();
			groupBox5 = new System.Windows.Forms.GroupBox();
			radioButton3 = new System.Windows.Forms.RadioButton();
			textBox1 = new System.Windows.Forms.TextBox();
			checkBox2 = new System.Windows.Forms.CheckBox();
			radioButton6 = new System.Windows.Forms.RadioButton();
			textBox3 = new System.Windows.Forms.TextBox();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox5.SuspendLayout();
			SuspendLayout();
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(button2);
			groupBox3.Controls.Add(dateTimePicker1);
			groupBox3.Controls.Add(label2);
			groupBox3.Controls.Add(pictureBox1);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackColor = System.Drawing.Color.Transparent;
			button2.BackgroundImage = null;
			button2.Cursor = System.Windows.Forms.Cursors.Hand;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = false;
			button2.Click += new System.EventHandler(DentalLogoBtn_Click);
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.Font = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			dateTimePicker1.Value = new System.DateTime(2016, 9, 28, 0, 0, 0, 0);
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			pictureBox1.AccessibleDescription = null;
			pictureBox1.AccessibleName = null;
			resources.ApplyResources(pictureBox1, "pictureBox1");
			pictureBox1.BackColor = System.Drawing.Color.Transparent;
			pictureBox1.BackgroundImage = null;
			pictureBox1.Font = null;
			pictureBox1.ImageLocation = null;
			pictureBox1.Name = "pictureBox1";
			pictureBox1.TabStop = false;
			dateTimePicker2.AccessibleDescription = null;
			dateTimePicker2.AccessibleName = null;
			resources.ApplyResources(dateTimePicker2, "dateTimePicker2");
			dateTimePicker2.BackgroundImage = null;
			dateTimePicker2.CalendarFont = null;
			dateTimePicker2.Font = null;
			dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker2.Name = "dateTimePicker2";
			dateTimePicker2.Value = new System.DateTime(2016, 9, 28, 0, 0, 0, 0);
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(button1);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(dateTimePicker2);
			groupBox1.Controls.Add(pictureBox2);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.Transparent;
			button1.BackgroundImage = null;
			button1.Cursor = System.Windows.Forms.Cursors.Hand;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			pictureBox2.AccessibleDescription = null;
			pictureBox2.AccessibleName = null;
			resources.ApplyResources(pictureBox2, "pictureBox2");
			pictureBox2.BackColor = System.Drawing.Color.Transparent;
			pictureBox2.BackgroundImage = null;
			pictureBox2.Font = null;
			pictureBox2.ImageLocation = null;
			pictureBox2.Name = "pictureBox2";
			pictureBox2.TabStop = false;
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.BackColor = System.Drawing.Color.Transparent;
			label3.Name = "label3";
			PatientcomboBox.AccessibleDescription = null;
			PatientcomboBox.AccessibleName = null;
			resources.ApplyResources(PatientcomboBox, "PatientcomboBox");
			PatientcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			PatientcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientcomboBox.BackgroundImage = null;
			PatientcomboBox.FormattingEnabled = true;
			PatientcomboBox.Name = "PatientcomboBox";
			PatientcomboBox.SelectedIndexChanged += new System.EventHandler(PatientcomboBox_SelectedIndexChanged);
			SaveBtn.AccessibleDescription = null;
			SaveBtn.AccessibleName = null;
			resources.ApplyResources(SaveBtn, "SaveBtn");
			SaveBtn.BackColor = System.Drawing.Color.Gainsboro;
			SaveBtn.BackgroundImage = null;
			SaveBtn.Name = "SaveBtn";
			SaveBtn.UseVisualStyleBackColor = false;
			SaveBtn.Click += new System.EventHandler(SaveBtn_Click);
			resources.ApplyResources(openFileDialog1, "openFileDialog1");
			resources.ApplyResources(openFileDialog2, "openFileDialog2");
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(dataGridView1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(Column3, Column1);
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseClick);
			resources.ApplyResources(Column3, "Column3");
			Column3.Name = "Column3";
			Column3.ReadOnly = true;
			resources.ApplyResources(Column1, "Column1");
			Column1.Name = "Column1";
			Column1.ReadOnly = true;
			nameTextBox.AccessibleDescription = null;
			nameTextBox.AccessibleName = null;
			resources.ApplyResources(nameTextBox, "nameTextBox");
			nameTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			nameTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			nameTextBox.BackgroundImage = null;
			nameTextBox.FormattingEnabled = true;
			nameTextBox.Name = "nameTextBox";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label5");
			label5.BackColor = System.Drawing.Color.Transparent;
			label5.Name = "label5";
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackColor = System.Drawing.Color.Gainsboro;
			button3.BackgroundImage = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = false;
			button3.Click += new System.EventHandler(button3_Click);
			groupBox5.AccessibleDescription = null;
			groupBox5.AccessibleName = null;
			resources.ApplyResources(groupBox5, "groupBox5");
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.BackgroundImage = null;
			groupBox5.Controls.Add(radioButton3);
			groupBox5.Controls.Add(textBox1);
			groupBox5.Controls.Add(checkBox2);
			groupBox5.Controls.Add(radioButton6);
			groupBox5.Controls.Add(textBox3);
			groupBox5.Font = null;
			groupBox5.Name = "groupBox5";
			groupBox5.TabStop = false;
			radioButton3.AccessibleDescription = null;
			radioButton3.AccessibleName = null;
			resources.ApplyResources(radioButton3, "radioButton3");
			radioButton3.BackgroundImage = null;
			radioButton3.Font = null;
			radioButton3.Name = "radioButton3";
			radioButton3.TabStop = true;
			radioButton3.UseVisualStyleBackColor = true;
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Font = null;
			textBox1.Name = "textBox1";
			textBox1.TextChanged += new System.EventHandler(textBox1_TextChanged);
			checkBox2.AccessibleDescription = null;
			checkBox2.AccessibleName = null;
			resources.ApplyResources(checkBox2, "checkBox2");
			checkBox2.BackgroundImage = null;
			checkBox2.Font = null;
			checkBox2.Name = "checkBox2";
			checkBox2.UseVisualStyleBackColor = true;
			checkBox2.CheckedChanged += new System.EventHandler(checkBox2_CheckedChanged);
			radioButton6.AccessibleDescription = null;
			radioButton6.AccessibleName = null;
			resources.ApplyResources(radioButton6, "radioButton6");
			radioButton6.BackgroundImage = null;
			radioButton6.Font = null;
			radioButton6.Name = "radioButton6";
			radioButton6.TabStop = true;
			radioButton6.UseVisualStyleBackColor = true;
			textBox3.AccessibleDescription = null;
			textBox3.AccessibleName = null;
			resources.ApplyResources(textBox3, "textBox3");
			textBox3.BackgroundImage = null;
			textBox3.Font = null;
			textBox3.Name = "textBox3";
			textBox3.TextChanged += new System.EventHandler(textBox3_TextChanged);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox5);
			base.Controls.Add(button3);
			base.Controls.Add(groupBox3);
			base.Controls.Add(label5);
			base.Controls.Add(nameTextBox);
			base.Controls.Add(groupBox2);
			base.Controls.Add(SaveBtn);
			base.Controls.Add(PatientcomboBox);
			base.Controls.Add(label3);
			base.Controls.Add(groupBox1);
			Font = null;
			base.MaximizeBox = true;
			base.Name = "FrmBeforeAndAfter";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.Load += new System.EventHandler(FrmBeforeAndAfter_Load);
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox5.ResumeLayout(false);
			groupBox5.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		public FrmBeforeAndAfter()
		{
			InitializeComponent();
		}

		private byte[] GetImage(string path)
		{
			FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read);
			BinaryReader binaryReader = new BinaryReader(fileStream);
			byte[] result = binaryReader.ReadBytes(Convert.ToInt32(fileStream.Length));
			binaryReader.Close();
			fileStream.Close();
			return result;
		}

		private void DentalLogoBtn_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = openFileDialog1.ShowDialog();
			if (dialogResult != DialogResult.Cancel)
			{
				image1 = GetImage(openFileDialog1.FileName);
				pictureBox1.BackgroundImage = Image.FromFile(openFileDialog1.FileName);
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = openFileDialog1.ShowDialog();
			if (dialogResult != DialogResult.Cancel)
			{
				image2 = GetImage(openFileDialog1.FileName);
				pictureBox2.BackgroundImage = Image.FromFile(openFileDialog1.FileName);
			}
		}

		private void FrmBeforeAndAfter_Load(object sender, EventArgs e)
		{
			new DataTable();
			try
			{
				DataTable dataTable = new DataTable();
				if (Convert.ToBoolean(codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString()))
				{
					dataTable = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True' order by PName");
					PatientcomboBox.DataSource = dataTable;
					PatientcomboBox.DisplayMember = dataTable.Columns[1].ToString();
					PatientcomboBox.ValueMember = dataTable.Columns[0].ToString();
				}
				else
				{
					dataTable = dc.Select("SelectAllPatient");
					gui.loadComboBox(PatientcomboBox, dataTable);
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = codes.Search2("Select distinct ImageName from BeforeAndAfter");
				nameTextBox.DataSource = dataTable2;
				nameTextBox.DisplayMember = dataTable2.Columns[0].ToString();
				nameTextBox.Text = "";
			}
			catch
			{
			}
			PatientcomboBox_SelectedIndexChanged(sender, e);
		}

		private void PatientcomboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				dataGridView1.Rows.Clear();
				nameTextBox.Text = "";
				pictureBox1.BackgroundImage = null;
				pictureBox2.BackgroundImage = null;
				dateTimePicker1.Value = DateTime.Now;
				dateTimePicker2.Value = DateTime.Now;
				if (Settings.Default.Language == "en-GB")
				{
					SaveBtn.Text = "Save";
				}
				else
				{
					SaveBtn.Text = "حفظ";
				}
				DataTable dataTable = codes.Search2(string.Concat("select ID,ImageName from BeforeAndAfter where PatientID = '", PatientcomboBox.SelectedValue, "'"));
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					dataGridView1.Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString());
				}
			}
			catch
			{
			}
		}

		private void SaveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (PatientcomboBox.SelectedIndex == -1)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Patient Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المريض صحيح");
					}
					return;
				}
				if (nameTextBox.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل الاسم اولا");
					}
					return;
				}
				string[] fields = new string[6] { "PatientID", "DateBefore", "DateAfter", "ImageBefore", "ImageAfter", "ImageName" };
				string[] fields2 = new string[4] { "PatientID", "DateBefore", "ImageBefore", "ImageName" };
				string[] fields3 = new string[7] { "ID", "PatientID", "DateBefore", "DateAfter", "ImageBefore", "ImageAfter", "ImageName" };
				string[] fields4 = new string[5] { "ID", "PatientID", "DateBefore", "ImageBefore", "ImageName" };
				string text = "";
				if (SaveBtn.Text == "Save")
				{
					text = "Save";
				}
				if (SaveBtn.Text == "حفظ")
				{
					text = "حفظ";
				}
				if (SaveBtn.Text == text)
				{
					if (pictureBox1.BackgroundImage == null)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please enter at least the image before");
						}
						else
						{
							MessageBox.Show("من فضلك ادخل على الاقل الصورة قبل");
						}
						return;
					}
					try
					{
						DataTable dataTable = codes.Search2(string.Concat("select * from BeforeAndAfter where PatientID = '", PatientcomboBox.SelectedValue, "' and ImageName = '", nameTextBox.Text, "'"));
						if (dataTable.Rows.Count > 0)
						{
							MessageBox.Show("هذه البيانات تم تسجيلها قبل ذلك");
							return;
						}
					}
					catch
					{
					}
					if (pictureBox2.BackgroundImage == null)
					{
						try
						{
							dc.Insert("AddBeforeAndAfter2", fields2, Convert.ToInt32(PatientcomboBox.SelectedValue), dateTimePicker1.Value.ToString("MM/dd/yyyy"), image1, nameTextBox.Text);
						}
						catch
						{
						}
					}
					else
					{
						try
						{
							dc.Insert("AddBeforeAndAfter1", fields, Convert.ToInt32(PatientcomboBox.SelectedValue), dateTimePicker1.Value.ToString("MM/dd/yyyy"), dateTimePicker2.Value.ToString("MM/dd/yyyy"), image1, image2, nameTextBox.Text);
						}
						catch
						{
						}
					}
					goto IL_05de;
				}
				try
				{
					DataTable dataTable = codes.Search2(string.Concat("select * from BeforeAndAfter where PatientID = '", PatientcomboBox.SelectedValue, "' and ImageName = '", nameTextBox.Text, "' and ID != '", ID, "'"));
					if (dataTable.Rows.Count > 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Have Save This Data Before");
						}
						else
						{
							MessageBox.Show("هذه البيانات تم تسجيلها قبل ذلك");
						}
						return;
					}
				}
				catch
				{
				}
				if (pictureBox2.BackgroundImage == null)
				{
					try
					{
						dc.Update("UpdateBeforeAndAfter2", fields4, ID, Convert.ToInt32(PatientcomboBox.SelectedValue), dateTimePicker1.Value.ToString("MM/dd/yyyy"), image1, nameTextBox.Text);
					}
					catch
					{
					}
				}
				else
				{
					try
					{
						dc.Update("UpdateBeforeAndAfter1", fields3, ID, Convert.ToInt32(PatientcomboBox.SelectedValue), dateTimePicker1.Value.ToString("MM/dd/yyyy"), dateTimePicker2.Value.ToString("MM/dd/yyyy"), image1, image2, nameTextBox.Text);
					}
					catch
					{
					}
				}
				goto IL_05de;
				IL_05de:
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				ID = 0;
				pictureBox1.BackgroundImage = null;
				pictureBox2.BackgroundImage = null;
				dateTimePicker1.Value = DateTime.Now;
				dateTimePicker2.Value = DateTime.Now;
				nameTextBox.Text = "";
				try
				{
					nameTextBox.DataSource = null;
					DataTable dataTable2 = codes.Search2("Select distinct ImageName from BeforeAndAfter");
					nameTextBox.DataSource = dataTable2;
					nameTextBox.DisplayMember = dataTable2.Columns[0].ToString();
					nameTextBox.Text = "";
				}
				catch
				{
				}
				PatientcomboBox_SelectedIndexChanged(sender, e);
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				pictureBox1.BackgroundImage = null;
				pictureBox2.BackgroundImage = null;
				dateTimePicker1.Value = DateTime.Now;
				dateTimePicker2.Value = DateTime.Now;
				ID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
				nameTextBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
				DataTable dataTable = codes.Search2("select * from BeforeAndAfter where ID = '" + ID + "'");
				DataTable dataTable2 = codes.Search2("select * from BeforeAndAfter where ID = '" + ID + "' and ImageAfter IS NULL");
				if (dataTable2.Rows.Count > 0)
				{
					dateTimePicker1.Value = Convert.ToDateTime(dataTable2.Rows[0]["DateBefore"]);
					try
					{
						SqlBytes sqlBytes = new SqlBytes((byte[])dataTable2.Rows[0]["ImageBefore"]);
						image1 = (byte[])dataTable2.Rows[0]["ImageBefore"];
						pictureBox1.BackgroundImage = Image.FromStream(sqlBytes.Stream);
					}
					catch
					{
					}
					if (Settings.Default.Language == "en-GB")
					{
						SaveBtn.Text = "Update";
					}
					else
					{
						SaveBtn.Text = "تعديل";
					}
					return;
				}
				dateTimePicker1.Value = Convert.ToDateTime(dataTable.Rows[0]["DateBefore"]);
				dateTimePicker2.Value = Convert.ToDateTime(dataTable.Rows[0]["DateAfter"]);
				try
				{
					SqlBytes sqlBytes = new SqlBytes((byte[])dataTable.Rows[0]["ImageBefore"]);
					image1 = (byte[])dataTable.Rows[0]["ImageBefore"];
					pictureBox1.BackgroundImage = Image.FromStream(sqlBytes.Stream);
				}
				catch
				{
				}
				try
				{
					SqlBytes sqlBytes = new SqlBytes((byte[])dataTable.Rows[0]["ImageAfter"]);
					image2 = (byte[])dataTable.Rows[0]["ImageAfter"];
					pictureBox2.BackgroundImage = Image.FromStream(sqlBytes.Stream);
				}
				catch
				{
				}
				if (Settings.Default.Language == "en-GB")
				{
					SaveBtn.Text = "Update";
				}
				else
				{
					SaveBtn.Text = "تعديل";
				}
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			ID = 0;
			pictureBox1.BackgroundImage = null;
			pictureBox2.BackgroundImage = null;
			dateTimePicker1.Value = DateTime.Now;
			dateTimePicker2.Value = DateTime.Now;
			nameTextBox.Text = "";
			if (Settings.Default.Language == "en-GB")
			{
				SaveBtn.Text = "Save";
			}
			else
			{
				SaveBtn.Text = "حفظ";
			}
			PatientcomboBox_SelectedIndexChanged(sender, e);
		}

		private void checkBox2_CheckedChanged(object sender, EventArgs e)
		{
			if (!checkBox2.Checked)
			{
				DataTable dataTable = new DataTable();
				try
				{
					dataTable = dc.Select("SelectAllPatient");
					gui.loadComboBox(PatientcomboBox, dataTable);
				}
				catch
				{
				}
			}
		}

		private void textBox3_TextChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBox2.Checked && radioButton6.Checked)
				{
					DataTable dataTable = codes.Search2("select id,pname from PatientData where Mob like '%" + textBox3.Text + "%' and Active = 'True'");
					PatientcomboBox.DataSource = dataTable;
					PatientcomboBox.ValueMember = dataTable.Columns[0].ToString();
					PatientcomboBox.DisplayMember = dataTable.Columns[1].ToString();
				}
			}
			catch
			{
			}
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
			try
			{
				if (checkBox2.Checked && radioButton3.Checked)
				{
					DataTable dataTable = codes.Search2("select id,pname from PatientData where FileNo like '%" + textBox1.Text + "%' and Active = 'True'");
					PatientcomboBox.DataSource = dataTable;
					PatientcomboBox.ValueMember = dataTable.Columns[0].ToString();
					PatientcomboBox.DisplayMember = dataTable.Columns[1].ToString();
				}
			}
			catch
			{
			}
		}
	}
}
