using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using DentistClinic.Properties;
using FloatTextBox;
using VistaButtonTest;

namespace DentistClinic
{
	public class PationtAccountReBack : BaseForm
	{
		private int docid;

		private bool b;

		private DataSet1 ds = new DataSet1();

		private string Teeth1;

		private string BuyPrice;

		private string CompanyPrice;

		private string companyId;

		private int patientid;

		private int appointid;

		private bool done = false;

		private ClassDataBase dc;

		private dataClass codes;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private double total;

		private GUI gui = new GUI();

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private GroupBox groupBox2;

		private Label label7;

		private Button ADDBtn;

		private ComboBox doctorcomboBox;

		private DataGridView dataGridView1;

		private DateTimePicker appdateTimePicker1;

		private GroupBox groupBox5;

		private Button saveBtn;

		private TextBox tottextBox;

		private GroupBox groupBox1;

		private ComboBox PatientComboBox;

		private TextBox PricetextBox;

		private GroupBox groupBox4;

		private DateTimePicker dateTimePicker1;

		private ComboBox commentTextBox;

		private Button button1;

		private Button button6;

		private Button button5;

		private Button button3;

		private Button button4;

		private Button button2;

		private Panel panel1;

		private Label label9;

		private Label label8;

		private Label label6;

		private Label label1;

		private GroupBox groupBox6;

		private GroupBox groupBox7;

		private VistaButton vistaButton24;

		private VistaButton vistaButton17;

		private VistaButton vistaButton23;

		private VistaButton vistaButton18;

		private VistaButton vistaButton22;

		private VistaButton vistaButton19;

		private VistaButton vistaButton21;

		private VistaButton vistaButton20;

		private GroupBox groupBox3;

		private GroupBox groupBox8;

		private VistaButton vistaButton9;

		private VistaButton vistaButton10;

		private VistaButton vistaButton11;

		private VistaButton vistaButton12;

		private VistaButton vistaButton13;

		private VistaButton vistaButton14;

		private VistaButton vistaButton15;

		private VistaButton vistaButton16;

		private VistaButton U26;

		private VistaButton U29;

		private VistaButton U32;

		private VistaButton U30;

		private VistaButton U28;

		private VistaButton U31;

		private VistaButton U24;

		private VistaButton U22;

		private VistaButton U27;

		private VistaButton U23;

		private VistaButton U9;

		private VistaButton U16;

		private VistaButton U11;

		private VistaButton U10;

		private VistaButton U12;

		private VistaButton U13;

		private VistaButton U14;

		private VistaButton U15;

		private VistaButton U1;

		private VistaButton U8;

		private VistaButton U25;

		private VistaButton U3;

		private VistaButton U2;

		private VistaButton U18;

		private VistaButton U17;

		private VistaButton U4;

		private VistaButton U5;

		private VistaButton U6;

		private VistaButton U7;

		private VistaButton U19;

		private VistaButton U21;

		private VistaButton U20;

		private Panel panel2;

		private Label label22;

		private Label label23;

		private Label label24;

		private NumericUpDown numericUpDown13;

		private Label label18;

		private TableLayoutPanel tableLayoutPanel1;

		private NumericUpDown numericUpDown1;

		private Label label19;

		private Label label20;

		private NumericUpDown numericUpDown5;

		private Label label21;

		private NumericUpDown numericUpDown6;

		private NumericUpDown numericUpDown2;

		private NumericUpDown numericUpDown4;

		private NumericUpDown numericUpDown3;

		private Label label2;

		private NumericUpDown numericUpDown14;

		private Label label4;

		private TableLayoutPanel tableLayoutPanel2;

		private Label label5;

		private Label label16;

		private Label label17;

		private NumericUpDown numericUpDown7;

		private NumericUpDown numericUpDown8;

		private NumericUpDown numericUpDown11;

		private NumericUpDown numericUpDown12;

		private NumericUpDown numericUpDown9;

		private NumericUpDown numericUpDown10;

		private Label label25;

		private Label label26;

		private CheckBox checkBox3;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private GroupBox groupBox12;

		private TextBox textBox4;

		private FloatText floatText4;

		private FloatText floatText3;

		private FloatText floatText2;

		private FloatText Head;

		private FloatText Length;

		private FloatText YAge;

		private FloatText Weight;

		private FloatText MAge;

		private TextBox textBox8;

		private Button button7;

		private ComboBox AssistantcomboBox;

		private GroupBox groupBox9;

		private GroupBox groupBox21;

		private TextBox textBox3;

		private TextBox textBox5;

		private Button button16;

		private GroupBox groupBox10;

		private GroupBox groupBox24;

		private Button button17;

		private FloatText txtQty;

		private Label label72;

		private FloatText floatText1;

		private Label label71;

		private Label label70;

		private TextBox txtStore;

		private ComboBox itemIdComboBox;

		private GroupBox groupBox22;

		private DataGridView dataGridView3;

		private GroupBox groupBox25;

		private TextBox txtOthers;

		private TextBox txtUrinAnalysis;

		private TextBox txtRBS;

		private TextBox txtHeamoglobin;

		private TextBox txtTreatment;

		private TextBox txtUS;

		private TextBox txtWeight;

		private TextBox txtBP;

		private TextBox txtComplain;

		private GroupBox groupBox26;

		private DateTimePicker dtpDate;

		private TextBox txtHistory;

		private TextBox txtCS;

		private TextBox txtKind;

		private TextBox txtParity;

		private Button btnPatient;

		private Button button18;

		private ComboBox comboCategory;

		private FloatText floatText5;

		private DateTimePicker txtEDD;

		private DateTimePicker txtIMP;

		private ToolTip toolTip1;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;

		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;

		private DataGridViewTextBoxColumn ItemId;

		private DataGridViewTextBoxColumn Column3;

		private GroupBox groupBox27;

		private DateTimePicker dateTimeHeart;

		private TextBox txtBox21;

		private TextBox txtBox20;

		private TextBox txtBox19;

		private TextBox txtBox18;

		private TextBox txtBox17;

		private TextBox txtBox16;

		private TextBox txtBox15;

		private TextBox txtBox14;

		private TextBox txtBox13;

		private TextBox txtBox11;

		private TextBox txtBox12;

		private Button button22;

		private Panel PaidPanel;

		private ComboBox TreasuryCom;

		private TextBox EsalNoTxt;

		private Label lblTreasury;

		private Label label69;

		private Label label48;

		private TextBox Dariba;

		private Label label47;

		private TextBox AfterDariba;

		private Label label46;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlInsertCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlSelectCommand2;

		private Label label105;

		private TextBox textBoxDiscount;

		private GroupBox groupBox29;

		private ComboBox OfferName;

		private TextBox OfferPrice;

		private Button button23;

		private DateTimePicker dateTimePicker4;

		private RadioButton radioButton5;

		private RadioButton radioButton6;

		private DataGridViewTextBoxColumn Service;

		private DataGridViewTextBoxColumn Price;

		private DataGridViewTextBoxColumn ServiceDate;

		private DataGridViewTextBoxColumn Teethn;

		private DataGridViewTextBoxColumn Tid;

		private DataGridViewTextBoxColumn Cost;

		private DataGridViewTextBoxColumn Count;

		private DataGridViewTextBoxColumn driba;

		private DataGridViewTextBoxColumn Aftrdriba;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Column2;

		private DataGridViewTextBoxColumn Column4;

		private TextBox Rased;

		private RadioButton PayNaqdy;

		private RadioButton PayBefore;

		public PationtAccountReBack(int PATIENTID, int AppointID, int doctorId)
		{
			patientid = PATIENTID;
			docid = doctorId;
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
			appointid = AppointID;
			InitializeComponent();
		}

		public void GetBean()
		{
			try
			{
				string text = codes.Search2("select ServiceName from Properties ").Rows[0][0].ToString();
				DataTable dataTable = codes.Search2("select distinct(Service) from CompanyService where Service != '" + text + "' ");
				commentTextBox.DataSource = null;
				commentTextBox.DataSource = dataTable;
				commentTextBox.DisplayMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		public void DisplayImag()
		{
			try
			{
				DataTable tableText = dc.GetTableText("select ClinicType,EyeClinic,FemaleClinic,HeartClinic from DentalData ");
				panel1.Visible = Convert.ToBoolean(tableText.Rows[0][0].ToString());
				panel2.Visible = Convert.ToBoolean(tableText.Rows[0][1].ToString());
				groupBox25.Visible = Convert.ToBoolean(tableText.Rows[0][2].ToString());
				groupBox27.Visible = Convert.ToBoolean(tableText.Rows[0][3].ToString());
			}
			catch
			{
			}
		}

		private void PationtAccountReBack_Load(object sender, EventArgs e)
		{
			try
			{
				if (Convert.ToBoolean(codes.Search2("select AvoidPay2 from Properties").Rows[0][0].ToString()))
				{
					checkBox3.Enabled = false;
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataSource = codes.Search2("select distinct name,OfferID from Offers where StartDate<='" + DateTime.Now.ToString("MM/dd/yyyy") + "' and EndDate >='" + DateTime.Now.ToString("MM/dd/yyyy") + "'");
				OfferName.DataSource = dataSource;
				OfferName.ValueMember = "OfferID";
				OfferName.DisplayMember = "name";
				if (UsersClass.AutoEsal)
				{
					EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
					EsalNoTxt.Enabled = false;
				}
				else
				{
					EsalNoTxt.Text = "";
					EsalNoTxt.Enabled = true;
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select * from Categories");
				comboCategory.DataSource = dataTable;
				comboCategory.ValueMember = dataTable.Columns[0].ToString();
				comboCategory.DisplayMember = dataTable.Columns[1].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = codes.Search2("select * from Items");
				itemIdComboBox.DataSource = null;
				itemIdComboBox.DataSource = dataTable2;
				itemIdComboBox.DisplayMember = dataTable2.Columns[1].ToString();
				itemIdComboBox.ValueMember = dataTable2.Columns[0].ToString();
				itemIdComboBox.SelectedIndex = -1;
			}
			catch
			{
			}
			try
			{
				DataTable dataTable3 = codes.Search2("select ClinicType from DentalData");
				if (!Convert.ToBoolean(dataTable3.Rows[0][0].ToString()))
				{
					dataGridView1.Columns[3].Visible = false;
					dataGridView1.Columns[2].Width = 200;
				}
				else
				{
					dataGridView1.Columns[3].Visible = true;
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable4 = codes.Search2("select * from users where userId='" + Main.userId + "'");
				button5.Enabled = Convert.ToBoolean(dataTable4.Rows[0]["PrescriptionFrmBtn"].ToString());
				button4.Enabled = Convert.ToBoolean(dataTable4.Rows[0]["PatientXray"].ToString());
				button18.Enabled = Convert.ToBoolean(dataTable4.Rows[0]["FrmAnalyzesBtn"].ToString());
				button3.Enabled = Convert.ToBoolean(dataTable4.Rows[0]["PatientPay"].ToString());
				button6.Enabled = Convert.ToBoolean(dataTable4.Rows[0]["Comments"].ToString());
				button1.Enabled = Convert.ToBoolean(dataTable4.Rows[0]["OldServiceProvided"].ToString());
				button7.Enabled = Convert.ToBoolean(dataTable4.Rows[0]["FollowUpKids"].ToString());
				button22.Enabled = Convert.ToBoolean(dataTable4.Rows[0]["SurgeryDate"].ToString());
			}
			catch
			{
			}
			try
			{
				DataTable dataTable5 = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				TreasuryCom.DataSource = null;
				TreasuryCom.DataSource = dataTable5;
				TreasuryCom.DisplayMember = dataTable5.Columns[1].ToString();
				TreasuryCom.ValueMember = dataTable5.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable6 = codes.Search2(string.Concat("select company from PatientData where id='", PatientComboBox.SelectedValue, "'"));
				DataTable dataTable7 = codes.Search2("select Price from CompanyService where CompanyID='" + dataTable6.Rows[0][0].ToString() + "' and Service='" + commentTextBox.Text + "'");
				if (dataTable7.Rows.Count > 0)
				{
					PricetextBox.Text = dataTable7.Rows[0][0].ToString();
				}
				else
				{
					PricetextBox.Text = "0";
				}
			}
			catch
			{
			}
			DataTable dataTable8 = new DataTable();
			try
			{
				dataTable8 = dc.Select("SelectAllDoctor");
				gui.loadComboBox(doctorcomboBox, dataTable8);
			}
			catch
			{
			}
			try
			{
				DataTable dataTable9 = new DataTable();
				if (Convert.ToBoolean(codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString()))
				{
					dataTable9 = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True' order by PName");
					PatientComboBox.DataSource = dataTable9;
					PatientComboBox.DisplayMember = dataTable9.Columns[1].ToString();
					PatientComboBox.ValueMember = dataTable9.Columns[0].ToString();
				}
				else
				{
					dataTable9 = dc.Select("SelectAllPatient");
					gui.loadComboBox(PatientComboBox, dataTable9);
				}
			}
			catch
			{
			}
			try
			{
				dataTable8 = dc.Select("SelectAllAssistant");
				gui.loadComboBox(AssistantcomboBox, dataTable8);
			}
			catch
			{
			}
			try
			{
				doctorcomboBox.SelectedValue = docid;
				PatientComboBox.SelectedValue = patientid;
			}
			catch
			{
			}
			try
			{
				DataTable tableText = dc.GetTableText("select NaturalClinic from DentalData ");
				button7.Visible = Convert.ToBoolean(tableText.Rows[0][0].ToString());
			}
			catch
			{
			}
			try
			{
				txtEDD.Value = txtIMP.Value.AddMonths(9).AddDays(7.0);
			}
			catch
			{
			}
			DisplayImag();
			try
			{
				if (groupBox27.Visible)
				{
					DataTable dataTable10 = codes.Search2(string.Concat("select * from HeartCard where PatientID = '", PatientComboBox.SelectedValue, "' order by ID desc"));
					if (dataTable10.Rows.Count > 0)
					{
						txtBox13.Text = dataTable10.Rows[0]["PresentHistory"].ToString();
					}
					else
					{
						txtBox13.Text = "";
					}
				}
			}
			catch
			{
			}
			PricetextBox.Enabled = UsersClass.ChangeServicePrice;
			floatText1.Enabled = UsersClass.ChangeServicePrice;
			comboCategory_SelectedIndexChanged(sender, e);
			try
			{
				DataTable tableText2 = dc.GetTableText(string.Concat("select Dariba from PatientData where ID = '", PatientComboBox.SelectedValue, "'"));
				if (!Convert.ToBoolean(tableText2.Rows[0][0].ToString()))
				{
					AfterDariba.Visible = false;
					AfterDariba.Text = "0";
					Dariba.Text = "0";
				}
				else
				{
					AfterDariba.Visible = true;
					PatientComboBox_SelectedValueChanged(sender, e);
				}
			}
			catch
			{
			}
		}

		private void commentTextBox_TextChanged(object sender, EventArgs e)
		{
			decimal num = 0m;
			decimal num2 = 0m;
			string text = commentTextBox.Text;
			if (text.StartsWith(" "))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("It IS Not Allowed To Use Space In The Beginning", "Notes");
				}
				else
				{
					MessageBox.Show("لا يمكن ترك فراغ في بداية الإسم", "تنبيه");
				}
				commentTextBox.Text = "";
			}
			try
			{
				DataTable dataTable = codes.Search2("SELECT dbo.Company.Name,dbo.Company.ID,dbo.Company.Status,dbo.Company.Discount,dbo.Company.Nesba\r\nFROM         dbo.Company INNER JOIN\r\n                      dbo.PatientData ON dbo.Company.ID = dbo.PatientData.company where PatientData.ID='" + PatientComboBox.SelectedValue.ToString() + "'");
				string text2 = dataTable.Rows[0][2].ToString();
				companyId = dataTable.Rows[0][1].ToString();
				DataTable dataTable2 = codes.Search2(string.Concat("select Price,Dariba from CompanyService where Service='", commentTextBox.Text, "' and CompanyID = '", comboCategory.SelectedValue, "'"));
				if (dataTable2.Rows.Count > 0)
				{
					if (text2 == "1")
					{
						if (Convert.ToBoolean(dataTable.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(dataTable.Rows[0][3]) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = Convert.ToDouble(dataTable.Rows[0][3]).ToString();
						}
						PricetextBox.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text2 == "2")
					{
						string text3 = codes.Search2("SELECT dbo.DiscountCategory.Discount FROM DiscountCategory where Category = '" + comboCategory.Text + "'").Rows[0][0].ToString();
						if (Convert.ToBoolean(dataTable.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(text3) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = text3;
						}
						PricetextBox.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text2 == "3")
					{
						string text3 = codes.Search2("SELECT     Discount\r\nFROM         dbo.DiscountService where Service = '" + commentTextBox.Text + "'").Rows[0][0].ToString();
						if (Convert.ToBoolean(dataTable.Rows[0]["Nesba"].ToString()))
						{
							CompanyPrice = (Convert.ToDouble(dataTable2.Rows[0][0]) * Convert.ToDouble(text3) / 100.0).ToString();
						}
						else
						{
							CompanyPrice = text3;
						}
						PricetextBox.Text = (Convert.ToDouble(dataTable2.Rows[0][0]) - Convert.ToDouble(CompanyPrice)).ToString();
					}
					if (text2 == "4")
					{
						PricetextBox.Text = dataTable2.Rows[0][0].ToString();
						CompanyPrice = "0";
					}
				}
				else
				{
					PricetextBox.Text = "0";
				}
				DataTable tableText = dc.GetTableText(string.Concat("select Dariba from PatientData where ID = '", PatientComboBox.SelectedValue, "'"));
				if (tableText.Rows.Count > 0)
				{
					if (!Convert.ToBoolean(tableText.Rows[0][0].ToString()))
					{
						AfterDariba.Text = "0";
						Dariba.Text = "0";
						num = Convert.ToDecimal(PricetextBox.Text) + Convert.ToDecimal(PricetextBox.Text) * Convert.ToDecimal(Dariba.Text) / 100m;
					}
					else
					{
						PricetextBox.Text = dataTable2.Rows[0][0].ToString();
						Dariba.Text = dataTable2.Rows[0][1].ToString();
						num = Convert.ToDecimal(PricetextBox.Text) + Convert.ToDecimal(PricetextBox.Text) * Convert.ToDecimal(Dariba.Text) / 100m;
					}
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable3 = codes.Search2(string.Concat("select DiscountNesba,DiscountValue from CompanyService where Service='", commentTextBox.Text, "' and CompanyID = '", comboCategory.SelectedValue, "'"));
				if (Convert.ToDecimal(dataTable3.Rows[0][0].ToString()) != 0m)
				{
					num2 = num - num * Convert.ToDecimal(dataTable3.Rows[0][0].ToString()) / 100m;
					if (Settings.Default.Language == "en-GB")
					{
						label105.Text = "Discount%";
					}
					else
					{
						label105.Text = "نسبة الخصم";
					}
					textBoxDiscount.Text = dataTable3.Rows[0][0].ToString();
					AfterDariba.Text = num2.ToString();
				}
				else if (Convert.ToDecimal(dataTable3.Rows[0][1].ToString()) != 0m)
				{
					num2 = num - Convert.ToDecimal(dataTable3.Rows[0][1].ToString());
					if (Settings.Default.Language == "en-GB")
					{
						label105.Text = "Discount";
					}
					else
					{
						label105.Text = "قيمة الخصم";
					}
					textBoxDiscount.Text = dataTable3.Rows[0][1].ToString();
					AfterDariba.Text = num2.ToString();
				}
				else
				{
					if (Settings.Default.Language == "en-GB")
					{
						label105.Text = "Discount";
					}
					else
					{
						label105.Text = "الخصم";
					}
					textBoxDiscount.Text = "0";
					AfterDariba.Text = num.ToString();
				}
			}
			catch
			{
			}
		}

		private void PricetextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && PricetextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل ارقام فقط");
				}
				e.Handled = true;
			}
			catch
			{
			}
		}

		private void PricetextBox_Leave(object sender, EventArgs e)
		{
			try
			{
				if (PricetextBox.Text == "")
				{
					PricetextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void ADDBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (commentTextBox.Text != "")
				{
					bool flag = false;
					foreach (Control control in panel1.Controls)
					{
						if (control is VistaButton && control.BackColor == Color.Red)
						{
							string text = control.Name.ToString();
							int num = Convert.ToInt32(text.Remove(0, 1));
							DataTable dataTable = codes.Search2("select Name from Teath where Id='" + num + "'");
							dataGridView1.Rows.Add(commentTextBox.Text, Convert.ToDouble(floatText5.Text) * Convert.ToDouble(PricetextBox.Text), dateTimePicker1.Value.ToString("yyyy/MM/dd"), dataTable.Rows[0][0].ToString(), num, CompanyPrice, floatText5.Text, Dariba.Text, Convert.ToDouble(floatText5.Text) * Convert.ToDouble(AfterDariba.Text), 0, 0, (OfferName.SelectedValue == null) ? " " : OfferName.SelectedValue);
							flag = true;
							total = Convert.ToDouble(tottextBox.Text);
							total += Convert.ToDouble(floatText5.Text) * Convert.ToDouble(AfterDariba.Text);
							tottextBox.Text = total.ToString();
							commentTextBox.Text = "";
							PricetextBox.Text = "0";
							floatText5.Text = "1";
							AssistantcomboBox.Enabled = false;
						}
					}
					if (!flag)
					{
						dataGridView1.Rows.Add(commentTextBox.Text, Convert.ToDouble(floatText5.Text) * Convert.ToDouble(PricetextBox.Text), dateTimePicker1.Value.ToString("yyyy/MM/dd"), "General", "33", CompanyPrice, floatText5.Text, Dariba.Text, Convert.ToDouble(floatText5.Text) * Convert.ToDouble(AfterDariba.Text), 0, 0, (OfferName.SelectedValue == null) ? " " : OfferName.SelectedValue);
						flag = true;
						total = Convert.ToDouble(tottextBox.Text);
						total += Convert.ToDouble(floatText5.Text) * Convert.ToDouble(AfterDariba.Text);
						tottextBox.Text = total.ToString();
						commentTextBox.Text = "";
						PricetextBox.Text = "0";
						floatText5.Text = "1";
						AssistantcomboBox.Enabled = false;
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Service Name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("من فضلك ادخل الخدمة", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (!checkBox3.Checked)
				{
					goto IL_0149;
				}
				if (PayNaqdy.Checked)
				{
					if (!(EsalNoTxt.Text == ""))
					{
						DataTable dataTable = codes.Search2("select EsalNo from Esal where EsalNo ='" + EsalNoTxt.Text + "'");
						if (dataTable.Rows.Count > 0)
						{
							MessageBox.Show("رقم الايصال مسجل من قبل");
							EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
						}
						goto IL_0149;
					}
					MessageBox.Show("من فضلك ادخل رقم الايصال");
				}
				else if (Rased.Text == "0.00" || Rased.Text == "0")
				{
					MessageBox.Show("لا يمكن الدفع من مدفوعات سابقة لان الحساب السابق للمريض بصفر");
				}
				else
				{
					if (!(Convert.ToDecimal(tottextBox.Text) > Convert.ToDecimal(Rased.Text)))
					{
						goto IL_0149;
					}
					MessageBox.Show("لا يمكن الدفع من مدفوعات سابقة لان الحساب السابق للمريض أقل من اجمالي الكشف");
				}
				goto end_IL_0001;
				IL_0149:
				string text = "";
				double num = 0.0;
				double num2 = 0.0;
				for (int i = 0; i < dataGridView3.Rows.Count; i++)
				{
					num += Convert.ToDouble(dataGridView3.Rows[i].Cells[1].Value) * Convert.ToDouble(dataGridView3.Rows[i].Cells[2].Value);
				}
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					num2 += Convert.ToDouble(dataGridView1.Rows[i].Cells[5].Value);
				}
				string value = codes.Search("select isnull(sum(Madeen),0) -  isnull(sum(Daen),0) from Company5 where CompanyId = '" + companyId + "'").Rows[0][0].ToString();
				string text2 = EsalNoTxt.Text;
				string[] array = new string[8] { "PatientId", "DoctorID", "Bean", "Price", "Date", "BeanDate", "TeathId", "Assistant" };
				if (dataGridView1.Rows.Count > 1)
				{
					if (checkBox3.Checked)
					{
						if (PayNaqdy.Checked)
						{
							string text3 = "";
							DataTable dataTable2 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
							try
							{
								text3 = dataTable2.Rows[0][0].ToString();
							}
							catch
							{
							}
							codes.Edit2("update Stock Set Value= Value + '" + tottextBox.Text + "' where ID = '" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "'");
							codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('إعادة كشف' ,'" + Convert.ToDecimal(tottextBox.Text) + "','" + PatientComboBox.Text + " إيصال رقم: " + EsalNoTxt.Text + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
							for (int i = 1; i < dataGridView1.Rows.Count; i++)
							{
								codes.Add2(string.Concat("INSERT INTO PatientAccount\r\n                   (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay,BeanDate,TeathId,Appears,Assistant,StockId,ServiceCount,Dariba,PriceBeforeDariba,OfferNumUsed, OfferID) VALUES ('", PatientComboBox.SelectedValue, "','", doctorcomboBox.SelectedValue, "','", dataGridView1.Rows[i - 1].Cells[0].Value.ToString(), "', '", dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString(), "',1, '", dataGridView1.Rows[i - 1].Cells[2].Value.ToString(), "','", dataGridView1.Rows[i - 1].Cells[1].Value.ToString(), "' ,'", dataGridView1.Rows[i - 1].Cells[2].Value.ToString(), "','", dataGridView1.Rows[i - 1].Cells[4].Value.ToString(), "',0,'", AssistantcomboBox.Text, "','", Convert.ToInt32(TreasuryCom.SelectedValue.ToString()), "','", dataGridView1.Rows[i - 1].Cells["Count"].Value.ToString(), "', '", dataGridView1.Rows[i - 1].Cells["driba"].Value.ToString(), "', '", dataGridView1.Rows[i - 1].Cells[1].Value.ToString(), "',", dataGridView1.Rows[i - 1].Cells[10].Value.ToString(), ",'", dataGridView1.Rows[i - 1].Cells[11].Value.ToString(), "')"));
								DataTable dataTable3 = codes.Search2("select max(ID) from PatientAccount");
								codes.Add2("insert into AccountDetails (PatientId, DoctorId, Date, Bean, Price, PricePay, PatientAcountId, StockId) values('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','" + dataGridView1.Rows[i - 1].Cells[2].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells[0].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString() + "','" + Convert.ToInt32(dataTable3.Rows[0][0].ToString()) + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
								codes.Add2("insert into Esal (EsalNo, PatientAcountId, Date,Pay, Patient, Bean, Price, Teeth, Company, Username,Assistant) values('" + text2 + "','" + Convert.ToInt32(dataTable3.Rows[0][0].ToString()) + "','" + dataGridView1.Rows[i - 1].Cells[2].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString() + "','" + PatientComboBox.Text + "','" + dataGridView1.Rows[i - 1].Cells[0].Value.ToString() + "', '" + dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString() + "', '" + dataGridView1.Rows[i - 1].Cells[3].Value.ToString() + "','" + text3 + "','" + Main.usernames + "','" + AssistantcomboBox.Text + "')");
								if (num2 != 0.0)
								{
									codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + dataGridView1.Rows[i - 1].Cells[5].Value.ToString() + "','" + (Convert.ToDouble(value) + Convert.ToDouble(dataGridView1.Rows[i - 1].Cells[5].Value.ToString())) + "','" + dataGridView1.Rows[i - 1].Cells[0].Value.ToString() + "'+' - '+'" + PatientComboBox.Text + "'+' - '+'" + doctorcomboBox.Text + "','" + dataGridView1.Rows[i - 1].Cells[2].Value.ToString() + "','" + Convert.ToInt32(dataTable3.Rows[0][0].ToString()) + "')");
								}
							}
							if (dataGridView3.Rows.Count > 0)
							{
								try
								{
									text = codes.Search2(string.Concat("insert into PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay, BeanDate,ServiceCount,StockId) values('", PatientComboBox.SelectedValue, "','", doctorcomboBox.SelectedValue, "','سحب كميات اصناف','", num.ToString(), "','True','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "','", num.ToString(), "','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "',1,", Convert.ToInt32(TreasuryCom.SelectedValue.ToString()), ");select @@identity")).Rows[0][0].ToString();
									codes.Add2("insert into AccountDetails (PatientId, DoctorId, Date, Bean, Price, PricePay, PatientAcountId, StockId) values('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','سحب كميات اصناف','" + num.ToString() + "','" + num.ToString() + "','" + text + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
									codes.Add2("insert into Esal (EsalNo, PatientAcountId, Date,Pay, Patient, Bean, Price, Teeth, Company, Username,Assistant) values('" + text2 + "','" + text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + num + "','" + PatientComboBox.Text + "','سحب كميات اصناف','" + num + "','','" + text3 + "','" + Main.usernames + "','" + AssistantcomboBox.Text + "')");
								}
								catch
								{
								}
							}
							string[] fields = new string[3] { "PatientID", "Pay", "Date" };
							b = dc.Insert("AddPatientPay", fields, Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), tottextBox.Text, appdateTimePicker1.Value.ToString("MM/dd/yyyy"));
							b = true;
						}
						else
						{
							string text3 = "";
							DataTable dataTable2 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
							try
							{
								text3 = dataTable2.Rows[0][0].ToString();
							}
							catch
							{
							}
							decimal num3 = Convert.ToDecimal(Rased.Text) - Convert.ToDecimal(tottextBox.Text);
							for (int i = 1; i < dataGridView1.Rows.Count; i++)
							{
								codes.Add2(string.Concat("INSERT INTO PatientAccount\r\n                   (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay,BeanDate,TeathId,Appears,Assistant,StockId,ServiceCount,Dariba,PriceBeforeDariba,OfferNumUsed, OfferID) VALUES ('", PatientComboBox.SelectedValue, "','", doctorcomboBox.SelectedValue, "','", dataGridView1.Rows[i - 1].Cells[0].Value.ToString(), "', '", dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString(), "',1, '", dataGridView1.Rows[i - 1].Cells[2].Value.ToString(), "','", dataGridView1.Rows[i - 1].Cells[1].Value.ToString(), "' ,'", dataGridView1.Rows[i - 1].Cells[2].Value.ToString(), "','", dataGridView1.Rows[i - 1].Cells[4].Value.ToString(), "',0,'", AssistantcomboBox.Text, "','", Convert.ToInt32(TreasuryCom.SelectedValue.ToString()), "','", dataGridView1.Rows[i - 1].Cells["Count"].Value.ToString(), "', '", dataGridView1.Rows[i - 1].Cells["driba"].Value.ToString(), "', '", dataGridView1.Rows[i - 1].Cells[1].Value.ToString(), "',", dataGridView1.Rows[i - 1].Cells[10].Value.ToString(), ",'", dataGridView1.Rows[i - 1].Cells[11].Value.ToString(), "')"));
								DataTable dataTable3 = codes.Search2("select max(ID) from PatientAccount");
								codes.Add2("insert into AccountDetails (PatientId, DoctorId, Date, Bean, Price, PricePay, PatientAcountId, StockId) values('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','" + dataGridView1.Rows[i - 1].Cells[2].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells[0].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString() + "','" + Convert.ToInt32(dataTable3.Rows[0][0].ToString()) + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
								codes.Add2("insert into Esal (EsalNo, PatientAcountId, Date,Pay, Patient, Bean, Price, Teeth, Company, Username,Assistant) values('" + text2 + "','" + Convert.ToInt32(dataTable3.Rows[0][0].ToString()) + "','" + dataGridView1.Rows[i - 1].Cells[2].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString() + "','" + PatientComboBox.Text + "','" + dataGridView1.Rows[i - 1].Cells[0].Value.ToString() + "', '" + dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString() + "', '" + dataGridView1.Rows[i - 1].Cells[3].Value.ToString() + "','" + text3 + "','" + Main.usernames + "','" + AssistantcomboBox.Text + "')");
								if (num2 != 0.0)
								{
									codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + dataGridView1.Rows[i - 1].Cells[5].Value.ToString() + "','" + (Convert.ToDouble(value) + Convert.ToDouble(dataGridView1.Rows[i - 1].Cells[5].Value.ToString())) + "','" + dataGridView1.Rows[i - 1].Cells[0].Value.ToString() + "'+' - '+'" + PatientComboBox.Text + "'+' - '+'" + doctorcomboBox.Text + "','" + dataGridView1.Rows[i - 1].Cells[2].Value.ToString() + "','" + Convert.ToInt32(dataTable3.Rows[0][0].ToString()) + "')");
								}
							}
							DataTable dataTable4 = codes.Search2("select max(ID) from Esal");
							codes.Search2(string.Concat("insert into PatientBeforePay (PatientID,Daen,Madeen,Raseed,Bayan,[Date],EsalNum,StockID) values (", PatientComboBox.SelectedValue, ",", Convert.ToDecimal(tottextBox.Text) * -1m, ",0,", num3, ",'كشف مدفوع من رصيد سابق','", appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "','", dataTable4.Rows[0][0].ToString(), "','0','true')"));
							if (dataGridView3.Rows.Count > 0)
							{
								try
								{
									text = codes.Search2(string.Concat("insert into PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay, BeanDate,ServiceCount,StockId) values('", PatientComboBox.SelectedValue, "','", doctorcomboBox.SelectedValue, "','سحب كميات اصناف','", num.ToString(), "','True','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "','", num.ToString(), "','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "',1,", Convert.ToInt32(TreasuryCom.SelectedValue.ToString()), ");select @@identity")).Rows[0][0].ToString();
									codes.Add2("insert into AccountDetails (PatientId, DoctorId, Date, Bean, Price, PricePay, PatientAcountId, StockId) values('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','سحب كميات اصناف','" + num.ToString() + "','" + num.ToString() + "','" + text + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
									codes.Add2("insert into Esal (EsalNo, PatientAcountId, Date,Pay, Patient, Bean, Price, Teeth, Company, Username,Assistant) values('" + text2 + "','" + text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + num + "','" + PatientComboBox.Text + "','سحب كميات اصناف','" + num + "','','" + text3 + "','" + Main.usernames + "','" + AssistantcomboBox.Text + "')");
								}
								catch
								{
								}
							}
							b = true;
						}
					}
					else
					{
						for (int i = 1; i < dataGridView1.Rows.Count; i++)
						{
							b = true;
							string text4 = codes.Search2("INSERT INTO PatientAccount(PatientId, DoctorID, Bean, Price, Pay, Date, PricePay,BeanDate,TeathId,Appears,Assistant,ServiceCount,Dariba,PriceBeforeDariba,OfferNumUsed, OfferID) VALUES ('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','" + dataGridView1.Rows[i - 1].Cells[0].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString() + "', 0,'" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "', 0,'" + dataGridView1.Rows[i - 1].Cells[2].Value.ToString() + "','" + dataGridView1.Rows[i - 1].Cells[4].Value.ToString() + "','False','" + AssistantcomboBox.Text + "','" + dataGridView1.Rows[i - 1].Cells["Count"].Value.ToString() + "', '" + dataGridView1.Rows[i - 1].Cells["driba"].Value.ToString() + "', '" + dataGridView1.Rows[i - 1].Cells[1].Value.ToString() + "'," + dataGridView1.Rows[i - 1].Cells[10].Value.ToString() + ", " + dataGridView1.Rows[i - 1].Cells[11].Value.ToString() + ");select @@identity").Rows[0][0].ToString();
							if (num2 != 0.0)
							{
								codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + dataGridView1.Rows[i - 1].Cells[5].Value.ToString() + "','" + (Convert.ToDouble(value) + Convert.ToDouble(dataGridView1.Rows[i - 1].Cells[5].Value.ToString())) + "','" + dataGridView1.Rows[i - 1].Cells[0].Value.ToString() + "'+' - '+'" + PatientComboBox.Text + "'+' - '+'" + doctorcomboBox.Text + "','" + dataGridView1.Rows[i - 1].Cells[2].Value.ToString() + "','" + text4 + "')");
							}
						}
						if (dataGridView3.Rows.Count > 0)
						{
							try
							{
								text = codes.Search2(string.Concat("insert into PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay, BeanDate,ServiceCount) values('", PatientComboBox.SelectedValue, "','", doctorcomboBox.SelectedValue, "','سحب كميات اصناف','", num.ToString(), "','False','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "',0,'", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "',1);select @@identity")).Rows[0][0].ToString();
							}
							catch
							{
							}
						}
					}
					if (b)
					{
						DataTable tableText = dc.GetTableText("select NaturalClinic from DentalData ");
						bool flag = Convert.ToBoolean(tableText.Rows[0][0]);
						try
						{
							Codes.Add2("insert into Diagnoses (PatientId,Diagnosis,Date,Notes,DoctorId) values('" + PatientComboBox.SelectedValue.ToString() + "','" + textBox3.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + textBox5.Text + "','" + doctorcomboBox.SelectedValue.ToString() + "')");
						}
						catch
						{
						}
						if (flag)
						{
							try
							{
								int num4 = 12 * Convert.ToInt32(YAge.Text) + Convert.ToInt32(MAge.Text);
								Codes.Add2("insert into ChildDetails (PatientId,Age,Weight,Length,HeadCircumference,Others,Date,Temperature,BloodPressure,pulse,Color) values('" + PatientComboBox.SelectedValue.ToString() + "','" + num4 + "','" + Weight.Text + "','" + Length.Text + "','" + Head.Text + "','" + textBox8.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + floatText2.Text + "','" + floatText3.Text + "','" + floatText4.Text + "','" + textBox4.Text + "')");
							}
							catch
							{
							}
						}
						DataTable tableText2 = dc.GetTableText("select ClinicType,EyeClinic from DentalData ");
						if (numericUpDown1.Value != 0m || numericUpDown1.Value != 0m || numericUpDown2.Value != 0m || numericUpDown3.Value != 0m || numericUpDown4.Value != 0m || numericUpDown5.Value != 0m || numericUpDown6.Value != 0m || numericUpDown7.Value != 0m || (numericUpDown8.Value != 0m && numericUpDown9.Value != 0m) || numericUpDown10.Value != 0m || numericUpDown11.Value != 0m || numericUpDown12.Value != 0m || numericUpDown13.Value != 0m || numericUpDown14.Value != 0m)
						{
							Codes.Add2("insert into Detect (ClientID,DRsph,DRcyl,DRax,RRsph,RRcyl,RRax,DLsph,DLcyl,DLax,RLsph,RLcyl,Rlax,DateDetect,IPDR,IPDL) values ('" + PatientComboBox.SelectedValue.ToString() + "','" + numericUpDown1.Value + "','" + numericUpDown2.Value + "','" + numericUpDown3.Value + "','" + numericUpDown4.Value + "','" + numericUpDown5.Value + "','" + numericUpDown6.Value + "','" + numericUpDown7.Value + "','" + numericUpDown8.Value + "','" + numericUpDown9.Value + "','" + numericUpDown10.Value + "','" + numericUpDown11.Value + "','" + numericUpDown12.Value + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + numericUpDown13.Value + "','" + numericUpDown14.Value + "')");
							if (Convert.ToBoolean(tableText2.Rows[0][1]))
							{
								((DataTable)(object)ds.Glasses).Rows.Add(numericUpDown1.Value, numericUpDown2.Value, numericUpDown3.Value, numericUpDown4.Value, numericUpDown5.Value, numericUpDown6.Value, numericUpDown7.Value, numericUpDown8.Value, numericUpDown9.Value, numericUpDown10.Value, numericUpDown11.Value, numericUpDown12.Value, numericUpDown13.Value, numericUpDown14.Value);
							}
						}
						try
						{
							if (dataGridView3.Rows.Count > 0)
							{
								codes.Add2(string.Concat("insert into Sahb (PatientId, Date,PatientAccountId) values('", PatientComboBox.SelectedValue, "','", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "','", text, "')"));
								string text5 = codes.Search2("select max(ID) from Sahb").Rows[0][0].ToString();
								for (int i = 0; i < dataGridView3.Rows.Count; i++)
								{
									decimal num5 = 0m;
									try
									{
										DataTable dataTable5 = codes.Search2("select Qnt from store where ItemID='" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "'");
										num5 = Convert.ToDecimal(dataTable5.Rows[0][0].ToString());
									}
									catch
									{
									}
									decimal num6 = 0m;
									try
									{
										DataTable dataTable6 = codes.Search2("select BuyPrice from store where ItemID='" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "'");
										num6 = Convert.ToDecimal(dataTable6.Rows[0][0].ToString());
									}
									catch
									{
									}
									decimal num7 = 0m;
									try
									{
										DataTable dataTable7 = codes.Search2("select SalePrice from Items where ID='" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "'");
										num7 = Convert.ToDecimal(dataTable7.Rows[0][0].ToString());
									}
									catch
									{
									}
									codes.Add2("INSERT INTO ItemsMove\r\n                      (ItemId, StoreId, IncomeQnt, IncomePrice, OutcomeQnt, OutcomePrice, LastQnt, LastIncomePrice, LastOutComePrice, Bayan, MoveDate, UserId, Time,Type)\r\n                       VALUES ('" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "',0,0,0,'" + dataGridView3.Rows[i].Cells[2].Value.ToString() + "','" + dataGridView3.Rows[i].Cells[1].Value.ToString() + "','" + num5 + "','" + num6 + "','" + num7 + "','كشوفات','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Main.userId + "','" + dateTimePicker1.Value.ToShortTimeString() + "','خروج')");
									codes.Add2("insert into Sahb_details (SahbId, ItemId, Price, Qty) values('" + text5 + "','" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "','" + dataGridView3.Rows[i].Cells[1].Value.ToString() + "','" + dataGridView3.Rows[i].Cells[2].Value.ToString() + "')");
									codes.Edit2("update Store set Qnt = Qnt - '" + dataGridView3.Rows[i].Cells[2].Value.ToString() + "' where ItemId = '" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "'");
									codes.Add2("insert into SahbItem (TypeSahb, ItemId, Qty, Date, Notes) values('استهلاك مرضى','" + dataGridView3.Rows[i].Cells[3].Value.ToString() + "','" + dataGridView3.Rows[i].Cells[2].Value.ToString() + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','')");
								}
							}
						}
						catch
						{
						}
						try
						{
							if (groupBox25.Visible)
							{
								DataTable dataTable8 = codes.Search2("select * from HeaderCard where PatientID = " + PatientComboBox.SelectedValue);
								if (dataTable8.Rows.Count > 0)
								{
									codes.Edit2(string.Concat("update HeaderCard set Parity = '", txtParity.Text, "', IMP = '", txtIMP.Text, "', Kind = '", txtKind.Text, "', CS = '", txtCS.Text, "', EDD = '", txtEDD.Text, "', History = '", txtHistory.Text, "' where PatientID = '", PatientComboBox.SelectedValue, "'"));
								}
								else
								{
									codes.Add2(string.Concat("insert into HeaderCard (PatientID, Parity, IMP, Kind, CS, EDD, History) values ('", PatientComboBox.SelectedValue, "', '", txtParity.Text, "', '", txtIMP.Text, "', '", txtKind.Text, "', '", txtCS.Text, "', '", txtEDD.Text, "', '", txtHistory.Text, "')"));
								}
								codes.Add2(string.Concat("insert into CardDetails (PatientID, Date, Complain, BP, Weight, US, Treatment, Heamoglobin, RBS, UrinAnalysis, Others) values ('", PatientComboBox.SelectedValue, "', '", dtpDate.Value.ToString("MM/dd/yyyy"), "', '", txtComplain.Text, "', '", txtBP.Text, "', '", txtWeight.Text, "', '", txtUS.Text, "', '", txtTreatment.Text, "', '", txtHeamoglobin.Text, "', '", txtRBS.Text, "', '", txtUrinAnalysis.Text, "', '", txtOthers.Text, "')"));
							}
						}
						catch
						{
						}
						try
						{
							if (groupBox27.Visible)
							{
								codes.Add2(string.Concat("insert into HeartCard (PatientID, Complaint, PresentHistory, PastHistory, [B/P], Puse, [RR], Temp, [PP], GeneralExamination, SystemicExamination, [N.B.], Date) values('", PatientComboBox.SelectedValue, "','", txtBox11.Text, "','", txtBox12.Text, "','", txtBox13.Text, "','", txtBox14.Text, "','", txtBox15.Text, "','", txtBox16.Text, "','", txtBox17.Text, "','", txtBox18.Text, "','", txtBox19.Text, "','", txtBox20.Text, "','", txtBox21.Text, "','", dateTimeHeart.Value.ToString("MM/dd/yyyy"), "')"));
							}
						}
						catch
						{
						}
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove("تسجيل أعادة الكشف علي مريض");
						try
						{
							string[] fields2 = new string[1] { "ID" };
							dc.Update("updateAppointPackDone", fields2, appointid);
						}
						catch
						{
						}
						DataTable tableText3 = dc.GetTableText("select ClinicType,EyeClinic from DentalData ");
						bool flag2 = Convert.ToBoolean(tableText3.Rows[0][0]);
						DataTable dataTable9 = codes.Search2("select chTxtUnderPres,TxtUnderPres from Properties");
						string text6 = "";
						text6 = ((!Convert.ToBoolean(dataTable9.Rows[0]["chTxtUnderPres"].ToString())) ? "" : dataTable9.Rows[0]["TxtUnderPres"].ToString());
						if (checkBox3.Checked)
						{
							ds.Clear();
							string text3 = "";
							DataTable dataTable2 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
							try
							{
								text3 = dataTable2.Rows[0][0].ToString();
							}
							catch
							{
							}
							if (!flag2)
							{
								for (int i = 1; i < dataGridView1.Rows.Count; i++)
								{
									((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, dataGridView1.Rows[i - 1].Cells[2].Value.ToString(), dataGridView1.Rows[i - 1].Cells[0].Value.ToString(), tottextBox.Text, dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString(), tottextBox.Text, dataGridView1.Rows[i - 1].Cells[3].Value.ToString(), text3, Main.usernames, text2, Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Count"].Value), Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Price"].Value) / Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Count"].Value), 0, doctorcomboBox.Text);
								}
								for (int j = 0; j < dataGridView3.Rows.Count; j++)
								{
									string text7 = (Convert.ToDecimal(dataGridView3.Rows[j].Cells[2].Value.ToString()) * Convert.ToDecimal(dataGridView3.Rows[j].Cells[1].Value.ToString())).ToString();
									((DataTable)(object)ds.SahbItemEsal).Rows.Add(dataGridView3.Rows[j].Cells[0].Value.ToString(), dataGridView3.Rows[j].Cells[2].Value.ToString(), dataGridView3.Rows[j].Cells[1].Value.ToString(), text7);
								}
								if ((numericUpDown1.Value != 0m || numericUpDown1.Value != 0m || numericUpDown2.Value != 0m || numericUpDown3.Value != 0m || numericUpDown4.Value != 0m || numericUpDown5.Value != 0m || numericUpDown6.Value != 0m || numericUpDown7.Value != 0m || (numericUpDown8.Value != 0m && numericUpDown9.Value != 0m) || numericUpDown10.Value != 0m || numericUpDown11.Value != 0m || numericUpDown12.Value != 0m || numericUpDown13.Value != 0m || numericUpDown14.Value != 0m) && Convert.ToBoolean(tableText3.Rows[0][1]))
								{
									((DataTable)(object)ds.Glasses).Rows.Add(numericUpDown1.Value, numericUpDown2.Value, numericUpDown3.Value, numericUpDown4.Value, numericUpDown5.Value, numericUpDown6.Value, numericUpDown7.Value, numericUpDown8.Value, numericUpDown9.Value, numericUpDown10.Value, numericUpDown11.Value, numericUpDown12.Value, numericUpDown13.Value, numericUpDown14.Value);
								}
								sqlConnection1.ConnectionString = codes.ConnectionStr;
								sqlDataAdapter1.Fill(ds);
								sqlConnection2.ConnectionString = Codes.ConnectionStr;
								sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
								sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
								sqlDataAdapter2.Fill(ds);
								DataTable dataTable10 = Codes.Search2("select EsalPrinter from Properties");
								switch (dataTable10.Rows[0][0].ToString())
								{
								case "A5":
								{
									ReportDocument reportDocument = new ReportDocument();
									reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptA5.rpt");
									try
									{
										reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
										textObject.Text = text6;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									reportDocument.SetDataSource(ds);
									StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
									statmentRptFrm.ShowDialog();
									break;
								}
								case "Reset":
								{
									ReportDocument reportDocument = new ReportDocument();
									reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1Reset.rpt");
									try
									{
										reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
										textObject.Text = text6;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									reportDocument.SetDataSource(ds);
									StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
									statmentRptFrm.ShowDialog();
									break;
								}
								case "1/2 A4":
								{
									((DataTable)(object)ds.Statment).Rows.Clear();
									double num8 = 0.0;
									for (int i = 1; i < dataGridView1.Rows.Count; i++)
									{
										num8 += Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString());
									}
									for (int i = 1; i < dataGridView1.Rows.Count; i++)
									{
										((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, dataGridView1.Rows[i - 1].Cells["ServiceDate"].Value.ToString(), dataGridView1.Rows[i - 1].Cells["Service"].Value.ToString(), num8, dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString(), tottextBox.Text, dataGridView1.Rows[i - 1].Cells["Teethn"].Value.ToString(), text3, Main.usernames, text2, Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Count"].Value), Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Price"].Value) / Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Count"].Value), Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString()) * Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["driba"].Value.ToString()) / 100.0, doctorcomboBox.Text);
									}
									sqlConnection2.ConnectionString = Codes.ConnectionStr;
									sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
									sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
									sqlDataAdapter2.Fill(ds);
									ReportDocument reportDocument = new ReportDocument();
									reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt_HalfA4.rpt");
									try
									{
										reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
										textObject.Text = text6;
									}
									catch
									{
									}
									reportDocument.SetDataSource(ds);
									try
									{
										reportDocument.SetParameterValue("DoctorName", doctorcomboBox.Text);
									}
									catch
									{
									}
									FrmStatmentRpt_HalfA4 frmStatmentRpt_HalfA = new FrmStatmentRpt_HalfA4(reportDocument);
									frmStatmentRpt_HalfA.ShowDialog();
									break;
								}
								default:
								{
									ReportDocument reportDocument = new ReportDocument();
									reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1.rpt");
									try
									{
										reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
										textObject.Text = text6;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									reportDocument.SetDataSource(ds);
									reportDocument.SetParameterValue("Assistant", AssistantcomboBox.Text);
									StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
									statmentRptFrm.ShowDialog();
									break;
								}
								}
							}
							else
							{
								for (int i = 1; i < dataGridView1.Rows.Count; i++)
								{
									((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, dataGridView1.Rows[i - 1].Cells[2].Value.ToString(), dataGridView1.Rows[i - 1].Cells[0].Value.ToString(), tottextBox.Text, dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString(), tottextBox.Text, dataGridView1.Rows[i - 1].Cells[3].Value.ToString(), text3, Main.usernames, text2, Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Count"].Value), Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value) / Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Count"].Value), 0, doctorcomboBox.Text);
								}
								for (int j = 0; j < dataGridView3.Rows.Count; j++)
								{
									string text7 = (Convert.ToDecimal(dataGridView3.Rows[j].Cells[2].Value.ToString()) * Convert.ToDecimal(dataGridView3.Rows[j].Cells[1].Value.ToString())).ToString();
									((DataTable)(object)ds.SahbItemEsal).Rows.Add(dataGridView3.Rows[j].Cells[0].Value.ToString(), dataGridView3.Rows[j].Cells[2].Value.ToString(), dataGridView3.Rows[j].Cells[1].Value.ToString(), text7);
								}
								sqlConnection1.ConnectionString = codes.ConnectionStr;
								sqlDataAdapter1.Fill(ds);
								sqlConnection2.ConnectionString = Codes.ConnectionStr;
								sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
								sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
								sqlDataAdapter2.Fill(ds);
								DataTable dataTable10 = Codes.Search2("select EsalPrinter from Properties");
								switch (dataTable10.Rows[0][0].ToString())
								{
								case "A5":
								{
									ReportDocument reportDocument = new ReportDocument();
									reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptA5.rpt");
									try
									{
										reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
										textObject.Text = text6;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									reportDocument.SetDataSource(ds);
									StatmentRptFrm statmentRptFrm2 = new StatmentRptFrm(reportDocument);
									statmentRptFrm2.ShowDialog();
									break;
								}
								case "Reset":
								{
									ReportDocument reportDocument = new ReportDocument();
									reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptReset.rpt");
									try
									{
										reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
										textObject.Text = text6;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									reportDocument.SetDataSource(ds);
									StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
									statmentRptFrm.ShowDialog();
									break;
								}
								case "1/2 A4":
								{
									((DataTable)(object)ds.Statment).Rows.Clear();
									double num8 = 0.0;
									for (int i = 1; i < dataGridView1.Rows.Count; i++)
									{
										num8 += Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString());
									}
									for (int i = 1; i < dataGridView1.Rows.Count; i++)
									{
										((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, dataGridView1.Rows[i - 1].Cells["ServiceDate"].Value.ToString(), dataGridView1.Rows[i - 1].Cells["Service"].Value.ToString(), num8, dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString(), tottextBox.Text, dataGridView1.Rows[i - 1].Cells["Teethn"].Value.ToString(), text3, Main.usernames, text2, Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Count"].Value), Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Price"].Value) / Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Count"].Value), Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Price"].Value.ToString()) * Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["driba"].Value.ToString()) / 100.0, doctorcomboBox.Text);
									}
									sqlConnection2.ConnectionString = Codes.ConnectionStr;
									sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
									sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
									sqlDataAdapter2.Fill(ds);
									ReportDocument reportDocument = new ReportDocument();
									reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt_HalfA4.rpt");
									try
									{
										reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
										textObject.Text = text6;
									}
									catch
									{
									}
									reportDocument.SetDataSource(ds);
									try
									{
										reportDocument.SetParameterValue("DoctorName", doctorcomboBox.Text);
									}
									catch
									{
									}
									FrmStatmentRpt_HalfA4 frmStatmentRpt_HalfA = new FrmStatmentRpt_HalfA4(reportDocument);
									frmStatmentRpt_HalfA.ShowDialog();
									break;
								}
								default:
								{
									ReportDocument reportDocument = new ReportDocument();
									reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt.rpt");
									try
									{
										reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
										textObject.Text = text6;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									reportDocument.SetDataSource(ds);
									reportDocument.SetParameterValue("Assistant", AssistantcomboBox.Text);
									StatmentRptFrm statmentRptFrm2 = new StatmentRptFrm(reportDocument);
									statmentRptFrm2.ShowDialog();
									break;
								}
								}
							}
						}
						else if (!checkBox3.Checked && Convert.ToBoolean(tableText3.Rows[0][1]))
						{
							ds.Clear();
							string text3 = "";
							DataTable dataTable2 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
							try
							{
								text3 = dataTable2.Rows[0][0].ToString();
							}
							catch
							{
							}
							if (!flag2)
							{
								for (int i = 1; i < dataGridView1.Rows.Count; i++)
								{
									((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, dataGridView1.Rows[i - 1].Cells[2].Value.ToString(), dataGridView1.Rows[i - 1].Cells[0].Value.ToString(), tottextBox.Text, dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value.ToString(), 0, dataGridView1.Rows[i - 1].Cells[3].Value.ToString(), text3, Main.usernames, "0", Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Count"].Value), Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Aftrdriba"].Value) / Convert.ToDouble(dataGridView1.Rows[i - 1].Cells["Count"].Value), 0, doctorcomboBox.Text);
								}
								for (int j = 0; j < dataGridView3.Rows.Count; j++)
								{
									string text7 = (Convert.ToDecimal(dataGridView3.Rows[j].Cells[2].Value.ToString()) * Convert.ToDecimal(dataGridView3.Rows[j].Cells[1].Value.ToString())).ToString();
									((DataTable)(object)ds.SahbItemEsal).Rows.Add(dataGridView3.Rows[j].Cells[0].Value.ToString(), dataGridView3.Rows[j].Cells[2].Value.ToString(), dataGridView3.Rows[j].Cells[1].Value.ToString(), text7);
								}
								if ((numericUpDown1.Value != 0m || numericUpDown1.Value != 0m || numericUpDown2.Value != 0m || numericUpDown3.Value != 0m || numericUpDown4.Value != 0m || numericUpDown5.Value != 0m || numericUpDown6.Value != 0m || numericUpDown7.Value != 0m || (numericUpDown8.Value != 0m && numericUpDown9.Value != 0m) || numericUpDown10.Value != 0m || numericUpDown11.Value != 0m || numericUpDown12.Value != 0m || numericUpDown13.Value != 0m || numericUpDown14.Value != 0m) && Convert.ToBoolean(tableText3.Rows[0][1]))
								{
									((DataTable)(object)ds.Glasses).Rows.Add(numericUpDown1.Value, numericUpDown2.Value, numericUpDown3.Value, numericUpDown4.Value, numericUpDown5.Value, numericUpDown6.Value, numericUpDown7.Value, numericUpDown8.Value, numericUpDown9.Value, numericUpDown10.Value, numericUpDown11.Value, numericUpDown12.Value, numericUpDown13.Value, numericUpDown14.Value);
								}
								sqlConnection1.ConnectionString = codes.ConnectionStr;
								sqlDataAdapter1.Fill(ds);
								sqlConnection2.ConnectionString = Codes.ConnectionStr;
								sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
								sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
								sqlDataAdapter2.Fill(ds);
								DataTable dataTable10 = Codes.Search2("select EsalPrinter from Properties");
								string text8 = dataTable10.Rows[0][0].ToString();
								if (text8 == "A5")
								{
									ReportDocument reportDocument = new ReportDocument();
									reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptA5.rpt");
									try
									{
										reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
										textObject.Text = text6;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									reportDocument.SetDataSource(ds);
									StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
									statmentRptFrm.ShowDialog();
								}
								else if (text8 == "Reset")
								{
									ReportDocument reportDocument = new ReportDocument();
									reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptReset.rpt");
									try
									{
										reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
										textObject.Text = text6;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									reportDocument.SetDataSource(ds);
									StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
									statmentRptFrm.ShowDialog();
								}
								else
								{
									ReportDocument reportDocument = new ReportDocument();
									reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1.rpt");
									try
									{
										reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Notes"] as TextObject;
										textObject.Text = text6;
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									try
									{
										TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
										textObject.Text = "0";
									}
									catch
									{
									}
									reportDocument.SetDataSource(ds);
									reportDocument.SetParameterValue("Assistant", AssistantcomboBox.Text);
									StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
									statmentRptFrm.ShowDialog();
								}
							}
						}
						dataGridView1.Rows.Clear();
						done = true;
						Close();
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("No data to save", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					MessageBox.Show("لا يوجد بيانات للحفظ", "تنبيه");
				}
				GetBean();
				end_IL_0001:;
			}
			catch
			{
			}
		}

		private void PationtAccountReBack_FormClosing(object sender, FormClosingEventArgs e)
		{
			try
			{
				if (!done)
				{
					if (MessageBox.Show("This Detection Is Done", "Notes", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
					{
						string[] fields = new string[1] { "ID" };
						b = dc.Update("updateAppointPackDone", fields, appointid);
						if (b)
						{
							if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							else
							{
								MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
						}
						else if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						else
						{
							MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
					}
					else
					{
						e.Cancel = false;
					}
				}
				else
				{
					e.Cancel = false;
				}
			}
			catch
			{
			}
		}

		private void PationtAccountReBack_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			OldServiceProvidedFrm oldServiceProvidedFrm = new OldServiceProvidedFrm(patientid);
			oldServiceProvidedFrm.ShowDialog();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			FrmImage frmImage = new FrmImage(patientid);
			frmImage.ShowDialog();
			if (UsersClass.AutoEsal)
			{
				EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
				EsalNoTxt.Enabled = false;
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			PrescriptionFrm prescriptionFrm = new PrescriptionFrm(patientid);
			prescriptionFrm.ShowDialog();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			PatientPayAccount patientPayAccount = new PatientPayAccount(patientid);
			patientPayAccount.ShowDialog();
			if (UsersClass.AutoEsal)
			{
				EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
				EsalNoTxt.Enabled = false;
			}
		}

		private void button6_Click(object sender, EventArgs e)
		{
			CommentFrm commentFrm = new CommentFrm(patientid);
			commentFrm.ShowDialog();
		}

		public void VistaColor(VistaButton vis)
		{
			foreach (Control control in panel1.Controls)
			{
				if (control is VistaButton && control.BackColor == Color.Red)
				{
					U1.ButtonColor = Color.LightGray;
					U2.ButtonColor = Color.LightGray;
					U3.ButtonColor = Color.LightGray;
					U4.ButtonColor = Color.LightGray;
					U5.ButtonColor = Color.LightGray;
					U6.ButtonColor = Color.LightGray;
					U7.ButtonColor = Color.LightGray;
					U8.ButtonColor = Color.LightGray;
					U9.ButtonColor = Color.LightGray;
					U10.ButtonColor = Color.LightGray;
					U11.ButtonColor = Color.LightGray;
					U12.ButtonColor = Color.LightGray;
					U13.ButtonColor = Color.LightGray;
					U14.ButtonColor = Color.LightGray;
					U15.ButtonColor = Color.LightGray;
					U16.ButtonColor = Color.LightGray;
					U32.ButtonColor = Color.LightGray;
					U31.ButtonColor = Color.LightGray;
					U30.ButtonColor = Color.LightGray;
					U29.ButtonColor = Color.LightGray;
					U28.ButtonColor = Color.LightGray;
					U27.ButtonColor = Color.LightGray;
					U26.ButtonColor = Color.LightGray;
					U25.ButtonColor = Color.LightGray;
					U17.ButtonColor = Color.LightGray;
					U18.ButtonColor = Color.LightGray;
					U19.ButtonColor = Color.LightGray;
					U20.ButtonColor = Color.LightGray;
					U21.ButtonColor = Color.LightGray;
					U22.ButtonColor = Color.LightGray;
					U23.ButtonColor = Color.LightGray;
					U24.ButtonColor = Color.LightGray;
					control.BackColor = Color.Maroon;
				}
			}
			if (vis.ButtonColor == Color.Red)
			{
				vis.ButtonColor = Color.LightGray;
				vis.BackColor = Color.Maroon;
			}
			else
			{
				vis.ButtonColor = Color.Red;
				vis.BackColor = Color.Red;
			}
		}

		private void U32_Click(object sender, EventArgs e)
		{
			VistaColor(U24);
		}

		private void U17_Click(object sender, EventArgs e)
		{
			VistaColor(U32);
		}

		private void U20_Click(object sender, EventArgs e)
		{
			VistaColor(U29);
		}

		private void U23_Click(object sender, EventArgs e)
		{
			VistaColor(U26);
		}

		private void U19_Click(object sender, EventArgs e)
		{
			VistaColor(U30);
		}

		private void U21_Click(object sender, EventArgs e)
		{
			VistaColor(U28);
		}

		private void U18_Click(object sender, EventArgs e)
		{
			VistaColor(U31);
		}

		private void U22_Click(object sender, EventArgs e)
		{
			VistaColor(U27);
		}

		private void U24_Click(object sender, EventArgs e)
		{
			VistaColor(U25);
		}

		private void U30_Click(object sender, EventArgs e)
		{
			VistaColor(U22);
		}

		private void U31_Click(object sender, EventArgs e)
		{
			VistaColor(U23);
		}

		private void U26_Click(object sender, EventArgs e)
		{
			VistaColor(U18);
		}

		private void U25_Click(object sender, EventArgs e)
		{
			VistaColor(U17);
		}

		private void U27_Click(object sender, EventArgs e)
		{
			VistaColor(U19);
		}

		private void U29_Click(object sender, EventArgs e)
		{
			VistaColor(U21);
		}

		private void U28_Click(object sender, EventArgs e)
		{
			VistaColor(U20);
		}

		private void U8_Click(object sender, EventArgs e)
		{
			VistaColor(U8);
		}

		private void U2_Click(object sender, EventArgs e)
		{
			VistaColor(U2);
		}

		private void U3_Click(object sender, EventArgs e)
		{
			VistaColor(U3);
		}

		private void U4_Click(object sender, EventArgs e)
		{
			VistaColor(U4);
		}

		private void U5_Click(object sender, EventArgs e)
		{
			VistaColor(U5);
		}

		private void U6_Click(object sender, EventArgs e)
		{
			VistaColor(U6);
		}

		private void U7_Click(object sender, EventArgs e)
		{
			VistaColor(U7);
		}

		private void U1_Click(object sender, EventArgs e)
		{
			VistaColor(U1);
		}

		private void U16_Click(object sender, EventArgs e)
		{
			VistaColor(U16);
		}

		private void U10_Click(object sender, EventArgs e)
		{
			VistaColor(U10);
		}

		private void U11_Click(object sender, EventArgs e)
		{
			VistaColor(U11);
		}

		private void U12_Click(object sender, EventArgs e)
		{
			VistaColor(U12);
		}

		private void U13_Click(object sender, EventArgs e)
		{
			VistaColor(U13);
		}

		private void U14_Click(object sender, EventArgs e)
		{
			VistaColor(U14);
		}

		private void U15_Click(object sender, EventArgs e)
		{
			VistaColor(U15);
		}

		private void U9_Click(object sender, EventArgs e)
		{
			VistaColor(U9);
		}

		private void button2_Click(object sender, EventArgs e)
		{
			FrmFilePatient frmFilePatient = new FrmFilePatient(PatientComboBox.Text);
			frmFilePatient.ShowDialog();
		}

		private void PatientComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("select isnull(sum(Daen),0) from PatientBeforePay where PatientID=" + PatientComboBox.SelectedValue);
				Rased.Text = Math.Round(Convert.ToDecimal(dataTable.Rows[0][0]), 2).ToString();
			}
			catch
			{
			}
		}

		private void PatientComboBox_SelectedValueChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2(string.Concat("select top 1 * from detect where ClientiD= '", PatientComboBox.SelectedValue, "' order by ID desc"));
				if (!(numericUpDown1.Value != 0m) && !(numericUpDown1.Value != 0m) && !(numericUpDown2.Value != 0m) && !(numericUpDown3.Value != 0m) && !(numericUpDown4.Value != 0m) && !(numericUpDown5.Value != 0m) && !(numericUpDown6.Value != 0m) && !(numericUpDown7.Value != 0m) && (!(numericUpDown8.Value != 0m) || !(numericUpDown9.Value != 0m)) && !(numericUpDown10.Value != 0m) && !(numericUpDown11.Value != 0m) && !(numericUpDown12.Value != 0m) && !(numericUpDown13.Value != 0m) && !(numericUpDown14.Value != 0m))
				{
					if (dataTable.Rows.Count > 0)
					{
						numericUpDown1.Value = Convert.ToDecimal(dataTable.Rows[0][2].ToString());
						numericUpDown2.Value = Convert.ToDecimal(dataTable.Rows[0][3].ToString());
						numericUpDown3.Value = Convert.ToDecimal(dataTable.Rows[0][4].ToString());
						numericUpDown4.Value = Convert.ToDecimal(dataTable.Rows[0][5].ToString());
						numericUpDown5.Value = Convert.ToDecimal(dataTable.Rows[0][6].ToString());
						numericUpDown6.Value = Convert.ToDecimal(dataTable.Rows[0][7].ToString());
						numericUpDown7.Value = Convert.ToDecimal(dataTable.Rows[0][8].ToString());
						numericUpDown8.Value = Convert.ToDecimal(dataTable.Rows[0][9].ToString());
						numericUpDown9.Value = Convert.ToDecimal(dataTable.Rows[0][10].ToString());
						numericUpDown10.Value = Convert.ToDecimal(dataTable.Rows[0][11].ToString());
						numericUpDown11.Value = Convert.ToDecimal(dataTable.Rows[0][12].ToString());
						numericUpDown12.Value = Convert.ToDecimal(dataTable.Rows[0][13].ToString());
						numericUpDown13.Value = Convert.ToDecimal(dataTable.Rows[0][15].ToString());
						numericUpDown14.Value = Convert.ToDecimal(dataTable.Rows[0][16].ToString());
					}
					else
					{
						numericUpDown1.Value = 0m;
						numericUpDown2.Value = 0m;
						numericUpDown3.Value = 0m;
						numericUpDown4.Value = 0m;
						numericUpDown5.Value = 0m;
						numericUpDown6.Value = 0m;
						numericUpDown7.Value = 0m;
						numericUpDown8.Value = 0m;
						numericUpDown9.Value = 0m;
						numericUpDown10.Value = 0m;
						numericUpDown11.Value = 0m;
						numericUpDown12.Value = 0m;
						numericUpDown13.Value = 0m;
						numericUpDown14.Value = 0m;
					}
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = codes.Search2(string.Concat("select * from HeaderCard where PatientID = '", PatientComboBox.SelectedValue, "'"));
				if (dataTable2.Rows.Count > 0)
				{
					txtParity.Text = dataTable2.Rows[0][2].ToString();
					txtIMP.Text = dataTable2.Rows[0][3].ToString();
					txtKind.Text = dataTable2.Rows[0][4].ToString();
					txtCS.Text = dataTable2.Rows[0][5].ToString();
					txtEDD.Text = dataTable2.Rows[0][6].ToString();
					txtHistory.Text = dataTable2.Rows[0][7].ToString();
				}
				else
				{
					txtParity.Text = "";
					txtIMP.Text = "";
					txtKind.Text = "";
					txtCS.Text = "";
					txtEDD.Text = "";
					txtHistory.Text = "";
				}
			}
			catch
			{
			}
			try
			{
				if (groupBox27.Visible)
				{
					DataTable dataTable3 = codes.Search2(string.Concat("select * from HeartCard where PatientID = '", PatientComboBox.SelectedValue, "' order by ID desc"));
					if (dataTable3.Rows.Count > 0)
					{
						txtBox13.Text = dataTable3.Rows[0]["PresentHistory"].ToString();
					}
					else
					{
						txtBox13.Text = "";
					}
				}
			}
			catch
			{
			}
		}

		private void button7_Click(object sender, EventArgs e)
		{
			FrmRptFollowUpKids frmRptFollowUpKids = new FrmRptFollowUpKids(patientid);
			frmRptFollowUpKids.Show();
		}

		private void button16_Click(object sender, EventArgs e)
		{
			FrmSahbAmount frmSahbAmount = new FrmSahbAmount(Convert.ToInt32(PatientComboBox.SelectedValue), Convert.ToInt32(doctorcomboBox.SelectedValue));
			frmSahbAmount.ShowDialog();
		}

		private void checkBox3_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox3.Checked)
			{
				PayBefore.Visible = true;
				PayNaqdy.Visible = true;
				PaidPanel.Visible = true;
			}
			else
			{
				PaidPanel.Visible = false;
				PayBefore.Visible = false;
				PayNaqdy.Visible = false;
			}
		}

		private void itemIdComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				if (itemIdComboBox.SelectedIndex == -1)
				{
					txtStore.Text = "0";
					floatText1.Text = "0";
					return;
				}
				DataTable dataTable = codes.Search2(string.Concat("SELECT     dbo.Store.Qnt, dbo.Items.SalePrice, dbo.Store.BuyPrice\r\nFROM         dbo.Items INNER JOIN\r\n                      dbo.Store ON dbo.Items.Id = dbo.Store.ItemId where dbo.Store.ItemId='", itemIdComboBox.SelectedValue, "'"));
				txtStore.Text = dataTable.Rows[0][0].ToString();
				floatText1.Text = dataTable.Rows[0][1].ToString();
				BuyPrice = dataTable.Rows[0][2].ToString();
			}
			catch
			{
			}
		}

		private void button17_Click(object sender, EventArgs e)
		{
			if (itemIdComboBox.SelectedIndex == -1)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Item Name");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم الصنف");
				}
				return;
			}
			if (txtQty.Text == "0")
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Quantity");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل الكمية");
				}
				return;
			}
			if (Convert.ToDecimal(txtQty.Text) > Convert.ToDecimal(txtStore.Text))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("The quantity is larger than the stock");
				}
				else
				{
					MessageBox.Show("الكمية اكبر من المخزون");
				}
				return;
			}
			if (Convert.ToDecimal(floatText1.Text) < Convert.ToDecimal(BuyPrice))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("The sale price is less than the purchase price");
				}
				else
				{
					MessageBox.Show("سعر البيع اقل من سعر الشراء");
				}
			}
			bool flag = false;
			if (dataGridView3.Rows.Count == 0)
			{
				dataGridView3.Rows.Add(itemIdComboBox.Text, floatText1.Text, txtQty.Text, itemIdComboBox.SelectedValue.ToString(), (Convert.ToDouble(floatText1.Text) * Convert.ToDouble(txtQty.Text)).ToString());
				tottextBox.Text = (Convert.ToDouble(tottextBox.Text) + Convert.ToDouble(floatText1.Text) * Convert.ToDouble(txtQty.Text)).ToString();
				return;
			}
			for (int i = 0; i < dataGridView3.Rows.Count; i++)
			{
				if (itemIdComboBox.Text == dataGridView3.Rows[i].Cells[0].Value.ToString())
				{
					flag = true;
					break;
				}
			}
			if (flag)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("You Have Save This Item Before");
				}
				else
				{
					MessageBox.Show("تم ادخال اسم الصنف قبل ");
				}
				return;
			}
			dataGridView3.Rows.Add(itemIdComboBox.Text, floatText1.Text, txtQty.Text, itemIdComboBox.SelectedValue.ToString(), (Convert.ToDouble(floatText1.Text) * Convert.ToDouble(txtQty.Text)).ToString());
			tottextBox.Text = (Convert.ToDouble(tottextBox.Text) + Convert.ToDouble(floatText1.Text) * Convert.ToDouble(txtQty.Text)).ToString();
		}

		private void dataGridView1_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
		{
			try
			{
				tottextBox.Text = (Convert.ToDouble(tottextBox.Text) - Convert.ToDouble(dataGridView1.CurrentRow.Cells["Aftrdriba"].Value)).ToString();
			}
			catch
			{
			}
		}

		private void dataGridView3_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
		{
			tottextBox.Text = (Convert.ToDouble(tottextBox.Text) - Convert.ToDouble(dataGridView3.CurrentRow.Cells[1].Value) * Convert.ToDouble(dataGridView3.CurrentRow.Cells[2].Value)).ToString();
		}

		private void btnPatient_Click(object sender, EventArgs e)
		{
			PationtInfo pationtInfo = new PationtInfo(Convert.ToInt32(PatientComboBox.SelectedValue));
			pationtInfo.ShowDialog();
		}

		private void button18_Click(object sender, EventArgs e)
		{
			FrmAnalyzes frmAnalyzes = new FrmAnalyzes(patientid);
			frmAnalyzes.ShowDialog();
			if (UsersClass.AutoEsal)
			{
				EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
				EsalNoTxt.Enabled = false;
			}
		}

		private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				commentTextBox.DataSource = null;
				string text = codes.Search2("select ServiceName from Properties").Rows[0][0].ToString();
				string text2 = codes.Search2("select ServiceDetect from Properties").Rows[0][0].ToString();
				DataTable dataTable = codes.Search2(string.Concat("select Service from CompanyService where CompanyID = '", comboCategory.SelectedValue, "' and Service != '", text, "' and Service != '", text2, "'"));
				commentTextBox.DataSource = dataTable;
				commentTextBox.DisplayMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void txtIMP_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				txtEDD.Value = txtIMP.Value.AddMonths(9).AddDays(7.0);
			}
			catch
			{
			}
		}

		private void U1_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=1 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			if (dataTable.Rows.Count > 0)
			{
				try
				{
					toolTip1.SetToolTip(U1, text);
				}
				catch
				{
				}
			}
		}

		private void U2_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=2 and PatientId = '", PatientComboBox.SelectedValue, "' order by Date Desc"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U2, text);
			}
			catch
			{
			}
		}

		private void U3_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=3 and PatientId = '", PatientComboBox.SelectedValue, "' order by Date Desc"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U3, text);
			}
			catch
			{
			}
		}

		private void U4_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=4 and PatientId = '", PatientComboBox.SelectedValue, "' order by Date Desc"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U4, text);
			}
			catch
			{
			}
		}

		private void U5_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=5 and PatientId = '", PatientComboBox.SelectedValue, "' order by Date Desc"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U5, text);
			}
			catch
			{
			}
		}

		private void U6_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=6 and PatientId = '", PatientComboBox.SelectedValue, "' order by Date Desc"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U6, text);
			}
			catch
			{
			}
		}

		private void U7_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=7 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U7, text);
			}
			catch
			{
			}
		}

		private void U8_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=8 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U8, text);
			}
			catch
			{
			}
		}

		private void U9_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=9 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U9, text);
			}
			catch
			{
			}
		}

		private void U10_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=10 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U10, text);
			}
			catch
			{
			}
		}

		private void U11_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=11 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U11, text);
			}
			catch
			{
			}
		}

		private void U12_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=12 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U12, text);
			}
			catch
			{
			}
		}

		private void U13_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=13 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U13, text);
			}
			catch
			{
			}
		}

		private void U14_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=14 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U14, text);
			}
			catch
			{
			}
		}

		private void U15_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=15 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U15, text);
			}
			catch
			{
			}
		}

		private void U16_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=16 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U16, text);
			}
			catch
			{
			}
		}

		private void U32_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=32 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U32, text);
			}
			catch
			{
			}
		}

		private void U31_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=31 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U31, text);
			}
			catch
			{
			}
		}

		private void U30_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=30 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U30, text);
			}
			catch
			{
			}
		}

		private void U29_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=29 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U29, text);
			}
			catch
			{
			}
		}

		private void U28_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=28 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U28, text);
			}
			catch
			{
			}
		}

		private void U27_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=27 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U27, text);
			}
			catch
			{
			}
		}

		private void U26_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=26 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U26, text);
			}
			catch
			{
			}
		}

		private void U25_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=25 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U25, text);
			}
			catch
			{
			}
		}

		private void U17_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=17 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U17, text);
			}
			catch
			{
			}
		}

		private void U18_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=18 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U18, text);
			}
			catch
			{
			}
		}

		private void U19_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=19 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U19, text);
			}
			catch
			{
			}
		}

		private void U20_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=20 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U20, text);
			}
			catch
			{
			}
		}

		private void U21_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=21 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U21, text);
			}
			catch
			{
			}
		}

		private void U22_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=22 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U22, text);
			}
			catch
			{
			}
		}

		private void U23_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=23 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U23, text);
			}
			catch
			{
			}
		}

		private void U24_MouseHover(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2(string.Concat("select Bean,Date from PatientAccount where TeathId=24 and PatientId = '", PatientComboBox.SelectedValue, "'"));
			string text = "";
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				text = ((i <= 0) ? (dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")) : (text + " , " + dataTable.Rows[i][0].ToString() + " / " + Convert.ToDateTime(dataTable.Rows[i][1].ToString()).ToString("yyyy/MM/dd")));
			}
			toolTip1.RemoveAll();
			try
			{
				toolTip1.SetToolTip(U24, text);
			}
			catch
			{
			}
		}

		private void button22_Click(object sender, EventArgs e)
		{
			try
			{
				FrmSurgeryDate frmSurgeryDate = new FrmSurgeryDate(PatientComboBox.SelectedValue.ToString(), doctorcomboBox.SelectedValue.ToString());
				frmSurgeryDate.Show();
			}
			catch
			{
			}
		}

		private void EsalNoTxt_KeyPress(object sender, KeyPressEventArgs e)
		{
			if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
			{
				if (e.KeyChar == '.' && EsalNoTxt.Text.Contains("."))
				{
					e.Handled = true;
				}
			}
			else
			{
				e.Handled = true;
				MessageBox.Show("من فضلك أدخل رقم الإيصال بالارقام");
			}
		}

		private void PricetextBox_TextChanged(object sender, EventArgs e)
		{
			if (PricetextBox.Text == "")
			{
				PatientComboBox_SelectedValueChanged(sender, e);
			}
			else
			{
				AfterDariba.Text = Convert.ToString(Convert.ToDecimal(PricetextBox.Text) + Convert.ToDecimal(PricetextBox.Text) * Convert.ToDecimal(Dariba.Text) / 100m);
			}
		}

		private void radioButton5_CheckedChanged(object sender, EventArgs e)
		{
			if (radioButton5.Checked)
			{
				groupBox10.Visible = true;
				groupBox29.Visible = false;
				dataGridView1.Columns[7].Visible = true;
				dataGridView1.Columns[8].Visible = true;
				dataGridView1.Columns[9].Visible = false;
				dataGridView1.Columns[10].Visible = false;
				dataGridView1.Columns[6].Visible = false;
			}
			else
			{
				groupBox10.Visible = false;
				groupBox29.Visible = true;
				dataGridView1.Columns[7].Visible = false;
				dataGridView1.Columns[8].Visible = false;
				dataGridView1.Columns[9].Visible = true;
				dataGridView1.Columns[10].Visible = true;
				dataGridView1.Columns[6].Visible = true;
			}
		}

		private void OfferName_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2(string.Concat("select Price from Offers where OfferID='", OfferName.SelectedValue, "'"));
				OfferPrice.Text = dataTable.Rows[0][0].ToString();
			}
			catch
			{
			}
		}

		private void button23_Click(object sender, EventArgs e)
		{
			try
			{
				_ = 0m;
				DataTable tableText = dc.GetTableText("select * from Empdata where Name='" + doctorcomboBox.Text + "'");
				if (tableText.Rows.Count > 0)
				{
					DataTable tableText2 = dc.GetTableText("select * from PatientData where PName='" + PatientComboBox.Text + "'");
					if (tableText2.Rows.Count > 0)
					{
						if (OfferName.Text != "")
						{
							bool flag = false;
							DataTable dataTable = Codes.Search2(string.Concat("select ServiceID,Servicename ,serviceNum ,ServicePrice from Offers where OfferID='", OfferName.SelectedValue, "'"));
							foreach (Control control in panel1.Controls)
							{
								if (control is VistaButton && control.BackColor == Color.Red)
								{
									string text = control.Name.ToString();
									int num = Convert.ToInt32(text.Remove(0, 1));
									DataTable dataTable2 = codes.Search2("select Name from Teath where Id='" + num + "'");
									for (int i = 0; i < dataTable.Rows.Count; i++)
									{
										DataTable dataTable3 = Codes.Search2(string.Concat("select isnull(sum(OfferNumUsed),0) from PatientAccount where OfferID='", OfferName.SelectedValue, "' and Bean='", dataTable.Rows[i]["Servicename"].ToString(), "' and PatientId='", PatientComboBox.SelectedValue, "'"));
										dataGridView1.Rows.Add(dataTable.Rows[i][1].ToString(), Convert.ToDouble(dataTable.Rows[i][3].ToString()), dateTimePicker1.Value.ToString("yyyy/MM/dd"), dataTable2.Rows[0][0].ToString(), num, 0, dataTable.Rows[i][2].ToString(), 0, dataTable.Rows[i][3].ToString(), dataTable3.Rows[0][0].ToString(), 0, (OfferName.SelectedValue == null) ? " " : OfferName.SelectedValue);
									}
									flag = true;
									total = Convert.ToDouble(tottextBox.Text);
									total += Convert.ToDouble(OfferPrice.Text);
									tottextBox.Text = total.ToString();
									commentTextBox.Text = "";
									PricetextBox.Text = "0";
									floatText5.Text = "1";
									AssistantcomboBox.Enabled = false;
								}
							}
							if (!flag)
							{
								for (int i = 0; i < dataTable.Rows.Count; i++)
								{
									DataTable dataTable3 = Codes.Search2(string.Concat("select isnull(sum(OfferNumUsed),0) from PatientAccount where OfferID='", OfferName.SelectedValue, "' and Bean='", dataTable.Rows[i]["Servicename"].ToString(), "' and PatientId='", PatientComboBox.SelectedValue, "'"));
									dataGridView1.Rows.Add(dataTable.Rows[i][1].ToString(), Convert.ToDouble(dataTable.Rows[i][3].ToString()), dateTimePicker1.Value.ToString("yyyy/MM/dd"), "General", "33", 0, dataTable.Rows[i][2].ToString(), 0, dataTable.Rows[i][3].ToString(), dataTable3.Rows[0][0].ToString(), 0, (OfferName.SelectedValue == null) ? " " : OfferName.SelectedValue);
								}
								flag = true;
								total = Convert.ToDouble(tottextBox.Text);
								total += Convert.ToDouble(OfferPrice.Text);
								tottextBox.Text = total.ToString();
								commentTextBox.Text = "";
								PricetextBox.Text = "0";
								floatText5.Text = "1";
								AssistantcomboBox.Enabled = false;
							}
						}
						else if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please enter Offer Name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("من فضلك ادخل العرض", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Valid Patient Name");
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم مريض صحيح");
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Valid Doctor Name");
				}
				else
				{
					MessageBox.Show("من فضلك اختر اسم طبيب صحيح");
				}
			}
			catch
			{
			}
		}

		private void PayNaqdy_CheckedChanged(object sender, EventArgs e)
		{
			if (PayNaqdy.Checked)
			{
				DataTable dataTable = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				if (dataTable.Rows.Count > 0)
				{
					PaidPanel.Visible = true;
					return;
				}
				PaidPanel.Visible = false;
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please add Treasury validity");
				}
				else
				{
					MessageBox.Show("من فضلك اضف صلاحية للخزينة");
				}
			}
			else
			{
				PaidPanel.Visible = false;
			}
		}

		private void PayBefore_CheckedChanged(object sender, EventArgs e)
		{
			if (PayBefore.Checked && (Rased.Text == "0.00" || Rased.Text == "0"))
			{
				MessageBox.Show("لا يمكن الدفع من رصيد سابق لان الرصيد السابق للمريض بصفر");
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.PationtAccountReBack));
			groupBox2 = new System.Windows.Forms.GroupBox();
			this.label7 = new System.Windows.Forms.Label();
			ADDBtn = new System.Windows.Forms.Button();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			Service = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ServiceDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Teethn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Tid = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Cost = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Count = new System.Windows.Forms.DataGridViewTextBoxColumn();
			driba = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Aftrdriba = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			appdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			groupBox5 = new System.Windows.Forms.GroupBox();
			saveBtn = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			tottextBox = new System.Windows.Forms.TextBox();
			groupBox1 = new System.Windows.Forms.GroupBox();
			PatientComboBox = new System.Windows.Forms.ComboBox();
			PricetextBox = new System.Windows.Forms.TextBox();
			groupBox4 = new System.Windows.Forms.GroupBox();
			Rased = new System.Windows.Forms.TextBox();
			groupBox29 = new System.Windows.Forms.GroupBox();
			OfferName = new System.Windows.Forms.ComboBox();
			OfferPrice = new System.Windows.Forms.TextBox();
			button23 = new System.Windows.Forms.Button();
			dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
			radioButton5 = new System.Windows.Forms.RadioButton();
			radioButton6 = new System.Windows.Forms.RadioButton();
			btnPatient = new System.Windows.Forms.Button();
			groupBox10 = new System.Windows.Forms.GroupBox();
			label105 = new System.Windows.Forms.Label();
			textBoxDiscount = new System.Windows.Forms.TextBox();
			this.label46 = new System.Windows.Forms.Label();
			this.label48 = new System.Windows.Forms.Label();
			Dariba = new System.Windows.Forms.TextBox();
			floatText5 = new FloatTextBox.FloatText();
			this.label47 = new System.Windows.Forms.Label();
			AfterDariba = new System.Windows.Forms.TextBox();
			comboCategory = new System.Windows.Forms.ComboBox();
			commentTextBox = new System.Windows.Forms.ComboBox();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			AssistantcomboBox = new System.Windows.Forms.ComboBox();
			button2 = new System.Windows.Forms.Button();
			button6 = new System.Windows.Forms.Button();
			button5 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			button4 = new System.Windows.Forms.Button();
			panel1 = new System.Windows.Forms.Panel();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			groupBox6 = new System.Windows.Forms.GroupBox();
			groupBox7 = new System.Windows.Forms.GroupBox();
			vistaButton24 = new VistaButtonTest.VistaButton();
			vistaButton17 = new VistaButtonTest.VistaButton();
			vistaButton23 = new VistaButtonTest.VistaButton();
			vistaButton18 = new VistaButtonTest.VistaButton();
			vistaButton22 = new VistaButtonTest.VistaButton();
			vistaButton19 = new VistaButtonTest.VistaButton();
			vistaButton21 = new VistaButtonTest.VistaButton();
			vistaButton20 = new VistaButtonTest.VistaButton();
			groupBox3 = new System.Windows.Forms.GroupBox();
			groupBox8 = new System.Windows.Forms.GroupBox();
			vistaButton9 = new VistaButtonTest.VistaButton();
			vistaButton10 = new VistaButtonTest.VistaButton();
			vistaButton11 = new VistaButtonTest.VistaButton();
			vistaButton12 = new VistaButtonTest.VistaButton();
			vistaButton13 = new VistaButtonTest.VistaButton();
			vistaButton14 = new VistaButtonTest.VistaButton();
			vistaButton15 = new VistaButtonTest.VistaButton();
			vistaButton16 = new VistaButtonTest.VistaButton();
			U26 = new VistaButtonTest.VistaButton();
			U29 = new VistaButtonTest.VistaButton();
			U32 = new VistaButtonTest.VistaButton();
			U30 = new VistaButtonTest.VistaButton();
			U28 = new VistaButtonTest.VistaButton();
			U31 = new VistaButtonTest.VistaButton();
			U24 = new VistaButtonTest.VistaButton();
			U22 = new VistaButtonTest.VistaButton();
			U27 = new VistaButtonTest.VistaButton();
			U23 = new VistaButtonTest.VistaButton();
			U9 = new VistaButtonTest.VistaButton();
			U16 = new VistaButtonTest.VistaButton();
			U11 = new VistaButtonTest.VistaButton();
			U10 = new VistaButtonTest.VistaButton();
			U12 = new VistaButtonTest.VistaButton();
			U13 = new VistaButtonTest.VistaButton();
			U14 = new VistaButtonTest.VistaButton();
			U15 = new VistaButtonTest.VistaButton();
			U1 = new VistaButtonTest.VistaButton();
			U8 = new VistaButtonTest.VistaButton();
			U25 = new VistaButtonTest.VistaButton();
			U3 = new VistaButtonTest.VistaButton();
			U2 = new VistaButtonTest.VistaButton();
			U18 = new VistaButtonTest.VistaButton();
			U17 = new VistaButtonTest.VistaButton();
			U4 = new VistaButtonTest.VistaButton();
			U5 = new VistaButtonTest.VistaButton();
			U6 = new VistaButtonTest.VistaButton();
			U7 = new VistaButtonTest.VistaButton();
			U19 = new VistaButtonTest.VistaButton();
			U21 = new VistaButtonTest.VistaButton();
			U20 = new VistaButtonTest.VistaButton();
			panel2 = new System.Windows.Forms.Panel();
			this.label22 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			numericUpDown13 = new System.Windows.Forms.NumericUpDown();
			this.label18 = new System.Windows.Forms.Label();
			tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			this.label19 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			numericUpDown5 = new System.Windows.Forms.NumericUpDown();
			this.label21 = new System.Windows.Forms.Label();
			numericUpDown6 = new System.Windows.Forms.NumericUpDown();
			numericUpDown2 = new System.Windows.Forms.NumericUpDown();
			numericUpDown4 = new System.Windows.Forms.NumericUpDown();
			numericUpDown3 = new System.Windows.Forms.NumericUpDown();
			this.label2 = new System.Windows.Forms.Label();
			numericUpDown14 = new System.Windows.Forms.NumericUpDown();
			this.label4 = new System.Windows.Forms.Label();
			tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.label5 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			numericUpDown7 = new System.Windows.Forms.NumericUpDown();
			numericUpDown8 = new System.Windows.Forms.NumericUpDown();
			numericUpDown11 = new System.Windows.Forms.NumericUpDown();
			numericUpDown12 = new System.Windows.Forms.NumericUpDown();
			numericUpDown9 = new System.Windows.Forms.NumericUpDown();
			numericUpDown10 = new System.Windows.Forms.NumericUpDown();
			this.label25 = new System.Windows.Forms.Label();
			this.label26 = new System.Windows.Forms.Label();
			checkBox3 = new System.Windows.Forms.CheckBox();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			groupBox12 = new System.Windows.Forms.GroupBox();
			textBox4 = new System.Windows.Forms.TextBox();
			floatText4 = new FloatTextBox.FloatText();
			floatText3 = new FloatTextBox.FloatText();
			floatText2 = new FloatTextBox.FloatText();
			Head = new FloatTextBox.FloatText();
			Length = new FloatTextBox.FloatText();
			YAge = new FloatTextBox.FloatText();
			Weight = new FloatTextBox.FloatText();
			MAge = new FloatTextBox.FloatText();
			textBox8 = new System.Windows.Forms.TextBox();
			button7 = new System.Windows.Forms.Button();
			groupBox9 = new System.Windows.Forms.GroupBox();
			button22 = new System.Windows.Forms.Button();
			button18 = new System.Windows.Forms.Button();
			button16 = new System.Windows.Forms.Button();
			groupBox21 = new System.Windows.Forms.GroupBox();
			textBox3 = new System.Windows.Forms.TextBox();
			textBox5 = new System.Windows.Forms.TextBox();
			groupBox24 = new System.Windows.Forms.GroupBox();
			button17 = new System.Windows.Forms.Button();
			txtQty = new FloatTextBox.FloatText();
			label72 = new System.Windows.Forms.Label();
			floatText1 = new FloatTextBox.FloatText();
			label71 = new System.Windows.Forms.Label();
			label70 = new System.Windows.Forms.Label();
			txtStore = new System.Windows.Forms.TextBox();
			itemIdComboBox = new System.Windows.Forms.ComboBox();
			groupBox22 = new System.Windows.Forms.GroupBox();
			dataGridView3 = new System.Windows.Forms.DataGridView();
			dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ItemId = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			groupBox25 = new System.Windows.Forms.GroupBox();
			txtEDD = new System.Windows.Forms.DateTimePicker();
			txtIMP = new System.Windows.Forms.DateTimePicker();
			txtOthers = new System.Windows.Forms.TextBox();
			txtUrinAnalysis = new System.Windows.Forms.TextBox();
			txtRBS = new System.Windows.Forms.TextBox();
			txtHeamoglobin = new System.Windows.Forms.TextBox();
			txtTreatment = new System.Windows.Forms.TextBox();
			txtUS = new System.Windows.Forms.TextBox();
			txtWeight = new System.Windows.Forms.TextBox();
			txtBP = new System.Windows.Forms.TextBox();
			txtComplain = new System.Windows.Forms.TextBox();
			groupBox26 = new System.Windows.Forms.GroupBox();
			dtpDate = new System.Windows.Forms.DateTimePicker();
			txtHistory = new System.Windows.Forms.TextBox();
			txtCS = new System.Windows.Forms.TextBox();
			txtKind = new System.Windows.Forms.TextBox();
			txtParity = new System.Windows.Forms.TextBox();
			toolTip1 = new System.Windows.Forms.ToolTip(components);
			groupBox27 = new System.Windows.Forms.GroupBox();
			dateTimeHeart = new System.Windows.Forms.DateTimePicker();
			txtBox21 = new System.Windows.Forms.TextBox();
			txtBox20 = new System.Windows.Forms.TextBox();
			txtBox19 = new System.Windows.Forms.TextBox();
			txtBox18 = new System.Windows.Forms.TextBox();
			txtBox17 = new System.Windows.Forms.TextBox();
			txtBox16 = new System.Windows.Forms.TextBox();
			txtBox15 = new System.Windows.Forms.TextBox();
			txtBox14 = new System.Windows.Forms.TextBox();
			txtBox13 = new System.Windows.Forms.TextBox();
			txtBox11 = new System.Windows.Forms.TextBox();
			txtBox12 = new System.Windows.Forms.TextBox();
			PaidPanel = new System.Windows.Forms.Panel();
			TreasuryCom = new System.Windows.Forms.ComboBox();
			EsalNoTxt = new System.Windows.Forms.TextBox();
			lblTreasury = new System.Windows.Forms.Label();
			label69 = new System.Windows.Forms.Label();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			PayNaqdy = new System.Windows.Forms.RadioButton();
			PayBefore = new System.Windows.Forms.RadioButton();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label7 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label8 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label9 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label10 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label11 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label12 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label13 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label14 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label15 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label16 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label17 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label18 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label19 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label20 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label21 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label22 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label23 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label24 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label25 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label26 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label27 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label28 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label29 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label30 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label31 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label32 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label33 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label34 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label35 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label36 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label37 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label38 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label39 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label40 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label41 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label42 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label43 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label44 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label45 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label46 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label47 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label48 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label49 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label50 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label51 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label52 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label53 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label54 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label55 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label56 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label57 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label58 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label59 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label60 = new System.Windows.Forms.Label();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox5.SuspendLayout();
			groupBox1.SuspendLayout();
			groupBox4.SuspendLayout();
			groupBox29.SuspendLayout();
			groupBox10.SuspendLayout();
			panel1.SuspendLayout();
			groupBox7.SuspendLayout();
			groupBox3.SuspendLayout();
			panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown13).BeginInit();
			tableLayoutPanel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown5).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown6).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown4).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown3).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown14).BeginInit();
			tableLayoutPanel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown7).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown8).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown11).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown12).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown9).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown10).BeginInit();
			groupBox12.SuspendLayout();
			groupBox9.SuspendLayout();
			groupBox21.SuspendLayout();
			groupBox24.SuspendLayout();
			groupBox22.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
			groupBox25.SuspendLayout();
			groupBox27.SuspendLayout();
			PaidPanel.SuspendLayout();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "label3");
			label.BackColor = System.Drawing.Color.Transparent;
			label.ForeColor = System.Drawing.Color.Firebrick;
			label.Name = "label3";
			toolTip1.SetToolTip(label, resources.GetString("label3.ToolTip"));
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label10");
			label2.Name = "label10";
			toolTip1.SetToolTip(label2, resources.GetString("label10.ToolTip"));
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label11");
			label3.Name = "label11";
			toolTip1.SetToolTip(label3, resources.GetString("label11.ToolTip"));
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label12");
			label4.Name = "label12";
			toolTip1.SetToolTip(label4, resources.GetString("label12.ToolTip"));
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label13");
			label5.Name = "label13";
			toolTip1.SetToolTip(label5, resources.GetString("label13.ToolTip"));
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "label14");
			label6.Name = "label14";
			toolTip1.SetToolTip(label6, resources.GetString("label14.ToolTip"));
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "label15");
			label7.Name = "label15";
			toolTip1.SetToolTip(label7, resources.GetString("label15.ToolTip"));
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "label39");
			label8.BackColor = System.Drawing.Color.Transparent;
			label8.Name = "label39";
			toolTip1.SetToolTip(label8, resources.GetString("label39.ToolTip"));
			label9.AccessibleDescription = null;
			label9.AccessibleName = null;
			resources.ApplyResources(label9, "label38");
			label9.BackColor = System.Drawing.Color.Transparent;
			label9.Name = "label38";
			toolTip1.SetToolTip(label9, resources.GetString("label38.ToolTip"));
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "label36");
			label10.BackColor = System.Drawing.Color.Transparent;
			label10.Name = "label36";
			toolTip1.SetToolTip(label10, resources.GetString("label36.ToolTip"));
			label11.AccessibleDescription = null;
			label11.AccessibleName = null;
			resources.ApplyResources(label11, "label37");
			label11.BackColor = System.Drawing.Color.Transparent;
			label11.Name = "label37";
			toolTip1.SetToolTip(label11, resources.GetString("label37.ToolTip"));
			label12.AccessibleDescription = null;
			label12.AccessibleName = null;
			resources.ApplyResources(label12, "label35");
			label12.BackColor = System.Drawing.Color.Transparent;
			label12.Name = "label35";
			toolTip1.SetToolTip(label12, resources.GetString("label35.ToolTip"));
			label13.AccessibleDescription = null;
			label13.AccessibleName = null;
			resources.ApplyResources(label13, "label33");
			label13.BackColor = System.Drawing.Color.Transparent;
			label13.Name = "label33";
			toolTip1.SetToolTip(label13, resources.GetString("label33.ToolTip"));
			label14.AccessibleDescription = null;
			label14.AccessibleName = null;
			resources.ApplyResources(label14, "label32");
			label14.BackColor = System.Drawing.Color.Transparent;
			label14.Name = "label32";
			toolTip1.SetToolTip(label14, resources.GetString("label32.ToolTip"));
			label15.AccessibleDescription = null;
			label15.AccessibleName = null;
			resources.ApplyResources(label15, "label27");
			label15.BackColor = System.Drawing.Color.Transparent;
			label15.Name = "label27";
			toolTip1.SetToolTip(label15, resources.GetString("label27.ToolTip"));
			label16.AccessibleDescription = null;
			label16.AccessibleName = null;
			resources.ApplyResources(label16, "label28");
			label16.BackColor = System.Drawing.Color.Transparent;
			label16.Name = "label28";
			toolTip1.SetToolTip(label16, resources.GetString("label28.ToolTip"));
			label17.AccessibleDescription = null;
			label17.AccessibleName = null;
			resources.ApplyResources(label17, "label31");
			label17.BackColor = System.Drawing.Color.Transparent;
			label17.Name = "label31";
			toolTip1.SetToolTip(label17, resources.GetString("label31.ToolTip"));
			label18.AccessibleDescription = null;
			label18.AccessibleName = null;
			resources.ApplyResources(label18, "label30");
			label18.BackColor = System.Drawing.Color.Transparent;
			label18.Name = "label30";
			toolTip1.SetToolTip(label18, resources.GetString("label30.ToolTip"));
			label19.AccessibleDescription = null;
			label19.AccessibleName = null;
			resources.ApplyResources(label19, "label29");
			label19.BackColor = System.Drawing.Color.Transparent;
			label19.Name = "label29";
			toolTip1.SetToolTip(label19, resources.GetString("label29.ToolTip"));
			label20.AccessibleDescription = null;
			label20.AccessibleName = null;
			resources.ApplyResources(label20, "label34");
			label20.BackColor = System.Drawing.Color.Transparent;
			label20.Name = "label34";
			toolTip1.SetToolTip(label20, resources.GetString("label34.ToolTip"));
			label21.AccessibleDescription = null;
			label21.AccessibleName = null;
			resources.ApplyResources(label21, "label40");
			label21.BackColor = System.Drawing.Color.Transparent;
			label21.Name = "label40";
			toolTip1.SetToolTip(label21, resources.GetString("label40.ToolTip"));
			label22.AccessibleDescription = null;
			label22.AccessibleName = null;
			resources.ApplyResources(label22, "label43");
			label22.Name = "label43";
			toolTip1.SetToolTip(label22, resources.GetString("label43.ToolTip"));
			label23.AccessibleDescription = null;
			label23.AccessibleName = null;
			resources.ApplyResources(label23, "label41");
			label23.BackColor = System.Drawing.Color.Transparent;
			label23.Name = "label41";
			toolTip1.SetToolTip(label23, resources.GetString("label41.ToolTip"));
			label24.AccessibleDescription = null;
			label24.AccessibleName = null;
			resources.ApplyResources(label24, "label42");
			label24.BackColor = System.Drawing.Color.Transparent;
			label24.Name = "label42";
			toolTip1.SetToolTip(label24, resources.GetString("label42.ToolTip"));
			label25.AccessibleDescription = null;
			label25.AccessibleName = null;
			resources.ApplyResources(label25, "label81");
			label25.BackColor = System.Drawing.Color.Transparent;
			label25.Name = "label81";
			toolTip1.SetToolTip(label25, resources.GetString("label81.ToolTip"));
			label26.AccessibleDescription = null;
			label26.AccessibleName = null;
			resources.ApplyResources(label26, "label80");
			label26.BackColor = System.Drawing.Color.Transparent;
			label26.Name = "label80";
			toolTip1.SetToolTip(label26, resources.GetString("label80.ToolTip"));
			label27.AccessibleDescription = null;
			label27.AccessibleName = null;
			resources.ApplyResources(label27, "label78");
			label27.BackColor = System.Drawing.Color.Transparent;
			label27.Name = "label78";
			toolTip1.SetToolTip(label27, resources.GetString("label78.ToolTip"));
			label28.AccessibleDescription = null;
			label28.AccessibleName = null;
			resources.ApplyResources(label28, "label77");
			label28.BackColor = System.Drawing.Color.Transparent;
			label28.Name = "label77";
			toolTip1.SetToolTip(label28, resources.GetString("label77.ToolTip"));
			label29.AccessibleDescription = null;
			label29.AccessibleName = null;
			resources.ApplyResources(label29, "label76");
			label29.BackColor = System.Drawing.Color.Transparent;
			label29.Name = "label76";
			toolTip1.SetToolTip(label29, resources.GetString("label76.ToolTip"));
			label30.AccessibleDescription = null;
			label30.AccessibleName = null;
			resources.ApplyResources(label30, "label75");
			label30.BackColor = System.Drawing.Color.Transparent;
			label30.Name = "label75";
			toolTip1.SetToolTip(label30, resources.GetString("label75.ToolTip"));
			label31.AccessibleDescription = null;
			label31.AccessibleName = null;
			resources.ApplyResources(label31, "label74");
			label31.BackColor = System.Drawing.Color.Transparent;
			label31.Name = "label74";
			toolTip1.SetToolTip(label31, resources.GetString("label74.ToolTip"));
			label32.AccessibleDescription = null;
			label32.AccessibleName = null;
			resources.ApplyResources(label32, "label73");
			label32.BackColor = System.Drawing.Color.Transparent;
			label32.Name = "label73";
			toolTip1.SetToolTip(label32, resources.GetString("label73.ToolTip"));
			label33.AccessibleDescription = null;
			label33.AccessibleName = null;
			resources.ApplyResources(label33, "label85");
			label33.BackColor = System.Drawing.Color.Transparent;
			label33.Name = "label85";
			toolTip1.SetToolTip(label33, resources.GetString("label85.ToolTip"));
			label34.AccessibleDescription = null;
			label34.AccessibleName = null;
			resources.ApplyResources(label34, "label79");
			label34.BackColor = System.Drawing.Color.Transparent;
			label34.Name = "label79";
			toolTip1.SetToolTip(label34, resources.GetString("label79.ToolTip"));
			label35.AccessibleDescription = null;
			label35.AccessibleName = null;
			resources.ApplyResources(label35, "label90");
			label35.BackColor = System.Drawing.Color.Transparent;
			label35.Name = "label90";
			toolTip1.SetToolTip(label35, resources.GetString("label90.ToolTip"));
			label36.AccessibleDescription = null;
			label36.AccessibleName = null;
			resources.ApplyResources(label36, "label91");
			label36.BackColor = System.Drawing.Color.Transparent;
			label36.Name = "label91";
			toolTip1.SetToolTip(label36, resources.GetString("label91.ToolTip"));
			label37.AccessibleDescription = null;
			label37.AccessibleName = null;
			resources.ApplyResources(label37, "label88");
			label37.BackColor = System.Drawing.Color.Transparent;
			label37.Name = "label88";
			toolTip1.SetToolTip(label37, resources.GetString("label88.ToolTip"));
			label38.AccessibleDescription = null;
			label38.AccessibleName = null;
			resources.ApplyResources(label38, "label89");
			label38.BackColor = System.Drawing.Color.Transparent;
			label38.Name = "label89";
			toolTip1.SetToolTip(label38, resources.GetString("label89.ToolTip"));
			label39.AccessibleDescription = null;
			label39.AccessibleName = null;
			resources.ApplyResources(label39, "label87");
			label39.BackColor = System.Drawing.Color.Transparent;
			label39.Name = "label87";
			toolTip1.SetToolTip(label39, resources.GetString("label87.ToolTip"));
			label40.AccessibleDescription = null;
			label40.AccessibleName = null;
			resources.ApplyResources(label40, "label86");
			label40.BackColor = System.Drawing.Color.Transparent;
			label40.Name = "label86";
			toolTip1.SetToolTip(label40, resources.GetString("label86.ToolTip"));
			label41.AccessibleDescription = null;
			label41.AccessibleName = null;
			resources.ApplyResources(label41, "label82");
			label41.Name = "label82";
			toolTip1.SetToolTip(label41, resources.GetString("label82.ToolTip"));
			label42.AccessibleDescription = null;
			label42.AccessibleName = null;
			resources.ApplyResources(label42, "label83");
			label42.Name = "label83";
			toolTip1.SetToolTip(label42, resources.GetString("label83.ToolTip"));
			label43.AccessibleDescription = null;
			label43.AccessibleName = null;
			resources.ApplyResources(label43, "label104");
			label43.BackColor = System.Drawing.Color.Transparent;
			label43.Name = "label104";
			toolTip1.SetToolTip(label43, resources.GetString("label104.ToolTip"));
			label44.AccessibleDescription = null;
			label44.AccessibleName = null;
			resources.ApplyResources(label44, "label103");
			label44.BackColor = System.Drawing.Color.Transparent;
			label44.Name = "label103";
			toolTip1.SetToolTip(label44, resources.GetString("label103.ToolTip"));
			label45.AccessibleDescription = null;
			label45.AccessibleName = null;
			resources.ApplyResources(label45, "label102");
			label45.BackColor = System.Drawing.Color.Transparent;
			label45.Name = "label102";
			toolTip1.SetToolTip(label45, resources.GetString("label102.ToolTip"));
			label46.AccessibleDescription = null;
			label46.AccessibleName = null;
			resources.ApplyResources(label46, "label100");
			label46.BackColor = System.Drawing.Color.Transparent;
			label46.Name = "label100";
			toolTip1.SetToolTip(label46, resources.GetString("label100.ToolTip"));
			label47.AccessibleDescription = null;
			label47.AccessibleName = null;
			resources.ApplyResources(label47, "label99");
			label47.BackColor = System.Drawing.Color.Transparent;
			label47.Name = "label99";
			toolTip1.SetToolTip(label47, resources.GetString("label99.ToolTip"));
			label48.AccessibleDescription = null;
			label48.AccessibleName = null;
			resources.ApplyResources(label48, "label97");
			label48.BackColor = System.Drawing.Color.Transparent;
			label48.Name = "label97";
			toolTip1.SetToolTip(label48, resources.GetString("label97.ToolTip"));
			label49.AccessibleDescription = null;
			label49.AccessibleName = null;
			resources.ApplyResources(label49, "label96");
			label49.BackColor = System.Drawing.Color.Transparent;
			label49.Name = "label96";
			toolTip1.SetToolTip(label49, resources.GetString("label96.ToolTip"));
			label50.AccessibleDescription = null;
			label50.AccessibleName = null;
			resources.ApplyResources(label50, "label93");
			label50.BackColor = System.Drawing.Color.Transparent;
			label50.Name = "label93";
			toolTip1.SetToolTip(label50, resources.GetString("label93.ToolTip"));
			label51.AccessibleDescription = null;
			label51.AccessibleName = null;
			resources.ApplyResources(label51, "label84");
			label51.BackColor = System.Drawing.Color.Transparent;
			label51.Name = "label84";
			toolTip1.SetToolTip(label51, resources.GetString("label84.ToolTip"));
			label52.AccessibleDescription = null;
			label52.AccessibleName = null;
			resources.ApplyResources(label52, "label92");
			label52.BackColor = System.Drawing.Color.Transparent;
			label52.Name = "label92";
			toolTip1.SetToolTip(label52, resources.GetString("label92.ToolTip"));
			label53.AccessibleDescription = null;
			label53.AccessibleName = null;
			resources.ApplyResources(label53, "label94");
			label53.BackColor = System.Drawing.Color.Transparent;
			label53.Name = "label94";
			toolTip1.SetToolTip(label53, resources.GetString("label94.ToolTip"));
			label54.AccessibleDescription = null;
			label54.AccessibleName = null;
			resources.ApplyResources(label54, "label95");
			label54.BackColor = System.Drawing.Color.Transparent;
			label54.Name = "label95";
			toolTip1.SetToolTip(label54, resources.GetString("label95.ToolTip"));
			label55.AccessibleDescription = null;
			label55.AccessibleName = null;
			resources.ApplyResources(label55, "label98");
			label55.BackColor = System.Drawing.Color.Transparent;
			label55.Name = "label98";
			toolTip1.SetToolTip(label55, resources.GetString("label98.ToolTip"));
			label56.AccessibleDescription = null;
			label56.AccessibleName = null;
			resources.ApplyResources(label56, "label101");
			label56.BackColor = System.Drawing.Color.Transparent;
			label56.Name = "label101";
			toolTip1.SetToolTip(label56, resources.GetString("label101.ToolTip"));
			label57.AccessibleDescription = null;
			label57.AccessibleName = null;
			resources.ApplyResources(label57, "label115");
			label57.Name = "label115";
			toolTip1.SetToolTip(label57, resources.GetString("label115.ToolTip"));
			label58.AccessibleDescription = null;
			label58.AccessibleName = null;
			resources.ApplyResources(label58, "label116");
			label58.Name = "label116";
			toolTip1.SetToolTip(label58, resources.GetString("label116.ToolTip"));
			label59.AccessibleDescription = null;
			label59.AccessibleName = null;
			resources.ApplyResources(label59, "label117");
			label59.Name = "label117";
			toolTip1.SetToolTip(label59, resources.GetString("label117.ToolTip"));
			label60.AccessibleDescription = null;
			label60.AccessibleName = null;
			resources.ApplyResources(label60, "label110");
			label60.Name = "label110";
			toolTip1.SetToolTip(label60, resources.GetString("label110.ToolTip"));
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(this.label7);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			toolTip1.SetToolTip(groupBox2, resources.GetString("groupBox2.ToolTip"));
			this.label7.AccessibleDescription = null;
			this.label7.AccessibleName = null;
			resources.ApplyResources(this.label7, "label7");
			this.label7.Name = "label7";
			toolTip1.SetToolTip(this.label7, resources.GetString("label7.ToolTip"));
			ADDBtn.AccessibleDescription = null;
			ADDBtn.AccessibleName = null;
			resources.ApplyResources(ADDBtn, "ADDBtn");
			ADDBtn.BackColor = System.Drawing.Color.Gainsboro;
			ADDBtn.BackgroundImage = null;
			ADDBtn.Name = "ADDBtn";
			toolTip1.SetToolTip(ADDBtn, resources.GetString("ADDBtn.ToolTip"));
			ADDBtn.UseVisualStyleBackColor = false;
			ADDBtn.Click += new System.EventHandler(ADDBtn_Click);
			doctorcomboBox.AccessibleDescription = null;
			doctorcomboBox.AccessibleName = null;
			resources.ApplyResources(doctorcomboBox, "doctorcomboBox");
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.BackgroundImage = null;
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Name = "doctorcomboBox";
			toolTip1.SetToolTip(doctorcomboBox, resources.GetString("doctorcomboBox.ToolTip"));
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(Service, Price, ServiceDate, Teethn, Tid, Cost, Count, driba, Aftrdriba, Column1, Column2, Column4);
			dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			toolTip1.SetToolTip(dataGridView1, resources.GetString("dataGridView1.ToolTip"));
			dataGridView1.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(dataGridView1_UserDeletingRow);
			dataGridView1.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(dataGridView1_RowsRemoved);
			resources.ApplyResources(Service, "Service");
			Service.Name = "Service";
			Service.ReadOnly = true;
			resources.ApplyResources(Price, "Price");
			Price.Name = "Price";
			Price.ReadOnly = true;
			resources.ApplyResources(ServiceDate, "ServiceDate");
			ServiceDate.Name = "ServiceDate";
			ServiceDate.ReadOnly = true;
			resources.ApplyResources(Teethn, "Teethn");
			Teethn.Name = "Teethn";
			Teethn.ReadOnly = true;
			resources.ApplyResources(Tid, "Tid");
			Tid.Name = "Tid";
			Tid.ReadOnly = true;
			resources.ApplyResources(Cost, "Cost");
			Cost.Name = "Cost";
			Cost.ReadOnly = true;
			resources.ApplyResources(Count, "Count");
			Count.Name = "Count";
			Count.ReadOnly = true;
			resources.ApplyResources(driba, "driba");
			driba.Name = "driba";
			driba.ReadOnly = true;
			resources.ApplyResources(Aftrdriba, "Aftrdriba");
			Aftrdriba.Name = "Aftrdriba";
			Aftrdriba.ReadOnly = true;
			resources.ApplyResources(Column1, "Column1");
			Column1.Name = "Column1";
			Column1.ReadOnly = true;
			resources.ApplyResources(Column2, "Column2");
			Column2.Name = "Column2";
			resources.ApplyResources(Column4, "Column4");
			Column4.Name = "Column4";
			Column4.ReadOnly = true;
			appdateTimePicker1.AccessibleDescription = null;
			appdateTimePicker1.AccessibleName = null;
			resources.ApplyResources(appdateTimePicker1, "appdateTimePicker1");
			appdateTimePicker1.BackgroundImage = null;
			appdateTimePicker1.CalendarFont = null;
			appdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			appdateTimePicker1.Name = "appdateTimePicker1";
			toolTip1.SetToolTip(appdateTimePicker1, resources.GetString("appdateTimePicker1.ToolTip"));
			groupBox5.AccessibleDescription = null;
			groupBox5.AccessibleName = null;
			resources.ApplyResources(groupBox5, "groupBox5");
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.BackgroundImage = null;
			groupBox5.Controls.Add(saveBtn);
			groupBox5.Font = null;
			groupBox5.Name = "groupBox5";
			groupBox5.TabStop = false;
			toolTip1.SetToolTip(groupBox5, resources.GetString("groupBox5.ToolTip"));
			saveBtn.AccessibleDescription = null;
			saveBtn.AccessibleName = null;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			saveBtn.BackgroundImage = null;
			saveBtn.Name = "saveBtn";
			toolTip1.SetToolTip(saveBtn, resources.GetString("saveBtn.ToolTip"));
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.BackgroundImage = null;
			button1.Name = "button1";
			toolTip1.SetToolTip(button1, resources.GetString("button1.ToolTip"));
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			tottextBox.AccessibleDescription = null;
			tottextBox.AccessibleName = null;
			resources.ApplyResources(tottextBox, "tottextBox");
			tottextBox.BackgroundImage = null;
			tottextBox.Font = null;
			tottextBox.ForeColor = System.Drawing.Color.Maroon;
			tottextBox.Name = "tottextBox";
			tottextBox.ReadOnly = true;
			toolTip1.SetToolTip(tottextBox, resources.GetString("tottextBox.ToolTip"));
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(dataGridView1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			toolTip1.SetToolTip(groupBox1, resources.GetString("groupBox1.ToolTip"));
			PatientComboBox.AccessibleDescription = null;
			PatientComboBox.AccessibleName = null;
			resources.ApplyResources(PatientComboBox, "PatientComboBox");
			PatientComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			PatientComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientComboBox.BackgroundImage = null;
			PatientComboBox.FormattingEnabled = true;
			PatientComboBox.Name = "PatientComboBox";
			toolTip1.SetToolTip(PatientComboBox, resources.GetString("PatientComboBox.ToolTip"));
			PatientComboBox.SelectedIndexChanged += new System.EventHandler(PatientComboBox_SelectedIndexChanged);
			PatientComboBox.SelectedValueChanged += new System.EventHandler(PatientComboBox_SelectedValueChanged);
			PricetextBox.AccessibleDescription = null;
			PricetextBox.AccessibleName = null;
			resources.ApplyResources(PricetextBox, "PricetextBox");
			PricetextBox.BackgroundImage = null;
			PricetextBox.Name = "PricetextBox";
			toolTip1.SetToolTip(PricetextBox, resources.GetString("PricetextBox.ToolTip"));
			PricetextBox.TextChanged += new System.EventHandler(PricetextBox_TextChanged);
			PricetextBox.Leave += new System.EventHandler(PricetextBox_Leave);
			PricetextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(PricetextBox_KeyPress);
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(label60);
			groupBox4.Controls.Add(Rased);
			groupBox4.Controls.Add(radioButton5);
			groupBox4.Controls.Add(radioButton6);
			groupBox4.Controls.Add(btnPatient);
			groupBox4.Controls.Add(groupBox10);
			groupBox4.Controls.Add(AssistantcomboBox);
			groupBox4.Controls.Add(label22);
			groupBox4.Controls.Add(label4);
			groupBox4.Controls.Add(label5);
			groupBox4.Controls.Add(label7);
			groupBox4.Controls.Add(button2);
			groupBox4.Controls.Add(doctorcomboBox);
			groupBox4.Controls.Add(PatientComboBox);
			groupBox4.Controls.Add(groupBox1);
			groupBox4.Controls.Add(appdateTimePicker1);
			groupBox4.Controls.Add(groupBox29);
			groupBox4.ForeColor = System.Drawing.Color.Black;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			toolTip1.SetToolTip(groupBox4, resources.GetString("groupBox4.ToolTip"));
			Rased.AccessibleDescription = null;
			Rased.AccessibleName = null;
			resources.ApplyResources(Rased, "Rased");
			Rased.BackColor = System.Drawing.Color.White;
			Rased.BackgroundImage = null;
			Rased.Font = null;
			Rased.ForeColor = System.Drawing.Color.Black;
			Rased.Name = "Rased";
			Rased.ReadOnly = true;
			toolTip1.SetToolTip(Rased, resources.GetString("Rased.ToolTip"));
			groupBox29.AccessibleDescription = null;
			groupBox29.AccessibleName = null;
			resources.ApplyResources(groupBox29, "groupBox29");
			groupBox29.BackColor = System.Drawing.Color.Transparent;
			groupBox29.BackgroundImage = null;
			groupBox29.Controls.Add(label57);
			groupBox29.Controls.Add(label58);
			groupBox29.Controls.Add(label59);
			groupBox29.Controls.Add(OfferPrice);
			groupBox29.Controls.Add(button23);
			groupBox29.Controls.Add(dateTimePicker4);
			groupBox29.Controls.Add(OfferName);
			groupBox29.Name = "groupBox29";
			groupBox29.TabStop = false;
			toolTip1.SetToolTip(groupBox29, resources.GetString("groupBox29.ToolTip"));
			OfferName.AccessibleDescription = null;
			OfferName.AccessibleName = null;
			resources.ApplyResources(OfferName, "OfferName");
			OfferName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			OfferName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			OfferName.BackgroundImage = null;
			OfferName.FormattingEnabled = true;
			OfferName.Name = "OfferName";
			toolTip1.SetToolTip(OfferName, resources.GetString("OfferName.ToolTip"));
			OfferName.SelectedIndexChanged += new System.EventHandler(OfferName_SelectedIndexChanged);
			OfferPrice.AccessibleDescription = null;
			OfferPrice.AccessibleName = null;
			resources.ApplyResources(OfferPrice, "OfferPrice");
			OfferPrice.BackgroundImage = null;
			OfferPrice.Name = "OfferPrice";
			toolTip1.SetToolTip(OfferPrice, resources.GetString("OfferPrice.ToolTip"));
			button23.AccessibleDescription = null;
			button23.AccessibleName = null;
			resources.ApplyResources(button23, "button23");
			button23.BackColor = System.Drawing.Color.Gainsboro;
			button23.BackgroundImage = null;
			button23.Name = "button23";
			toolTip1.SetToolTip(button23, resources.GetString("button23.ToolTip"));
			button23.UseVisualStyleBackColor = false;
			button23.Click += new System.EventHandler(button23_Click);
			dateTimePicker4.AccessibleDescription = null;
			dateTimePicker4.AccessibleName = null;
			resources.ApplyResources(dateTimePicker4, "dateTimePicker4");
			dateTimePicker4.BackgroundImage = null;
			dateTimePicker4.CalendarFont = null;
			dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker4.Name = "dateTimePicker4";
			toolTip1.SetToolTip(dateTimePicker4, resources.GetString("dateTimePicker4.ToolTip"));
			radioButton5.AccessibleDescription = null;
			radioButton5.AccessibleName = null;
			resources.ApplyResources(radioButton5, "radioButton5");
			radioButton5.BackgroundImage = null;
			radioButton5.Checked = true;
			radioButton5.Name = "radioButton5";
			radioButton5.TabStop = true;
			toolTip1.SetToolTip(radioButton5, resources.GetString("radioButton5.ToolTip"));
			radioButton5.UseVisualStyleBackColor = true;
			radioButton5.CheckedChanged += new System.EventHandler(radioButton5_CheckedChanged);
			radioButton6.AccessibleDescription = null;
			radioButton6.AccessibleName = null;
			resources.ApplyResources(radioButton6, "radioButton6");
			radioButton6.BackgroundImage = null;
			radioButton6.Name = "radioButton6";
			toolTip1.SetToolTip(radioButton6, resources.GetString("radioButton6.ToolTip"));
			radioButton6.UseVisualStyleBackColor = true;
			btnPatient.AccessibleDescription = null;
			btnPatient.AccessibleName = null;
			resources.ApplyResources(btnPatient, "btnPatient");
			btnPatient.BackColor = System.Drawing.Color.Gainsboro;
			btnPatient.BackgroundImage = null;
			btnPatient.Name = "btnPatient";
			toolTip1.SetToolTip(btnPatient, resources.GetString("btnPatient.ToolTip"));
			btnPatient.UseVisualStyleBackColor = false;
			btnPatient.Click += new System.EventHandler(btnPatient_Click);
			groupBox10.AccessibleDescription = null;
			groupBox10.AccessibleName = null;
			resources.ApplyResources(groupBox10, "groupBox10");
			groupBox10.BackColor = System.Drawing.Color.Transparent;
			groupBox10.BackgroundImage = null;
			groupBox10.Controls.Add(label105);
			groupBox10.Controls.Add(textBoxDiscount);
			groupBox10.Controls.Add(this.label46);
			groupBox10.Controls.Add(this.label48);
			groupBox10.Controls.Add(Dariba);
			groupBox10.Controls.Add(floatText5);
			groupBox10.Controls.Add(label42);
			groupBox10.Controls.Add(this.label47);
			groupBox10.Controls.Add(AfterDariba);
			groupBox10.Controls.Add(comboCategory);
			groupBox10.Controls.Add(label41);
			groupBox10.Controls.Add(label3);
			groupBox10.Controls.Add(commentTextBox);
			groupBox10.Controls.Add(dateTimePicker1);
			groupBox10.Controls.Add(label2);
			groupBox10.Controls.Add(PricetextBox);
			groupBox10.Controls.Add(label6);
			groupBox10.Controls.Add(ADDBtn);
			groupBox10.Name = "groupBox10";
			groupBox10.TabStop = false;
			toolTip1.SetToolTip(groupBox10, resources.GetString("groupBox10.ToolTip"));
			label105.AccessibleDescription = null;
			label105.AccessibleName = null;
			resources.ApplyResources(label105, "label105");
			label105.BackColor = System.Drawing.Color.Transparent;
			label105.Name = "label105";
			toolTip1.SetToolTip(label105, resources.GetString("label105.ToolTip"));
			textBoxDiscount.AccessibleDescription = null;
			textBoxDiscount.AccessibleName = null;
			resources.ApplyResources(textBoxDiscount, "textBoxDiscount");
			textBoxDiscount.BackgroundImage = null;
			textBoxDiscount.Name = "textBoxDiscount";
			toolTip1.SetToolTip(textBoxDiscount, resources.GetString("textBoxDiscount.ToolTip"));
			this.label46.AccessibleDescription = null;
			this.label46.AccessibleName = null;
			resources.ApplyResources(this.label46, "label46");
			this.label46.Name = "label46";
			toolTip1.SetToolTip(this.label46, resources.GetString("label46.ToolTip"));
			this.label48.AccessibleDescription = null;
			this.label48.AccessibleName = null;
			resources.ApplyResources(this.label48, "label48");
			this.label48.BackColor = System.Drawing.Color.Transparent;
			this.label48.Name = "label48";
			toolTip1.SetToolTip(this.label48, resources.GetString("label48.ToolTip"));
			Dariba.AccessibleDescription = null;
			Dariba.AccessibleName = null;
			resources.ApplyResources(Dariba, "Dariba");
			Dariba.BackColor = System.Drawing.SystemColors.Window;
			Dariba.BackgroundImage = null;
			Dariba.Name = "Dariba";
			Dariba.ReadOnly = true;
			toolTip1.SetToolTip(Dariba, resources.GetString("Dariba.ToolTip"));
			floatText5.AccessibleDescription = null;
			floatText5.AccessibleName = null;
			resources.ApplyResources(floatText5, "floatText5");
			floatText5.BackgroundImage = null;
			floatText5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText5.Font = null;
			floatText5.Name = "floatText5";
			toolTip1.SetToolTip(floatText5, resources.GetString("floatText5.ToolTip"));
			this.label47.AccessibleDescription = null;
			this.label47.AccessibleName = null;
			resources.ApplyResources(this.label47, "label47");
			this.label47.Name = "label47";
			toolTip1.SetToolTip(this.label47, resources.GetString("label47.ToolTip"));
			AfterDariba.AccessibleDescription = null;
			AfterDariba.AccessibleName = null;
			resources.ApplyResources(AfterDariba, "AfterDariba");
			AfterDariba.BackColor = System.Drawing.SystemColors.Window;
			AfterDariba.BackgroundImage = null;
			AfterDariba.Name = "AfterDariba";
			AfterDariba.ReadOnly = true;
			toolTip1.SetToolTip(AfterDariba, resources.GetString("AfterDariba.ToolTip"));
			comboCategory.AccessibleDescription = null;
			comboCategory.AccessibleName = null;
			resources.ApplyResources(comboCategory, "comboCategory");
			comboCategory.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboCategory.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboCategory.BackgroundImage = null;
			comboCategory.FormattingEnabled = true;
			comboCategory.Name = "comboCategory";
			toolTip1.SetToolTip(comboCategory, resources.GetString("comboCategory.ToolTip"));
			comboCategory.SelectedIndexChanged += new System.EventHandler(comboCategory_SelectedIndexChanged);
			commentTextBox.AccessibleDescription = null;
			commentTextBox.AccessibleName = null;
			resources.ApplyResources(commentTextBox, "commentTextBox");
			commentTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			commentTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			commentTextBox.BackgroundImage = null;
			commentTextBox.FormattingEnabled = true;
			commentTextBox.Name = "commentTextBox";
			toolTip1.SetToolTip(commentTextBox, resources.GetString("commentTextBox.ToolTip"));
			commentTextBox.SelectedIndexChanged += new System.EventHandler(commentTextBox_TextChanged);
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			toolTip1.SetToolTip(dateTimePicker1, resources.GetString("dateTimePicker1.ToolTip"));
			AssistantcomboBox.AccessibleDescription = null;
			AssistantcomboBox.AccessibleName = null;
			resources.ApplyResources(AssistantcomboBox, "AssistantcomboBox");
			AssistantcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			AssistantcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			AssistantcomboBox.BackgroundImage = null;
			AssistantcomboBox.FormattingEnabled = true;
			AssistantcomboBox.Name = "AssistantcomboBox";
			toolTip1.SetToolTip(AssistantcomboBox, resources.GetString("AssistantcomboBox.ToolTip"));
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackColor = System.Drawing.Color.Gainsboro;
			button2.BackgroundImage = null;
			button2.Name = "button2";
			toolTip1.SetToolTip(button2, resources.GetString("button2.ToolTip"));
			button2.UseVisualStyleBackColor = false;
			button2.Click += new System.EventHandler(button2_Click);
			button6.AccessibleDescription = null;
			button6.AccessibleName = null;
			resources.ApplyResources(button6, "button6");
			button6.BackColor = System.Drawing.Color.Gainsboro;
			button6.BackgroundImage = null;
			button6.Name = "button6";
			toolTip1.SetToolTip(button6, resources.GetString("button6.ToolTip"));
			button6.UseVisualStyleBackColor = false;
			button6.Click += new System.EventHandler(button6_Click);
			button5.AccessibleDescription = null;
			button5.AccessibleName = null;
			resources.ApplyResources(button5, "button5");
			button5.BackColor = System.Drawing.Color.Gainsboro;
			button5.BackgroundImage = null;
			button5.Name = "button5";
			toolTip1.SetToolTip(button5, resources.GetString("button5.ToolTip"));
			button5.UseVisualStyleBackColor = false;
			button5.Click += new System.EventHandler(button5_Click);
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackColor = System.Drawing.Color.Gainsboro;
			button3.BackgroundImage = null;
			button3.Name = "button3";
			toolTip1.SetToolTip(button3, resources.GetString("button3.ToolTip"));
			button3.UseVisualStyleBackColor = false;
			button3.Click += new System.EventHandler(button3_Click);
			button4.AccessibleDescription = null;
			button4.AccessibleName = null;
			resources.ApplyResources(button4, "button4");
			button4.BackColor = System.Drawing.Color.Gainsboro;
			button4.BackgroundImage = null;
			button4.Name = "button4";
			toolTip1.SetToolTip(button4, resources.GetString("button4.ToolTip"));
			button4.UseVisualStyleBackColor = false;
			button4.Click += new System.EventHandler(button4_Click);
			panel1.AccessibleDescription = null;
			panel1.AccessibleName = null;
			resources.ApplyResources(panel1, "panel1");
			panel1.BackColor = System.Drawing.Color.RosyBrown;
			panel1.BackgroundImage = null;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			panel1.Controls.Add(this.label9);
			panel1.Controls.Add(this.label8);
			panel1.Controls.Add(this.label6);
			panel1.Controls.Add(label1);
			panel1.Controls.Add(groupBox6);
			panel1.Controls.Add(groupBox7);
			panel1.Controls.Add(groupBox3);
			panel1.Controls.Add(U26);
			panel1.Controls.Add(U29);
			panel1.Controls.Add(U32);
			panel1.Controls.Add(U30);
			panel1.Controls.Add(U28);
			panel1.Controls.Add(U31);
			panel1.Controls.Add(U24);
			panel1.Controls.Add(U22);
			panel1.Controls.Add(U27);
			panel1.Controls.Add(U23);
			panel1.Controls.Add(U9);
			panel1.Controls.Add(U16);
			panel1.Controls.Add(U11);
			panel1.Controls.Add(U10);
			panel1.Controls.Add(U12);
			panel1.Controls.Add(U13);
			panel1.Controls.Add(U14);
			panel1.Controls.Add(U15);
			panel1.Controls.Add(U1);
			panel1.Controls.Add(U8);
			panel1.Controls.Add(U25);
			panel1.Controls.Add(U3);
			panel1.Controls.Add(U2);
			panel1.Controls.Add(U18);
			panel1.Controls.Add(U17);
			panel1.Controls.Add(U4);
			panel1.Controls.Add(U5);
			panel1.Controls.Add(U6);
			panel1.Controls.Add(U7);
			panel1.Controls.Add(U19);
			panel1.Controls.Add(U21);
			panel1.Controls.Add(U20);
			panel1.Font = null;
			panel1.Name = "panel1";
			toolTip1.SetToolTip(panel1, resources.GetString("panel1.ToolTip"));
			this.label9.AccessibleDescription = null;
			this.label9.AccessibleName = null;
			resources.ApplyResources(this.label9, "label9");
			this.label9.Font = null;
			this.label9.Name = "label9";
			toolTip1.SetToolTip(this.label9, resources.GetString("label9.ToolTip"));
			this.label8.AccessibleDescription = null;
			this.label8.AccessibleName = null;
			resources.ApplyResources(this.label8, "label8");
			this.label8.Font = null;
			this.label8.Name = "label8";
			toolTip1.SetToolTip(this.label8, resources.GetString("label8.ToolTip"));
			this.label6.AccessibleDescription = null;
			this.label6.AccessibleName = null;
			resources.ApplyResources(this.label6, "label6");
			this.label6.Font = null;
			this.label6.Name = "label6";
			toolTip1.SetToolTip(this.label6, resources.GetString("label6.ToolTip"));
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.Name = "label1";
			toolTip1.SetToolTip(label1, resources.GetString("label1.ToolTip"));
			groupBox6.AccessibleDescription = null;
			groupBox6.AccessibleName = null;
			resources.ApplyResources(groupBox6, "groupBox6");
			groupBox6.BackgroundImage = null;
			groupBox6.Font = null;
			groupBox6.Name = "groupBox6";
			groupBox6.TabStop = false;
			toolTip1.SetToolTip(groupBox6, resources.GetString("groupBox6.ToolTip"));
			groupBox7.AccessibleDescription = null;
			groupBox7.AccessibleName = null;
			resources.ApplyResources(groupBox7, "groupBox7");
			groupBox7.BackgroundImage = null;
			groupBox7.Controls.Add(vistaButton24);
			groupBox7.Controls.Add(vistaButton17);
			groupBox7.Controls.Add(vistaButton23);
			groupBox7.Controls.Add(vistaButton18);
			groupBox7.Controls.Add(vistaButton22);
			groupBox7.Controls.Add(vistaButton19);
			groupBox7.Controls.Add(vistaButton21);
			groupBox7.Controls.Add(vistaButton20);
			groupBox7.Font = null;
			groupBox7.Name = "groupBox7";
			groupBox7.TabStop = false;
			toolTip1.SetToolTip(groupBox7, resources.GetString("groupBox7.ToolTip"));
			vistaButton24.AccessibleDescription = null;
			vistaButton24.AccessibleName = null;
			resources.ApplyResources(vistaButton24, "vistaButton24");
			vistaButton24.BackColor = System.Drawing.Color.Maroon;
			vistaButton24.BackgroundImage = null;
			vistaButton24.BaseColor = System.Drawing.Color.White;
			vistaButton24.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton24.ButtonText = "7";
			vistaButton24.CornerRadius = 20;
			vistaButton24.Font = null;
			vistaButton24.ForeColor = System.Drawing.Color.Black;
			vistaButton24.Name = "vistaButton24";
			toolTip1.SetToolTip(vistaButton24, resources.GetString("vistaButton24.ToolTip"));
			vistaButton17.AccessibleDescription = null;
			vistaButton17.AccessibleName = null;
			resources.ApplyResources(vistaButton17, "vistaButton17");
			vistaButton17.BackColor = System.Drawing.Color.Maroon;
			vistaButton17.BackgroundImage = null;
			vistaButton17.BaseColor = System.Drawing.Color.White;
			vistaButton17.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton17.ButtonText = "1";
			vistaButton17.CornerRadius = 20;
			vistaButton17.Font = null;
			vistaButton17.ForeColor = System.Drawing.Color.Black;
			vistaButton17.Name = "vistaButton17";
			toolTip1.SetToolTip(vistaButton17, resources.GetString("vistaButton17.ToolTip"));
			vistaButton23.AccessibleDescription = null;
			vistaButton23.AccessibleName = null;
			resources.ApplyResources(vistaButton23, "vistaButton23");
			vistaButton23.BackColor = System.Drawing.Color.Maroon;
			vistaButton23.BackgroundImage = null;
			vistaButton23.BaseColor = System.Drawing.Color.White;
			vistaButton23.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton23.ButtonText = "6";
			vistaButton23.CornerRadius = 20;
			vistaButton23.Font = null;
			vistaButton23.ForeColor = System.Drawing.Color.Black;
			vistaButton23.Name = "vistaButton23";
			toolTip1.SetToolTip(vistaButton23, resources.GetString("vistaButton23.ToolTip"));
			vistaButton18.AccessibleDescription = null;
			vistaButton18.AccessibleName = null;
			resources.ApplyResources(vistaButton18, "vistaButton18");
			vistaButton18.BackColor = System.Drawing.Color.Maroon;
			vistaButton18.BackgroundImage = null;
			vistaButton18.BaseColor = System.Drawing.Color.White;
			vistaButton18.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton18.ButtonText = "8";
			vistaButton18.CornerRadius = 20;
			vistaButton18.Font = null;
			vistaButton18.ForeColor = System.Drawing.Color.Black;
			vistaButton18.Name = "vistaButton18";
			toolTip1.SetToolTip(vistaButton18, resources.GetString("vistaButton18.ToolTip"));
			vistaButton22.AccessibleDescription = null;
			vistaButton22.AccessibleName = null;
			resources.ApplyResources(vistaButton22, "vistaButton22");
			vistaButton22.BackColor = System.Drawing.Color.Maroon;
			vistaButton22.BackgroundImage = null;
			vistaButton22.BaseColor = System.Drawing.Color.White;
			vistaButton22.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton22.ButtonText = "5";
			vistaButton22.CornerRadius = 20;
			vistaButton22.Font = null;
			vistaButton22.ForeColor = System.Drawing.Color.Black;
			vistaButton22.Name = "vistaButton22";
			toolTip1.SetToolTip(vistaButton22, resources.GetString("vistaButton22.ToolTip"));
			vistaButton19.AccessibleDescription = null;
			vistaButton19.AccessibleName = null;
			resources.ApplyResources(vistaButton19, "vistaButton19");
			vistaButton19.BackColor = System.Drawing.Color.Maroon;
			vistaButton19.BackgroundImage = null;
			vistaButton19.BaseColor = System.Drawing.Color.White;
			vistaButton19.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton19.ButtonText = "3";
			vistaButton19.CornerRadius = 20;
			vistaButton19.Font = null;
			vistaButton19.ForeColor = System.Drawing.Color.Black;
			vistaButton19.Name = "vistaButton19";
			toolTip1.SetToolTip(vistaButton19, resources.GetString("vistaButton19.ToolTip"));
			vistaButton21.AccessibleDescription = null;
			vistaButton21.AccessibleName = null;
			resources.ApplyResources(vistaButton21, "vistaButton21");
			vistaButton21.BackColor = System.Drawing.Color.Maroon;
			vistaButton21.BackgroundImage = null;
			vistaButton21.BaseColor = System.Drawing.Color.White;
			vistaButton21.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton21.ButtonText = "4";
			vistaButton21.CornerRadius = 20;
			vistaButton21.Font = null;
			vistaButton21.ForeColor = System.Drawing.Color.Black;
			vistaButton21.Name = "vistaButton21";
			toolTip1.SetToolTip(vistaButton21, resources.GetString("vistaButton21.ToolTip"));
			vistaButton20.AccessibleDescription = null;
			vistaButton20.AccessibleName = null;
			resources.ApplyResources(vistaButton20, "vistaButton20");
			vistaButton20.BackColor = System.Drawing.Color.Maroon;
			vistaButton20.BackgroundImage = null;
			vistaButton20.BaseColor = System.Drawing.Color.White;
			vistaButton20.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton20.ButtonText = "2";
			vistaButton20.CornerRadius = 20;
			vistaButton20.Font = null;
			vistaButton20.ForeColor = System.Drawing.Color.Black;
			vistaButton20.Name = "vistaButton20";
			toolTip1.SetToolTip(vistaButton20, resources.GetString("vistaButton20.ToolTip"));
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(groupBox8);
			groupBox3.Controls.Add(vistaButton9);
			groupBox3.Controls.Add(vistaButton10);
			groupBox3.Controls.Add(vistaButton11);
			groupBox3.Controls.Add(vistaButton12);
			groupBox3.Controls.Add(vistaButton13);
			groupBox3.Controls.Add(vistaButton14);
			groupBox3.Controls.Add(vistaButton15);
			groupBox3.Controls.Add(vistaButton16);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			toolTip1.SetToolTip(groupBox3, resources.GetString("groupBox3.ToolTip"));
			groupBox8.AccessibleDescription = null;
			groupBox8.AccessibleName = null;
			resources.ApplyResources(groupBox8, "groupBox8");
			groupBox8.BackgroundImage = null;
			groupBox8.Font = null;
			groupBox8.Name = "groupBox8";
			groupBox8.TabStop = false;
			toolTip1.SetToolTip(groupBox8, resources.GetString("groupBox8.ToolTip"));
			vistaButton9.AccessibleDescription = null;
			vistaButton9.AccessibleName = null;
			resources.ApplyResources(vistaButton9, "vistaButton9");
			vistaButton9.BackColor = System.Drawing.Color.Maroon;
			vistaButton9.BackgroundImage = null;
			vistaButton9.BaseColor = System.Drawing.Color.White;
			vistaButton9.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton9.ButtonText = "7";
			vistaButton9.CornerRadius = 20;
			vistaButton9.Font = null;
			vistaButton9.ForeColor = System.Drawing.Color.Black;
			vistaButton9.Name = "vistaButton9";
			toolTip1.SetToolTip(vistaButton9, resources.GetString("vistaButton9.ToolTip"));
			vistaButton10.AccessibleDescription = null;
			vistaButton10.AccessibleName = null;
			resources.ApplyResources(vistaButton10, "vistaButton10");
			vistaButton10.BackColor = System.Drawing.Color.Maroon;
			vistaButton10.BackgroundImage = null;
			vistaButton10.BaseColor = System.Drawing.Color.White;
			vistaButton10.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton10.ButtonText = "6";
			vistaButton10.CornerRadius = 20;
			vistaButton10.Font = null;
			vistaButton10.ForeColor = System.Drawing.Color.Black;
			vistaButton10.Name = "vistaButton10";
			toolTip1.SetToolTip(vistaButton10, resources.GetString("vistaButton10.ToolTip"));
			vistaButton11.AccessibleDescription = null;
			vistaButton11.AccessibleName = null;
			resources.ApplyResources(vistaButton11, "vistaButton11");
			vistaButton11.BackColor = System.Drawing.Color.Maroon;
			vistaButton11.BackgroundImage = null;
			vistaButton11.BaseColor = System.Drawing.Color.White;
			vistaButton11.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton11.ButtonText = "5";
			vistaButton11.CornerRadius = 20;
			vistaButton11.Font = null;
			vistaButton11.ForeColor = System.Drawing.Color.Black;
			vistaButton11.Name = "vistaButton11";
			toolTip1.SetToolTip(vistaButton11, resources.GetString("vistaButton11.ToolTip"));
			vistaButton12.AccessibleDescription = null;
			vistaButton12.AccessibleName = null;
			resources.ApplyResources(vistaButton12, "vistaButton12");
			vistaButton12.BackColor = System.Drawing.Color.Maroon;
			vistaButton12.BackgroundImage = null;
			vistaButton12.BaseColor = System.Drawing.Color.White;
			vistaButton12.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton12.ButtonText = "4";
			vistaButton12.CornerRadius = 20;
			vistaButton12.Font = null;
			vistaButton12.ForeColor = System.Drawing.Color.Black;
			vistaButton12.Name = "vistaButton12";
			toolTip1.SetToolTip(vistaButton12, resources.GetString("vistaButton12.ToolTip"));
			vistaButton13.AccessibleDescription = null;
			vistaButton13.AccessibleName = null;
			resources.ApplyResources(vistaButton13, "vistaButton13");
			vistaButton13.BackColor = System.Drawing.Color.Maroon;
			vistaButton13.BackgroundImage = null;
			vistaButton13.BaseColor = System.Drawing.Color.White;
			vistaButton13.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton13.ButtonText = "2";
			vistaButton13.CornerRadius = 20;
			vistaButton13.Font = null;
			vistaButton13.ForeColor = System.Drawing.Color.Black;
			vistaButton13.Name = "vistaButton13";
			toolTip1.SetToolTip(vistaButton13, resources.GetString("vistaButton13.ToolTip"));
			vistaButton14.AccessibleDescription = null;
			vistaButton14.AccessibleName = null;
			resources.ApplyResources(vistaButton14, "vistaButton14");
			vistaButton14.BackColor = System.Drawing.Color.Maroon;
			vistaButton14.BackgroundImage = null;
			vistaButton14.BaseColor = System.Drawing.Color.White;
			vistaButton14.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton14.ButtonText = "3";
			vistaButton14.CornerRadius = 20;
			vistaButton14.Font = null;
			vistaButton14.ForeColor = System.Drawing.Color.Black;
			vistaButton14.Name = "vistaButton14";
			toolTip1.SetToolTip(vistaButton14, resources.GetString("vistaButton14.ToolTip"));
			vistaButton15.AccessibleDescription = null;
			vistaButton15.AccessibleName = null;
			resources.ApplyResources(vistaButton15, "vistaButton15");
			vistaButton15.BackColor = System.Drawing.Color.Maroon;
			vistaButton15.BackgroundImage = null;
			vistaButton15.BaseColor = System.Drawing.Color.White;
			vistaButton15.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton15.ButtonText = "8";
			vistaButton15.CornerRadius = 20;
			vistaButton15.Font = null;
			vistaButton15.ForeColor = System.Drawing.Color.Black;
			vistaButton15.Name = "vistaButton15";
			toolTip1.SetToolTip(vistaButton15, resources.GetString("vistaButton15.ToolTip"));
			vistaButton16.AccessibleDescription = null;
			vistaButton16.AccessibleName = null;
			resources.ApplyResources(vistaButton16, "vistaButton16");
			vistaButton16.BackColor = System.Drawing.Color.Maroon;
			vistaButton16.BackgroundImage = null;
			vistaButton16.BaseColor = System.Drawing.Color.White;
			vistaButton16.ButtonColor = System.Drawing.Color.LightGray;
			vistaButton16.ButtonText = "1";
			vistaButton16.CornerRadius = 20;
			vistaButton16.Font = null;
			vistaButton16.ForeColor = System.Drawing.Color.Black;
			vistaButton16.Name = "vistaButton16";
			toolTip1.SetToolTip(vistaButton16, resources.GetString("vistaButton16.ToolTip"));
			U26.AccessibleDescription = null;
			U26.AccessibleName = null;
			resources.ApplyResources(U26, "U26");
			U26.BackColor = System.Drawing.Color.Maroon;
			U26.BackgroundImage = null;
			U26.BaseColor = System.Drawing.Color.White;
			U26.ButtonColor = System.Drawing.Color.LightGray;
			U26.ButtonText = "2";
			U26.CornerRadius = 20;
			U26.Font = null;
			U26.ForeColor = System.Drawing.Color.Black;
			U26.Name = "U26";
			toolTip1.SetToolTip(U26, resources.GetString("U26.ToolTip"));
			U26.Click += new System.EventHandler(U26_Click);
			U26.MouseHover += new System.EventHandler(U26_MouseHover);
			U29.AccessibleDescription = null;
			U29.AccessibleName = null;
			resources.ApplyResources(U29, "U29");
			U29.BackColor = System.Drawing.Color.Maroon;
			U29.BackgroundImage = null;
			U29.BaseColor = System.Drawing.Color.White;
			U29.ButtonColor = System.Drawing.Color.LightGray;
			U29.ButtonText = "5";
			U29.CornerRadius = 20;
			U29.Font = null;
			U29.ForeColor = System.Drawing.Color.Black;
			U29.Name = "U29";
			toolTip1.SetToolTip(U29, resources.GetString("U29.ToolTip"));
			U29.Click += new System.EventHandler(U29_Click);
			U29.MouseHover += new System.EventHandler(U29_MouseHover);
			U32.AccessibleDescription = null;
			U32.AccessibleName = null;
			resources.ApplyResources(U32, "U32");
			U32.BackColor = System.Drawing.Color.Maroon;
			U32.BackgroundImage = null;
			U32.BaseColor = System.Drawing.Color.White;
			U32.ButtonColor = System.Drawing.Color.LightGray;
			U32.ButtonText = "8";
			U32.CornerRadius = 20;
			U32.Font = null;
			U32.ForeColor = System.Drawing.Color.Black;
			U32.Name = "U32";
			toolTip1.SetToolTip(U32, resources.GetString("U32.ToolTip"));
			U32.Click += new System.EventHandler(U32_Click);
			U32.MouseHover += new System.EventHandler(U32_MouseHover);
			U30.AccessibleDescription = null;
			U30.AccessibleName = null;
			resources.ApplyResources(U30, "U30");
			U30.BackColor = System.Drawing.Color.Maroon;
			U30.BackgroundImage = null;
			U30.BaseColor = System.Drawing.Color.White;
			U30.ButtonColor = System.Drawing.Color.LightGray;
			U30.ButtonText = "6";
			U30.CornerRadius = 20;
			U30.Font = null;
			U30.ForeColor = System.Drawing.Color.Black;
			U30.Name = "U30";
			toolTip1.SetToolTip(U30, resources.GetString("U30.ToolTip"));
			U30.Click += new System.EventHandler(U30_Click);
			U30.MouseHover += new System.EventHandler(U30_MouseHover);
			U28.AccessibleDescription = null;
			U28.AccessibleName = null;
			resources.ApplyResources(U28, "U28");
			U28.BackColor = System.Drawing.Color.Maroon;
			U28.BackgroundImage = null;
			U28.BaseColor = System.Drawing.Color.White;
			U28.ButtonColor = System.Drawing.Color.LightGray;
			U28.ButtonText = "4";
			U28.CornerRadius = 20;
			U28.Font = null;
			U28.ForeColor = System.Drawing.Color.Black;
			U28.Name = "U28";
			toolTip1.SetToolTip(U28, resources.GetString("U28.ToolTip"));
			U28.Click += new System.EventHandler(U28_Click);
			U28.MouseHover += new System.EventHandler(U28_MouseHover);
			U31.AccessibleDescription = null;
			U31.AccessibleName = null;
			resources.ApplyResources(U31, "U31");
			U31.BackColor = System.Drawing.Color.Maroon;
			U31.BackgroundImage = null;
			U31.BaseColor = System.Drawing.Color.White;
			U31.ButtonColor = System.Drawing.Color.LightGray;
			U31.ButtonText = "7";
			U31.CornerRadius = 20;
			U31.Font = null;
			U31.ForeColor = System.Drawing.Color.Black;
			U31.Name = "U31";
			toolTip1.SetToolTip(U31, resources.GetString("U31.ToolTip"));
			U31.Click += new System.EventHandler(U31_Click);
			U31.MouseHover += new System.EventHandler(U31_MouseHover);
			U24.AccessibleDescription = null;
			U24.AccessibleName = null;
			resources.ApplyResources(U24, "U24");
			U24.BackColor = System.Drawing.Color.Maroon;
			U24.BackgroundImage = null;
			U24.BaseColor = System.Drawing.Color.White;
			U24.ButtonColor = System.Drawing.Color.LightGray;
			U24.ButtonText = "8";
			U24.CornerRadius = 20;
			U24.Font = null;
			U24.ForeColor = System.Drawing.Color.Black;
			U24.Name = "U24";
			toolTip1.SetToolTip(U24, resources.GetString("U24.ToolTip"));
			U24.Click += new System.EventHandler(U24_Click);
			U24.MouseHover += new System.EventHandler(U24_MouseHover);
			U22.AccessibleDescription = null;
			U22.AccessibleName = null;
			resources.ApplyResources(U22, "U22");
			U22.BackColor = System.Drawing.Color.Maroon;
			U22.BackgroundImage = null;
			U22.BaseColor = System.Drawing.Color.White;
			U22.ButtonColor = System.Drawing.Color.LightGray;
			U22.ButtonText = "6";
			U22.CornerRadius = 20;
			U22.Font = null;
			U22.ForeColor = System.Drawing.Color.Black;
			U22.Name = "U22";
			toolTip1.SetToolTip(U22, resources.GetString("U22.ToolTip"));
			U22.Click += new System.EventHandler(U22_Click);
			U22.MouseHover += new System.EventHandler(U22_MouseHover);
			U27.AccessibleDescription = null;
			U27.AccessibleName = null;
			resources.ApplyResources(U27, "U27");
			U27.BackColor = System.Drawing.Color.Maroon;
			U27.BackgroundImage = null;
			U27.BaseColor = System.Drawing.Color.White;
			U27.ButtonColor = System.Drawing.Color.LightGray;
			U27.ButtonText = "3";
			U27.CornerRadius = 20;
			U27.Font = null;
			U27.ForeColor = System.Drawing.Color.Black;
			U27.Name = "U27";
			toolTip1.SetToolTip(U27, resources.GetString("U27.ToolTip"));
			U27.Click += new System.EventHandler(U27_Click);
			U27.MouseHover += new System.EventHandler(U27_MouseHover);
			U23.AccessibleDescription = null;
			U23.AccessibleName = null;
			resources.ApplyResources(U23, "U23");
			U23.BackColor = System.Drawing.Color.Maroon;
			U23.BackgroundImage = null;
			U23.BaseColor = System.Drawing.Color.White;
			U23.ButtonColor = System.Drawing.Color.LightGray;
			U23.ButtonText = "7";
			U23.CornerRadius = 20;
			U23.Font = null;
			U23.ForeColor = System.Drawing.Color.Black;
			U23.Name = "U23";
			toolTip1.SetToolTip(U23, resources.GetString("U23.ToolTip"));
			U23.Click += new System.EventHandler(U23_Click);
			U23.MouseHover += new System.EventHandler(U23_MouseHover);
			U9.AccessibleDescription = null;
			U9.AccessibleName = null;
			resources.ApplyResources(U9, "U9");
			U9.BackColor = System.Drawing.Color.Maroon;
			U9.BackgroundImage = null;
			U9.BaseColor = System.Drawing.Color.White;
			U9.ButtonColor = System.Drawing.Color.LightGray;
			U9.ButtonText = "1";
			U9.CornerRadius = 20;
			U9.Font = null;
			U9.ForeColor = System.Drawing.Color.Black;
			U9.Name = "U9";
			toolTip1.SetToolTip(U9, resources.GetString("U9.ToolTip"));
			U9.Click += new System.EventHandler(U9_Click);
			U9.MouseHover += new System.EventHandler(U9_MouseHover);
			U16.AccessibleDescription = null;
			U16.AccessibleName = null;
			resources.ApplyResources(U16, "U16");
			U16.BackColor = System.Drawing.Color.Maroon;
			U16.BackgroundImage = null;
			U16.BaseColor = System.Drawing.Color.White;
			U16.ButtonColor = System.Drawing.Color.LightGray;
			U16.ButtonText = "8";
			U16.CornerRadius = 20;
			U16.Font = null;
			U16.ForeColor = System.Drawing.Color.Black;
			U16.Name = "U16";
			toolTip1.SetToolTip(U16, resources.GetString("U16.ToolTip"));
			U16.Click += new System.EventHandler(U16_Click);
			U16.MouseHover += new System.EventHandler(U16_MouseHover);
			U11.AccessibleDescription = null;
			U11.AccessibleName = null;
			resources.ApplyResources(U11, "U11");
			U11.BackColor = System.Drawing.Color.Maroon;
			U11.BackgroundImage = null;
			U11.BaseColor = System.Drawing.Color.White;
			U11.ButtonColor = System.Drawing.Color.LightGray;
			U11.ButtonText = "3";
			U11.CornerRadius = 20;
			U11.Font = null;
			U11.ForeColor = System.Drawing.Color.Black;
			U11.Name = "U11";
			toolTip1.SetToolTip(U11, resources.GetString("U11.ToolTip"));
			U11.Click += new System.EventHandler(U11_Click);
			U11.MouseHover += new System.EventHandler(U11_MouseHover);
			U10.AccessibleDescription = null;
			U10.AccessibleName = null;
			resources.ApplyResources(U10, "U10");
			U10.BackColor = System.Drawing.Color.Maroon;
			U10.BackgroundImage = null;
			U10.BaseColor = System.Drawing.Color.White;
			U10.ButtonColor = System.Drawing.Color.LightGray;
			U10.ButtonText = "2";
			U10.CornerRadius = 20;
			U10.Font = null;
			U10.ForeColor = System.Drawing.Color.Black;
			U10.Name = "U10";
			toolTip1.SetToolTip(U10, resources.GetString("U10.ToolTip"));
			U10.Click += new System.EventHandler(U10_Click);
			U10.MouseHover += new System.EventHandler(U10_MouseHover);
			U12.AccessibleDescription = null;
			U12.AccessibleName = null;
			resources.ApplyResources(U12, "U12");
			U12.BackColor = System.Drawing.Color.Maroon;
			U12.BackgroundImage = null;
			U12.BaseColor = System.Drawing.Color.White;
			U12.ButtonColor = System.Drawing.Color.LightGray;
			U12.ButtonText = "4";
			U12.CornerRadius = 20;
			U12.Font = null;
			U12.ForeColor = System.Drawing.Color.Black;
			U12.Name = "U12";
			toolTip1.SetToolTip(U12, resources.GetString("U12.ToolTip"));
			U12.Click += new System.EventHandler(U12_Click);
			U12.MouseHover += new System.EventHandler(U12_MouseHover);
			U13.AccessibleDescription = null;
			U13.AccessibleName = null;
			resources.ApplyResources(U13, "U13");
			U13.BackColor = System.Drawing.Color.Maroon;
			U13.BackgroundImage = null;
			U13.BaseColor = System.Drawing.Color.White;
			U13.ButtonColor = System.Drawing.Color.LightGray;
			U13.ButtonText = "5";
			U13.CornerRadius = 20;
			U13.Font = null;
			U13.ForeColor = System.Drawing.Color.Black;
			U13.Name = "U13";
			toolTip1.SetToolTip(U13, resources.GetString("U13.ToolTip"));
			U13.Click += new System.EventHandler(U13_Click);
			U13.MouseHover += new System.EventHandler(U13_MouseHover);
			U14.AccessibleDescription = null;
			U14.AccessibleName = null;
			resources.ApplyResources(U14, "U14");
			U14.BackColor = System.Drawing.Color.Maroon;
			U14.BackgroundImage = null;
			U14.BaseColor = System.Drawing.Color.White;
			U14.ButtonColor = System.Drawing.Color.LightGray;
			U14.ButtonText = "6";
			U14.CornerRadius = 20;
			U14.Font = null;
			U14.ForeColor = System.Drawing.Color.Black;
			U14.Name = "U14";
			toolTip1.SetToolTip(U14, resources.GetString("U14.ToolTip"));
			U14.Click += new System.EventHandler(U14_Click);
			U14.MouseHover += new System.EventHandler(U14_MouseHover);
			U15.AccessibleDescription = null;
			U15.AccessibleName = null;
			resources.ApplyResources(U15, "U15");
			U15.BackColor = System.Drawing.Color.Maroon;
			U15.BackgroundImage = null;
			U15.BaseColor = System.Drawing.Color.White;
			U15.ButtonColor = System.Drawing.Color.LightGray;
			U15.ButtonText = "7";
			U15.CornerRadius = 20;
			U15.Font = null;
			U15.ForeColor = System.Drawing.Color.Black;
			U15.Name = "U15";
			toolTip1.SetToolTip(U15, resources.GetString("U15.ToolTip"));
			U15.Click += new System.EventHandler(U15_Click);
			U15.MouseHover += new System.EventHandler(U15_MouseHover);
			U1.AccessibleDescription = null;
			U1.AccessibleName = null;
			resources.ApplyResources(U1, "U1");
			U1.BackColor = System.Drawing.Color.Maroon;
			U1.BackgroundImage = null;
			U1.BaseColor = System.Drawing.Color.White;
			U1.ButtonColor = System.Drawing.Color.LightGray;
			U1.ButtonText = "1";
			U1.CornerRadius = 20;
			U1.Font = null;
			U1.ForeColor = System.Drawing.Color.Black;
			U1.Name = "U1";
			toolTip1.SetToolTip(U1, resources.GetString("U1.ToolTip"));
			U1.Click += new System.EventHandler(U1_Click);
			U1.MouseHover += new System.EventHandler(U1_MouseHover);
			U8.AccessibleDescription = null;
			U8.AccessibleName = null;
			resources.ApplyResources(U8, "U8");
			U8.BackColor = System.Drawing.Color.Maroon;
			U8.BackgroundImage = null;
			U8.BaseColor = System.Drawing.Color.White;
			U8.ButtonColor = System.Drawing.Color.LightGray;
			U8.ButtonText = "8";
			U8.CornerRadius = 20;
			U8.Font = null;
			U8.ForeColor = System.Drawing.Color.Black;
			U8.Name = "U8";
			toolTip1.SetToolTip(U8, resources.GetString("U8.ToolTip"));
			U8.Click += new System.EventHandler(U8_Click);
			U8.MouseHover += new System.EventHandler(U8_MouseHover);
			U25.AccessibleDescription = null;
			U25.AccessibleName = null;
			resources.ApplyResources(U25, "U25");
			U25.BackColor = System.Drawing.Color.Maroon;
			U25.BackgroundImage = null;
			U25.BaseColor = System.Drawing.Color.White;
			U25.ButtonColor = System.Drawing.Color.LightGray;
			U25.ButtonText = "1";
			U25.CornerRadius = 20;
			U25.Font = null;
			U25.ForeColor = System.Drawing.Color.Black;
			U25.Name = "U25";
			toolTip1.SetToolTip(U25, resources.GetString("U25.ToolTip"));
			U25.Click += new System.EventHandler(U25_Click);
			U25.MouseHover += new System.EventHandler(U25_MouseHover);
			U3.AccessibleDescription = null;
			U3.AccessibleName = null;
			resources.ApplyResources(U3, "U3");
			U3.BackColor = System.Drawing.Color.Maroon;
			U3.BackgroundImage = null;
			U3.BaseColor = System.Drawing.Color.White;
			U3.ButtonColor = System.Drawing.Color.LightGray;
			U3.ButtonText = "3";
			U3.CornerRadius = 20;
			U3.Font = null;
			U3.ForeColor = System.Drawing.Color.Black;
			U3.Name = "U3";
			toolTip1.SetToolTip(U3, resources.GetString("U3.ToolTip"));
			U3.Click += new System.EventHandler(U3_Click);
			U3.MouseHover += new System.EventHandler(U3_MouseHover);
			U2.AccessibleDescription = null;
			U2.AccessibleName = null;
			resources.ApplyResources(U2, "U2");
			U2.BackColor = System.Drawing.Color.Maroon;
			U2.BackgroundImage = null;
			U2.BaseColor = System.Drawing.Color.White;
			U2.ButtonColor = System.Drawing.Color.LightGray;
			U2.ButtonText = "2";
			U2.CornerRadius = 20;
			U2.Font = null;
			U2.ForeColor = System.Drawing.Color.Black;
			U2.Name = "U2";
			toolTip1.SetToolTip(U2, resources.GetString("U2.ToolTip"));
			U2.Click += new System.EventHandler(U2_Click);
			U2.MouseHover += new System.EventHandler(U2_MouseHover);
			U18.AccessibleDescription = null;
			U18.AccessibleName = null;
			resources.ApplyResources(U18, "U18");
			U18.BackColor = System.Drawing.Color.Maroon;
			U18.BackgroundImage = null;
			U18.BaseColor = System.Drawing.Color.White;
			U18.ButtonColor = System.Drawing.Color.LightGray;
			U18.ButtonText = "2";
			U18.CornerRadius = 20;
			U18.Font = null;
			U18.ForeColor = System.Drawing.Color.Black;
			U18.Name = "U18";
			toolTip1.SetToolTip(U18, resources.GetString("U18.ToolTip"));
			U18.Click += new System.EventHandler(U18_Click);
			U18.MouseHover += new System.EventHandler(U18_MouseHover);
			U17.AccessibleDescription = null;
			U17.AccessibleName = null;
			resources.ApplyResources(U17, "U17");
			U17.BackColor = System.Drawing.Color.Maroon;
			U17.BackgroundImage = null;
			U17.BaseColor = System.Drawing.Color.White;
			U17.ButtonColor = System.Drawing.Color.LightGray;
			U17.ButtonText = "1";
			U17.CornerRadius = 20;
			U17.Font = null;
			U17.ForeColor = System.Drawing.Color.Black;
			U17.Name = "U17";
			toolTip1.SetToolTip(U17, resources.GetString("U17.ToolTip"));
			U17.Click += new System.EventHandler(U17_Click);
			U17.MouseHover += new System.EventHandler(U17_MouseHover);
			U4.AccessibleDescription = null;
			U4.AccessibleName = null;
			resources.ApplyResources(U4, "U4");
			U4.BackColor = System.Drawing.Color.Maroon;
			U4.BackgroundImage = null;
			U4.BaseColor = System.Drawing.Color.White;
			U4.ButtonColor = System.Drawing.Color.LightGray;
			U4.ButtonText = "4";
			U4.CornerRadius = 20;
			U4.Font = null;
			U4.ForeColor = System.Drawing.Color.Black;
			U4.Name = "U4";
			toolTip1.SetToolTip(U4, resources.GetString("U4.ToolTip"));
			U4.Click += new System.EventHandler(U4_Click);
			U4.MouseHover += new System.EventHandler(U4_MouseHover);
			U5.AccessibleDescription = null;
			U5.AccessibleName = null;
			resources.ApplyResources(U5, "U5");
			U5.BackColor = System.Drawing.Color.Maroon;
			U5.BackgroundImage = null;
			U5.BaseColor = System.Drawing.Color.White;
			U5.ButtonColor = System.Drawing.Color.LightGray;
			U5.ButtonText = "5";
			U5.CornerRadius = 20;
			U5.Font = null;
			U5.ForeColor = System.Drawing.Color.Black;
			U5.Name = "U5";
			toolTip1.SetToolTip(U5, resources.GetString("U5.ToolTip"));
			U5.Click += new System.EventHandler(U5_Click);
			U5.MouseHover += new System.EventHandler(U5_MouseHover);
			U6.AccessibleDescription = null;
			U6.AccessibleName = null;
			resources.ApplyResources(U6, "U6");
			U6.BackColor = System.Drawing.Color.Maroon;
			U6.BackgroundImage = null;
			U6.BaseColor = System.Drawing.Color.White;
			U6.ButtonColor = System.Drawing.Color.LightGray;
			U6.ButtonText = "6";
			U6.CornerRadius = 20;
			U6.Font = null;
			U6.ForeColor = System.Drawing.Color.Black;
			U6.Name = "U6";
			toolTip1.SetToolTip(U6, resources.GetString("U6.ToolTip"));
			U6.Click += new System.EventHandler(U6_Click);
			U6.MouseHover += new System.EventHandler(U6_MouseHover);
			U7.AccessibleDescription = null;
			U7.AccessibleName = null;
			resources.ApplyResources(U7, "U7");
			U7.BackColor = System.Drawing.Color.Maroon;
			U7.BackgroundImage = null;
			U7.BaseColor = System.Drawing.Color.White;
			U7.ButtonColor = System.Drawing.Color.LightGray;
			U7.ButtonText = "7";
			U7.CornerRadius = 20;
			U7.Font = null;
			U7.ForeColor = System.Drawing.Color.Black;
			U7.Name = "U7";
			toolTip1.SetToolTip(U7, resources.GetString("U7.ToolTip"));
			U7.Click += new System.EventHandler(U7_Click);
			U7.MouseHover += new System.EventHandler(U7_MouseHover);
			U19.AccessibleDescription = null;
			U19.AccessibleName = null;
			resources.ApplyResources(U19, "U19");
			U19.BackColor = System.Drawing.Color.Maroon;
			U19.BackgroundImage = null;
			U19.BaseColor = System.Drawing.Color.White;
			U19.ButtonColor = System.Drawing.Color.LightGray;
			U19.ButtonText = "3";
			U19.CornerRadius = 20;
			U19.Font = null;
			U19.ForeColor = System.Drawing.Color.Black;
			U19.Name = "U19";
			toolTip1.SetToolTip(U19, resources.GetString("U19.ToolTip"));
			U19.Click += new System.EventHandler(U19_Click);
			U19.MouseHover += new System.EventHandler(U19_MouseHover);
			U21.AccessibleDescription = null;
			U21.AccessibleName = null;
			resources.ApplyResources(U21, "U21");
			U21.BackColor = System.Drawing.Color.Maroon;
			U21.BackgroundImage = null;
			U21.BaseColor = System.Drawing.Color.White;
			U21.ButtonColor = System.Drawing.Color.LightGray;
			U21.ButtonText = "5";
			U21.CornerRadius = 20;
			U21.Font = null;
			U21.ForeColor = System.Drawing.Color.Black;
			U21.Name = "U21";
			toolTip1.SetToolTip(U21, resources.GetString("U21.ToolTip"));
			U21.Click += new System.EventHandler(U21_Click);
			U21.MouseHover += new System.EventHandler(U21_MouseHover);
			U20.AccessibleDescription = null;
			U20.AccessibleName = null;
			resources.ApplyResources(U20, "U20");
			U20.BackColor = System.Drawing.Color.Maroon;
			U20.BackgroundImage = null;
			U20.BaseColor = System.Drawing.Color.White;
			U20.ButtonColor = System.Drawing.Color.LightGray;
			U20.ButtonText = "4";
			U20.CornerRadius = 20;
			U20.Font = null;
			U20.ForeColor = System.Drawing.Color.Black;
			U20.Name = "U20";
			toolTip1.SetToolTip(U20, resources.GetString("U20.ToolTip"));
			U20.Click += new System.EventHandler(U20_Click);
			U20.MouseHover += new System.EventHandler(U20_MouseHover);
			panel2.AccessibleDescription = null;
			panel2.AccessibleName = null;
			resources.ApplyResources(panel2, "panel2");
			panel2.BackColor = System.Drawing.Color.Transparent;
			panel2.BackgroundImage = null;
			panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			panel2.Controls.Add(this.label22);
			panel2.Controls.Add(this.label23);
			panel2.Controls.Add(this.label24);
			panel2.Controls.Add(numericUpDown13);
			panel2.Controls.Add(this.label18);
			panel2.Controls.Add(tableLayoutPanel1);
			panel2.Controls.Add(this.label2);
			panel2.Controls.Add(numericUpDown14);
			panel2.Controls.Add(this.label4);
			panel2.Controls.Add(tableLayoutPanel2);
			panel2.Controls.Add(this.label25);
			panel2.Controls.Add(this.label26);
			panel2.Font = null;
			panel2.Name = "panel2";
			toolTip1.SetToolTip(panel2, resources.GetString("panel2.ToolTip"));
			this.label22.AccessibleDescription = null;
			this.label22.AccessibleName = null;
			resources.ApplyResources(this.label22, "label22");
			this.label22.Name = "label22";
			toolTip1.SetToolTip(this.label22, resources.GetString("label22.ToolTip"));
			this.label23.AccessibleDescription = null;
			this.label23.AccessibleName = null;
			resources.ApplyResources(this.label23, "label23");
			this.label23.Name = "label23";
			toolTip1.SetToolTip(this.label23, resources.GetString("label23.ToolTip"));
			this.label24.AccessibleDescription = null;
			this.label24.AccessibleName = null;
			resources.ApplyResources(this.label24, "label24");
			this.label24.Name = "label24";
			toolTip1.SetToolTip(this.label24, resources.GetString("label24.ToolTip"));
			numericUpDown13.AccessibleDescription = null;
			numericUpDown13.AccessibleName = null;
			resources.ApplyResources(numericUpDown13, "numericUpDown13");
			numericUpDown13.DecimalPlaces = 2;
			numericUpDown13.Font = null;
			numericUpDown13.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown13.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown13.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown13.Name = "numericUpDown13";
			toolTip1.SetToolTip(numericUpDown13, resources.GetString("numericUpDown13.ToolTip"));
			this.label18.AccessibleDescription = null;
			this.label18.AccessibleName = null;
			resources.ApplyResources(this.label18, "label18");
			this.label18.Name = "label18";
			toolTip1.SetToolTip(this.label18, resources.GetString("label18.ToolTip"));
			tableLayoutPanel1.AccessibleDescription = null;
			tableLayoutPanel1.AccessibleName = null;
			resources.ApplyResources(tableLayoutPanel1, "tableLayoutPanel1");
			tableLayoutPanel1.BackColor = System.Drawing.Color.WhiteSmoke;
			tableLayoutPanel1.BackgroundImage = null;
			tableLayoutPanel1.Controls.Add(numericUpDown1, 2, 1);
			tableLayoutPanel1.Controls.Add(this.label19, 0, 0);
			tableLayoutPanel1.Controls.Add(this.label20, 2, 0);
			tableLayoutPanel1.Controls.Add(numericUpDown5, 1, 2);
			tableLayoutPanel1.Controls.Add(this.label21, 1, 0);
			tableLayoutPanel1.Controls.Add(numericUpDown6, 0, 2);
			tableLayoutPanel1.Controls.Add(numericUpDown2, 1, 1);
			tableLayoutPanel1.Controls.Add(numericUpDown4, 2, 2);
			tableLayoutPanel1.Controls.Add(numericUpDown3, 0, 1);
			tableLayoutPanel1.Font = null;
			tableLayoutPanel1.Name = "tableLayoutPanel1";
			toolTip1.SetToolTip(tableLayoutPanel1, resources.GetString("tableLayoutPanel1.ToolTip"));
			numericUpDown1.AccessibleDescription = null;
			numericUpDown1.AccessibleName = null;
			resources.ApplyResources(numericUpDown1, "numericUpDown1");
			numericUpDown1.DecimalPlaces = 2;
			numericUpDown1.Font = null;
			numericUpDown1.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown1.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown1.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown1.Name = "numericUpDown1";
			toolTip1.SetToolTip(numericUpDown1, resources.GetString("numericUpDown1.ToolTip"));
			this.label19.AccessibleDescription = null;
			this.label19.AccessibleName = null;
			resources.ApplyResources(this.label19, "label19");
			this.label19.Font = null;
			this.label19.Name = "label19";
			toolTip1.SetToolTip(this.label19, resources.GetString("label19.ToolTip"));
			this.label20.AccessibleDescription = null;
			this.label20.AccessibleName = null;
			resources.ApplyResources(this.label20, "label20");
			this.label20.Font = null;
			this.label20.Name = "label20";
			toolTip1.SetToolTip(this.label20, resources.GetString("label20.ToolTip"));
			numericUpDown5.AccessibleDescription = null;
			numericUpDown5.AccessibleName = null;
			resources.ApplyResources(numericUpDown5, "numericUpDown5");
			numericUpDown5.DecimalPlaces = 2;
			numericUpDown5.Font = null;
			numericUpDown5.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown5.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown5.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown5.Name = "numericUpDown5";
			toolTip1.SetToolTip(numericUpDown5, resources.GetString("numericUpDown5.ToolTip"));
			this.label21.AccessibleDescription = null;
			this.label21.AccessibleName = null;
			resources.ApplyResources(this.label21, "label21");
			this.label21.Font = null;
			this.label21.Name = "label21";
			toolTip1.SetToolTip(this.label21, resources.GetString("label21.ToolTip"));
			numericUpDown6.AccessibleDescription = null;
			numericUpDown6.AccessibleName = null;
			resources.ApplyResources(numericUpDown6, "numericUpDown6");
			numericUpDown6.Font = null;
			numericUpDown6.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown6.Name = "numericUpDown6";
			toolTip1.SetToolTip(numericUpDown6, resources.GetString("numericUpDown6.ToolTip"));
			numericUpDown2.AccessibleDescription = null;
			numericUpDown2.AccessibleName = null;
			resources.ApplyResources(numericUpDown2, "numericUpDown2");
			numericUpDown2.DecimalPlaces = 2;
			numericUpDown2.Font = null;
			numericUpDown2.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown2.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown2.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown2.Name = "numericUpDown2";
			toolTip1.SetToolTip(numericUpDown2, resources.GetString("numericUpDown2.ToolTip"));
			numericUpDown4.AccessibleDescription = null;
			numericUpDown4.AccessibleName = null;
			resources.ApplyResources(numericUpDown4, "numericUpDown4");
			numericUpDown4.DecimalPlaces = 2;
			numericUpDown4.Font = null;
			numericUpDown4.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown4.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown4.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown4.Name = "numericUpDown4";
			toolTip1.SetToolTip(numericUpDown4, resources.GetString("numericUpDown4.ToolTip"));
			numericUpDown3.AccessibleDescription = null;
			numericUpDown3.AccessibleName = null;
			resources.ApplyResources(numericUpDown3, "numericUpDown3");
			numericUpDown3.Font = null;
			numericUpDown3.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown3.Name = "numericUpDown3";
			toolTip1.SetToolTip(numericUpDown3, resources.GetString("numericUpDown3.ToolTip"));
			this.label2.AccessibleDescription = null;
			this.label2.AccessibleName = null;
			resources.ApplyResources(this.label2, "label2");
			this.label2.Name = "label2";
			toolTip1.SetToolTip(this.label2, resources.GetString("label2.ToolTip"));
			numericUpDown14.AccessibleDescription = null;
			numericUpDown14.AccessibleName = null;
			resources.ApplyResources(numericUpDown14, "numericUpDown14");
			numericUpDown14.DecimalPlaces = 2;
			numericUpDown14.Font = null;
			numericUpDown14.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown14.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown14.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown14.Name = "numericUpDown14";
			toolTip1.SetToolTip(numericUpDown14, resources.GetString("numericUpDown14.ToolTip"));
			this.label4.AccessibleDescription = null;
			this.label4.AccessibleName = null;
			resources.ApplyResources(this.label4, "label4");
			this.label4.Name = "label4";
			toolTip1.SetToolTip(this.label4, resources.GetString("label4.ToolTip"));
			tableLayoutPanel2.AccessibleDescription = null;
			tableLayoutPanel2.AccessibleName = null;
			resources.ApplyResources(tableLayoutPanel2, "tableLayoutPanel2");
			tableLayoutPanel2.BackColor = System.Drawing.Color.WhiteSmoke;
			tableLayoutPanel2.BackgroundImage = null;
			tableLayoutPanel2.Controls.Add(this.label5, 0, 0);
			tableLayoutPanel2.Controls.Add(this.label16, 2, 0);
			tableLayoutPanel2.Controls.Add(this.label17, 1, 0);
			tableLayoutPanel2.Controls.Add(numericUpDown7, 2, 1);
			tableLayoutPanel2.Controls.Add(numericUpDown8, 1, 1);
			tableLayoutPanel2.Controls.Add(numericUpDown11, 1, 2);
			tableLayoutPanel2.Controls.Add(numericUpDown12, 0, 2);
			tableLayoutPanel2.Controls.Add(numericUpDown9, 0, 1);
			tableLayoutPanel2.Controls.Add(numericUpDown10, 2, 2);
			tableLayoutPanel2.Font = null;
			tableLayoutPanel2.Name = "tableLayoutPanel2";
			toolTip1.SetToolTip(tableLayoutPanel2, resources.GetString("tableLayoutPanel2.ToolTip"));
			this.label5.AccessibleDescription = null;
			this.label5.AccessibleName = null;
			resources.ApplyResources(this.label5, "label5");
			this.label5.Font = null;
			this.label5.Name = "label5";
			toolTip1.SetToolTip(this.label5, resources.GetString("label5.ToolTip"));
			this.label16.AccessibleDescription = null;
			this.label16.AccessibleName = null;
			resources.ApplyResources(this.label16, "label16");
			this.label16.Font = null;
			this.label16.Name = "label16";
			toolTip1.SetToolTip(this.label16, resources.GetString("label16.ToolTip"));
			this.label17.AccessibleDescription = null;
			this.label17.AccessibleName = null;
			resources.ApplyResources(this.label17, "label17");
			this.label17.Font = null;
			this.label17.Name = "label17";
			toolTip1.SetToolTip(this.label17, resources.GetString("label17.ToolTip"));
			numericUpDown7.AccessibleDescription = null;
			numericUpDown7.AccessibleName = null;
			resources.ApplyResources(numericUpDown7, "numericUpDown7");
			numericUpDown7.DecimalPlaces = 2;
			numericUpDown7.Font = null;
			numericUpDown7.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown7.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown7.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown7.Name = "numericUpDown7";
			toolTip1.SetToolTip(numericUpDown7, resources.GetString("numericUpDown7.ToolTip"));
			numericUpDown8.AccessibleDescription = null;
			numericUpDown8.AccessibleName = null;
			resources.ApplyResources(numericUpDown8, "numericUpDown8");
			numericUpDown8.DecimalPlaces = 2;
			numericUpDown8.Font = null;
			numericUpDown8.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown8.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown8.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown8.Name = "numericUpDown8";
			toolTip1.SetToolTip(numericUpDown8, resources.GetString("numericUpDown8.ToolTip"));
			numericUpDown11.AccessibleDescription = null;
			numericUpDown11.AccessibleName = null;
			resources.ApplyResources(numericUpDown11, "numericUpDown11");
			numericUpDown11.DecimalPlaces = 2;
			numericUpDown11.Font = null;
			numericUpDown11.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown11.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown11.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown11.Name = "numericUpDown11";
			toolTip1.SetToolTip(numericUpDown11, resources.GetString("numericUpDown11.ToolTip"));
			numericUpDown12.AccessibleDescription = null;
			numericUpDown12.AccessibleName = null;
			resources.ApplyResources(numericUpDown12, "numericUpDown12");
			numericUpDown12.Font = null;
			numericUpDown12.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown12.Name = "numericUpDown12";
			toolTip1.SetToolTip(numericUpDown12, resources.GetString("numericUpDown12.ToolTip"));
			numericUpDown9.AccessibleDescription = null;
			numericUpDown9.AccessibleName = null;
			resources.ApplyResources(numericUpDown9, "numericUpDown9");
			numericUpDown9.Font = null;
			numericUpDown9.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown9.Name = "numericUpDown9";
			toolTip1.SetToolTip(numericUpDown9, resources.GetString("numericUpDown9.ToolTip"));
			numericUpDown10.AccessibleDescription = null;
			numericUpDown10.AccessibleName = null;
			resources.ApplyResources(numericUpDown10, "numericUpDown10");
			numericUpDown10.DecimalPlaces = 2;
			numericUpDown10.Font = null;
			numericUpDown10.Increment = new decimal(new int[4] { 25, 0, 0, 131072 });
			numericUpDown10.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			numericUpDown10.Minimum = new decimal(new int[4] { 25, 0, 0, -2147483648 });
			numericUpDown10.Name = "numericUpDown10";
			toolTip1.SetToolTip(numericUpDown10, resources.GetString("numericUpDown10.ToolTip"));
			this.label25.AccessibleDescription = null;
			this.label25.AccessibleName = null;
			resources.ApplyResources(this.label25, "label25");
			this.label25.Name = "label25";
			toolTip1.SetToolTip(this.label25, resources.GetString("label25.ToolTip"));
			this.label26.AccessibleDescription = null;
			this.label26.AccessibleName = null;
			resources.ApplyResources(this.label26, "label26");
			this.label26.Name = "label26";
			toolTip1.SetToolTip(this.label26, resources.GetString("label26.ToolTip"));
			checkBox3.AccessibleDescription = null;
			checkBox3.AccessibleName = null;
			resources.ApplyResources(checkBox3, "checkBox3");
			checkBox3.BackColor = System.Drawing.Color.Transparent;
			checkBox3.BackgroundImage = null;
			checkBox3.Name = "checkBox3";
			toolTip1.SetToolTip(checkBox3, resources.GetString("checkBox3.ToolTip"));
			checkBox3.UseVisualStyleBackColor = false;
			checkBox3.CheckedChanged += new System.EventHandler(checkBox3_CheckedChanged);
			sqlSelectCommand1.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[35]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[14]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData"),
					new System.Data.Common.DataColumnMapping("Powred", "Powred"),
					new System.Data.Common.DataColumnMapping("ClinicType", "ClinicType"),
					new System.Data.Common.DataColumnMapping("EyeClinic", "EyeClinic"),
					new System.Data.Common.DataColumnMapping("FemaleClinic", "FemaleClinic"),
					new System.Data.Common.DataColumnMapping("NaturalClinic", "NaturalClinic")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			groupBox12.AccessibleDescription = null;
			groupBox12.AccessibleName = null;
			resources.ApplyResources(groupBox12, "groupBox12");
			groupBox12.BackColor = System.Drawing.Color.Transparent;
			groupBox12.BackgroundImage = null;
			groupBox12.Controls.Add(label8);
			groupBox12.Controls.Add(textBox4);
			groupBox12.Controls.Add(floatText4);
			groupBox12.Controls.Add(label9);
			groupBox12.Controls.Add(floatText3);
			groupBox12.Controls.Add(label10);
			groupBox12.Controls.Add(floatText2);
			groupBox12.Controls.Add(label11);
			groupBox12.Controls.Add(label12);
			groupBox12.Controls.Add(Head);
			groupBox12.Controls.Add(Length);
			groupBox12.Controls.Add(label13);
			groupBox12.Controls.Add(label14);
			groupBox12.Controls.Add(label15);
			groupBox12.Controls.Add(label16);
			groupBox12.Controls.Add(YAge);
			groupBox12.Controls.Add(Weight);
			groupBox12.Controls.Add(MAge);
			groupBox12.Controls.Add(textBox8);
			groupBox12.Controls.Add(label17);
			groupBox12.Controls.Add(label18);
			groupBox12.Controls.Add(label19);
			groupBox12.Controls.Add(label20);
			groupBox12.Controls.Add(label21);
			groupBox12.Name = "groupBox12";
			groupBox12.TabStop = false;
			toolTip1.SetToolTip(groupBox12, resources.GetString("groupBox12.ToolTip"));
			textBox4.AccessibleDescription = null;
			textBox4.AccessibleName = null;
			resources.ApplyResources(textBox4, "textBox4");
			textBox4.BackgroundImage = null;
			textBox4.Font = null;
			textBox4.Name = "textBox4";
			toolTip1.SetToolTip(textBox4, resources.GetString("textBox4.ToolTip"));
			floatText4.AccessibleDescription = null;
			floatText4.AccessibleName = null;
			resources.ApplyResources(floatText4, "floatText4");
			floatText4.BackgroundImage = null;
			floatText4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText4.Font = null;
			floatText4.Name = "floatText4";
			toolTip1.SetToolTip(floatText4, resources.GetString("floatText4.ToolTip"));
			floatText3.AccessibleDescription = null;
			floatText3.AccessibleName = null;
			resources.ApplyResources(floatText3, "floatText3");
			floatText3.BackgroundImage = null;
			floatText3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText3.Font = null;
			floatText3.Name = "floatText3";
			toolTip1.SetToolTip(floatText3, resources.GetString("floatText3.ToolTip"));
			floatText2.AccessibleDescription = null;
			floatText2.AccessibleName = null;
			resources.ApplyResources(floatText2, "floatText2");
			floatText2.BackgroundImage = null;
			floatText2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText2.Font = null;
			floatText2.Name = "floatText2";
			toolTip1.SetToolTip(floatText2, resources.GetString("floatText2.ToolTip"));
			Head.AccessibleDescription = null;
			Head.AccessibleName = null;
			resources.ApplyResources(Head, "Head");
			Head.BackgroundImage = null;
			Head.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			Head.Font = null;
			Head.Name = "Head";
			toolTip1.SetToolTip(Head, resources.GetString("Head.ToolTip"));
			Length.AccessibleDescription = null;
			Length.AccessibleName = null;
			resources.ApplyResources(Length, "Length");
			Length.BackgroundImage = null;
			Length.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			Length.Font = null;
			Length.Name = "Length";
			toolTip1.SetToolTip(Length, resources.GetString("Length.ToolTip"));
			YAge.AccessibleDescription = null;
			YAge.AccessibleName = null;
			resources.ApplyResources(YAge, "YAge");
			YAge.BackgroundImage = null;
			YAge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			YAge.Font = null;
			YAge.Name = "YAge";
			toolTip1.SetToolTip(YAge, resources.GetString("YAge.ToolTip"));
			Weight.AccessibleDescription = null;
			Weight.AccessibleName = null;
			resources.ApplyResources(Weight, "Weight");
			Weight.BackgroundImage = null;
			Weight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			Weight.Font = null;
			Weight.Name = "Weight";
			toolTip1.SetToolTip(Weight, resources.GetString("Weight.ToolTip"));
			MAge.AccessibleDescription = null;
			MAge.AccessibleName = null;
			resources.ApplyResources(MAge, "MAge");
			MAge.BackgroundImage = null;
			MAge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			MAge.Font = null;
			MAge.Name = "MAge";
			toolTip1.SetToolTip(MAge, resources.GetString("MAge.ToolTip"));
			textBox8.AccessibleDescription = null;
			textBox8.AccessibleName = null;
			resources.ApplyResources(textBox8, "textBox8");
			textBox8.BackColor = System.Drawing.Color.White;
			textBox8.BackgroundImage = null;
			textBox8.Font = null;
			textBox8.ForeColor = System.Drawing.Color.Black;
			textBox8.Name = "textBox8";
			toolTip1.SetToolTip(textBox8, resources.GetString("textBox8.ToolTip"));
			button7.AccessibleDescription = null;
			button7.AccessibleName = null;
			resources.ApplyResources(button7, "button7");
			button7.BackColor = System.Drawing.Color.Gainsboro;
			button7.BackgroundImage = null;
			button7.Name = "button7";
			toolTip1.SetToolTip(button7, resources.GetString("button7.ToolTip"));
			button7.UseVisualStyleBackColor = false;
			button7.Click += new System.EventHandler(button7_Click);
			groupBox9.AccessibleDescription = null;
			groupBox9.AccessibleName = null;
			resources.ApplyResources(groupBox9, "groupBox9");
			groupBox9.BackColor = System.Drawing.Color.Transparent;
			groupBox9.BackgroundImage = null;
			groupBox9.Controls.Add(button22);
			groupBox9.Controls.Add(button18);
			groupBox9.Controls.Add(button7);
			groupBox9.Controls.Add(button5);
			groupBox9.Controls.Add(button6);
			groupBox9.Controls.Add(button4);
			groupBox9.Controls.Add(button3);
			groupBox9.Controls.Add(button1);
			groupBox9.Font = null;
			groupBox9.Name = "groupBox9";
			groupBox9.TabStop = false;
			toolTip1.SetToolTip(groupBox9, resources.GetString("groupBox9.ToolTip"));
			button22.AccessibleDescription = null;
			button22.AccessibleName = null;
			resources.ApplyResources(button22, "button22");
			button22.BackColor = System.Drawing.Color.Gainsboro;
			button22.BackgroundImage = null;
			button22.Name = "button22";
			toolTip1.SetToolTip(button22, resources.GetString("button22.ToolTip"));
			button22.UseVisualStyleBackColor = false;
			button22.Click += new System.EventHandler(button22_Click);
			button18.AccessibleDescription = null;
			button18.AccessibleName = null;
			resources.ApplyResources(button18, "button18");
			button18.BackColor = System.Drawing.Color.Gainsboro;
			button18.BackgroundImage = null;
			button18.Name = "button18";
			toolTip1.SetToolTip(button18, resources.GetString("button18.ToolTip"));
			button18.UseVisualStyleBackColor = false;
			button18.Click += new System.EventHandler(button18_Click);
			button16.AccessibleDescription = null;
			button16.AccessibleName = null;
			resources.ApplyResources(button16, "button16");
			button16.BackColor = System.Drawing.Color.Gainsboro;
			button16.BackgroundImage = null;
			button16.Name = "button16";
			toolTip1.SetToolTip(button16, resources.GetString("button16.ToolTip"));
			button16.UseVisualStyleBackColor = false;
			button16.Click += new System.EventHandler(button16_Click);
			groupBox21.AccessibleDescription = null;
			groupBox21.AccessibleName = null;
			resources.ApplyResources(groupBox21, "groupBox21");
			groupBox21.BackColor = System.Drawing.Color.Transparent;
			groupBox21.BackgroundImage = null;
			groupBox21.Controls.Add(textBox3);
			groupBox21.Controls.Add(textBox5);
			groupBox21.Controls.Add(label23);
			groupBox21.Controls.Add(label24);
			groupBox21.Font = null;
			groupBox21.Name = "groupBox21";
			groupBox21.TabStop = false;
			toolTip1.SetToolTip(groupBox21, resources.GetString("groupBox21.ToolTip"));
			textBox3.AccessibleDescription = null;
			textBox3.AccessibleName = null;
			resources.ApplyResources(textBox3, "textBox3");
			textBox3.BackColor = System.Drawing.Color.White;
			textBox3.BackgroundImage = null;
			textBox3.Font = null;
			textBox3.ForeColor = System.Drawing.Color.Black;
			textBox3.Name = "textBox3";
			toolTip1.SetToolTip(textBox3, resources.GetString("textBox3.ToolTip"));
			textBox5.AccessibleDescription = null;
			textBox5.AccessibleName = null;
			resources.ApplyResources(textBox5, "textBox5");
			textBox5.BackColor = System.Drawing.Color.White;
			textBox5.BackgroundImage = null;
			textBox5.Font = null;
			textBox5.ForeColor = System.Drawing.Color.Black;
			textBox5.Name = "textBox5";
			toolTip1.SetToolTip(textBox5, resources.GetString("textBox5.ToolTip"));
			groupBox24.AccessibleDescription = null;
			groupBox24.AccessibleName = null;
			resources.ApplyResources(groupBox24, "groupBox24");
			groupBox24.BackColor = System.Drawing.Color.Transparent;
			groupBox24.BackgroundImage = null;
			groupBox24.Controls.Add(button17);
			groupBox24.Controls.Add(txtQty);
			groupBox24.Controls.Add(label72);
			groupBox24.Controls.Add(floatText1);
			groupBox24.Controls.Add(label71);
			groupBox24.Controls.Add(label70);
			groupBox24.Controls.Add(txtStore);
			groupBox24.Controls.Add(itemIdComboBox);
			groupBox24.Name = "groupBox24";
			groupBox24.TabStop = false;
			toolTip1.SetToolTip(groupBox24, resources.GetString("groupBox24.ToolTip"));
			button17.AccessibleDescription = null;
			button17.AccessibleName = null;
			resources.ApplyResources(button17, "button17");
			button17.BackColor = System.Drawing.Color.Gainsboro;
			button17.BackgroundImage = null;
			button17.Name = "button17";
			toolTip1.SetToolTip(button17, resources.GetString("button17.ToolTip"));
			button17.UseVisualStyleBackColor = false;
			button17.Click += new System.EventHandler(button17_Click);
			txtQty.AccessibleDescription = null;
			txtQty.AccessibleName = null;
			resources.ApplyResources(txtQty, "txtQty");
			txtQty.BackgroundImage = null;
			txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			txtQty.Font = null;
			txtQty.Name = "txtQty";
			toolTip1.SetToolTip(txtQty, resources.GetString("txtQty.ToolTip"));
			label72.AccessibleDescription = null;
			label72.AccessibleName = null;
			resources.ApplyResources(label72, "label72");
			label72.Name = "label72";
			toolTip1.SetToolTip(label72, resources.GetString("label72.ToolTip"));
			floatText1.AccessibleDescription = null;
			floatText1.AccessibleName = null;
			resources.ApplyResources(floatText1, "floatText1");
			floatText1.BackgroundImage = null;
			floatText1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText1.Font = null;
			floatText1.Name = "floatText1";
			toolTip1.SetToolTip(floatText1, resources.GetString("floatText1.ToolTip"));
			label71.AccessibleDescription = null;
			label71.AccessibleName = null;
			resources.ApplyResources(label71, "label71");
			label71.Name = "label71";
			toolTip1.SetToolTip(label71, resources.GetString("label71.ToolTip"));
			label70.AccessibleDescription = null;
			label70.AccessibleName = null;
			resources.ApplyResources(label70, "label70");
			label70.Name = "label70";
			toolTip1.SetToolTip(label70, resources.GetString("label70.ToolTip"));
			txtStore.AccessibleDescription = null;
			txtStore.AccessibleName = null;
			resources.ApplyResources(txtStore, "txtStore");
			txtStore.BackgroundImage = null;
			txtStore.Font = null;
			txtStore.Name = "txtStore";
			txtStore.ReadOnly = true;
			toolTip1.SetToolTip(txtStore, resources.GetString("txtStore.ToolTip"));
			itemIdComboBox.AccessibleDescription = null;
			itemIdComboBox.AccessibleName = null;
			resources.ApplyResources(itemIdComboBox, "itemIdComboBox");
			itemIdComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			itemIdComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			itemIdComboBox.BackgroundImage = null;
			itemIdComboBox.Font = null;
			itemIdComboBox.FormattingEnabled = true;
			itemIdComboBox.Name = "itemIdComboBox";
			toolTip1.SetToolTip(itemIdComboBox, resources.GetString("itemIdComboBox.ToolTip"));
			itemIdComboBox.SelectedIndexChanged += new System.EventHandler(itemIdComboBox_SelectedIndexChanged);
			groupBox22.AccessibleDescription = null;
			groupBox22.AccessibleName = null;
			resources.ApplyResources(groupBox22, "groupBox22");
			groupBox22.BackColor = System.Drawing.Color.Transparent;
			groupBox22.BackgroundImage = null;
			groupBox22.Controls.Add(dataGridView3);
			groupBox22.Font = null;
			groupBox22.Name = "groupBox22";
			groupBox22.TabStop = false;
			toolTip1.SetToolTip(groupBox22, resources.GetString("groupBox22.ToolTip"));
			dataGridView3.AccessibleDescription = null;
			dataGridView3.AccessibleName = null;
			dataGridView3.AllowUserToAddRows = false;
			resources.ApplyResources(dataGridView3, "dataGridView3");
			dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView3.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView3.BackgroundImage = null;
			dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView3.Columns.AddRange(dataGridViewTextBoxColumn6, dataGridViewTextBoxColumn7, dataGridViewTextBoxColumn8, ItemId, Column3);
			dataGridView3.Font = null;
			dataGridView3.Name = "dataGridView3";
			dataGridView3.ReadOnly = true;
			toolTip1.SetToolTip(dataGridView3, resources.GetString("dataGridView3.ToolTip"));
			dataGridView3.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(dataGridView3_UserDeletingRow);
			resources.ApplyResources(dataGridViewTextBoxColumn6, "dataGridViewTextBoxColumn6");
			dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
			dataGridViewTextBoxColumn6.ReadOnly = true;
			resources.ApplyResources(dataGridViewTextBoxColumn7, "dataGridViewTextBoxColumn7");
			dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
			dataGridViewTextBoxColumn7.ReadOnly = true;
			resources.ApplyResources(dataGridViewTextBoxColumn8, "dataGridViewTextBoxColumn8");
			dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
			dataGridViewTextBoxColumn8.ReadOnly = true;
			resources.ApplyResources(ItemId, "ItemId");
			ItemId.Name = "ItemId";
			ItemId.ReadOnly = true;
			resources.ApplyResources(Column3, "Column3");
			Column3.Name = "Column3";
			Column3.ReadOnly = true;
			groupBox25.AccessibleDescription = null;
			groupBox25.AccessibleName = null;
			resources.ApplyResources(groupBox25, "groupBox25");
			groupBox25.BackColor = System.Drawing.Color.Transparent;
			groupBox25.BackgroundImage = null;
			groupBox25.Controls.Add(txtEDD);
			groupBox25.Controls.Add(txtIMP);
			groupBox25.Controls.Add(txtOthers);
			groupBox25.Controls.Add(label25);
			groupBox25.Controls.Add(txtUrinAnalysis);
			groupBox25.Controls.Add(label26);
			groupBox25.Controls.Add(txtRBS);
			groupBox25.Controls.Add(label27);
			groupBox25.Controls.Add(txtHeamoglobin);
			groupBox25.Controls.Add(label28);
			groupBox25.Controls.Add(txtTreatment);
			groupBox25.Controls.Add(label29);
			groupBox25.Controls.Add(txtUS);
			groupBox25.Controls.Add(label30);
			groupBox25.Controls.Add(txtWeight);
			groupBox25.Controls.Add(label31);
			groupBox25.Controls.Add(txtBP);
			groupBox25.Controls.Add(label32);
			groupBox25.Controls.Add(txtComplain);
			groupBox25.Controls.Add(groupBox26);
			groupBox25.Controls.Add(label33);
			groupBox25.Controls.Add(dtpDate);
			groupBox25.Controls.Add(label34);
			groupBox25.Controls.Add(txtHistory);
			groupBox25.Controls.Add(label35);
			groupBox25.Controls.Add(label36);
			groupBox25.Controls.Add(txtCS);
			groupBox25.Controls.Add(label37);
			groupBox25.Controls.Add(txtKind);
			groupBox25.Controls.Add(label38);
			groupBox25.Controls.Add(label39);
			groupBox25.Controls.Add(txtParity);
			groupBox25.Controls.Add(label40);
			groupBox25.Name = "groupBox25";
			groupBox25.TabStop = false;
			toolTip1.SetToolTip(groupBox25, resources.GetString("groupBox25.ToolTip"));
			txtEDD.AccessibleDescription = null;
			txtEDD.AccessibleName = null;
			resources.ApplyResources(txtEDD, "txtEDD");
			txtEDD.BackgroundImage = null;
			txtEDD.CalendarFont = null;
			txtEDD.Font = null;
			txtEDD.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			txtEDD.Name = "txtEDD";
			toolTip1.SetToolTip(txtEDD, resources.GetString("txtEDD.ToolTip"));
			txtIMP.AccessibleDescription = null;
			txtIMP.AccessibleName = null;
			resources.ApplyResources(txtIMP, "txtIMP");
			txtIMP.BackgroundImage = null;
			txtIMP.CalendarFont = null;
			txtIMP.Font = null;
			txtIMP.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			txtIMP.Name = "txtIMP";
			toolTip1.SetToolTip(txtIMP, resources.GetString("txtIMP.ToolTip"));
			txtIMP.ValueChanged += new System.EventHandler(txtIMP_ValueChanged);
			txtOthers.AccessibleDescription = null;
			txtOthers.AccessibleName = null;
			resources.ApplyResources(txtOthers, "txtOthers");
			txtOthers.BackgroundImage = null;
			txtOthers.Font = null;
			txtOthers.Name = "txtOthers";
			toolTip1.SetToolTip(txtOthers, resources.GetString("txtOthers.ToolTip"));
			txtUrinAnalysis.AccessibleDescription = null;
			txtUrinAnalysis.AccessibleName = null;
			resources.ApplyResources(txtUrinAnalysis, "txtUrinAnalysis");
			txtUrinAnalysis.BackgroundImage = null;
			txtUrinAnalysis.Font = null;
			txtUrinAnalysis.Name = "txtUrinAnalysis";
			toolTip1.SetToolTip(txtUrinAnalysis, resources.GetString("txtUrinAnalysis.ToolTip"));
			txtRBS.AccessibleDescription = null;
			txtRBS.AccessibleName = null;
			resources.ApplyResources(txtRBS, "txtRBS");
			txtRBS.BackgroundImage = null;
			txtRBS.Font = null;
			txtRBS.Name = "txtRBS";
			toolTip1.SetToolTip(txtRBS, resources.GetString("txtRBS.ToolTip"));
			txtHeamoglobin.AccessibleDescription = null;
			txtHeamoglobin.AccessibleName = null;
			resources.ApplyResources(txtHeamoglobin, "txtHeamoglobin");
			txtHeamoglobin.BackgroundImage = null;
			txtHeamoglobin.Font = null;
			txtHeamoglobin.Name = "txtHeamoglobin";
			toolTip1.SetToolTip(txtHeamoglobin, resources.GetString("txtHeamoglobin.ToolTip"));
			txtTreatment.AccessibleDescription = null;
			txtTreatment.AccessibleName = null;
			resources.ApplyResources(txtTreatment, "txtTreatment");
			txtTreatment.BackgroundImage = null;
			txtTreatment.Font = null;
			txtTreatment.Name = "txtTreatment";
			toolTip1.SetToolTip(txtTreatment, resources.GetString("txtTreatment.ToolTip"));
			txtUS.AccessibleDescription = null;
			txtUS.AccessibleName = null;
			resources.ApplyResources(txtUS, "txtUS");
			txtUS.BackgroundImage = null;
			txtUS.Font = null;
			txtUS.Name = "txtUS";
			toolTip1.SetToolTip(txtUS, resources.GetString("txtUS.ToolTip"));
			txtWeight.AccessibleDescription = null;
			txtWeight.AccessibleName = null;
			resources.ApplyResources(txtWeight, "txtWeight");
			txtWeight.BackgroundImage = null;
			txtWeight.Font = null;
			txtWeight.Name = "txtWeight";
			toolTip1.SetToolTip(txtWeight, resources.GetString("txtWeight.ToolTip"));
			txtBP.AccessibleDescription = null;
			txtBP.AccessibleName = null;
			resources.ApplyResources(txtBP, "txtBP");
			txtBP.BackgroundImage = null;
			txtBP.Font = null;
			txtBP.Name = "txtBP";
			toolTip1.SetToolTip(txtBP, resources.GetString("txtBP.ToolTip"));
			txtComplain.AccessibleDescription = null;
			txtComplain.AccessibleName = null;
			resources.ApplyResources(txtComplain, "txtComplain");
			txtComplain.BackgroundImage = null;
			txtComplain.Font = null;
			txtComplain.Name = "txtComplain";
			toolTip1.SetToolTip(txtComplain, resources.GetString("txtComplain.ToolTip"));
			groupBox26.AccessibleDescription = null;
			groupBox26.AccessibleName = null;
			resources.ApplyResources(groupBox26, "groupBox26");
			groupBox26.BackColor = System.Drawing.Color.Transparent;
			groupBox26.BackgroundImage = null;
			groupBox26.Font = null;
			groupBox26.Name = "groupBox26";
			groupBox26.TabStop = false;
			toolTip1.SetToolTip(groupBox26, resources.GetString("groupBox26.ToolTip"));
			dtpDate.AccessibleDescription = null;
			dtpDate.AccessibleName = null;
			resources.ApplyResources(dtpDate, "dtpDate");
			dtpDate.BackgroundImage = null;
			dtpDate.CalendarFont = null;
			dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dtpDate.Name = "dtpDate";
			toolTip1.SetToolTip(dtpDate, resources.GetString("dtpDate.ToolTip"));
			txtHistory.AccessibleDescription = null;
			txtHistory.AccessibleName = null;
			resources.ApplyResources(txtHistory, "txtHistory");
			txtHistory.BackgroundImage = null;
			txtHistory.Font = null;
			txtHistory.Name = "txtHistory";
			toolTip1.SetToolTip(txtHistory, resources.GetString("txtHistory.ToolTip"));
			txtCS.AccessibleDescription = null;
			txtCS.AccessibleName = null;
			resources.ApplyResources(txtCS, "txtCS");
			txtCS.BackgroundImage = null;
			txtCS.Font = null;
			txtCS.Name = "txtCS";
			toolTip1.SetToolTip(txtCS, resources.GetString("txtCS.ToolTip"));
			txtKind.AccessibleDescription = null;
			txtKind.AccessibleName = null;
			resources.ApplyResources(txtKind, "txtKind");
			txtKind.BackgroundImage = null;
			txtKind.Font = null;
			txtKind.Name = "txtKind";
			toolTip1.SetToolTip(txtKind, resources.GetString("txtKind.ToolTip"));
			txtParity.AccessibleDescription = null;
			txtParity.AccessibleName = null;
			resources.ApplyResources(txtParity, "txtParity");
			txtParity.BackgroundImage = null;
			txtParity.Font = null;
			txtParity.Name = "txtParity";
			toolTip1.SetToolTip(txtParity, resources.GetString("txtParity.ToolTip"));
			toolTip1.AutoPopDelay = 5000;
			toolTip1.InitialDelay = 100;
			toolTip1.IsBalloon = true;
			toolTip1.ReshowDelay = 100;
			toolTip1.ShowAlways = true;
			groupBox27.AccessibleDescription = null;
			groupBox27.AccessibleName = null;
			resources.ApplyResources(groupBox27, "groupBox27");
			groupBox27.BackColor = System.Drawing.Color.Transparent;
			groupBox27.BackgroundImage = null;
			groupBox27.Controls.Add(dateTimeHeart);
			groupBox27.Controls.Add(label43);
			groupBox27.Controls.Add(txtBox21);
			groupBox27.Controls.Add(label44);
			groupBox27.Controls.Add(txtBox20);
			groupBox27.Controls.Add(label45);
			groupBox27.Controls.Add(txtBox19);
			groupBox27.Controls.Add(label46);
			groupBox27.Controls.Add(txtBox18);
			groupBox27.Controls.Add(label47);
			groupBox27.Controls.Add(txtBox17);
			groupBox27.Controls.Add(label48);
			groupBox27.Controls.Add(txtBox16);
			groupBox27.Controls.Add(label49);
			groupBox27.Controls.Add(txtBox15);
			groupBox27.Controls.Add(label50);
			groupBox27.Controls.Add(txtBox14);
			groupBox27.Controls.Add(txtBox13);
			groupBox27.Controls.Add(label51);
			groupBox27.Controls.Add(label52);
			groupBox27.Controls.Add(txtBox11);
			groupBox27.Controls.Add(txtBox12);
			groupBox27.Controls.Add(label53);
			groupBox27.Controls.Add(label54);
			groupBox27.Controls.Add(label55);
			groupBox27.Controls.Add(label56);
			groupBox27.Name = "groupBox27";
			groupBox27.TabStop = false;
			toolTip1.SetToolTip(groupBox27, resources.GetString("groupBox27.ToolTip"));
			dateTimeHeart.AccessibleDescription = null;
			dateTimeHeart.AccessibleName = null;
			resources.ApplyResources(dateTimeHeart, "dateTimeHeart");
			dateTimeHeart.BackgroundImage = null;
			dateTimeHeart.CalendarFont = null;
			dateTimeHeart.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimeHeart.Name = "dateTimeHeart";
			toolTip1.SetToolTip(dateTimeHeart, resources.GetString("dateTimeHeart.ToolTip"));
			txtBox21.AccessibleDescription = null;
			txtBox21.AccessibleName = null;
			resources.ApplyResources(txtBox21, "txtBox21");
			txtBox21.BackColor = System.Drawing.Color.White;
			txtBox21.BackgroundImage = null;
			txtBox21.Font = null;
			txtBox21.ForeColor = System.Drawing.Color.Black;
			txtBox21.Name = "txtBox21";
			toolTip1.SetToolTip(txtBox21, resources.GetString("txtBox21.ToolTip"));
			txtBox20.AccessibleDescription = null;
			txtBox20.AccessibleName = null;
			resources.ApplyResources(txtBox20, "txtBox20");
			txtBox20.BackColor = System.Drawing.Color.White;
			txtBox20.BackgroundImage = null;
			txtBox20.Font = null;
			txtBox20.ForeColor = System.Drawing.Color.Black;
			txtBox20.Name = "txtBox20";
			toolTip1.SetToolTip(txtBox20, resources.GetString("txtBox20.ToolTip"));
			txtBox19.AccessibleDescription = null;
			txtBox19.AccessibleName = null;
			resources.ApplyResources(txtBox19, "txtBox19");
			txtBox19.BackColor = System.Drawing.Color.White;
			txtBox19.BackgroundImage = null;
			txtBox19.Font = null;
			txtBox19.ForeColor = System.Drawing.Color.Black;
			txtBox19.Name = "txtBox19";
			toolTip1.SetToolTip(txtBox19, resources.GetString("txtBox19.ToolTip"));
			txtBox18.AccessibleDescription = null;
			txtBox18.AccessibleName = null;
			resources.ApplyResources(txtBox18, "txtBox18");
			txtBox18.BackColor = System.Drawing.Color.White;
			txtBox18.BackgroundImage = null;
			txtBox18.Font = null;
			txtBox18.ForeColor = System.Drawing.Color.Black;
			txtBox18.Name = "txtBox18";
			toolTip1.SetToolTip(txtBox18, resources.GetString("txtBox18.ToolTip"));
			txtBox17.AccessibleDescription = null;
			txtBox17.AccessibleName = null;
			resources.ApplyResources(txtBox17, "txtBox17");
			txtBox17.BackColor = System.Drawing.Color.White;
			txtBox17.BackgroundImage = null;
			txtBox17.Font = null;
			txtBox17.ForeColor = System.Drawing.Color.Black;
			txtBox17.Name = "txtBox17";
			toolTip1.SetToolTip(txtBox17, resources.GetString("txtBox17.ToolTip"));
			txtBox16.AccessibleDescription = null;
			txtBox16.AccessibleName = null;
			resources.ApplyResources(txtBox16, "txtBox16");
			txtBox16.BackColor = System.Drawing.Color.White;
			txtBox16.BackgroundImage = null;
			txtBox16.Font = null;
			txtBox16.ForeColor = System.Drawing.Color.Black;
			txtBox16.Name = "txtBox16";
			toolTip1.SetToolTip(txtBox16, resources.GetString("txtBox16.ToolTip"));
			txtBox15.AccessibleDescription = null;
			txtBox15.AccessibleName = null;
			resources.ApplyResources(txtBox15, "txtBox15");
			txtBox15.BackColor = System.Drawing.Color.White;
			txtBox15.BackgroundImage = null;
			txtBox15.Font = null;
			txtBox15.ForeColor = System.Drawing.Color.Black;
			txtBox15.Name = "txtBox15";
			toolTip1.SetToolTip(txtBox15, resources.GetString("txtBox15.ToolTip"));
			txtBox14.AccessibleDescription = null;
			txtBox14.AccessibleName = null;
			resources.ApplyResources(txtBox14, "txtBox14");
			txtBox14.BackColor = System.Drawing.Color.White;
			txtBox14.BackgroundImage = null;
			txtBox14.Font = null;
			txtBox14.ForeColor = System.Drawing.Color.Black;
			txtBox14.Name = "txtBox14";
			toolTip1.SetToolTip(txtBox14, resources.GetString("txtBox14.ToolTip"));
			txtBox13.AccessibleDescription = null;
			txtBox13.AccessibleName = null;
			resources.ApplyResources(txtBox13, "txtBox13");
			txtBox13.BackColor = System.Drawing.Color.White;
			txtBox13.BackgroundImage = null;
			txtBox13.Font = null;
			txtBox13.ForeColor = System.Drawing.Color.Black;
			txtBox13.Name = "txtBox13";
			toolTip1.SetToolTip(txtBox13, resources.GetString("txtBox13.ToolTip"));
			txtBox11.AccessibleDescription = null;
			txtBox11.AccessibleName = null;
			resources.ApplyResources(txtBox11, "txtBox11");
			txtBox11.BackgroundImage = null;
			txtBox11.Font = null;
			txtBox11.Name = "txtBox11";
			toolTip1.SetToolTip(txtBox11, resources.GetString("txtBox11.ToolTip"));
			txtBox12.AccessibleDescription = null;
			txtBox12.AccessibleName = null;
			resources.ApplyResources(txtBox12, "txtBox12");
			txtBox12.BackColor = System.Drawing.Color.White;
			txtBox12.BackgroundImage = null;
			txtBox12.Font = null;
			txtBox12.ForeColor = System.Drawing.Color.Black;
			txtBox12.Name = "txtBox12";
			toolTip1.SetToolTip(txtBox12, resources.GetString("txtBox12.ToolTip"));
			PaidPanel.AccessibleDescription = null;
			PaidPanel.AccessibleName = null;
			resources.ApplyResources(PaidPanel, "PaidPanel");
			PaidPanel.BackColor = System.Drawing.Color.Transparent;
			PaidPanel.BackgroundImage = null;
			PaidPanel.Controls.Add(TreasuryCom);
			PaidPanel.Controls.Add(EsalNoTxt);
			PaidPanel.Controls.Add(lblTreasury);
			PaidPanel.Controls.Add(label69);
			PaidPanel.Font = null;
			PaidPanel.Name = "PaidPanel";
			toolTip1.SetToolTip(PaidPanel, resources.GetString("PaidPanel.ToolTip"));
			TreasuryCom.AccessibleDescription = null;
			TreasuryCom.AccessibleName = null;
			resources.ApplyResources(TreasuryCom, "TreasuryCom");
			TreasuryCom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			TreasuryCom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			TreasuryCom.BackgroundImage = null;
			TreasuryCom.FormattingEnabled = true;
			TreasuryCom.Name = "TreasuryCom";
			toolTip1.SetToolTip(TreasuryCom, resources.GetString("TreasuryCom.ToolTip"));
			EsalNoTxt.AccessibleDescription = null;
			EsalNoTxt.AccessibleName = null;
			resources.ApplyResources(EsalNoTxt, "EsalNoTxt");
			EsalNoTxt.BackgroundImage = null;
			EsalNoTxt.Font = null;
			EsalNoTxt.Name = "EsalNoTxt";
			toolTip1.SetToolTip(EsalNoTxt, resources.GetString("EsalNoTxt.ToolTip"));
			EsalNoTxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(EsalNoTxt_KeyPress);
			lblTreasury.AccessibleDescription = null;
			lblTreasury.AccessibleName = null;
			resources.ApplyResources(lblTreasury, "lblTreasury");
			lblTreasury.BackColor = System.Drawing.Color.Transparent;
			lblTreasury.Name = "lblTreasury";
			toolTip1.SetToolTip(lblTreasury, resources.GetString("lblTreasury.ToolTip"));
			label69.AccessibleDescription = null;
			label69.AccessibleName = null;
			resources.ApplyResources(label69, "label69");
			label69.BackColor = System.Drawing.Color.Transparent;
			label69.Name = "label69";
			toolTip1.SetToolTip(label69, resources.GetString("label69.ToolTip"));
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[51]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
					new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
					new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
					new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
					new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
					new System.Data.Common.DataColumnMapping("Implant", "Implant"),
					new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
					new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers"),
					new System.Data.Common.DataColumnMapping("DoctoreName", "DoctoreName"),
					new System.Data.Common.DataColumnMapping("NextVisit", "NextVisit"),
					new System.Data.Common.DataColumnMapping("Accept", "Accept"),
					new System.Data.Common.DataColumnMapping("Taqweem", "Taqweem"),
					new System.Data.Common.DataColumnMapping("Photo", "Photo"),
					new System.Data.Common.DataColumnMapping("BloodType", "BloodType"),
					new System.Data.Common.DataColumnMapping("Active", "Active"),
					new System.Data.Common.DataColumnMapping("FileNo", "FileNo"),
					new System.Data.Common.DataColumnMapping("Patient", "Patient"),
					new System.Data.Common.DataColumnMapping("Facebook", "Facebook"),
					new System.Data.Common.DataColumnMapping("Adv", "Adv"),
					new System.Data.Common.DataColumnMapping("FormerPatient", "FormerPatient"),
					new System.Data.Common.DataColumnMapping("Discount", "Discount"),
					new System.Data.Common.DataColumnMapping("Without", "Without"),
					new System.Data.Common.DataColumnMapping("Doctor", "Doctor"),
					new System.Data.Common.DataColumnMapping("DoctorId", "DoctorId")
				})
			});
			sqlInsertCommand2.CommandText = resources.GetString("sqlInsertCommand2.CommandText");
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[50]
			{
				new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
				new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
				new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
				new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
				new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
				new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
				new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
				new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
				new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
				new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
				new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
				new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
				new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
				new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
				new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
				new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
				new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
				new System.Data.SqlClient.SqlParameter("@Lactating", System.Data.SqlDbType.Bit, 0, "Lactating"),
				new System.Data.SqlClient.SqlParameter("@Pregnant", System.Data.SqlDbType.Bit, 0, "Pregnant"),
				new System.Data.SqlClient.SqlParameter("@HepatitisB", System.Data.SqlDbType.Bit, 0, "HepatitisB"),
				new System.Data.SqlClient.SqlParameter("@Hepatitisc", System.Data.SqlDbType.Bit, 0, "Hepatitisc"),
				new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
				new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
				new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
				new System.Data.SqlClient.SqlParameter("@Endodontics", System.Data.SqlDbType.Bit, 0, "Endodontics"),
				new System.Data.SqlClient.SqlParameter("@Fixed", System.Data.SqlDbType.Bit, 0, "Fixed"),
				new System.Data.SqlClient.SqlParameter("@Implant", System.Data.SqlDbType.Bit, 0, "Implant"),
				new System.Data.SqlClient.SqlParameter("@Opretive", System.Data.SqlDbType.Bit, 0, "Opretive"),
				new System.Data.SqlClient.SqlParameter("@Bleaching", System.Data.SqlDbType.Bit, 0, "Bleaching"),
				new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers"),
				new System.Data.SqlClient.SqlParameter("@DoctoreName", System.Data.SqlDbType.NVarChar, 0, "DoctoreName"),
				new System.Data.SqlClient.SqlParameter("@NextVisit", System.Data.SqlDbType.NVarChar, 0, "NextVisit"),
				new System.Data.SqlClient.SqlParameter("@Accept", System.Data.SqlDbType.Bit, 0, "Accept"),
				new System.Data.SqlClient.SqlParameter("@Taqweem", System.Data.SqlDbType.Bit, 0, "Taqweem"),
				new System.Data.SqlClient.SqlParameter("@Photo", System.Data.SqlDbType.Image, 0, "Photo"),
				new System.Data.SqlClient.SqlParameter("@BloodType", System.Data.SqlDbType.NVarChar, 0, "BloodType"),
				new System.Data.SqlClient.SqlParameter("@Active", System.Data.SqlDbType.Bit, 0, "Active"),
				new System.Data.SqlClient.SqlParameter("@FileNo", System.Data.SqlDbType.Int, 0, "FileNo"),
				new System.Data.SqlClient.SqlParameter("@Patient", System.Data.SqlDbType.Bit, 0, "Patient"),
				new System.Data.SqlClient.SqlParameter("@Facebook", System.Data.SqlDbType.Bit, 0, "Facebook"),
				new System.Data.SqlClient.SqlParameter("@Adv", System.Data.SqlDbType.Bit, 0, "Adv"),
				new System.Data.SqlClient.SqlParameter("@FormerPatient", System.Data.SqlDbType.NVarChar, 0, "FormerPatient"),
				new System.Data.SqlClient.SqlParameter("@Discount", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Discount", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Without", System.Data.SqlDbType.Bit, 0, "Without"),
				new System.Data.SqlClient.SqlParameter("@Doctor", System.Data.SqlDbType.Bit, 0, "Doctor"),
				new System.Data.SqlClient.SqlParameter("@DoctorId", System.Data.SqlDbType.NVarChar, 0, "DoctorId")
			});
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlSelectCommand2.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlSelectCommand2.Connection = sqlConnection2;
			PayNaqdy.AccessibleDescription = null;
			PayNaqdy.AccessibleName = null;
			resources.ApplyResources(PayNaqdy, "PayNaqdy");
			PayNaqdy.BackColor = System.Drawing.Color.Transparent;
			PayNaqdy.BackgroundImage = null;
			PayNaqdy.Checked = true;
			PayNaqdy.Name = "PayNaqdy";
			PayNaqdy.TabStop = true;
			toolTip1.SetToolTip(PayNaqdy, resources.GetString("PayNaqdy.ToolTip"));
			PayNaqdy.UseVisualStyleBackColor = false;
			PayNaqdy.CheckedChanged += new System.EventHandler(PayNaqdy_CheckedChanged);
			PayBefore.AccessibleDescription = null;
			PayBefore.AccessibleName = null;
			resources.ApplyResources(PayBefore, "PayBefore");
			PayBefore.BackColor = System.Drawing.Color.Transparent;
			PayBefore.BackgroundImage = null;
			PayBefore.Name = "PayBefore";
			toolTip1.SetToolTip(PayBefore, resources.GetString("PayBefore.ToolTip"));
			PayBefore.UseVisualStyleBackColor = false;
			PayBefore.CheckedChanged += new System.EventHandler(PayBefore_CheckedChanged);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(panel1);
			base.Controls.Add(PayNaqdy);
			base.Controls.Add(PayBefore);
			base.Controls.Add(PaidPanel);
			base.Controls.Add(button16);
			base.Controls.Add(groupBox24);
			base.Controls.Add(groupBox22);
			base.Controls.Add(groupBox9);
			base.Controls.Add(groupBox21);
			base.Controls.Add(checkBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(tottextBox);
			base.Controls.Add(groupBox5);
			base.Controls.Add(label);
			base.Controls.Add(groupBox4);
			base.Controls.Add(panel2);
			base.Controls.Add(groupBox25);
			base.Controls.Add(groupBox27);
			base.Controls.Add(groupBox12);
			Font = null;
			base.KeyPreview = true;
			base.Name = "PationtAccountReBack";
			toolTip1.SetToolTip(this, resources.GetString("$this.ToolTip"));
			base.Load += new System.EventHandler(PationtAccountReBack_Load);
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(PationtAccountReBack_FormClosing);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(PationtAccountReBack_KeyDown);
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox5.ResumeLayout(false);
			groupBox1.ResumeLayout(false);
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			groupBox29.ResumeLayout(false);
			groupBox29.PerformLayout();
			groupBox10.ResumeLayout(false);
			groupBox10.PerformLayout();
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			groupBox7.ResumeLayout(false);
			groupBox3.ResumeLayout(false);
			panel2.ResumeLayout(false);
			panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown13).EndInit();
			tableLayoutPanel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown5).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown6).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown4).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown3).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown14).EndInit();
			tableLayoutPanel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)numericUpDown7).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown8).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown11).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown12).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown9).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown10).EndInit();
			groupBox12.ResumeLayout(false);
			groupBox12.PerformLayout();
			groupBox9.ResumeLayout(false);
			groupBox21.ResumeLayout(false);
			groupBox21.PerformLayout();
			groupBox24.ResumeLayout(false);
			groupBox24.PerformLayout();
			groupBox22.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
			groupBox25.ResumeLayout(false);
			groupBox25.PerformLayout();
			groupBox27.ResumeLayout(false);
			groupBox27.PerformLayout();
			PaidPanel.ResumeLayout(false);
			PaidPanel.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
