using System;

namespace DentistClinic
{
	public class GeneralMethods
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		public void UserMove(string BayanName)
		{
			string userId = Main.userId;
			Codes.Add2(string.Concat("insert into LoginUsers (userId, Date,BayanName) values('", Convert.ToInt32(userId), "','", DateTime.Now, "','", BayanName, "')"));
		}
	}
}
