using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Windows.Forms;

namespace DentistClinic
{
	public class StatmentRptFrm : ReportBaseForm
	{
		private IContainer components = null;

		private Panel panel1;

		private CrystalReportViewer crystalReportViewer1;

		private DataSet1 datset;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			panel1 = new System.Windows.Forms.Panel();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			panel1.SuspendLayout();
			SuspendLayout();
			panel1.BackColor = System.Drawing.Color.Transparent;
			panel1.Controls.Add(crystalReportViewer1);
			panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(686, 495);
			panel1.TabIndex = 0;
			crystalReportViewer1.ActiveViewIndex = -1;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
			crystalReportViewer1.Location = new System.Drawing.Point(0, 0);
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.Size = new System.Drawing.Size(686, 495);
			crystalReportViewer1.TabIndex = 0;
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(686, 495);
			base.Controls.Add(panel1);
			base.Location = new System.Drawing.Point(0, 0);
			base.Name = "StatmentRptFrm";
			Text = "";
			base.Load += new System.EventHandler(StatmentRptFrm_Load);
			panel1.ResumeLayout(false);
			ResumeLayout(false);
		}

		public StatmentRptFrm(object rpt)
		{
			InitializeComponent();
			crystalReportViewer1.ReportSource = (ReportDocument)rpt;
		}

		private void StatmentRptFrm_Load(object sender, EventArgs e)
		{
		}
	}
}
