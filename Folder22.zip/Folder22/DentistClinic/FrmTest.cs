using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmTest : Form
	{
		private IContainer components = null;

		private CheckedListBox checkedListBox1;

		private Button button1;

		private RichTextBox richTextBox1;

		private CrystalReportViewer crystalReportViewer1;

		private ColorDialog colorDialog1;

		private FontDialog fontDialog1;

		private ContextMenuStrip contextMenuStrip1;

		private ToolStripMenuItem toolStripMenuItem1;

		private ToolStripMenuItem toolStripMenuItem2;

		private Button button2;

		private dataClass codes = new dataClass(".\\sqlExpress");

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			checkedListBox1 = new System.Windows.Forms.CheckedListBox();
			button1 = new System.Windows.Forms.Button();
			richTextBox1 = new System.Windows.Forms.RichTextBox();
			contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(components);
			toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			colorDialog1 = new System.Windows.Forms.ColorDialog();
			fontDialog1 = new System.Windows.Forms.FontDialog();
			button2 = new System.Windows.Forms.Button();
			contextMenuStrip1.SuspendLayout();
			SuspendLayout();
			checkedListBox1.FormattingEnabled = true;
			checkedListBox1.Location = new System.Drawing.Point(43, 24);
			checkedListBox1.Name = "checkedListBox1";
			checkedListBox1.Size = new System.Drawing.Size(236, 94);
			checkedListBox1.TabIndex = 0;
			button1.Location = new System.Drawing.Point(55, 124);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(75, 23);
			button1.TabIndex = 1;
			button1.Text = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			richTextBox1.ContextMenuStrip = contextMenuStrip1;
			richTextBox1.Location = new System.Drawing.Point(55, 153);
			richTextBox1.Name = "richTextBox1";
			richTextBox1.Size = new System.Drawing.Size(191, 123);
			richTextBox1.TabIndex = 2;
			richTextBox1.Text = "";
			richTextBox1.MouseHover += new System.EventHandler(richTextBox1_MouseHover);
			richTextBox1.TextChanged += new System.EventHandler(richTextBox1_TextChanged);
			richTextBox1.Click += new System.EventHandler(richTextBox1_Click);
			contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { toolStripMenuItem1, toolStripMenuItem2 });
			contextMenuStrip1.Name = "contextMenuStrip1";
			contextMenuStrip1.Size = new System.Drawing.Size(139, 48);
			toolStripMenuItem1.Name = "toolStripMenuItem1";
			toolStripMenuItem1.Size = new System.Drawing.Size(138, 22);
			toolStripMenuItem1.Text = "a)Add Color";
			toolStripMenuItem2.Name = "toolStripMenuItem2";
			toolStripMenuItem2.Size = new System.Drawing.Size(138, 22);
			toolStripMenuItem2.Text = "b)Add Font";
			crystalReportViewer1.ActiveViewIndex = -1;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Location = new System.Drawing.Point(297, 12);
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.Size = new System.Drawing.Size(530, 397);
			crystalReportViewer1.TabIndex = 3;
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			button2.Location = new System.Drawing.Point(243, 153);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(75, 36);
			button2.TabIndex = 4;
			button2.Text = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = DentistClinic.Properties.Resources.color_circle1;
			BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			base.ClientSize = new System.Drawing.Size(839, 421);
			base.Controls.Add(button2);
			base.Controls.Add(crystalReportViewer1);
			base.Controls.Add(richTextBox1);
			base.Controls.Add(button1);
			base.Controls.Add(checkedListBox1);
			DoubleBuffered = true;
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "FrmTest";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "FrmTest";
			base.TransparencyKey = System.Drawing.Color.Lime;
			base.Load += new System.EventHandler(FrmTest_Load);
			contextMenuStrip1.ResumeLayout(false);
			ResumeLayout(false);
		}

		public FrmTest()
		{
			InitializeComponent();
		}

		private void FrmTest_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select Complaint from MainComplaint");
				foreach (DataRow row in dataTable.Rows)
				{
					checkedListBox1.Items.Add(row.ItemArray[0]);
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			foreach (object checkedItem in checkedListBox1.CheckedItems)
			{
				codes.Add(string.Concat("insert into checks(checkId) Values ('", checkedItem, "')"));
			}
		}

		private void richTextBox1_MouseHover(object sender, EventArgs e)
		{
		}

		private void richTextBox1_Click(object sender, EventArgs e)
		{
		}

		private void richTextBox1_TextChanged(object sender, EventArgs e)
		{
		}

		private void button2_Click(object sender, EventArgs e)
		{
			contextMenuStrip1.Show(Cursor.Position.X, Cursor.Position.Y);
		}
	}
}
