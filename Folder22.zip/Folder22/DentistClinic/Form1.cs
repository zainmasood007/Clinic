using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Windows.Forms;
using DentistClinic.Properties;
using iptb;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;

namespace DentistClinic
{
	public class Form1 : BaseForm
	{
		private IContainer components = null;

		private Label lblServer;

		private Button btnRestore;

		private Label lblUsername;

		private Label label3;

		private TextBox txtUsername;

		private TextBox txtPassword;

		private ComboBox cmbDatabase;

		private ComboBox cmbServer;

		private Label lblPassword;

		private GroupBox groupBox1;

		private GroupBox groupBox2;

		private Button btnConnect;

		private Button btnCreate;

		private OpenFileDialog openBackupDialog;

		private SaveFileDialog saveBackupDialog;

		private Button button1;

		private CheckBox checkBox1;

		private IPTextBox ipTextBox1;

		private Panel panel1;

		private Label label1;

		private TextBox textBox1;

		private Button button2;

		private static Server srvSql;

		private string localServers = "";

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			lblServer = new System.Windows.Forms.Label();
			btnRestore = new System.Windows.Forms.Button();
			lblUsername = new System.Windows.Forms.Label();
			label3 = new System.Windows.Forms.Label();
			txtUsername = new System.Windows.Forms.TextBox();
			txtPassword = new System.Windows.Forms.TextBox();
			cmbDatabase = new System.Windows.Forms.ComboBox();
			cmbServer = new System.Windows.Forms.ComboBox();
			lblPassword = new System.Windows.Forms.Label();
			groupBox1 = new System.Windows.Forms.GroupBox();
			panel1 = new System.Windows.Forms.Panel();
			textBox1 = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			ipTextBox1 = new iptb.IPTextBox();
			btnConnect = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			groupBox2 = new System.Windows.Forms.GroupBox();
			button1 = new System.Windows.Forms.Button();
			btnCreate = new System.Windows.Forms.Button();
			openBackupDialog = new System.Windows.Forms.OpenFileDialog();
			saveBackupDialog = new System.Windows.Forms.SaveFileDialog();
			checkBox1 = new System.Windows.Forms.CheckBox();
			groupBox1.SuspendLayout();
			panel1.SuspendLayout();
			groupBox2.SuspendLayout();
			SuspendLayout();
			lblServer.AutoSize = true;
			lblServer.Location = new System.Drawing.Point(28, 22);
			lblServer.Name = "lblServer";
			lblServer.Size = new System.Drawing.Size(41, 13);
			lblServer.TabIndex = 1;
			lblServer.Text = "Server:";
			btnRestore.Enabled = false;
			btnRestore.Location = new System.Drawing.Point(311, 57);
			btnRestore.Name = "btnRestore";
			btnRestore.Size = new System.Drawing.Size(10, 23);
			btnRestore.TabIndex = 6;
			btnRestore.Text = "إسترجاع نسخه أحتياطيه";
			btnRestore.UseVisualStyleBackColor = true;
			btnRestore.Visible = false;
			btnRestore.Click += new System.EventHandler(btnRestore_Click);
			lblUsername.AutoSize = true;
			lblUsername.Location = new System.Drawing.Point(11, 49);
			lblUsername.Name = "lblUsername";
			lblUsername.Size = new System.Drawing.Size(58, 13);
			lblUsername.TabIndex = 3;
			lblUsername.Text = "Username:";
			label3.AutoSize = true;
			label3.Location = new System.Drawing.Point(45, 22);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(56, 13);
			label3.TabIndex = 4;
			label3.Text = "Database:";
			txtUsername.Location = new System.Drawing.Point(75, 46);
			txtUsername.Name = "txtUsername";
			txtUsername.Size = new System.Drawing.Size(186, 20);
			txtUsername.TabIndex = 1;
			txtPassword.Location = new System.Drawing.Point(75, 73);
			txtPassword.Name = "txtPassword";
			txtPassword.PasswordChar = '*';
			txtPassword.Size = new System.Drawing.Size(186, 20);
			txtPassword.TabIndex = 2;
			cmbDatabase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cmbDatabase.FormattingEnabled = true;
			cmbDatabase.Location = new System.Drawing.Point(107, 19);
			cmbDatabase.Name = "cmbDatabase";
			cmbDatabase.Size = new System.Drawing.Size(193, 21);
			cmbDatabase.TabIndex = 4;
			cmbDatabase.SelectionChangeCommitted += new System.EventHandler(cmbDatabase_SelectedIndexChanged);
			cmbDatabase.SelectedIndexChanged += new System.EventHandler(cmbDatabase_SelectedIndexChanged);
			cmbDatabase.TextChanged += new System.EventHandler(cmbDatabase_SelectedIndexChanged);
			cmbServer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cmbServer.FormattingEnabled = true;
			cmbServer.Location = new System.Drawing.Point(75, 19);
			cmbServer.Name = "cmbServer";
			cmbServer.Size = new System.Drawing.Size(186, 21);
			cmbServer.TabIndex = 0;
			lblPassword.AutoSize = true;
			lblPassword.Location = new System.Drawing.Point(13, 76);
			lblPassword.Name = "lblPassword";
			lblPassword.Size = new System.Drawing.Size(56, 13);
			lblPassword.TabIndex = 9;
			lblPassword.Text = "Password:";
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(panel1);
			groupBox1.Controls.Add(btnConnect);
			groupBox1.Controls.Add(txtPassword);
			groupBox1.Controls.Add(lblServer);
			groupBox1.Controls.Add(lblPassword);
			groupBox1.Controls.Add(lblUsername);
			groupBox1.Controls.Add(cmbServer);
			groupBox1.Controls.Add(txtUsername);
			groupBox1.Controls.Add(button2);
			groupBox1.Location = new System.Drawing.Point(12, 35);
			groupBox1.Name = "groupBox1";
			groupBox1.Size = new System.Drawing.Size(416, 143);
			groupBox1.TabIndex = 10;
			groupBox1.TabStop = false;
			groupBox1.Text = "server Settings";
			panel1.Controls.Add(textBox1);
			panel1.Controls.Add(label1);
			panel1.Controls.Add(ipTextBox1);
			panel1.Location = new System.Drawing.Point(71, 19);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(339, 24);
			panel1.TabIndex = 13;
			panel1.Visible = false;
			textBox1.Location = new System.Drawing.Point(211, 2);
			textBox1.Name = "textBox1";
			textBox1.Size = new System.Drawing.Size(125, 20);
			textBox1.TabIndex = 15;
			label1.AutoSize = true;
			label1.Location = new System.Drawing.Point(135, 6);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(83, 13);
			label1.TabIndex = 10;
			label1.Text = "\\SQLEXPRESS";
			ipTextBox1.Location = new System.Drawing.Point(3, 2);
			ipTextBox1.Name = "ipTextBox1";
			ipTextBox1.Size = new System.Drawing.Size(128, 18);
			ipTextBox1.TabIndex = 10;
			ipTextBox1.ToolTipText = "";
			btnConnect.Location = new System.Drawing.Point(148, 99);
			btnConnect.Name = "btnConnect";
			btnConnect.Size = new System.Drawing.Size(90, 32);
			btnConnect.TabIndex = 3;
			btnConnect.Text = "Connect";
			btnConnect.UseVisualStyleBackColor = true;
			btnConnect.Click += new System.EventHandler(btnConnect_Click);
			button2.Location = new System.Drawing.Point(267, 17);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(113, 28);
			button2.TabIndex = 14;
			button2.Text = "تحميل السيرفرات";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(button1);
			groupBox2.Controls.Add(btnCreate);
			groupBox2.Controls.Add(label3);
			groupBox2.Controls.Add(cmbDatabase);
			groupBox2.Controls.Add(btnRestore);
			groupBox2.Location = new System.Drawing.Point(12, 184);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(416, 99);
			groupBox2.TabIndex = 11;
			groupBox2.TabStop = false;
			groupBox2.Text = "database settings";
			button1.Enabled = false;
			button1.Location = new System.Drawing.Point(137, 57);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(139, 23);
			button1.TabIndex = 7;
			button1.Text = "تسجل الدخول";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			btnCreate.Enabled = false;
			btnCreate.Location = new System.Drawing.Point(16, 57);
			btnCreate.Name = "btnCreate";
			btnCreate.Size = new System.Drawing.Size(10, 23);
			btnCreate.TabIndex = 5;
			btnCreate.Text = "عمل نسخه أحتياطيه";
			btnCreate.UseVisualStyleBackColor = true;
			btnCreate.Visible = false;
			btnCreate.Click += new System.EventHandler(btnCreate_Click);
			openBackupDialog.FileName = "Backup.bak";
			openBackupDialog.Filter = "Backup File|*.bak";
			saveBackupDialog.FileName = "Backup.bak";
			saveBackupDialog.Filter = "Backup File|*.bak";
			checkBox1.AutoSize = true;
			checkBox1.BackColor = System.Drawing.Color.Transparent;
			checkBox1.Location = new System.Drawing.Point(312, 12);
			checkBox1.Name = "checkBox1";
			checkBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			checkBox1.Size = new System.Drawing.Size(110, 17);
			checkBox1.TabIndex = 12;
			checkBox1.Text = "اتصال باستخدام IP";
			checkBox1.UseVisualStyleBackColor = false;
			checkBox1.CheckedChanged += new System.EventHandler(checkBox1_CheckedChanged);
			base.AcceptButton = btnConnect;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.WhiteSmoke;
			base.ClientSize = new System.Drawing.Size(440, 291);
			base.Controls.Add(groupBox1);
			base.Controls.Add(checkBox1);
			base.Controls.Add(groupBox2);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Name = "Form1";
			Text = "الإتصال بقاعدة البيانات";
			base.Load += new System.EventHandler(Form1_Load);
			base.FormClosed += new System.Windows.Forms.FormClosedEventHandler(Form1_FormClosed);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			try
			{
				DentistClinic.Properties.Settings.Default.Save();
				if (DentistClinic.Properties.Settings.Default.IpCheck)
				{
					checkBox1.Checked = true;
				}
				else
				{
					panel1.Visible = false;
					cmbServer.Visible = true;
				}
				if (!Splash.Instance.Visible)
				{
					Splash.Instance.Visible = true;
				}
				if (DentistClinic.Properties.Settings.Default.ServerName == "server" || string.IsNullOrEmpty(DentistClinic.Properties.Settings.Default.ServerName))
				{
					if (Splash.Instance.Visible)
					{
						Splash.Instance.Visible = false;
					}
					LoadAllServers();
					return;
				}
				fmlogin fmlogin2 = new fmlogin();
				if (Splash.Instance.Visible)
				{
					Splash.Instance.Visible = false;
				}
				if (!fmlogin.Exit)
				{
					base.Visible = false;
					fmlogin2.ShowDialog();
				}
				Close();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void btnConnect_Click(object sender, EventArgs e)
		{
			try
			{
				cmbDatabase.Items.Clear();
				if ((txtPassword.Text != "") & (txtUsername.Text != ""))
				{
					ServerConnection serverConnection;
					if (!checkBox1.Checked)
					{
						if (cmbServer.SelectedItem != null && cmbServer.SelectedItem.ToString() != "")
						{
							serverConnection = new ServerConnection(cmbServer.SelectedItem.ToString());
							serverConnection.LoginSecure = false;
							serverConnection.Login = txtUsername.Text;
							serverConnection.Password = txtPassword.Text;
							srvSql = new Server(serverConnection);
							foreach (Database database2 in srvSql.Databases)
							{
								cmbDatabase.Items.Add(database2.Name);
							}
						}
						else
						{
							MessageBox.Show("Please select a server first", "Server Not Selected", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
						return;
					}
					if (ipTextBox1.Text == "")
					{
						MessageBox.Show("من فضلك قم بكتابة ip صحيح");
						return;
					}
					if (Enumerable.Contains<string>((IEnumerable<string>)GetIPAddress(), ipTextBox1.Text) && DentistClinic.Properties.Settings.Default.IsSecondary)
					{
						MessageBox.Show("لا يمكن الاتصال بهذا السيرفر من خلال النسخه الفرعية");
						cmbDatabase.Items.Clear();
						return;
					}
					if (ipTextBox1.Text == "127.0.0.1" && DentistClinic.Properties.Settings.Default.IsSecondary)
					{
						MessageBox.Show("لا يمكن الاتصال بهذا السيرفر من خلال النسخه الفرعية");
						cmbDatabase.Items.Clear();
						return;
					}
					serverConnection = new ServerConnection(ipTextBox1.Text + label1.Text + textBox1.Text);
					serverConnection.LoginSecure = false;
					serverConnection.Login = txtUsername.Text;
					serverConnection.Password = txtPassword.Text;
					srvSql = new Server(serverConnection);
					foreach (Database database3 in srvSql.Databases)
					{
						if (!DentistClinic.Properties.Settings.Default.IsSecondary || (!serverConnection.TrueName.Contains(Environment.MachineName) && !Enumerable.Contains<string>((IEnumerable<string>)GetIPAddress(), serverConnection.TrueName) && !serverConnection.TrueName.Contains("127.0.0.1") && !serverConnection.TrueName.Contains("\\\\.\\")))
						{
							cmbDatabase.Items.Add(database3.Name);
							continue;
						}
						MessageBox.Show("لا يمكن الاتصال بهذا السيرفر من خلال النسخه الفرعية");
						break;
					}
				}
				else
				{
					MessageBox.Show("قم بأدخال اسم المستخدم وكلمة المرور", "تنبيه");
				}
			}
			catch
			{
				MessageBox.Show("من فضلك تأكد من  اسم المستخدم وكلمة المرور أو إسم السيرفر", "تنبيه");
			}
		}

		private string[] GetIPAddress()
		{
			string empty = string.Empty;
			empty = Dns.GetHostName();
			IPHostEntry hostEntry = Dns.GetHostEntry(empty);
			return Enumerable.ToArray<string>(Enumerable.Select<IPAddress, string>((IEnumerable<IPAddress>)hostEntry.AddressList, (Func<IPAddress, string>)((IPAddress ip) => ip.ToString())));
		}

		private void btnCreate_Click(object sender, EventArgs e)
		{
			try
			{
				if (srvSql != null)
				{
					if (saveBackupDialog.ShowDialog() == DialogResult.OK)
					{
						Backup backup = new Backup();
						backup.BackupSetDescription = "ArchiveDataBase:" + DateTime.Now.ToShortDateString();
						backup.BackupSetName = "Archive";
						backup.Action = BackupActionType.Database;
						backup.Database = cmbDatabase.SelectedItem.ToString();
						BackupDeviceItem item = new BackupDeviceItem(saveBackupDialog.FileName, DeviceType.File);
						ServerConnection serverConnection = new ServerConnection(cmbServer.SelectedItem.ToString(), txtUsername.Text, txtPassword.Text);
						Server server = new Server(serverConnection);
						_ = server.Databases[cmbDatabase.SelectedItem.ToString()];
						backup.Initialize = true;
						backup.Checksum = true;
						backup.ContinueAfterError = true;
						backup.Devices.Add(item);
						backup.Incremental = false;
						backup.ExpirationDate = DateTime.Now.AddDays(3.0);
						backup.LogTruncation = BackupTruncateLogType.Truncate;
						backup.FormatMedia = false;
						backup.SqlBackup(srvSql);
						MessageBox.Show("Bakup of Database " + cmbDatabase.Text + " successfully created", "Server", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else
				{
					MessageBox.Show("A connection to a SQL server was not established.", "Not Connected to Server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
				MessageBox.Show("no connection");
			}
		}

		private void btnRestore_Click(object sender, EventArgs e)
		{
			try
			{
				if (srvSql != null)
				{
					if (openBackupDialog.ShowDialog() == DialogResult.OK)
					{
						Restore restore = new Restore();
						restore.Action = RestoreActionType.Database;
						restore.Database = cmbDatabase.SelectedItem.ToString();
						BackupDeviceItem item = new BackupDeviceItem(openBackupDialog.FileName, DeviceType.File);
						restore.Devices.Add(item);
						restore.ReplaceDatabase = true;
						restore.SqlRestore(srvSql);
						MessageBox.Show("Database " + cmbDatabase.Text + " succefully restored", "Server", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else
				{
					MessageBox.Show("A connection to a SQL server was not established.", "Not Connected to Server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (cmbDatabase.Text != "")
				{
					if (!checkBox1.Checked)
					{
						DentistClinic.Properties.Settings.Default.ServerName = cmbServer.SelectedItem.ToString();
						DentistClinic.Properties.Settings.Default.DataBaseName = cmbDatabase.SelectedItem.ToString();
						DentistClinic.Properties.Settings.Default.UserName = txtUsername.Text;
						DentistClinic.Properties.Settings.Default.Pass = txtPassword.Text;
						DentistClinic.Properties.Settings.Default.IpCheck = false;
						DentistClinic.Properties.Settings.Default.Save();
					}
					else
					{
						DentistClinic.Properties.Settings.Default.ServerName = ipTextBox1.Text + label1.Text + textBox1.Text;
						DentistClinic.Properties.Settings.Default.DataBaseName = cmbDatabase.SelectedItem.ToString();
						DentistClinic.Properties.Settings.Default.UserName = txtUsername.Text;
						DentistClinic.Properties.Settings.Default.Pass = txtPassword.Text;
						DentistClinic.Properties.Settings.Default.IpCheck = true;
						DentistClinic.Properties.Settings.Default.Save();
					}
					MessageBox.Show("تم الإتصال بنجاح", "");
					base.Visible = false;
					fmlogin fmlogin2 = new fmlogin();
					fmlogin2.ShowDialog();
					Close();
					base.DialogResult = DialogResult.OK;
				}
				else
				{
					MessageBox.Show("من فضلك قم بإختيار قاعدة بيانات أولا", "database Not Selected", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
			}
		}

		private void cmbDatabase_SelectedIndexChanged(object sender, EventArgs e)
		{
			button1.Enabled = true;
			btnCreate.Enabled = true;
			btnRestore.Enabled = true;
		}

		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
			Application.Exit();
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox1.Checked)
			{
				panel1.Visible = true;
				cmbServer.Visible = false;
				cmbDatabase.Items.Clear();
			}
			else
			{
				panel1.Visible = false;
				cmbServer.Visible = true;
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			Main.Exit = true;
			Close();
		}

		private void BtnLoad_Click(object sender, EventArgs e)
		{
			LoadAllServers();
		}

		private void LoadAllServers()
		{
			try
			{
				cmbServer.Items.Clear();
				cmbDatabase.Items.Clear();
				DataTable dataTable = SmoApplication.EnumAvailableSqlServers(localOnly: false);
				bool flag = false;
				while (dataTable.Rows.Count == 0 && !flag)
				{
					DialogResult dialogResult = MessageBox.Show("لم يتم العثور علي أي سيرفرات .. هل تريد المحاولة مرة أخري؟", "إنتظر قليلا\u064b", MessageBoxButtons.RetryCancel, MessageBoxIcon.Asterisk);
					if (dialogResult == DialogResult.Retry)
					{
						dataTable = SmoApplication.EnumAvailableSqlServers(localOnly: false);
					}
					else
					{
						flag = true;
					}
				}
				if (dataTable.Rows.Count <= 0)
				{
					return;
				}
				foreach (DataRow row in dataTable.Rows)
				{
					if (DentistClinic.Properties.Settings.Default.IsSecondary)
					{
						if (Convert.ToBoolean(row[5].ToString()))
						{
							localServers += (localServers.Contains(row["Server"].ToString()) ? "" : (row["Server"].ToString() + "^"));
						}
						else
						{
							cmbServer.Items.Add(row["Name"]);
						}
					}
					else
					{
						cmbServer.Items.Add(row["Name"]);
					}
					try
					{
						cmbServer.SelectedItem = cmbServer.Items[0];
					}
					catch
					{
					}
				}
				localServers = localServers.TrimEnd('^');
			}
			catch
			{
				MessageBox.Show("حدث خطأ أثناء محاولة العثور علي السيرفرات");
			}
		}

		private void cmbServer_SelectedIndexChanged(object sender, EventArgs e)
		{
			cmbDatabase.Items.Clear();
		}

		private void ipTextBox1_Leave(object sender, EventArgs e)
		{
			cmbDatabase.Items.Clear();
		}

		private void Link_TextChanged(object sender, EventArgs e)
		{
			cmbDatabase.Items.Clear();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			LoadAllServers();
		}
	}
}
