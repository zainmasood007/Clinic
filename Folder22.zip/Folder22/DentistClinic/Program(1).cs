using System;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	internal static class Program
	{
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(defaultValue: false);
			string text = null;
			text = Settings.Default.Language;
			if (string.IsNullOrEmpty(text) || text.Contains("\r\n"))
			{
				text = "ar-EG";
			}
			CultureInfo currentUICulture = CultureInfo.CreateSpecificCulture(text);
			Thread.CurrentThread.CurrentUICulture = currentUICulture;
			Splash.Instance = new Splash();
			Application.Run(Splash.Instance);
		}
	}
}
