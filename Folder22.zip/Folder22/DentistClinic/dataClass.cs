using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing.Drawing2D;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using DentistClinic.Properties;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;

namespace DentistClinic
{
	public class dataClass
	{
		private static Server srvSql2;

		private SqlConnection cn = new SqlConnection();

		private SqlCommand cmd = new SqlCommand();

		private string connectionStr;

		public bool mov;

		public static string text;

		public int x;

		private int height;

		public int y;

		public string ConnectionStr => connectionStr;

		public dataClass(string ComputerName)
		{
			connectionStr = (cn.ConnectionString = "Data Source=" + ComputerName + ";AttachDbFilename=" + Application.StartupPath + "\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
			cmd.Connection = cn;
			cnnect();
		}

		private void cnnect()
		{
			try
			{
				if (cn.State != ConnectionState.Open)
				{
					cn.Open();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
			}
		}

		private bool RunSQL(string comdmandText)
		{
			cmd.CommandType = CommandType.Text;
			cmd.CommandText = comdmandText;
			cmd.Connection = cn;
			cnnect();
			if (cmd.ExecuteNonQuery() > 0)
			{
				return true;
			}
			return false;
		}

		public string SearchText(string labelText)
		{
			FrmSearch frmSearch = new FrmSearch(labelText);
			frmSearch.ShowDialog();
			return text;
		}

		public string SearchService(string labelText)
		{
			FrmSearchService frmSearchService = new FrmSearchService(labelText);
			frmSearchService.ShowDialog();
			return text;
		}

		public static string Encrypt(string toEncrypt)
		{
			byte[] bytes = Encoding.UTF8.GetBytes(toEncrypt);
			AppSettingsReader appSettingsReader = new AppSettingsReader();
			string s = (string)appSettingsReader.GetValue("Security", typeof(string));
			MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider();
			byte[] key = mD5CryptoServiceProvider.ComputeHash(Encoding.UTF8.GetBytes(s));
			mD5CryptoServiceProvider.Clear();
			TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider();
			tripleDESCryptoServiceProvider.Key = key;
			tripleDESCryptoServiceProvider.Mode = CipherMode.ECB;
			tripleDESCryptoServiceProvider.Padding = PaddingMode.PKCS7;
			ICryptoTransform cryptoTransform = tripleDESCryptoServiceProvider.CreateEncryptor();
			byte[] array = cryptoTransform.TransformFinalBlock(bytes, 0, bytes.Length);
			tripleDESCryptoServiceProvider.Clear();
			return Convert.ToBase64String(array, 0, array.Length);
		}

		public static string Decrypt(string cipherString)
		{
			byte[] array = Convert.FromBase64String(cipherString);
			AppSettingsReader appSettingsReader = new AppSettingsReader();
			string s = (string)appSettingsReader.GetValue("Security", typeof(string));
			MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider();
			byte[] key = mD5CryptoServiceProvider.ComputeHash(Encoding.UTF8.GetBytes(s));
			mD5CryptoServiceProvider.Clear();
			TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider();
			tripleDESCryptoServiceProvider.Key = key;
			tripleDESCryptoServiceProvider.Mode = CipherMode.ECB;
			tripleDESCryptoServiceProvider.Padding = PaddingMode.PKCS7;
			ICryptoTransform cryptoTransform = tripleDESCryptoServiceProvider.CreateDecryptor();
			byte[] bytes = cryptoTransform.TransformFinalBlock(array, 0, array.Length);
			tripleDESCryptoServiceProvider.Clear();
			return Encoding.UTF8.GetString(bytes);
		}

		public void Add(string Insertcmdmand)
		{
			try
			{
				if (RunSQL(Insertcmdmand))
				{
					if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Save Data successfully", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else
				{
					MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
				MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		public void Edit(string Updatecmdmand)
		{
			try
			{
				if (RunSQL(Updatecmdmand))
				{
					if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Edit Data successfully", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم تعديل البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else
				{
					MessageBox.Show("حدث خطأ أثناء تعديل البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
				MessageBox.Show("حدث خطأ أثناء تعديل البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		public void Delete(string Deletecmdmand)
		{
			try
			{
				if (MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
				{
					return;
				}
				if (RunSQL(Deletecmdmand))
				{
					if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Delete Data successfully", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else
				{
					MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
				MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		public DataTable Search(string Selectcmdmand)
		{
			DataTable dataTable = new DataTable();
			try
			{
				cmd.CommandType = CommandType.Text;
				cmd.CommandText = Selectcmdmand;
				cmd.Connection = cn;
				SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(cmd);
				cnnect();
				sqlDataAdapter.Fill(dataTable);
				if (dataTable.Rows.Count == 0)
				{
					MessageBox.Show("لم يتم العثور على البيانات المطلوبة", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				return dataTable;
			}
			catch
			{
				MessageBox.Show("حدث خطأ أثناء البحث عن البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return dataTable;
			}
		}

		public SqlDataAdapter SearchDataAdapter(string Selectcmdmand)
		{
			SqlDataAdapter result = new SqlDataAdapter();
			new DataTable();
			try
			{
				cmd.CommandType = CommandType.Text;
				cmd.CommandText = Selectcmdmand;
				cmd.Connection = cn;
				SqlDataAdapter result2 = new SqlDataAdapter(cmd);
				cnnect();
				return result2;
			}
			catch
			{
				MessageBox.Show("حدث خطأ أثناء البحث عن البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return result;
			}
		}

		public static GraphicsPath DrawRoundRect(float x, float y, float width, float height, float radius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			graphicsPath.AddLine(x + radius, y, x + width - radius * 2f, y);
			graphicsPath.AddArc(x + width - radius * 2f, y, radius * 2f, radius * 2f, 270f, 90f);
			graphicsPath.AddLine(x + width, y + radius, x + width, y + height - radius * 2f);
			graphicsPath.AddArc(x + width - radius * 2f, y + height - radius * 2f, radius * 2f, radius * 2f, 0f, 90f);
			graphicsPath.AddLine(x + width - radius * 2f, y + height, x + radius, y + height);
			graphicsPath.AddArc(x, y + height - radius * 2f, radius * 2f, radius * 2f, 90f, 90f);
			graphicsPath.AddLine(x, y + height - radius * 2f, x, y + radius);
			graphicsPath.AddArc(x, y, radius * 2f, radius * 2f, 180f, 90f);
			return graphicsPath;
		}

		public void Showdata(Form FormName, int Height, DataGridView GridName)
		{
			if (FormName.Height == Height)
			{
				FormName.Height = GridName.Location.Y;
			}
			else
			{
				FormName.Height = Height;
			}
		}

		public void FillDataGrid(DataGridView GridName, string SelectText)
		{
			GridName.DataSource = Search(SelectText);
			GridName.Refresh();
		}

		public void Add2(string Insertcmdmand)
		{
			RunSQL(Insertcmdmand);
		}

		public void Edit2(string Updatecmdmand)
		{
			RunSQL(Updatecmdmand);
		}

		public DataTable Search2(string Selectcmdmand)
		{
			DataTable dataTable = new DataTable();
			try
			{
				cmd.CommandType = CommandType.Text;
				cmd.CommandText = Selectcmdmand;
				cmd.Connection = cn;
				SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(cmd);
				cnnect();
				sqlDataAdapter.Fill(dataTable);
				return dataTable;
			}
			catch
			{
				return dataTable;
			}
		}

		public void FillDataGrid2(DataGridView GridName, string SelectText)
		{
			GridName.DataSource = Search2(SelectText);
			GridName.Refresh();
		}

		public void FillList(ListBox ListName, string SelectText)
		{
			DataTable dataTable = Search2(SelectText);
			ListName.Items.Clear();
			for (int i = 0; i < dataTable.Rows.Count; i++)
			{
				ListName.Items.Add(dataTable.Rows[i][0].ToString());
			}
		}

		public bool Update(string StoredProc, string[] Fields, params object[] Paramteres)
		{
			for (int i = 0; i < Fields.Length; i++)
			{
				switch (Paramteres[i].GetType().ToString())
				{
				case "System.String":
					cmd.Parameters.Add("@" + Fields[i].ToString(), SqlDbType.VarChar).Value = Paramteres[i];
					break;
				case "System.DateTime":
					cmd.Parameters.Add("@" + Fields[i].ToString(), SqlDbType.DateTime).Value = Paramteres[i];
					break;
				case "System.Int16":
				case "System.Int32":
					cmd.Parameters.Add("@" + Fields[i].ToString(), SqlDbType.Int).Value = Paramteres[i];
					break;
				case "System.Int64":
					cmd.Parameters.Add("@" + Fields[i].ToString(), SqlDbType.BigInt).Value = Paramteres[i];
					break;
				case "System.Double":
				case "System.Decimal":
					cmd.Parameters.Add("@" + Fields[i].ToString(), SqlDbType.Decimal).Value = Paramteres[i];
					break;
				case "System.Array":
				case "System.Byte[]":
					cmd.Parameters.Add("@" + Fields[i].ToString(), SqlDbType.VarBinary).Value = Paramteres[i];
					break;
				case "System.Boolean":
					cmd.Parameters.Add("@" + Fields[i].ToString(), SqlDbType.Bit).Value = Paramteres[i];
					break;
				case "System.Byte":
					cmd.Parameters.Add("@" + Fields[i].ToString(), SqlDbType.TinyInt).Value = Paramteres[i];
					break;
				case "System.Object":
					cmd.Parameters.Add("@" + Fields[i].ToString(), SqlDbType.Variant).Value = Paramteres[i];
					break;
				case "System.Single":
					cmd.Parameters.Add("@" + Fields[i].ToString(), SqlDbType.Real).Value = Paramteres[i];
					break;
				case "System.Guid":
					cmd.Parameters.Add("@" + Fields[i].ToString(), SqlDbType.UniqueIdentifier).Value = Paramteres[i];
					break;
				}
			}
			bool result = RunSql(StoredProc);
			cmd.Parameters.Clear();
			return result;
		}

		private bool RunSql(string StoredProc)
		{
			try
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.CommandText = StoredProc;
				cnnect();
				if (cmd.ExecuteNonQuery() > 0)
				{
					return true;
				}
				return false;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Error");
				return false;
			}
		}

		public void Delete2(string Deletecmdmand)
		{
			try
			{
				RunSQL(Deletecmdmand);
			}
			catch
			{
			}
		}

		public void Backup()
		{
			try
			{
				ServerConnection serverConnection = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName);
				serverConnection.LoginSecure = false;
				serverConnection.Login = DentistClinic.Properties.Settings.Default.UserName;
				serverConnection.Password = DentistClinic.Properties.Settings.Default.Pass;
				serverConnection.DatabaseName = DentistClinic.Properties.Settings.Default.DataBaseName;
				srvSql2 = new Server(serverConnection);
				if (srvSql2 != null)
				{
					DentistClinic.Properties.Settings.Default.Filename = Application.StartupPath;
					DentistClinic.Properties.Settings.Default.Save();
					Backup backup = new Backup();
					backup.BackupSetDescription = "ArchiveDataBase:" + DateTime.Now.ToShortDateString();
					backup.BackupSetName = "Archive";
					backup.Action = BackupActionType.Database;
					backup.Database = DentistClinic.Properties.Settings.Default.DataBaseName;
					string name = Application.StartupPath + "\\Backup\\Backup" + DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year + "   " + DateTime.Now.Hour + "-" + DateTime.Now.Minute + "-" + DateTime.Now.Second + ".bak";
					BackupDeviceItem item = new BackupDeviceItem(name, DeviceType.File);
					ServerConnection serverConnection2 = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName, DentistClinic.Properties.Settings.Default.UserName, DentistClinic.Properties.Settings.Default.Pass);
					Server server = new Server(serverConnection2);
					_ = server.Databases[DentistClinic.Properties.Settings.Default.DataBaseName];
					backup.Initialize = true;
					backup.Checksum = true;
					backup.ContinueAfterError = true;
					backup.Devices.Add(item);
					backup.Incremental = false;
					backup.ExpirationDate = DateTime.Now.AddDays(3.0);
					backup.LogTruncation = BackupTruncateLogType.Truncate;
					backup.FormatMedia = false;
					if (!Directory.Exists(Application.StartupPath + "\\Backup"))
					{
						Directory.CreateDirectory(Application.StartupPath + "\\Backup");
					}
					backup.SqlBackup(srvSql2);
				}
			}
			catch
			{
				try
				{
					ServerConnection serverConnection = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName);
					serverConnection.LoginSecure = false;
					serverConnection.Login = DentistClinic.Properties.Settings.Default.UserName;
					serverConnection.Password = DentistClinic.Properties.Settings.Default.Pass;
					serverConnection.DatabaseName = DentistClinic.Properties.Settings.Default.DataBaseName;
					srvSql2 = new Server(serverConnection);
					if (srvSql2 != null)
					{
						Backup backup = new Backup();
						backup.BackupSetDescription = "ArchiveDataBase:" + DateTime.Now.ToShortDateString();
						backup.BackupSetName = "Archive";
						backup.Action = BackupActionType.Database;
						backup.Database = DentistClinic.Properties.Settings.Default.DataBaseName;
						string text = "\\Backup" + DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year + "   " + DateTime.Now.Hour + "-" + DateTime.Now.Minute + "-" + DateTime.Now.Second + ".bak";
						string name = "\\\\" + srvSql2.ComputerNamePhysicalNetBIOS + "\\EasyStoreBackups" + text;
						BackupDeviceItem item = new BackupDeviceItem(name, DeviceType.File);
						ServerConnection serverConnection2 = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName, DentistClinic.Properties.Settings.Default.UserName, DentistClinic.Properties.Settings.Default.Pass);
						Server server = new Server(serverConnection2);
						_ = server.Databases[DentistClinic.Properties.Settings.Default.DataBaseName];
						backup.Initialize = true;
						backup.Checksum = true;
						backup.ContinueAfterError = true;
						backup.Devices.Add(item);
						backup.Incremental = false;
						backup.ExpirationDate = DateTime.Now.AddDays(3.0);
						backup.LogTruncation = BackupTruncateLogType.Truncate;
						backup.FormatMedia = false;
						backup.SqlBackup(srvSql2);
						File.Copy(name, DentistClinic.Properties.Settings.Default.Filename + text);
					}
				}
				catch
				{
				}
			}
		}
	}
}
