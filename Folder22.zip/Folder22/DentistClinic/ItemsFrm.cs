using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class ItemsFrm : BaseForm
	{
		private dataClass codes;

		private GUI gui = new GUI();

		private int id;

		private Main ownerForm = null;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private decimal saleprice;

		public static string text;

		private IContainer components = null;

		private TextBox nameTextBox;

		private GroupBox groupBox1;

		private Button AddBtn;

		private Button SearchBtn;

		private Button EditBtn;

		private Button DeleteBtn;

		private GroupBox groupBox2;

		private DataGridView dataGridView1;

		private Button button1;

		private TextBox textBarcode;

		private TextBox LimitOrder;

		private TextBox qntText;

		private TextBox salePriceFloatText;

		private TextBox buyPriceFloatText;

		public ItemsFrm()
		{
			InitializeComponent();
			codes = new dataClass(".\\sqlExpress");
		}

		public void Clear()
		{
			qntText.Enabled = true;
			buyPriceFloatText.Enabled = true;
			EditBtn.Enabled = false;
			DeleteBtn.Enabled = false;
			AddBtn.Enabled = true;
			nameTextBox.Text = "";
			salePriceFloatText.Text = "0";
			buyPriceFloatText.Text = "0";
			qntText.Text = "0";
			LimitOrder.Text = "0";
			textBarcode.Text = "";
			LoadData();
			textBarcode.ReadOnly = Convert.ToBoolean(codes.Search2("select AutoAsnaf from Properties").Rows[0][0]);
			if (textBarcode.ReadOnly)
			{
				textBarcode.Text = codes.Search2("select isnull(max(Barcode)+ 1,1) from Items").Rows[0][0].ToString();
				nameTextBox.Focus();
			}
			else
			{
				textBarcode.Focus();
			}
		}

		public void DataGrid()
		{
			dataGridView1.Columns[0].Visible = false;
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView1.Columns[1].HeaderText = "Item Name";
				dataGridView1.Columns[3].HeaderText = "Buy Price";
				dataGridView1.Columns[4].HeaderText = "First Period Balance";
				dataGridView1.Columns[5].HeaderText = "Minimum";
				dataGridView1.Columns[6].HeaderText = "Barcode";
			}
			else
			{
				dataGridView1.Columns[1].HeaderText = "اسم الصنف";
				dataGridView1.Columns[3].HeaderText = "سعر الشراء";
				dataGridView1.Columns[4].HeaderText = "رصيد اول المدة";
				dataGridView1.Columns[5].HeaderText = "الحد الأدنى";
				dataGridView1.Columns[6].HeaderText = "الباركود";
			}
			dataGridView1.Columns[1].Width = 200;
			dataGridView1.Columns[2].Visible = false;
		}

		public void LoadData()
		{
			try
			{
				DataTable dataSource = codes.Search2("SELECT Items.Id, Items.Name, Items.SalePrice, Store.BuyPrice, Store.Qnt,Items.LimitOrder,Items.Barcode FROM Store INNER JOIN  Items ON Store.ItemId = Items.Id ");
				dataGridView1.DataSource = dataSource;
				DataGrid();
			}
			catch
			{
			}
		}

		private void ItemsFrm_Load(object sender, EventArgs e)
		{
			textBarcode.ReadOnly = Convert.ToBoolean(codes.Search2("select AutoAsnaf from Properties").Rows[0][0]);
			if (textBarcode.ReadOnly)
			{
				textBarcode.Text = codes.Search2("select isnull(max(Barcode)+ 1,1) from Items").Rows[0][0].ToString();
				nameTextBox.Focus();
			}
			else
			{
				textBarcode.TabIndex = 0;
				textBarcode.Focus();
			}
			LoadData();
		}

		private void AddBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select * from Items where Name='" + nameTextBox.Text + "'");
				DataTable dataTable2 = codes.Search2("select * from Items where Barcode='" + textBarcode.Text + "'");
				if (nameTextBox.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل الإسم");
					}
					return;
				}
				if (textBarcode.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Barcode");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل الباركود");
					}
					return;
				}
				if (dataTable2.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This Barcode Before");
					}
					else
					{
						MessageBox.Show("هذا الباركود مسجل من قبل");
					}
					return;
				}
				if (dataTable.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This Name Before");
					}
					else
					{
						MessageBox.Show("هذا الإسم مسجل من قبل");
					}
					return;
				}
				codes.Add2("INSERT INTO Items(Name, SalePrice,LimitOrder,Barcode)VALUES('" + nameTextBox.Text + "','" + salePriceFloatText.Text + "','" + LimitOrder.Text + "','" + textBarcode.Text + "')");
				DataTable dataTable3 = codes.Search2("select Id from Items Where Name='" + nameTextBox.Text + "'");
				int num = Convert.ToInt32(dataTable3.Rows[0][0].ToString());
				codes.Add2("INSERT INTO Store (ItemId, Qnt, BuyPrice) VALUES('" + num + "','" + qntText.Text + "','" + buyPriceFloatText.Text + "')");
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				MethodsClass.UserMove(" أضافة صنف جديد");
				Clear();
			}
			catch
			{
			}
		}

		private void SearchBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dt = codes.Search2("SELECT Items.Id, Items.Name, Items.SalePrice, Store.BuyPrice, Store.Qnt,Items.LimitOrder,Items.Barcode FROM Store INNER JOIN  Items ON Store.ItemId = Items.Id where Items.Name like  '%" + codes.SearchText("بحث باسم الصنف") + "%'");
				gui.loadDataGrid(dataGridView1, dt);
				DataGrid();
			}
			catch
			{
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select * from Items where Name='" + nameTextBox.Text + "' and Id<>" + id);
				DataTable dataTable2 = codes.Search2("select * from Items where Barcode='" + textBarcode.Text + "' and Id<>" + id);
				if (nameTextBox.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل الإسم");
					}
					return;
				}
				if (textBarcode.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Barcode");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل الباركود");
					}
					return;
				}
				if (dataTable2.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This Barcode Before");
					}
					else
					{
						MessageBox.Show("هذا الباركود مسجل من قبل");
					}
					return;
				}
				if (dataTable.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Have Save This Name Before");
					}
					else
					{
						MessageBox.Show("هذا الإسم مسجل من قبل");
					}
					return;
				}
				codes.Edit2("UPDATE Items SET Name ='" + nameTextBox.Text + "', SalePrice ='" + salePriceFloatText.Text + "',LimitOrder = '" + LimitOrder.Text + "',Barcode = '" + textBarcode.Text + "' where id=" + id);
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Updated Successfully", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("تم تعديل البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				MethodsClass.UserMove(" تعديل صنف ");
				DataTable dataTable3 = codes.Search2("select Id from Items where Name='" + nameTextBox.Text + "'");
				codes.Edit2("Update Store set BuyPrice = '" + buyPriceFloatText.Text + "' where ItemId = '" + Convert.ToInt32(dataTable3.Rows[0][0].ToString()) + "'");
				qntText.Enabled = true;
				buyPriceFloatText.Enabled = true;
				EditBtn.Enabled = false;
				DeleteBtn.Enabled = false;
				Clear();
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				qntText.Enabled = false;
				buyPriceFloatText.Enabled = true;
				EditBtn.Enabled = true;
				DeleteBtn.Enabled = true;
				AddBtn.Enabled = false;
				id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
				nameTextBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
				salePriceFloatText.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
				buyPriceFloatText.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
				qntText.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
				saleprice = Convert.ToDecimal(dataGridView1.CurrentRow.Cells[2].Value.ToString());
				LimitOrder.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
				textBarcode.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Clear();
		}

		private void salePriceFloatText_Validating(object sender, CancelEventArgs e)
		{
			try
			{
				if (Convert.ToDecimal(salePriceFloatText.Text) < Convert.ToDecimal(buyPriceFloatText.Text))
				{
					if (AddBtn.Enabled)
					{
						MessageBox.Show("سعر البيع اكبر من سعر الشراء");
						salePriceFloatText.Text = buyPriceFloatText.Text;
					}
					else
					{
						MessageBox.Show("سعر البيع اكبر من سعر الشراء");
						salePriceFloatText.Text = saleprice.ToString();
					}
				}
			}
			catch
			{
			}
		}

		private void LimitOrder_TextChanged(object sender, EventArgs e)
		{
			if (LimitOrder.Text == "")
			{
				LimitOrder.Text = "0";
			}
		}

		private void ItemsFrm_FormClosing(object sender, FormClosingEventArgs e)
		{
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dt = codes.Search2("SELECT Items.Id, Items.Name, Items.SalePrice, Store.BuyPrice, Store.Qnt,Items.LimitOrder,Items.Barcode FROM Store INNER JOIN  Items ON Store.ItemId = Items.Id where Items.Barcode =  '" + codes.SearchText("بحث باسم الباركود") + "'");
				gui.loadDataGrid(dataGridView1, dt);
				DataGrid();
			}
			catch
			{
			}
		}

		private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == '\r' || e.KeyChar == '\t')
			{
				nameTextBox.Focus();
			}
		}

		private void nameTextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == '\r' || e.KeyChar == '\t')
			{
				buyPriceFloatText.Focus();
			}
		}

		private void buyPriceFloatText_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == '\r' || e.KeyChar == '\t')
			{
				salePriceFloatText.Focus();
			}
			else if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
			{
				if (e.KeyChar == '.' && buyPriceFloatText.Text.Contains("."))
				{
					e.Handled = true;
				}
			}
			else
			{
				e.Handled = true;
				MessageBox.Show("من فضلك أدخل أرقام");
			}
		}

		private void salePriceFloatText_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == '\r' || e.KeyChar == '\t')
			{
				qntText.Focus();
			}
			else if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
			{
				if (e.KeyChar == '.' && salePriceFloatText.Text.Contains("."))
				{
					e.Handled = true;
				}
			}
			else
			{
				e.Handled = true;
				MessageBox.Show("من فضلك أدخل أرقام");
			}
		}

		private void qntText_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == '\r' || e.KeyChar == '\t')
			{
				LimitOrder.Focus();
			}
			else if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
			{
				if (e.KeyChar == '.' && qntText.Text.Contains("."))
				{
					e.Handled = true;
				}
			}
			else
			{
				e.Handled = true;
				MessageBox.Show("من فضلك أدخل أرقام");
			}
		}

		private void LimitOrder_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == '\r' || e.KeyChar == '\t')
			{
				AddBtn.Focus();
			}
			else if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
			{
				if (e.KeyChar == '.' && LimitOrder.Text.Contains("."))
				{
					e.Handled = true;
				}
			}
			else
			{
				e.Handled = true;
				MessageBox.Show("من فضلك أدخل أرقام");
			}
		}

		private void DeleteBtn_Click(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.ItemsFrm));
			nameTextBox = new System.Windows.Forms.TextBox();
			groupBox1 = new System.Windows.Forms.GroupBox();
			LimitOrder = new System.Windows.Forms.TextBox();
			qntText = new System.Windows.Forms.TextBox();
			salePriceFloatText = new System.Windows.Forms.TextBox();
			buyPriceFloatText = new System.Windows.Forms.TextBox();
			textBarcode = new System.Windows.Forms.TextBox();
			AddBtn = new System.Windows.Forms.Button();
			SearchBtn = new System.Windows.Forms.Button();
			EditBtn = new System.Windows.Forms.Button();
			DeleteBtn = new System.Windows.Forms.Button();
			groupBox2 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			button1 = new System.Windows.Forms.Button();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			resources.ApplyResources(label, "nameLabel");
			label.BackColor = System.Drawing.Color.Transparent;
			label.Name = "nameLabel";
			resources.ApplyResources(label2, "salePriceLabel");
			label2.BackColor = System.Drawing.Color.Transparent;
			label2.Name = "salePriceLabel";
			resources.ApplyResources(label3, "buyPriceLabel");
			label3.BackColor = System.Drawing.Color.Transparent;
			label3.Name = "buyPriceLabel";
			resources.ApplyResources(label4, "label1");
			label4.BackColor = System.Drawing.Color.Transparent;
			label4.Name = "label1";
			resources.ApplyResources(label5, "label2");
			label5.BackColor = System.Drawing.Color.Transparent;
			label5.Name = "label2";
			resources.ApplyResources(label6, "label3");
			label6.BackColor = System.Drawing.Color.Transparent;
			label6.Name = "label3";
			resources.ApplyResources(nameTextBox, "nameTextBox");
			nameTextBox.Name = "nameTextBox";
			nameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(nameTextBox_KeyPress);
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(LimitOrder);
			groupBox1.Controls.Add(qntText);
			groupBox1.Controls.Add(salePriceFloatText);
			groupBox1.Controls.Add(buyPriceFloatText);
			groupBox1.Controls.Add(textBarcode);
			groupBox1.Controls.Add(label6);
			groupBox1.Controls.Add(label5);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(nameTextBox);
			groupBox1.Controls.Add(label);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(label2);
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			resources.ApplyResources(LimitOrder, "LimitOrder");
			LimitOrder.Name = "LimitOrder";
			LimitOrder.Leave += new System.EventHandler(LimitOrder_TextChanged);
			LimitOrder.KeyPress += new System.Windows.Forms.KeyPressEventHandler(LimitOrder_KeyPress);
			resources.ApplyResources(qntText, "qntText");
			qntText.Name = "qntText";
			qntText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(qntText_KeyPress);
			resources.ApplyResources(salePriceFloatText, "salePriceFloatText");
			salePriceFloatText.Name = "salePriceFloatText";
			salePriceFloatText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(salePriceFloatText_KeyPress);
			salePriceFloatText.Validating += new System.ComponentModel.CancelEventHandler(salePriceFloatText_Validating);
			resources.ApplyResources(buyPriceFloatText, "buyPriceFloatText");
			buyPriceFloatText.Name = "buyPriceFloatText";
			buyPriceFloatText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(buyPriceFloatText_KeyPress);
			resources.ApplyResources(textBarcode, "textBarcode");
			textBarcode.Name = "textBarcode";
			textBarcode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(textBox1_KeyPress);
			AddBtn.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(AddBtn, "AddBtn");
			AddBtn.Name = "AddBtn";
			AddBtn.UseVisualStyleBackColor = false;
			AddBtn.Click += new System.EventHandler(AddBtn_Click);
			SearchBtn.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(SearchBtn, "SearchBtn");
			SearchBtn.Name = "SearchBtn";
			SearchBtn.UseVisualStyleBackColor = false;
			SearchBtn.Click += new System.EventHandler(SearchBtn_Click);
			EditBtn.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(EditBtn, "EditBtn");
			EditBtn.Name = "EditBtn";
			EditBtn.UseVisualStyleBackColor = false;
			EditBtn.Click += new System.EventHandler(EditBtn_Click);
			DeleteBtn.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(DeleteBtn, "DeleteBtn");
			DeleteBtn.Name = "DeleteBtn";
			DeleteBtn.UseVisualStyleBackColor = false;
			DeleteBtn.Click += new System.EventHandler(DeleteBtn_Click);
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(dataGridView1);
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseClick);
			button1.BackColor = System.Drawing.Color.Gainsboro;
			resources.ApplyResources(button1, "button1");
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(button1);
			base.Controls.Add(groupBox2);
			base.Controls.Add(EditBtn);
			base.Controls.Add(SearchBtn);
			base.Controls.Add(AddBtn);
			base.Controls.Add(groupBox1);
			base.Controls.Add(DeleteBtn);
			base.Name = "ItemsFrm";
			base.Load += new System.EventHandler(ItemsFrm_Load);
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(ItemsFrm_FormClosing);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
		}
	}
}
