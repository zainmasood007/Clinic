using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class StockUsersFrm : BaseForm
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		private IContainer components = null;

		private Label label1;

		private ComboBox comboBox1;

		private DataGridView dataGridView1;

		private Button button1;

		public StockUsersFrm()
		{
			InitializeComponent();
		}

		public void LoadGrid()
		{
			try
			{
				DataTable dataSource = Codes.Search2("select Id,Name FROM Stock");
				dataGridView1.DataSource = null;
				dataGridView1.Columns.Clear();
				dataGridView1.DataSource = dataSource;
				dataGridView1.Columns[0].Visible = false;
				if (Settings.Default.Language == "en-GB")
				{
					dataGridView1.Columns[1].HeaderText = "Treasury Name";
				}
				else
				{
					dataGridView1.Columns[1].HeaderText = "اسم الخزينة";
				}
				dataGridView1.Columns[1].Width = 300;
				dataGridView1.Columns[1].ReadOnly = true;
				DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn = new DataGridViewCheckBoxColumn();
				if (Settings.Default.Language == "en-GB")
				{
					dataGridViewCheckBoxColumn.HeaderText = "Status";
				}
				else
				{
					dataGridViewCheckBoxColumn.HeaderText = "الحالة";
				}
				dataGridViewCheckBoxColumn.Name = "Statss";
				dataGridView1.Columns.Add(dataGridViewCheckBoxColumn);
			}
			catch
			{
			}
		}

		public void LoadUser()
		{
			try
			{
				DataTable dataTable = Codes.Search2("select * from users ");
				comboBox1.DataSource = null;
				DataRow dataRow = dataTable.NewRow();
				if (Settings.Default.Language == "en-GB")
				{
					dataRow["userName"] = "<-Choose->";
				}
				else
				{
					dataRow["userName"] = "<-اختر->";
				}
				comboBox1.SelectedIndex = -1;
				dataTable.Rows.InsertAt(dataRow, 0);
				comboBox1.DataSource = dataTable;
				comboBox1.DisplayMember = dataTable.Columns[2].ToString();
				comboBox1.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void StockUsersFrm_Load(object sender, EventArgs e)
		{
			try
			{
				LoadUser();
				LoadGrid();
			}
			catch
			{
			}
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					DataTable dataTable = Codes.Search2("select Status from UserStock where UserId='" + comboBox1.SelectedValue.ToString() + "' and StockId='" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "'");
					if (dataTable.Rows.Count > 0)
					{
						dataGridView1.Rows[i].Cells[2].Value = Convert.ToBoolean(dataTable.Rows[0][0].ToString());
					}
					else
					{
						dataGridView1.Rows[i].Cells[2].Value = false;
					}
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				bool flag = false;
				if (dataGridView1.Rows.Count == 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("There are no Treasury for this user");
					}
					else
					{
						MessageBox.Show("لايوجد خزائن لهذا المستخدم");
					}
					return;
				}
				if (comboBox1.SelectedItem == null)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Choose User Name");
					}
					else
					{
						MessageBox.Show("من فضلك قم باختيار اسم مستخدم صحيح");
					}
					return;
				}
				try
				{
					Codes.Delete2("delete from UserStock where UserId='" + comboBox1.SelectedValue.ToString() + "'");
				}
				catch
				{
				}
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					Codes.Add2("INSERT INTO UserStock (UserId, StockId,Status)VALUES ('" + comboBox1.SelectedValue.ToString() + "','" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "')");
					flag = true;
				}
				if (flag)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Data Saved Successfully");
					}
					else
					{
						MessageBox.Show("تمت عملية الاضافة بنجاح");
					}
					MethodsClass.UserMove("أضافة خزينة لمستخدم");
					LoadGrid();
					LoadUser();
				}
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.StockUsersFrm));
			label1 = new System.Windows.Forms.Label();
			comboBox1 = new System.Windows.Forms.ComboBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			button1 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.BackColor = System.Drawing.Color.Transparent;
			label1.Font = null;
			label1.Name = "label1";
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.BackgroundImage = null;
			comboBox1.Font = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Name = "comboBox1";
			comboBox1.SelectedIndexChanged += new System.EventHandler(comboBox1_SelectedIndexChanged);
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(button1);
			base.Controls.Add(dataGridView1);
			base.Controls.Add(comboBox1);
			base.Controls.Add(label1);
			Font = null;
			base.Name = "StockUsersFrm";
			base.Load += new System.EventHandler(StockUsersFrm_Load);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
