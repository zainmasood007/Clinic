using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using FloatTextBox;

namespace DentistClinic
{
	public class FrmSarfFreeSample : BaseForm
	{
		private ClassDataBase dc = new ClassDataBase(".\\sqlExpress");

		private string patientId;

		private string doctorId;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GUI gui = new GUI();

		private IContainer components = null;

		private ComboBox doctorcomboBox;

		private GroupBox groupBox21;

		private ComboBox PatientComboBox;

		private DateTimePicker appdateTimePicker1;

		private GroupBox groupBox3;

		private DataGridView dataGridView1;

		private GroupBox groupBox1;

		private Button button1;

		private FloatText qntFloatText;

		private Label label3;

		private Label label4;

		private ComboBox comboBox1;

		private Button button2;

		private Label label2;

		private Label label1;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Column2;

		public FrmSarfFreeSample()
		{
			InitializeComponent();
		}

		public FrmSarfFreeSample(string s1, string s2)
		{
			InitializeComponent();
			patientId = s1;
			doctorId = s2;
		}

		private void FrmSarfFreeSample_Load(object sender, EventArgs e)
		{
			DataTable dataTable = new DataTable();
			try
			{
				dataTable = codes.Search2("select MedicineName from FreeSamples");
				comboBox1.DataSource = dataTable;
				comboBox1.DisplayMember = "MedicineName";
			}
			catch
			{
			}
			try
			{
				dataTable = dc.Select("SelectAllDoctor");
				gui.loadComboBox(doctorcomboBox, dataTable);
			}
			catch
			{
			}
			try
			{
				dataTable = dc.Select("SelectAllPatient");
				gui.loadComboBox(PatientComboBox, dataTable);
			}
			catch
			{
			}
			doctorcomboBox.SelectedValue = doctorId;
			PatientComboBox.SelectedValue = patientId;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (comboBox1.SelectedIndex == -1)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Medicine Name");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم الدواء");
				}
				return;
			}
			if (qntFloatText.Text == "0")
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Quantity");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل الكمية");
				}
				return;
			}
			if (Convert.ToDecimal(qntFloatText.Text) > Convert.ToDecimal(label2.Text))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("The quantity is larger than the stock");
				}
				else
				{
					MessageBox.Show("الكمية اكبر من المخزون");
				}
				return;
			}
			if (dataGridView1.Rows.Count == 0)
			{
				dataGridView1.Rows.Add(comboBox1.Text, qntFloatText.Text);
			}
			else
			{
				bool flag = false;
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					if (comboBox1.Text == dataGridView1.Rows[i].Cells[0].Value.ToString())
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Have Save This Medicine Before");
						}
						else
						{
							MessageBox.Show("تم ادخال هذا الدواء من قبل");
						}
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					dataGridView1.Rows.Add(comboBox1.Text, qntFloatText.Text);
				}
			}
			comboBox1.Text = "";
			qntFloatText.Text = "0";
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.Rows.Count == 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Data");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل الادوية");
					}
					return;
				}
				codes.Add2("insert into SarfFreeSample (PatientId, DoctorID, Date) values('" + PatientComboBox.SelectedValue.ToString() + "','" + doctorcomboBox.SelectedValue.ToString() + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "')");
				string text = codes.Search2("select max(Id) from SarfFreeSample").Rows[0][0].ToString();
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					codes.Add2("insert into SarfMedicine (SarfId, MedicineName, Qty) values('" + text + "','" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[1].Value.ToString() + "')");
					codes.Edit2("update StoreMed set Qty = Qty - '" + dataGridView1.Rows[i].Cells[1].Value.ToString() + "' where MedicineName ='" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "'");
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2("select isnull(Qty,0) from StoreMed where MedicineName = '" + comboBox1.Text + "'");
			if (dataTable.Rows.Count > 0)
			{
				label2.Text = dataTable.Rows[0][0].ToString();
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmSarfFreeSample));
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			groupBox21 = new System.Windows.Forms.GroupBox();
			appdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			PatientComboBox = new System.Windows.Forms.ComboBox();
			groupBox3 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox1 = new System.Windows.Forms.GroupBox();
			this.label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			button1 = new System.Windows.Forms.Button();
			qntFloatText = new FloatTextBox.FloatText();
			this.label3 = new System.Windows.Forms.Label();
			label4 = new System.Windows.Forms.Label();
			comboBox1 = new System.Windows.Forms.ComboBox();
			button2 = new System.Windows.Forms.Button();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			groupBox21.SuspendLayout();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox1.SuspendLayout();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "nameLabel");
			label.Name = "nameLabel";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "titelLabel");
			label2.Name = "titelLabel";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "addressLabel");
			label3.Name = "addressLabel";
			doctorcomboBox.AccessibleDescription = null;
			doctorcomboBox.AccessibleName = null;
			resources.ApplyResources(doctorcomboBox, "doctorcomboBox");
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.BackgroundImage = null;
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Name = "doctorcomboBox";
			groupBox21.AccessibleDescription = null;
			groupBox21.AccessibleName = null;
			resources.ApplyResources(groupBox21, "groupBox21");
			groupBox21.BackColor = System.Drawing.Color.Transparent;
			groupBox21.BackgroundImage = null;
			groupBox21.Controls.Add(appdateTimePicker1);
			groupBox21.Controls.Add(label3);
			groupBox21.Controls.Add(label2);
			groupBox21.Controls.Add(PatientComboBox);
			groupBox21.Controls.Add(doctorcomboBox);
			groupBox21.Controls.Add(label);
			groupBox21.Font = null;
			groupBox21.Name = "groupBox21";
			groupBox21.TabStop = false;
			appdateTimePicker1.AccessibleDescription = null;
			appdateTimePicker1.AccessibleName = null;
			resources.ApplyResources(appdateTimePicker1, "appdateTimePicker1");
			appdateTimePicker1.BackgroundImage = null;
			appdateTimePicker1.CalendarFont = null;
			appdateTimePicker1.Font = null;
			appdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			appdateTimePicker1.Name = "appdateTimePicker1";
			PatientComboBox.AccessibleDescription = null;
			PatientComboBox.AccessibleName = null;
			resources.ApplyResources(PatientComboBox, "PatientComboBox");
			PatientComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			PatientComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientComboBox.BackgroundImage = null;
			PatientComboBox.FormattingEnabled = true;
			PatientComboBox.Name = "PatientComboBox";
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(dataGridView1);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(Column1, Column2);
			dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(this.label2);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(button1);
			groupBox1.Controls.Add(qntFloatText);
			groupBox1.Controls.Add(this.label3);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(comboBox1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			this.label2.AccessibleDescription = null;
			this.label2.AccessibleName = null;
			resources.ApplyResources(this.label2, "label2");
			this.label2.Font = null;
			this.label2.Name = "label2";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.Name = "label1";
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			qntFloatText.AccessibleDescription = null;
			qntFloatText.AccessibleName = null;
			resources.ApplyResources(qntFloatText, "qntFloatText");
			qntFloatText.BackgroundImage = null;
			qntFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			qntFloatText.Font = null;
			qntFloatText.Name = "qntFloatText";
			this.label3.AccessibleDescription = null;
			this.label3.AccessibleName = null;
			resources.ApplyResources(this.label3, "label3");
			this.label3.Font = null;
			this.label3.Name = "label3";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Font = null;
			label4.Name = "label4";
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.Font = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Name = "comboBox1";
			comboBox1.SelectedIndexChanged += new System.EventHandler(comboBox1_SelectedIndexChanged);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackColor = System.Drawing.Color.Gainsboro;
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = false;
			button2.Click += new System.EventHandler(button2_Click);
			resources.ApplyResources(Column1, "Column1");
			Column1.Name = "Column1";
			Column1.ReadOnly = true;
			resources.ApplyResources(Column2, "Column2");
			Column2.Name = "Column2";
			Column2.ReadOnly = true;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(button2);
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox21);
			Font = null;
			base.Name = "FrmSarfFreeSample";
			base.Load += new System.EventHandler(FrmSarfFreeSample_Load);
			groupBox21.ResumeLayout(false);
			groupBox21.PerformLayout();
			groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			ResumeLayout(false);
		}
	}
}
