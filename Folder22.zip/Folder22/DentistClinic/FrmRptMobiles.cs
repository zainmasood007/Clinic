using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace DentistClinic
{
	public class FrmRptMobiles : BaseForm
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		private string ID;

		private IContainer components = null;

		private GroupBox groupBox3;

		private DataGridView dataGridView1;

		private GroupBox groupBox2;

		private Button button4;

		private Button button3;

		private Button button2;

		private GroupBox groupBox1;

		private TextBox textBox1;

		private Label label1;

		public FrmRptMobiles()
		{
			InitializeComponent();
		}

		private void FrmRptMobiles_Load(object sender, EventArgs e)
		{
			try
			{
				Clear();
			}
			catch
			{
			}
		}

		private void Clear()
		{
			Codes.FillDataGrid2(dataGridView1, "select ID, MobileNo [رقم الموبايل] from RptMobiles");
			dataGridView1.Columns[0].Visible = false;
			textBox1.Text = "";
			button2.Visible = true;
			button3.Visible = false;
			button4.Visible = false;
			textBox1.Focus();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				if (textBox1.Text != "")
				{
					DataTable dataTable = Codes.Search2("select * from RptMobiles where MobileNo = '" + textBox1.Text + "'");
					if (dataTable.Rows.Count == 0)
					{
						Codes.Add("insert into RptMobiles (MobileNo) Values ('" + textBox1.Text + "')");
						Clear();
					}
					else if (dataTable.Rows.Count > 0)
					{
						MessageBox.Show("هذه الرقم مسجل من قبل", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
				else
				{
					MessageBox.Show("من فضلك أدخل رقم الموبايل", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				if (textBox1.Text != "")
				{
					DataTable dataTable = Codes.Search2("select * from RptMobiles where MobileNo = '" + textBox1.Text + "' and ID <> '" + ID + "'");
					if (dataTable.Rows.Count == 0)
					{
						Codes.Edit("update RptMobiles set MobileNo = '" + textBox1.Text + "' where ID = '" + ID + "'");
						Clear();
					}
					else if (dataTable.Rows.Count > 0)
					{
						MessageBox.Show("هذه الرقم مسجل من قبل", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
				else
				{
					MessageBox.Show("من فضلك أدخل رقم الموبايل", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
			}
		}

		private void button4_Click(object sender, EventArgs e)
		{
			try
			{
				if (MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
				{
					Codes.Delete2("delete from RptMobiles where ID = '" + ID + "'");
					Codes.Delete2("delete from RptMobileConfig where MobileID = '" + ID + "'");
					MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					Clear();
				}
			}
			catch
			{
				MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				ID = dataGridView1.CurrentRow.Cells[0].Value.ToString();
				textBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
				button3.Visible = true;
				button4.Visible = true;
				button2.Visible = false;
			}
			catch
			{
			}
		}

		private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar < '0' || e.KeyChar > '9') && e.KeyChar != '\b')
				{
					e.Handled = true;
				}
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmRptMobiles));
			groupBox3 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox2 = new System.Windows.Forms.GroupBox();
			button4 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			groupBox1 = new System.Windows.Forms.GroupBox();
			textBox1 = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox2.SuspendLayout();
			groupBox1.SuspendLayout();
			SuspendLayout();
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(dataGridView1);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(button4);
			groupBox2.Controls.Add(button3);
			groupBox2.Controls.Add(button2);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			button4.AccessibleDescription = null;
			button4.AccessibleName = null;
			resources.ApplyResources(button4, "button4");
			button4.BackgroundImage = null;
			button4.Font = null;
			button4.ForeColor = System.Drawing.Color.Black;
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = true;
			button4.Click += new System.EventHandler(button4_Click);
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackgroundImage = null;
			button3.Font = null;
			button3.ForeColor = System.Drawing.Color.Black;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.ForeColor = System.Drawing.Color.Black;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(textBox1);
			groupBox1.Controls.Add(label1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Font = null;
			textBox1.Name = "textBox1";
			textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(textBox1_KeyPress);
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.Name = "label1";
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Icon = null;
			base.Name = "FrmRptMobiles";
			base.Load += new System.EventHandler(FrmRptMobiles_Load);
			groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			ResumeLayout(false);
		}
	}
}
