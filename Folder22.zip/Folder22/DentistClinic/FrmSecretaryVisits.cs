using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmSecretaryVisits : BaseForm
	{
		private IContainer components = null;

		private Button DeletBtn;

		private GroupBox groupBox3;

		private Button button5;

		private Button button3;

		private Button button2;

		private Label label5;

		private Button button1;

		private Label label4;

		private Label label3;

		private GroupBox groupBox2;

		private ComboBox comboBox2;

		private Button searchBtn;

		private Label label2;

		private ComboBox doctorcomboBox;

		private Label label1;

		private DateTimePicker dateTimePicker1;

		private GroupBox groupBox1;

		private DataGridView dataGridView1;

		private Timer timer1;

		private DataSet1 dataSet11;

		private ClassDataBase dc = new ClassDataBase(".\\sqlExpress");

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GUI gui = new GUI();

		private int GridID;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmSecretaryVisits));
			DeletBtn = new System.Windows.Forms.Button();
			groupBox3 = new System.Windows.Forms.GroupBox();
			button5 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			label5 = new System.Windows.Forms.Label();
			button1 = new System.Windows.Forms.Button();
			label4 = new System.Windows.Forms.Label();
			label3 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			comboBox2 = new System.Windows.Forms.ComboBox();
			searchBtn = new System.Windows.Forms.Button();
			label2 = new System.Windows.Forms.Label();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			label1 = new System.Windows.Forms.Label();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			groupBox1 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			timer1 = new System.Windows.Forms.Timer(components);
			dataSet11 = new DataSet1();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			groupBox3.SuspendLayout();
			groupBox2.SuspendLayout();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "label7");
			label.Name = "label7";
			DeletBtn.AccessibleDescription = null;
			DeletBtn.AccessibleName = null;
			resources.ApplyResources(DeletBtn, "DeletBtn");
			DeletBtn.BackColor = System.Drawing.Color.Gainsboro;
			DeletBtn.BackgroundImage = null;
			DeletBtn.Name = "DeletBtn";
			DeletBtn.UseVisualStyleBackColor = false;
			DeletBtn.Click += new System.EventHandler(DeletBtn_Click);
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(button5);
			groupBox3.Controls.Add(button3);
			groupBox3.Controls.Add(button2);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			button5.AccessibleDescription = null;
			button5.AccessibleName = null;
			resources.ApplyResources(button5, "button5");
			button5.BackgroundImage = null;
			button5.Name = "button5";
			button5.UseVisualStyleBackColor = true;
			button5.Click += new System.EventHandler(button5_Click);
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackgroundImage = null;
			button3.FlatAppearance.BorderSize = 0;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.FlatAppearance.BorderSize = 0;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label5");
			label5.BackColor = System.Drawing.Color.Beige;
			label5.Font = null;
			label5.Name = "label5";
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.BackColor = System.Drawing.Color.Transparent;
			label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			label4.ForeColor = System.Drawing.Color.Maroon;
			label4.Name = "label4";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.BackColor = System.Drawing.Color.Transparent;
			label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			label3.ForeColor = System.Drawing.Color.Maroon;
			label3.Name = "label3";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(comboBox2);
			groupBox2.Controls.Add(label);
			groupBox2.Controls.Add(searchBtn);
			groupBox2.Controls.Add(label2);
			groupBox2.Controls.Add(doctorcomboBox);
			groupBox2.Controls.Add(label1);
			groupBox2.Controls.Add(dateTimePicker1);
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			comboBox2.AccessibleDescription = null;
			comboBox2.AccessibleName = null;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.BackgroundImage = null;
			comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox2.FormattingEnabled = true;
			comboBox2.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox2.Items"),
				resources.GetString("comboBox2.Items1")
			});
			comboBox2.Name = "comboBox2";
			searchBtn.AccessibleDescription = null;
			searchBtn.AccessibleName = null;
			resources.ApplyResources(searchBtn, "searchBtn");
			searchBtn.BackColor = System.Drawing.Color.Gainsboro;
			searchBtn.BackgroundImage = null;
			searchBtn.Name = "searchBtn";
			searchBtn.UseVisualStyleBackColor = false;
			searchBtn.Click += new System.EventHandler(searchBtn_Click);
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			doctorcomboBox.AccessibleDescription = null;
			doctorcomboBox.AccessibleName = null;
			resources.ApplyResources(doctorcomboBox, "doctorcomboBox");
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.BackgroundImage = null;
			doctorcomboBox.Font = null;
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Name = "doctorcomboBox";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.Font = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(dataGridView1);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowTemplate.Height = 30;
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseClick);
			timer1.Interval = 3000;
			timer1.Tick += new System.EventHandler(timer1_Tick);
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(label5);
			base.Controls.Add(DeletBtn);
			base.Controls.Add(groupBox3);
			base.Controls.Add(label4);
			base.Controls.Add(label3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.Controls.Add(button1);
			Font = null;
			base.KeyPreview = true;
			base.Name = "FrmSecretaryVisits";
			base.Load += new System.EventHandler(FrmSecretaryVisits_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(FrmSecretaryVisits_KeyDown);
			groupBox3.ResumeLayout(false);
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		public FrmSecretaryVisits()
		{
			InitializeComponent();
		}

		public void DataGrid(bool Prd)
		{
			string[] fields = new string[3] { "ID", "detectDate", "Prd" };
			dc.Select("doctorreserveVisit", fields, Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), dateTimePicker1.Value.ToString("MM/dd/yyyy"), Prd);
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView1.Columns[1].HeaderText = "Visit No.";
				dataGridView1.Columns[5].HeaderText = "Patient Name";
				dataGridView1.Columns[6].HeaderText = "Phone";
				dataGridView1.Columns[7].HeaderText = "Mobile";
				dataGridView1.Columns[8].HeaderText = "Address";
				dataGridView1.Columns[9].HeaderText = "Birth Date";
			}
			dataGridView1.Columns["Doctor ID"].Visible = false;
			dataGridView1.Columns["Patient ID"].Visible = false;
			dataGridView1.Columns["Status"].Visible = false;
			if (Settings.Default.Language == "en-GB")
			{
				foreach (DataGridViewRow item in (IEnumerable)dataGridView1.Rows)
				{
					if (item.Cells["Status"].Value.ToString() == "Confirmed")
					{
						item.DefaultCellStyle.BackColor = Color.FromArgb(187, 240, 188);
					}
					else if (item.Cells["Status"].Value.ToString() == "Not Confirmed")
					{
						item.DefaultCellStyle.BackColor = Color.FromArgb(201, 226, 245);
					}
					else if (item.Cells["Status"].Value.ToString() == "Cancelled")
					{
						item.DefaultCellStyle.BackColor = Color.FromArgb(240, 209, 200);
					}
					else if (item.Cells["Status"].Value.ToString() == "Done")
					{
						item.DefaultCellStyle.BackColor = Color.Beige;
					}
				}
			}
			else
			{
				foreach (DataGridViewRow item2 in (IEnumerable)dataGridView1.Rows)
				{
					if (item2.Cells["Status"].Value.ToString() == "تم التأكيد")
					{
						item2.DefaultCellStyle.BackColor = Color.FromArgb(187, 240, 188);
					}
					else if (item2.Cells["Status"].Value.ToString() == "لم يؤكد")
					{
						item2.DefaultCellStyle.BackColor = Color.FromArgb(201, 226, 245);
					}
					else if (item2.Cells["Status"].Value.ToString() == "تم إلغاؤه")
					{
						item2.DefaultCellStyle.BackColor = Color.FromArgb(240, 209, 200);
					}
					else if (item2.Cells["Status"].Value.ToString() == "تم الكشف")
					{
						item2.DefaultCellStyle.BackColor = Color.Beige;
					}
				}
			}
			dataGridView1.Columns[10].Visible = false;
			dataGridView1.Columns[11].Visible = false;
			dataGridView1.Columns[12].Visible = false;
			dataGridView1.Columns[13].Visible = false;
			dataGridView1.Columns[14].Visible = false;
			dataGridView1.Columns[15].Visible = false;
			dataGridView1.Columns[16].Visible = false;
			dataGridView1.Columns[17].Visible = false;
			dataGridView1.Columns[18].Visible = false;
			dataGridView1.Columns[19].Visible = false;
			dataGridView1.Columns[20].Visible = false;
			dataGridView1.Columns[21].Visible = false;
			dataGridView1.Columns[22].Visible = false;
			dataGridView1.Columns[23].Visible = false;
			dataGridView1.Columns[24].Visible = false;
			dataGridView1.Columns[25].Visible = false;
			dataGridView1.Columns[26].Visible = false;
			dataGridView1.Columns[27].Visible = false;
			dataGridView1.Columns[28].Visible = false;
			dataGridView1.Columns[29].Visible = false;
			dataGridView1.Columns[30].Visible = false;
			dataGridView1.Columns[31].Visible = false;
			dataGridView1.Columns[32].Visible = false;
			dataGridView1.Columns[33].Visible = false;
			dataGridView1.Columns[34].Visible = false;
		}

		public void Doctor(bool Prd)
		{
			try
			{
				string[] fields = new string[3] { "ID", "detectDate", "Prd" };
				DataTable dataTable = dc.Select("doctorreserveVisit", fields, Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), dateTimePicker1.Value.ToString("MM/dd/yyyy"), Prd);
				gui.loadDataGrid(dataGridView1, dataTable);
				DataGrid(Prd);
				if (dataGridView1.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						label3.Text = "Number Of Reservations: " + Convert.ToString(dataGridView1.Rows.Count.ToString());
						label4.Text = "Patient Name:" + Convert.ToString(dataTable.Rows[0]["اسم المريض"].ToString());
					}
					else
					{
						label3.Text = "عدد الحجوزات : " + Convert.ToString(dataGridView1.Rows.Count.ToString());
						label4.Text = "اسم المريض :" + Convert.ToString(dataTable.Rows[0]["اسم المريض"].ToString());
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					label3.Text = "No Reservation";
					label4.Text = "";
				}
				else
				{
					label3.Text = "لا يوجد حجز";
					label4.Text = "";
				}
			}
			catch
			{
			}
		}

		private void FrmSecretaryVisits_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = dc.Select("SelectAllDoctor");
				gui.loadComboBox(doctorcomboBox, dataTable);
				comboBox2.SelectedIndex = 0;
			}
			catch
			{
			}
		}

		private void searchBtn_Click(object sender, EventArgs e)
		{
			bool prd = false;
			if (comboBox2.SelectedIndex == 1)
			{
				prd = true;
			}
			Doctor(prd);
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			bool prd = false;
			if (comboBox2.SelectedIndex == 1)
			{
				prd = true;
			}
			Doctor(prd);
		}

		private void FrmSecretaryVisits_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					PationtInfo pationtInfo = new PationtInfo(Convert.ToInt32(dataGridView1.CurrentRow.Cells[3].Value.ToString()));
					pationtInfo.ShowDialog();
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Select Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("من فضلك اختر بيانات اولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count == 1)
				{
					codes.Edit2("update Visits set Status='تم الكشف' where id='" + dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + "'");
					bool prd = false;
					if (comboBox2.SelectedIndex == 1)
					{
						prd = true;
					}
					Doctor(prd);
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please select Patient");
				}
				else
				{
					MessageBox.Show("من فضلك اختر مريض");
				}
			}
			catch
			{
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			try
			{
				dataSet11.Clear();
				((DataTable)(object)dataSet11.ReportData).Rows.Add(1, doctorcomboBox.Text, dateTimePicker1.Value, dateTimePicker1.Value);
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					DataTable dataTable = codes.Search2(string.Concat("SELECT detectDate,detectDate, Price FROM Visits where AppointNum ='", dataGridView1.Rows[i].Cells["رقم الحجز"].Value.ToString(), "' and DoctorID ='", doctorcomboBox.SelectedValue, "' and detectDate ='", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "'"));
					DataTable dataTable2 = codes.Search2("select isnull(sum(Price),0), isnull(sum(PricePay),0), isnull((sum(Price)-sum(PricePay)),0) from PatientAccount where PatientId='" + dataGridView1.Rows[i].Cells["Patient ID"].Value.ToString() + "' and Appears='True'");
					DataTable dataTable3 = codes.Search2("SELECT        PatientAccount.Bean ,Teath.Name AS Expr1\r\nFROM            PatientAccount INNER JOIN\r\n                         Teath ON PatientAccount.TeathId = Teath.Id where PatientId='" + dataGridView1.Rows[i].Cells["Patient ID"].Value.ToString() + "'  and Appears='True'");
					string text = "";
					decimal num = 0m;
					decimal num2 = 0m;
					decimal num3 = 0m;
					num = Convert.ToDecimal(dataTable2.Rows[0][0].ToString());
					num2 = Convert.ToDecimal(dataTable2.Rows[0][1].ToString());
					num3 = Convert.ToDecimal(dataTable2.Rows[0][2].ToString());
					for (int j = 0; j < dataTable3.Rows.Count; j++)
					{
						if (j == 0)
						{
							text = text + dataTable3.Rows[j][0].ToString() + " " + dataTable3.Rows[j][1].ToString();
							continue;
						}
						string text2 = text;
						text = text2 + " / " + dataTable3.Rows[j][0].ToString() + " " + dataTable3.Rows[j][1].ToString();
					}
					bool flag;
					try
					{
						flag = Convert.ToBoolean(dataGridView1.Rows[i].Cells["Accepted"].Value.ToString());
					}
					catch
					{
						flag = false;
					}
					((DataTable)(object)dataSet11.RptReserve).Rows.Add(dataGridView1.Rows[i].Cells[1].Value.ToString(), dataGridView1.Rows[i].Cells[" "].Value.ToString(), dataGridView1.Rows[i].Cells[5].Value.ToString(), dataGridView1.Rows[i].Cells[8].Value.ToString(), Convert.ToDateTime(dataTable.Rows[0][0].ToString()), Convert.ToDateTime(dataTable.Rows[0][1].ToString()), dataTable.Rows[0][2].ToString(), dataGridView1.Rows[i].Cells["Name"].Value.ToString(), num, num2, num3, flag, text);
				}
				FrmRptReserve frmRptReserve = new FrmRptReserve(dataSet11, 1);
				frmRptReserve.ShowDialog();
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = (DataTable)dataGridView1.DataSource;
				int index = dataGridView1.SelectedRows[0].Index;
				if (index > 0)
				{
					DataRow dataRow = dataTable.NewRow();
					dataRow.ItemArray = dataTable.Rows[index].ItemArray;
					dataTable.Rows.Remove(dataTable.Rows[index]);
					dataTable.Rows.InsertAt(dataRow, index - 1);
					dataGridView1.DataSource = dataTable;
					for (int i = 0; i < dataGridView1.Rows.Count; i++)
					{
						codes.Edit2("update Visits set AppointNum = '" + (i + 1) + "' where ID='" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "'");
					}
					bool prd = false;
					if (comboBox2.SelectedIndex == 1)
					{
						prd = true;
					}
					Doctor(prd);
					dataGridView1.Rows[0].Selected = false;
					dataGridView1.Rows[index - 1].Selected = true;
				}
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = (DataTable)dataGridView1.DataSource;
				int index = dataGridView1.SelectedRows[0].Index;
				if (index < dataGridView1.Rows.Count)
				{
					DataRow dataRow = dataTable.NewRow();
					dataRow.ItemArray = dataTable.Rows[index].ItemArray;
					dataTable.Rows.Remove(dataTable.Rows[index]);
					dataTable.Rows.InsertAt(dataRow, index + 1);
					dataGridView1.DataSource = dataTable;
					for (int i = 0; i < dataGridView1.Rows.Count; i++)
					{
						codes.Edit2("update Visits set AppointNum = '" + (i + 1) + "' where ID='" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "'");
					}
					bool prd = false;
					if (comboBox2.SelectedIndex == 1)
					{
						prd = true;
					}
					Doctor(prd);
					dataGridView1.Rows[0].Selected = false;
					dataGridView1.Rows[index + 1].Selected = true;
				}
			}
			catch
			{
			}
		}

		private void DeletBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					DataTable dataTable;
					double num;
					string[] fields;
					DataTable dataTable2;
					if (Settings.Default.Language != "en-GB")
					{
						if (MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.OKCancel) != DialogResult.OK)
						{
							return;
						}
						dataTable = new DataTable();
						dataTable = dc.GetTableText("select * from Stock");
						num = Convert.ToDouble(dataTable.Rows[0][1].ToString());
						fields = new string[1] { "id" };
						dataTable2 = codes.Search2("select * from Visits where id='" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'");
						if (dc.Delete("DeleteVisit", fields, dataGridView1.Rows[GridID].Cells["ID"].Value.ToString()))
						{
							double num2 = Convert.ToDouble(dataTable2.Rows[0][8].ToString());
							double num3 = num - num2;
							string text = codes.Search2("select ID from Stock").Rows[0][0].ToString();
							codes.Edit2("update Stock Set Value=" + num3 + " where ID = '" + text + "'");
							codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('حذف زيارة' ," + num2 + ",'" + dataGridView1.Rows[GridID].Cells["اسم المريض"].Value.ToString() + "','" + DateTime.Today.ToString("MM/dd/yyyy") + "','" + text + "')");
							if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("Delete Record successfully");
							}
							else
							{
								MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							bool prd = false;
							if (comboBox2.SelectedIndex == 1)
							{
								prd = true;
							}
							Doctor(prd);
						}
						else
						{
							MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						return;
					}
					if (!(Settings.Default.Language == "en-GB") || MessageBox.Show("Are you Sure To delete Data ؟", "confirmation", MessageBoxButtons.OKCancel) != DialogResult.OK)
					{
						return;
					}
					dataTable = new DataTable();
					dataTable = dc.GetTableText("select * from Stock");
					num = Convert.ToDouble(dataTable.Rows[0][1].ToString());
					fields = new string[1] { "id" };
					dataTable2 = codes.Search2("select * from Visits where id='" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'");
					if (dc.Delete("DeleteVisit", fields, dataGridView1.Rows[GridID].Cells["ID"].Value.ToString()))
					{
						double num2 = Convert.ToDouble(dataTable2.Rows[0][8].ToString());
						double num3 = num - num2;
						string text = codes.Search2("select ID from Stock").Rows[0][0].ToString();
						codes.Edit2("update Stock Set Value=" + num3 + " where ID = '" + text + "'");
						codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('حذف زيارة' ," + num2 + ",'" + dataGridView1.Rows[GridID].Cells["اسم المريض"].Value.ToString() + "','" + DateTime.Today.ToString("MM/dd/yyyy") + "','" + text + "')");
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Delete Record successfully");
						}
						else
						{
							MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						bool prd = false;
						if (comboBox2.SelectedIndex == 1)
						{
							prd = true;
						}
						Doctor(prd);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Choose a Record");
				}
				else
				{
					MessageBox.Show("من فضلك اختر سجل");
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				GridID = dataGridView1.CurrentRow.Index;
			}
			catch
			{
			}
		}
	}
}
