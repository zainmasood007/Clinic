using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmBill : ReportBaseForm
	{
		private IContainer components = null;

		private CrystalReportViewer crystalReportViewer1;

		private GroupBox groupBox1;

		private Button button1;

		private NumericUpDown numericUpDown1;

		private Label label1;

		private RadioButton radioButton2;

		private RadioButton radioButton1;

		private GroupBox groupBox2;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlSelectCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlInsertCommand2;

		private SqlCommand sqlUpdateCommand2;

		private SqlCommand sqlDeleteCommand2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlSelectCommand3;

		private SqlCommand sqlInsertCommand3;

		private SqlCommand sqlUpdateCommand3;

		private SqlCommand sqlDeleteCommand3;

		private SqlDataAdapter sqlDataAdapter3;

		private SqlConnection sqlConnection3;

		private SqlCommand sqlSelectCommand4;

		private SqlConnection sqlConnection4;

		private SqlCommand sqlInsertCommand4;

		private SqlCommand sqlUpdateCommand4;

		private SqlCommand sqlDeleteCommand4;

		private SqlDataAdapter sqlDataAdapter4;

		private SqlCommand sqlSelectCommand5;

		private SqlConnection sqlConnection5;

		private SqlCommand sqlInsertCommand5;

		private SqlCommand sqlUpdateCommand5;

		private SqlCommand sqlDeleteCommand5;

		private SqlDataAdapter sqlDataAdapter5;

		private SqlCommand sqlSelectCommand6;

		private SqlConnection sqlConnection6;

		private SqlCommand sqlInsertCommand6;

		private SqlDataAdapter sqlDataAdapter6;

		private SqlCommand sqlSelectCommand7;

		private SqlConnection sqlConnection7;

		private SqlCommand sqlInsertCommand7;

		private SqlCommand sqlUpdateCommand6;

		private SqlCommand sqlDeleteCommand6;

		private SqlDataAdapter sqlDataAdapter7;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmBill));
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			groupBox1 = new System.Windows.Forms.GroupBox();
			button1 = new System.Windows.Forms.Button();
			numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			label1 = new System.Windows.Forms.Label();
			radioButton2 = new System.Windows.Forms.RadioButton();
			radioButton1 = new System.Windows.Forms.RadioButton();
			groupBox2 = new System.Windows.Forms.GroupBox();
			dataSet11 = new DataSet1();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlConnection3 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlConnection4 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand4 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter4 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand5 = new System.Data.SqlClient.SqlCommand();
			sqlConnection5 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand5 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand5 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand5 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter5 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand6 = new System.Data.SqlClient.SqlCommand();
			sqlConnection6 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand6 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter6 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand7 = new System.Data.SqlClient.SqlCommand();
			sqlConnection7 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand7 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand6 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand6 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter7 = new System.Data.SqlClient.SqlDataAdapter();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(button1);
			groupBox1.Controls.Add(numericUpDown1);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(radioButton2);
			groupBox1.Controls.Add(radioButton1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			numericUpDown1.AccessibleDescription = null;
			numericUpDown1.AccessibleName = null;
			resources.ApplyResources(numericUpDown1, "numericUpDown1");
			numericUpDown1.Font = null;
			numericUpDown1.Maximum = new decimal(new int[4] { -727379969, 232, 0, 0 });
			numericUpDown1.Minimum = new decimal(new int[4] { 1, 0, 0, 0 });
			numericUpDown1.Name = "numericUpDown1";
			numericUpDown1.Value = new decimal(new int[4] { 1, 0, 0, 0 });
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.Name = "label1";
			radioButton2.AccessibleDescription = null;
			radioButton2.AccessibleName = null;
			resources.ApplyResources(radioButton2, "radioButton2");
			radioButton2.BackgroundImage = null;
			radioButton2.Font = null;
			radioButton2.Name = "radioButton2";
			radioButton2.UseVisualStyleBackColor = true;
			radioButton1.AccessibleDescription = null;
			radioButton1.AccessibleName = null;
			resources.ApplyResources(radioButton1, "radioButton1");
			radioButton1.BackgroundImage = null;
			radioButton1.Checked = true;
			radioButton1.Font = null;
			radioButton1.Name = "radioButton1";
			radioButton1.TabStop = true;
			radioButton1.UseVisualStyleBackColor = true;
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlSelectCommand1.CommandText = "SELECT        IncomingBill.*\r\nFROM            IncomingBill";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[14]
			{
				new System.Data.SqlClient.SqlParameter("@BillNo", System.Data.SqlDbType.NVarChar, 0, "BillNo"),
				new System.Data.SqlClient.SqlParameter("@SupplierId", System.Data.SqlDbType.Int, 0, "SupplierId"),
				new System.Data.SqlClient.SqlParameter("@BillDate", System.Data.SqlDbType.DateTime, 0, "BillDate"),
				new System.Data.SqlClient.SqlParameter("@ItemId", System.Data.SqlDbType.Int, 0, "ItemId"),
				new System.Data.SqlClient.SqlParameter("@Qnt", System.Data.SqlDbType.Money, 0, "Qnt"),
				new System.Data.SqlClient.SqlParameter("@UnitPrice", System.Data.SqlDbType.Money, 0, "UnitPrice"),
				new System.Data.SqlClient.SqlParameter("@SanfDiscount", System.Data.SqlDbType.Money, 0, "SanfDiscount"),
				new System.Data.SqlClient.SqlParameter("@TotalPrice", System.Data.SqlDbType.Money, 0, "TotalPrice"),
				new System.Data.SqlClient.SqlParameter("@BillTotalBeforeDiscount", System.Data.SqlDbType.Money, 0, "BillTotalBeforeDiscount"),
				new System.Data.SqlClient.SqlParameter("@DiscountPer", System.Data.SqlDbType.Money, 0, "DiscountPer"),
				new System.Data.SqlClient.SqlParameter("@DiscountAmount", System.Data.SqlDbType.Money, 0, "DiscountAmount"),
				new System.Data.SqlClient.SqlParameter("@BillTotAfterDiscount", System.Data.SqlDbType.Money, 0, "BillTotAfterDiscount"),
				new System.Data.SqlClient.SqlParameter("@Pay", System.Data.SqlDbType.Money, 0, "Pay"),
				new System.Data.SqlClient.SqlParameter("@Backey", System.Data.SqlDbType.Money, 0, "Backey")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[44]
			{
				new System.Data.SqlClient.SqlParameter("@BillNo", System.Data.SqlDbType.NVarChar, 0, "BillNo"),
				new System.Data.SqlClient.SqlParameter("@SupplierId", System.Data.SqlDbType.Int, 0, "SupplierId"),
				new System.Data.SqlClient.SqlParameter("@BillDate", System.Data.SqlDbType.DateTime, 0, "BillDate"),
				new System.Data.SqlClient.SqlParameter("@ItemId", System.Data.SqlDbType.Int, 0, "ItemId"),
				new System.Data.SqlClient.SqlParameter("@Qnt", System.Data.SqlDbType.Money, 0, "Qnt"),
				new System.Data.SqlClient.SqlParameter("@UnitPrice", System.Data.SqlDbType.Money, 0, "UnitPrice"),
				new System.Data.SqlClient.SqlParameter("@SanfDiscount", System.Data.SqlDbType.Money, 0, "SanfDiscount"),
				new System.Data.SqlClient.SqlParameter("@TotalPrice", System.Data.SqlDbType.Money, 0, "TotalPrice"),
				new System.Data.SqlClient.SqlParameter("@BillTotalBeforeDiscount", System.Data.SqlDbType.Money, 0, "BillTotalBeforeDiscount"),
				new System.Data.SqlClient.SqlParameter("@DiscountPer", System.Data.SqlDbType.Money, 0, "DiscountPer"),
				new System.Data.SqlClient.SqlParameter("@DiscountAmount", System.Data.SqlDbType.Money, 0, "DiscountAmount"),
				new System.Data.SqlClient.SqlParameter("@BillTotAfterDiscount", System.Data.SqlDbType.Money, 0, "BillTotAfterDiscount"),
				new System.Data.SqlClient.SqlParameter("@Pay", System.Data.SqlDbType.Money, 0, "Pay"),
				new System.Data.SqlClient.SqlParameter("@Backey", System.Data.SqlDbType.Money, 0, "Backey"),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillNo", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Qnt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Qnt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Qnt", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Qnt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_UnitPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "UnitPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_UnitPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "UnitPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SanfDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SanfDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SanfDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SanfDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_TotalPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "TotalPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_TotalPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "TotalPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillTotalBeforeDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillTotalBeforeDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillTotalBeforeDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillTotalBeforeDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountPer", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountPer", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountPer", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountPer", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountAmount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountAmount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountAmount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountAmount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillTotAfterDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillTotAfterDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillTotAfterDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillTotAfterDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Pay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Pay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Pay", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Pay", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Backey", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Backey", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Backey", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Backey", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[29]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillNo", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Qnt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Qnt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Qnt", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Qnt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_UnitPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "UnitPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_UnitPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "UnitPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SanfDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SanfDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SanfDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SanfDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_TotalPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "TotalPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_TotalPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "TotalPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillTotalBeforeDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillTotalBeforeDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillTotalBeforeDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillTotalBeforeDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountPer", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountPer", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountPer", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountPer", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountAmount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountAmount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountAmount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountAmount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillTotAfterDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillTotAfterDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillTotAfterDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillTotAfterDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Pay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Pay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Pay", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Pay", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Backey", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Backey", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Backey", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Backey", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "IncomingBill", new System.Data.Common.DataColumnMapping[15]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("BillNo", "BillNo"),
					new System.Data.Common.DataColumnMapping("SupplierId", "SupplierId"),
					new System.Data.Common.DataColumnMapping("BillDate", "BillDate"),
					new System.Data.Common.DataColumnMapping("ItemId", "ItemId"),
					new System.Data.Common.DataColumnMapping("Qnt", "Qnt"),
					new System.Data.Common.DataColumnMapping("UnitPrice", "UnitPrice"),
					new System.Data.Common.DataColumnMapping("SanfDiscount", "SanfDiscount"),
					new System.Data.Common.DataColumnMapping("TotalPrice", "TotalPrice"),
					new System.Data.Common.DataColumnMapping("BillTotalBeforeDiscount", "BillTotalBeforeDiscount"),
					new System.Data.Common.DataColumnMapping("DiscountPer", "DiscountPer"),
					new System.Data.Common.DataColumnMapping("DiscountAmount", "DiscountAmount"),
					new System.Data.Common.DataColumnMapping("BillTotAfterDiscount", "BillTotAfterDiscount"),
					new System.Data.Common.DataColumnMapping("Pay", "Pay"),
					new System.Data.Common.DataColumnMapping("Backey", "Backey")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			sqlSelectCommand2.CommandText = "SELECT        Items.*\r\nFROM            Items";
			sqlSelectCommand2.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.CommandText = "INSERT INTO [Items] ([Name], [SalePrice], [LimitOrder]) VALUES (@Name, @SalePrice, @LimitOrder);\r\nSELECT Id, Name, SalePrice, LimitOrder FROM Items WHERE (Id = SCOPE_IDENTITY())";
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[3]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@SalePrice", System.Data.SqlDbType.Money, 0, "SalePrice"),
				new System.Data.SqlClient.SqlParameter("@LimitOrder", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "LimitOrder", System.Data.DataRowVersion.Current, null)
			});
			sqlUpdateCommand2.CommandText = resources.GetString("sqlUpdateCommand2.CommandText");
			sqlUpdateCommand2.Connection = sqlConnection2;
			sqlUpdateCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[11]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@SalePrice", System.Data.SqlDbType.Money, 0, "SalePrice"),
				new System.Data.SqlClient.SqlParameter("@LimitOrder", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "LimitOrder", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Name", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Name", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Name", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Name", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SalePrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SalePrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SalePrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SalePrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_LimitOrder", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "LimitOrder", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_LimitOrder", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "LimitOrder", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDeleteCommand2.CommandText = resources.GetString("sqlDeleteCommand2.CommandText");
			sqlDeleteCommand2.Connection = sqlConnection2;
			sqlDeleteCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[7]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Name", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Name", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Name", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Name", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SalePrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SalePrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SalePrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SalePrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_LimitOrder", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "LimitOrder", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_LimitOrder", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "LimitOrder", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter2.DeleteCommand = sqlDeleteCommand2;
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Items", new System.Data.Common.DataColumnMapping[4]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("Name", "Name"),
					new System.Data.Common.DataColumnMapping("SalePrice", "SalePrice"),
					new System.Data.Common.DataColumnMapping("LimitOrder", "LimitOrder")
				})
			});
			sqlDataAdapter2.UpdateCommand = sqlUpdateCommand2;
			sqlSelectCommand3.CommandText = "SELECT        Supplier.*\r\nFROM            Supplier";
			sqlSelectCommand3.Connection = sqlConnection3;
			sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection3.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand3.CommandText = resources.GetString("sqlInsertCommand3.CommandText");
			sqlInsertCommand3.Connection = sqlConnection3;
			sqlInsertCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[5]
			{
				new System.Data.SqlClient.SqlParameter("@SupName", System.Data.SqlDbType.NVarChar, 0, "SupName"),
				new System.Data.SqlClient.SqlParameter("@SupAddress", System.Data.SqlDbType.NVarChar, 0, "SupAddress"),
				new System.Data.SqlClient.SqlParameter("@NationalId", System.Data.SqlDbType.NVarChar, 0, "NationalId"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mobile", System.Data.SqlDbType.NVarChar, 0, "Mobile")
			});
			sqlUpdateCommand3.CommandText = resources.GetString("sqlUpdateCommand3.CommandText");
			sqlUpdateCommand3.Connection = sqlConnection3;
			sqlUpdateCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[17]
			{
				new System.Data.SqlClient.SqlParameter("@SupName", System.Data.SqlDbType.NVarChar, 0, "SupName"),
				new System.Data.SqlClient.SqlParameter("@SupAddress", System.Data.SqlDbType.NVarChar, 0, "SupAddress"),
				new System.Data.SqlClient.SqlParameter("@NationalId", System.Data.SqlDbType.NVarChar, 0, "NationalId"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mobile", System.Data.SqlDbType.NVarChar, 0, "Mobile"),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NationalId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NationalId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NationalId", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NationalId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@SupplierID", System.Data.SqlDbType.Int, 4, "SupplierID")
			});
			sqlDeleteCommand3.CommandText = resources.GetString("sqlDeleteCommand3.CommandText");
			sqlDeleteCommand3.Connection = sqlConnection3;
			sqlDeleteCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[11]
			{
				new System.Data.SqlClient.SqlParameter("@Original_SupplierID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NationalId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NationalId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NationalId", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NationalId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mobile", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter3.DeleteCommand = sqlDeleteCommand3;
			sqlDataAdapter3.InsertCommand = sqlInsertCommand3;
			sqlDataAdapter3.SelectCommand = sqlSelectCommand3;
			sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Supplier", new System.Data.Common.DataColumnMapping[6]
				{
					new System.Data.Common.DataColumnMapping("SupplierID", "SupplierID"),
					new System.Data.Common.DataColumnMapping("SupName", "SupName"),
					new System.Data.Common.DataColumnMapping("SupAddress", "SupAddress"),
					new System.Data.Common.DataColumnMapping("NationalId", "NationalId"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mobile", "Mobile")
				})
			});
			sqlDataAdapter3.UpdateCommand = sqlUpdateCommand3;
			sqlSelectCommand4.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand4.Connection = sqlConnection4;
			sqlConnection4.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection4.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand4.CommandText = resources.GetString("sqlInsertCommand4.CommandText");
			sqlInsertCommand4.Connection = sqlConnection4;
			sqlInsertCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[15]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
				new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
				new System.Data.SqlClient.SqlParameter("@GeneralClinic", System.Data.SqlDbType.Bit, 0, "GeneralClinic")
			});
			sqlUpdateCommand4.CommandText = resources.GetString("sqlUpdateCommand4.CommandText");
			sqlUpdateCommand4.Connection = sqlConnection4;
			sqlUpdateCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[37]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
				new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
				new System.Data.SqlClient.SqlParameter("@GeneralClinic", System.Data.SqlDbType.Bit, 0, "GeneralClinic"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_GeneralClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_GeneralClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand4.CommandText = resources.GetString("sqlDeleteCommand4.CommandText");
			sqlDeleteCommand4.Connection = sqlConnection4;
			sqlDeleteCommand4.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_GeneralClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_GeneralClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "GeneralClinic", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter4.DeleteCommand = sqlDeleteCommand4;
			sqlDataAdapter4.InsertCommand = sqlInsertCommand4;
			sqlDataAdapter4.SelectCommand = sqlSelectCommand4;
			sqlDataAdapter4.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[16]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData"),
					new System.Data.Common.DataColumnMapping("Powred", "Powred"),
					new System.Data.Common.DataColumnMapping("ClinicType", "ClinicType"),
					new System.Data.Common.DataColumnMapping("EyeClinic", "EyeClinic"),
					new System.Data.Common.DataColumnMapping("FemaleClinic", "FemaleClinic"),
					new System.Data.Common.DataColumnMapping("NaturalClinic", "NaturalClinic"),
					new System.Data.Common.DataColumnMapping("EnName", "EnName"),
					new System.Data.Common.DataColumnMapping("GeneralClinic", "GeneralClinic")
				})
			});
			sqlDataAdapter4.UpdateCommand = sqlUpdateCommand4;
			sqlSelectCommand5.CommandText = "SELECT        Sell.*\r\nFROM            Sell";
			sqlSelectCommand5.Connection = sqlConnection5;
			sqlConnection5.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection5.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand5.CommandText = resources.GetString("sqlInsertCommand5.CommandText");
			sqlInsertCommand5.Connection = sqlConnection5;
			sqlInsertCommand5.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[16]
			{
				new System.Data.SqlClient.SqlParameter("@SellNo", System.Data.SqlDbType.Int, 0, "SellNo"),
				new System.Data.SqlClient.SqlParameter("@PatientId", System.Data.SqlDbType.Int, 0, "PatientId"),
				new System.Data.SqlClient.SqlParameter("@DoctorID", System.Data.SqlDbType.Int, 0, "DoctorID"),
				new System.Data.SqlClient.SqlParameter("@SellDate", System.Data.SqlDbType.DateTime, 0, "SellDate"),
				new System.Data.SqlClient.SqlParameter("@ItemId", System.Data.SqlDbType.Int, 0, "ItemId"),
				new System.Data.SqlClient.SqlParameter("@Qnt", System.Data.SqlDbType.Money, 0, "Qnt"),
				new System.Data.SqlClient.SqlParameter("@UnitPrice", System.Data.SqlDbType.Money, 0, "UnitPrice"),
				new System.Data.SqlClient.SqlParameter("@BuyPrice", System.Data.SqlDbType.Money, 0, "BuyPrice"),
				new System.Data.SqlClient.SqlParameter("@SanfDiscount", System.Data.SqlDbType.Money, 0, "SanfDiscount"),
				new System.Data.SqlClient.SqlParameter("@TotalPrice", System.Data.SqlDbType.Money, 0, "TotalPrice"),
				new System.Data.SqlClient.SqlParameter("@BillTotalBeforeDiscount", System.Data.SqlDbType.Money, 0, "BillTotalBeforeDiscount"),
				new System.Data.SqlClient.SqlParameter("@DiscountPer", System.Data.SqlDbType.Money, 0, "DiscountPer"),
				new System.Data.SqlClient.SqlParameter("@DiscountAmount", System.Data.SqlDbType.Money, 0, "DiscountAmount"),
				new System.Data.SqlClient.SqlParameter("@BillTotAfterDiscount", System.Data.SqlDbType.Money, 0, "BillTotAfterDiscount"),
				new System.Data.SqlClient.SqlParameter("@Pay", System.Data.SqlDbType.Money, 0, "Pay"),
				new System.Data.SqlClient.SqlParameter("@Backey", System.Data.SqlDbType.Money, 0, "Backey")
			});
			sqlUpdateCommand5.CommandText = resources.GetString("sqlUpdateCommand5.CommandText");
			sqlUpdateCommand5.Connection = sqlConnection5;
			sqlUpdateCommand5.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[50]
			{
				new System.Data.SqlClient.SqlParameter("@SellNo", System.Data.SqlDbType.Int, 0, "SellNo"),
				new System.Data.SqlClient.SqlParameter("@PatientId", System.Data.SqlDbType.Int, 0, "PatientId"),
				new System.Data.SqlClient.SqlParameter("@DoctorID", System.Data.SqlDbType.Int, 0, "DoctorID"),
				new System.Data.SqlClient.SqlParameter("@SellDate", System.Data.SqlDbType.DateTime, 0, "SellDate"),
				new System.Data.SqlClient.SqlParameter("@ItemId", System.Data.SqlDbType.Int, 0, "ItemId"),
				new System.Data.SqlClient.SqlParameter("@Qnt", System.Data.SqlDbType.Money, 0, "Qnt"),
				new System.Data.SqlClient.SqlParameter("@UnitPrice", System.Data.SqlDbType.Money, 0, "UnitPrice"),
				new System.Data.SqlClient.SqlParameter("@BuyPrice", System.Data.SqlDbType.Money, 0, "BuyPrice"),
				new System.Data.SqlClient.SqlParameter("@SanfDiscount", System.Data.SqlDbType.Money, 0, "SanfDiscount"),
				new System.Data.SqlClient.SqlParameter("@TotalPrice", System.Data.SqlDbType.Money, 0, "TotalPrice"),
				new System.Data.SqlClient.SqlParameter("@BillTotalBeforeDiscount", System.Data.SqlDbType.Money, 0, "BillTotalBeforeDiscount"),
				new System.Data.SqlClient.SqlParameter("@DiscountPer", System.Data.SqlDbType.Money, 0, "DiscountPer"),
				new System.Data.SqlClient.SqlParameter("@DiscountAmount", System.Data.SqlDbType.Money, 0, "DiscountAmount"),
				new System.Data.SqlClient.SqlParameter("@BillTotAfterDiscount", System.Data.SqlDbType.Money, 0, "BillTotAfterDiscount"),
				new System.Data.SqlClient.SqlParameter("@Pay", System.Data.SqlDbType.Money, 0, "Pay"),
				new System.Data.SqlClient.SqlParameter("@Backey", System.Data.SqlDbType.Money, 0, "Backey"),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SellNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SellNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SellNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SellNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SellDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SellDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SellDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SellDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Qnt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Qnt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Qnt", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Qnt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_UnitPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "UnitPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_UnitPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "UnitPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BuyPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BuyPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BuyPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BuyPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SanfDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SanfDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SanfDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SanfDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_TotalPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "TotalPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_TotalPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "TotalPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillTotalBeforeDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillTotalBeforeDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillTotalBeforeDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillTotalBeforeDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountPer", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountPer", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountPer", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountPer", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountAmount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountAmount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountAmount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountAmount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillTotAfterDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillTotAfterDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillTotAfterDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillTotAfterDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Pay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Pay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Pay", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Pay", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Backey", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Backey", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Backey", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Backey", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDeleteCommand5.CommandText = resources.GetString("sqlDeleteCommand5.CommandText");
			sqlDeleteCommand5.Connection = sqlConnection5;
			sqlDeleteCommand5.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[33]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SellNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SellNo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SellNo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SellNo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_PatientId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "PatientId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_PatientId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DoctorID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DoctorID", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DoctorID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DoctorID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SellDate", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SellDate", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SellDate", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SellDate", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Qnt", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Qnt", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Qnt", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Qnt", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_UnitPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "UnitPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_UnitPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "UnitPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BuyPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BuyPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BuyPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BuyPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SanfDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SanfDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SanfDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SanfDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_TotalPrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "TotalPrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_TotalPrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "TotalPrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillTotalBeforeDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillTotalBeforeDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillTotalBeforeDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillTotalBeforeDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountPer", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountPer", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountPer", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountPer", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DiscountAmount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DiscountAmount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DiscountAmount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DiscountAmount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BillTotAfterDiscount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BillTotAfterDiscount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BillTotAfterDiscount", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BillTotAfterDiscount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Pay", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Pay", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Pay", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Pay", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Backey", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Backey", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Backey", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Backey", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter5.DeleteCommand = sqlDeleteCommand5;
			sqlDataAdapter5.InsertCommand = sqlInsertCommand5;
			sqlDataAdapter5.SelectCommand = sqlSelectCommand5;
			sqlDataAdapter5.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Sell", new System.Data.Common.DataColumnMapping[17]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("SellNo", "SellNo"),
					new System.Data.Common.DataColumnMapping("PatientId", "PatientId"),
					new System.Data.Common.DataColumnMapping("DoctorID", "DoctorID"),
					new System.Data.Common.DataColumnMapping("SellDate", "SellDate"),
					new System.Data.Common.DataColumnMapping("ItemId", "ItemId"),
					new System.Data.Common.DataColumnMapping("Qnt", "Qnt"),
					new System.Data.Common.DataColumnMapping("UnitPrice", "UnitPrice"),
					new System.Data.Common.DataColumnMapping("BuyPrice", "BuyPrice"),
					new System.Data.Common.DataColumnMapping("SanfDiscount", "SanfDiscount"),
					new System.Data.Common.DataColumnMapping("TotalPrice", "TotalPrice"),
					new System.Data.Common.DataColumnMapping("BillTotalBeforeDiscount", "BillTotalBeforeDiscount"),
					new System.Data.Common.DataColumnMapping("DiscountPer", "DiscountPer"),
					new System.Data.Common.DataColumnMapping("DiscountAmount", "DiscountAmount"),
					new System.Data.Common.DataColumnMapping("BillTotAfterDiscount", "BillTotAfterDiscount"),
					new System.Data.Common.DataColumnMapping("Pay", "Pay"),
					new System.Data.Common.DataColumnMapping("Backey", "Backey")
				})
			});
			sqlDataAdapter5.UpdateCommand = sqlUpdateCommand5;
			sqlSelectCommand6.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlSelectCommand6.Connection = sqlConnection6;
			sqlConnection6.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection6.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand6.CommandText = resources.GetString("sqlInsertCommand6.CommandText");
			sqlInsertCommand6.Connection = sqlConnection6;
			sqlInsertCommand6.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[40]
			{
				new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
				new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
				new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
				new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
				new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
				new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
				new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
				new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
				new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
				new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
				new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
				new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
				new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
				new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
				new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
				new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
				new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
				new System.Data.SqlClient.SqlParameter("@Lactating", System.Data.SqlDbType.Bit, 0, "Lactating"),
				new System.Data.SqlClient.SqlParameter("@Pregnant", System.Data.SqlDbType.Bit, 0, "Pregnant"),
				new System.Data.SqlClient.SqlParameter("@HepatitisB", System.Data.SqlDbType.Bit, 0, "HepatitisB"),
				new System.Data.SqlClient.SqlParameter("@Hepatitisc", System.Data.SqlDbType.Bit, 0, "Hepatitisc"),
				new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
				new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
				new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
				new System.Data.SqlClient.SqlParameter("@Endodontics", System.Data.SqlDbType.Bit, 0, "Endodontics"),
				new System.Data.SqlClient.SqlParameter("@Fixed", System.Data.SqlDbType.Bit, 0, "Fixed"),
				new System.Data.SqlClient.SqlParameter("@Implant", System.Data.SqlDbType.Bit, 0, "Implant"),
				new System.Data.SqlClient.SqlParameter("@Opretive", System.Data.SqlDbType.Bit, 0, "Opretive"),
				new System.Data.SqlClient.SqlParameter("@Bleaching", System.Data.SqlDbType.Bit, 0, "Bleaching"),
				new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers"),
				new System.Data.SqlClient.SqlParameter("@DoctoreName", System.Data.SqlDbType.NVarChar, 0, "DoctoreName"),
				new System.Data.SqlClient.SqlParameter("@NextVisit", System.Data.SqlDbType.NVarChar, 0, "NextVisit"),
				new System.Data.SqlClient.SqlParameter("@Accept", System.Data.SqlDbType.Bit, 0, "Accept"),
				new System.Data.SqlClient.SqlParameter("@Taqweem", System.Data.SqlDbType.Bit, 0, "Taqweem"),
				new System.Data.SqlClient.SqlParameter("@Photo", System.Data.SqlDbType.Image, 0, "Photo"),
				new System.Data.SqlClient.SqlParameter("@BloodType", System.Data.SqlDbType.NVarChar, 0, "BloodType")
			});
			sqlDataAdapter6.InsertCommand = sqlInsertCommand6;
			sqlDataAdapter6.SelectCommand = sqlSelectCommand6;
			sqlDataAdapter6.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[41]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
					new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
					new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
					new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
					new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
					new System.Data.Common.DataColumnMapping("Implant", "Implant"),
					new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
					new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers"),
					new System.Data.Common.DataColumnMapping("DoctoreName", "DoctoreName"),
					new System.Data.Common.DataColumnMapping("NextVisit", "NextVisit"),
					new System.Data.Common.DataColumnMapping("Accept", "Accept"),
					new System.Data.Common.DataColumnMapping("Taqweem", "Taqweem"),
					new System.Data.Common.DataColumnMapping("Photo", "Photo"),
					new System.Data.Common.DataColumnMapping("BloodType", "BloodType")
				})
			});
			sqlSelectCommand7.CommandText = "SELECT        Empdata.*\r\nFROM            Empdata";
			sqlSelectCommand7.Connection = sqlConnection7;
			sqlConnection7.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection7.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand7.CommandText = resources.GetString("sqlInsertCommand7.CommandText");
			sqlInsertCommand7.Connection = sqlConnection7;
			sqlInsertCommand7.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[14]
			{
				new System.Data.SqlClient.SqlParameter("@Designation", System.Data.SqlDbType.NVarChar, 0, "Designation"),
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 0, "Address"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@Salary", System.Data.SqlDbType.Money, 0, "Salary"),
				new System.Data.SqlClient.SqlParameter("@Percentage", System.Data.SqlDbType.NVarChar, 0, "Percentage"),
				new System.Data.SqlClient.SqlParameter("@Specialty", System.Data.SqlDbType.NVarChar, 0, "Specialty"),
				new System.Data.SqlClient.SqlParameter("@Signature", System.Data.SqlDbType.NVarChar, 0, "Signature"),
				new System.Data.SqlClient.SqlParameter("@AppointCount", System.Data.SqlDbType.Int, 0, "AppointCount"),
				new System.Data.SqlClient.SqlParameter("@BacksCount", System.Data.SqlDbType.Int, 0, "BacksCount"),
				new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
				new System.Data.SqlClient.SqlParameter("@EnSpecialty", System.Data.SqlDbType.NVarChar, 0, "EnSpecialty")
			});
			sqlUpdateCommand6.CommandText = resources.GetString("sqlUpdateCommand6.CommandText");
			sqlUpdateCommand6.Connection = sqlConnection7;
			sqlUpdateCommand6.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[32]
			{
				new System.Data.SqlClient.SqlParameter("@Designation", System.Data.SqlDbType.NVarChar, 0, "Designation"),
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Address", System.Data.SqlDbType.NVarChar, 0, "Address"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@Salary", System.Data.SqlDbType.Money, 0, "Salary"),
				new System.Data.SqlClient.SqlParameter("@Percentage", System.Data.SqlDbType.NVarChar, 0, "Percentage"),
				new System.Data.SqlClient.SqlParameter("@Specialty", System.Data.SqlDbType.NVarChar, 0, "Specialty"),
				new System.Data.SqlClient.SqlParameter("@Signature", System.Data.SqlDbType.NVarChar, 0, "Signature"),
				new System.Data.SqlClient.SqlParameter("@AppointCount", System.Data.SqlDbType.Int, 0, "AppointCount"),
				new System.Data.SqlClient.SqlParameter("@BacksCount", System.Data.SqlDbType.Int, 0, "BacksCount"),
				new System.Data.SqlClient.SqlParameter("@EnName", System.Data.SqlDbType.NVarChar, 0, "EnName"),
				new System.Data.SqlClient.SqlParameter("@EnSpecialty", System.Data.SqlDbType.NVarChar, 0, "EnSpecialty"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Designation", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Designation", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Designation", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Designation", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mob", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mob", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mob", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mob", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Email", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Email", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Email", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Email", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Salary", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Salary", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Salary", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Salary", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Percentage", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Percentage", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Percentage", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Percentage", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AppointCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AppointCount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AppointCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AppointCount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BacksCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BacksCount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BacksCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BacksCount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand6.CommandText = resources.GetString("sqlDeleteCommand6.CommandText");
			sqlDeleteCommand6.Connection = sqlConnection7;
			sqlDeleteCommand6.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[17]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Designation", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Designation", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Designation", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Designation", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mob", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mob", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mob", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mob", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Email", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Email", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Email", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Email", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Salary", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Salary", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Salary", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Salary", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Percentage", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Percentage", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Percentage", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Percentage", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_AppointCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "AppointCount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_AppointCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "AppointCount", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_BacksCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "BacksCount", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_BacksCount", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "BacksCount", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter7.DeleteCommand = sqlDeleteCommand6;
			sqlDataAdapter7.InsertCommand = sqlInsertCommand7;
			sqlDataAdapter7.SelectCommand = sqlSelectCommand7;
			sqlDataAdapter7.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Empdata", new System.Data.Common.DataColumnMapping[15]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Designation", "Designation"),
					new System.Data.Common.DataColumnMapping("Name", "Name"),
					new System.Data.Common.DataColumnMapping("Address", "Address"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("Salary", "Salary"),
					new System.Data.Common.DataColumnMapping("Percentage", "Percentage"),
					new System.Data.Common.DataColumnMapping("Specialty", "Specialty"),
					new System.Data.Common.DataColumnMapping("Signature", "Signature"),
					new System.Data.Common.DataColumnMapping("AppointCount", "AppointCount"),
					new System.Data.Common.DataColumnMapping("BacksCount", "BacksCount"),
					new System.Data.Common.DataColumnMapping("EnName", "EnName"),
					new System.Data.Common.DataColumnMapping("EnSpecialty", "EnSpecialty")
				})
			});
			sqlDataAdapter7.UpdateCommand = sqlUpdateCommand6;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FrmBill";
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}

		public FrmBill()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			dataSet11.Clear();
			if (radioButton1.Checked)
			{
				sqlConnection1.ConnectionString = Codes.ConnectionStr;
				sqlConnection2.ConnectionString = Codes.ConnectionStr;
				sqlConnection3.ConnectionString = Codes.ConnectionStr;
				sqlConnection4.ConnectionString = Codes.ConnectionStr;
				sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter1.SelectCommand.CommandText = "select * from IncomingBill where BillNo='" + numericUpDown1.Value + "'";
				sqlDataAdapter1.Fill(dataSet11);
				sqlDataAdapter2.Fill(dataSet11);
				sqlDataAdapter3.Fill(dataSet11);
				sqlDataAdapter4.Fill(dataSet11);
				IncomingBillRpt incomingBillRpt = new IncomingBillRpt();
				incomingBillRpt.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = incomingBillRpt;
			}
			else
			{
				sqlConnection2.ConnectionString = Codes.ConnectionStr;
				sqlConnection5.ConnectionString = Codes.ConnectionStr;
				sqlConnection4.ConnectionString = Codes.ConnectionStr;
				sqlConnection6.ConnectionString = Codes.ConnectionStr;
				sqlConnection7.ConnectionString = Codes.ConnectionStr;
				sqlDataAdapter5.SelectCommand.CommandType = CommandType.Text;
				sqlDataAdapter5.SelectCommand.CommandText = "select * from Sell where SellNo='" + numericUpDown1.Value + "'";
				sqlDataAdapter2.Fill(dataSet11);
				sqlDataAdapter5.Fill(dataSet11);
				sqlDataAdapter4.Fill(dataSet11);
				sqlDataAdapter6.Fill(dataSet11);
				sqlDataAdapter7.Fill(dataSet11);
				SellRpt sellRpt = new SellRpt();
				sellRpt.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = sellRpt;
			}
		}
	}
}
