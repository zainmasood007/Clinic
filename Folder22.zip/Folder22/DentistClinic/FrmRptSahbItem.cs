using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Properties;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmRptSahbItem : ReportBaseForm
	{
		private ClassDataBase dc;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private GUI gui = new GUI();

		private IContainer components = null;

		private GroupBox groupBox1;

		private ComboBox comboBox1;

		private Label label4;

		private DateTimePicker date2;

		private DateTimePicker date1;

		private Button ViewRptBtn;

		private Label label3;

		private ComboBox ItemcomboBox;

		private Label label2;

		private Label label1;

		private GroupBox groupBox2;

		private CrystalReportViewer crystalReportViewer1;

		private DataSet1 dataSet11;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlSelectCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlInsertCommand2;

		private SqlCommand sqlUpdateCommand2;

		private SqlCommand sqlDeleteCommand2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlSelectCommand3;

		private SqlCommand sqlInsertCommand3;

		private SqlCommand sqlUpdateCommand3;

		private SqlCommand sqlDeleteCommand3;

		private SqlDataAdapter sqlDataAdapter3;

		private SqlConnection sqlConnection3;

		public FrmRptSahbItem()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		private void FrmRptSahbItem_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("select Id,Name from Items");
				DataRow dataRow = dataTable.NewRow();
				if (Settings.Default.Language == "en-GB")
				{
					dataRow["Name"] = "All";
				}
				else
				{
					dataRow["Name"] = "الكل";
				}
				dataTable.Rows.InsertAt(dataRow, 0);
				ItemcomboBox.DataSource = dataTable;
				ItemcomboBox.ValueMember = "Id";
				ItemcomboBox.DisplayMember = "Name";
			}
			catch
			{
			}
			comboBox1.SelectedIndex = 0;
		}

		private void ViewRptBtn_Click(object sender, EventArgs e)
		{
			try
			{
				dataSet11.Clear();
				sqlConnection1.ConnectionString = Codes.ConnectionStr;
				sqlConnection2.ConnectionString = Codes.ConnectionStr;
				sqlConnection3.ConnectionString = Codes.ConnectionStr;
				if (ItemcomboBox.SelectedIndex == 0)
				{
					if (comboBox1.SelectedIndex == 0)
					{
						sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
						sqlDataAdapter1.SelectCommand.CommandText = "select * from SahbItem where Date between '" + date1.Value.ToShortDateString() + "' and '" + date2.Value.ToShortDateString() + "'";
					}
					else
					{
						sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
						sqlDataAdapter1.SelectCommand.CommandText = "select * from SahbItem where TypeSahb = '" + comboBox1.Text + "' and Date between '" + date1.Value.ToShortDateString() + "' and '" + date2.Value.ToShortDateString() + "'";
					}
				}
				else if (comboBox1.SelectedIndex == 0)
				{
					sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
					sqlDataAdapter1.SelectCommand.CommandText = string.Concat("select * from SahbItem where ItemId = '", ItemcomboBox.SelectedValue, "' and Date between '", date1.Value.ToShortDateString(), "' and '", date2.Value.ToShortDateString(), "'");
				}
				else
				{
					sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
					sqlDataAdapter1.SelectCommand.CommandText = string.Concat("select * from SahbItem where ItemId = '", ItemcomboBox.SelectedValue, "' and TypeSahb = '", comboBox1.Text, "' and Date between '", date1.Value.ToShortDateString(), "' and '", date2.Value.ToShortDateString(), "'");
				}
				sqlDataAdapter1.Fill(dataSet11);
				sqlDataAdapter2.Fill(dataSet11);
				sqlDataAdapter3.Fill(dataSet11);
				((DataTable)(object)dataSet11.ReportData).Rows.Add(1, "", date1.Value, date2.Value);
				RptSahbItem rptSahbItem = new RptSahbItem();
				rptSahbItem.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = rptSahbItem;
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmRptSahbItem));
			groupBox1 = new System.Windows.Forms.GroupBox();
			comboBox1 = new System.Windows.Forms.ComboBox();
			label4 = new System.Windows.Forms.Label();
			date2 = new System.Windows.Forms.DateTimePicker();
			date1 = new System.Windows.Forms.DateTimePicker();
			ViewRptBtn = new System.Windows.Forms.Button();
			label3 = new System.Windows.Forms.Label();
			ItemcomboBox = new System.Windows.Forms.ComboBox();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			dataSet11 = new DataSet1();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlConnection3 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand3 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter3 = new System.Data.SqlClient.SqlDataAdapter();
			groupBox1.SuspendLayout();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(comboBox1);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(date2);
			groupBox1.Controls.Add(date1);
			groupBox1.Controls.Add(ViewRptBtn);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(ItemcomboBox);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(label1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.Font = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Items.AddRange(new object[5]
			{
				resources.GetString("comboBox1.Items"),
				resources.GetString("comboBox1.Items1"),
				resources.GetString("comboBox1.Items2"),
				resources.GetString("comboBox1.Items3"),
				resources.GetString("comboBox1.Items4")
			});
			comboBox1.Name = "comboBox1";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Name = "label4";
			date2.AccessibleDescription = null;
			date2.AccessibleName = null;
			resources.ApplyResources(date2, "date2");
			date2.BackgroundImage = null;
			date2.CalendarFont = null;
			date2.Font = null;
			date2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date2.Name = "date2";
			date1.AccessibleDescription = null;
			date1.AccessibleName = null;
			resources.ApplyResources(date1, "date1");
			date1.BackgroundImage = null;
			date1.CalendarFont = null;
			date1.Font = null;
			date1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			date1.Name = "date1";
			ViewRptBtn.AccessibleDescription = null;
			ViewRptBtn.AccessibleName = null;
			resources.ApplyResources(ViewRptBtn, "ViewRptBtn");
			ViewRptBtn.BackColor = System.Drawing.Color.Gainsboro;
			ViewRptBtn.BackgroundImage = null;
			ViewRptBtn.Name = "ViewRptBtn";
			ViewRptBtn.UseVisualStyleBackColor = false;
			ViewRptBtn.Click += new System.EventHandler(ViewRptBtn_Click);
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			ItemcomboBox.AccessibleDescription = null;
			ItemcomboBox.AccessibleName = null;
			resources.ApplyResources(ItemcomboBox, "ItemcomboBox");
			ItemcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			ItemcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			ItemcomboBox.BackgroundImage = null;
			ItemcomboBox.Font = null;
			ItemcomboBox.FormattingEnabled = true;
			ItemcomboBox.Name = "ItemcomboBox";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			crystalReportViewer1.AccessibleDescription = null;
			crystalReportViewer1.AccessibleName = null;
			crystalReportViewer1.ActiveViewIndex = -1;
			resources.ApplyResources(crystalReportViewer1, "crystalReportViewer1");
			crystalReportViewer1.BackgroundImage = null;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.Font = null;
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlSelectCommand1.CommandText = "SELECT        SahbItem.*\r\nFROM            SahbItem";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[5]
			{
				new System.Data.SqlClient.SqlParameter("@TypeSahb", System.Data.SqlDbType.NVarChar, 0, "TypeSahb"),
				new System.Data.SqlClient.SqlParameter("@ItemId", System.Data.SqlDbType.Int, 0, "ItemId"),
				new System.Data.SqlClient.SqlParameter("@Qty", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Qty", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
				new System.Data.SqlClient.SqlParameter("@Notes", System.Data.SqlDbType.NVarChar, 0, "Notes")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[15]
			{
				new System.Data.SqlClient.SqlParameter("@TypeSahb", System.Data.SqlDbType.NVarChar, 0, "TypeSahb"),
				new System.Data.SqlClient.SqlParameter("@ItemId", System.Data.SqlDbType.Int, 0, "ItemId"),
				new System.Data.SqlClient.SqlParameter("@Qty", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Qty", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
				new System.Data.SqlClient.SqlParameter("@Notes", System.Data.SqlDbType.NVarChar, 0, "Notes"),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_TypeSahb", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "TypeSahb", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_TypeSahb", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "TypeSahb", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Qty", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Qty", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Qty", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Qty", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Date", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Date", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Date", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Date", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[9]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_TypeSahb", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "TypeSahb", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_TypeSahb", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "TypeSahb", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ItemId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ItemId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ItemId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Qty", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Qty", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Qty", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Qty", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Date", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Date", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Date", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Date", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "SahbItem", new System.Data.Common.DataColumnMapping[6]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("TypeSahb", "TypeSahb"),
					new System.Data.Common.DataColumnMapping("ItemId", "ItemId"),
					new System.Data.Common.DataColumnMapping("Qty", "Qty"),
					new System.Data.Common.DataColumnMapping("Date", "Date"),
					new System.Data.Common.DataColumnMapping("Notes", "Notes")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			sqlSelectCommand2.CommandText = "SELECT        Items.*\r\nFROM            Items";
			sqlSelectCommand2.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.CommandText = "INSERT INTO [Items] ([Name], [SalePrice]) VALUES (@Name, @SalePrice);\r\nSELECT Id, Name, SalePrice FROM Items WHERE (Id = SCOPE_IDENTITY())";
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@SalePrice", System.Data.SqlDbType.Money, 0, "SalePrice")
			});
			sqlUpdateCommand2.CommandText = resources.GetString("sqlUpdateCommand2.CommandText");
			sqlUpdateCommand2.Connection = sqlConnection2;
			sqlUpdateCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[8]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@SalePrice", System.Data.SqlDbType.Money, 0, "SalePrice"),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Name", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Name", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Name", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Name", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SalePrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SalePrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SalePrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SalePrice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDeleteCommand2.CommandText = resources.GetString("sqlDeleteCommand2.CommandText");
			sqlDeleteCommand2.Connection = sqlConnection2;
			sqlDeleteCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[5]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Name", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Name", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Name", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Name", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SalePrice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SalePrice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SalePrice", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SalePrice", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter2.DeleteCommand = sqlDeleteCommand2;
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Items", new System.Data.Common.DataColumnMapping[3]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("Name", "Name"),
					new System.Data.Common.DataColumnMapping("SalePrice", "SalePrice")
				})
			});
			sqlDataAdapter2.UpdateCommand = sqlUpdateCommand2;
			sqlSelectCommand3.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand3.Connection = sqlConnection3;
			sqlConnection3.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection3.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand3.CommandText = resources.GetString("sqlInsertCommand3.CommandText");
			sqlInsertCommand3.Connection = sqlConnection3;
			sqlInsertCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[10]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType")
			});
			sqlUpdateCommand3.CommandText = resources.GetString("sqlUpdateCommand3.CommandText");
			sqlUpdateCommand3.Connection = sqlConnection3;
			sqlUpdateCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[26]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlDeleteCommand3.CommandText = resources.GetString("sqlDeleteCommand3.CommandText");
			sqlDeleteCommand3.Connection = sqlConnection3;
			sqlDeleteCommand3.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[15]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter3.DeleteCommand = sqlDeleteCommand3;
			sqlDataAdapter3.InsertCommand = sqlInsertCommand3;
			sqlDataAdapter3.SelectCommand = sqlSelectCommand3;
			sqlDataAdapter3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[11]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData"),
					new System.Data.Common.DataColumnMapping("Powred", "Powred"),
					new System.Data.Common.DataColumnMapping("ClinicType", "ClinicType")
				})
			});
			sqlDataAdapter3.UpdateCommand = sqlUpdateCommand3;
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox2);
			Font = null;
			base.Name = "FrmRptSahbItem";
			base.Load += new System.EventHandler(FrmRptSahbItem_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}
	}
}
