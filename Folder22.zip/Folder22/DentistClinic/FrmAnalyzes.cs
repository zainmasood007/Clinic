using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using DentistClinic.Properties;
using FloatTextBox;

namespace DentistClinic
{
	public class FrmAnalyzes : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private ComboBox PatientComboBox;

		private Label label1;

		private GroupBox groupBox2;

		private PictureBox pictureBox1;

		private Button browseBtn;

		private Button AddBtn;

		private TextBox textBox1;

		private Label label3;

		private DateTimePicker dateTimePicker1;

		private Label label2;

		private Button searchBtn;

		private Button deleteBtn;

		private Button EditBtn;

		private GroupBox groupBox3;

		private DataGridView dataGridView1;

		private GroupBox searchGrop;

		private ComboBox comboBox1;

		private Label label4;

		private Button button1;

		private GroupBox groupBox4;

		private Button button2;

		private Button button3;

		private GroupBox groupBox5;

		private CheckBox checkBox1;

		private Label label5;

		private CheckBox checkBox2;

		private FloatText payFloatText;

		private ComboBox doctorcomboBox;

		private Label label7;

		private Label label8;

		private FloatText floatText1;

		private Label label9;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlDeleteCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlSelectCommand1;

		private SqlCommand sqlUpdateCommand1;

		private ComboBox nameTextBox;

		private Label label10;

		private Panel PaidPanel;

		private ComboBox TreasuryCom;

		private TextBox EsalNoTxt;

		private Label lblTreasury;

		private Label label45;

		private SqlConnection sqlConnection2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlCommand1;

		private SqlCommand sqlSelectCommand2;

		private Button ViewFile;

		private Button button4;

		private OpenFileDialog openFileDialog1;

		private Panel panel1;

		private Button button7;

		private Button button8;

		private Button button6;

		private Button button5;

		private Label label11;

		private Label label6;

		private ClassDataBase dc;

		private byte[] PaientRay;

		private int PatientRayID;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private string stockId;

		private decimal discount;

		private decimal Pprice;

		private GUI gui = new GUI();

		private int PatientId;

		private bool Free;

		private bool pay;

		private DataSet1 ds = new DataSet1();

		private string PatientAccountID;

		private decimal Account;

		private string companyId;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private bool checkPay = false;

		private string filename = "";

		private bool Nesba = false;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmAnalyzes));
			groupBox1 = new System.Windows.Forms.GroupBox();
			PaidPanel = new System.Windows.Forms.Panel();
			TreasuryCom = new System.Windows.Forms.ComboBox();
			EsalNoTxt = new System.Windows.Forms.TextBox();
			lblTreasury = new System.Windows.Forms.Label();
			label45 = new System.Windows.Forms.Label();
			label10 = new System.Windows.Forms.Label();
			nameTextBox = new System.Windows.Forms.ComboBox();
			label9 = new System.Windows.Forms.Label();
			label8 = new System.Windows.Forms.Label();
			floatText1 = new FloatTextBox.FloatText();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			label7 = new System.Windows.Forms.Label();
			groupBox5 = new System.Windows.Forms.GroupBox();
			label5 = new System.Windows.Forms.Label();
			checkBox2 = new System.Windows.Forms.CheckBox();
			payFloatText = new FloatTextBox.FloatText();
			checkBox1 = new System.Windows.Forms.CheckBox();
			textBox1 = new System.Windows.Forms.TextBox();
			label3 = new System.Windows.Forms.Label();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label2 = new System.Windows.Forms.Label();
			PatientComboBox = new System.Windows.Forms.ComboBox();
			label1 = new System.Windows.Forms.Label();
			groupBox2 = new System.Windows.Forms.GroupBox();
			searchGrop = new System.Windows.Forms.GroupBox();
			button1 = new System.Windows.Forms.Button();
			comboBox1 = new System.Windows.Forms.ComboBox();
			label4 = new System.Windows.Forms.Label();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			browseBtn = new System.Windows.Forms.Button();
			AddBtn = new System.Windows.Forms.Button();
			searchBtn = new System.Windows.Forms.Button();
			deleteBtn = new System.Windows.Forms.Button();
			EditBtn = new System.Windows.Forms.Button();
			groupBox3 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox4 = new System.Windows.Forms.GroupBox();
			button3 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			ViewFile = new System.Windows.Forms.Button();
			button4 = new System.Windows.Forms.Button();
			openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			panel1 = new System.Windows.Forms.Panel();
			button7 = new System.Windows.Forms.Button();
			button8 = new System.Windows.Forms.Button();
			button6 = new System.Windows.Forms.Button();
			button5 = new System.Windows.Forms.Button();
			label11 = new System.Windows.Forms.Label();
			label6 = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			PaidPanel.SuspendLayout();
			groupBox5.SuspendLayout();
			groupBox2.SuspendLayout();
			searchGrop.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox4.SuspendLayout();
			panel1.SuspendLayout();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(label10);
			groupBox1.Controls.Add(nameTextBox);
			groupBox1.Controls.Add(label9);
			groupBox1.Controls.Add(label8);
			groupBox1.Controls.Add(floatText1);
			groupBox1.Controls.Add(doctorcomboBox);
			groupBox1.Controls.Add(label7);
			groupBox1.Controls.Add(groupBox5);
			groupBox1.Controls.Add(checkBox1);
			groupBox1.Controls.Add(textBox1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(dateTimePicker1);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(PatientComboBox);
			groupBox1.Controls.Add(label1);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			PaidPanel.AccessibleDescription = null;
			PaidPanel.AccessibleName = null;
			resources.ApplyResources(PaidPanel, "PaidPanel");
			PaidPanel.BackColor = System.Drawing.Color.Transparent;
			PaidPanel.BackgroundImage = null;
			PaidPanel.Controls.Add(TreasuryCom);
			PaidPanel.Controls.Add(EsalNoTxt);
			PaidPanel.Controls.Add(lblTreasury);
			PaidPanel.Controls.Add(label45);
			PaidPanel.Font = null;
			PaidPanel.Name = "PaidPanel";
			TreasuryCom.AccessibleDescription = null;
			TreasuryCom.AccessibleName = null;
			resources.ApplyResources(TreasuryCom, "TreasuryCom");
			TreasuryCom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			TreasuryCom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			TreasuryCom.BackgroundImage = null;
			TreasuryCom.FormattingEnabled = true;
			TreasuryCom.Name = "TreasuryCom";
			EsalNoTxt.AccessibleDescription = null;
			EsalNoTxt.AccessibleName = null;
			resources.ApplyResources(EsalNoTxt, "EsalNoTxt");
			EsalNoTxt.BackgroundImage = null;
			EsalNoTxt.Font = null;
			EsalNoTxt.Name = "EsalNoTxt";
			EsalNoTxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(EsalNoTxt_KeyPress);
			lblTreasury.AccessibleDescription = null;
			lblTreasury.AccessibleName = null;
			resources.ApplyResources(lblTreasury, "lblTreasury");
			lblTreasury.BackColor = System.Drawing.Color.Transparent;
			lblTreasury.Name = "lblTreasury";
			label45.AccessibleDescription = null;
			label45.AccessibleName = null;
			resources.ApplyResources(label45, "label45");
			label45.BackColor = System.Drawing.Color.Transparent;
			label45.Name = "label45";
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "label10");
			label10.BackColor = System.Drawing.Color.Black;
			label10.ForeColor = System.Drawing.Color.White;
			label10.Name = "label10";
			nameTextBox.AccessibleDescription = null;
			nameTextBox.AccessibleName = null;
			resources.ApplyResources(nameTextBox, "nameTextBox");
			nameTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			nameTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			nameTextBox.BackgroundImage = null;
			nameTextBox.FormattingEnabled = true;
			nameTextBox.Name = "nameTextBox";
			nameTextBox.SelectedIndexChanged += new System.EventHandler(nameTextBox_SelectedIndexChanged);
			nameTextBox.TextChanged += new System.EventHandler(nameTextBox_SelectedIndexChanged);
			label9.AccessibleDescription = null;
			label9.AccessibleName = null;
			resources.ApplyResources(label9, "label9");
			label9.BackColor = System.Drawing.Color.Transparent;
			label9.Name = "label9";
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "label8");
			label8.BackColor = System.Drawing.Color.Transparent;
			label8.Name = "label8";
			floatText1.AccessibleDescription = null;
			floatText1.AccessibleName = null;
			resources.ApplyResources(floatText1, "floatText1");
			floatText1.BackgroundImage = null;
			floatText1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText1.Name = "floatText1";
			floatText1.ReadOnly = true;
			doctorcomboBox.AccessibleDescription = null;
			doctorcomboBox.AccessibleName = null;
			resources.ApplyResources(doctorcomboBox, "doctorcomboBox");
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.BackgroundImage = null;
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Name = "doctorcomboBox";
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "label7");
			label7.BackColor = System.Drawing.Color.Transparent;
			label7.Name = "label7";
			groupBox5.AccessibleDescription = null;
			groupBox5.AccessibleName = null;
			resources.ApplyResources(groupBox5, "groupBox5");
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.BackgroundImage = null;
			groupBox5.Controls.Add(PaidPanel);
			groupBox5.Controls.Add(label5);
			groupBox5.Controls.Add(checkBox2);
			groupBox5.Controls.Add(payFloatText);
			groupBox5.Font = null;
			groupBox5.Name = "groupBox5";
			groupBox5.TabStop = false;
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label5");
			label5.BackColor = System.Drawing.Color.Transparent;
			label5.Name = "label5";
			checkBox2.AccessibleDescription = null;
			checkBox2.AccessibleName = null;
			resources.ApplyResources(checkBox2, "checkBox2");
			checkBox2.BackgroundImage = null;
			checkBox2.Name = "checkBox2";
			checkBox2.UseVisualStyleBackColor = true;
			checkBox2.CheckedChanged += new System.EventHandler(checkBox2_CheckedChanged);
			payFloatText.AccessibleDescription = null;
			payFloatText.AccessibleName = null;
			resources.ApplyResources(payFloatText, "payFloatText");
			payFloatText.BackgroundImage = null;
			payFloatText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			payFloatText.Name = "payFloatText";
			checkBox1.AccessibleDescription = null;
			checkBox1.AccessibleName = null;
			resources.ApplyResources(checkBox1, "checkBox1");
			checkBox1.BackgroundImage = null;
			checkBox1.Name = "checkBox1";
			checkBox1.UseVisualStyleBackColor = true;
			checkBox1.CheckedChanged += new System.EventHandler(checkBox1_CheckedChanged);
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Name = "textBox1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.BackColor = System.Drawing.Color.Transparent;
			label3.Name = "label3";
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.BackColor = System.Drawing.Color.Transparent;
			label2.Name = "label2";
			PatientComboBox.AccessibleDescription = null;
			PatientComboBox.AccessibleName = null;
			resources.ApplyResources(PatientComboBox, "PatientComboBox");
			PatientComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			PatientComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientComboBox.BackgroundImage = null;
			PatientComboBox.FormattingEnabled = true;
			PatientComboBox.Name = "PatientComboBox";
			PatientComboBox.SelectedIndexChanged += new System.EventHandler(PatientComboBox_SelectedIndexChanged);
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.BackColor = System.Drawing.Color.Transparent;
			label1.Name = "label1";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(searchGrop);
			groupBox2.Controls.Add(pictureBox1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			searchGrop.AccessibleDescription = null;
			searchGrop.AccessibleName = null;
			resources.ApplyResources(searchGrop, "searchGrop");
			searchGrop.BackColor = System.Drawing.Color.Transparent;
			searchGrop.BackgroundImage = null;
			searchGrop.Controls.Add(button1);
			searchGrop.Controls.Add(comboBox1);
			searchGrop.Controls.Add(label4);
			searchGrop.Font = null;
			searchGrop.Name = "searchGrop";
			searchGrop.TabStop = false;
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.BackgroundImage = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.Font = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Name = "comboBox1";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.BackColor = System.Drawing.Color.Transparent;
			label4.Name = "label4";
			pictureBox1.AccessibleDescription = null;
			pictureBox1.AccessibleName = null;
			resources.ApplyResources(pictureBox1, "pictureBox1");
			pictureBox1.BackgroundImage = null;
			pictureBox1.Font = null;
			pictureBox1.ImageLocation = null;
			pictureBox1.Name = "pictureBox1";
			pictureBox1.TabStop = false;
			pictureBox1.Click += new System.EventHandler(pictureBox1_Click);
			browseBtn.AccessibleDescription = null;
			browseBtn.AccessibleName = null;
			resources.ApplyResources(browseBtn, "browseBtn");
			browseBtn.BackColor = System.Drawing.Color.Gainsboro;
			browseBtn.BackgroundImage = null;
			browseBtn.Name = "browseBtn";
			browseBtn.UseVisualStyleBackColor = false;
			browseBtn.Click += new System.EventHandler(browseBtn_Click);
			AddBtn.AccessibleDescription = null;
			AddBtn.AccessibleName = null;
			resources.ApplyResources(AddBtn, "AddBtn");
			AddBtn.BackColor = System.Drawing.Color.Gainsboro;
			AddBtn.BackgroundImage = null;
			AddBtn.Name = "AddBtn";
			AddBtn.UseVisualStyleBackColor = false;
			AddBtn.Click += new System.EventHandler(AddBtn_Click);
			searchBtn.AccessibleDescription = null;
			searchBtn.AccessibleName = null;
			resources.ApplyResources(searchBtn, "searchBtn");
			searchBtn.BackColor = System.Drawing.Color.Gainsboro;
			searchBtn.BackgroundImage = null;
			searchBtn.Name = "searchBtn";
			searchBtn.UseVisualStyleBackColor = false;
			searchBtn.Click += new System.EventHandler(searchBtn_Click);
			deleteBtn.AccessibleDescription = null;
			deleteBtn.AccessibleName = null;
			resources.ApplyResources(deleteBtn, "deleteBtn");
			deleteBtn.BackColor = System.Drawing.Color.Gainsboro;
			deleteBtn.BackgroundImage = null;
			deleteBtn.Name = "deleteBtn";
			deleteBtn.UseVisualStyleBackColor = false;
			deleteBtn.Click += new System.EventHandler(deleteBtn_Click);
			EditBtn.AccessibleDescription = null;
			EditBtn.AccessibleName = null;
			resources.ApplyResources(EditBtn, "EditBtn");
			EditBtn.BackColor = System.Drawing.Color.Gainsboro;
			EditBtn.BackgroundImage = null;
			EditBtn.Name = "EditBtn";
			EditBtn.UseVisualStyleBackColor = false;
			EditBtn.Click += new System.EventHandler(EditBtn_Click);
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(dataGridView1);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.BackgroundImage = null;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseClick);
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(button3);
			groupBox4.Controls.Add(button2);
			groupBox4.Controls.Add(AddBtn);
			groupBox4.Controls.Add(searchBtn);
			groupBox4.Controls.Add(EditBtn);
			groupBox4.Controls.Add(deleteBtn);
			groupBox4.Font = null;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackColor = System.Drawing.Color.Gainsboro;
			button3.BackgroundImage = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = false;
			button3.Click += new System.EventHandler(button3_Click);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackColor = System.Drawing.Color.Gainsboro;
			button2.BackgroundImage = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = false;
			button2.Click += new System.EventHandler(button2_Click);
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[14]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
					new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
					new System.Data.Common.DataColumnMapping("DTel", "DTel"),
					new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
					new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
					new System.Data.Common.DataColumnMapping("DSite", "DSite"),
					new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
					new System.Data.Common.DataColumnMapping("WorkData", "WorkData"),
					new System.Data.Common.DataColumnMapping("Powred", "Powred"),
					new System.Data.Common.DataColumnMapping("ClinicType", "ClinicType"),
					new System.Data.Common.DataColumnMapping("EyeClinic", "EyeClinic"),
					new System.Data.Common.DataColumnMapping("FemaleClinic", "FemaleClinic"),
					new System.Data.Common.DataColumnMapping("NaturalClinic", "NaturalClinic")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[21]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[13]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic")
			});
			sqlSelectCommand1.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[35]
			{
				new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
				new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
				new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
				new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
				new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
				new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
				new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
				new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
				new System.Data.SqlClient.SqlParameter("@Powred", System.Data.SqlDbType.NVarChar, 0, "Powred"),
				new System.Data.SqlClient.SqlParameter("@ClinicType", System.Data.SqlDbType.Bit, 0, "ClinicType"),
				new System.Data.SqlClient.SqlParameter("@EyeClinic", System.Data.SqlDbType.Bit, 0, "EyeClinic"),
				new System.Data.SqlClient.SqlParameter("@FemaleClinic", System.Data.SqlDbType.Bit, 0, "FemaleClinic"),
				new System.Data.SqlClient.SqlParameter("@NaturalClinic", System.Data.SqlDbType.Bit, 0, "NaturalClinic"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DTel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DMobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DEmail", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "DSite", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Powred", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Powred", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Powred", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Powred", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_ClinicType", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_ClinicType", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ClinicType", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_EyeClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_EyeClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "EyeClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_FemaleClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_FemaleClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "FemaleClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NaturalClinic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NaturalClinic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NaturalClinic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlDataAdapter2.InsertCommand = sqlCommand1;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[51]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
					new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
					new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
					new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
					new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
					new System.Data.Common.DataColumnMapping("Implant", "Implant"),
					new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
					new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers"),
					new System.Data.Common.DataColumnMapping("DoctoreName", "DoctoreName"),
					new System.Data.Common.DataColumnMapping("NextVisit", "NextVisit"),
					new System.Data.Common.DataColumnMapping("Accept", "Accept"),
					new System.Data.Common.DataColumnMapping("Taqweem", "Taqweem"),
					new System.Data.Common.DataColumnMapping("Photo", "Photo"),
					new System.Data.Common.DataColumnMapping("BloodType", "BloodType"),
					new System.Data.Common.DataColumnMapping("Active", "Active"),
					new System.Data.Common.DataColumnMapping("FileNo", "FileNo"),
					new System.Data.Common.DataColumnMapping("Patient", "Patient"),
					new System.Data.Common.DataColumnMapping("Facebook", "Facebook"),
					new System.Data.Common.DataColumnMapping("Adv", "Adv"),
					new System.Data.Common.DataColumnMapping("FormerPatient", "FormerPatient"),
					new System.Data.Common.DataColumnMapping("Discount", "Discount"),
					new System.Data.Common.DataColumnMapping("Without", "Without"),
					new System.Data.Common.DataColumnMapping("Doctor", "Doctor"),
					new System.Data.Common.DataColumnMapping("DoctorId", "DoctorId")
				})
			});
			sqlCommand1.CommandText = resources.GetString("sqlCommand1.CommandText");
			sqlCommand1.Connection = sqlConnection2;
			sqlCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[50]
			{
				new System.Data.SqlClient.SqlParameter("@Titel", System.Data.SqlDbType.NVarChar, 0, "Titel"),
				new System.Data.SqlClient.SqlParameter("@PName", System.Data.SqlDbType.NVarChar, 0, "PName"),
				new System.Data.SqlClient.SqlParameter("@PAddress", System.Data.SqlDbType.NVarChar, 0, "PAddress"),
				new System.Data.SqlClient.SqlParameter("@City", System.Data.SqlDbType.NVarChar, 0, "City"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mob", System.Data.SqlDbType.NVarChar, 0, "Mob"),
				new System.Data.SqlClient.SqlParameter("@Email", System.Data.SqlDbType.NVarChar, 0, "Email"),
				new System.Data.SqlClient.SqlParameter("@BirthDate", System.Data.SqlDbType.DateTime, 0, "BirthDate"),
				new System.Data.SqlClient.SqlParameter("@Sex", System.Data.SqlDbType.NVarChar, 0, "Sex"),
				new System.Data.SqlClient.SqlParameter("@Nationality", System.Data.SqlDbType.NVarChar, 0, "Nationality"),
				new System.Data.SqlClient.SqlParameter("@Statue", System.Data.SqlDbType.NVarChar, 0, "Statue"),
				new System.Data.SqlClient.SqlParameter("@company", System.Data.SqlDbType.Int, 0, "company"),
				new System.Data.SqlClient.SqlParameter("@cardNum", System.Data.SqlDbType.NVarChar, 0, "cardNum"),
				new System.Data.SqlClient.SqlParameter("@LastVistDate", System.Data.SqlDbType.DateTime, 0, "LastVistDate"),
				new System.Data.SqlClient.SqlParameter("@Allergies", System.Data.SqlDbType.Bit, 0, "Allergies"),
				new System.Data.SqlClient.SqlParameter("@CardiacDisease", System.Data.SqlDbType.Bit, 0, "CardiacDisease"),
				new System.Data.SqlClient.SqlParameter("@KidneyDesease", System.Data.SqlDbType.Bit, 0, "KidneyDesease"),
				new System.Data.SqlClient.SqlParameter("@Diabetes", System.Data.SqlDbType.Bit, 0, "Diabetes"),
				new System.Data.SqlClient.SqlParameter("@RheumaticFever", System.Data.SqlDbType.Bit, 0, "RheumaticFever"),
				new System.Data.SqlClient.SqlParameter("@Asthma", System.Data.SqlDbType.Bit, 0, "Asthma"),
				new System.Data.SqlClient.SqlParameter("@BloodDyscrasias", System.Data.SqlDbType.Bit, 0, "BloodDyscrasias"),
				new System.Data.SqlClient.SqlParameter("@Lactating", System.Data.SqlDbType.Bit, 0, "Lactating"),
				new System.Data.SqlClient.SqlParameter("@Pregnant", System.Data.SqlDbType.Bit, 0, "Pregnant"),
				new System.Data.SqlClient.SqlParameter("@HepatitisB", System.Data.SqlDbType.Bit, 0, "HepatitisB"),
				new System.Data.SqlClient.SqlParameter("@Hepatitisc", System.Data.SqlDbType.Bit, 0, "Hepatitisc"),
				new System.Data.SqlClient.SqlParameter("@HistoryOther", System.Data.SqlDbType.NVarChar, 0, "HistoryOther"),
				new System.Data.SqlClient.SqlParameter("@Extraction", System.Data.SqlDbType.Bit, 0, "Extraction"),
				new System.Data.SqlClient.SqlParameter("@PeriodontalTherpy", System.Data.SqlDbType.Bit, 0, "PeriodontalTherpy"),
				new System.Data.SqlClient.SqlParameter("@Endodontics", System.Data.SqlDbType.Bit, 0, "Endodontics"),
				new System.Data.SqlClient.SqlParameter("@Fixed", System.Data.SqlDbType.Bit, 0, "Fixed"),
				new System.Data.SqlClient.SqlParameter("@Implant", System.Data.SqlDbType.Bit, 0, "Implant"),
				new System.Data.SqlClient.SqlParameter("@Opretive", System.Data.SqlDbType.Bit, 0, "Opretive"),
				new System.Data.SqlClient.SqlParameter("@Bleaching", System.Data.SqlDbType.Bit, 0, "Bleaching"),
				new System.Data.SqlClient.SqlParameter("@PrviousHistoryOthers", System.Data.SqlDbType.NVarChar, 0, "PrviousHistoryOthers"),
				new System.Data.SqlClient.SqlParameter("@DoctoreName", System.Data.SqlDbType.NVarChar, 0, "DoctoreName"),
				new System.Data.SqlClient.SqlParameter("@NextVisit", System.Data.SqlDbType.NVarChar, 0, "NextVisit"),
				new System.Data.SqlClient.SqlParameter("@Accept", System.Data.SqlDbType.Bit, 0, "Accept"),
				new System.Data.SqlClient.SqlParameter("@Taqweem", System.Data.SqlDbType.Bit, 0, "Taqweem"),
				new System.Data.SqlClient.SqlParameter("@Photo", System.Data.SqlDbType.Image, 0, "Photo"),
				new System.Data.SqlClient.SqlParameter("@BloodType", System.Data.SqlDbType.NVarChar, 0, "BloodType"),
				new System.Data.SqlClient.SqlParameter("@Active", System.Data.SqlDbType.Bit, 0, "Active"),
				new System.Data.SqlClient.SqlParameter("@FileNo", System.Data.SqlDbType.Int, 0, "FileNo"),
				new System.Data.SqlClient.SqlParameter("@Patient", System.Data.SqlDbType.Bit, 0, "Patient"),
				new System.Data.SqlClient.SqlParameter("@Facebook", System.Data.SqlDbType.Bit, 0, "Facebook"),
				new System.Data.SqlClient.SqlParameter("@Adv", System.Data.SqlDbType.Bit, 0, "Adv"),
				new System.Data.SqlClient.SqlParameter("@FormerPatient", System.Data.SqlDbType.NVarChar, 0, "FormerPatient"),
				new System.Data.SqlClient.SqlParameter("@Discount", System.Data.SqlDbType.Decimal, 0, System.Data.ParameterDirection.Input, false, 18, 2, "Discount", System.Data.DataRowVersion.Current, null),
				new System.Data.SqlClient.SqlParameter("@Without", System.Data.SqlDbType.Bit, 0, "Without"),
				new System.Data.SqlClient.SqlParameter("@Doctor", System.Data.SqlDbType.Bit, 0, "Doctor"),
				new System.Data.SqlClient.SqlParameter("@DoctorId", System.Data.SqlDbType.NVarChar, 0, "DoctorId")
			});
			sqlSelectCommand2.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlSelectCommand2.Connection = sqlConnection2;
			ViewFile.AccessibleDescription = null;
			ViewFile.AccessibleName = null;
			resources.ApplyResources(ViewFile, "ViewFile");
			ViewFile.BackColor = System.Drawing.Color.Gainsboro;
			ViewFile.BackgroundImage = null;
			ViewFile.Name = "ViewFile";
			ViewFile.UseVisualStyleBackColor = false;
			ViewFile.Click += new System.EventHandler(ViewFile_Click);
			button4.AccessibleDescription = null;
			button4.AccessibleName = null;
			resources.ApplyResources(button4, "button4");
			button4.BackColor = System.Drawing.Color.Gainsboro;
			button4.BackgroundImage = null;
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = false;
			button4.Click += new System.EventHandler(button4_Click);
			openFileDialog1.FileName = "openFileDialog1";
			resources.ApplyResources(openFileDialog1, "openFileDialog1");
			panel1.AccessibleDescription = null;
			panel1.AccessibleName = null;
			resources.ApplyResources(panel1, "panel1");
			panel1.BackColor = System.Drawing.Color.Transparent;
			panel1.BackgroundImage = null;
			panel1.Controls.Add(button7);
			panel1.Controls.Add(button8);
			panel1.Controls.Add(button6);
			panel1.Controls.Add(button5);
			panel1.Controls.Add(label11);
			panel1.Controls.Add(label6);
			panel1.Font = null;
			panel1.Name = "panel1";
			button7.AccessibleDescription = null;
			button7.AccessibleName = null;
			resources.ApplyResources(button7, "button7");
			button7.BackColor = System.Drawing.Color.Gainsboro;
			button7.BackgroundImage = null;
			button7.Name = "button7";
			button7.UseVisualStyleBackColor = false;
			button7.Click += new System.EventHandler(button7_Click);
			button8.AccessibleDescription = null;
			button8.AccessibleName = null;
			resources.ApplyResources(button8, "button8");
			button8.BackColor = System.Drawing.Color.Gainsboro;
			button8.BackgroundImage = null;
			button8.Name = "button8";
			button8.UseVisualStyleBackColor = false;
			button8.Click += new System.EventHandler(button8_Click);
			button6.AccessibleDescription = null;
			button6.AccessibleName = null;
			resources.ApplyResources(button6, "button6");
			button6.BackColor = System.Drawing.Color.Gainsboro;
			button6.BackgroundImage = null;
			button6.Name = "button6";
			button6.UseVisualStyleBackColor = false;
			button6.Click += new System.EventHandler(button6_Click);
			button5.AccessibleDescription = null;
			button5.AccessibleName = null;
			resources.ApplyResources(button5, "button5");
			button5.BackColor = System.Drawing.Color.Gainsboro;
			button5.BackgroundImage = null;
			button5.Name = "button5";
			button5.UseVisualStyleBackColor = false;
			button5.Click += new System.EventHandler(button5_Click);
			label11.AccessibleDescription = null;
			label11.AccessibleName = null;
			resources.ApplyResources(label11, "label11");
			label11.BackColor = System.Drawing.Color.Transparent;
			label11.Name = "label11";
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "label6");
			label6.BackColor = System.Drawing.Color.Transparent;
			label6.Name = "label6";
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			BackgroundImage = null;
			base.Controls.Add(panel1);
			base.Controls.Add(ViewFile);
			base.Controls.Add(button4);
			base.Controls.Add(groupBox4);
			base.Controls.Add(groupBox3);
			base.Controls.Add(browseBtn);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.MaximizeBox = true;
			base.Name = "FrmAnalyzes";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.Load += new System.EventHandler(FrmImage_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(FrmImage_KeyDown);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			PaidPanel.ResumeLayout(false);
			PaidPanel.PerformLayout();
			groupBox5.ResumeLayout(false);
			groupBox5.PerformLayout();
			groupBox2.ResumeLayout(false);
			searchGrop.ResumeLayout(false);
			searchGrop.PerformLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox4.ResumeLayout(false);
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			ResumeLayout(false);
		}

		public FrmAnalyzes(int Patient)
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			PatientId = Patient;
		}

		private void browseBtn_Click(object sender, EventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog();
			DialogResult dialogResult = openFileDialog.ShowDialog();
			openFileDialog.Filter = "image type |*.png;*.jpg;*.jpeg;*.bmb;*.gif";
			if (dialogResult != DialogResult.Cancel)
			{
				PaientRay = GetImage(openFileDialog.FileName);
				pictureBox1.BackgroundImage = Image.FromFile(openFileDialog.FileName);
			}
		}

		private byte[] GetImage(string path)
		{
			FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read);
			BinaryReader binaryReader = new BinaryReader(fileStream);
			byte[] result = binaryReader.ReadBytes(Convert.ToInt32(fileStream.Length));
			binaryReader.Close();
			fileStream.Close();
			return result;
		}

		private void FrmImage_Load(object sender, EventArgs e)
		{
			try
			{
				if (UsersClass.AutoEsal)
				{
					EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
					EsalNoTxt.Enabled = false;
				}
				else
				{
					EsalNoTxt.Text = "";
					EsalNoTxt.Enabled = true;
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataSource = codes.Search2("select distinct Name from RayAnalyze where Type = 'تحاليل'");
				nameTextBox.DataSource = dataSource;
				nameTextBox.DisplayMember = "Name";
			}
			catch
			{
			}
			if (PatientId == 0)
			{
				PatientComboBox.Enabled = true;
				DataTable dataTable = new DataTable();
				try
				{
					DataTable dataTable2 = new DataTable();
					if (Convert.ToBoolean(codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString()))
					{
						dataTable2 = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True' order by PName");
						PatientComboBox.DataSource = dataTable2;
						PatientComboBox.DisplayMember = dataTable2.Columns[1].ToString();
						PatientComboBox.ValueMember = dataTable2.Columns[0].ToString();
					}
					else
					{
						dataTable2 = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True' ");
						PatientComboBox.DataSource = dataTable2;
						PatientComboBox.DisplayMember = dataTable2.Columns[1].ToString();
						PatientComboBox.ValueMember = dataTable2.Columns[0].ToString();
					}
				}
				catch
				{
				}
				EditBtn.Enabled = false;
				AddBtn.Enabled = true;
				deleteBtn.Enabled = false;
			}
			else
			{
				PatientComboBox.Enabled = false;
				DataTable dataTable = new DataTable();
				try
				{
					dataTable = dc.Select("SelectAllPatient");
					gui.loadComboBox(PatientComboBox, dataTable);
				}
				catch
				{
				}
				EditBtn.Enabled = false;
				AddBtn.Enabled = true;
				deleteBtn.Enabled = false;
				button2.Enabled = false;
				PatientComboBox.SelectedValue = PatientId;
			}
			try
			{
				DataTable dataSource = dc.Select("SelectAllDoctor");
				gui.loadComboBox(doctorcomboBox, dataSource);
			}
			catch
			{
			}
			try
			{
				DataTable dataTable3 = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				TreasuryCom.DataSource = null;
				TreasuryCom.DataSource = dataTable3;
				TreasuryCom.DisplayMember = dataTable3.Columns[1].ToString();
				TreasuryCom.ValueMember = dataTable3.Columns[0].ToString();
			}
			catch
			{
			}
			payFloatText.Enabled = UsersClass.ChangeServicePrice;
			nameTextBox.Focus();
		}

		public void ClearData()
		{
			textBox1.Text = "";
			label8.Visible = false;
			floatText1.Visible = false;
			floatText1.Text = "0";
			PatientComboBox.Enabled = true;
			pictureBox1.BackgroundImage = null;
			payFloatText.Text = "0";
			checkBox1.Checked = false;
			checkBox2.Checked = false;
			nameTextBox.Text = "";
			try
			{
				DataTable dataSource = codes.Search2("select distinct Name from RayAnalyze where Type = 'تحاليل'");
				nameTextBox.DataSource = dataSource;
				nameTextBox.DisplayMember = "Name";
			}
			catch
			{
			}
		}

		private void AddBtn_Click(object sender, EventArgs e)
		{
			ds.Clear();
			if (checkBox2.Checked)
			{
				if (EsalNoTxt.Text == "")
				{
					MessageBox.Show("من فضلك ادخل رقم الايصال");
					return;
				}
				DataTable dataTable = codes.Search2("select EsalNo from Esal where EsalNo ='" + EsalNoTxt.Text + "'");
				if (dataTable.Rows.Count > 0)
				{
					MessageBox.Show("رقم الايصال مسجل من قبل");
					EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
				}
			}
			string[] fields = new string[8] { "PatientID", "AnalyzeImage", "AnalyzeDate", "AnalyzeNots", "Free", "DoctorId", "AnalyzeName", "AnalyzeFile" };
			try
			{
				DataTable tableText = dc.GetTableText("select * from PatientData where ID='" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "'");
				dc.GetTableText("select * from PatientAnalyze where AnalyzeName = '" + nameTextBox.Text + "' and PatientID = '" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "' and AnalyzeDate='" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "'");
				if (tableText.Rows.Count == 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Patient Name");
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم مريض صحيح");
					}
				}
				else if (nameTextBox.SelectedIndex == -1)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Analysis Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم التحليل", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else if (checkBox2.Checked && TreasuryCom.SelectedIndex == -1)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Treasury Name");
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم الخزينة");
					}
				}
				else
				{
					if (pictureBox1.BackgroundImage == null)
					{
						PaientRay = new byte[0];
					}
					try
					{
						if (Nesba)
						{
							Account = Convert.ToDecimal(payFloatText.Text) * discount / 100m;
						}
						else
						{
							Account = discount;
						}
						Pprice = Convert.ToDecimal(payFloatText.Text) - Account;
					}
					catch
					{
					}
					string text = EsalNoTxt.Text;
					if (dc.Insert("AddAnalyze", fields, Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), PaientRay, dateTimePicker1.Value.ToString("MM/dd/yyyy"), textBox1.Text, !checkBox1.Checked, Convert.ToInt32(doctorcomboBox.SelectedValue), nameTextBox.Text, filename))
					{
						if (checkBox1.Checked)
						{
							string value = codes.Search("select isnull(sum(Madeen),0) -  isnull(sum(Daen),0) from Company5 where CompanyId = '" + companyId + "'").Rows[0][0].ToString();
							string text2 = codes.Search2("select Max(ID) from PatientAnalyze").Rows[0][0].ToString();
							if (checkBox2.Checked)
							{
								string text3 = "";
								DataTable dataTable2 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
								try
								{
									text3 = dataTable2.Rows[0][0].ToString();
								}
								catch
								{
								}
								string text4 = codes.Search2("INSERT INTO PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay, BeanDate, StockId,AnalyzeId) values ('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue) + "','" + nameTextBox.Text + "','" + Pprice + "','True','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Pprice + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(TreasuryCom.SelectedValue) + "','" + text2 + "');select @@identity").Rows[0][0].ToString();
								if (Account != 0m)
								{
									codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + Account + "','" + (Convert.ToDouble(value) + Convert.ToDouble(Account)) + "','" + nameTextBox.Text + "'+' - '+'" + PatientComboBox.Text + "'+' - '+'" + doctorcomboBox.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(text4) + "')");
								}
								codes.Edit2("update Stock Set Value= Value + " + Pprice + " where ID = '" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "'");
								codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId) values ('تحليل' ,'" + Pprice + "','" + PatientComboBox.Text + " إيصال رقم: " + EsalNoTxt.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
								codes.Add2("insert into Esal (EsalNo, PatientAcountId, Date,Pay, Patient, Bean, Price, Teeth, Company, Username,Assistant) values('" + text + "','" + text4 + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToDecimal(payFloatText.Text) + "','" + PatientComboBox.Text + "','" + nameTextBox.Text + "','" + Convert.ToDecimal(payFloatText.Text) + "','','" + text3 + "','" + Main.usernames + "','')");
							}
							else
							{
								string text4 = codes.Search2("insert into PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay, BeanDate,AnalyzeId) values ('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue) + "','" + nameTextBox.Text + "','" + Pprice + "','False','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "',0,'" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + text2 + "');select @@identity").Rows[0][0].ToString();
								if (Account != 0m)
								{
									codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + Account + "','" + (Convert.ToDouble(value) + Convert.ToDouble(Account)) + "','" + nameTextBox.Text + "'+' - '+'" + PatientComboBox.Text + "'+' - '+'" + doctorcomboBox.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(text4) + "')");
								}
							}
						}
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Data Saved Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						MethodsClass.UserMove("أضافة تحليل لمريض");
						filename = "";
						openFileDialog1.FileName = "";
						ViewFile.Visible = false;
						if (checkBox2.Checked)
						{
							((DataTable)(object)ds.Statment).Rows.Clear();
							string text3 = "";
							DataTable dataTable2 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
							try
							{
								text3 = dataTable2.Rows[0][0].ToString();
							}
							catch
							{
							}
							((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, dateTimePicker1.Value, nameTextBox.Text, Pprice, Pprice, Pprice, "", text3, Main.usernames, text, 1, Pprice);
							sqlConnection1.ConnectionString = codes.ConnectionStr;
							sqlDataAdapter1.Fill(ds);
							sqlConnection2.ConnectionString = codes.ConnectionStr;
							sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
							sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
							sqlDataAdapter2.Fill(ds);
							DataTable dataTable3 = codes.Search2("select EsalPrinter from Properties");
							switch (dataTable3.Rows[0][0].ToString())
							{
							case "A5":
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptA5.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = "0";
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = "0";
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								try
								{
									reportDocument.SetParameterValue("Assistant", "");
								}
								catch
								{
								}
								StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
								statmentRptFrm.ShowDialog();
								break;
							}
							case "Reset":
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1Reset.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = "0";
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = "0";
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
								statmentRptFrm.ShowDialog();
								break;
							}
							case "1/2 A4":
							{
								((DataTable)(object)ds.Statment).Rows.Clear();
								string text5 = "";
								DataTable dataTable4 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
								try
								{
									text5 = dataTable4.Rows[0][0].ToString();
								}
								catch
								{
								}
								((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, dateTimePicker1.Value, nameTextBox.Text, Pprice, Pprice, Pprice, "", text5, Main.usernames, text, 1, Pprice, 0);
								sqlConnection2.ConnectionString = codes.ConnectionStr;
								sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
								sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
								sqlDataAdapter2.Fill(ds);
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt_HalfA4.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								FrmStatmentRpt_HalfA4 frmStatmentRpt_HalfA = new FrmStatmentRpt_HalfA4(reportDocument);
								frmStatmentRpt_HalfA.ShowDialog();
								break;
							}
							default:
							{
								ReportDocument reportDocument = new ReportDocument();
								reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1.rpt");
								try
								{
									reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
									textObject.Text = "0";
								}
								catch
								{
								}
								try
								{
									TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
									textObject.Text = "0";
								}
								catch
								{
								}
								reportDocument.SetDataSource(ds);
								reportDocument.SetParameterValue("Assistant", "");
								StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
								statmentRptFrm.ShowDialog();
								break;
							}
							}
						}
						ClearData();
						dataGridView1.DataSource = null;
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
				if (UsersClass.AutoEsal)
				{
					EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
					EsalNoTxt.Enabled = false;
				}
				else
				{
					EsalNoTxt.Text = "";
					EsalNoTxt.Enabled = true;
				}
			}
			catch
			{
			}
		}

		private void searchBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				try
				{
					dataTable = dc.Select("SelectAllPatient");
					gui.loadComboBox(comboBox1, dataTable);
				}
				catch
				{
				}
				searchGrop.Visible = true;
			}
			catch
			{
			}
		}

		public void DataGrid()
		{
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].Visible = false;
				dataGridView1.Columns[2].HeaderText = "Patient Name";
				dataGridView1.Columns[3].Visible = false;
				dataGridView1.Columns[4].HeaderText = "Analysis Date";
				dataGridView1.Columns[5].HeaderText = "Notes";
				dataGridView1.Columns[6].Visible = false;
				dataGridView1.Columns[7].Visible = false;
				dataGridView1.Columns[8].HeaderText = "Analysis Name";
			}
			else
			{
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].Visible = false;
				dataGridView1.Columns[2].HeaderText = "اسم المريض";
				dataGridView1.Columns[3].Visible = false;
				dataGridView1.Columns[4].HeaderText = "تاريخ التحليل";
				dataGridView1.Columns[5].HeaderText = "ملاحظات";
				dataGridView1.Columns[6].Visible = false;
				dataGridView1.Columns[7].Visible = false;
				dataGridView1.Columns[8].HeaderText = "اسم التحليل";
			}
		}

		public void RefreshDataGrid()
		{
			try
			{
				string[] fields = new string[1] { "PatientID" };
				DataTable dataTable = dc.Select("selectPatientAnalyze", fields, Convert.ToInt32(comboBox1.SelectedValue.ToString()));
				if (dataTable.Rows.Count == 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("There is no Analysis of the patient", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					else
					{
						MessageBox.Show("لا يوجد تحاليل للمريض", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else
				{
					dataGridView1.DataSource = dataTable;
					DataGrid();
					searchGrop.Visible = false;
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			DataTable tableText = dc.GetTableText("select * from PatientData where ID='" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "'");
			if (tableText.Rows.Count == 0)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Patient Name");
				}
				else
				{
					MessageBox.Show("من فضلك اختر اسم مريض صحيح");
				}
			}
			else
			{
				RefreshDataGrid();
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			checkPay = false;
			ClearData();
			EditBtn.Enabled = true;
			button2.Enabled = true;
			AddBtn.Enabled = false;
			deleteBtn.Enabled = true;
			PatientRayID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
			textBox1.Text = dataGridView1.CurrentRow.Cells["AnalyzeNots"].Value.ToString();
			dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells["AnalyzeDate"].Value.ToString());
			PatientComboBox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
			PatientComboBox.Enabled = false;
			try
			{
				SqlBytes sqlBytes = new SqlBytes((byte[])dataGridView1.CurrentRow.Cells["AnalyzeImage"].Value);
				PaientRay = (byte[])dataGridView1.CurrentRow.Cells["AnalyzeImage"].Value;
				pictureBox1.BackgroundImage = Image.FromStream(sqlBytes.Stream);
			}
			catch
			{
			}
			try
			{
				checkBox1.Checked = !Convert.ToBoolean(dataGridView1.CurrentRow.Cells[6].Value.ToString());
				Free = Convert.ToBoolean(dataGridView1.CurrentRow.Cells[6].Value.ToString());
			}
			catch
			{
			}
			try
			{
				doctorcomboBox.SelectedValue = Convert.ToInt32(dataGridView1.CurrentRow.Cells[7].Value.ToString());
			}
			catch
			{
			}
			try
			{
				nameTextBox.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
			}
			catch
			{
			}
			if (checkBox1.Checked)
			{
				try
				{
					label8.Visible = true;
					floatText1.Visible = true;
					DataTable dataTable = codes.Search2("select Price,PricePay,Pay,StockId,ID from PatientAccount where AnalyzeId = '" + PatientRayID + "'");
					payFloatText.Text = Convert.ToDouble(dataTable.Rows[0][0]).ToString();
					floatText1.Text = Convert.ToDouble(dataTable.Rows[0][1]).ToString();
					checkBox2.Checked = Convert.ToBoolean(dataTable.Rows[0][2]);
					PatientAccountID = dataTable.Rows[0][4].ToString();
					try
					{
						DataTable dataTable2 = codes.Search2("select Madeen from Company5 where PatientAccountId = '" + PatientAccountID + "'");
						if (dataTable2.Rows.Count > 0)
						{
							payFloatText.Text = (Convert.ToDouble(dataTable.Rows[0][1]) + Convert.ToDouble(dataTable2.Rows[0][0])).ToString();
						}
					}
					catch
					{
					}
					pay = Convert.ToBoolean(dataTable.Rows[0][2]);
					try
					{
						stockId = dataTable.Rows[0][3].ToString();
						TreasuryCom.SelectedValue = Convert.ToInt32(stockId);
					}
					catch
					{
					}
				}
				catch
				{
				}
				try
				{
					if (checkBox2.Checked)
					{
						EsalNoTxt.Text = codes.Search2("select EsalNo from Esal where PatientAcountId = '" + PatientAccountID + "'").Rows[0][0].ToString();
					}
					else if (UsersClass.AutoEsal)
					{
						checkPay = true;
						EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
						EsalNoTxt.Enabled = false;
					}
					else
					{
						EsalNoTxt.Text = "";
						EsalNoTxt.Enabled = true;
					}
				}
				catch
				{
				}
			}
			else if (UsersClass.AutoEsal)
			{
				EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
				EsalNoTxt.Enabled = false;
			}
			else
			{
				EsalNoTxt.Text = "";
				EsalNoTxt.Enabled = true;
			}
			try
			{
				DataTable dataTable3 = codes.Search2("select AnalyzeFile from PatientAnalyze  where ID = '" + dataGridView1.CurrentRow.Cells[0].Value.ToString() + "'");
				if (dataTable3.Rows[0][0].ToString() == "")
				{
					ViewFile.Visible = false;
					openFileDialog1.FileName = "";
				}
				else
				{
					ViewFile.Visible = true;
					filename = dataTable3.Rows[0][0].ToString();
				}
			}
			catch
			{
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				string[] fields = new string[9] { "ID", "PatientID", "AnalyzeImage", "AnalyzeDate", "AnalyzeNots", "Free", "DoctorId", "AnalyzeName", "AnalyzeFile" };
				try
				{
					dc.GetTableText("select * from PatientAnalyze where AnalyzeName = '" + nameTextBox.Text + "' and PatientID = '" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "' and AnalyzeDate='" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' and ID <> " + PatientRayID);
					DataTable tableText = dc.GetTableText("select * from PatientData where ID='" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "'");
					if (tableText.Rows.Count == 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please Enter Patient Name");
						}
						else
						{
							MessageBox.Show("من فضلك اختر اسم مريض صحيح");
						}
					}
					else if (nameTextBox.SelectedIndex == -1)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please Enter Analysis Name");
						}
						else
						{
							MessageBox.Show("من فضلك ادخل اسم التحليل", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else
					{
						if (checkBox2.Checked)
						{
							if (EsalNoTxt.Text == "")
							{
								MessageBox.Show("من فضلك ادخل رقم الايصال");
								return;
							}
							DataTable dataTable = codes.Search2("select EsalNo from Esal where EsalNo ='" + EsalNoTxt.Text + "' and PatientAcountId <> '" + PatientAccountID + "'");
							if (dataTable.Rows.Count > 0)
							{
								MessageBox.Show("رقم الايصال مسجل من قبل");
								EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
							}
						}
						if (pictureBox1.BackgroundImage == null)
						{
							PaientRay = new byte[0];
						}
						if (dc.Update("UpdateAnalyze", fields, PatientRayID, Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), PaientRay, dateTimePicker1.Value.ToString("MM/dd/yyyy"), textBox1.Text, !checkBox1.Checked, Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), nameTextBox.Text, filename))
						{
							string text = "";
							DataTable dataTable2 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
							try
							{
								text = dataTable2.Rows[0][0].ToString();
							}
							catch
							{
							}
							try
							{
								if (Nesba)
								{
									Account = Convert.ToDecimal(payFloatText.Text) * discount / 100m;
								}
								else
								{
									Account = discount;
								}
								Pprice = Convert.ToDecimal(payFloatText.Text) - Account;
							}
							catch
							{
							}
							string value = codes.Search("select isnull(sum(Madeen),0) -  isnull(sum(Daen),0) from Company5 where CompanyId = '" + companyId + "'").Rows[0][0].ToString();
							if (!Free && !checkBox1.Checked)
							{
								codes.Delete2("delete from PatientAccount where AnalyzeId = '" + PatientRayID + "'");
								codes.Delete2("delete from Esal where PatientAcountId = '" + PatientAccountID + "'");
								DataTable dataTable3 = codes.Search2("select ID,Madeen from Company5 where PatientAccountId = '" + PatientAccountID + "'");
								if (dataTable3.Rows.Count > 0)
								{
									string text2 = dataTable3.Rows[0][0].ToString();
									string text3 = dataTable3.Rows[0][1].ToString();
									codes.Edit2("update Company5 set Raseed = Raseed- " + text3 + " where ID > '" + text2 + "' ");
								}
								codes.Delete2("delete from Company5 where PatientAccountId = '" + PatientAccountID + "'");
								if (Convert.ToDouble(floatText1.Text) != 0.0)
								{
									codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId) values ('حذف تحليل' ,'" + Convert.ToDecimal(floatText1.Text) + "','" + PatientComboBox.Text + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','" + stockId + "')");
									codes.Edit2("update Stock Set Value= Value - " + floatText1.Text + " where ID = '" + stockId + "'");
								}
							}
							else if (Free && checkBox1.Checked)
							{
								if (checkBox2.Checked)
								{
									string text4 = EsalNoTxt.Text;
									string text5 = codes.Search2("insert into PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay, BeanDate, StockId,AnalyzeId) values ('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue) + "','" + nameTextBox.Text + "','" + Pprice + "','True','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Pprice + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(TreasuryCom.SelectedValue) + "','" + PatientRayID + "');select @@identity").Rows[0][0].ToString();
									if (Account != 0m)
									{
										codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + Account + "','" + (Convert.ToDouble(value) + Convert.ToDouble(Account)) + "','" + nameTextBox.Text + "'+' - '+'" + PatientComboBox.Text + "'+' - '+'" + doctorcomboBox.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(text5) + "')");
									}
									codes.Edit2("update Stock Set Value= Value + " + Pprice + " where ID = '" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "'");
									codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId) values ('تحليل' ,'" + Pprice + "','" + PatientComboBox.Text + " إيصال رقم: " + EsalNoTxt.Text + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
									codes.Add2("insert into Esal (EsalNo, PatientAcountId, Date,Pay, Patient, Bean, Price, Teeth, Company, Username,Assistant) values('" + text4 + "','" + text5 + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Pprice + "','" + PatientComboBox.Text + "','" + nameTextBox.Text + "','" + Pprice + "','','" + text + "','" + Main.usernames + "','')");
								}
								else
								{
									string text5 = codes.Search2("insert into PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay, BeanDate,AnalyzeId) values ('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue) + "','" + nameTextBox.Text + "','" + Pprice + "','False','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "',0,'" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + PatientRayID + "');select @@identity").Rows[0][0].ToString();
									if (Account != 0m)
									{
										codes.Add2("insert into Company5(CompanyId, Daen, Madeen, Raseed, Bayan, Date, PatientAccountId) values('" + companyId + "',0,'" + Account + "','" + (Convert.ToDouble(value) + Convert.ToDouble(Account)) + "','" + nameTextBox.Text + "'+' - '+'" + PatientComboBox.Text + "'+' - '+'" + doctorcomboBox.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(text5) + "')");
									}
								}
							}
							else if (!Free && checkBox1.Checked && Convert.ToDouble(Pprice) != Convert.ToDouble(floatText1.Text))
							{
								if (checkBox2.Checked && pay)
								{
									codes.Edit2("update PatientAccount set StockId = '" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "' ,Price = '" + Convert.ToDouble(payFloatText.Text) + "',Pay = 'True',PricePay = '" + Convert.ToDouble(payFloatText.Text) + "',Date = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' ,Bean = '" + nameTextBox.Text + "' where AnalyzeId = '" + PatientRayID + "'");
									DataTable dataTable3 = codes.Search2("select ID,Madeen from Company5 where PatientAccountId = '" + PatientAccountID + "'");
									if (dataTable3.Rows.Count > 0)
									{
										string text2 = dataTable3.Rows[0][0].ToString();
										string text3 = dataTable3.Rows[0][1].ToString();
										string text6 = (Convert.ToDecimal(Account) - Convert.ToDecimal(text3)).ToString();
										codes.Edit2("update Company5 set Madeen = '" + Account + "',Date = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' where ID = '" + text2 + "'");
										codes.Edit2("update Company5 set CompanyId = '" + companyId + "',Raseed = Raseed+ " + text6 + " where ID >= '" + text2 + "' ");
									}
									codes.Edit2("update Esal set Pay = '" + Pprice + "' ,Date = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "',Price = '" + Pprice + "', Username = '" + Main.usernames + "' where PatientAcountId = '" + PatientAccountID + "'");
									if (Convert.ToInt32(stockId) == Convert.ToInt32(TreasuryCom.SelectedValue.ToString()))
									{
										double num = Convert.ToDouble(Pprice) - Convert.ToDouble(floatText1.Text);
										codes.Edit2("update Stock Set Value= Value + " + num + " where ID = '" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "'");
										codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId) values ('تعديل تحليل' ," + num + ",'" + PatientComboBox.Text + " إيصال رقم: " + EsalNoTxt.Text + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
									}
									else
									{
										double num = Convert.ToDouble(Pprice) - Convert.ToDouble(floatText1.Text);
										codes.Edit2("update Stock Set Value= Value - " + floatText1.Text + " where ID = '" + stockId + "'");
										codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId) values ('تعديل تحليل' ," + -1m * Convert.ToDecimal(floatText1.Text) + ",'" + PatientComboBox.Text + " إيصال رقم: " + EsalNoTxt.Text + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','" + stockId + "')");
										codes.Edit2("update Stock Set Value= Value + " + Pprice + " where ID = '" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "'");
										codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId) values ('تعديل تحليل' ," + Pprice + ",'" + PatientComboBox.Text + " إيصال رقم: " + EsalNoTxt.Text + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "')");
									}
								}
								else if (Convert.ToDouble(floatText1.Text) == 0.0)
								{
									codes.Edit2("update Esal set Date = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "',Price = '" + Pprice + "', Username = '" + Main.usernames + "' where PatientAcountId = '" + PatientAccountID + "'");
									codes.Edit2("update PatientAccount set StockId = '" + Convert.ToInt32(TreasuryCom.SelectedValue.ToString()) + "' ,Price = '" + Pprice + "',Date = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "',Bean = '" + nameTextBox.Text + "'  where AnalyzeId = '" + PatientRayID + "'");
									DataTable dataTable3 = codes.Search2("select ID,Madeen from Company5 where PatientAccountId = '" + PatientAccountID + "'");
									if (dataTable3.Rows.Count > 0)
									{
										string text2 = dataTable3.Rows[0][0].ToString();
										string text3 = dataTable3.Rows[0][1].ToString();
										string text6 = (Convert.ToDecimal(Account) - Convert.ToDecimal(text3)).ToString();
										codes.Edit2("update Company5 set Madeen = '" + Account + "',Date = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' where ID = '" + text2 + "'");
										codes.Edit2("update Company5 set CompanyId = '" + companyId + "',Raseed = Raseed+ " + text6 + " where ID >= '" + text2 + "' ");
									}
								}
								else
								{
									codes.Edit2("update Esal set Pay = 0 ,Date = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "',Price = '" + Pprice + "', Username = '" + Main.usernames + "' where PatientAcountId = '" + PatientAccountID + "'");
									codes.Edit2("update PatientAccount set Price = '" + Pprice + "',Pay = 'False',PricePay = 0,Date = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "',Bean = '" + nameTextBox.Text + "'  where AnalyzeId = '" + PatientRayID + "'");
									DataTable dataTable3 = codes.Search2("select ID,Madeen from Company5 where PatientAccountId = '" + PatientAccountID + "'");
									if (dataTable3.Rows.Count > 0)
									{
										string text2 = dataTable3.Rows[0][0].ToString();
										string text3 = dataTable3.Rows[0][1].ToString();
										string text6 = (Convert.ToDecimal(Account) - Convert.ToDecimal(text3)).ToString();
										codes.Edit2("update Company5 set Madeen = '" + Account + "',Date = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' where ID = '" + text2 + "'");
										codes.Edit2("update Company5 set CompanyId = '" + companyId + "',Raseed = Raseed+ " + text6 + " where ID >= '" + text2 + "' ");
									}
									codes.Edit2("update Stock Set Value= Value - " + floatText1.Text + " where ID = '" + stockId + "'");
									codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId) values ('حذف تحليل' ,'" + Convert.ToDecimal(floatText1.Text) + "','" + PatientComboBox.Text + "','" + DateTime.Now.ToString("MM/dd/yyyy") + "','" + stockId + "')");
								}
							}
							if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("Data Updated Successfully", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							else
							{
								MessageBox.Show("تم تعديل البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							MethodsClass.UserMove("تعديل تحليل لمريض");
							filename = "";
							openFileDialog1.FileName = "";
							ViewFile.Visible = false;
							if (checkBox2.Checked)
							{
								((DataTable)(object)ds.Statment).Rows.Clear();
								if (checkBox2.Checked)
								{
									string text7 = EsalNoTxt.Text;
									string text8 = "";
									DataTable dataTable4 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
									try
									{
										text8 = dataTable4.Rows[0][0].ToString();
									}
									catch
									{
									}
									((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, dateTimePicker1.Value, nameTextBox.Text, Pprice, Pprice, Pprice, "", text8, Main.usernames, text7, 1, Pprice);
									sqlConnection1.ConnectionString = codes.ConnectionStr;
									sqlDataAdapter1.Fill(ds);
									sqlConnection2.ConnectionString = codes.ConnectionStr;
									sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
									sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
									sqlDataAdapter2.Fill(ds);
									DataTable dataTable5 = codes.Search2("select EsalPrinter from Properties");
									switch (dataTable5.Rows[0][0].ToString())
									{
									case "A5":
									{
										ReportDocument reportDocument = new ReportDocument();
										reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRptA5.rpt");
										try
										{
											reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
										}
										catch
										{
										}
										try
										{
											TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
											textObject.Text = "0";
										}
										catch
										{
										}
										try
										{
											TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
											textObject.Text = "0";
										}
										catch
										{
										}
										reportDocument.SetDataSource(ds);
										try
										{
											reportDocument.SetParameterValue("Assistant", "");
										}
										catch
										{
										}
										StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
										statmentRptFrm.ShowDialog();
										break;
									}
									case "Reset":
									{
										ReportDocument reportDocument = new ReportDocument();
										reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1Reset.rpt");
										try
										{
											reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
										}
										catch
										{
										}
										try
										{
											TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
											textObject.Text = "0";
										}
										catch
										{
										}
										try
										{
											TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
											textObject.Text = "0";
										}
										catch
										{
										}
										reportDocument.SetDataSource(ds);
										StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
										statmentRptFrm.ShowDialog();
										break;
									}
									case "1/2 A4":
									{
										((DataTable)(object)ds.Statment).Rows.Clear();
										string text9 = "";
										DataTable dataTable6 = codes.Search2(string.Concat("SELECT        Company.Name\r\nFROM            Company INNER JOIN\r\n                         PatientData ON Company.ID = PatientData.company where PatientData.id='", PatientComboBox.SelectedValue, "'"));
										try
										{
											text9 = dataTable6.Rows[0][0].ToString();
										}
										catch
										{
										}
										((DataTable)(object)ds.Statment).Rows.Add(PatientComboBox.Text, dateTimePicker1.Value, nameTextBox.Text, Pprice, 0, Pprice, "", text9, Main.usernames, text7, 1, Pprice, 0);
										sqlConnection2.ConnectionString = codes.ConnectionStr;
										sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
										sqlDataAdapter2.SelectCommand.CommandText = string.Concat("select * from PatientData where ID ='", PatientComboBox.SelectedValue, "'");
										sqlDataAdapter2.Fill(ds);
										ReportDocument reportDocument = new ReportDocument();
										reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt_HalfA4.rpt");
										try
										{
											reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
										}
										catch
										{
										}
										reportDocument.SetDataSource(ds);
										FrmStatmentRpt_HalfA4 frmStatmentRpt_HalfA = new FrmStatmentRpt_HalfA4(reportDocument);
										frmStatmentRpt_HalfA.ShowDialog();
										break;
									}
									default:
									{
										ReportDocument reportDocument = new ReportDocument();
										reportDocument.Load(Application.StartupPath + "\\Reports\\StatmentRpt1.rpt");
										try
										{
											reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
										}
										catch
										{
										}
										try
										{
											reportDocument.PrintOptions.PrinterName = UsersClass.EsalPrinterName;
										}
										catch
										{
										}
										try
										{
											TextObject textObject = reportDocument.ReportDefinition.ReportObjects["OldPay"] as TextObject;
											textObject.Text = "0";
										}
										catch
										{
										}
										try
										{
											TextObject textObject = reportDocument.ReportDefinition.ReportObjects["Rest"] as TextObject;
											textObject.Text = "0";
										}
										catch
										{
										}
										reportDocument.SetDataSource(ds);
										reportDocument.SetParameterValue("Assistant", "");
										StatmentRptFrm1 statmentRptFrm = new StatmentRptFrm1(reportDocument);
										statmentRptFrm.ShowDialog();
										break;
									}
									}
								}
							}
							ClearData();
							dataGridView1.DataSource = null;
							EditBtn.Enabled = false;
							AddBtn.Enabled = true;
							deleteBtn.Enabled = false;
							button2.Enabled = false;
						}
						else
						{
							MessageBox.Show("حدث خطأ أثناء تعديل البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
					}
				}
				catch
				{
				}
				if (UsersClass.AutoEsal)
				{
					EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
					EsalNoTxt.Enabled = false;
				}
				else
				{
					EsalNoTxt.Text = "";
					EsalNoTxt.Enabled = true;
				}
			}
			catch
			{
			}
		}

		private void deleteBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DialogResult dialogResult = DialogResult.None;
				dialogResult = ((!(Settings.Default.Language == "en-GB")) ? MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) : MessageBox.Show("Are You Sure You Want To Delete This Analysis?", "", MessageBoxButtons.OKCancel, MessageBoxIcon.Question));
				if (dialogResult != DialogResult.OK)
				{
					return;
				}
				string[] fields = new string[1] { "ID" };
				if (dc.Delete("deletePatientRay", fields, PatientRayID))
				{
					if (!Free)
					{
						codes.Delete2("delete from PatientAccount where AnalyzeId = '" + PatientRayID + "'");
						codes.Delete2("delete from Esal where PatientAcountId = '" + PatientAccountID + "'");
						DataTable dataTable = codes.Search2("select ID,Madeen from Company5 where PatientAccountId = '" + PatientAccountID + "'");
						if (dataTable.Rows.Count > 0)
						{
							string text = dataTable.Rows[0][0].ToString();
							string text2 = dataTable.Rows[0][1].ToString();
							codes.Edit2("update Company5 set Raseed = Raseed- " + text2 + " where ID > '" + text + "' ");
						}
						codes.Delete2("delete from Company5 where PatientAccountId = '" + PatientAccountID + "'");
						if (Convert.ToDouble(floatText1.Text) != 0.0)
						{
							codes.Edit2("update Stock Set Value= Value - " + floatText1.Text + " where ID = '" + stockId + "'");
							codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId) values ('حذف تحليل' ,'" + Convert.ToDecimal(floatText1.Text) + "','" + PatientComboBox.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + stockId + "')");
						}
					}
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Analysis Deleted Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					MethodsClass.UserMove("حذف تحليل لمريض");
					ClearData();
					dataGridView1.DataSource = null;
					EditBtn.Enabled = false;
					AddBtn.Enabled = true;
					deleteBtn.Enabled = false;
					button2.Enabled = false;
				}
				else
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("An Error Occurred During The Deletion Process ", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					dataGridView1.DataSource = null;
				}
			}
			catch
			{
			}
		}

		private void FrmImage_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			if (pictureBox1.BackgroundImage == null)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Choose Image");
				}
				else
				{
					MessageBox.Show("من فضلك اختار الصورة");
				}
			}
			else
			{
				FrmPrintImages frmPrintImages = new FrmPrintImages(PatientRayID.ToString(), "a");
				frmPrintImages.ShowDialog();
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			ClearData();
			dataGridView1.DataSource = null;
			EditBtn.Enabled = false;
			AddBtn.Enabled = true;
			deleteBtn.Enabled = false;
			button2.Enabled = false;
			if (UsersClass.AutoEsal)
			{
				EsalNoTxt.Text = codes.Search2("select isnull(max(EsalNo)+1,1) from Esal").Rows[0][0].ToString();
				EsalNoTxt.Enabled = false;
			}
			else
			{
				EsalNoTxt.Text = "";
				EsalNoTxt.Enabled = true;
			}
			filename = "";
			openFileDialog1.FileName = "";
			ViewFile.Visible = false;
		}

		private void checkBox2_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox2.Checked)
			{
				DataTable dataTable = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				if (dataTable.Rows.Count > 0)
				{
					PaidPanel.Visible = true;
					return;
				}
				checkBox2.Checked = false;
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please add Treasury validity");
				}
				else
				{
					MessageBox.Show("من فضلك اضف صلاحية للخزينة");
				}
			}
			else
			{
				PaidPanel.Visible = false;
			}
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox1.Checked)
			{
				groupBox5.Visible = true;
				checkBox2.Checked = false;
			}
			else
			{
				groupBox5.Visible = false;
			}
		}

		private void PatientComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				companyId = codes.Search2("select company from PatientData where  PName = '" + PatientComboBox.Text + "'").Rows[0][0].ToString();
			}
			catch
			{
			}
			try
			{
				discount = Convert.ToDecimal(codes.Search2("SELECT dbo.Company.DisAnalyze FROM dbo.PatientData INNER JOIN dbo.Company ON dbo.PatientData.company = dbo.Company.ID where PatientData.PName = '" + PatientComboBox.Text + "'").Rows[0][0].ToString());
			}
			catch
			{
			}
			try
			{
				Nesba = Convert.ToBoolean(codes.Search2("SELECT dbo.Company.Nesba FROM dbo.PatientData INNER JOIN dbo.Company ON dbo.PatientData.company = dbo.Company.ID where PatientData.PName = '" + PatientComboBox.Text + "'").Rows[0][0].ToString());
			}
			catch
			{
			}
		}

		private void nameTextBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				payFloatText.Text = Convert.ToDecimal(codes.Search2("select price from RayAnalyze where Name = '" + nameTextBox.Text + "' and Type = 'تحاليل'").Rows[0][0]).ToString();
			}
			catch
			{
				payFloatText.Text = "0";
			}
		}

		private void EsalNoTxt_KeyPress(object sender, KeyPressEventArgs e)
		{
			if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
			{
				if (e.KeyChar == '.' && EsalNoTxt.Text.Contains("."))
				{
					e.Handled = true;
				}
			}
			else
			{
				e.Handled = true;
				MessageBox.Show("من فضلك أدخل رقم الإيصال بالارقام");
			}
		}

		private void button4_Click(object sender, EventArgs e)
		{
			string text = "";
			openFileDialog1.Filter = "pdf files|*.pdf";
			openFileDialog1.InitialDirectory = "C:\\";
			if (openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				filename = Path.GetFileName(openFileDialog1.FileName) ?? "";
				text = openFileDialog1.FileName;
				string destFileName = Path.Combine(Application.StartupPath + "\\AnalyzeAndRays\\", filename);
				File.Copy(text, destFileName, overwrite: true);
			}
		}

		private void ViewFile_Click(object sender, EventArgs e)
		{
			Process.Start(Application.StartupPath + "\\AnalyzeAndRays\\" + filename);
		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{
		}

		private void button5_Click(object sender, EventArgs e)
		{
			pictureBox1.Height -= 10;
		}

		private void button6_Click(object sender, EventArgs e)
		{
			pictureBox1.Height += 10;
		}

		private void button8_Click(object sender, EventArgs e)
		{
			pictureBox1.Width -= 10;
		}

		private void button7_Click(object sender, EventArgs e)
		{
			pictureBox1.Width += 10;
		}
	}
}
