using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmBookingVisits : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox3;

		private TextBox textBox2;

		private GroupBox groupBox1;

		private DataGridView dataGridView1;

		private GroupBox groupBox5;

		private Button button1;

		private Button DeletBtn;

		private Button Searchbtn;

		private Button EditBtn;

		private Button saveBtn;

		private GroupBox groupBox4;

		private ComboBox comboBox2;

		private CheckBox checkBox2;

		private TextBox textBox1;

		private Panel StatusPanel;

		private ComboBox StatusCom;

		private Label label1;

		private TextBox priceTextBox;

		private DateTimePicker appdateTimePicker1;

		private TextBox ChairTextBox;

		private MaskedTextBox TOTextBox;

		private MaskedTextBox FromTextBox;

		private TextBox apptextBox;

		private ComboBox doctorcomboBox;

		private ComboBox PatientComboBox;

		private GroupBox groupBox6;

		private Label label6;

		private TextBox textBox3;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlDeleteCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlSelectCommand1;

		private SqlCommand sqlUpdateCommand1;

		private DataSet1 dataSet11;

		private Label label69;

		private ComboBox comboBox7;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private int stockId;

		private decimal pay;

		private ClassDataBase dc = new ClassDataBase(".\\sqlExpress");

		private GUI gui = new GUI();

		private int appid;

		private double oldpric = 0.0;

		private GeneralMethods MethodsClass = new GeneralMethods();
		private Label label11;
		private Label label3;
		private Label label12;
		private Label label;
		private Label label2;
		private Label label4;
		private Label label5;
		private Label label7;
		private Label label8;
		private Label label9;
		private Label label10;
		private bool b = true;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBookingVisits));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.DeletBtn = new System.Windows.Forms.Button();
            this.saveBtn = new System.Windows.Forms.Button();
            this.Searchbtn = new System.Windows.Forms.Button();
            this.EditBtn = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label69 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.StatusPanel = new System.Windows.Forms.Panel();
            this.StatusCom = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.appdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.ChairTextBox = new System.Windows.Forms.TextBox();
            this.TOTextBox = new System.Windows.Forms.MaskedTextBox();
            this.FromTextBox = new System.Windows.Forms.MaskedTextBox();
            this.apptextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.doctorcomboBox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.PatientComboBox = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
            this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
            this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
            this.dataSet11 = new DataSet1();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.groupBox6);
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(6, 1);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox3.Size = new System.Drawing.Size(772, 51);
            this.groupBox3.TabIndex = 82;
            this.groupBox3.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Transparent;
            this.groupBox6.Location = new System.Drawing.Point(40, 8);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(251, 35);
            this.groupBox6.TabIndex = 82;
            this.groupBox6.TabStop = false;
            this.groupBox6.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label6.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(2, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(167, 18);
            this.label6.TabIndex = 0;
            this.label6.Text = "مطلوب موافقة لهذا المريض";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(415, 19);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(251, 20);
            this.textBox2.TabIndex = 5;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(668, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 16);
            this.label11.TabIndex = 6;
            this.label11.Text = "بحث برقم الموبايل :";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Location = new System.Drawing.Point(6, 314);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(772, 265);
            this.groupBox1.TabIndex = 83;
            this.groupBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 16);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(766, 246);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.DeletBtn);
            this.groupBox5.Controls.Add(this.saveBtn);
            this.groupBox5.Controls.Add(this.Searchbtn);
            this.groupBox5.Controls.Add(this.EditBtn);
            this.groupBox5.Location = new System.Drawing.Point(6, 256);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(772, 58);
            this.groupBox5.TabIndex = 81;
            this.groupBox5.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gainsboro;
            this.button1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(40, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 37);
            this.button1.TabIndex = 78;
            this.button1.Text = "تراجع";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // DeletBtn
            // 
            this.DeletBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.DeletBtn.Enabled = false;
            this.DeletBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.DeletBtn.Location = new System.Drawing.Point(182, 13);
            this.DeletBtn.Name = "DeletBtn";
            this.DeletBtn.Size = new System.Drawing.Size(128, 37);
            this.DeletBtn.TabIndex = 77;
            this.DeletBtn.Text = "حذف";
            this.DeletBtn.UseVisualStyleBackColor = false;
            this.DeletBtn.Click += new System.EventHandler(this.DeletBtn_Click);
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.saveBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.saveBtn.Location = new System.Drawing.Point(611, 13);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(128, 37);
            this.saveBtn.TabIndex = 34;
            this.saveBtn.Text = "إضافة";
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // Searchbtn
            // 
            this.Searchbtn.BackColor = System.Drawing.Color.Gainsboro;
            this.Searchbtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.Searchbtn.Location = new System.Drawing.Point(325, 13);
            this.Searchbtn.Name = "Searchbtn";
            this.Searchbtn.Size = new System.Drawing.Size(128, 37);
            this.Searchbtn.TabIndex = 76;
            this.Searchbtn.Text = "بحث بالاسم";
            this.Searchbtn.UseVisualStyleBackColor = false;
            this.Searchbtn.Click += new System.EventHandler(this.Searchbtn_Click);
            // 
            // EditBtn
            // 
            this.EditBtn.BackColor = System.Drawing.Color.Gainsboro;
            this.EditBtn.Enabled = false;
            this.EditBtn.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.EditBtn.Location = new System.Drawing.Point(468, 13);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(128, 37);
            this.EditBtn.TabIndex = 75;
            this.EditBtn.Text = "تعديل";
            this.EditBtn.UseVisualStyleBackColor = false;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.label69);
            this.groupBox4.Controls.Add(this.comboBox7);
            this.groupBox4.Controls.Add(this.textBox3);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.comboBox2);
            this.groupBox4.Controls.Add(this.label);
            this.groupBox4.Controls.Add(this.checkBox2);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.textBox1);
            this.groupBox4.Controls.Add(this.StatusPanel);
            this.groupBox4.Controls.Add(this.StatusCom);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.priceTextBox);
            this.groupBox4.Controls.Add(this.appdateTimePicker1);
            this.groupBox4.Controls.Add(this.ChairTextBox);
            this.groupBox4.Controls.Add(this.TOTextBox);
            this.groupBox4.Controls.Add(this.FromTextBox);
            this.groupBox4.Controls.Add(this.apptextBox);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.doctorcomboBox);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.PatientComboBox);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Font = new System.Drawing.Font("Arial", 11.25F);
            this.groupBox4.ForeColor = System.Drawing.Color.Black;
            this.groupBox4.Location = new System.Drawing.Point(6, 52);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox4.Size = new System.Drawing.Size(772, 204);
            this.groupBox4.TabIndex = 80;
            this.groupBox4.TabStop = false;
            // 
            // label69
            // 
            this.label69.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.Transparent;
            this.label69.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label69.Location = new System.Drawing.Point(669, 172);
            this.label69.Name = "label69";
            this.label69.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label69.Size = new System.Drawing.Size(68, 16);
            this.label69.TabIndex = 148;
            this.label69.Text = "اسم الخزينة :";
            // 
            // comboBox7
            // 
            this.comboBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox7.Font = new System.Drawing.Font("Arial", 9.75F);
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(415, 169);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.comboBox7.Size = new System.Drawing.Size(251, 24);
            this.comboBox7.TabIndex = 147;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.White;
            this.textBox3.Location = new System.Drawing.Point(40, 30);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(90, 25);
            this.textBox3.TabIndex = 34;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(293, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 16);
            this.label3.TabIndex = 25;
            this.label3.Text = "الحالة :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(136, 34);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 16);
            this.label12.TabIndex = 33;
            this.label12.Text = "يوم :";
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.Font = new System.Drawing.Font("Arial", 9.75F);
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "الفترة الصباحية",
            "الفترة المسائية"});
            this.comboBox2.Location = new System.Drawing.Point(40, 92);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(251, 24);
            this.comboBox2.TabIndex = 32;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label.Location = new System.Drawing.Point(294, 96);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(40, 16);
            this.label.TabIndex = 31;
            this.label.Text = "الفترة :";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.checkBox2.Location = new System.Drawing.Point(446, 19);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(81, 22);
            this.checkBox2.TabIndex = 30;
            this.checkBox2.Text = "تم الموافقة";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(669, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 16);
            this.label2.TabIndex = 29;
            this.label2.Text = "اسم الشركة :";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.ForeColor = System.Drawing.Color.Maroon;
            this.textBox1.Location = new System.Drawing.Point(415, 77);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(251, 25);
            this.textBox1.TabIndex = 28;
            // 
            // StatusPanel
            // 
            this.StatusPanel.BackColor = System.Drawing.Color.LightCoral;
            this.StatusPanel.Location = new System.Drawing.Point(56, 152);
            this.StatusPanel.Name = "StatusPanel";
            this.StatusPanel.Size = new System.Drawing.Size(43, 22);
            this.StatusPanel.TabIndex = 27;
            // 
            // StatusCom
            // 
            this.StatusCom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.StatusCom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.StatusCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StatusCom.Font = new System.Drawing.Font("Arial", 9.75F);
            this.StatusCom.FormattingEnabled = true;
            this.StatusCom.Items.AddRange(new object[] {
            "لم يؤكد",
            "تم التأكيد",
            "تم تعديله",
            "تم إلغاؤه",
            "تم الكشف"});
            this.StatusCom.Location = new System.Drawing.Point(105, 152);
            this.StatusCom.Name = "StatusCom";
            this.StatusCom.Size = new System.Drawing.Size(186, 24);
            this.StatusCom.TabIndex = 26;
            this.StatusCom.SelectedIndexChanged += new System.EventHandler(this.StatusCom_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(668, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 24;
            this.label1.Text = "المبلغ :";
            // 
            // priceTextBox
            // 
            this.priceTextBox.Font = new System.Drawing.Font("Arial", 11.25F);
            this.priceTextBox.Location = new System.Drawing.Point(415, 138);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(251, 25);
            this.priceTextBox.TabIndex = 8;
            this.priceTextBox.Text = "0";
            this.priceTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.priceTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.priceTextBox_KeyPress);
            this.priceTextBox.Leave += new System.EventHandler(this.priceTextBox_Leave);
            // 
            // appdateTimePicker1
            // 
            this.appdateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.appdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.appdateTimePicker1.Location = new System.Drawing.Point(171, 30);
            this.appdateTimePicker1.Name = "appdateTimePicker1";
            this.appdateTimePicker1.RightToLeftLayout = true;
            this.appdateTimePicker1.Size = new System.Drawing.Size(120, 25);
            this.appdateTimePicker1.TabIndex = 2;
            this.appdateTimePicker1.ValueChanged += new System.EventHandler(this.appdateTimePicker1_ValueChanged);
            // 
            // ChairTextBox
            // 
            this.ChairTextBox.Font = new System.Drawing.Font("Arial", 11.25F);
            this.ChairTextBox.Location = new System.Drawing.Point(40, 121);
            this.ChairTextBox.Name = "ChairTextBox";
            this.ChairTextBox.Size = new System.Drawing.Size(251, 25);
            this.ChairTextBox.TabIndex = 7;
            // 
            // TOTextBox
            // 
            this.TOTextBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.TOTextBox.Location = new System.Drawing.Point(40, 60);
            this.TOTextBox.Mask = "00:00";
            this.TOTextBox.Name = "TOTextBox";
            this.TOTextBox.Size = new System.Drawing.Size(90, 26);
            this.TOTextBox.TabIndex = 4;
            this.TOTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TOTextBox.ValidatingType = typeof(System.DateTime);
            // 
            // FromTextBox
            // 
            this.FromTextBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.FromTextBox.Location = new System.Drawing.Point(201, 60);
            this.FromTextBox.Mask = "00:00";
            this.FromTextBox.Name = "FromTextBox";
            this.FromTextBox.Size = new System.Drawing.Size(90, 26);
            this.FromTextBox.TabIndex = 3;
            this.FromTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.FromTextBox.ValidatingType = typeof(System.DateTime);
            // 
            // apptextBox
            // 
            this.apptextBox.BackColor = System.Drawing.Color.White;
            this.apptextBox.ForeColor = System.Drawing.Color.Maroon;
            this.apptextBox.Location = new System.Drawing.Point(555, 17);
            this.apptextBox.Name = "apptextBox";
            this.apptextBox.ReadOnly = true;
            this.apptextBox.Size = new System.Drawing.Size(111, 25);
            this.apptextBox.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Firebrick;
            this.label4.Location = new System.Drawing.Point(669, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 16);
            this.label4.TabIndex = 17;
            this.label4.Text = "رقم الحجز :";
            // 
            // doctorcomboBox
            // 
            this.doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.doctorcomboBox.Font = new System.Drawing.Font("Arial", 9.75F);
            this.doctorcomboBox.FormattingEnabled = true;
            this.doctorcomboBox.Location = new System.Drawing.Point(415, 108);
            this.doctorcomboBox.Name = "doctorcomboBox";
            this.doctorcomboBox.Size = new System.Drawing.Size(251, 24);
            this.doctorcomboBox.TabIndex = 1;
            this.doctorcomboBox.SelectedIndexChanged += new System.EventHandler(this.doctorcomboBox_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(669, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "اسم المريض :";
            // 
            // PatientComboBox
            // 
            this.PatientComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.PatientComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.PatientComboBox.Font = new System.Drawing.Font("Arial", 9.75F);
            this.PatientComboBox.FormattingEnabled = true;
            this.PatientComboBox.Location = new System.Drawing.Point(415, 47);
            this.PatientComboBox.Name = "PatientComboBox";
            this.PatientComboBox.Size = new System.Drawing.Size(251, 24);
            this.PatientComboBox.TabIndex = 0;
            this.PatientComboBox.SelectedIndexChanged += new System.EventHandler(this.PatientComboBox_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(669, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "اسم الطبيب :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(293, 36);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 16);
            this.label8.TabIndex = 0;
            this.label8.Text = "تاريخ الزيارة :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(294, 67);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 16);
            this.label9.TabIndex = 0;
            this.label9.Text = "من :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(136, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 16);
            this.label10.TabIndex = 0;
            this.label10.Text = "إلى :";
            // 
            // sqlDataAdapter1
            // 
            this.sqlDataAdapter1.DeleteCommand = this.sqlDeleteCommand1;
            this.sqlDataAdapter1.InsertCommand = this.sqlInsertCommand1;
            this.sqlDataAdapter1.SelectCommand = this.sqlSelectCommand1;
            this.sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "DentalData", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("ID", "ID"),
                        new System.Data.Common.DataColumnMapping("DentalName", "DentalName"),
                        new System.Data.Common.DataColumnMapping("DAddress", "DAddress"),
                        new System.Data.Common.DataColumnMapping("DTel", "DTel"),
                        new System.Data.Common.DataColumnMapping("DMobile", "DMobile"),
                        new System.Data.Common.DataColumnMapping("DEmail", "DEmail"),
                        new System.Data.Common.DataColumnMapping("DSite", "DSite"),
                        new System.Data.Common.DataColumnMapping("DLogo", "DLogo"),
                        new System.Data.Common.DataColumnMapping("WorkData", "WorkData")})});
            this.sqlDataAdapter1.UpdateCommand = this.sqlUpdateCommand1;
            // 
            // sqlDeleteCommand1
            // 
            this.sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
            this.sqlDeleteCommand1.Connection = this.sqlConnection1;
            this.sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ID", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DentalName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, null)});
            // 
            // sqlConnection1
            // 
            this.sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrat" +
    "ed Security=True;Connect Timeout=30;User Instance=True";
            this.sqlConnection1.FireInfoMessageEventOnUserErrors = false;
            // 
            // sqlInsertCommand1
            // 
            this.sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
            this.sqlInsertCommand1.Connection = this.sqlConnection1;
            this.sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
            new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
            new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
            new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
            new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
            new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
            new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
            new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData")});
            // 
            // sqlSelectCommand1
            // 
            this.sqlSelectCommand1.CommandText = "SELECT        DentalData.*\r\nFROM            DentalData";
            this.sqlSelectCommand1.Connection = this.sqlConnection1;
            // 
            // sqlUpdateCommand1
            // 
            this.sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
            this.sqlUpdateCommand1.Connection = this.sqlConnection1;
            this.sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@DentalName", System.Data.SqlDbType.NVarChar, 0, "DentalName"),
            new System.Data.SqlClient.SqlParameter("@DAddress", System.Data.SqlDbType.NVarChar, 0, "DAddress"),
            new System.Data.SqlClient.SqlParameter("@DTel", System.Data.SqlDbType.NVarChar, 0, "DTel"),
            new System.Data.SqlClient.SqlParameter("@DMobile", System.Data.SqlDbType.NVarChar, 0, "DMobile"),
            new System.Data.SqlClient.SqlParameter("@DEmail", System.Data.SqlDbType.NVarChar, 0, "DEmail"),
            new System.Data.SqlClient.SqlParameter("@DSite", System.Data.SqlDbType.NVarChar, 0, "DSite"),
            new System.Data.SqlClient.SqlParameter("@DLogo", System.Data.SqlDbType.Image, 0, "DLogo"),
            new System.Data.SqlClient.SqlParameter("@WorkData", System.Data.SqlDbType.NVarChar, 0, "WorkData"),
            new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "ID", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DentalName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DentalName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DentalName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DentalName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DTel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DTel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DTel", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DMobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DMobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DMobile", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DEmail", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DEmail", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DEmail", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@IsNull_DSite", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, true, null, "", "", ""),
            new System.Data.SqlClient.SqlParameter("@Original_DSite", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "DSite", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")});
            // 
            // dataSet11
            // 
            this.dataSet11.DataSetName = "DataSet1";
            this.dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // FrmBookingVisits
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 585);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.KeyPreview = true;
            this.Name = "FrmBookingVisits";
            this.Text = "حجز زيارة لمريض";
            this.Load += new System.EventHandler(this.FrmBookingVisits_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmBookingVisits_KeyDown);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).EndInit();
            this.ResumeLayout(false);

		}

		public FrmBookingVisits()
		{
			InitializeComponent();
		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select id,pname from PatientData where Mob like '%" + textBox2.Text + "%' and PatientData.Active = 'True'");
				PatientComboBox.DataSource = dataTable;
				PatientComboBox.ValueMember = dataTable.Columns[0].ToString();
				PatientComboBox.DisplayMember = dataTable.Columns[1].ToString();
			}
			catch
			{
			}
		}

		private void load()
		{
			try
			{
				DataTable dataTable = codes.Search2(string.Concat("SELECT Company.Name,PatientData.Accept,DoctoreName FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID WHERE (PatientData.ID ='", PatientComboBox.SelectedValue, "')"));
				textBox1.Text = dataTable.Rows[0][0].ToString();
				try
				{
					groupBox6.Visible = Convert.ToBoolean(dataTable.Rows[0][1].ToString());
				}
				catch
				{
					groupBox6.Visible = false;
				}
				try
				{
					DataTable dataTable2 = codes.Search2("select id from Empdata where name='" + dataTable.Rows[0][2].ToString() + "' and Designation='Doctor'");
					doctorcomboBox.SelectedValue = dataTable2.Rows[0][0].ToString();
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void PatientComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2(string.Concat("SELECT Company.Name,PatientData.Accept,DoctoreName FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID WHERE (PatientData.ID ='", PatientComboBox.SelectedValue, "')"));
				textBox1.Text = dataTable.Rows[0][0].ToString();
				try
				{
					groupBox6.Visible = Convert.ToBoolean(dataTable.Rows[0][1].ToString());
				}
				catch
				{
					groupBox6.Visible = false;
				}
				try
				{
					DataTable dataTable2 = codes.Search2("select id from Empdata where name='" + dataTable.Rows[0][2].ToString() + "' and Designation='Doctor'");
					doctorcomboBox.SelectedValue = dataTable2.Rows[0][0].ToString();
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void VisitsCount()
		{
			DataTable dataTable = codes.Search2(string.Concat("select AppointCount from Empdata where ID='", doctorcomboBox.SelectedValue, "'"));
			int num = Convert.ToInt32(dataTable.Rows[0][0].ToString());
			DataTable dataTable2 = codes.Search2(string.Concat("select count(ID) from Visits where DoctorID='", doctorcomboBox.SelectedValue, "' and detectDate='", appdateTimePicker1.Value.ToString("MM/dd/yyyy"), "'"));
			int num2 = Convert.ToInt32(dataTable2.Rows[0][0].ToString());
			if (num2 > num)
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Doctor visits reached the maximum limit");
				}
				else
				{
					MessageBox.Show("عدد الزيارات لهذا الطبيب وصلت الحد الأقصى");
				}
				b = false;
			}
		}

		private void doctorcomboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				VisitsCount();
			}
			catch
			{
			}
		}

		private void appdateTimePicker1_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				VisitsCount();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = new DataTable();
				string[] fields = new string[1] { "Date" };
				dataTable = dc.Select("SelectAllVisitsBydate", fields, appdateTimePicker1.Value.ToString("MM/dd/yyyy"));
				if (!EditBtn.Enabled)
				{
					if (dataTable.Rows.Count > 0)
					{
						apptextBox.Text = (dataTable.Rows.Count + 1).ToString();
					}
					else
					{
						apptextBox.Text = "1";
					}
				}
			}
			catch
			{
			}
			try
			{
				if (Settings.Default.Language == "en-GB")
				{
					if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Friday)
					{
						textBox3.Text = "Friday";
					}
					else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Monday)
					{
						textBox3.Text = "Monday";
					}
					else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Saturday)
					{
						textBox3.Text = "Saturday";
					}
					else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Sunday)
					{
						textBox3.Text = "Sunday";
					}
					else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Thursday)
					{
						textBox3.Text = "Thursday";
					}
					else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Tuesday)
					{
						textBox3.Text = "Tuesday";
					}
					else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Wednesday)
					{
						textBox3.Text = "Wednesday";
					}
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Friday)
				{
					textBox3.Text = "الجمعة";
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Monday)
				{
					textBox3.Text = "الإثنين";
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Saturday)
				{
					textBox3.Text = "السبت";
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Sunday)
				{
					textBox3.Text = "الأحد";
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Thursday)
				{
					textBox3.Text = "الخميس";
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Tuesday)
				{
					textBox3.Text = "الثلاثاء";
				}
				else if (appdateTimePicker1.Value.DayOfWeek == DayOfWeek.Wednesday)
				{
					textBox3.Text = "الأربعاء";
				}
			}
			catch
			{
			}
		}

		private void priceTextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && priceTextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Numbers Only");
				}
				else
				{
					MessageBox.Show("من فضلك أدخل أرقام فقط");
				}
				e.Handled = true;
			}
			catch
			{
			}
		}

		private void priceTextBox_Leave(object sender, EventArgs e)
		{
			try
			{
				if (priceTextBox.Text == "")
				{
					priceTextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void StatusCom_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (StatusCom.SelectedIndex == 0)
			{
				StatusPanel.BackColor = Color.FromArgb(143, 213, 245);
			}
			else if (StatusCom.SelectedIndex == 1)
			{
				StatusPanel.BackColor = Color.YellowGreen;
			}
			else if (StatusCom.SelectedIndex == 2)
			{
				StatusPanel.BackColor = Color.Transparent;
			}
			else if (StatusCom.SelectedIndex == 3)
			{
				StatusPanel.BackColor = Color.FromArgb(230, 119, 96);
			}
			else if (StatusCom.SelectedIndex == 4)
			{
				StatusPanel.BackColor = Color.BlueViolet;
			}
		}

		private void FrmBookingVisits_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				string[] fields = new string[1] { "Date" };
				dataTable = dc.Select("SelectAllVisitsBydate", fields, appdateTimePicker1.Value.ToString("MM/dd/yyyy"));
				if (dataTable.Rows.Count > 0)
				{
					apptextBox.Text = (dataTable.Rows.Count + 1).ToString();
				}
				else
				{
					apptextBox.Text = "1";
				}
				try
				{
					if (Settings.Default.Language == "en-GB")
					{
						dataTable = codes.Search2("SELECT     Visits.ID, Visits.AppointNum AS [Appoint Num], PatientData.PName AS [Patient Name], Empdata.Name AS [Doctor Name], \r\n                      Visits.detectDate AS [Visit Date], Visits.detectStartTime AS [From], Visits.detectEndTime AS [To],\r\n                      Visits.ChairNum AS [Chair No], Visits.Price AS Price,Visits.Status as Statues,Visits.Accepted as [Done Accept],Visits.Period as Period\r\nFROM         Visits INNER JOIN\r\n                      PatientData ON Visits.PatuentID = PatientData.ID INNER JOIN\r\n                      Empdata ON Visits.DoctorID = Empdata.ID WHERE     (Visits.Done = 0)");
						gui.loadDataGrid(dataGridView1, dataTable);
						dataGridView1.Columns[11].Visible = false;
					}
					else
					{
						dataTable = dc.Select("SelectAllVisits");
						gui.loadDataGrid(dataGridView1, dataTable);
						dataGridView1.Columns[11].Visible = false;
					}
				}
				catch
				{
				}
				try
				{
					dataTable = dc.Select("SelectAllDoctor");
					gui.loadComboBox(doctorcomboBox, dataTable);
				}
				catch
				{
				}
				try
				{
					DataTable dataTable2 = new DataTable();
					if (Convert.ToBoolean(codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString()))
					{
						dataTable2 = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True' order by PName");
						PatientComboBox.DataSource = dataTable2;
						PatientComboBox.DisplayMember = dataTable2.Columns[1].ToString();
						PatientComboBox.ValueMember = dataTable2.Columns[0].ToString();
					}
					else
					{
						dataTable2 = dc.Select("SelectAllPatient");
						gui.loadComboBox(PatientComboBox, dataTable);
					}
				}
				catch
				{
				}
				try
				{
					doctorcomboBox.SelectedIndex = 0;
					PatientComboBox.SelectedIndex = 0;
					StatusCom.SelectedIndex = 0;
					comboBox2.SelectedIndex = 0;
					appdateTimePicker1.Value = DateTime.Today;
				}
				catch
				{
				}
				load();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable3 = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				comboBox7.DataSource = null;
				comboBox7.DataSource = dataTable3;
				comboBox7.DisplayMember = dataTable3.Columns[1].ToString();
				comboBox7.ValueMember = dataTable3.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				clear();
				DataTable dataTable = new DataTable();
				if (Settings.Default.Language == "en-GB")
				{
					dataTable = codes.Search2("SELECT     Visits.ID, Visits.AppointNum AS [Appoint Num], PatientData.PName AS [Patient Name], Empdata.Name AS [Doctor Name], \r\n                      Visits.detectDate AS [Visit Date], Visits.detectStartTime AS [From], Visits.detectEndTime AS [To],\r\n                      Visits.ChairNum AS [Chair No], Visits.Price AS Price,Visits.Status as Statues,Visits.Accepted as [Done Accept],Visits.Period as Period\r\nFROM         Visits INNER JOIN\r\n                      PatientData ON Visits.PatuentID = PatientData.ID INNER JOIN\r\n                      Empdata ON Visits.DoctorID = Empdata.ID WHERE     (Visits.Done = 0)");
					gui.loadDataGrid(dataGridView1, dataTable);
					dataGridView1.Columns[11].Visible = false;
				}
				else
				{
					dataTable = dc.Select("SelectAllVisits");
					gui.loadDataGrid(dataGridView1, dataTable);
					dataGridView1.Columns[11].Visible = false;
				}
			}
			catch
			{
			}
		}

		private void clear()
		{
			FromTextBox.Text = "00:00";
			TOTextBox.Text = "00:00";
			ChairTextBox.Text = "";
			priceTextBox.Text = "0";
			appdateTimePicker1.Value = DateTime.Now;
			EditBtn.Enabled = false;
			saveBtn.Enabled = true;
			DeletBtn.Enabled = false;
			checkBox2.Checked = false;
			loaddata();
			PatientComboBox.SelectedIndex = 0;
			doctorcomboBox.SelectedIndex = 0;
		}

		private void Searchbtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				if (Settings.Default.Language == "en-GB")
				{
					dataTable = dc.GetTableText("SELECT     Visits.ID, Visits.AppointNum AS [Appointment No.], PatientData.PName AS [Patient Name], Empdata.Name AS [Doctor Name], \r\n                      Visits.detectDate AS [Date], Visits.detectStartTime AS [From], Visits.detectEndTime AS [TO],\r\n                      Visits.ChairNum AS [Chair Number], Visits.Price AS [Price],Visits.Status as [Status],Visits.Accepted as [Approved],Visits.Period as [Period]\r\nFROM         Visits INNER JOIN\r\n                      PatientData ON Visits.PatuentID = PatientData.ID INNER JOIN\r\n                      Empdata ON Visits.DoctorID = Empdata.ID\r\nWHERE     (Visits.Done = 0) and PatientData.PName like '%" + codes.SearchText("Patient Name") + "%' and PatientData.Active = 'True'");
					gui.loadDataGrid(dataGridView1, dataTable);
					dataGridView1.Columns[11].Visible = false;
				}
				else
				{
					dataTable = dc.GetTableText("SELECT     Visits.ID, Visits.AppointNum AS [رقم الحجز], PatientData.PName AS [اسم المريض], Empdata.Name AS [اسم الطبيب], \r\n                      Visits.detectDate AS [تاريخ الزيارة], Visits.detectStartTime AS من, Visits.detectEndTime AS إلى,\r\n                      Visits.ChairNum AS [رقم الكرسي], Visits.Price AS المبلغ,Visits.Status as الحالة,Visits.Accepted as [تم الموافقة],Visits.Period as الفترة\r\nFROM         Visits INNER JOIN\r\n                      PatientData ON Visits.PatuentID = PatientData.ID INNER JOIN\r\n                      Empdata ON Visits.DoctorID = Empdata.ID\r\nWHERE     (Visits.Done = 0) and PatientData.PName like '%" + codes.SearchText("اسم المريض") + "%' and PatientData.Active = 'True'");
				}
				gui.loadDataGrid(dataGridView1, dataTable);
				dataGridView1.Columns[11].Visible = false;
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				EditBtn.Enabled = true;
				saveBtn.Enabled = false;
				DeletBtn.Enabled = true;
				appid = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
				apptextBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
				PatientComboBox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
				doctorcomboBox.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
				appdateTimePicker1.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[4].Value.ToString());
				FromTextBox.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
				TOTextBox.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
				ChairTextBox.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
				priceTextBox.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
				oldpric = Convert.ToDouble(dataGridView1.CurrentRow.Cells[8].Value.ToString());
				StatusCom.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
				if (Convert.ToBoolean(dataGridView1.CurrentRow.Cells[11].Value.ToString()))
				{
					comboBox2.SelectedIndex = 1;
				}
				else
				{
					comboBox2.SelectedIndex = 0;
				}
				checkBox2.Checked = Convert.ToBoolean(dataGridView1.CurrentRow.Cells[10].Value.ToString());
				DataTable dataTable = codes.Search2("select StockId,PricePay from PatientAccount where VisitID = '" + appid + "' and Bean = 'حجز زيارة'");
				pay = Convert.ToDecimal(dataTable.Rows[0][1]);
				try
				{
					stockId = Convert.ToInt32(dataTable.Rows[0][0].ToString());
					comboBox7.SelectedValue = Convert.ToInt32(dataTable.Rows[0][0].ToString());
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (groupBox6.Visible && !checkBox2.Checked)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("You Cannot Reserve for this patient Without Approvement");
					}
					else
					{
						MessageBox.Show("لا يمكن الحجز لهذا المريض بدون موافقة");
					}
				}
				else if (comboBox7.SelectedIndex == -1)
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Enter Treasury Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الخزينة");
					}
				}
				else if (b)
				{
					if (doctorcomboBox.SelectedItem != null)
					{
						dataSet11.Clear();
						sqlConnection1.ConnectionString = dc.ConnectionStr;
						sqlDataAdapter1.Fill(dataSet11);
						if (PatientComboBox.SelectedItem != null)
						{
							DataTable dataTable = new DataTable();
							dataTable = dc.GetTableText("select * from Stock where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
							double num = Convert.ToDouble(dataTable.Rows[0][1].ToString());
							string[] fields = new string[11]
							{
								"AppointNum", "PatuentID", "DoctorID", "detectDate", "detectStartTime", "detectEndTime", "ChairNum", "Price", "Status", "Accepted",
								"Period"
							};
							bool flag = false;
							if (comboBox2.SelectedIndex == 1)
							{
								flag = true;
							}
							if (dc.Insert("AddVisit", fields, apptextBox.Text, Convert.ToInt32(PatientComboBox.SelectedValue.ToString()), Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), appdateTimePicker1.Value.ToString("MM/dd/yyyy"), FromTextBox.Text, TOTextBox.Text, ChairTextBox.Text, priceTextBox.Text, StatusCom.Text, checkBox2.Checked, flag))
							{
								double num2 = Convert.ToDouble(priceTextBox.Text);
								double num3 = num + num2;
								codes.Edit2("update Stock Set Value='" + num3.ToString() + "' where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
								codes.Edit2(string.Concat("update PatientData set Accept='False' where ID='", PatientComboBox.SelectedValue, "'"));
								DataTable dataTable2 = codes.Search2("select top 1 ID from Visits order by ID desc ");
								codes.Add2("INSERT INTO PatientAccount\r\n                      (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay,BeanDate,VisitID,StockId)\r\nVALUES     ('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','حجز زيارة','" + priceTextBox.Text + "', 1,'" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "', '" + priceTextBox.Text + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(dataTable2.Rows[0][0]) + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
								DataTable dataTable3 = codes.Search2("select max(ID) from PatientAccount");
								codes.Add2("insert into AccountDetails (PatientId, DoctorId, Date, Bean, Price, PricePay, PatientAcountId, StockId) values('" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "','" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','حجز زيارة','" + priceTextBox.Text + "','" + priceTextBox.Text + "','" + Convert.ToInt32(dataTable3.Rows[0][0].ToString()) + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
								codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('زيارة' ," + Convert.ToDecimal(priceTextBox.Text) + ",'" + PatientComboBox.Text + " إيصال رقم: " + apptextBox.Text + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
								if (Settings.Default.Language == "en-GB")
								{
									MessageBox.Show("Data Save Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								}
								else
								{
									MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								}
								MethodsClass.UserMove("أضافة زياره لمريض");
								((DataTable)(object)dataSet11.AppointmentEsal).Rows.Add(apptextBox.Text, PatientComboBox.Text, doctorcomboBox.Text, appdateTimePicker1.Value, FromTextBox.Text, TOTextBox.Text, textBox1.Text, Main.usernames, priceTextBox.Text);
								if (Convert.ToBoolean(codes.Search2("select ShowEsal from Properties").Rows[0][0]))
								{
									AppointEsalRptFrm appointEsalRptFrm = new AppointEsalRptFrm(dataSet11);
									appointEsalRptFrm.ShowDialog();
								}
								loaddata();
								clear();
							}
							else if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("Error Happend While Saving", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							}
							else
							{
								MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
							}
						}
						else if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("please choose patient name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("من فضلك اختر اسم المريض", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("please choose Doctor name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم الطبيب", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Doctor Visits reached the maximum limit");
				}
				else
				{
					MessageBox.Show("عدد الزيارات لهذا الطبيب وصلت الحد الأقصى");
				}
			}
			catch
			{
			}
		}

		private void loaddata()
		{
			try
			{
				DataTable dataTable = new DataTable();
				string[] fields = new string[1] { "Date" };
				dataTable = dc.Select("SelectAllVisitsBydate", fields, appdateTimePicker1.Value.ToString("MM/dd/yyyy"));
				if (dataTable.Rows.Count > 0)
				{
					apptextBox.Text = (dataTable.Rows.Count + 1).ToString();
				}
				else
				{
					apptextBox.Text = "1";
				}
				try
				{
					if (Settings.Default.Language == "en-GB")
					{
						dataTable = codes.Search2("SELECT     Visits.ID, Visits.AppointNum AS [Appoint Num], PatientData.PName AS [Patient Name], Empdata.Name AS [Doctor Name], \r\n                      Visits.detectDate AS [Visit Date], Visits.detectStartTime AS [From], Visits.detectEndTime AS [To],\r\n                      Visits.ChairNum AS [Chair No], Visits.Price AS Price,Visits.Status as Statues,Visits.Accepted as [Done Accept],Visits.Period as Period\r\nFROM         Visits INNER JOIN\r\n                      PatientData ON Visits.PatuentID = PatientData.ID INNER JOIN\r\n                      Empdata ON Visits.DoctorID = Empdata.ID WHERE     (Visits.Done = 0)");
						gui.loadDataGrid(dataGridView1, dataTable);
						dataGridView1.Columns[11].Visible = false;
					}
					else
					{
						dataTable = dc.Select("SelectAllVisits");
						gui.loadDataGrid(dataGridView1, dataTable);
						dataGridView1.Columns[11].Visible = false;
					}
				}
				catch
				{
				}
				try
				{
					dataTable = dc.Select("SelectAllDoctor");
					gui.loadComboBox(doctorcomboBox, dataTable);
				}
				catch
				{
				}
				try
				{
					dataTable = dc.Select("SelectAllPatient");
					gui.loadComboBox(PatientComboBox, dataTable);
				}
				catch
				{
				}
				try
				{
					doctorcomboBox.SelectedItem = doctorcomboBox.Items[0];
					PatientComboBox.SelectedItem = PatientComboBox.Items[0];
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void EditBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (b)
				{
					if (doctorcomboBox.SelectedItem != null)
					{
						if (PatientComboBox.SelectedItem != null)
						{
							string text = "";
							DataTable dataTable = new DataTable();
							string[] array = new string[1] { "Date" };
							DataTable dataTable2 = codes.Search2("select * from Visits where detectDate='" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "' and ID<>'" + appid + "' and AppointNum='" + apptextBox.Text + "'");
							if (dataTable2.Rows.Count > 0)
							{
								DataTable dataTable3 = codes.Search2("select max (AppointNum) from Visits where detectDate='" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "'");
								text = ((dataTable3.Rows.Count <= 0) ? "1" : (Convert.ToInt32(dataTable3.Rows[0][0].ToString()) + 1).ToString());
							}
							else
							{
								text = apptextBox.Text;
							}
							dataTable = dc.GetTableText("select * from Stock  where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
							Convert.ToDouble(dataTable.Rows[0][1].ToString());
							bool flag = false;
							if (comboBox2.SelectedIndex == 1)
							{
								flag = true;
							}
							codes.Edit2("UPDATE Visits SET AppointNum='" + text + "',PatuentID='" + Convert.ToInt32(PatientComboBox.SelectedValue.ToString()) + "',DoctorID='" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "',detectDate='" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "',detectStartTime='" + FromTextBox.Text + "',detectEndTime='" + TOTextBox.Text + "',ChairNum='" + ChairTextBox.Text + "',Price='" + priceTextBox.Text + "',Status='" + StatusCom.Text + "',Accepted='" + checkBox2.Checked + "',Period ='" + flag + "' where ID ='" + appid + "'");
							decimal num = Convert.ToDecimal(priceTextBox.Text) - pay;
							if (stockId == Convert.ToInt32(comboBox7.SelectedValue.ToString()))
							{
								codes.Edit2("update Stock Set Value = Value + '" + num.ToString() + "' where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
								codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('تعديل زيارة' ," + num.ToString() + ",'" + PatientComboBox.Text + " إيصال رقم: " + apptextBox.Text + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
							}
							else
							{
								codes.Edit2("update Stock Set Value = Value - '" + pay.ToString() + "' where ID = '" + Convert.ToInt32(stockId) + "'");
								codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('تعديل زيارة' ," + -1m * pay + ",'" + PatientComboBox.Text + " إيصال رقم: " + apptextBox.Text + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + stockId + "')");
								codes.Edit2("update Stock Set Value = Value + '" + num.ToString() + "' where ID = '" + Convert.ToInt32(comboBox2.SelectedValue.ToString()) + "'");
								codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('تعديل زيارة' ," + num.ToString() + ",'" + PatientComboBox.Text + " إيصال رقم: " + apptextBox.Text + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
							}
							if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("Data Save Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							else
							{
								MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							MethodsClass.UserMove("تعديل زياره لمريض");
							loaddata();
							clear();
						}
						else if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("please choose patient name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						else
						{
							MessageBox.Show("من فضلك اختر اسم المريض", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("please choose Doctor name", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم الطبيب", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Doctor Visits reached the maximum limit");
				}
				else
				{
					MessageBox.Show("عدد الزيارات لهذا الطبيب وصلت الحد الأقصى");
				}
			}
			catch
			{
			}
		}

		private void DeletBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (Settings.Default.Language == "en-GB")
				{
					if (MessageBox.Show("Are you Sure You Want To Delete", "Notes", MessageBoxButtons.OKCancel) == DialogResult.OK)
					{
						DataTable dataTable = new DataTable();
						dataTable = dc.GetTableText("select * from Stock where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
						double num = Convert.ToDouble(dataTable.Rows[0][1].ToString());
						string[] fields = new string[1] { "id" };
						if (dc.Delete("DeleteVisit", fields, appid))
						{
							Convert.ToDouble(priceTextBox.Text);
							double num2 = num - oldpric;
							codes.Edit2("update Stock Set Value=" + num2.ToString() + " where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
							codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('حذف زيارة' ," + oldpric.ToString() + ",'" + PatientComboBox.Text + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
							MessageBox.Show("Data Delete Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							MethodsClass.UserMove("حذف زياره لمريض");
							loaddata();
							clear();
						}
						else
						{
							MessageBox.Show("Error Happend While Delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
					}
				}
				else if (MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.OKCancel) == DialogResult.OK)
				{
					DataTable dataTable = new DataTable();
					dataTable = dc.GetTableText("select * from Stock where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
					double num = Convert.ToDouble(dataTable.Rows[0][1].ToString());
					string[] fields = new string[1] { "id" };
					if (dc.Delete("DeleteVisit", fields, appid))
					{
						Convert.ToDouble(priceTextBox.Text);
						double num2 = num - oldpric;
						codes.Edit2("update Stock Set Value=" + num2.ToString() + " where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
						codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('حذف زيارة' ," + oldpric.ToString() + ",'" + PatientComboBox.Text + "','" + appdateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
						MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						loaddata();
						clear();
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
				}
			}
			catch
			{
			}
		}

		private void FrmBookingVisits_KeyDown(object sender, KeyEventArgs e)
		{
			try
			{
				if (e.KeyCode == Keys.F1)
				{
					Process.Start("calc");
				}
			}
			catch
			{
			}
		}
	}
}
