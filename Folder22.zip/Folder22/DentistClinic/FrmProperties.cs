using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;
using DentistClinic.Properties;
using FloatTextBox;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;

namespace DentistClinic
{
	public class FrmProperties : BaseForm
	{
		private dataClass codes = new dataClass(".\\sqlExpress");

		private string service;

		private static Server srvSql;

		public static string Databs;

		private string ServerName;

		private string DataBaseName;

		private string UserName;

		private string Pass;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private IContainer components = null;

		private GroupBox groupBox10;

		private Button saveBtn;

		private ComboBox commentTextBox;

		private Label label1;

		private ComboBox cmbservice;

		private Label label2;

		private CheckBox ShowDoctorCheckBox;

		private CheckBox checkBox1;

		private Button button1;

		private CheckBox checkBox2;

		private CheckBox checkBox3;

		private CheckBox checkBox4;

		private CheckBox checkBox5;

		private CheckBox checkBox6;

		private Button button2;

		private ComboBox comboBox1;

		private Label label3;

		private Panel panel1;

		private ComboBox comboBox2;

		private Label label4;

		private Panel panel2;

		private Label label5;

		private Label label;

		internal FloatText floatText1;

		private Label label8;

		private Label label7;

		private Label label10;

		private DateTimePicker dateTimePicker2;

		private CheckBox ShowEsal;

		private CheckBox AutoEsal;

		private ComboBox EsalPrint;

		private Label label9;

		private CheckBox AutoAsnaf;

		private GroupBox groupBox5;

		private Label label11;

		private Button button5;

		private Label label12;

		private DateTimePicker BackUpTime;

		private Timer timer1;

		private Label label6;

		private FolderBrowserDialog folderBrowserDialog1;

		private SaveFileDialog saveBackupDialog;

		private Button button3;

		private RadioButton DocNesba;

		private RadioButton EmpNesba;

		private Label label13;

		private CheckBox chTxtUnderPres;

		private TextBox TxtUnderPres;

		private CheckBox AcceptPatients;

		private DateTimePicker dateTimePicker1;

		private ComboBox EsalPrinterName;

		private Label label14;

		private ComboBox BillPrinter;

		private Label label15;

		private RadioButton DateFromFollow;

		private RadioButton DateFromReserve;

		private Label label16;

		private Panel panel4;

		private Panel panel3;

		private CheckBox AvoidPay2;

		private CheckBox AvoidPay1;

		private CheckBox PatientNameArggement;

		public FrmProperties()
		{
			InitializeComponent();
			groupBox5.Enabled = false;
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select * from CompanyService where Service = '" + comboBox1.Text + "'");
				if (commentTextBox.SelectedIndex == -1)
				{
					if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Choose Printer Size");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل حجم الطباعة");
					}
					return;
				}
				if (EsalPrint.SelectedIndex == -1)
				{
					if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Choose Esal Size");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل حجم طباعة الايصال");
					}
					return;
				}
				if (dataTable.Rows.Count == 0 && !checkBox6.Checked)
				{
					if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Choose Re-Detection service");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل خدمة اعادة الكشف");
					}
					return;
				}
				string text = "";
				text = ((!checkBox6.Checked) ? comboBox1.Text : "");
				codes.Edit2(string.Concat("UPDATE Properties set SizePrinter = '", commentTextBox.Text, "' , ServiceName = '", cmbservice.Text, "',ShowDoctor = '", ShowDoctorCheckBox.Checked, "',PaidState = '", checkBox1.Checked, "',AutoFileNo = '", checkBox2.Checked, "',CalSurgery = '", checkBox3.Checked, "',IncommingBillNo ='", checkBox4.Checked, "',ChooseDoctor='", checkBox5.Checked, "',AutoDetect='", checkBox6.Checked, "',ServiceDetect='", text, "', AppointSystem = ", comboBox2.SelectedIndex, ", AppointPeriod=", floatText1.Text, ", AppointFrom='", dateTimePicker1.Value, "', AppointTo='", dateTimePicker2.Value, "',ShowEsal='", ShowEsal.Checked, "',AutoEsal='", AutoEsal.Checked, "',EsalPrinter='", EsalPrint.Text, "', AutoAsnaf='", AutoAsnaf.Checked, "', BackUpTime ='", BackUpTime.Text, "',EmpNesba='", EmpNesba.Checked, "',DocNesba='", DocNesba.Checked, "',chTxtUnderPres='", chTxtUnderPres.Checked, "',TxtUnderPres='", TxtUnderPres.Text, "',AcceptPatients='", AcceptPatients.Checked, "',BillPrinter='", BillPrinter.Text, "',EsalPrinterName='", EsalPrinterName.Text, "', DateFromReserve='", DateFromReserve.Checked, "',DateFromFollow='", DateFromFollow.Checked, "',AvoidPay2='", AvoidPay2.Checked, "',AvoidPay1='", AvoidPay1.Checked, "',PatientNameArggement='", PatientNameArggement.Checked, "'"));
				Main.BackupDate = BackUpTime.Text;
				codes.Edit2("update PatientAccount set Bean = '" + cmbservice.Text + "' where Bean = '" + text + "' ");
				UsersClass.AutoEsal = AutoEsal.Checked;
				UsersClass.BillPrinter = BillPrinter.Text;
				UsersClass.EsalPrinterName = EsalPrinterName.Text;
				if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Data Updated Successfully", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("تم تعديل البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				MethodsClass.UserMove("تعديل الخصائص العامة ");
			}
			catch
			{
			}
		}

		private void loadData()
		{
			try
			{
				DataTable dataTable = codes.Search2("select distinct(Service) from CompanyService");
				cmbservice.DataSource = dataTable;
				cmbservice.DisplayMember = dataTable.Columns[0].ToString();
				cmbservice.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select distinct(Service) from CompanyService");
				comboBox1.DataSource = dataTable;
				comboBox1.DisplayMember = dataTable.Columns[0].ToString();
				comboBox1.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = codes.Search2("select SizePrinter,ServiceName,ShowDoctor,PaidState,AutoFileNo,CalSurgery,IncommingBillNo,ChooseDoctor,AutoDetect,ServiceDetect, AppointSystem, AppointPeriod, AppointFrom, AppointTo,ShowEsal,AutoEsal,EsalPrinter ,AutoAsnaf, BackUpTime,EmpNesba,DocNesba,chTxtUnderPres,TxtUnderPres,AcceptPatients,BillPrinter,EsalPrinterName, DateFromReserve,DateFromFollow ,AvoidPay1,AvoidPay2,PatientNameArggement from Properties");
				commentTextBox.Text = dataTable2.Rows[0][0].ToString();
				cmbservice.Text = dataTable2.Rows[0][1].ToString();
				service = dataTable2.Rows[0][1].ToString();
				ShowDoctorCheckBox.Checked = Convert.ToBoolean(dataTable2.Rows[0][2].ToString());
				checkBox1.Checked = Convert.ToBoolean(dataTable2.Rows[0][3].ToString());
				checkBox2.Checked = Convert.ToBoolean(dataTable2.Rows[0][4].ToString());
				checkBox3.Checked = Convert.ToBoolean(dataTable2.Rows[0][5].ToString());
				checkBox4.Checked = Convert.ToBoolean(dataTable2.Rows[0][6].ToString());
				checkBox5.Checked = Convert.ToBoolean(dataTable2.Rows[0][7].ToString());
				checkBox6.Checked = Convert.ToBoolean(dataTable2.Rows[0][8].ToString());
				comboBox1.Text = dataTable2.Rows[0][9].ToString();
				comboBox2.SelectedIndex = Convert.ToInt32(dataTable2.Rows[0][10].ToString());
				floatText1.Text = dataTable2.Rows[0][11].ToString();
				dateTimePicker1.Value = Convert.ToDateTime(dataTable2.Rows[0][12].ToString());
				dateTimePicker2.Value = Convert.ToDateTime(dataTable2.Rows[0][13].ToString());
				ShowEsal.Checked = Convert.ToBoolean(dataTable2.Rows[0]["ShowEsal"].ToString());
				AutoEsal.Checked = Convert.ToBoolean(dataTable2.Rows[0]["AutoEsal"].ToString());
				EsalPrint.Text = dataTable2.Rows[0]["EsalPrinter"].ToString();
				AutoAsnaf.Checked = Convert.ToBoolean(dataTable2.Rows[0]["AutoAsnaf"].ToString());
				AvoidPay1.Checked = Convert.ToBoolean(dataTable2.Rows[0]["AvoidPay1"].ToString());
				AvoidPay2.Checked = Convert.ToBoolean(dataTable2.Rows[0]["AvoidPay2"].ToString());
				try
				{
					BackUpTime.Text = dataTable2.Rows[0]["BackUpTime"].ToString();
				}
				catch
				{
				}
				EmpNesba.Checked = Convert.ToBoolean(dataTable2.Rows[0]["EmpNesba"].ToString());
				DocNesba.Checked = Convert.ToBoolean(dataTable2.Rows[0]["DocNesba"].ToString());
				chTxtUnderPres.Checked = Convert.ToBoolean(dataTable2.Rows[0]["chTxtUnderPres"].ToString());
				DateFromReserve.Checked = Convert.ToBoolean(dataTable2.Rows[0]["DateFromReserve"].ToString());
				DateFromFollow.Checked = Convert.ToBoolean(dataTable2.Rows[0]["DateFromFollow"].ToString());
				if (chTxtUnderPres.Checked)
				{
					TxtUnderPres.Visible = true;
					TxtUnderPres.Text = dataTable2.Rows[0]["TxtUnderPres"].ToString();
				}
				else
				{
					TxtUnderPres.Visible = false;
					TxtUnderPres.Text = "";
				}
				AcceptPatients.Checked = Convert.ToBoolean(dataTable2.Rows[0]["AcceptPatients"].ToString());
				BillPrinter.Text = dataTable2.Rows[0]["BillPrinter"].ToString();
				EsalPrinterName.Text = dataTable2.Rows[0]["EsalPrinterName"].ToString();
				PatientNameArggement.Checked = Convert.ToBoolean(dataTable2.Rows[0]["PatientNameArggement"].ToString());
			}
			catch
			{
			}
		}

		public void Printer(ComboBox com)
		{
			foreach (string installedPrinter in PrinterSettings.InstalledPrinters)
			{
				com.Items.Add(installedPrinter);
			}
		}

		private void FrmProperties_Load(object sender, EventArgs e)
		{
			try
			{
				if (DentistClinic.Properties.Settings.Default.Filename != "filename")
				{
					ServerConnection serverConnection = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName);
					serverConnection.LoginSecure = false;
					serverConnection.Login = DentistClinic.Properties.Settings.Default.UserName;
					serverConnection.Password = DentistClinic.Properties.Settings.Default.Pass;
					srvSql = new Server(serverConnection);
				}
			}
			catch
			{
			}
			loadData();
			Printer(BillPrinter);
			Printer(EsalPrinterName);
		}

		private void button1_Click(object sender, EventArgs e)
		{
			FrmCompaniesServicesPrices frmCompaniesServicesPrices = new FrmCompaniesServicesPrices();
			frmCompaniesServicesPrices.ShowDialog();
			loadData();
		}

		private void FrmProperties_FormClosing(object sender, FormClosingEventArgs e)
		{
			DataTable dataTable = codes.Search2("select ServiceName from Properties");
			string text = dataTable.Rows[0][0].ToString();
			if (text == "")
			{
				if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Choose Detection service");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل اسم خدمة الحجز");
				}
				e.Cancel = true;
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			FrmCompaniesServicesPrices frmCompaniesServicesPrices = new FrmCompaniesServicesPrices();
			frmCompaniesServicesPrices.ShowDialog();
			loadData();
		}

		private void checkBox6_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox6.Checked)
			{
				panel1.Visible = false;
			}
			else
			{
				panel1.Visible = true;
			}
		}

		private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (comboBox2.SelectedIndex == 0)
			{
				panel2.Visible = false;
			}
			else
			{
				panel2.Visible = true;
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
			{
				DentistClinic.Properties.Settings.Default.Filename = folderBrowserDialog1.SelectedPath;
				DentistClinic.Properties.Settings.Default.Save();
			}
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			label6.Text = DateTime.Now.ToString("hh:mm");
			try
			{
				if (label6.Text == BackUpTime.Value.ToString("hh:mm"))
				{
					if (srvSql != null)
					{
						Backup backup = new Backup();
						backup.BackupSetDescription = "ArchiveDataBase:" + DateTime.Now.ToShortDateString();
						backup.BackupSetName = "Archive";
						backup.Action = BackupActionType.Database;
						backup.Database = DentistClinic.Properties.Settings.Default.DataBaseName;
						string name = DentistClinic.Properties.Settings.Default.Filename + "\\Backup" + DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year + "   " + DateTime.Now.Hour + "-" + DateTime.Now.Minute + ".bak";
						BackupDeviceItem item = new BackupDeviceItem(name, DeviceType.File);
						ServerConnection serverConnection = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName, DentistClinic.Properties.Settings.Default.UserName, DentistClinic.Properties.Settings.Default.Pass);
						Server server = new Server(serverConnection);
						_ = server.Databases[DentistClinic.Properties.Settings.Default.DataBaseName];
						backup.Initialize = true;
						backup.Checksum = true;
						backup.ContinueAfterError = true;
						backup.Devices.Add(item);
						backup.Incremental = false;
						backup.ExpirationDate = DateTime.Now.AddDays(3.0);
						backup.LogTruncation = BackupTruncateLogType.Truncate;
						backup.FormatMedia = false;
						backup.SqlBackup(srvSql);
					}
					else
					{
						MessageBox.Show("A connection to a SQL server was not established.", "Not Connected to Server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					}
				}
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				ServerConnection serverConnection = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName);
				serverConnection.LoginSecure = false;
				serverConnection.Login = DentistClinic.Properties.Settings.Default.UserName;
				serverConnection.Password = DentistClinic.Properties.Settings.Default.Pass;
				serverConnection.DatabaseName = DentistClinic.Properties.Settings.Default.DataBaseName;
				srvSql = new Server(serverConnection);
				if (srvSql != null)
				{
					if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
					{
						DentistClinic.Properties.Settings.Default.Filename = folderBrowserDialog1.SelectedPath;
						DentistClinic.Properties.Settings.Default.Save();
						Backup backup = new Backup();
						backup.BackupSetDescription = "ArchiveDataBase:" + DateTime.Now.ToShortDateString();
						backup.BackupSetName = "Archive";
						backup.Action = BackupActionType.Database;
						backup.Database = DentistClinic.Properties.Settings.Default.DataBaseName;
						string name = DentistClinic.Properties.Settings.Default.Filename + "\\Backup" + DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year + "   " + DateTime.Now.Hour + "-" + DateTime.Now.Minute + "-" + DateTime.Now.Second + ".bak";
						BackupDeviceItem item = new BackupDeviceItem(name, DeviceType.File);
						ServerConnection serverConnection2 = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName, DentistClinic.Properties.Settings.Default.UserName, DentistClinic.Properties.Settings.Default.Pass);
						Server server = new Server(serverConnection2);
						_ = server.Databases[DentistClinic.Properties.Settings.Default.DataBaseName];
						backup.Initialize = true;
						backup.Checksum = true;
						backup.ContinueAfterError = true;
						backup.Devices.Add(item);
						backup.Incremental = false;
						backup.ExpirationDate = DateTime.Now.AddDays(3.0);
						backup.LogTruncation = BackupTruncateLogType.Truncate;
						backup.FormatMedia = false;
						backup.SqlBackup(srvSql);
						MessageBox.Show("Bakup of Database " + DentistClinic.Properties.Settings.Default.DataBaseName + " successfully created", "Server", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else
				{
					MessageBox.Show("A connection to a SQL server was not established.", "Not Connected to Server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
			}
		}

		private void checkBox7_CheckedChanged(object sender, EventArgs e)
		{
			if (chTxtUnderPres.Checked)
			{
				TxtUnderPres.Visible = true;
				return;
			}
			TxtUnderPres.Visible = false;
			TxtUnderPres.Text = "";
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmProperties));
			groupBox10 = new System.Windows.Forms.GroupBox();
			PatientNameArggement = new System.Windows.Forms.CheckBox();
			AvoidPay2 = new System.Windows.Forms.CheckBox();
			AvoidPay1 = new System.Windows.Forms.CheckBox();
			panel4 = new System.Windows.Forms.Panel();
			EmpNesba = new System.Windows.Forms.RadioButton();
			DocNesba = new System.Windows.Forms.RadioButton();
			panel3 = new System.Windows.Forms.Panel();
			DateFromReserve = new System.Windows.Forms.RadioButton();
			DateFromFollow = new System.Windows.Forms.RadioButton();
			label16 = new System.Windows.Forms.Label();
			BillPrinter = new System.Windows.Forms.ComboBox();
			label15 = new System.Windows.Forms.Label();
			EsalPrinterName = new System.Windows.Forms.ComboBox();
			label14 = new System.Windows.Forms.Label();
			AcceptPatients = new System.Windows.Forms.CheckBox();
			TxtUnderPres = new System.Windows.Forms.TextBox();
			chTxtUnderPres = new System.Windows.Forms.CheckBox();
			label13 = new System.Windows.Forms.Label();
			AutoAsnaf = new System.Windows.Forms.CheckBox();
			EsalPrint = new System.Windows.Forms.ComboBox();
			label9 = new System.Windows.Forms.Label();
			AutoEsal = new System.Windows.Forms.CheckBox();
			ShowEsal = new System.Windows.Forms.CheckBox();
			panel2 = new System.Windows.Forms.Panel();
			dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label10 = new System.Windows.Forms.Label();
			label8 = new System.Windows.Forms.Label();
			label7 = new System.Windows.Forms.Label();
			label = new System.Windows.Forms.Label();
			floatText1 = new FloatTextBox.FloatText();
			label5 = new System.Windows.Forms.Label();
			comboBox2 = new System.Windows.Forms.ComboBox();
			label4 = new System.Windows.Forms.Label();
			panel1 = new System.Windows.Forms.Panel();
			label3 = new System.Windows.Forms.Label();
			comboBox1 = new System.Windows.Forms.ComboBox();
			button2 = new System.Windows.Forms.Button();
			checkBox6 = new System.Windows.Forms.CheckBox();
			label2 = new System.Windows.Forms.Label();
			checkBox5 = new System.Windows.Forms.CheckBox();
			checkBox4 = new System.Windows.Forms.CheckBox();
			checkBox3 = new System.Windows.Forms.CheckBox();
			checkBox2 = new System.Windows.Forms.CheckBox();
			button1 = new System.Windows.Forms.Button();
			checkBox1 = new System.Windows.Forms.CheckBox();
			ShowDoctorCheckBox = new System.Windows.Forms.CheckBox();
			cmbservice = new System.Windows.Forms.ComboBox();
			commentTextBox = new System.Windows.Forms.ComboBox();
			label1 = new System.Windows.Forms.Label();
			saveBtn = new System.Windows.Forms.Button();
			groupBox5 = new System.Windows.Forms.GroupBox();
			button3 = new System.Windows.Forms.Button();
			label6 = new System.Windows.Forms.Label();
			label11 = new System.Windows.Forms.Label();
			button5 = new System.Windows.Forms.Button();
			label12 = new System.Windows.Forms.Label();
			BackUpTime = new System.Windows.Forms.DateTimePicker();
			timer1 = new System.Windows.Forms.Timer(components);
			folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
			saveBackupDialog = new System.Windows.Forms.SaveFileDialog();
			groupBox10.SuspendLayout();
			panel4.SuspendLayout();
			panel3.SuspendLayout();
			panel2.SuspendLayout();
			panel1.SuspendLayout();
			groupBox5.SuspendLayout();
			SuspendLayout();
			groupBox10.AccessibleDescription = null;
			groupBox10.AccessibleName = null;
			resources.ApplyResources(groupBox10, "groupBox10");
			groupBox10.BackColor = System.Drawing.Color.Transparent;
			groupBox10.BackgroundImage = null;
			groupBox10.Controls.Add(PatientNameArggement);
			groupBox10.Controls.Add(AvoidPay2);
			groupBox10.Controls.Add(AvoidPay1);
			groupBox10.Controls.Add(panel4);
			groupBox10.Controls.Add(panel3);
			groupBox10.Controls.Add(label16);
			groupBox10.Controls.Add(BillPrinter);
			groupBox10.Controls.Add(label15);
			groupBox10.Controls.Add(EsalPrinterName);
			groupBox10.Controls.Add(label14);
			groupBox10.Controls.Add(AcceptPatients);
			groupBox10.Controls.Add(TxtUnderPres);
			groupBox10.Controls.Add(chTxtUnderPres);
			groupBox10.Controls.Add(label13);
			groupBox10.Controls.Add(AutoAsnaf);
			groupBox10.Controls.Add(EsalPrint);
			groupBox10.Controls.Add(label9);
			groupBox10.Controls.Add(AutoEsal);
			groupBox10.Controls.Add(ShowEsal);
			groupBox10.Controls.Add(panel2);
			groupBox10.Controls.Add(comboBox2);
			groupBox10.Controls.Add(label4);
			groupBox10.Controls.Add(panel1);
			groupBox10.Controls.Add(checkBox6);
			groupBox10.Controls.Add(label2);
			groupBox10.Controls.Add(checkBox5);
			groupBox10.Controls.Add(checkBox4);
			groupBox10.Controls.Add(checkBox3);
			groupBox10.Controls.Add(checkBox2);
			groupBox10.Controls.Add(button1);
			groupBox10.Controls.Add(checkBox1);
			groupBox10.Controls.Add(ShowDoctorCheckBox);
			groupBox10.Controls.Add(cmbservice);
			groupBox10.Controls.Add(commentTextBox);
			groupBox10.Controls.Add(label1);
			groupBox10.Name = "groupBox10";
			groupBox10.TabStop = false;
			PatientNameArggement.AccessibleDescription = null;
			PatientNameArggement.AccessibleName = null;
			resources.ApplyResources(PatientNameArggement, "PatientNameArggement");
			PatientNameArggement.BackgroundImage = null;
			PatientNameArggement.Name = "PatientNameArggement";
			PatientNameArggement.UseVisualStyleBackColor = true;
			AvoidPay2.AccessibleDescription = null;
			AvoidPay2.AccessibleName = null;
			resources.ApplyResources(AvoidPay2, "AvoidPay2");
			AvoidPay2.BackgroundImage = null;
			AvoidPay2.Name = "AvoidPay2";
			AvoidPay2.UseVisualStyleBackColor = true;
			AvoidPay1.AccessibleDescription = null;
			AvoidPay1.AccessibleName = null;
			resources.ApplyResources(AvoidPay1, "AvoidPay1");
			AvoidPay1.BackgroundImage = null;
			AvoidPay1.Name = "AvoidPay1";
			AvoidPay1.UseVisualStyleBackColor = true;
			panel4.AccessibleDescription = null;
			panel4.AccessibleName = null;
			resources.ApplyResources(panel4, "panel4");
			panel4.BackgroundImage = null;
			panel4.Controls.Add(EmpNesba);
			panel4.Controls.Add(DocNesba);
			panel4.Font = null;
			panel4.Name = "panel4";
			EmpNesba.AccessibleDescription = null;
			EmpNesba.AccessibleName = null;
			resources.ApplyResources(EmpNesba, "EmpNesba");
			EmpNesba.BackgroundImage = null;
			EmpNesba.Name = "EmpNesba";
			EmpNesba.UseVisualStyleBackColor = true;
			DocNesba.AccessibleDescription = null;
			DocNesba.AccessibleName = null;
			resources.ApplyResources(DocNesba, "DocNesba");
			DocNesba.BackgroundImage = null;
			DocNesba.Name = "DocNesba";
			DocNesba.UseVisualStyleBackColor = true;
			panel3.AccessibleDescription = null;
			panel3.AccessibleName = null;
			resources.ApplyResources(panel3, "panel3");
			panel3.BackgroundImage = null;
			panel3.Controls.Add(DateFromReserve);
			panel3.Controls.Add(DateFromFollow);
			panel3.Font = null;
			panel3.Name = "panel3";
			DateFromReserve.AccessibleDescription = null;
			DateFromReserve.AccessibleName = null;
			resources.ApplyResources(DateFromReserve, "DateFromReserve");
			DateFromReserve.BackgroundImage = null;
			DateFromReserve.Name = "DateFromReserve";
			DateFromReserve.UseVisualStyleBackColor = true;
			DateFromFollow.AccessibleDescription = null;
			DateFromFollow.AccessibleName = null;
			resources.ApplyResources(DateFromFollow, "DateFromFollow");
			DateFromFollow.BackgroundImage = null;
			DateFromFollow.Name = "DateFromFollow";
			DateFromFollow.UseVisualStyleBackColor = true;
			label16.AccessibleDescription = null;
			label16.AccessibleName = null;
			resources.ApplyResources(label16, "label16");
			label16.Name = "label16";
			BillPrinter.AccessibleDescription = null;
			BillPrinter.AccessibleName = null;
			resources.ApplyResources(BillPrinter, "BillPrinter");
			BillPrinter.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			BillPrinter.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			BillPrinter.BackgroundImage = null;
			BillPrinter.FormattingEnabled = true;
			BillPrinter.Name = "BillPrinter";
			label15.AccessibleDescription = null;
			label15.AccessibleName = null;
			resources.ApplyResources(label15, "label15");
			label15.Name = "label15";
			EsalPrinterName.AccessibleDescription = null;
			EsalPrinterName.AccessibleName = null;
			resources.ApplyResources(EsalPrinterName, "EsalPrinterName");
			EsalPrinterName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			EsalPrinterName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			EsalPrinterName.BackgroundImage = null;
			EsalPrinterName.FormattingEnabled = true;
			EsalPrinterName.Name = "EsalPrinterName";
			label14.AccessibleDescription = null;
			label14.AccessibleName = null;
			resources.ApplyResources(label14, "label14");
			label14.Name = "label14";
			AcceptPatients.AccessibleDescription = null;
			AcceptPatients.AccessibleName = null;
			resources.ApplyResources(AcceptPatients, "AcceptPatients");
			AcceptPatients.BackgroundImage = null;
			AcceptPatients.Name = "AcceptPatients";
			AcceptPatients.UseVisualStyleBackColor = true;
			TxtUnderPres.AccessibleDescription = null;
			TxtUnderPres.AccessibleName = null;
			resources.ApplyResources(TxtUnderPres, "TxtUnderPres");
			TxtUnderPres.BackgroundImage = null;
			TxtUnderPres.Font = null;
			TxtUnderPres.Name = "TxtUnderPres";
			chTxtUnderPres.AccessibleDescription = null;
			chTxtUnderPres.AccessibleName = null;
			resources.ApplyResources(chTxtUnderPres, "chTxtUnderPres");
			chTxtUnderPres.BackgroundImage = null;
			chTxtUnderPres.Name = "chTxtUnderPres";
			chTxtUnderPres.UseVisualStyleBackColor = true;
			chTxtUnderPres.CheckedChanged += new System.EventHandler(checkBox7_CheckedChanged);
			label13.AccessibleDescription = null;
			label13.AccessibleName = null;
			resources.ApplyResources(label13, "label13");
			label13.Name = "label13";
			AutoAsnaf.AccessibleDescription = null;
			AutoAsnaf.AccessibleName = null;
			resources.ApplyResources(AutoAsnaf, "AutoAsnaf");
			AutoAsnaf.BackgroundImage = null;
			AutoAsnaf.Name = "AutoAsnaf";
			AutoAsnaf.UseVisualStyleBackColor = true;
			EsalPrint.AccessibleDescription = null;
			EsalPrint.AccessibleName = null;
			resources.ApplyResources(EsalPrint, "EsalPrint");
			EsalPrint.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			EsalPrint.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			EsalPrint.BackgroundImage = null;
			EsalPrint.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			EsalPrint.FormattingEnabled = true;
			EsalPrint.Items.AddRange(new object[4]
			{
				resources.GetString("EsalPrint.Items"),
				resources.GetString("EsalPrint.Items1"),
				resources.GetString("EsalPrint.Items2"),
				resources.GetString("EsalPrint.Items3")
			});
			EsalPrint.Name = "EsalPrint";
			label9.AccessibleDescription = null;
			label9.AccessibleName = null;
			resources.ApplyResources(label9, "label9");
			label9.Name = "label9";
			AutoEsal.AccessibleDescription = null;
			AutoEsal.AccessibleName = null;
			resources.ApplyResources(AutoEsal, "AutoEsal");
			AutoEsal.BackgroundImage = null;
			AutoEsal.Name = "AutoEsal";
			AutoEsal.UseVisualStyleBackColor = true;
			ShowEsal.AccessibleDescription = null;
			ShowEsal.AccessibleName = null;
			resources.ApplyResources(ShowEsal, "ShowEsal");
			ShowEsal.BackgroundImage = null;
			ShowEsal.Name = "ShowEsal";
			ShowEsal.UseVisualStyleBackColor = true;
			panel2.AccessibleDescription = null;
			panel2.AccessibleName = null;
			resources.ApplyResources(panel2, "panel2");
			panel2.BackgroundImage = null;
			panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel2.Controls.Add(dateTimePicker2);
			panel2.Controls.Add(dateTimePicker1);
			panel2.Controls.Add(label10);
			panel2.Controls.Add(label8);
			panel2.Controls.Add(label7);
			panel2.Controls.Add(label);
			panel2.Controls.Add(floatText1);
			panel2.Controls.Add(label5);
			panel2.Font = null;
			panel2.Name = "panel2";
			dateTimePicker2.AccessibleDescription = null;
			dateTimePicker2.AccessibleName = null;
			resources.ApplyResources(dateTimePicker2, "dateTimePicker2");
			dateTimePicker2.BackgroundImage = null;
			dateTimePicker2.CalendarFont = null;
			dateTimePicker2.Font = null;
			dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker2.Name = "dateTimePicker2";
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.Font = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			label10.AccessibleDescription = null;
			label10.AccessibleName = null;
			resources.ApplyResources(label10, "label10");
			label10.Name = "label10";
			label8.AccessibleDescription = null;
			label8.AccessibleName = null;
			resources.ApplyResources(label8, "label8");
			label8.Name = "label8";
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "label7");
			label7.Name = "label7";
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "label");
			label.Name = "label";
			floatText1.AccessibleDescription = null;
			floatText1.AccessibleName = null;
			resources.ApplyResources(floatText1, "floatText1");
			floatText1.BackgroundImage = null;
			floatText1.Font = null;
			floatText1.Name = "floatText1";
			floatText1.TabStop = false;
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label5");
			label5.Name = "label5";
			comboBox2.AccessibleDescription = null;
			comboBox2.AccessibleName = null;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.BackgroundImage = null;
			comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox2.FormattingEnabled = true;
			comboBox2.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox2.Items"),
				resources.GetString("comboBox2.Items1")
			});
			comboBox2.Name = "comboBox2";
			comboBox2.SelectedIndexChanged += new System.EventHandler(comboBox2_SelectedIndexChanged);
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Name = "label4";
			panel1.AccessibleDescription = null;
			panel1.AccessibleName = null;
			resources.ApplyResources(panel1, "panel1");
			panel1.BackgroundImage = null;
			panel1.Controls.Add(label3);
			panel1.Controls.Add(comboBox1);
			panel1.Controls.Add(button2);
			panel1.Font = null;
			panel1.Name = "panel1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Name = "label3";
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			comboBox1.FormattingEnabled = true;
			comboBox1.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox1.Items"),
				resources.GetString("comboBox1.Items1")
			});
			comboBox1.Name = "comboBox1";
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			checkBox6.AccessibleDescription = null;
			checkBox6.AccessibleName = null;
			resources.ApplyResources(checkBox6, "checkBox6");
			checkBox6.BackgroundImage = null;
			checkBox6.Checked = true;
			checkBox6.CheckState = System.Windows.Forms.CheckState.Checked;
			checkBox6.Name = "checkBox6";
			checkBox6.UseVisualStyleBackColor = true;
			checkBox6.CheckedChanged += new System.EventHandler(checkBox6_CheckedChanged);
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			checkBox5.AccessibleDescription = null;
			checkBox5.AccessibleName = null;
			resources.ApplyResources(checkBox5, "checkBox5");
			checkBox5.BackgroundImage = null;
			checkBox5.Name = "checkBox5";
			checkBox5.UseVisualStyleBackColor = true;
			checkBox4.AccessibleDescription = null;
			checkBox4.AccessibleName = null;
			resources.ApplyResources(checkBox4, "checkBox4");
			checkBox4.BackgroundImage = null;
			checkBox4.Name = "checkBox4";
			checkBox4.UseVisualStyleBackColor = true;
			checkBox3.AccessibleDescription = null;
			checkBox3.AccessibleName = null;
			resources.ApplyResources(checkBox3, "checkBox3");
			checkBox3.BackgroundImage = null;
			checkBox3.Name = "checkBox3";
			checkBox3.UseVisualStyleBackColor = true;
			checkBox2.AccessibleDescription = null;
			checkBox2.AccessibleName = null;
			resources.ApplyResources(checkBox2, "checkBox2");
			checkBox2.BackgroundImage = null;
			checkBox2.Name = "checkBox2";
			checkBox2.UseVisualStyleBackColor = true;
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			checkBox1.AccessibleDescription = null;
			checkBox1.AccessibleName = null;
			resources.ApplyResources(checkBox1, "checkBox1");
			checkBox1.BackgroundImage = null;
			checkBox1.Name = "checkBox1";
			checkBox1.UseVisualStyleBackColor = true;
			ShowDoctorCheckBox.AccessibleDescription = null;
			ShowDoctorCheckBox.AccessibleName = null;
			resources.ApplyResources(ShowDoctorCheckBox, "ShowDoctorCheckBox");
			ShowDoctorCheckBox.BackgroundImage = null;
			ShowDoctorCheckBox.Name = "ShowDoctorCheckBox";
			ShowDoctorCheckBox.UseVisualStyleBackColor = true;
			cmbservice.AccessibleDescription = null;
			cmbservice.AccessibleName = null;
			resources.ApplyResources(cmbservice, "cmbservice");
			cmbservice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			cmbservice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			cmbservice.BackgroundImage = null;
			cmbservice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cmbservice.FormattingEnabled = true;
			cmbservice.Items.AddRange(new object[2]
			{
				resources.GetString("cmbservice.Items"),
				resources.GetString("cmbservice.Items1")
			});
			cmbservice.Name = "cmbservice";
			commentTextBox.AccessibleDescription = null;
			commentTextBox.AccessibleName = null;
			resources.ApplyResources(commentTextBox, "commentTextBox");
			commentTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			commentTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			commentTextBox.BackgroundImage = null;
			commentTextBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			commentTextBox.FormattingEnabled = true;
			commentTextBox.Items.AddRange(new object[2]
			{
				resources.GetString("commentTextBox.Items"),
				resources.GetString("commentTextBox.Items1")
			});
			commentTextBox.Name = "commentTextBox";
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			saveBtn.AccessibleDescription = null;
			saveBtn.AccessibleName = null;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			saveBtn.BackgroundImage = null;
			saveBtn.Name = "saveBtn";
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			groupBox5.AccessibleDescription = null;
			groupBox5.AccessibleName = null;
			resources.ApplyResources(groupBox5, "groupBox5");
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.BackgroundImage = null;
			groupBox5.Controls.Add(button3);
			groupBox5.Controls.Add(label6);
			groupBox5.Controls.Add(label11);
			groupBox5.Controls.Add(button5);
			groupBox5.Controls.Add(label12);
			groupBox5.Controls.Add(BackUpTime);
			groupBox5.Name = "groupBox5";
			groupBox5.TabStop = false;
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackgroundImage = null;
			button3.Font = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "label6");
			label6.Font = null;
			label6.Name = "label6";
			label11.AccessibleDescription = null;
			label11.AccessibleName = null;
			resources.ApplyResources(label11, "label11");
			label11.Font = null;
			label11.Name = "label11";
			button5.AccessibleDescription = null;
			button5.AccessibleName = null;
			resources.ApplyResources(button5, "button5");
			button5.BackgroundImage = null;
			button5.Font = null;
			button5.Name = "button5";
			button5.UseVisualStyleBackColor = true;
			button5.Click += new System.EventHandler(button5_Click);
			label12.AccessibleDescription = null;
			label12.AccessibleName = null;
			resources.ApplyResources(label12, "label12");
			label12.Font = null;
			label12.Name = "label12";
			BackUpTime.AccessibleDescription = null;
			BackUpTime.AccessibleName = null;
			resources.ApplyResources(BackUpTime, "BackUpTime");
			BackUpTime.BackgroundImage = null;
			BackUpTime.CalendarFont = null;
			BackUpTime.CustomFormat = null;
			BackUpTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			BackUpTime.Name = "BackUpTime";
			BackUpTime.ShowUpDown = true;
			timer1.Interval = 10000;
			timer1.Tick += new System.EventHandler(timer1_Tick);
			resources.ApplyResources(folderBrowserDialog1, "folderBrowserDialog1");
			resources.ApplyResources(saveBackupDialog, "saveBackupDialog");
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox5);
			base.Controls.Add(saveBtn);
			base.Controls.Add(groupBox10);
			Font = null;
			base.Name = "FrmProperties";
			base.Load += new System.EventHandler(FrmProperties_Load);
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(FrmProperties_FormClosing);
			groupBox10.ResumeLayout(false);
			groupBox10.PerformLayout();
			panel4.ResumeLayout(false);
			panel4.PerformLayout();
			panel3.ResumeLayout(false);
			panel3.PerformLayout();
			panel2.ResumeLayout(false);
			panel2.PerformLayout();
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			groupBox5.ResumeLayout(false);
			groupBox5.PerformLayout();
			ResumeLayout(false);
		}
	}
}
