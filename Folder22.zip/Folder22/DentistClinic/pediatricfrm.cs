using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using FloatTextBox;

namespace DentistClinic
{
	public class pediatricfrm : BaseForm
	{
		private IContainer components = null;

		private TabControl tabControl1;

		private TabPage tabPage1;

		private TabPage tabPage2;

		private GroupBox groupBox2;

		private CheckBox Spastic;

		private CheckBox Dyskinetic;

		private CheckBox Hypo;

		private CheckBox Mixed;

		private CheckBox Ataxic;

		private GroupBox groupBox1;

		private CheckBox laborCS;

		private CheckBox laborNormal;

		private CheckBox Asphyxia;

		private CheckBox Incubation;

		private TextBox ClinicalFindings;

		private TextBox GMFCSLevel;

		private TextBox Diagnosis;

		private FloatText age;

		private TextBox filenum;

		private TextBox Sex;

		private ComboBox PatientName;

		private DateTimePicker birthDateDateTimePicker;

		private GroupBox groupBox6;

		private CheckBox SpeechLangdisability;

		private CheckBox Hearingdisability;

		private TextBox Cognition;

		private CheckBox Visualdisability;

		private CheckBox Epilepsy;

		private TextBox Mentalretardation;

		private GroupBox groupBox5;

		private TextBox Tapping;

		private TextBox Orthotics;

		private CheckBox Speechtherapy;

		private CheckBox OT;

		private CheckBox Earlyintervention;

		private TextBox SpecialComments;

		private TextBox Balance;

		private TextBox MuscleTone;

		private TabPage tabPage3;

		private Button update;

		private Button save;

		private TextBox Methods;

		private TextBox Goals;

		private TextBox Deformities;

		private TextBox GaitAnalysis;

		private GroupBox groupBox4;

		private Label label15;

		private DataGridView dataGridView1;

		private DataGridViewTextBoxColumn Milestone;

		private DataGridViewTextBoxColumn Z;

		private DataGridViewTextBoxColumn P;

		private DataGridViewTextBoxColumn N;

		private DataGridViewTextBoxColumn Comments;

		private Button Print;

		private Panel panelNatalHistory;

		private Panel panelCP;

		private Panel panelAssociated;

		private Panel panelNeeds;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlDataAdapter sqlDataAdapter1;

		private DataSet1 dataSet11;

		private CheckBox Consanguinity;

		private CheckBox Jaundice;

		private SqlCommand sqlCommand1;

		private SqlConnection sqlConnection2;

		private SqlDataAdapter sqlDataAdapter2;

		private SqlCommand sqlDeleteCommand;

		private SqlCommand sqlInsertCommand;

		private SqlCommand sqlUpdateCommand;

		private Panel panelneed_copy;

		private CheckBox checkneed2;

		private CheckBox checkneed1;

		private CheckBox checkneed3;

		private CheckBox checkAss1;

		private CheckBox checkAss2;

		private CheckBox checkAss3;

		private CheckBox checkAss4;

		private Panel panelAssociated_copy;

		private Button button1;

		private DateTimePicker Date;

		private DateTimePicker dateTimePicker1;

		private TextBox Signature;

		private ComboBox Devicescomb;

		private SqlDataAdapter sqlDataAdapter9;

		private SqlCommand sqlCommand19;

		private SqlConnection sqlConnection9;

		private SqlCommand sqlCommand26;

		private SqlCommand sqlCommand27;

		private SqlCommand sqlCommand28;

		private ClassDataBase dc;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		private GUI gui = new GUI();

		private string PatientID = "";

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.pediatricfrm));
			tabControl1 = new System.Windows.Forms.TabControl();
			tabPage1 = new System.Windows.Forms.TabPage();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			Milestone = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Z = new System.Windows.Forms.DataGridViewTextBoxColumn();
			P = new System.Windows.Forms.DataGridViewTextBoxColumn();
			N = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Comments = new System.Windows.Forms.DataGridViewTextBoxColumn();
			groupBox2 = new System.Windows.Forms.GroupBox();
			panelCP = new System.Windows.Forms.Panel();
			Spastic = new System.Windows.Forms.CheckBox();
			Ataxic = new System.Windows.Forms.CheckBox();
			Mixed = new System.Windows.Forms.CheckBox();
			Hypo = new System.Windows.Forms.CheckBox();
			Dyskinetic = new System.Windows.Forms.CheckBox();
			groupBox1 = new System.Windows.Forms.GroupBox();
			panelNatalHistory = new System.Windows.Forms.Panel();
			Consanguinity = new System.Windows.Forms.CheckBox();
			Jaundice = new System.Windows.Forms.CheckBox();
			Incubation = new System.Windows.Forms.CheckBox();
			laborNormal = new System.Windows.Forms.CheckBox();
			laborCS = new System.Windows.Forms.CheckBox();
			Asphyxia = new System.Windows.Forms.CheckBox();
			ClinicalFindings = new System.Windows.Forms.TextBox();
			GMFCSLevel = new System.Windows.Forms.TextBox();
			Diagnosis = new System.Windows.Forms.TextBox();
			age = new FloatTextBox.FloatText();
			filenum = new System.Windows.Forms.TextBox();
			Sex = new System.Windows.Forms.TextBox();
			PatientName = new System.Windows.Forms.ComboBox();
			birthDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
			tabPage2 = new System.Windows.Forms.TabPage();
			Date = new System.Windows.Forms.DateTimePicker();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			Signature = new System.Windows.Forms.TextBox();
			Deformities = new System.Windows.Forms.TextBox();
			groupBox6 = new System.Windows.Forms.GroupBox();
			Cognition = new System.Windows.Forms.TextBox();
			Mentalretardation = new System.Windows.Forms.TextBox();
			panelAssociated = new System.Windows.Forms.Panel();
			Epilepsy = new System.Windows.Forms.CheckBox();
			Visualdisability = new System.Windows.Forms.CheckBox();
			Hearingdisability = new System.Windows.Forms.CheckBox();
			SpeechLangdisability = new System.Windows.Forms.CheckBox();
			groupBox5 = new System.Windows.Forms.GroupBox();
			Tapping = new System.Windows.Forms.TextBox();
			Orthotics = new System.Windows.Forms.TextBox();
			panelNeeds = new System.Windows.Forms.Panel();
			Earlyintervention = new System.Windows.Forms.CheckBox();
			OT = new System.Windows.Forms.CheckBox();
			Speechtherapy = new System.Windows.Forms.CheckBox();
			SpecialComments = new System.Windows.Forms.TextBox();
			GaitAnalysis = new System.Windows.Forms.TextBox();
			Balance = new System.Windows.Forms.TextBox();
			MuscleTone = new System.Windows.Forms.TextBox();
			tabPage3 = new System.Windows.Forms.TabPage();
			Devicescomb = new System.Windows.Forms.ComboBox();
			Methods = new System.Windows.Forms.TextBox();
			Goals = new System.Windows.Forms.TextBox();
			panelAssociated_copy = new System.Windows.Forms.Panel();
			checkAss4 = new System.Windows.Forms.CheckBox();
			checkAss1 = new System.Windows.Forms.CheckBox();
			checkAss3 = new System.Windows.Forms.CheckBox();
			checkAss2 = new System.Windows.Forms.CheckBox();
			panelneed_copy = new System.Windows.Forms.Panel();
			checkneed2 = new System.Windows.Forms.CheckBox();
			checkneed1 = new System.Windows.Forms.CheckBox();
			checkneed3 = new System.Windows.Forms.CheckBox();
			update = new System.Windows.Forms.Button();
			save = new System.Windows.Forms.Button();
			groupBox4 = new System.Windows.Forms.GroupBox();
			this.label15 = new System.Windows.Forms.Label();
			Print = new System.Windows.Forms.Button();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			dataSet11 = new DataSet1();
			sqlCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			sqlDeleteCommand = new System.Data.SqlClient.SqlCommand();
			sqlInsertCommand = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand = new System.Data.SqlClient.SqlCommand();
			button1 = new System.Windows.Forms.Button();
			sqlDataAdapter9 = new System.Data.SqlClient.SqlDataAdapter();
			sqlCommand19 = new System.Data.SqlClient.SqlCommand();
			sqlConnection9 = new System.Data.SqlClient.SqlConnection();
			sqlCommand26 = new System.Data.SqlClient.SqlCommand();
			sqlCommand27 = new System.Data.SqlClient.SqlCommand();
			sqlCommand28 = new System.Data.SqlClient.SqlCommand();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label7 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label8 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label9 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label10 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label11 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label12 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label13 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label14 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label15 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label16 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label17 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label18 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label19 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label20 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label21 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label22 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label23 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label24 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label25 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label26 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label27 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label28 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label29 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label30 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label31 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label32 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label33 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label34 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label35 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label36 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label37 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label38 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label39 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label40 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label41 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label42 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label43 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label44 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label45 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label46 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label47 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label48 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label49 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label50 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label51 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label52 = new System.Windows.Forms.Label();
			tabControl1.SuspendLayout();
			tabPage1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox2.SuspendLayout();
			panelCP.SuspendLayout();
			groupBox1.SuspendLayout();
			panelNatalHistory.SuspendLayout();
			tabPage2.SuspendLayout();
			groupBox6.SuspendLayout();
			panelAssociated.SuspendLayout();
			groupBox5.SuspendLayout();
			panelNeeds.SuspendLayout();
			tabPage3.SuspendLayout();
			panelAssociated_copy.SuspendLayout();
			panelneed_copy.SuspendLayout();
			groupBox4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			label.AutoSize = true;
			label.BackColor = System.Drawing.Color.Transparent;
			label.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label.Location = new System.Drawing.Point(222, 7);
			label.Name = "label18";
			label.Size = new System.Drawing.Size(48, 16);
			label.TabIndex = 127;
			label.Text = "Ataxic";
			label2.AutoSize = true;
			label2.BackColor = System.Drawing.Color.Transparent;
			label2.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label2.Location = new System.Drawing.Point(26, 5);
			label2.Name = "label16";
			label2.Size = new System.Drawing.Size(58, 16);
			label2.TabIndex = 125;
			label2.Text = "Spastic ";
			label3.AutoSize = true;
			label3.BackColor = System.Drawing.Color.Transparent;
			label3.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label3.Location = new System.Drawing.Point(130, 5);
			label3.Name = "label17";
			label3.Size = new System.Drawing.Size(40, 16);
			label3.TabIndex = 126;
			label3.Text = "Hypo";
			label4.AutoSize = true;
			label4.BackColor = System.Drawing.Color.Transparent;
			label4.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label4.Location = new System.Drawing.Point(25, 33);
			label4.Name = "label19";
			label4.Size = new System.Drawing.Size(72, 16);
			label4.TabIndex = 128;
			label4.Text = "Dyskinetic";
			label5.AutoSize = true;
			label5.BackColor = System.Drawing.Color.Transparent;
			label5.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label5.Location = new System.Drawing.Point(127, 32);
			label5.Name = "label20";
			label5.Size = new System.Drawing.Size(51, 16);
			label5.TabIndex = 129;
			label5.Text = " Mixed";
			label6.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			label6.AutoSize = true;
			label6.BackColor = System.Drawing.Color.Transparent;
			label6.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label6.Location = new System.Drawing.Point(18, 2);
			label6.Name = "label6";
			label6.Size = new System.Drawing.Size(107, 16);
			label6.TabIndex = 115;
			label6.Text = "Nature of labor:";
			label7.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			label7.AutoSize = true;
			label7.BackColor = System.Drawing.Color.Transparent;
			label7.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label7.Location = new System.Drawing.Point(248, 5);
			label7.Name = "label7";
			label7.Size = new System.Drawing.Size(34, 16);
			label7.TabIndex = 116;
			label7.Text = "C.S ";
			label8.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			label8.AutoSize = true;
			label8.BackColor = System.Drawing.Color.Transparent;
			label8.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label8.Location = new System.Drawing.Point(143, 4);
			label8.Name = "label8";
			label8.Size = new System.Drawing.Size(54, 16);
			label8.TabIndex = 117;
			label8.Text = "Normal";
			label9.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			label9.AutoSize = true;
			label9.BackColor = System.Drawing.Color.Transparent;
			label9.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label9.Location = new System.Drawing.Point(55, 28);
			label9.Name = "label10";
			label9.Size = new System.Drawing.Size(70, 16);
			label9.TabIndex = 119;
			label9.Text = "Asphyxia:";
			label10.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			label10.AutoSize = true;
			label10.BackColor = System.Drawing.Color.Transparent;
			label10.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label10.Location = new System.Drawing.Point(44, 52);
			label10.Name = "label11";
			label10.Size = new System.Drawing.Size(79, 16);
			label10.TabIndex = 120;
			label10.Text = "Incubation:";
			label11.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			label11.AutoSize = true;
			label11.BackColor = System.Drawing.Color.Transparent;
			label11.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label11.Location = new System.Drawing.Point(149, 53);
			label11.Name = "label12";
			label11.Size = new System.Drawing.Size(38, 16);
			label11.TabIndex = 121;
			label11.Text = "Days";
			label12.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label12.AutoSize = true;
			label12.BackColor = System.Drawing.Color.Transparent;
			label12.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label12.Location = new System.Drawing.Point(604, 228);
			label12.Name = "label5";
			label12.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label12.Size = new System.Drawing.Size(159, 16);
			label12.TabIndex = 186;
			label12.Text = "(Sugary, C.T, E.M.G, etc.)";
			label13.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label13.AutoSize = true;
			label13.BackColor = System.Drawing.Color.Transparent;
			label13.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label13.Location = new System.Drawing.Point(484, 226);
			label13.Name = "label4";
			label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label13.Size = new System.Drawing.Size(124, 19);
			label13.TabIndex = 184;
			label13.Text = "Clinical Findings:";
			label14.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label14.AutoSize = true;
			label14.BackColor = System.Drawing.Color.Transparent;
			label14.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label14.Location = new System.Drawing.Point(484, 177);
			label14.Name = "label2";
			label14.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label14.Size = new System.Drawing.Size(113, 19);
			label14.TabIndex = 182;
			label14.Text = "GMFCS Level:";
			label15.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label15.AutoSize = true;
			label15.BackColor = System.Drawing.Color.Transparent;
			label15.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label15.Location = new System.Drawing.Point(484, 52);
			label15.Name = "label1";
			label15.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label15.Size = new System.Drawing.Size(80, 19);
			label15.TabIndex = 180;
			label15.Text = "Diagnosis:";
			label16.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label16.AutoSize = true;
			label16.BackColor = System.Drawing.Color.Transparent;
			label16.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label16.Location = new System.Drawing.Point(319, 12);
			label16.Name = "label52";
			label16.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label16.Size = new System.Drawing.Size(41, 19);
			label16.TabIndex = 179;
			label16.Text = "Age:";
			label17.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label17.AutoSize = true;
			label17.BackColor = System.Drawing.Color.Transparent;
			label17.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label17.Location = new System.Drawing.Point(421, 12);
			label17.Name = "label51";
			label17.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label17.Size = new System.Drawing.Size(39, 19);
			label17.TabIndex = 178;
			label17.Text = "Year";
			label18.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label18.AutoSize = true;
			label18.BackColor = System.Drawing.Color.Transparent;
			label18.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label18.Location = new System.Drawing.Point(485, 9);
			label18.Name = "label48";
			label18.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label18.Size = new System.Drawing.Size(63, 19);
			label18.TabIndex = 177;
			label18.Text = "File No:";
			label19.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label19.AutoSize = true;
			label19.BackColor = System.Drawing.Color.Transparent;
			label19.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label19.Location = new System.Drawing.Point(38, 12);
			label19.Name = "nameLabel";
			label19.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label19.Size = new System.Drawing.Size(54, 19);
			label19.TabIndex = 171;
			label19.Text = "Name:";
			label20.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label20.AutoSize = true;
			label20.BackColor = System.Drawing.Color.Transparent;
			label20.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label20.Location = new System.Drawing.Point(318, 56);
			label20.Name = "sexLabel";
			label20.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label20.Size = new System.Drawing.Size(39, 19);
			label20.TabIndex = 170;
			label20.Text = "Sex:";
			label21.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label21.AutoSize = true;
			label21.BackColor = System.Drawing.Color.Transparent;
			label21.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label21.Location = new System.Drawing.Point(36, 56);
			label21.Name = "birthDateLabel";
			label21.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label21.Size = new System.Drawing.Size(57, 19);
			label21.TabIndex = 169;
			label21.Text = "D.O.B:";
			label22.AutoSize = true;
			label22.BackColor = System.Drawing.Color.Transparent;
			label22.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label22.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label22.Location = new System.Drawing.Point(3, 3);
			label22.Name = "label34";
			label22.Size = new System.Drawing.Size(65, 16);
			label22.TabIndex = 145;
			label22.Text = "Epilepsy:";
			label23.AutoSize = true;
			label23.BackColor = System.Drawing.Color.Transparent;
			label23.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label23.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label23.Location = new System.Drawing.Point(3, 25);
			label23.Name = "label32";
			label23.Size = new System.Drawing.Size(112, 16);
			label23.TabIndex = 147;
			label23.Text = "Visual disability:";
			label24.AutoSize = true;
			label24.BackColor = System.Drawing.Color.Transparent;
			label24.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label24.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label24.Location = new System.Drawing.Point(3, 46);
			label24.Name = "label31";
			label24.Size = new System.Drawing.Size(123, 16);
			label24.TabIndex = 148;
			label24.Text = "Hearing disability:";
			label25.AutoSize = true;
			label25.BackColor = System.Drawing.Color.Transparent;
			label25.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label25.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label25.Location = new System.Drawing.Point(1, 66);
			label25.Name = "label30";
			label25.Size = new System.Drawing.Size(169, 16);
			label25.TabIndex = 149;
			label25.Text = "Speech & Lang. disability: ";
			label26.AutoSize = true;
			label26.BackColor = System.Drawing.Color.Transparent;
			label26.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label26.Location = new System.Drawing.Point(34, 125);
			label26.Name = "label35";
			label26.Size = new System.Drawing.Size(77, 16);
			label26.TabIndex = 150;
			label26.Text = "Cognition: ";
			label27.AutoSize = true;
			label27.BackColor = System.Drawing.Color.Transparent;
			label27.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label27.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label27.Location = new System.Drawing.Point(33, 220);
			label27.Name = "label36";
			label27.Size = new System.Drawing.Size(137, 16);
			label27.TabIndex = 152;
			label27.Text = "Mental retardation:  ";
			label28.AutoSize = true;
			label28.BackColor = System.Drawing.Color.Transparent;
			label28.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label28.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label28.Location = new System.Drawing.Point(4, 6);
			label28.Name = "label28";
			label28.Size = new System.Drawing.Size(33, 16);
			label28.TabIndex = 137;
			label28.Text = "O.T:";
			label29.AutoSize = true;
			label29.BackColor = System.Drawing.Color.Transparent;
			label29.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label29.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label29.Location = new System.Drawing.Point(5, 29);
			label29.Name = "label26";
			label29.Size = new System.Drawing.Size(124, 16);
			label29.TabIndex = 139;
			label29.Text = "Early intervention:";
			label30.AutoSize = true;
			label30.BackColor = System.Drawing.Color.Transparent;
			label30.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label30.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label30.Location = new System.Drawing.Point(3, 50);
			label30.Name = "label25";
			label30.Size = new System.Drawing.Size(116, 16);
			label30.TabIndex = 140;
			label30.Text = "Speech therapy :";
			label31.AutoSize = true;
			label31.BackColor = System.Drawing.Color.Transparent;
			label31.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label31.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label31.Location = new System.Drawing.Point(41, 113);
			label31.Name = "label24";
			label31.Size = new System.Drawing.Size(67, 16);
			label31.TabIndex = 141;
			label31.Text = "Tapping: ";
			label32.AutoSize = true;
			label32.BackColor = System.Drawing.Color.Transparent;
			label32.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label32.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label32.Location = new System.Drawing.Point(41, 221);
			label32.Name = "label29";
			label32.Size = new System.Drawing.Size(72, 16);
			label32.TabIndex = 143;
			label32.Text = "Orthotics: ";
			label33.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label33.AutoSize = true;
			label33.BackColor = System.Drawing.Color.Transparent;
			label33.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label33.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label33.Location = new System.Drawing.Point(455, 414);
			label33.Name = "label37";
			label33.Size = new System.Drawing.Size(141, 19);
			label33.TabIndex = 185;
			label33.Text = "Special Comments: ";
			label34.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label34.AutoSize = true;
			label34.BackColor = System.Drawing.Color.Transparent;
			label34.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label34.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label34.Location = new System.Drawing.Point(59, 89);
			label34.Name = "label23";
			label34.Size = new System.Drawing.Size(72, 19);
			label34.TabIndex = 181;
			label34.Text = "Balance: ";
			label35.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label35.AutoSize = true;
			label35.BackColor = System.Drawing.Color.Transparent;
			label35.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label35.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label35.Location = new System.Drawing.Point(59, 6);
			label35.Name = "label21";
			label35.Size = new System.Drawing.Size(109, 19);
			label35.TabIndex = 177;
			label35.Text = "Muscle Tone:  ";
			label36.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label36.AutoSize = true;
			label36.BackColor = System.Drawing.Color.Transparent;
			label36.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label36.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label36.Location = new System.Drawing.Point(52, 276);
			label36.Name = "label39";
			label36.Size = new System.Drawing.Size(74, 19);
			label36.TabIndex = 181;
			label36.Text = "Methods:";
			label37.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label37.AutoSize = true;
			label37.BackColor = System.Drawing.Color.Transparent;
			label37.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label37.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label37.Location = new System.Drawing.Point(52, 45);
			label37.Name = "label40";
			label37.Size = new System.Drawing.Size(53, 19);
			label37.TabIndex = 179;
			label37.Text = "Goals:";
			label38.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label38.AutoSize = true;
			label38.BackColor = System.Drawing.Color.Transparent;
			label38.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label38.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label38.Location = new System.Drawing.Point(41, 384);
			label38.Name = "label9";
			label38.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label38.Size = new System.Drawing.Size(169, 19);
			label38.TabIndex = 190;
			label38.Text = "Developmental History:";
			label39.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label39.AutoSize = true;
			label39.BackColor = System.Drawing.Color.Transparent;
			label39.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label39.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label39.Location = new System.Drawing.Point(455, 6);
			label39.Name = "label3";
			label39.Size = new System.Drawing.Size(97, 19);
			label39.TabIndex = 189;
			label39.Text = "Deformities: ";
			label40.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label40.AutoSize = true;
			label40.BackColor = System.Drawing.Color.Transparent;
			label40.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			label40.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label40.Location = new System.Drawing.Point(59, 482);
			label40.Name = "label38";
			label40.Size = new System.Drawing.Size(107, 19);
			label40.TabIndex = 183;
			label40.Text = "Gait Analysis: ";
			label41.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			label41.AutoSize = true;
			label41.BackColor = System.Drawing.Color.Transparent;
			label41.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label41.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label41.Location = new System.Drawing.Point(51, 76);
			label41.Name = "label13";
			label41.Size = new System.Drawing.Size(70, 16);
			label41.TabIndex = 168;
			label41.Text = "Jaundice:";
			label42.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			label42.AutoSize = true;
			label42.BackColor = System.Drawing.Color.Transparent;
			label42.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label42.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label42.Location = new System.Drawing.Point(20, 99);
			label42.Name = "label14";
			label42.Size = new System.Drawing.Size(102, 16);
			label42.TabIndex = 169;
			label42.Text = "Consanguinity:";
			label43.AutoSize = true;
			label43.BackColor = System.Drawing.Color.Transparent;
			label43.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label43.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label43.Location = new System.Drawing.Point(11, 5);
			label43.Name = "label22";
			label43.Size = new System.Drawing.Size(33, 16);
			label43.TabIndex = 137;
			label43.Text = "O.T:";
			label44.AutoSize = true;
			label44.BackColor = System.Drawing.Color.Transparent;
			label44.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label44.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label44.Location = new System.Drawing.Point(12, 28);
			label44.Name = "label27";
			label44.Size = new System.Drawing.Size(124, 16);
			label44.TabIndex = 139;
			label44.Text = "Early intervention:";
			label45.AutoSize = true;
			label45.BackColor = System.Drawing.Color.Transparent;
			label45.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label45.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label45.Location = new System.Drawing.Point(10, 49);
			label45.Name = "label33";
			label45.Size = new System.Drawing.Size(116, 16);
			label45.TabIndex = 140;
			label45.Text = "Speech therapy :";
			label46.AutoSize = true;
			label46.BackColor = System.Drawing.Color.Transparent;
			label46.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label46.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label46.Location = new System.Drawing.Point(13, 13);
			label46.Name = "label41";
			label46.Size = new System.Drawing.Size(65, 16);
			label46.TabIndex = 145;
			label46.Text = "Epilepsy:";
			label47.AutoSize = true;
			label47.BackColor = System.Drawing.Color.Transparent;
			label47.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label47.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label47.Location = new System.Drawing.Point(13, 35);
			label47.Name = "label42";
			label47.Size = new System.Drawing.Size(112, 16);
			label47.TabIndex = 147;
			label47.Text = "Visual disability:";
			label48.AutoSize = true;
			label48.BackColor = System.Drawing.Color.Transparent;
			label48.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label48.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label48.Location = new System.Drawing.Point(13, 56);
			label48.Name = "label43";
			label48.Size = new System.Drawing.Size(123, 16);
			label48.TabIndex = 148;
			label48.Text = "Hearing disability:";
			label49.AutoSize = true;
			label49.BackColor = System.Drawing.Color.Transparent;
			label49.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label49.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label49.Location = new System.Drawing.Point(11, 76);
			label49.Name = "label44";
			label49.Size = new System.Drawing.Size(169, 16);
			label49.TabIndex = 149;
			label49.Text = "Speech & Lang. disability: ";
			label50.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label50.AutoSize = true;
			label50.BackColor = System.Drawing.Color.Transparent;
			label50.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label50.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label50.Location = new System.Drawing.Point(456, 514);
			label50.Name = "label45";
			label50.Size = new System.Drawing.Size(74, 16);
			label50.TabIndex = 191;
			label50.Text = "Signature:";
			label51.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label51.AutoSize = true;
			label51.BackColor = System.Drawing.Color.Transparent;
			label51.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold);
			label51.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label51.Location = new System.Drawing.Point(478, 545);
			label51.Name = "label46";
			label51.Size = new System.Drawing.Size(52, 16);
			label51.TabIndex = 192;
			label51.Text = "D.O.A: ";
			label52.Anchor = System.Windows.Forms.AnchorStyles.Top;
			label52.AutoSize = true;
			label52.BackColor = System.Drawing.Color.Transparent;
			label52.Font = new System.Drawing.Font("Times New Roman", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label52.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			label52.Location = new System.Drawing.Point(73, 508);
			label52.Name = "label61";
			label52.RightToLeft = System.Windows.Forms.RightToLeft.No;
			label52.Size = new System.Drawing.Size(105, 22);
			label52.TabIndex = 358;
			label52.Text = "Treatment: ";
			tabControl1.Anchor = System.Windows.Forms.AnchorStyles.Top;
			tabControl1.Controls.Add(tabPage1);
			tabControl1.Controls.Add(tabPage2);
			tabControl1.Controls.Add(tabPage3);
			tabControl1.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			tabControl1.Location = new System.Drawing.Point(31, 27);
			tabControl1.Name = "tabControl1";
			tabControl1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			tabControl1.SelectedIndex = 0;
			tabControl1.Size = new System.Drawing.Size(829, 613);
			tabControl1.TabIndex = 179;
			tabPage1.Controls.Add(dataGridView1);
			tabPage1.Controls.Add(label38);
			tabPage1.Controls.Add(groupBox2);
			tabPage1.Controls.Add(groupBox1);
			tabPage1.Controls.Add(label12);
			tabPage1.Controls.Add(ClinicalFindings);
			tabPage1.Controls.Add(label13);
			tabPage1.Controls.Add(GMFCSLevel);
			tabPage1.Controls.Add(label14);
			tabPage1.Controls.Add(Diagnosis);
			tabPage1.Controls.Add(label15);
			tabPage1.Controls.Add(age);
			tabPage1.Controls.Add(label16);
			tabPage1.Controls.Add(label17);
			tabPage1.Controls.Add(filenum);
			tabPage1.Controls.Add(label18);
			tabPage1.Controls.Add(label19);
			tabPage1.Controls.Add(Sex);
			tabPage1.Controls.Add(PatientName);
			tabPage1.Controls.Add(label20);
			tabPage1.Controls.Add(birthDateDateTimePicker);
			tabPage1.Controls.Add(label21);
			tabPage1.Location = new System.Drawing.Point(4, 25);
			tabPage1.Name = "tabPage1";
			tabPage1.Padding = new System.Windows.Forms.Padding(3);
			tabPage1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			tabPage1.Size = new System.Drawing.Size(821, 584);
			tabPage1.TabIndex = 0;
			tabPage1.Text = "Page 1";
			tabPage1.UseVisualStyleBackColor = true;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.Top;
			dataGridView1.BackgroundColor = System.Drawing.Color.White;
			dataGridViewCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			dataGridView1.Columns.AddRange(Milestone, Z, P, N, Comments);
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.White;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
			dataGridView1.Location = new System.Drawing.Point(52, 415);
			dataGridView1.Name = "dataGridView1";
			dataGridView1.RowHeadersVisible = false;
			dataGridView1.RowHeadersWidth = 60;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle3;
			dataGridView1.Size = new System.Drawing.Size(743, 156);
			dataGridView1.TabIndex = 0;
			Milestone.HeaderText = "Milestone";
			Milestone.Name = "Milestone";
			Milestone.ReadOnly = true;
			Milestone.Width = 150;
			Z.HeaderText = "Z";
			Z.Name = "Z";
			Z.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			Z.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			Z.Width = 80;
			P.HeaderText = "P";
			P.Name = "P";
			P.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			P.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			P.Width = 80;
			N.HeaderText = "N";
			N.Name = "N";
			N.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			N.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			N.Width = 80;
			Comments.HeaderText = "Comments";
			Comments.Name = "Comments";
			Comments.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			Comments.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			Comments.Width = 350;
			groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(panelCP);
			groupBox2.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			groupBox2.Location = new System.Drawing.Point(45, 276);
			groupBox2.Name = "groupBox2";
			groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			groupBox2.Size = new System.Drawing.Size(343, 101);
			groupBox2.TabIndex = 189;
			groupBox2.TabStop = false;
			groupBox2.Text = "C.P Type:";
			panelCP.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			panelCP.Controls.Add(label);
			panelCP.Controls.Add(Spastic);
			panelCP.Controls.Add(label2);
			panelCP.Controls.Add(Ataxic);
			panelCP.Controls.Add(label3);
			panelCP.Controls.Add(Mixed);
			panelCP.Controls.Add(label4);
			panelCP.Controls.Add(Hypo);
			panelCP.Controls.Add(label5);
			panelCP.Controls.Add(Dyskinetic);
			panelCP.Location = new System.Drawing.Point(27, 28);
			panelCP.Name = "panelCP";
			panelCP.Size = new System.Drawing.Size(273, 59);
			panelCP.TabIndex = 191;
			Spastic.AutoSize = true;
			Spastic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Spastic.Location = new System.Drawing.Point(3, 7);
			Spastic.Name = "Spastic";
			Spastic.Size = new System.Drawing.Size(12, 11);
			Spastic.TabIndex = 168;
			Spastic.UseVisualStyleBackColor = true;
			Ataxic.AutoSize = true;
			Ataxic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Ataxic.Location = new System.Drawing.Point(201, 7);
			Ataxic.Name = "Ataxic";
			Ataxic.Size = new System.Drawing.Size(12, 11);
			Ataxic.TabIndex = 172;
			Ataxic.UseVisualStyleBackColor = true;
			Mixed.AutoSize = true;
			Mixed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Mixed.Location = new System.Drawing.Point(111, 34);
			Mixed.Name = "Mixed";
			Mixed.Size = new System.Drawing.Size(12, 11);
			Mixed.TabIndex = 171;
			Mixed.UseVisualStyleBackColor = true;
			Hypo.AutoSize = true;
			Hypo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Hypo.Location = new System.Drawing.Point(111, 7);
			Hypo.Name = "Hypo";
			Hypo.Size = new System.Drawing.Size(12, 11);
			Hypo.TabIndex = 170;
			Hypo.UseVisualStyleBackColor = true;
			Dyskinetic.AutoSize = true;
			Dyskinetic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Dyskinetic.Location = new System.Drawing.Point(4, 34);
			Dyskinetic.Name = "Dyskinetic";
			Dyskinetic.Size = new System.Drawing.Size(12, 11);
			Dyskinetic.TabIndex = 169;
			Dyskinetic.UseVisualStyleBackColor = true;
			groupBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(panelNatalHistory);
			groupBox1.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			groupBox1.Location = new System.Drawing.Point(45, 100);
			groupBox1.Name = "groupBox1";
			groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			groupBox1.Size = new System.Drawing.Size(343, 170);
			groupBox1.TabIndex = 188;
			groupBox1.TabStop = false;
			groupBox1.Text = "Natal History:";
			panelNatalHistory.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			panelNatalHistory.Controls.Add(label41);
			panelNatalHistory.Controls.Add(label42);
			panelNatalHistory.Controls.Add(Consanguinity);
			panelNatalHistory.Controls.Add(Jaundice);
			panelNatalHistory.Controls.Add(label10);
			panelNatalHistory.Controls.Add(label9);
			panelNatalHistory.Controls.Add(label11);
			panelNatalHistory.Controls.Add(label6);
			panelNatalHistory.Controls.Add(label7);
			panelNatalHistory.Controls.Add(Incubation);
			panelNatalHistory.Controls.Add(laborNormal);
			panelNatalHistory.Controls.Add(label8);
			panelNatalHistory.Controls.Add(laborCS);
			panelNatalHistory.Controls.Add(Asphyxia);
			panelNatalHistory.Location = new System.Drawing.Point(17, 31);
			panelNatalHistory.Name = "panelNatalHistory";
			panelNatalHistory.Size = new System.Drawing.Size(298, 125);
			panelNatalHistory.TabIndex = 191;
			Consanguinity.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			Consanguinity.AutoSize = true;
			Consanguinity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Consanguinity.Location = new System.Drawing.Point(130, 105);
			Consanguinity.Name = "Consanguinity";
			Consanguinity.Size = new System.Drawing.Size(12, 11);
			Consanguinity.TabIndex = 170;
			Consanguinity.UseVisualStyleBackColor = true;
			Jaundice.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			Jaundice.AutoSize = true;
			Jaundice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Jaundice.Location = new System.Drawing.Point(130, 81);
			Jaundice.Name = "Jaundice";
			Jaundice.Size = new System.Drawing.Size(12, 11);
			Jaundice.TabIndex = 171;
			Jaundice.UseVisualStyleBackColor = true;
			Incubation.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			Incubation.AutoSize = true;
			Incubation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Incubation.Location = new System.Drawing.Point(130, 57);
			Incubation.Name = "Incubation";
			Incubation.Size = new System.Drawing.Size(12, 11);
			Incubation.TabIndex = 165;
			Incubation.UseVisualStyleBackColor = true;
			laborNormal.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			laborNormal.AutoSize = true;
			laborNormal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			laborNormal.Location = new System.Drawing.Point(130, 7);
			laborNormal.Name = "laborNormal";
			laborNormal.Size = new System.Drawing.Size(12, 11);
			laborNormal.TabIndex = 163;
			laborNormal.UseVisualStyleBackColor = true;
			laborCS.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			laborCS.AutoSize = true;
			laborCS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			laborCS.Location = new System.Drawing.Point(231, 8);
			laborCS.Name = "laborCS";
			laborCS.Size = new System.Drawing.Size(12, 11);
			laborCS.TabIndex = 162;
			laborCS.UseVisualStyleBackColor = true;
			Asphyxia.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			Asphyxia.FlatAppearance.BorderColor = System.Drawing.Color.Black;
			Asphyxia.FlatAppearance.BorderSize = 3;
			Asphyxia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Asphyxia.Location = new System.Drawing.Point(130, 29);
			Asphyxia.Name = "Asphyxia";
			Asphyxia.Size = new System.Drawing.Size(15, 14);
			Asphyxia.TabIndex = 164;
			Asphyxia.UseVisualStyleBackColor = true;
			ClinicalFindings.Anchor = System.Windows.Forms.AnchorStyles.Top;
			ClinicalFindings.Font = new System.Drawing.Font("Arial", 9.75f);
			ClinicalFindings.Location = new System.Drawing.Point(488, 258);
			ClinicalFindings.Multiline = true;
			ClinicalFindings.Name = "ClinicalFindings";
			ClinicalFindings.RightToLeft = System.Windows.Forms.RightToLeft.No;
			ClinicalFindings.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			ClinicalFindings.Size = new System.Drawing.Size(275, 119);
			ClinicalFindings.TabIndex = 185;
			GMFCSLevel.Anchor = System.Windows.Forms.AnchorStyles.Top;
			GMFCSLevel.Font = new System.Drawing.Font("Arial", 9.75f);
			GMFCSLevel.Location = new System.Drawing.Point(597, 177);
			GMFCSLevel.Multiline = true;
			GMFCSLevel.Name = "GMFCSLevel";
			GMFCSLevel.RightToLeft = System.Windows.Forms.RightToLeft.No;
			GMFCSLevel.Size = new System.Drawing.Size(166, 22);
			GMFCSLevel.TabIndex = 183;
			Diagnosis.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Diagnosis.Font = new System.Drawing.Font("Arial", 9.75f);
			Diagnosis.Location = new System.Drawing.Point(488, 77);
			Diagnosis.Multiline = true;
			Diagnosis.Name = "Diagnosis";
			Diagnosis.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Diagnosis.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			Diagnosis.Size = new System.Drawing.Size(275, 79);
			Diagnosis.TabIndex = 181;
			age.Anchor = System.Windows.Forms.AnchorStyles.Top;
			age.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			age.Enabled = false;
			age.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			age.Location = new System.Drawing.Point(360, 10);
			age.Name = "age";
			age.RightToLeft = System.Windows.Forms.RightToLeft.No;
			age.Size = new System.Drawing.Size(58, 26);
			age.TabIndex = 173;
			age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			filenum.Anchor = System.Windows.Forms.AnchorStyles.Top;
			filenum.Enabled = false;
			filenum.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			filenum.ForeColor = System.Drawing.Color.Maroon;
			filenum.Location = new System.Drawing.Point(597, 9);
			filenum.Name = "filenum";
			filenum.ReadOnly = true;
			filenum.RightToLeft = System.Windows.Forms.RightToLeft.No;
			filenum.Size = new System.Drawing.Size(166, 26);
			filenum.TabIndex = 176;
			Sex.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Sex.Enabled = false;
			Sex.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			Sex.Location = new System.Drawing.Point(359, 54);
			Sex.Multiline = true;
			Sex.Name = "Sex";
			Sex.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Sex.Size = new System.Drawing.Size(91, 22);
			Sex.TabIndex = 174;
			PatientName.Anchor = System.Windows.Forms.AnchorStyles.Top;
			PatientName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			PatientName.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			PatientName.FormattingEnabled = true;
			PatientName.ItemHeight = 19;
			PatientName.Location = new System.Drawing.Point(95, 9);
			PatientName.Name = "PatientName";
			PatientName.RightToLeft = System.Windows.Forms.RightToLeft.No;
			PatientName.Size = new System.Drawing.Size(208, 27);
			PatientName.TabIndex = 175;
			PatientName.SelectedIndexChanged += new System.EventHandler(PatientName_SelectedIndexChanged);
			birthDateDateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.Top;
			birthDateDateTimePicker.CustomFormat = "dd/MM/yyyy";
			birthDateDateTimePicker.Enabled = false;
			birthDateDateTimePicker.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			birthDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			birthDateDateTimePicker.Location = new System.Drawing.Point(94, 52);
			birthDateDateTimePicker.Name = "birthDateDateTimePicker";
			birthDateDateTimePicker.RightToLeft = System.Windows.Forms.RightToLeft.No;
			birthDateDateTimePicker.RightToLeftLayout = true;
			birthDateDateTimePicker.Size = new System.Drawing.Size(206, 26);
			birthDateDateTimePicker.TabIndex = 172;
			birthDateDateTimePicker.ValueChanged += new System.EventHandler(birthDateDateTimePicker_ValueChanged);
			tabPage2.Controls.Add(Date);
			tabPage2.Controls.Add(dateTimePicker1);
			tabPage2.Controls.Add(Signature);
			tabPage2.Controls.Add(label51);
			tabPage2.Controls.Add(label50);
			tabPage2.Controls.Add(Deformities);
			tabPage2.Controls.Add(label39);
			tabPage2.Controls.Add(groupBox6);
			tabPage2.Controls.Add(groupBox5);
			tabPage2.Controls.Add(SpecialComments);
			tabPage2.Controls.Add(label33);
			tabPage2.Controls.Add(GaitAnalysis);
			tabPage2.Controls.Add(label40);
			tabPage2.Controls.Add(Balance);
			tabPage2.Controls.Add(label34);
			tabPage2.Controls.Add(MuscleTone);
			tabPage2.Controls.Add(label35);
			tabPage2.Location = new System.Drawing.Point(4, 25);
			tabPage2.Name = "tabPage2";
			tabPage2.Padding = new System.Windows.Forms.Padding(3);
			tabPage2.Size = new System.Drawing.Size(821, 584);
			tabPage2.TabIndex = 1;
			tabPage2.Text = "Page 2";
			tabPage2.UseVisualStyleBackColor = true;
			Date.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Date.CustomFormat = "dd/MM/yyyy";
			Date.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			Date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			Date.Location = new System.Drawing.Point(536, 543);
			Date.Name = "Date";
			Date.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Date.RightToLeftLayout = true;
			Date.Size = new System.Drawing.Size(233, 26);
			Date.TabIndex = 195;
			dateTimePicker1.Anchor = System.Windows.Forms.AnchorStyles.None;
			dateTimePicker1.CustomFormat = "dd/MM/yyyy";
			dateTimePicker1.Enabled = false;
			dateTimePicker1.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Location = new System.Drawing.Point(536, 543);
			dateTimePicker1.Name = "dateTimePicker1";
			dateTimePicker1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			dateTimePicker1.RightToLeftLayout = true;
			dateTimePicker1.Size = new System.Drawing.Size(206, 26);
			dateTimePicker1.TabIndex = 194;
			dateTimePicker1.Visible = false;
			Signature.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Signature.Font = new System.Drawing.Font("Arial", 9.75f);
			Signature.Location = new System.Drawing.Point(536, 511);
			Signature.Multiline = true;
			Signature.Name = "Signature";
			Signature.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Signature.Size = new System.Drawing.Size(233, 22);
			Signature.TabIndex = 193;
			Deformities.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Deformities.Font = new System.Drawing.Font("Arial", 9.75f);
			Deformities.Location = new System.Drawing.Point(459, 28);
			Deformities.Multiline = true;
			Deformities.Name = "Deformities";
			Deformities.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			Deformities.Size = new System.Drawing.Size(310, 50);
			Deformities.TabIndex = 190;
			groupBox6.Anchor = System.Windows.Forms.AnchorStyles.Top;
			groupBox6.BackColor = System.Drawing.Color.Transparent;
			groupBox6.Controls.Add(label26);
			groupBox6.Controls.Add(Cognition);
			groupBox6.Controls.Add(label27);
			groupBox6.Controls.Add(Mentalretardation);
			groupBox6.Controls.Add(panelAssociated);
			groupBox6.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			groupBox6.Location = new System.Drawing.Point(63, 161);
			groupBox6.Name = "groupBox6";
			groupBox6.Size = new System.Drawing.Size(304, 320);
			groupBox6.TabIndex = 188;
			groupBox6.TabStop = false;
			groupBox6.Text = "Associated Disabilities:";
			Cognition.Font = new System.Drawing.Font("Arial", 9.75f);
			Cognition.Location = new System.Drawing.Point(34, 145);
			Cognition.Multiline = true;
			Cognition.Name = "Cognition";
			Cognition.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			Cognition.Size = new System.Drawing.Size(233, 70);
			Cognition.TabIndex = 151;
			Mentalretardation.Font = new System.Drawing.Font("Arial", 9.75f);
			Mentalretardation.Location = new System.Drawing.Point(33, 239);
			Mentalretardation.Multiline = true;
			Mentalretardation.Name = "Mentalretardation";
			Mentalretardation.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			Mentalretardation.Size = new System.Drawing.Size(234, 68);
			Mentalretardation.TabIndex = 153;
			panelAssociated.Controls.Add(label22);
			panelAssociated.Controls.Add(label23);
			panelAssociated.Controls.Add(Epilepsy);
			panelAssociated.Controls.Add(label24);
			panelAssociated.Controls.Add(Visualdisability);
			panelAssociated.Controls.Add(label25);
			panelAssociated.Controls.Add(Hearingdisability);
			panelAssociated.Controls.Add(SpeechLangdisability);
			panelAssociated.Location = new System.Drawing.Point(33, 27);
			panelAssociated.Name = "panelAssociated";
			panelAssociated.Size = new System.Drawing.Size(215, 87);
			panelAssociated.TabIndex = 191;
			Epilepsy.AutoSize = true;
			Epilepsy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Epilepsy.Location = new System.Drawing.Point(180, 4);
			Epilepsy.Name = "Epilepsy";
			Epilepsy.Size = new System.Drawing.Size(12, 11);
			Epilepsy.TabIndex = 176;
			Epilepsy.UseVisualStyleBackColor = true;
			Epilepsy.CheckedChanged += new System.EventHandler(Epilepsy_CheckedChanged);
			Visualdisability.AutoSize = true;
			Visualdisability.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Visualdisability.Location = new System.Drawing.Point(180, 24);
			Visualdisability.Name = "Visualdisability";
			Visualdisability.Size = new System.Drawing.Size(12, 11);
			Visualdisability.TabIndex = 177;
			Visualdisability.UseVisualStyleBackColor = true;
			Visualdisability.CheckedChanged += new System.EventHandler(Visualdisability_CheckedChanged);
			Hearingdisability.AutoSize = true;
			Hearingdisability.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Hearingdisability.Location = new System.Drawing.Point(180, 44);
			Hearingdisability.Name = "Hearingdisability";
			Hearingdisability.Size = new System.Drawing.Size(12, 11);
			Hearingdisability.TabIndex = 178;
			Hearingdisability.UseVisualStyleBackColor = true;
			Hearingdisability.CheckedChanged += new System.EventHandler(Hearingdisability_CheckedChanged);
			SpeechLangdisability.AutoSize = true;
			SpeechLangdisability.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			SpeechLangdisability.Location = new System.Drawing.Point(180, 67);
			SpeechLangdisability.Name = "SpeechLangdisability";
			SpeechLangdisability.Size = new System.Drawing.Size(12, 11);
			SpeechLangdisability.TabIndex = 179;
			SpeechLangdisability.UseVisualStyleBackColor = true;
			SpeechLangdisability.CheckedChanged += new System.EventHandler(SpeechLangdisability_CheckedChanged);
			groupBox5.Anchor = System.Windows.Forms.AnchorStyles.Top;
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.Controls.Add(label31);
			groupBox5.Controls.Add(Tapping);
			groupBox5.Controls.Add(label32);
			groupBox5.Controls.Add(Orthotics);
			groupBox5.Controls.Add(panelNeeds);
			groupBox5.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			groupBox5.Location = new System.Drawing.Point(459, 84);
			groupBox5.Name = "groupBox5";
			groupBox5.Size = new System.Drawing.Size(310, 327);
			groupBox5.TabIndex = 187;
			groupBox5.TabStop = false;
			groupBox5.Text = "Needs:";
			Tapping.Font = new System.Drawing.Font("Arial", 9.75f);
			Tapping.Location = new System.Drawing.Point(44, 137);
			Tapping.Multiline = true;
			Tapping.Name = "Tapping";
			Tapping.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			Tapping.Size = new System.Drawing.Size(243, 75);
			Tapping.TabIndex = 142;
			Orthotics.Font = new System.Drawing.Font("Arial", 9.75f);
			Orthotics.Location = new System.Drawing.Point(42, 242);
			Orthotics.Multiline = true;
			Orthotics.Name = "Orthotics";
			Orthotics.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			Orthotics.Size = new System.Drawing.Size(245, 73);
			Orthotics.TabIndex = 144;
			panelNeeds.Controls.Add(label28);
			panelNeeds.Controls.Add(label29);
			panelNeeds.Controls.Add(Earlyintervention);
			panelNeeds.Controls.Add(label30);
			panelNeeds.Controls.Add(OT);
			panelNeeds.Controls.Add(Speechtherapy);
			panelNeeds.Location = new System.Drawing.Point(42, 32);
			panelNeeds.Name = "panelNeeds";
			panelNeeds.Size = new System.Drawing.Size(174, 73);
			panelNeeds.TabIndex = 176;
			Earlyintervention.AutoSize = true;
			Earlyintervention.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Earlyintervention.Location = new System.Drawing.Point(143, 30);
			Earlyintervention.Name = "Earlyintervention";
			Earlyintervention.Size = new System.Drawing.Size(12, 11);
			Earlyintervention.TabIndex = 174;
			Earlyintervention.UseVisualStyleBackColor = true;
			Earlyintervention.CheckedChanged += new System.EventHandler(Earlyintervention_CheckedChanged);
			OT.AutoSize = true;
			OT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			OT.Location = new System.Drawing.Point(143, 7);
			OT.Name = "OT";
			OT.Size = new System.Drawing.Size(12, 11);
			OT.TabIndex = 173;
			OT.UseVisualStyleBackColor = true;
			OT.CheckedChanged += new System.EventHandler(OT_CheckedChanged);
			Speechtherapy.AutoSize = true;
			Speechtherapy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Speechtherapy.Location = new System.Drawing.Point(143, 51);
			Speechtherapy.Name = "Speechtherapy";
			Speechtherapy.Size = new System.Drawing.Size(12, 11);
			Speechtherapy.TabIndex = 175;
			Speechtherapy.UseVisualStyleBackColor = true;
			Speechtherapy.CheckedChanged += new System.EventHandler(Speechtherapy_CheckedChanged);
			SpecialComments.Anchor = System.Windows.Forms.AnchorStyles.Top;
			SpecialComments.Font = new System.Drawing.Font("Arial", 9.75f);
			SpecialComments.Location = new System.Drawing.Point(459, 438);
			SpecialComments.Multiline = true;
			SpecialComments.Name = "SpecialComments";
			SpecialComments.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			SpecialComments.Size = new System.Drawing.Size(310, 56);
			SpecialComments.TabIndex = 186;
			GaitAnalysis.Anchor = System.Windows.Forms.AnchorStyles.Top;
			GaitAnalysis.Font = new System.Drawing.Font("Arial", 9.75f);
			GaitAnalysis.Location = new System.Drawing.Point(63, 508);
			GaitAnalysis.Multiline = true;
			GaitAnalysis.Name = "GaitAnalysis";
			GaitAnalysis.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			GaitAnalysis.Size = new System.Drawing.Size(331, 59);
			GaitAnalysis.TabIndex = 184;
			Balance.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Balance.Font = new System.Drawing.Font("Arial", 9.75f);
			Balance.Location = new System.Drawing.Point(63, 111);
			Balance.Multiline = true;
			Balance.Name = "Balance";
			Balance.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			Balance.Size = new System.Drawing.Size(303, 40);
			Balance.TabIndex = 182;
			MuscleTone.Anchor = System.Windows.Forms.AnchorStyles.Top;
			MuscleTone.Font = new System.Drawing.Font("Arial", 9.75f);
			MuscleTone.Location = new System.Drawing.Point(63, 28);
			MuscleTone.Multiline = true;
			MuscleTone.Name = "MuscleTone";
			MuscleTone.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			MuscleTone.Size = new System.Drawing.Size(304, 50);
			MuscleTone.TabIndex = 178;
			tabPage3.Controls.Add(Devicescomb);
			tabPage3.Controls.Add(label52);
			tabPage3.Controls.Add(Methods);
			tabPage3.Controls.Add(label36);
			tabPage3.Controls.Add(Goals);
			tabPage3.Controls.Add(label37);
			tabPage3.Location = new System.Drawing.Point(4, 25);
			tabPage3.Name = "tabPage3";
			tabPage3.Padding = new System.Windows.Forms.Padding(3);
			tabPage3.Size = new System.Drawing.Size(821, 584);
			tabPage3.TabIndex = 2;
			tabPage3.Text = "Page 3";
			tabPage3.UseVisualStyleBackColor = true;
			Devicescomb.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Devicescomb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			Devicescomb.Font = new System.Drawing.Font("Times New Roman", 12f, System.Drawing.FontStyle.Bold);
			Devicescomb.FormattingEnabled = true;
			Devicescomb.ItemHeight = 19;
			Devicescomb.Location = new System.Drawing.Point(173, 507);
			Devicescomb.Name = "Devicescomb";
			Devicescomb.RightToLeft = System.Windows.Forms.RightToLeft.No;
			Devicescomb.Size = new System.Drawing.Size(208, 27);
			Devicescomb.TabIndex = 359;
			Methods.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Methods.Font = new System.Drawing.Font("Arial", 9.75f);
			Methods.Location = new System.Drawing.Point(56, 307);
			Methods.Multiline = true;
			Methods.Name = "Methods";
			Methods.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			Methods.Size = new System.Drawing.Size(678, 153);
			Methods.TabIndex = 182;
			Goals.Anchor = System.Windows.Forms.AnchorStyles.Top;
			Goals.Font = new System.Drawing.Font("Arial", 9.75f);
			Goals.Location = new System.Drawing.Point(56, 80);
			Goals.Multiline = true;
			Goals.Name = "Goals";
			Goals.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			Goals.Size = new System.Drawing.Size(678, 159);
			Goals.TabIndex = 180;
			panelAssociated_copy.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			panelAssociated_copy.BackColor = System.Drawing.Color.White;
			panelAssociated_copy.Controls.Add(label46);
			panelAssociated_copy.Controls.Add(label47);
			panelAssociated_copy.Controls.Add(checkAss4);
			panelAssociated_copy.Controls.Add(checkAss1);
			panelAssociated_copy.Controls.Add(checkAss3);
			panelAssociated_copy.Controls.Add(label48);
			panelAssociated_copy.Controls.Add(label49);
			panelAssociated_copy.Controls.Add(checkAss2);
			panelAssociated_copy.Location = new System.Drawing.Point(661, -100);
			panelAssociated_copy.Name = "panelAssociated_copy";
			panelAssociated_copy.Size = new System.Drawing.Size(217, 109);
			panelAssociated_copy.TabIndex = 192;
			panelAssociated_copy.Visible = false;
			checkAss4.AutoSize = true;
			checkAss4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			checkAss4.Location = new System.Drawing.Point(190, 77);
			checkAss4.Name = "checkAss4";
			checkAss4.Size = new System.Drawing.Size(12, 11);
			checkAss4.TabIndex = 179;
			checkAss4.UseVisualStyleBackColor = true;
			checkAss1.AutoSize = true;
			checkAss1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			checkAss1.Location = new System.Drawing.Point(190, 14);
			checkAss1.Name = "checkAss1";
			checkAss1.Size = new System.Drawing.Size(12, 11);
			checkAss1.TabIndex = 176;
			checkAss1.UseVisualStyleBackColor = true;
			checkAss3.AutoSize = true;
			checkAss3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			checkAss3.Location = new System.Drawing.Point(190, 54);
			checkAss3.Name = "checkAss3";
			checkAss3.Size = new System.Drawing.Size(12, 11);
			checkAss3.TabIndex = 178;
			checkAss3.UseVisualStyleBackColor = true;
			checkAss2.AutoSize = true;
			checkAss2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			checkAss2.Location = new System.Drawing.Point(190, 34);
			checkAss2.Name = "checkAss2";
			checkAss2.Size = new System.Drawing.Size(12, 11);
			checkAss2.TabIndex = 177;
			checkAss2.UseVisualStyleBackColor = true;
			panelneed_copy.BackColor = System.Drawing.Color.White;
			panelneed_copy.Controls.Add(label43);
			panelneed_copy.Controls.Add(label44);
			panelneed_copy.Controls.Add(checkneed2);
			panelneed_copy.Controls.Add(label45);
			panelneed_copy.Controls.Add(checkneed1);
			panelneed_copy.Controls.Add(checkneed3);
			panelneed_copy.Location = new System.Drawing.Point(668, 303);
			panelneed_copy.Name = "panelneed_copy";
			panelneed_copy.Size = new System.Drawing.Size(195, 73);
			panelneed_copy.TabIndex = 187;
			panelneed_copy.Visible = false;
			checkneed2.AutoSize = true;
			checkneed2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			checkneed2.Location = new System.Drawing.Point(150, 29);
			checkneed2.Name = "checkneed2";
			checkneed2.Size = new System.Drawing.Size(12, 11);
			checkneed2.TabIndex = 174;
			checkneed2.UseVisualStyleBackColor = true;
			checkneed1.AutoSize = true;
			checkneed1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			checkneed1.Location = new System.Drawing.Point(150, 6);
			checkneed1.Name = "checkneed1";
			checkneed1.Size = new System.Drawing.Size(12, 11);
			checkneed1.TabIndex = 173;
			checkneed1.UseVisualStyleBackColor = true;
			checkneed3.AutoSize = true;
			checkneed3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			checkneed3.Location = new System.Drawing.Point(150, 50);
			checkneed3.Name = "checkneed3";
			checkneed3.Size = new System.Drawing.Size(12, 11);
			checkneed3.TabIndex = 175;
			checkneed3.UseVisualStyleBackColor = true;
			update.Anchor = System.Windows.Forms.AnchorStyles.None;
			update.Enabled = false;
			update.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			update.Location = new System.Drawing.Point(318, 719);
			update.Name = "update";
			update.Size = new System.Drawing.Size(109, 33);
			update.TabIndex = 184;
			update.Text = "Update";
			update.UseVisualStyleBackColor = true;
			update.Click += new System.EventHandler(update_Click);
			save.Anchor = System.Windows.Forms.AnchorStyles.None;
			save.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			save.Location = new System.Drawing.Point(348, 641);
			save.Name = "save";
			save.Size = new System.Drawing.Size(118, 34);
			save.TabIndex = 183;
			save.Text = "Save";
			save.UseVisualStyleBackColor = true;
			save.Click += new System.EventHandler(save_Click);
			groupBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.Controls.Add(this.label15);
			groupBox4.Location = new System.Drawing.Point(241, -3);
			groupBox4.Name = "groupBox4";
			groupBox4.Size = new System.Drawing.Size(424, 43);
			groupBox4.TabIndex = 185;
			groupBox4.TabStop = false;
			this.label15.AutoSize = true;
			this.label15.Font = new System.Drawing.Font("Arial", 15.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.label15.Location = new System.Drawing.Point(58, 13);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(321, 26);
			this.label15.TabIndex = 0;
			this.label15.Text = "Gross Motor Assessment Sheet ";
			Print.Anchor = System.Windows.Forms.AnchorStyles.None;
			Print.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			Print.Location = new System.Drawing.Point(2, 642);
			Print.Name = "Print";
			Print.Size = new System.Drawing.Size(109, 33);
			Print.TabIndex = 186;
			Print.Text = "Print Report";
			Print.UseVisualStyleBackColor = true;
			Print.Click += new System.EventHandler(Print_Click);
			sqlSelectCommand1.CommandText = "SELECT        PatientData.*\r\nFROM            PatientData";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "PatientData", new System.Data.Common.DataColumnMapping[53]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Titel", "Titel"),
					new System.Data.Common.DataColumnMapping("PName", "PName"),
					new System.Data.Common.DataColumnMapping("PAddress", "PAddress"),
					new System.Data.Common.DataColumnMapping("City", "City"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mob", "Mob"),
					new System.Data.Common.DataColumnMapping("Email", "Email"),
					new System.Data.Common.DataColumnMapping("BirthDate", "BirthDate"),
					new System.Data.Common.DataColumnMapping("Sex", "Sex"),
					new System.Data.Common.DataColumnMapping("Nationality", "Nationality"),
					new System.Data.Common.DataColumnMapping("Statue", "Statue"),
					new System.Data.Common.DataColumnMapping("company", "company"),
					new System.Data.Common.DataColumnMapping("cardNum", "cardNum"),
					new System.Data.Common.DataColumnMapping("LastVistDate", "LastVistDate"),
					new System.Data.Common.DataColumnMapping("Allergies", "Allergies"),
					new System.Data.Common.DataColumnMapping("CardiacDisease", "CardiacDisease"),
					new System.Data.Common.DataColumnMapping("KidneyDesease", "KidneyDesease"),
					new System.Data.Common.DataColumnMapping("Diabetes", "Diabetes"),
					new System.Data.Common.DataColumnMapping("RheumaticFever", "RheumaticFever"),
					new System.Data.Common.DataColumnMapping("Asthma", "Asthma"),
					new System.Data.Common.DataColumnMapping("BloodDyscrasias", "BloodDyscrasias"),
					new System.Data.Common.DataColumnMapping("Lactating", "Lactating"),
					new System.Data.Common.DataColumnMapping("Pregnant", "Pregnant"),
					new System.Data.Common.DataColumnMapping("HepatitisB", "HepatitisB"),
					new System.Data.Common.DataColumnMapping("Hepatitisc", "Hepatitisc"),
					new System.Data.Common.DataColumnMapping("HistoryOther", "HistoryOther"),
					new System.Data.Common.DataColumnMapping("Extraction", "Extraction"),
					new System.Data.Common.DataColumnMapping("PeriodontalTherpy", "PeriodontalTherpy"),
					new System.Data.Common.DataColumnMapping("Endodontics", "Endodontics"),
					new System.Data.Common.DataColumnMapping("Fixed", "Fixed"),
					new System.Data.Common.DataColumnMapping("Implant", "Implant"),
					new System.Data.Common.DataColumnMapping("Opretive", "Opretive"),
					new System.Data.Common.DataColumnMapping("Bleaching", "Bleaching"),
					new System.Data.Common.DataColumnMapping("PrviousHistoryOthers", "PrviousHistoryOthers"),
					new System.Data.Common.DataColumnMapping("DoctoreName", "DoctoreName"),
					new System.Data.Common.DataColumnMapping("NextVisit", "NextVisit"),
					new System.Data.Common.DataColumnMapping("Accept", "Accept"),
					new System.Data.Common.DataColumnMapping("Taqweem", "Taqweem"),
					new System.Data.Common.DataColumnMapping("Photo", "Photo"),
					new System.Data.Common.DataColumnMapping("BloodType", "BloodType"),
					new System.Data.Common.DataColumnMapping("Active", "Active"),
					new System.Data.Common.DataColumnMapping("FileNo", "FileNo"),
					new System.Data.Common.DataColumnMapping("Patient", "Patient"),
					new System.Data.Common.DataColumnMapping("Facebook", "Facebook"),
					new System.Data.Common.DataColumnMapping("Adv", "Adv"),
					new System.Data.Common.DataColumnMapping("FormerPatient", "FormerPatient"),
					new System.Data.Common.DataColumnMapping("Discount", "Discount"),
					new System.Data.Common.DataColumnMapping("Without", "Without"),
					new System.Data.Common.DataColumnMapping("Doctor", "Doctor"),
					new System.Data.Common.DataColumnMapping("DoctorId", "DoctorId"),
					new System.Data.Common.DataColumnMapping("nationalID", "nationalID"),
					new System.Data.Common.DataColumnMapping("Dariba", "Dariba")
				})
			});
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			sqlCommand1.CommandText = "SELECT        Pediatric.*\r\nFROM            Pediatric";
			sqlCommand1.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlDataAdapter2.DeleteCommand = sqlDeleteCommand;
			sqlDataAdapter2.InsertCommand = sqlInsertCommand;
			sqlDataAdapter2.SelectCommand = sqlCommand1;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Pediatric", new System.Data.Common.DataColumnMapping[82]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("PatientID", "PatientID"),
					new System.Data.Common.DataColumnMapping("Diagnosis", "Diagnosis"),
					new System.Data.Common.DataColumnMapping("GMFCS Level", "GMFCS Level"),
					new System.Data.Common.DataColumnMapping("Clinical Findings", "Clinical Findings"),
					new System.Data.Common.DataColumnMapping("laborNormal", "laborNormal"),
					new System.Data.Common.DataColumnMapping("laborCS", "laborCS"),
					new System.Data.Common.DataColumnMapping("Asphyxia", "Asphyxia"),
					new System.Data.Common.DataColumnMapping("Incubation", "Incubation"),
					new System.Data.Common.DataColumnMapping("Jaundice", "Jaundice"),
					new System.Data.Common.DataColumnMapping("Consanguinity", "Consanguinity"),
					new System.Data.Common.DataColumnMapping("Spastic", "Spastic"),
					new System.Data.Common.DataColumnMapping("Hypo", "Hypo"),
					new System.Data.Common.DataColumnMapping("Ataxic", "Ataxic"),
					new System.Data.Common.DataColumnMapping("Dyskinetic", "Dyskinetic"),
					new System.Data.Common.DataColumnMapping("Mixed", "Mixed"),
					new System.Data.Common.DataColumnMapping("HeadcontrolZ", "HeadcontrolZ"),
					new System.Data.Common.DataColumnMapping("HeadcontrolP", "HeadcontrolP"),
					new System.Data.Common.DataColumnMapping("HeadcontrolN", "HeadcontrolN"),
					new System.Data.Common.DataColumnMapping("Headcontrolnote", "Headcontrolnote"),
					new System.Data.Common.DataColumnMapping("RollZ", "RollZ"),
					new System.Data.Common.DataColumnMapping("RollP", "RollP"),
					new System.Data.Common.DataColumnMapping("RollN", "RollN"),
					new System.Data.Common.DataColumnMapping("Rollnote", "Rollnote"),
					new System.Data.Common.DataColumnMapping("GettositZ", "GettositZ"),
					new System.Data.Common.DataColumnMapping("GettositP", "GettositP"),
					new System.Data.Common.DataColumnMapping("GettositN", "GettositN"),
					new System.Data.Common.DataColumnMapping("Gettositnote", "Gettositnote"),
					new System.Data.Common.DataColumnMapping("SittingZ", "SittingZ"),
					new System.Data.Common.DataColumnMapping("SittingP", "SittingP"),
					new System.Data.Common.DataColumnMapping("SittingN", "SittingN"),
					new System.Data.Common.DataColumnMapping("Sittingnote", "Sittingnote"),
					new System.Data.Common.DataColumnMapping("SidesittingZ", "SidesittingZ"),
					new System.Data.Common.DataColumnMapping("SidesittingP", "SidesittingP"),
					new System.Data.Common.DataColumnMapping("SidesittingN", "SidesittingN"),
					new System.Data.Common.DataColumnMapping("Sidesittingnote", "Sidesittingnote"),
					new System.Data.Common.DataColumnMapping("CrawlingZ", "CrawlingZ"),
					new System.Data.Common.DataColumnMapping("CrawlingP", "CrawlingP"),
					new System.Data.Common.DataColumnMapping("CrawlingN", "CrawlingN"),
					new System.Data.Common.DataColumnMapping("Crawlingnote", "Crawlingnote"),
					new System.Data.Common.DataColumnMapping("CreepingZ", "CreepingZ"),
					new System.Data.Common.DataColumnMapping("CreepingP", "CreepingP"),
					new System.Data.Common.DataColumnMapping("CreepingN", "CreepingN"),
					new System.Data.Common.DataColumnMapping("Creepingnote", "Creepingnote"),
					new System.Data.Common.DataColumnMapping("KneelingZ", "KneelingZ"),
					new System.Data.Common.DataColumnMapping("KneelingP", "KneelingP"),
					new System.Data.Common.DataColumnMapping("KneelingN", "KneelingN"),
					new System.Data.Common.DataColumnMapping("Kneelingnote", "Kneelingnote"),
					new System.Data.Common.DataColumnMapping("HalfKneelingZ", "HalfKneelingZ"),
					new System.Data.Common.DataColumnMapping("HalfKneelingP", "HalfKneelingP"),
					new System.Data.Common.DataColumnMapping("HalfKneelingN", "HalfKneelingN"),
					new System.Data.Common.DataColumnMapping("HalfKneelingnote", "HalfKneelingnote"),
					new System.Data.Common.DataColumnMapping("GettostandZ", "GettostandZ"),
					new System.Data.Common.DataColumnMapping("GettostandP", "GettostandP"),
					new System.Data.Common.DataColumnMapping("GettostandN", "GettostandN"),
					new System.Data.Common.DataColumnMapping("Gettostandnote", "Gettostandnote"),
					new System.Data.Common.DataColumnMapping("StandingZ", "StandingZ"),
					new System.Data.Common.DataColumnMapping("StandingP", "StandingP"),
					new System.Data.Common.DataColumnMapping("StandinglN", "StandinglN"),
					new System.Data.Common.DataColumnMapping("Standingnote", "Standingnote"),
					new System.Data.Common.DataColumnMapping("WalkingZ", "WalkingZ"),
					new System.Data.Common.DataColumnMapping("WalkingP", "WalkingP"),
					new System.Data.Common.DataColumnMapping("WalkingN", "WalkingN"),
					new System.Data.Common.DataColumnMapping("Walkingnote", "Walkingnote"),
					new System.Data.Common.DataColumnMapping("Muscle Tone", "Muscle Tone"),
					new System.Data.Common.DataColumnMapping("Deformities", "Deformities"),
					new System.Data.Common.DataColumnMapping("Balance", "Balance"),
					new System.Data.Common.DataColumnMapping("O.T", "O.T"),
					new System.Data.Common.DataColumnMapping("Earlyintervention", "Earlyintervention"),
					new System.Data.Common.DataColumnMapping("Speechtherapy ", "Speechtherapy "),
					new System.Data.Common.DataColumnMapping("Tapping", "Tapping"),
					new System.Data.Common.DataColumnMapping("Orthotics", "Orthotics"),
					new System.Data.Common.DataColumnMapping("Epilepsy", "Epilepsy"),
					new System.Data.Common.DataColumnMapping("Visualdisability", "Visualdisability"),
					new System.Data.Common.DataColumnMapping("Hearingdisability", "Hearingdisability"),
					new System.Data.Common.DataColumnMapping("Speech&Langdisability", "Speech&Langdisability"),
					new System.Data.Common.DataColumnMapping("Cognition", "Cognition"),
					new System.Data.Common.DataColumnMapping("Mentalretardation", "Mentalretardation"),
					new System.Data.Common.DataColumnMapping("GaitAnalysis", "GaitAnalysis"),
					new System.Data.Common.DataColumnMapping("SpecialComments", "SpecialComments"),
					new System.Data.Common.DataColumnMapping("Goals", "Goals"),
					new System.Data.Common.DataColumnMapping("Methods", "Methods")
				})
			});
			sqlDataAdapter2.UpdateCommand = sqlUpdateCommand;
			sqlDeleteCommand.CommandText = resources.GetString("sqlDeleteCommand.CommandText");
			sqlDeleteCommand.Connection = sqlConnection2;
			sqlDeleteCommand.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[38]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_laborNormal", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "laborNormal", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_laborNormal", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "laborNormal", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_laborCS", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "laborCS", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_laborCS", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "laborCS", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Asphyxia", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Asphyxia", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Asphyxia", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Asphyxia", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Incubation", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Incubation", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Incubation", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Incubation", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Jaundice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Jaundice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Jaundice", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Jaundice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Consanguinity", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Consanguinity", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Consanguinity", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Consanguinity", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Spastic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Spastic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Spastic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Spastic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Hypo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Hypo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Hypo", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Hypo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Ataxic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Ataxic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Ataxic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Ataxic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Dyskinetic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Dyskinetic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Dyskinetic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Dyskinetic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mixed", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mixed", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mixed", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mixed", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@p3", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "O.T", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@p2", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "O.T", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Earlyintervention", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Earlyintervention", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Earlyintervention", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Earlyintervention", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Speechtherapy_", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Speechtherapy ", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Speechtherapy_", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Speechtherapy ", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Epilepsy", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Epilepsy", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Epilepsy", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Epilepsy", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Visualdisability", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Visualdisability", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Visualdisability", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Visualdisability", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Hearingdisability", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Hearingdisability", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Hearingdisability", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Hearingdisability", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@p6", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Speech&Langdisability", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@p5", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Speech&Langdisability", System.Data.DataRowVersion.Original, null)
			});
			sqlInsertCommand.CommandText = resources.GetString("sqlInsertCommand.CommandText");
			sqlInsertCommand.Connection = sqlConnection2;
			sqlInsertCommand.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[81]
			{
				new System.Data.SqlClient.SqlParameter("@PatientID", System.Data.SqlDbType.Int, 0, "PatientID"),
				new System.Data.SqlClient.SqlParameter("@Diagnosis", System.Data.SqlDbType.NVarChar, 0, "Diagnosis"),
				new System.Data.SqlClient.SqlParameter("@GMFCS_Level", System.Data.SqlDbType.NVarChar, 0, "GMFCS Level"),
				new System.Data.SqlClient.SqlParameter("@Clinical_Findings", System.Data.SqlDbType.NVarChar, 0, "Clinical Findings"),
				new System.Data.SqlClient.SqlParameter("@laborNormal", System.Data.SqlDbType.Bit, 0, "laborNormal"),
				new System.Data.SqlClient.SqlParameter("@laborCS", System.Data.SqlDbType.Bit, 0, "laborCS"),
				new System.Data.SqlClient.SqlParameter("@Asphyxia", System.Data.SqlDbType.Bit, 0, "Asphyxia"),
				new System.Data.SqlClient.SqlParameter("@Incubation", System.Data.SqlDbType.Bit, 0, "Incubation"),
				new System.Data.SqlClient.SqlParameter("@Jaundice", System.Data.SqlDbType.Bit, 0, "Jaundice"),
				new System.Data.SqlClient.SqlParameter("@Consanguinity", System.Data.SqlDbType.Bit, 0, "Consanguinity"),
				new System.Data.SqlClient.SqlParameter("@Spastic", System.Data.SqlDbType.Bit, 0, "Spastic"),
				new System.Data.SqlClient.SqlParameter("@Hypo", System.Data.SqlDbType.Bit, 0, "Hypo"),
				new System.Data.SqlClient.SqlParameter("@Ataxic", System.Data.SqlDbType.Bit, 0, "Ataxic"),
				new System.Data.SqlClient.SqlParameter("@Dyskinetic", System.Data.SqlDbType.Bit, 0, "Dyskinetic"),
				new System.Data.SqlClient.SqlParameter("@Mixed", System.Data.SqlDbType.Bit, 0, "Mixed"),
				new System.Data.SqlClient.SqlParameter("@HeadcontrolZ", System.Data.SqlDbType.NVarChar, 0, "HeadcontrolZ"),
				new System.Data.SqlClient.SqlParameter("@HeadcontrolP", System.Data.SqlDbType.NVarChar, 0, "HeadcontrolP"),
				new System.Data.SqlClient.SqlParameter("@HeadcontrolN", System.Data.SqlDbType.NVarChar, 0, "HeadcontrolN"),
				new System.Data.SqlClient.SqlParameter("@Headcontrolnote", System.Data.SqlDbType.NVarChar, 0, "Headcontrolnote"),
				new System.Data.SqlClient.SqlParameter("@RollZ", System.Data.SqlDbType.NVarChar, 0, "RollZ"),
				new System.Data.SqlClient.SqlParameter("@RollP", System.Data.SqlDbType.NVarChar, 0, "RollP"),
				new System.Data.SqlClient.SqlParameter("@RollN", System.Data.SqlDbType.NVarChar, 0, "RollN"),
				new System.Data.SqlClient.SqlParameter("@Rollnote", System.Data.SqlDbType.NVarChar, 0, "Rollnote"),
				new System.Data.SqlClient.SqlParameter("@GettositZ", System.Data.SqlDbType.NVarChar, 0, "GettositZ"),
				new System.Data.SqlClient.SqlParameter("@GettositP", System.Data.SqlDbType.NVarChar, 0, "GettositP"),
				new System.Data.SqlClient.SqlParameter("@GettositN", System.Data.SqlDbType.NVarChar, 0, "GettositN"),
				new System.Data.SqlClient.SqlParameter("@Gettositnote", System.Data.SqlDbType.NVarChar, 0, "Gettositnote"),
				new System.Data.SqlClient.SqlParameter("@SittingZ", System.Data.SqlDbType.NVarChar, 0, "SittingZ"),
				new System.Data.SqlClient.SqlParameter("@SittingP", System.Data.SqlDbType.NVarChar, 0, "SittingP"),
				new System.Data.SqlClient.SqlParameter("@SittingN", System.Data.SqlDbType.NVarChar, 0, "SittingN"),
				new System.Data.SqlClient.SqlParameter("@Sittingnote", System.Data.SqlDbType.NVarChar, 0, "Sittingnote"),
				new System.Data.SqlClient.SqlParameter("@SidesittingZ", System.Data.SqlDbType.NVarChar, 0, "SidesittingZ"),
				new System.Data.SqlClient.SqlParameter("@SidesittingP", System.Data.SqlDbType.NVarChar, 0, "SidesittingP"),
				new System.Data.SqlClient.SqlParameter("@SidesittingN", System.Data.SqlDbType.NVarChar, 0, "SidesittingN"),
				new System.Data.SqlClient.SqlParameter("@Sidesittingnote", System.Data.SqlDbType.NVarChar, 0, "Sidesittingnote"),
				new System.Data.SqlClient.SqlParameter("@CrawlingZ", System.Data.SqlDbType.NVarChar, 0, "CrawlingZ"),
				new System.Data.SqlClient.SqlParameter("@CrawlingP", System.Data.SqlDbType.NVarChar, 0, "CrawlingP"),
				new System.Data.SqlClient.SqlParameter("@CrawlingN", System.Data.SqlDbType.NVarChar, 0, "CrawlingN"),
				new System.Data.SqlClient.SqlParameter("@Crawlingnote", System.Data.SqlDbType.NVarChar, 0, "Crawlingnote"),
				new System.Data.SqlClient.SqlParameter("@CreepingZ", System.Data.SqlDbType.NVarChar, 0, "CreepingZ"),
				new System.Data.SqlClient.SqlParameter("@CreepingP", System.Data.SqlDbType.NVarChar, 0, "CreepingP"),
				new System.Data.SqlClient.SqlParameter("@CreepingN", System.Data.SqlDbType.NVarChar, 0, "CreepingN"),
				new System.Data.SqlClient.SqlParameter("@Creepingnote", System.Data.SqlDbType.NVarChar, 0, "Creepingnote"),
				new System.Data.SqlClient.SqlParameter("@KneelingZ", System.Data.SqlDbType.NVarChar, 0, "KneelingZ"),
				new System.Data.SqlClient.SqlParameter("@KneelingP", System.Data.SqlDbType.NVarChar, 0, "KneelingP"),
				new System.Data.SqlClient.SqlParameter("@KneelingN", System.Data.SqlDbType.NVarChar, 0, "KneelingN"),
				new System.Data.SqlClient.SqlParameter("@Kneelingnote", System.Data.SqlDbType.NVarChar, 0, "Kneelingnote"),
				new System.Data.SqlClient.SqlParameter("@HalfKneelingZ", System.Data.SqlDbType.NVarChar, 0, "HalfKneelingZ"),
				new System.Data.SqlClient.SqlParameter("@HalfKneelingP", System.Data.SqlDbType.NVarChar, 0, "HalfKneelingP"),
				new System.Data.SqlClient.SqlParameter("@HalfKneelingN", System.Data.SqlDbType.NVarChar, 0, "HalfKneelingN"),
				new System.Data.SqlClient.SqlParameter("@HalfKneelingnote", System.Data.SqlDbType.NVarChar, 0, "HalfKneelingnote"),
				new System.Data.SqlClient.SqlParameter("@GettostandZ", System.Data.SqlDbType.NVarChar, 0, "GettostandZ"),
				new System.Data.SqlClient.SqlParameter("@GettostandP", System.Data.SqlDbType.NVarChar, 0, "GettostandP"),
				new System.Data.SqlClient.SqlParameter("@GettostandN", System.Data.SqlDbType.NVarChar, 0, "GettostandN"),
				new System.Data.SqlClient.SqlParameter("@Gettostandnote", System.Data.SqlDbType.NVarChar, 0, "Gettostandnote"),
				new System.Data.SqlClient.SqlParameter("@StandingZ", System.Data.SqlDbType.NVarChar, 0, "StandingZ"),
				new System.Data.SqlClient.SqlParameter("@StandingP", System.Data.SqlDbType.NVarChar, 0, "StandingP"),
				new System.Data.SqlClient.SqlParameter("@StandinglN", System.Data.SqlDbType.NVarChar, 0, "StandinglN"),
				new System.Data.SqlClient.SqlParameter("@Standingnote", System.Data.SqlDbType.NVarChar, 0, "Standingnote"),
				new System.Data.SqlClient.SqlParameter("@WalkingZ", System.Data.SqlDbType.NVarChar, 0, "WalkingZ"),
				new System.Data.SqlClient.SqlParameter("@WalkingP", System.Data.SqlDbType.NVarChar, 0, "WalkingP"),
				new System.Data.SqlClient.SqlParameter("@WalkingN", System.Data.SqlDbType.NVarChar, 0, "WalkingN"),
				new System.Data.SqlClient.SqlParameter("@Walkingnote", System.Data.SqlDbType.NVarChar, 0, "Walkingnote"),
				new System.Data.SqlClient.SqlParameter("@Muscle_Tone", System.Data.SqlDbType.NVarChar, 0, "Muscle Tone"),
				new System.Data.SqlClient.SqlParameter("@Deformities", System.Data.SqlDbType.NVarChar, 0, "Deformities"),
				new System.Data.SqlClient.SqlParameter("@Balance", System.Data.SqlDbType.NVarChar, 0, "Balance"),
				new System.Data.SqlClient.SqlParameter("@p1", System.Data.SqlDbType.Bit, 0, "O.T"),
				new System.Data.SqlClient.SqlParameter("@Earlyintervention", System.Data.SqlDbType.Bit, 0, "Earlyintervention"),
				new System.Data.SqlClient.SqlParameter("@Speechtherapy_", System.Data.SqlDbType.Bit, 0, "Speechtherapy "),
				new System.Data.SqlClient.SqlParameter("@Tapping", System.Data.SqlDbType.NVarChar, 0, "Tapping"),
				new System.Data.SqlClient.SqlParameter("@Orthotics", System.Data.SqlDbType.NVarChar, 0, "Orthotics"),
				new System.Data.SqlClient.SqlParameter("@Epilepsy", System.Data.SqlDbType.Bit, 0, "Epilepsy"),
				new System.Data.SqlClient.SqlParameter("@Visualdisability", System.Data.SqlDbType.Bit, 0, "Visualdisability"),
				new System.Data.SqlClient.SqlParameter("@Hearingdisability", System.Data.SqlDbType.Bit, 0, "Hearingdisability"),
				new System.Data.SqlClient.SqlParameter("@p4", System.Data.SqlDbType.Bit, 0, "Speech&Langdisability"),
				new System.Data.SqlClient.SqlParameter("@Cognition", System.Data.SqlDbType.NVarChar, 0, "Cognition"),
				new System.Data.SqlClient.SqlParameter("@Mentalretardation", System.Data.SqlDbType.NVarChar, 0, "Mentalretardation"),
				new System.Data.SqlClient.SqlParameter("@GaitAnalysis", System.Data.SqlDbType.NVarChar, 0, "GaitAnalysis"),
				new System.Data.SqlClient.SqlParameter("@SpecialComments", System.Data.SqlDbType.NVarChar, 0, "SpecialComments"),
				new System.Data.SqlClient.SqlParameter("@Goals", System.Data.SqlDbType.NVarChar, 0, "Goals"),
				new System.Data.SqlClient.SqlParameter("@Methods", System.Data.SqlDbType.NVarChar, 0, "Methods")
			});
			sqlUpdateCommand.CommandText = resources.GetString("sqlUpdateCommand.CommandText");
			sqlUpdateCommand.Connection = sqlConnection2;
			sqlUpdateCommand.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[120]
			{
				new System.Data.SqlClient.SqlParameter("@PatientID", System.Data.SqlDbType.Int, 0, "PatientID"),
				new System.Data.SqlClient.SqlParameter("@Diagnosis", System.Data.SqlDbType.NVarChar, 0, "Diagnosis"),
				new System.Data.SqlClient.SqlParameter("@GMFCS_Level", System.Data.SqlDbType.NVarChar, 0, "GMFCS Level"),
				new System.Data.SqlClient.SqlParameter("@Clinical_Findings", System.Data.SqlDbType.NVarChar, 0, "Clinical Findings"),
				new System.Data.SqlClient.SqlParameter("@laborNormal", System.Data.SqlDbType.Bit, 0, "laborNormal"),
				new System.Data.SqlClient.SqlParameter("@laborCS", System.Data.SqlDbType.Bit, 0, "laborCS"),
				new System.Data.SqlClient.SqlParameter("@Asphyxia", System.Data.SqlDbType.Bit, 0, "Asphyxia"),
				new System.Data.SqlClient.SqlParameter("@Incubation", System.Data.SqlDbType.Bit, 0, "Incubation"),
				new System.Data.SqlClient.SqlParameter("@Jaundice", System.Data.SqlDbType.Bit, 0, "Jaundice"),
				new System.Data.SqlClient.SqlParameter("@Consanguinity", System.Data.SqlDbType.Bit, 0, "Consanguinity"),
				new System.Data.SqlClient.SqlParameter("@Spastic", System.Data.SqlDbType.Bit, 0, "Spastic"),
				new System.Data.SqlClient.SqlParameter("@Hypo", System.Data.SqlDbType.Bit, 0, "Hypo"),
				new System.Data.SqlClient.SqlParameter("@Ataxic", System.Data.SqlDbType.Bit, 0, "Ataxic"),
				new System.Data.SqlClient.SqlParameter("@Dyskinetic", System.Data.SqlDbType.Bit, 0, "Dyskinetic"),
				new System.Data.SqlClient.SqlParameter("@Mixed", System.Data.SqlDbType.Bit, 0, "Mixed"),
				new System.Data.SqlClient.SqlParameter("@HeadcontrolZ", System.Data.SqlDbType.NVarChar, 0, "HeadcontrolZ"),
				new System.Data.SqlClient.SqlParameter("@HeadcontrolP", System.Data.SqlDbType.NVarChar, 0, "HeadcontrolP"),
				new System.Data.SqlClient.SqlParameter("@HeadcontrolN", System.Data.SqlDbType.NVarChar, 0, "HeadcontrolN"),
				new System.Data.SqlClient.SqlParameter("@Headcontrolnote", System.Data.SqlDbType.NVarChar, 0, "Headcontrolnote"),
				new System.Data.SqlClient.SqlParameter("@RollZ", System.Data.SqlDbType.NVarChar, 0, "RollZ"),
				new System.Data.SqlClient.SqlParameter("@RollP", System.Data.SqlDbType.NVarChar, 0, "RollP"),
				new System.Data.SqlClient.SqlParameter("@RollN", System.Data.SqlDbType.NVarChar, 0, "RollN"),
				new System.Data.SqlClient.SqlParameter("@Rollnote", System.Data.SqlDbType.NVarChar, 0, "Rollnote"),
				new System.Data.SqlClient.SqlParameter("@GettositZ", System.Data.SqlDbType.NVarChar, 0, "GettositZ"),
				new System.Data.SqlClient.SqlParameter("@GettositP", System.Data.SqlDbType.NVarChar, 0, "GettositP"),
				new System.Data.SqlClient.SqlParameter("@GettositN", System.Data.SqlDbType.NVarChar, 0, "GettositN"),
				new System.Data.SqlClient.SqlParameter("@Gettositnote", System.Data.SqlDbType.NVarChar, 0, "Gettositnote"),
				new System.Data.SqlClient.SqlParameter("@SittingZ", System.Data.SqlDbType.NVarChar, 0, "SittingZ"),
				new System.Data.SqlClient.SqlParameter("@SittingP", System.Data.SqlDbType.NVarChar, 0, "SittingP"),
				new System.Data.SqlClient.SqlParameter("@SittingN", System.Data.SqlDbType.NVarChar, 0, "SittingN"),
				new System.Data.SqlClient.SqlParameter("@Sittingnote", System.Data.SqlDbType.NVarChar, 0, "Sittingnote"),
				new System.Data.SqlClient.SqlParameter("@SidesittingZ", System.Data.SqlDbType.NVarChar, 0, "SidesittingZ"),
				new System.Data.SqlClient.SqlParameter("@SidesittingP", System.Data.SqlDbType.NVarChar, 0, "SidesittingP"),
				new System.Data.SqlClient.SqlParameter("@SidesittingN", System.Data.SqlDbType.NVarChar, 0, "SidesittingN"),
				new System.Data.SqlClient.SqlParameter("@Sidesittingnote", System.Data.SqlDbType.NVarChar, 0, "Sidesittingnote"),
				new System.Data.SqlClient.SqlParameter("@CrawlingZ", System.Data.SqlDbType.NVarChar, 0, "CrawlingZ"),
				new System.Data.SqlClient.SqlParameter("@CrawlingP", System.Data.SqlDbType.NVarChar, 0, "CrawlingP"),
				new System.Data.SqlClient.SqlParameter("@CrawlingN", System.Data.SqlDbType.NVarChar, 0, "CrawlingN"),
				new System.Data.SqlClient.SqlParameter("@Crawlingnote", System.Data.SqlDbType.NVarChar, 0, "Crawlingnote"),
				new System.Data.SqlClient.SqlParameter("@CreepingZ", System.Data.SqlDbType.NVarChar, 0, "CreepingZ"),
				new System.Data.SqlClient.SqlParameter("@CreepingP", System.Data.SqlDbType.NVarChar, 0, "CreepingP"),
				new System.Data.SqlClient.SqlParameter("@CreepingN", System.Data.SqlDbType.NVarChar, 0, "CreepingN"),
				new System.Data.SqlClient.SqlParameter("@Creepingnote", System.Data.SqlDbType.NVarChar, 0, "Creepingnote"),
				new System.Data.SqlClient.SqlParameter("@KneelingZ", System.Data.SqlDbType.NVarChar, 0, "KneelingZ"),
				new System.Data.SqlClient.SqlParameter("@KneelingP", System.Data.SqlDbType.NVarChar, 0, "KneelingP"),
				new System.Data.SqlClient.SqlParameter("@KneelingN", System.Data.SqlDbType.NVarChar, 0, "KneelingN"),
				new System.Data.SqlClient.SqlParameter("@Kneelingnote", System.Data.SqlDbType.NVarChar, 0, "Kneelingnote"),
				new System.Data.SqlClient.SqlParameter("@HalfKneelingZ", System.Data.SqlDbType.NVarChar, 0, "HalfKneelingZ"),
				new System.Data.SqlClient.SqlParameter("@HalfKneelingP", System.Data.SqlDbType.NVarChar, 0, "HalfKneelingP"),
				new System.Data.SqlClient.SqlParameter("@HalfKneelingN", System.Data.SqlDbType.NVarChar, 0, "HalfKneelingN"),
				new System.Data.SqlClient.SqlParameter("@HalfKneelingnote", System.Data.SqlDbType.NVarChar, 0, "HalfKneelingnote"),
				new System.Data.SqlClient.SqlParameter("@GettostandZ", System.Data.SqlDbType.NVarChar, 0, "GettostandZ"),
				new System.Data.SqlClient.SqlParameter("@GettostandP", System.Data.SqlDbType.NVarChar, 0, "GettostandP"),
				new System.Data.SqlClient.SqlParameter("@GettostandN", System.Data.SqlDbType.NVarChar, 0, "GettostandN"),
				new System.Data.SqlClient.SqlParameter("@Gettostandnote", System.Data.SqlDbType.NVarChar, 0, "Gettostandnote"),
				new System.Data.SqlClient.SqlParameter("@StandingZ", System.Data.SqlDbType.NVarChar, 0, "StandingZ"),
				new System.Data.SqlClient.SqlParameter("@StandingP", System.Data.SqlDbType.NVarChar, 0, "StandingP"),
				new System.Data.SqlClient.SqlParameter("@StandinglN", System.Data.SqlDbType.NVarChar, 0, "StandinglN"),
				new System.Data.SqlClient.SqlParameter("@Standingnote", System.Data.SqlDbType.NVarChar, 0, "Standingnote"),
				new System.Data.SqlClient.SqlParameter("@WalkingZ", System.Data.SqlDbType.NVarChar, 0, "WalkingZ"),
				new System.Data.SqlClient.SqlParameter("@WalkingP", System.Data.SqlDbType.NVarChar, 0, "WalkingP"),
				new System.Data.SqlClient.SqlParameter("@WalkingN", System.Data.SqlDbType.NVarChar, 0, "WalkingN"),
				new System.Data.SqlClient.SqlParameter("@Walkingnote", System.Data.SqlDbType.NVarChar, 0, "Walkingnote"),
				new System.Data.SqlClient.SqlParameter("@Muscle_Tone", System.Data.SqlDbType.NVarChar, 0, "Muscle Tone"),
				new System.Data.SqlClient.SqlParameter("@Deformities", System.Data.SqlDbType.NVarChar, 0, "Deformities"),
				new System.Data.SqlClient.SqlParameter("@Balance", System.Data.SqlDbType.NVarChar, 0, "Balance"),
				new System.Data.SqlClient.SqlParameter("@p1", System.Data.SqlDbType.Bit, 0, "O.T"),
				new System.Data.SqlClient.SqlParameter("@Earlyintervention", System.Data.SqlDbType.Bit, 0, "Earlyintervention"),
				new System.Data.SqlClient.SqlParameter("@Speechtherapy_", System.Data.SqlDbType.Bit, 0, "Speechtherapy "),
				new System.Data.SqlClient.SqlParameter("@Tapping", System.Data.SqlDbType.NVarChar, 0, "Tapping"),
				new System.Data.SqlClient.SqlParameter("@Orthotics", System.Data.SqlDbType.NVarChar, 0, "Orthotics"),
				new System.Data.SqlClient.SqlParameter("@Epilepsy", System.Data.SqlDbType.Bit, 0, "Epilepsy"),
				new System.Data.SqlClient.SqlParameter("@Visualdisability", System.Data.SqlDbType.Bit, 0, "Visualdisability"),
				new System.Data.SqlClient.SqlParameter("@Hearingdisability", System.Data.SqlDbType.Bit, 0, "Hearingdisability"),
				new System.Data.SqlClient.SqlParameter("@p4", System.Data.SqlDbType.Bit, 0, "Speech&Langdisability"),
				new System.Data.SqlClient.SqlParameter("@Cognition", System.Data.SqlDbType.NVarChar, 0, "Cognition"),
				new System.Data.SqlClient.SqlParameter("@Mentalretardation", System.Data.SqlDbType.NVarChar, 0, "Mentalretardation"),
				new System.Data.SqlClient.SqlParameter("@GaitAnalysis", System.Data.SqlDbType.NVarChar, 0, "GaitAnalysis"),
				new System.Data.SqlClient.SqlParameter("@SpecialComments", System.Data.SqlDbType.NVarChar, 0, "SpecialComments"),
				new System.Data.SqlClient.SqlParameter("@Goals", System.Data.SqlDbType.NVarChar, 0, "Goals"),
				new System.Data.SqlClient.SqlParameter("@Methods", System.Data.SqlDbType.NVarChar, 0, "Methods"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Original_PatientID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "PatientID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_laborNormal", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "laborNormal", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_laborNormal", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "laborNormal", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_laborCS", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "laborCS", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_laborCS", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "laborCS", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Asphyxia", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Asphyxia", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Asphyxia", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Asphyxia", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Incubation", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Incubation", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Incubation", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Incubation", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Jaundice", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Jaundice", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Jaundice", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Jaundice", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Consanguinity", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Consanguinity", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Consanguinity", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Consanguinity", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Spastic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Spastic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Spastic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Spastic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Hypo", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Hypo", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Hypo", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Hypo", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Ataxic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Ataxic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Ataxic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Ataxic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Dyskinetic", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Dyskinetic", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Dyskinetic", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Dyskinetic", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mixed", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mixed", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mixed", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mixed", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@p3", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "O.T", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@p2", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "O.T", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Earlyintervention", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Earlyintervention", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Earlyintervention", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Earlyintervention", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Speechtherapy_", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Speechtherapy ", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Speechtherapy_", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Speechtherapy ", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Epilepsy", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Epilepsy", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Epilepsy", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Epilepsy", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Visualdisability", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Visualdisability", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Visualdisability", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Visualdisability", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Hearingdisability", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Hearingdisability", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Hearingdisability", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Hearingdisability", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@p6", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Speech&Langdisability", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@p5", System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Speech&Langdisability", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			button1.Anchor = System.Windows.Forms.AnchorStyles.None;
			button1.Font = new System.Drawing.Font("Tahoma", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button1.Location = new System.Drawing.Point(481, 641);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(118, 34);
			button1.TabIndex = 193;
			button1.Text = "Back";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			sqlDataAdapter9.DeleteCommand = sqlCommand19;
			sqlDataAdapter9.InsertCommand = sqlCommand26;
			sqlDataAdapter9.SelectCommand = sqlCommand27;
			sqlDataAdapter9.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "NaturalTherapy", new System.Data.Common.DataColumnMapping[3]
				{
					new System.Data.Common.DataColumnMapping("ID", "ID"),
					new System.Data.Common.DataColumnMapping("Name", "Name"),
					new System.Data.Common.DataColumnMapping("Notes", "Notes")
				})
			});
			sqlDataAdapter9.UpdateCommand = sqlCommand28;
			sqlCommand19.CommandText = "DELETE FROM [NaturalTherapy] WHERE (([ID] = @Original_ID))";
			sqlCommand19.Connection = sqlConnection9;
			sqlCommand19.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[1]
			{
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null)
			});
			sqlConnection9.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
			sqlConnection9.FireInfoMessageEventOnUserErrors = false;
			sqlCommand26.CommandText = "INSERT INTO [NaturalTherapy] ([Name], [Notes]) VALUES (@Name, @Notes);\r\nSELECT ID, Name, Notes FROM NaturalTherapy WHERE (ID = SCOPE_IDENTITY())";
			sqlCommand26.Connection = sqlConnection9;
			sqlCommand26.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[2]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Notes", System.Data.SqlDbType.NVarChar, 0, "Notes")
			});
			sqlCommand27.CommandText = "SELECT        NaturalTherapy.*\r\nFROM            NaturalTherapy";
			sqlCommand27.Connection = sqlConnection9;
			sqlCommand28.CommandText = "UPDATE [NaturalTherapy] SET [Name] = @Name, [Notes] = @Notes WHERE (([ID] = @Original_ID));\r\nSELECT ID, Name, Notes FROM NaturalTherapy WHERE (ID = @ID)";
			sqlCommand28.Connection = sqlConnection9;
			sqlCommand28.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[4]
			{
				new System.Data.SqlClient.SqlParameter("@Name", System.Data.SqlDbType.NVarChar, 0, "Name"),
				new System.Data.SqlClient.SqlParameter("@Notes", System.Data.SqlDbType.NVarChar, 0, "Notes"),
				new System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "ID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.Int, 4, "ID")
			});
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(893, 675);
			base.Controls.Add(button1);
			base.Controls.Add(panelAssociated_copy);
			base.Controls.Add(Print);
			base.Controls.Add(panelneed_copy);
			base.Controls.Add(update);
			base.Controls.Add(save);
			base.Controls.Add(groupBox4);
			base.Controls.Add(tabControl1);
			base.MaximizeBox = true;
			base.Name = "pediatricfrm";
			Text = "Pediatric Assessment  ";
			base.Load += new System.EventHandler(pediatricfrm_Load);
			tabControl1.ResumeLayout(false);
			tabPage1.ResumeLayout(false);
			tabPage1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox2.ResumeLayout(false);
			panelCP.ResumeLayout(false);
			panelCP.PerformLayout();
			groupBox1.ResumeLayout(false);
			panelNatalHistory.ResumeLayout(false);
			panelNatalHistory.PerformLayout();
			tabPage2.ResumeLayout(false);
			tabPage2.PerformLayout();
			groupBox6.ResumeLayout(false);
			groupBox6.PerformLayout();
			panelAssociated.ResumeLayout(false);
			panelAssociated.PerformLayout();
			groupBox5.ResumeLayout(false);
			groupBox5.PerformLayout();
			panelNeeds.ResumeLayout(false);
			panelNeeds.PerformLayout();
			tabPage3.ResumeLayout(false);
			tabPage3.PerformLayout();
			panelAssociated_copy.ResumeLayout(false);
			panelAssociated_copy.PerformLayout();
			panelneed_copy.ResumeLayout(false);
			panelneed_copy.PerformLayout();
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}

		public pediatricfrm(string ID)
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			PatientID = ID;
		}

		private void pediatricfrm_Load(object sender, EventArgs e)
		{
			PatientName.SelectedIndexChanged -= PatientName_SelectedIndexChanged;
			DataTable dataTable = codes.Search2("select * from PatientData order by PName");
			PatientName.DataSource = null;
			PatientName.DataSource = dataTable;
			PatientName.DisplayMember = dataTable.Columns["PName"].ToString();
			PatientName.ValueMember = dataTable.Columns[0].ToString();
			PatientName.SelectedIndex = -1;
			PatientName.SelectedIndexChanged += PatientName_SelectedIndexChanged;
			DataTable tableText = dc.GetTableText("select ID,Name from NaturalTherapy");
			Devicescomb.DataSource = null;
			Devicescomb.DataSource = tableText;
			Devicescomb.DisplayMember = tableText.Columns["Name"].ToString();
			Devicescomb.ValueMember = tableText.Columns["ID"].ToString();
			try
			{
				dataGridView1.Rows.Add("Head control", "", "", "", "");
				dataGridView1.Rows.Add("Roll", "", "", "", "");
				dataGridView1.Rows.Add("Get to sit", "", "", "", "");
				dataGridView1.Rows.Add("Sitting", "", "", "", "");
				dataGridView1.Rows.Add("Side sitting", "", "", "", "");
				dataGridView1.Rows.Add("Crawling", "", "", "", "");
				dataGridView1.Rows.Add("Creeping", "", "", "", "");
				dataGridView1.Rows.Add("Kneeling", "", "", "", "");
				dataGridView1.Rows.Add("Half Kneeling", "", "", "", "");
				dataGridView1.Rows.Add("Get to stand", "", "", "", "");
				dataGridView1.Rows.Add("Standing", "", "", "", "");
				dataGridView1.Rows.Add("Walking", "", "", "", "");
				if (PatientID != "")
				{
					PatientName.Text = PatientID;
					PatientName.Enabled = false;
				}
			}
			catch
			{
			}
		}

		private void PatientName_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (PatientName.SelectedValue == null)
			{
				return;
			}
			DataTable dataTable = codes.Search2("select * from PatientData where ID = '" + PatientName.SelectedValue.ToString() + "'");
			if (dataTable.Rows.Count > 0)
			{
				filenum.Text = dataTable.Rows[0]["FileNo"].ToString();
				Sex.Text = dataTable.Rows[0]["Sex"].ToString();
				try
				{
					if (dataTable.Rows[0]["BirthDate"].ToString() != "")
					{
						birthDateDateTimePicker.Value = Convert.ToDateTime(dataTable.Rows[0]["BirthDate"]);
						birthDateDateTimePicker_ValueChanged(sender, e);
					}
					else
					{
						age.Text = "";
					}
				}
				catch
				{
				}
			}
			try
			{
				DataTable dataTable2 = codes.Search2("select * from Pediatric where PatientID = '" + PatientName.SelectedValue.ToString() + "'");
				if (dataTable2.Rows.Count > 0)
				{
					Diagnosis.Text = dataTable2.Rows[0]["Diagnosis"].ToString();
					GMFCSLevel.Text = dataTable2.Rows[0]["GMFCS Level"].ToString();
					ClinicalFindings.Text = dataTable2.Rows[0]["Clinical Findings"].ToString();
					laborNormal.Checked = Convert.ToBoolean(dataTable2.Rows[0]["laborNormal"].ToString());
					laborCS.Checked = Convert.ToBoolean(dataTable2.Rows[0]["laborCS"].ToString());
					Asphyxia.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Asphyxia"].ToString());
					Incubation.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Incubation"].ToString());
					Jaundice.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Jaundice"].ToString());
					Consanguinity.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Consanguinity"].ToString());
					Spastic.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Spastic"].ToString());
					Hypo.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Hypo"].ToString());
					Ataxic.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Ataxic"].ToString());
					Dyskinetic.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Dyskinetic"].ToString());
					Mixed.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Mixed"].ToString());
					dataGridView1.Rows[0].Cells["Z"].Value = dataTable2.Rows[0]["HeadcontrolZ"].ToString();
					dataGridView1.Rows[0].Cells["P"].Value = dataTable2.Rows[0]["HeadcontrolP"].ToString();
					dataGridView1.Rows[0].Cells["N"].Value = dataTable2.Rows[0]["HeadcontrolN"].ToString();
					dataGridView1.Rows[0].Cells["Comments"].Value = dataTable2.Rows[0]["Headcontrolnote"].ToString();
					dataGridView1.Rows[1].Cells["Z"].Value = dataTable2.Rows[0]["RollZ"].ToString();
					dataGridView1.Rows[1].Cells["P"].Value = dataTable2.Rows[0]["RollP"].ToString();
					dataGridView1.Rows[1].Cells["N"].Value = dataTable2.Rows[0]["RollN"].ToString();
					dataGridView1.Rows[1].Cells["Comments"].Value = dataTable2.Rows[0]["Rollnote"].ToString();
					dataGridView1.Rows[2].Cells["Z"].Value = dataTable2.Rows[0]["GettositZ"].ToString();
					dataGridView1.Rows[2].Cells["P"].Value = dataTable2.Rows[0]["GettositP"].ToString();
					dataGridView1.Rows[2].Cells["N"].Value = dataTable2.Rows[0]["GettositN"].ToString();
					dataGridView1.Rows[2].Cells["Comments"].Value = dataTable2.Rows[0]["Gettositnote"].ToString();
					dataGridView1.Rows[3].Cells["Z"].Value = dataTable2.Rows[0]["SittingZ"].ToString();
					dataGridView1.Rows[3].Cells["P"].Value = dataTable2.Rows[0]["SittingP"].ToString();
					dataGridView1.Rows[3].Cells["N"].Value = dataTable2.Rows[0]["SittingN"].ToString();
					dataGridView1.Rows[3].Cells["Comments"].Value = dataTable2.Rows[0]["Sittingnote"].ToString();
					dataGridView1.Rows[4].Cells["Z"].Value = dataTable2.Rows[0]["SidesittingZ"].ToString();
					dataGridView1.Rows[4].Cells["N"].Value = dataTable2.Rows[0]["SidesittingP"].ToString();
					dataGridView1.Rows[4].Cells["P"].Value = dataTable2.Rows[0]["SidesittingN"].ToString();
					dataGridView1.Rows[4].Cells["Comments"].Value = dataTable2.Rows[0]["Sidesittingnote"].ToString();
					dataGridView1.Rows[5].Cells["Z"].Value = dataTable2.Rows[0]["CrawlingZ"].ToString();
					dataGridView1.Rows[5].Cells["P"].Value = dataTable2.Rows[0]["CrawlingP"].ToString();
					dataGridView1.Rows[5].Cells["N"].Value = dataTable2.Rows[0]["CrawlingN"].ToString();
					dataGridView1.Rows[5].Cells["Comments"].Value = dataTable2.Rows[0]["Crawlingnote"].ToString();
					dataGridView1.Rows[6].Cells["Z"].Value = dataTable2.Rows[0]["CreepingZ"].ToString();
					dataGridView1.Rows[6].Cells["P"].Value = dataTable2.Rows[0]["CreepingP"].ToString();
					dataGridView1.Rows[6].Cells["N"].Value = dataTable2.Rows[0]["CreepingN"].ToString();
					dataGridView1.Rows[6].Cells["Comments"].Value = dataTable2.Rows[0]["Creepingnote"].ToString();
					dataGridView1.Rows[7].Cells["Z"].Value = dataTable2.Rows[0]["KneelingZ"].ToString();
					dataGridView1.Rows[7].Cells["P"].Value = dataTable2.Rows[0]["KneelingP"].ToString();
					dataGridView1.Rows[7].Cells["N"].Value = dataTable2.Rows[0]["KneelingN"].ToString();
					dataGridView1.Rows[7].Cells["Comments"].Value = dataTable2.Rows[0]["Kneelingnote"].ToString();
					dataGridView1.Rows[8].Cells["Z"].Value = dataTable2.Rows[0]["HalfKneelingZ"].ToString();
					dataGridView1.Rows[8].Cells["P"].Value = dataTable2.Rows[0]["HalfKneelingP"].ToString();
					dataGridView1.Rows[8].Cells["N"].Value = dataTable2.Rows[0]["HalfKneelingN"].ToString();
					dataGridView1.Rows[8].Cells["Comments"].Value = dataTable2.Rows[0]["HalfKneelingnote"].ToString();
					dataGridView1.Rows[9].Cells["Z"].Value = dataTable2.Rows[0]["GettostandZ"].ToString();
					dataGridView1.Rows[9].Cells["P"].Value = dataTable2.Rows[0]["GettostandP"].ToString();
					dataGridView1.Rows[9].Cells["N"].Value = dataTable2.Rows[0]["GettostandN"].ToString();
					dataGridView1.Rows[9].Cells["Comments"].Value = dataTable2.Rows[0]["Gettostandnote"].ToString();
					dataGridView1.Rows[10].Cells["Z"].Value = dataTable2.Rows[0]["StandingZ"].ToString();
					dataGridView1.Rows[10].Cells["P"].Value = dataTable2.Rows[0]["StandingP"].ToString();
					dataGridView1.Rows[10].Cells["N"].Value = dataTable2.Rows[0]["StandinglN"].ToString();
					dataGridView1.Rows[10].Cells["Comments"].Value = dataTable2.Rows[0]["Standingnote"].ToString();
					dataGridView1.Rows[11].Cells["Z"].Value = dataTable2.Rows[0]["WalkingZ"].ToString();
					dataGridView1.Rows[11].Cells["P"].Value = dataTable2.Rows[0]["WalkingP"].ToString();
					dataGridView1.Rows[11].Cells["N"].Value = dataTable2.Rows[0]["WalkingN"].ToString();
					dataGridView1.Rows[11].Cells["Comments"].Value = dataTable2.Rows[0]["Walkingnote"].ToString();
					MuscleTone.Text = dataTable2.Rows[0]["Muscle Tone"].ToString();
					Deformities.Text = dataTable2.Rows[0]["Deformities"].ToString();
					Balance.Text = dataTable2.Rows[0]["Balance"].ToString();
					OT.Checked = Convert.ToBoolean(dataTable2.Rows[0]["O.T"].ToString());
					Earlyintervention.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Earlyintervention"].ToString());
					Speechtherapy.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Speechtherapy "].ToString());
					Tapping.Text = dataTable2.Rows[0]["Tapping"].ToString();
					Orthotics.Text = dataTable2.Rows[0]["Orthotics"].ToString();
					Epilepsy.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Epilepsy"].ToString());
					Visualdisability.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Visualdisability"].ToString());
					Hearingdisability.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Hearingdisability"].ToString());
					SpeechLangdisability.Checked = Convert.ToBoolean(dataTable2.Rows[0]["Speech&Langdisability"].ToString());
					Cognition.Text = dataTable2.Rows[0]["Cognition"].ToString();
					Mentalretardation.Text = dataTable2.Rows[0]["Mentalretardation"].ToString();
					GaitAnalysis.Text = dataTable2.Rows[0]["GaitAnalysis"].ToString();
					SpecialComments.Text = dataTable2.Rows[0]["SpecialComments"].ToString();
					Goals.Text = dataTable2.Rows[0]["Goals"].ToString();
					Methods.Text = dataTable2.Rows[0]["Methods"].ToString();
					Signature.Text = dataTable2.Rows[0]["Signature"].ToString();
					Devicescomb.SelectedValue = dataTable2.Rows[0]["Devices"].ToString();
					try
					{
						Date.Value = Convert.ToDateTime(dataTable2.Rows[0]["Date"]);
					}
					catch
					{
						Date.Value = DateTime.Now;
					}
					update.Enabled = true;
					save.Enabled = false;
				}
				else
				{
					update.Enabled = false;
					save.Enabled = true;
				}
			}
			catch
			{
			}
		}

		private void birthDateDateTimePicker_ValueChanged(object sender, EventArgs e)
		{
			try
			{
				DateTime.Today.Subtract(birthDateDateTimePicker.Value);
				int day = DateTime.Now.Day;
				int month = DateTime.Now.Month;
				int year = DateTime.Now.Year;
				int day2 = birthDateDateTimePicker.Value.Day;
				int month2 = birthDateDateTimePicker.Value.Month;
				int year2 = birthDateDateTimePicker.Value.Year;
				if (month * 100 + day >= month2 * 100 + day2)
				{
					age.Text = (year - year2).ToString();
				}
				else
				{
					age.Text = (year - year2 - 1).ToString();
				}
			}
			catch
			{
			}
		}

		private void save_Click(object sender, EventArgs e)
		{
			try
			{
				if (PatientName.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter patient name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المريض");
					}
					return;
				}
				codes.Add(string.Concat("insert into Pediatric (PatientID, Diagnosis, [GMFCS Level], [Clinical Findings], laborNormal, laborCS, Asphyxia, Incubation, Jaundice, Consanguinity, Spastic, Hypo, Ataxic, Dyskinetic, Mixed, HeadcontrolZ, HeadcontrolP, HeadcontrolN, Headcontrolnote, RollZ, RollP, RollN, Rollnote, GettositZ, GettositP, GettositN, Gettositnote, SittingZ, SittingP, SittingN, Sittingnote, SidesittingZ, SidesittingP, SidesittingN, Sidesittingnote, CrawlingZ, CrawlingP, CrawlingN, Crawlingnote, CreepingZ, CreepingP, CreepingN, Creepingnote, KneelingZ, KneelingP, KneelingN, Kneelingnote, HalfKneelingZ, HalfKneelingP, HalfKneelingN, HalfKneelingnote, GettostandZ, GettostandP, GettostandN, Gettostandnote, StandingZ, StandingP, StandinglN, Standingnote, WalkingZ, WalkingP, WalkingN, Walkingnote, [Muscle Tone], Deformities, Balance, [O.T], Earlyintervention, Speechtherapy , Tapping, Orthotics, Epilepsy, Visualdisability, Hearingdisability, [Speech&Langdisability], Cognition, Mentalretardation, GaitAnalysis, SpecialComments, Goals, Methods,Signature,Date,Devices)\r\nvalues ('", PatientName.SelectedValue, "','", Diagnosis.Text, "','", GMFCSLevel.Text, "','", ClinicalFindings.Text, "','", laborNormal.Checked, "','", laborCS.Checked, "','", Asphyxia.Checked, "','", Incubation.Checked, "','", Jaundice.Checked, "','", Consanguinity.Checked, "','", Spastic.Checked, "','", Hypo.Checked, "','", Ataxic.Checked, "','", Dyskinetic.Checked, "','", Mixed.Checked, "','", dataGridView1.Rows[0].Cells["Z"].Value.ToString(), "','", dataGridView1.Rows[0].Cells["P"].Value.ToString(), "','", dataGridView1.Rows[0].Cells["N"].Value.ToString(), "','", dataGridView1.Rows[0].Cells["Comments"].Value.ToString(), "','", dataGridView1.Rows[1].Cells["Z"].Value.ToString(), "','", dataGridView1.Rows[1].Cells["P"].Value.ToString(), "','", dataGridView1.Rows[1].Cells["N"].Value.ToString(), "','", dataGridView1.Rows[1].Cells["Comments"].Value.ToString(), "','", dataGridView1.Rows[2].Cells["Z"].Value.ToString(), "','", dataGridView1.Rows[2].Cells["P"].Value.ToString(), "','", dataGridView1.Rows[2].Cells["N"].Value.ToString(), "','", dataGridView1.Rows[2].Cells["Comments"].Value.ToString(), "','", dataGridView1.Rows[3].Cells["Z"].Value.ToString(), "','", dataGridView1.Rows[3].Cells["P"].Value.ToString(), "','", dataGridView1.Rows[3].Cells["N"].Value.ToString(), "','", dataGridView1.Rows[3].Cells["Comments"].Value.ToString(), "','", dataGridView1.Rows[4].Cells["Z"].Value.ToString(), "','", dataGridView1.Rows[4].Cells["P"].Value.ToString(), "','", dataGridView1.Rows[4].Cells["N"].Value.ToString(), "','", dataGridView1.Rows[4].Cells["Comments"].Value.ToString(), "','", dataGridView1.Rows[5].Cells["Z"].Value.ToString(), "','", dataGridView1.Rows[5].Cells["P"].Value.ToString(), "','", dataGridView1.Rows[5].Cells["N"].Value.ToString(), "','", dataGridView1.Rows[5].Cells["Comments"].Value.ToString(), "','", dataGridView1.Rows[6].Cells["Z"].Value.ToString(), "','", dataGridView1.Rows[6].Cells["P"].Value.ToString(), "','", dataGridView1.Rows[6].Cells["N"].Value.ToString(), "','", dataGridView1.Rows[6].Cells["Comments"].Value.ToString(), "','", dataGridView1.Rows[7].Cells["Z"].Value.ToString(), "','", dataGridView1.Rows[7].Cells["P"].Value.ToString(), "','", dataGridView1.Rows[7].Cells["N"].Value.ToString(), "','", dataGridView1.Rows[7].Cells["Comments"].Value.ToString(), "','", dataGridView1.Rows[8].Cells["Z"].Value.ToString(), "','", dataGridView1.Rows[8].Cells["P"].Value.ToString(), "','", dataGridView1.Rows[8].Cells["N"].Value.ToString(), "','", dataGridView1.Rows[8].Cells["Comments"].Value.ToString(), "','", dataGridView1.Rows[9].Cells["Z"].Value.ToString(), "','", dataGridView1.Rows[9].Cells["P"].Value.ToString(), "','", dataGridView1.Rows[9].Cells["N"].Value.ToString(), "','", dataGridView1.Rows[9].Cells["Comments"].Value.ToString(), "','", dataGridView1.Rows[10].Cells["Z"].Value.ToString(), "','", dataGridView1.Rows[10].Cells["P"].Value.ToString(), "','", dataGridView1.Rows[10].Cells["N"].Value.ToString(), "','", dataGridView1.Rows[10].Cells["Comments"].Value.ToString(), "','", dataGridView1.Rows[11].Cells["Z"].Value.ToString(), "','", dataGridView1.Rows[11].Cells["P"].Value.ToString(), "','", dataGridView1.Rows[11].Cells["N"].Value.ToString(), "','", dataGridView1.Rows[11].Cells["Comments"].Value.ToString(), "','", MuscleTone.Text, "','", Deformities.Text, "','", Balance.Text, "','", OT.Checked, "','", Earlyintervention.Checked, "','", Speechtherapy.Checked, "','", Tapping.Text, "','", Orthotics.Text, "','", Epilepsy.Checked, "','", Visualdisability.Checked, "','", Hearingdisability.Checked, "','", SpeechLangdisability.Checked, "','", Cognition.Text, "','", Mentalretardation.Text, "','", GaitAnalysis.Text, "','", SpecialComments.Text, "','", Goals.Text, "','", Methods.Text, "','", Signature.Text, "','", Date.Value, "','", Devicescomb.SelectedValue, "')"));
				Print_Click(sender, e);
				clear();
			}
			catch
			{
			}
		}

		private void clear()
		{
			try
			{
				dataGridView1.Rows.Clear();
				dataGridView1.Rows.Add("Head control", "", "", "", "");
				dataGridView1.Rows.Add("Roll", "", "", "", "");
				dataGridView1.Rows.Add("Get to sit", "", "", "", "");
				dataGridView1.Rows.Add("Sitting", "", "", "", "");
				dataGridView1.Rows.Add("Side sitting", "", "", "", "");
				dataGridView1.Rows.Add("Crawling", "", "", "", "");
				dataGridView1.Rows.Add("Creeping", "", "", "", "");
				dataGridView1.Rows.Add("Kneeling", "", "", "", "");
				dataGridView1.Rows.Add("Half Kneeling", "", "", "", "");
				dataGridView1.Rows.Add("Get to stand", "", "", "", "");
				dataGridView1.Rows.Add("Standing", "", "", "", "");
				dataGridView1.Rows.Add("Walking", "", "", "", "");
				Diagnosis.Text = "";
				GMFCSLevel.Text = "";
				ClinicalFindings.Text = "";
				laborNormal.Checked = false;
				laborCS.Checked = false;
				Asphyxia.Checked = false;
				Incubation.Checked = false;
				Jaundice.Checked = false;
				Consanguinity.Checked = false;
				Spastic.Checked = false;
				Hypo.Checked = false;
				Ataxic.Checked = false;
				Dyskinetic.Checked = false;
				Mixed.Checked = false;
				MuscleTone.Text = "";
				Deformities.Text = "";
				Balance.Text = "";
				OT.Checked = false;
				Earlyintervention.Checked = false;
				Speechtherapy.Checked = false;
				Tapping.Text = "";
				Orthotics.Text = "";
				Epilepsy.Checked = false;
				Visualdisability.Checked = false;
				Hearingdisability.Checked = false;
				SpeechLangdisability.Checked = false;
				Cognition.Text = "";
				Mentalretardation.Text = "";
				GaitAnalysis.Text = "";
				SpecialComments.Text = "";
				Goals.Text = "";
				Methods.Text = "";
				Signature.Text = "";
				Date.Value = DateTime.Now;
				update.Enabled = false;
				save.Enabled = true;
				filenum.Text = "";
				Sex.Text = "";
				birthDateDateTimePicker.Value = DateTime.Now;
			}
			catch
			{
			}
		}

		private void update_Click(object sender, EventArgs e)
		{
			try
			{
				if (PatientName.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter patient name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المريض");
					}
				}
				else
				{
					codes.Edit(string.Concat("update Pediatric set  Diagnosis='", Diagnosis.Text, "', [GMFCS Level]='", GMFCSLevel.Text, "', [Clinical Findings]='", ClinicalFindings.Text, "',laborNormal='", laborNormal.Checked, "',laborCS='", laborCS.Checked, "',Asphyxia='", Asphyxia.Checked, "',Incubation='", Incubation.Checked, "',Jaundice='", Jaundice.Checked, "', Consanguinity='", Consanguinity.Checked, "',Spastic='", Spastic.Checked, "', Hypo='", Hypo.Checked, "', Ataxic='", Ataxic.Checked, "', Dyskinetic='", Dyskinetic.Checked, "', Mixed='", Mixed.Checked, "', HeadcontrolZ='", dataGridView1.Rows[0].Cells["Z"].Value.ToString(), "', HeadcontrolP='", dataGridView1.Rows[0].Cells["P"].Value.ToString(), "', HeadcontrolN='", dataGridView1.Rows[0].Cells["N"].Value.ToString(), "', Headcontrolnote='", dataGridView1.Rows[0].Cells["Comments"].Value.ToString(), "', RollZ='", dataGridView1.Rows[1].Cells["Z"].Value.ToString(), "', RollP='", dataGridView1.Rows[1].Cells["P"].Value.ToString(), "', RollN='", dataGridView1.Rows[1].Cells["N"].Value.ToString(), "', Rollnote='", dataGridView1.Rows[1].Cells["Comments"].Value.ToString(), "', GettositZ='", dataGridView1.Rows[2].Cells["Z"].Value.ToString(), "', GettositP='", dataGridView1.Rows[2].Cells["P"].Value.ToString(), "', GettositN='", dataGridView1.Rows[2].Cells["N"].Value.ToString(), "', Gettositnote='", dataGridView1.Rows[2].Cells["Comments"].Value.ToString(), "', SittingZ='", dataGridView1.Rows[3].Cells["Z"].Value.ToString(), "', SittingP='", dataGridView1.Rows[3].Cells["P"].Value.ToString(), "', SittingN='", dataGridView1.Rows[3].Cells["N"].Value.ToString(), "', Sittingnote='", dataGridView1.Rows[3].Cells["Comments"].Value.ToString(), "',SidesittingZ='", dataGridView1.Rows[4].Cells["Z"].Value.ToString(), "', SidesittingP='", dataGridView1.Rows[4].Cells["P"].Value.ToString(), "', SidesittingN='", dataGridView1.Rows[4].Cells["N"].Value.ToString(), "', Sidesittingnote='", dataGridView1.Rows[4].Cells["Comments"].Value.ToString(), "', CrawlingZ='", dataGridView1.Rows[5].Cells["Z"].Value.ToString(), "', CrawlingP='", dataGridView1.Rows[5].Cells["P"].Value.ToString(), "', CrawlingN='", dataGridView1.Rows[5].Cells["N"].Value.ToString(), "', Crawlingnote='", dataGridView1.Rows[5].Cells["Comments"].Value.ToString(), "', CreepingZ='", dataGridView1.Rows[6].Cells["Z"].Value.ToString(), "', CreepingP='", dataGridView1.Rows[6].Cells["P"].Value.ToString(), "',CreepingN='", dataGridView1.Rows[6].Cells["N"].Value.ToString(), "', Creepingnote='", dataGridView1.Rows[6].Cells["Comments"].Value.ToString(), "', KneelingZ='", dataGridView1.Rows[7].Cells["Z"].Value.ToString(), "', KneelingP='", dataGridView1.Rows[7].Cells["P"].Value.ToString(), "', KneelingN='", dataGridView1.Rows[7].Cells["N"].Value.ToString(), "', Kneelingnote='", dataGridView1.Rows[7].Cells["Comments"].Value.ToString(), "', HalfKneelingZ='", dataGridView1.Rows[8].Cells["Z"].Value.ToString(), "', HalfKneelingP='", dataGridView1.Rows[8].Cells["P"].Value.ToString(), "', HalfKneelingN='", dataGridView1.Rows[8].Cells["N"].Value.ToString(), "', HalfKneelingnote='", dataGridView1.Rows[8].Cells["Comments"].Value.ToString(), "', GettostandZ='", dataGridView1.Rows[9].Cells["Z"].Value.ToString(), "', GettostandP='", dataGridView1.Rows[9].Cells["P"].Value.ToString(), "', GettostandN='", dataGridView1.Rows[9].Cells["N"].Value.ToString(), "', Gettostandnote='", dataGridView1.Rows[9].Cells["Comments"].Value.ToString(), "', StandingZ='", dataGridView1.Rows[10].Cells["Z"].Value.ToString(), "', StandingP='", dataGridView1.Rows[10].Cells["P"].Value.ToString(), "', StandinglN='", dataGridView1.Rows[10].Cells["N"].Value.ToString(), "', Standingnote='", dataGridView1.Rows[10].Cells["Comments"].Value.ToString(), "',WalkingZ='", dataGridView1.Rows[11].Cells["Z"].Value.ToString(), "', WalkingP='", dataGridView1.Rows[11].Cells["P"].Value.ToString(), "', WalkingN='", dataGridView1.Rows[11].Cells["N"].Value.ToString(), "', Walkingnote='", dataGridView1.Rows[11].Cells["Comments"].Value.ToString(), "',[Muscle Tone]='", MuscleTone.Text, "', Deformities='", Deformities.Text, "', Balance='", Balance.Text, "', [O.T]='", OT.Checked, "', Earlyintervention='", Earlyintervention.Checked, "', Speechtherapy ='", Speechtherapy.Checked, "', Tapping='", Tapping.Text, "', Orthotics='", Orthotics.Text, "', Epilepsy='", Epilepsy.Checked, "', Visualdisability='", Visualdisability.Checked, "', Hearingdisability='", Hearingdisability.Checked, "', [Speech&Langdisability]='", SpeechLangdisability.Checked, "', Cognition='", Cognition.Text, "', Mentalretardation='", Mentalretardation.Text, "', GaitAnalysis='", GaitAnalysis.Text, "', SpecialComments='", SpecialComments.Text, "', Goals='", Goals.Text, "', Methods='", Methods.Text, "',Signature='", Signature.Text, "',Date='", Date.Value, "',Devices='", Devicescomb.SelectedValue, "' where PatientID = '", PatientName.SelectedValue.ToString(), "'"));
				}
				clear();
				PatientName.SelectedIndex = -1;
			}
			catch
			{
			}
		}

		private void Print_Click(object sender, EventArgs e)
		{
			try
			{
				if (PatientName.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter patient name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم المريض");
					}
				}
				else
				{
					sqlConnection1.ConnectionString = codes.ConnectionStr;
					sqlConnection2.ConnectionString = codes.ConnectionStr;
					sqlConnection9.ConnectionString = codes.ConnectionStr;
					sqlDataAdapter1.SelectCommand.CommandType = CommandType.Text;
					sqlDataAdapter1.SelectCommand.CommandText = "select * from PatientData where ID = '" + PatientName.SelectedValue.ToString() + "'";
					sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
					sqlDataAdapter2.SelectCommand.CommandText = "select * from Pediatric where PatientID = '" + PatientName.SelectedValue.ToString() + "'";
					sqlDataAdapter9.SelectCommand.CommandType = CommandType.Text;
					sqlDataAdapter9.SelectCommand.CommandText = string.Concat("select * from NaturalTherapy where ID = '", Devicescomb.SelectedValue, "'");
					sqlDataAdapter1.Fill(dataSet11);
					sqlDataAdapter2.Fill(dataSet11);
					sqlDataAdapter9.Fill(dataSet11);
					pic();
					NaturalTherapyRPT naturalTherapyRPT = new NaturalTherapyRPT(dataSet11, "P");
					naturalTherapyRPT.ShowDialog();
				}
				panelAssociated_copy.Visible = false;
				panelneed_copy.Visible = false;
			}
			catch
			{
			}
		}

		private void pic()
		{
			panelAssociated_copy.Visible = true;
			panelneed_copy.Visible = true;
			int num = 0;
			int num2 = 0;
			num = panelNatalHistory.Size.Width;
			num2 = panelNatalHistory.Size.Height;
			Bitmap bitmap = new Bitmap(num, num2);
			panelNatalHistory.DrawToBitmap(bitmap, new Rectangle(0, 0, num, num2));
			byte[] array = ImageToByte(bitmap);
			num = panelCP.Size.Width;
			num2 = panelCP.Size.Height;
			Bitmap bitmap2 = new Bitmap(num, num2);
			panelCP.DrawToBitmap(bitmap2, new Rectangle(0, 0, num, num2));
			byte[] array2 = ImageToByte(bitmap2);
			num = panelneed_copy.Size.Width;
			num2 = panelneed_copy.Size.Height;
			Bitmap bitmap3 = new Bitmap(num, num2);
			panelneed_copy.DrawToBitmap(bitmap3, new Rectangle(0, 0, num, num2));
			byte[] array3 = ImageToByte(bitmap3);
			panelAssociated_copy.BackColor = Color.White;
			num = panelAssociated_copy.Size.Width;
			num2 = panelAssociated_copy.Size.Height;
			Bitmap bitmap4 = new Bitmap(num, num2);
			bitmap4.MakeTransparent();
			panelAssociated_copy.DrawToBitmap(bitmap4, new Rectangle(0, 0, num, num2));
			byte[] array4 = ImageToByte(bitmap4);
			((DataTable)(object)dataSet11.PediatricImages).Rows.Add(array, array2, array3, array4);
		}

		public static byte[] ImageToByte(Image img)
		{
			ImageConverter imageConverter = new ImageConverter();
			return (byte[])imageConverter.ConvertTo(img, typeof(byte[]));
		}

		private void Epilepsy_CheckedChanged(object sender, EventArgs e)
		{
			checkAss1.Checked = Epilepsy.Checked;
		}

		private void Visualdisability_CheckedChanged(object sender, EventArgs e)
		{
			checkAss2.Checked = Visualdisability.Checked;
		}

		private void Hearingdisability_CheckedChanged(object sender, EventArgs e)
		{
			checkAss3.Checked = Hearingdisability.Checked;
		}

		private void SpeechLangdisability_CheckedChanged(object sender, EventArgs e)
		{
			checkAss4.Checked = SpeechLangdisability.Checked;
		}

		private void OT_CheckedChanged(object sender, EventArgs e)
		{
			checkneed1.Checked = OT.Checked;
		}

		private void Earlyintervention_CheckedChanged(object sender, EventArgs e)
		{
			checkneed2.Checked = Earlyintervention.Checked;
		}

		private void Speechtherapy_CheckedChanged(object sender, EventArgs e)
		{
			checkneed3.Checked = Speechtherapy.Checked;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (tabPage1.Focus())
			{
				Diagnosis.Text = "";
				GMFCSLevel.Text = "";
				ClinicalFindings.Text = "";
				laborNormal.Checked = false;
				laborCS.Checked = false;
				Asphyxia.Checked = false;
				Incubation.Checked = false;
				Jaundice.Checked = false;
				Consanguinity.Checked = false;
				Spastic.Checked = false;
				Hypo.Checked = false;
				Ataxic.Checked = false;
				Dyskinetic.Checked = false;
				Mixed.Checked = false;
				PatientName.SelectedValue = -1;
				dataGridView1.Rows.Clear();
				dataGridView1.Rows.Add("Head control", "", "", "", "");
				dataGridView1.Rows.Add("Roll", "", "", "", "");
				dataGridView1.Rows.Add("Get to sit", "", "", "", "");
				dataGridView1.Rows.Add("Sitting", "", "", "", "");
				dataGridView1.Rows.Add("Side sitting", "", "", "", "");
				dataGridView1.Rows.Add("Crawling", "", "", "", "");
				dataGridView1.Rows.Add("Creeping", "", "", "", "");
				dataGridView1.Rows.Add("Kneeling", "", "", "", "");
				dataGridView1.Rows.Add("Half Kneeling", "", "", "", "");
				dataGridView1.Rows.Add("Get to stand", "", "", "", "");
				dataGridView1.Rows.Add("Standing", "", "", "", "");
				dataGridView1.Rows.Add("Walking", "", "", "", "");
				update.Enabled = false;
				save.Enabled = true;
			}
			else if (tabPage2.Focus())
			{
				MuscleTone.Text = "";
				Deformities.Text = "";
				Balance.Text = "";
				OT.Checked = false;
				Earlyintervention.Checked = false;
				Speechtherapy.Checked = false;
				Tapping.Text = "";
				Orthotics.Text = "";
				Epilepsy.Checked = false;
				Visualdisability.Checked = false;
				Hearingdisability.Checked = false;
				SpeechLangdisability.Checked = false;
				Cognition.Text = "";
				Mentalretardation.Text = "";
				GaitAnalysis.Text = "";
				SpecialComments.Text = "";
				Signature.Text = "";
				Date.Value = DateTime.Now;
			}
			else
			{
				Goals.Text = "";
				Methods.Text = "";
			}
		}
	}
}
