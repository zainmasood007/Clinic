namespace DentistClinic
{
	internal class UsersClass
	{
		public static int EmpId;

		public static bool ChangeServicePrice;

		public static bool AutoEsal;

		public static string BillPrinter;

		public static string EsalPrinterName;
	}
}
