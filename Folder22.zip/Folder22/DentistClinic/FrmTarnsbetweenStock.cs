using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using FloatTextBox;

namespace DentistClinic
{
	public class FrmTarnsbetweenStock : BaseForm
	{
		private IContainer components = null;

		private Label label1;

		private Label label2;

		private GroupBox groupBox1;

		private ComboBox FromStockCom;

		private Label label4;

		private FloatText ValueText;

		private DateTimePicker dateTimePicker1;

		private Label label3;

		private ComboBox ToStockCom;

		private Button button1;

		private TextBox textBox1;

		private Label label5;

		private FloatText StockValue;

		private Label label6;

		private dataClass Codes = new dataClass(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmTarnsbetweenStock));
			label1 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			groupBox1 = new System.Windows.Forms.GroupBox();
			StockValue = new FloatTextBox.FloatText();
			label6 = new System.Windows.Forms.Label();
			textBox1 = new System.Windows.Forms.TextBox();
			label5 = new System.Windows.Forms.Label();
			label4 = new System.Windows.Forms.Label();
			ValueText = new FloatTextBox.FloatText();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label3 = new System.Windows.Forms.Label();
			ToStockCom = new System.Windows.Forms.ComboBox();
			FromStockCom = new System.Windows.Forms.ComboBox();
			button1 = new System.Windows.Forms.Button();
			groupBox1.SuspendLayout();
			SuspendLayout();
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.Name = "label1";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Font = null;
			label2.Name = "label2";
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(StockValue);
			groupBox1.Controls.Add(label6);
			groupBox1.Controls.Add(textBox1);
			groupBox1.Controls.Add(label5);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(ValueText);
			groupBox1.Controls.Add(dateTimePicker1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(ToStockCom);
			groupBox1.Controls.Add(FromStockCom);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(label2);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			groupBox1.Enter += new System.EventHandler(groupBox1_Enter);
			StockValue.AccessibleDescription = null;
			StockValue.AccessibleName = null;
			resources.ApplyResources(StockValue, "StockValue");
			StockValue.BackgroundImage = null;
			StockValue.Font = null;
			StockValue.Name = "StockValue";
			StockValue.ReadOnly = true;
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "label6");
			label6.Font = null;
			label6.Name = "label6";
			label6.Click += new System.EventHandler(label6_Click);
			textBox1.AccessibleDescription = null;
			textBox1.AccessibleName = null;
			resources.ApplyResources(textBox1, "textBox1");
			textBox1.BackgroundImage = null;
			textBox1.Font = null;
			textBox1.Name = "textBox1";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label5");
			label5.Font = null;
			label5.Name = "label5";
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Font = null;
			label4.Name = "label4";
			ValueText.AccessibleDescription = null;
			ValueText.AccessibleName = null;
			resources.ApplyResources(ValueText, "ValueText");
			ValueText.BackgroundImage = null;
			ValueText.Font = null;
			ValueText.Name = "ValueText";
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.Font = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Font = null;
			label3.Name = "label3";
			ToStockCom.AccessibleDescription = null;
			ToStockCom.AccessibleName = null;
			resources.ApplyResources(ToStockCom, "ToStockCom");
			ToStockCom.BackgroundImage = null;
			ToStockCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			ToStockCom.Font = null;
			ToStockCom.FormattingEnabled = true;
			ToStockCom.Name = "ToStockCom";
			FromStockCom.AccessibleDescription = null;
			FromStockCom.AccessibleName = null;
			resources.ApplyResources(FromStockCom, "FromStockCom");
			FromStockCom.BackgroundImage = null;
			FromStockCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			FromStockCom.Font = null;
			FromStockCom.FormattingEnabled = true;
			FromStockCom.Name = "FromStockCom";
			FromStockCom.SelectedIndexChanged += new System.EventHandler(FromStockCom_SelectedIndexChanged);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(button1);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FrmTarnsbetweenStock";
			base.Load += new System.EventHandler(FrmTarnsbetweenStock_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			ResumeLayout(false);
		}

		public FrmTarnsbetweenStock()
		{
			InitializeComponent();
		}

		private void FrmTarnsbetweenStock_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				FromStockCom.DataSource = null;
				FromStockCom.DataSource = dataTable;
				FromStockCom.DisplayMember = dataTable.Columns[1].ToString();
				FromStockCom.ValueMember = dataTable.Columns[0].ToString();
				FromStockCom.SelectedIndex = 0;
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				decimal num = 0m;
				decimal num2 = 0m;
				decimal num3 = Convert.ToDecimal(ValueText.Text);
				DataTable dataTable = Codes.Search2("SELECT  Value FROM Stock where Id=" + FromStockCom.SelectedValue.ToString());
				num = Convert.ToDecimal(dataTable.Rows[0][0].ToString());
				DataTable dataTable2 = Codes.Search2("SELECT  Value FROM Stock where Id=" + ToStockCom.SelectedValue.ToString());
				num2 = Convert.ToDecimal(dataTable2.Rows[0][0].ToString());
				if (num >= Convert.ToDecimal(ValueText.Text))
				{
					if (FromStockCom.Text == ToStockCom.Text)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Can not transfer to same treasury");
						}
						else
						{
							MessageBox.Show("لايمكن التحويل لنفس الخزينة");
						}
						return;
					}
					if (Convert.ToDecimal(ValueText.Text) == 0m)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Please enter the value of the transfer");
						}
						else
						{
							MessageBox.Show("من فضلك قم بادخال قيمة الترحيل");
						}
						return;
					}
					using (SqlConnection sqlConnection = new SqlConnection(Codes.ConnectionStr))
					{
						sqlConnection.Open();
						SqlCommand sqlCommand = sqlConnection.CreateCommand();
						SqlTransaction sqlTransaction = sqlConnection.BeginTransaction();
						sqlCommand.Connection = sqlConnection;
						sqlCommand.Transaction = sqlTransaction;
						try
						{
							sqlCommand.CommandText = "UPDATE   Stock SET   Value =" + (num - num3) + " where Id=" + FromStockCom.SelectedValue.ToString();
							sqlCommand.ExecuteNonQuery();
							sqlCommand.CommandText = "UPDATE   Stock SET   Value =" + (num2 + num3) + " where Id=" + ToStockCom.SelectedValue.ToString();
							sqlCommand.ExecuteNonQuery();
							string esalNo = Search2(sqlCommand, "INSERT INTO TransStock (FromStock, ToStock, Date, Value, UserId,notes)VALUES  ('" + FromStockCom.Text + "','" + ToStockCom.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + ValueText.Text + "','" + Main.userId + "','" + textBox1.Text + "');select @@Identity").Rows[0][0].ToString();
							sqlCommand.CommandText = "INSERT INTO StokeMove(Price, date, Type, bean, StockId)VALUES('" + ValueText.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','تحويل الى خزينة',' تحويل من خزينة " + FromStockCom.Text + " الى " + ToStockCom.Text + "','" + FromStockCom.SelectedValue.ToString() + "')";
							sqlCommand.ExecuteNonQuery();
							sqlCommand.CommandText = "INSERT INTO StokeMove(Price, date, Type, bean, StockId)VALUES('" + ValueText.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','تحويل من خزينة',' تحويل الى خزينة " + ToStockCom.Text + " من " + FromStockCom.Text + "','" + ToStockCom.SelectedValue.ToString() + "')";
							sqlCommand.ExecuteNonQuery();
							sqlTransaction.Commit();
							if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("Data Saved Successfully");
							}
							else
							{
								MessageBox.Show("تم حفظ البيانات بنجاح");
							}
							MethodsClass.UserMove("تحويل من خزينة لأخري");
							ValueText.Text = "0";
							textBox1.Text = "";
							FrmEsalStock frmEsalStock = new FrmEsalStock(esalNo);
							frmEsalStock.Show();
						}
						catch (Exception)
						{
							sqlTransaction.Rollback();
							if (Settings.Default.Language == "en-GB")
							{
								MessageBox.Show("Error Happend While Saving");
							}
							else
							{
								MessageBox.Show("حدث خطأ أثناء حفظ البيانات");
							}
						}
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("The value of the treasury to be transfered is less than the amount required to transfer");
				}
				else
				{
					MessageBox.Show("قيمة الخزينة المراد التحويل منها اقل من المبلغ المطلوب تحويلة");
				}
			}
			catch
			{
			}
		}

		private DataTable Search2(SqlCommand cmd, string Selectcmdmand)
		{
			DataTable dataTable = new DataTable();
			cmd.CommandType = CommandType.Text;
			cmd.CommandText = Selectcmdmand;
			SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(cmd);
			sqlDataAdapter.Fill(dataTable);
			return dataTable;
		}

		private void FromStockCom_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = Codes.Search2("SELECT     Stock.ID, Stock.Name, UserStock.Status,Stock.Value FROM  UserStock INNER JOIN Stock ON UserStock.StockId = Stock.ID where UserStock.Status='True' and UserId='" + Main.userId + "' and Stock.ID <> " + FromStockCom.SelectedValue);
				ToStockCom.DataSource = dataTable;
				ToStockCom.DisplayMember = dataTable.Columns[1].ToString();
				ToStockCom.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = Codes.Search2("SELECT  Stock.Value FROM  Stock where  Stock.ID = " + FromStockCom.SelectedValue);
				StockValue.Text = dataTable2.Rows[0][0].ToString();
			}
			catch
			{
			}
		}

		private void groupBox1_Enter(object sender, EventArgs e)
		{
		}

		private void label6_Click(object sender, EventArgs e)
		{
		}
	}
}
