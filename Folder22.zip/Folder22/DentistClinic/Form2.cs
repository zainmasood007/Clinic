using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Windows.Forms;
using DentistClinic.Properties;
using iptb;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;

namespace DentistClinic
{
	public class Form2 : BaseForm
	{
		private IContainer components = null;

		private Label lblServer;

		private Button btnRestore;

		private Label lblUsername;

		private Label label3;

		private TextBox txtUsername;

		private TextBox txtPassword;

		private ComboBox cmbDatabase;

		private ComboBox cmbServer;

		private Label lblPassword;

		private GroupBox groupBox1;

		private GroupBox groupBox2;

		private Button btnConnect;

		private Button btnCreate;

		private OpenFileDialog openBackupDialog;

		private SaveFileDialog saveBackupDialog;

		private Button button1;

		private CheckBox checkBox1;

		private Panel panel1;

		private Label label1;

		private IPTextBox ipTextBox1;

		private CheckBox checkBox2;

		private GroupBox groupBox3;

		private Button button2;

		private Label label2;

		private TextBox textBox3;

		private IPTextBox ipTextBox2;

		private TextBox textBox1;

		private Label label4;

		private Label label5;

		private Label label6;

		private TextBox textBox2;

		private TextBox textBox4;

		private TextBox textBox5;

		private Button button3;

		private Button button4;

		private static Server srvSql;

		private string localServers = "";

		private string LoginMain = "";

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			lblServer = new System.Windows.Forms.Label();
			btnRestore = new System.Windows.Forms.Button();
			lblUsername = new System.Windows.Forms.Label();
			label3 = new System.Windows.Forms.Label();
			txtUsername = new System.Windows.Forms.TextBox();
			txtPassword = new System.Windows.Forms.TextBox();
			cmbDatabase = new System.Windows.Forms.ComboBox();
			cmbServer = new System.Windows.Forms.ComboBox();
			lblPassword = new System.Windows.Forms.Label();
			groupBox1 = new System.Windows.Forms.GroupBox();
			panel1 = new System.Windows.Forms.Panel();
			textBox5 = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			ipTextBox1 = new iptb.IPTextBox();
			btnConnect = new System.Windows.Forms.Button();
			groupBox2 = new System.Windows.Forms.GroupBox();
			button1 = new System.Windows.Forms.Button();
			btnCreate = new System.Windows.Forms.Button();
			openBackupDialog = new System.Windows.Forms.OpenFileDialog();
			saveBackupDialog = new System.Windows.Forms.SaveFileDialog();
			checkBox1 = new System.Windows.Forms.CheckBox();
			checkBox2 = new System.Windows.Forms.CheckBox();
			groupBox3 = new System.Windows.Forms.GroupBox();
			textBox4 = new System.Windows.Forms.TextBox();
			button2 = new System.Windows.Forms.Button();
			label2 = new System.Windows.Forms.Label();
			textBox3 = new System.Windows.Forms.TextBox();
			ipTextBox2 = new iptb.IPTextBox();
			textBox1 = new System.Windows.Forms.TextBox();
			label4 = new System.Windows.Forms.Label();
			label5 = new System.Windows.Forms.Label();
			label6 = new System.Windows.Forms.Label();
			textBox2 = new System.Windows.Forms.TextBox();
			button3 = new System.Windows.Forms.Button();
			button4 = new System.Windows.Forms.Button();
			groupBox1.SuspendLayout();
			panel1.SuspendLayout();
			groupBox2.SuspendLayout();
			groupBox3.SuspendLayout();
			SuspendLayout();
			lblServer.AutoSize = true;
			lblServer.Location = new System.Drawing.Point(28, 22);
			lblServer.Name = "lblServer";
			lblServer.Size = new System.Drawing.Size(41, 13);
			lblServer.TabIndex = 1;
			lblServer.Text = "Server:";
			btnRestore.Enabled = false;
			btnRestore.Location = new System.Drawing.Point(305, 50);
			btnRestore.Name = "btnRestore";
			btnRestore.Size = new System.Drawing.Size(10, 23);
			btnRestore.TabIndex = 6;
			btnRestore.Text = "إسترجاع نسخه أحتياطيه";
			btnRestore.UseVisualStyleBackColor = true;
			btnRestore.Visible = false;
			btnRestore.Click += new System.EventHandler(btnRestore_Click);
			lblUsername.AutoSize = true;
			lblUsername.Location = new System.Drawing.Point(11, 49);
			lblUsername.Name = "lblUsername";
			lblUsername.Size = new System.Drawing.Size(58, 13);
			lblUsername.TabIndex = 3;
			lblUsername.Text = "Username:";
			label3.AutoSize = true;
			label3.Location = new System.Drawing.Point(49, 22);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(56, 13);
			label3.TabIndex = 4;
			label3.Text = "Database:";
			txtUsername.Location = new System.Drawing.Point(75, 46);
			txtUsername.Name = "txtUsername";
			txtUsername.Size = new System.Drawing.Size(186, 20);
			txtUsername.TabIndex = 1;
			txtPassword.Location = new System.Drawing.Point(75, 73);
			txtPassword.Name = "txtPassword";
			txtPassword.PasswordChar = '*';
			txtPassword.Size = new System.Drawing.Size(186, 20);
			txtPassword.TabIndex = 2;
			cmbDatabase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cmbDatabase.FormattingEnabled = true;
			cmbDatabase.Location = new System.Drawing.Point(111, 19);
			cmbDatabase.Name = "cmbDatabase";
			cmbDatabase.Size = new System.Drawing.Size(193, 21);
			cmbDatabase.TabIndex = 4;
			cmbDatabase.SelectionChangeCommitted += new System.EventHandler(cmbDatabase_SelectedIndexChanged);
			cmbDatabase.SelectedIndexChanged += new System.EventHandler(cmbDatabase_SelectedIndexChanged);
			cmbDatabase.TextChanged += new System.EventHandler(cmbDatabase_SelectedIndexChanged);
			cmbServer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cmbServer.FormattingEnabled = true;
			cmbServer.Location = new System.Drawing.Point(75, 19);
			cmbServer.Name = "cmbServer";
			cmbServer.Size = new System.Drawing.Size(186, 21);
			cmbServer.TabIndex = 0;
			lblPassword.AutoSize = true;
			lblPassword.Location = new System.Drawing.Point(13, 76);
			lblPassword.Name = "lblPassword";
			lblPassword.Size = new System.Drawing.Size(56, 13);
			lblPassword.TabIndex = 9;
			lblPassword.Text = "Password:";
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(panel1);
			groupBox1.Controls.Add(btnConnect);
			groupBox1.Controls.Add(txtPassword);
			groupBox1.Controls.Add(lblServer);
			groupBox1.Controls.Add(lblPassword);
			groupBox1.Controls.Add(lblUsername);
			groupBox1.Controls.Add(cmbServer);
			groupBox1.Controls.Add(txtUsername);
			groupBox1.Controls.Add(button4);
			groupBox1.Location = new System.Drawing.Point(12, 28);
			groupBox1.Name = "groupBox1";
			groupBox1.Size = new System.Drawing.Size(422, 137);
			groupBox1.TabIndex = 10;
			groupBox1.TabStop = false;
			groupBox1.Text = "server Settings";
			panel1.Controls.Add(textBox5);
			panel1.Controls.Add(label1);
			panel1.Controls.Add(ipTextBox1);
			panel1.Location = new System.Drawing.Point(75, 17);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(341, 24);
			panel1.TabIndex = 14;
			panel1.Visible = false;
			textBox5.Location = new System.Drawing.Point(213, 3);
			textBox5.Name = "textBox5";
			textBox5.Size = new System.Drawing.Size(125, 20);
			textBox5.TabIndex = 11;
			label1.AutoSize = true;
			label1.Location = new System.Drawing.Point(135, 6);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(83, 13);
			label1.TabIndex = 10;
			label1.Text = "\\SQLEXPRESS";
			ipTextBox1.Location = new System.Drawing.Point(3, 2);
			ipTextBox1.Name = "ipTextBox1";
			ipTextBox1.Size = new System.Drawing.Size(128, 18);
			ipTextBox1.TabIndex = 10;
			ipTextBox1.ToolTipText = "";
			btnConnect.Location = new System.Drawing.Point(163, 99);
			btnConnect.Name = "btnConnect";
			btnConnect.Size = new System.Drawing.Size(90, 32);
			btnConnect.TabIndex = 3;
			btnConnect.Text = "Connect";
			btnConnect.UseVisualStyleBackColor = true;
			btnConnect.Click += new System.EventHandler(btnConnect_Click);
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(button1);
			groupBox2.Controls.Add(btnCreate);
			groupBox2.Controls.Add(label3);
			groupBox2.Controls.Add(cmbDatabase);
			groupBox2.Controls.Add(btnRestore);
			groupBox2.Location = new System.Drawing.Point(12, 171);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(422, 84);
			groupBox2.TabIndex = 11;
			groupBox2.TabStop = false;
			groupBox2.Text = "database settings";
			button1.Enabled = false;
			button1.Location = new System.Drawing.Point(140, 50);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(139, 23);
			button1.TabIndex = 7;
			button1.Text = "تسجل الدخول";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			btnCreate.Enabled = false;
			btnCreate.Location = new System.Drawing.Point(16, 50);
			btnCreate.Name = "btnCreate";
			btnCreate.Size = new System.Drawing.Size(10, 23);
			btnCreate.TabIndex = 5;
			btnCreate.Text = "عمل نسخه أحتياطيه";
			btnCreate.UseVisualStyleBackColor = true;
			btnCreate.Visible = false;
			btnCreate.Click += new System.EventHandler(btnCreate_Click);
			openBackupDialog.FileName = "Backup.bak";
			openBackupDialog.Filter = "Backup File|*.bak";
			saveBackupDialog.FileName = "Backup.bak";
			saveBackupDialog.Filter = "Backup File|*.bak";
			checkBox1.AutoSize = true;
			checkBox1.BackColor = System.Drawing.Color.Transparent;
			checkBox1.Location = new System.Drawing.Point(313, 6);
			checkBox1.Name = "checkBox1";
			checkBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			checkBox1.Size = new System.Drawing.Size(110, 17);
			checkBox1.TabIndex = 13;
			checkBox1.Text = "اتصال باستخدام IP";
			checkBox1.UseVisualStyleBackColor = false;
			checkBox1.CheckedChanged += new System.EventHandler(checkBox1_CheckedChanged);
			checkBox2.AutoSize = true;
			checkBox2.BackColor = System.Drawing.Color.Transparent;
			checkBox2.Location = new System.Drawing.Point(68, 6);
			checkBox2.Name = "checkBox2";
			checkBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			checkBox2.Size = new System.Drawing.Size(140, 17);
			checkBox2.TabIndex = 14;
			checkBox2.Text = "اتصال باستخدام Cloud IP";
			checkBox2.UseVisualStyleBackColor = false;
			checkBox2.CheckedChanged += new System.EventHandler(checkBox2_CheckedChanged);
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.Controls.Add(textBox4);
			groupBox3.Controls.Add(button2);
			groupBox3.Controls.Add(label2);
			groupBox3.Controls.Add(textBox3);
			groupBox3.Controls.Add(ipTextBox2);
			groupBox3.Controls.Add(textBox1);
			groupBox3.Controls.Add(label4);
			groupBox3.Controls.Add(label5);
			groupBox3.Controls.Add(label6);
			groupBox3.Controls.Add(textBox2);
			groupBox3.Location = new System.Drawing.Point(14, 28);
			groupBox3.Name = "groupBox3";
			groupBox3.Size = new System.Drawing.Size(420, 237);
			groupBox3.TabIndex = 16;
			groupBox3.TabStop = false;
			groupBox3.Text = "server Settings";
			groupBox3.Visible = false;
			textBox4.Location = new System.Drawing.Point(198, 21);
			textBox4.Name = "textBox4";
			textBox4.Size = new System.Drawing.Size(213, 20);
			textBox4.TabIndex = 19;
			textBox4.Text = "\\SQLEXPRESS";
			button2.Location = new System.Drawing.Point(129, 133);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(161, 23);
			button2.TabIndex = 18;
			button2.Text = "Connect";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			label2.AutoSize = true;
			label2.Location = new System.Drawing.Point(6, 51);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(57, 13);
			label2.TabIndex = 17;
			label2.Text = "DataBase:";
			textBox3.Location = new System.Drawing.Point(70, 48);
			textBox3.Name = "textBox3";
			textBox3.Size = new System.Drawing.Size(186, 20);
			textBox3.TabIndex = 16;
			ipTextBox2.Location = new System.Drawing.Point(69, 21);
			ipTextBox2.Name = "ipTextBox2";
			ipTextBox2.Size = new System.Drawing.Size(133, 18);
			ipTextBox2.TabIndex = 15;
			ipTextBox2.ToolTipText = "";
			textBox1.Location = new System.Drawing.Point(70, 104);
			textBox1.Name = "textBox1";
			textBox1.PasswordChar = '*';
			textBox1.Size = new System.Drawing.Size(186, 20);
			textBox1.TabIndex = 3;
			label4.AutoSize = true;
			label4.Location = new System.Drawing.Point(23, 22);
			label4.Name = "label4";
			label4.Size = new System.Drawing.Size(41, 13);
			label4.TabIndex = 1;
			label4.Text = "Server:";
			label5.AutoSize = true;
			label5.Location = new System.Drawing.Point(8, 107);
			label5.Name = "label5";
			label5.Size = new System.Drawing.Size(56, 13);
			label5.TabIndex = 9;
			label5.Text = "Password:";
			label6.AutoSize = true;
			label6.Location = new System.Drawing.Point(6, 80);
			label6.Name = "label6";
			label6.Size = new System.Drawing.Size(58, 13);
			label6.TabIndex = 3;
			label6.Text = "Username:";
			textBox2.Location = new System.Drawing.Point(70, 77);
			textBox2.Name = "textBox2";
			textBox2.Size = new System.Drawing.Size(186, 20);
			textBox2.TabIndex = 2;
			button3.Location = new System.Drawing.Point(12, 269);
			button3.Name = "button3";
			button3.Size = new System.Drawing.Size(123, 32);
			button3.TabIndex = 17;
			button3.Text = "إغلاق بدون اتصال";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			button4.Location = new System.Drawing.Point(271, 16);
			button4.Name = "button4";
			button4.Size = new System.Drawing.Size(113, 28);
			button4.TabIndex = 15;
			button4.Text = "تحميل السيرفرات";
			button4.UseVisualStyleBackColor = true;
			button4.Click += new System.EventHandler(button4_Click);
			base.AcceptButton = btnConnect;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.WhiteSmoke;
			base.ClientSize = new System.Drawing.Size(446, 305);
			base.ControlBox = false;
			base.Controls.Add(button3);
			base.Controls.Add(checkBox2);
			base.Controls.Add(checkBox1);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox3);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Name = "Form2";
			Text = "الإتصال بقاعدة البيانات";
			base.Load += new System.EventHandler(Form2_Load);
			base.FormClosed += new System.Windows.Forms.FormClosedEventHandler(Form1_FormClosed);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox3.ResumeLayout(false);
			groupBox3.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		public Form2()
		{
			InitializeComponent();
		}

		public Form2(string Main)
		{
			InitializeComponent();
			LoginMain = Main;
		}

		private void Form2_Load(object sender, EventArgs e)
		{
			try
			{
				if (DentistClinic.Properties.Settings.Default.IpCheck)
				{
					checkBox1.Checked = true;
				}
				else
				{
					panel1.Visible = false;
					cmbServer.Visible = true;
				}
				if (!Splash.Instance.Visible)
				{
					Splash.Instance.Visible = true;
				}
				if (DentistClinic.Properties.Settings.Default.ServerName == "server" || string.IsNullOrEmpty(DentistClinic.Properties.Settings.Default.ServerName))
				{
					if (Splash.Instance.Visible)
					{
						Splash.Instance.Visible = false;
					}
					LoadAllServers();
				}
				else if (Splash.Instance.Visible)
				{
					Splash.Instance.Visible = false;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void LoadAllServers()
		{
			try
			{
				cmbServer.Items.Clear();
				cmbDatabase.Items.Clear();
				DataTable dataTable = SmoApplication.EnumAvailableSqlServers(localOnly: false);
				bool flag = false;
				while (dataTable.Rows.Count == 0 && !flag)
				{
					DialogResult dialogResult = MessageBox.Show("لم يتم العثور علي أي سيرفرات .. هل تريد المحاولة مرة أخري؟", "إنتظر قليلا\u064b", MessageBoxButtons.RetryCancel, MessageBoxIcon.Asterisk);
					if (dialogResult == DialogResult.Retry)
					{
						dataTable = SmoApplication.EnumAvailableSqlServers(localOnly: false);
					}
					else
					{
						flag = true;
					}
				}
				if (dataTable.Rows.Count <= 0)
				{
					return;
				}
				foreach (DataRow row in dataTable.Rows)
				{
					if (DentistClinic.Properties.Settings.Default.IsSecondary)
					{
						if (Convert.ToBoolean(row[5].ToString()))
						{
							localServers += (localServers.Contains(row["Server"].ToString()) ? "" : (row["Server"].ToString() + "^"));
						}
						else
						{
							cmbServer.Items.Add(row["Name"]);
						}
					}
					else
					{
						cmbServer.Items.Add(row["Name"]);
					}
					try
					{
						cmbServer.SelectedItem = cmbServer.Items[0];
					}
					catch
					{
					}
				}
				localServers = localServers.TrimEnd('^');
			}
			catch
			{
				MessageBox.Show("حدث خطأ أثناء محاولة العثور علي السيرفرات");
			}
		}

		private void btnConnect_Click(object sender, EventArgs e)
		{
			try
			{
				cmbDatabase.Items.Clear();
				if ((txtPassword.Text != "") & (txtUsername.Text != ""))
				{
					ServerConnection serverConnection;
					if (!checkBox1.Checked)
					{
						if (cmbServer.SelectedItem != null && cmbServer.SelectedItem.ToString() != "")
						{
							serverConnection = new ServerConnection(cmbServer.SelectedItem.ToString());
							serverConnection.LoginSecure = false;
							serverConnection.Login = txtUsername.Text;
							serverConnection.Password = txtPassword.Text;
							srvSql = new Server(serverConnection);
							foreach (Database database2 in srvSql.Databases)
							{
								if (!DentistClinic.Properties.Settings.Default.IsSecondary || (!serverConnection.TrueName.Contains(Environment.MachineName) && !Enumerable.Contains<string>((IEnumerable<string>)GetIPAddress(), serverConnection.TrueName) && !serverConnection.TrueName.Contains("127.0.0.1") && !serverConnection.TrueName.Contains("\\\\.\\")))
								{
									cmbDatabase.Items.Add(database2.Name);
									continue;
								}
								MessageBox.Show("لا يمكن الاتصال بهذا السيرفر من خلال النسخه الفرعية");
								break;
							}
						}
						else
						{
							MessageBox.Show("Please select a server first", "Server Not Selected", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						}
						return;
					}
					if (ipTextBox1.Text == "")
					{
						MessageBox.Show("من فضلك قم بكتابة ip صحيح");
						return;
					}
					if (Enumerable.Contains<string>((IEnumerable<string>)GetIPAddress(), ipTextBox1.Text) && DentistClinic.Properties.Settings.Default.IsSecondary)
					{
						MessageBox.Show("لا يمكن الاتصال بهذا السيرفر من خلال النسخه الفرعية");
						cmbDatabase.Items.Clear();
						return;
					}
					if (ipTextBox1.Text == "127.0.0.1" && DentistClinic.Properties.Settings.Default.IsSecondary)
					{
						MessageBox.Show("لا يمكن الاتصال بهذا السيرفر من خلال النسخه الفرعية");
						cmbDatabase.Items.Clear();
						return;
					}
					serverConnection = new ServerConnection(ipTextBox1.Text + label1.Text + textBox5.Text);
					serverConnection.LoginSecure = false;
					serverConnection.Login = txtUsername.Text;
					serverConnection.Password = txtPassword.Text;
					srvSql = new Server(serverConnection);
					foreach (Database database3 in srvSql.Databases)
					{
						if (!DentistClinic.Properties.Settings.Default.IsSecondary || (!serverConnection.TrueName.Contains(Environment.MachineName) && !Enumerable.Contains<string>((IEnumerable<string>)GetIPAddress(), serverConnection.TrueName) && !serverConnection.TrueName.Contains("127.0.0.1") && !serverConnection.TrueName.Contains("\\\\.\\")))
						{
							cmbDatabase.Items.Add(database3.Name);
							continue;
						}
						MessageBox.Show("لا يمكن الاتصال بهذا السيرفر من خلال النسخه الفرعية");
						break;
					}
				}
				else
				{
					MessageBox.Show("قم بأدخال اسم المستخدم وكلمة المرور", "تنبيه");
				}
			}
			catch
			{
				MessageBox.Show("من فضلك تأكد من  اسم المستخدم وكلمة المرور", "تنبيه");
			}
		}

		private void btnCreate_Click(object sender, EventArgs e)
		{
			try
			{
				if (srvSql != null)
				{
					if (saveBackupDialog.ShowDialog() == DialogResult.OK)
					{
						Backup backup = new Backup();
						backup.BackupSetDescription = "ArchiveDataBase:" + DateTime.Now.ToShortDateString();
						backup.BackupSetName = "Archive";
						backup.Action = BackupActionType.Database;
						backup.Database = cmbDatabase.SelectedItem.ToString();
						BackupDeviceItem item = new BackupDeviceItem(saveBackupDialog.FileName, DeviceType.File);
						ServerConnection serverConnection = new ServerConnection(cmbServer.SelectedItem.ToString(), txtUsername.Text, txtPassword.Text);
						Server server = new Server(serverConnection);
						_ = server.Databases[cmbDatabase.SelectedItem.ToString()];
						backup.Initialize = true;
						backup.Checksum = true;
						backup.ContinueAfterError = true;
						backup.Devices.Add(item);
						backup.Incremental = false;
						backup.ExpirationDate = DateTime.Now.AddDays(3.0);
						backup.LogTruncation = BackupTruncateLogType.Truncate;
						backup.FormatMedia = false;
						backup.SqlBackup(srvSql);
						MessageBox.Show("Bakup of Database " + cmbDatabase.Text + " successfully created", "Server", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else
				{
					MessageBox.Show("A connection to a SQL server was not established.", "Not Connected to Server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
				MessageBox.Show("no connection");
			}
		}

		private void btnRestore_Click(object sender, EventArgs e)
		{
			try
			{
				if (srvSql != null)
				{
					if (openBackupDialog.ShowDialog() == DialogResult.OK)
					{
						Restore restore = new Restore();
						restore.Action = RestoreActionType.Database;
						restore.Database = cmbDatabase.SelectedItem.ToString();
						BackupDeviceItem item = new BackupDeviceItem(openBackupDialog.FileName, DeviceType.File);
						restore.Devices.Add(item);
						restore.ReplaceDatabase = true;
						restore.SqlRestore(srvSql);
						MessageBox.Show("Database " + cmbDatabase.Text + " succefully restored", "Server", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else
				{
					MessageBox.Show("A connection to a SQL server was not established.", "Not Connected to Server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (cmbDatabase.Text != "")
				{
					if (!checkBox1.Checked)
					{
						DentistClinic.Properties.Settings.Default.ServerName = cmbServer.SelectedItem.ToString();
						DentistClinic.Properties.Settings.Default.DataBaseName = cmbDatabase.SelectedItem.ToString();
						DentistClinic.Properties.Settings.Default.UserName = txtUsername.Text;
						DentistClinic.Properties.Settings.Default.Pass = txtPassword.Text;
						DentistClinic.Properties.Settings.Default.IpCheck = false;
						DentistClinic.Properties.Settings.Default.Save();
						if (LoginMain == "ChangeDataBase")
						{
							Main.RestoreDB = true;
							Application.Restart();
							Application.Exit();
						}
						else
						{
							base.Visible = false;
							fmlogin fmlogin2 = new fmlogin();
							fmlogin2.ShowDialog();
							Close();
						}
					}
					else
					{
						DentistClinic.Properties.Settings.Default.ServerName = ipTextBox1.Text + label1.Text + textBox5.Text;
						DentistClinic.Properties.Settings.Default.DataBaseName = cmbDatabase.SelectedItem.ToString();
						DentistClinic.Properties.Settings.Default.UserName = txtUsername.Text;
						DentistClinic.Properties.Settings.Default.Pass = txtPassword.Text;
						DentistClinic.Properties.Settings.Default.IpCheck = true;
						DentistClinic.Properties.Settings.Default.Save();
						if (LoginMain == "ChangeDataBase")
						{
							Application.Restart();
							return;
						}
						base.Visible = false;
						fmlogin fmlogin2 = new fmlogin();
						fmlogin2.ShowDialog();
						Close();
					}
				}
				else
				{
					MessageBox.Show("Please select a database first", "database Not Selected", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
			}
		}

		private void cmbDatabase_SelectedIndexChanged(object sender, EventArgs e)
		{
			button1.Enabled = true;
			btnCreate.Enabled = true;
			btnRestore.Enabled = true;
		}

		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
		}

		private string[] GetIPAddress()
		{
			string empty = string.Empty;
			empty = Dns.GetHostName();
			IPHostEntry hostEntry = Dns.GetHostEntry(empty);
			return Enumerable.ToArray<string>(Enumerable.Select<IPAddress, string>((IEnumerable<IPAddress>)hostEntry.AddressList, (Func<IPAddress, string>)((IPAddress ip) => ip.ToString())));
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox1.Checked)
			{
				panel1.Visible = true;
				cmbServer.Visible = false;
				checkBox2.Checked = false;
			}
			else
			{
				panel1.Visible = false;
				cmbServer.Visible = true;
			}
		}

		private void checkBox2_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox2.Checked)
			{
				groupBox3.Visible = true;
				groupBox1.Visible = false;
				groupBox2.Visible = false;
				checkBox1.Checked = false;
			}
			else
			{
				groupBox3.Visible = false;
				groupBox1.Visible = true;
				groupBox2.Visible = true;
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				DentistClinic.Properties.Settings.Default.ServerName = ipTextBox2.Text + textBox4.Text;
				DentistClinic.Properties.Settings.Default.DataBaseName = textBox3.Text;
				DentistClinic.Properties.Settings.Default.UserName = textBox2.Text;
				DentistClinic.Properties.Settings.Default.Pass = textBox1.Text;
				DentistClinic.Properties.Settings.Default.IpCheck = true;
				DentistClinic.Properties.Settings.Default.Save();
				base.Visible = false;
				fmlogin fmlogin2 = new fmlogin();
				fmlogin2.ShowDialog();
				Close();
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			LoadAllServers();
		}
	}
}
