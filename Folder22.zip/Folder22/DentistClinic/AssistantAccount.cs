using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace DentistClinic
{
	public class AssistantAccount : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox3;

		private DateTimePicker dateTimePicker1;

		private GroupBox groupBox2;

		private Button saveBtn;

		private GroupBox groupBox1;

		private TextBox totaltextBox;

		private TextBox proccestextBox;

		private TextBox percenttextBox;

		private TextBox salarytextBox;

		private GroupBox groupBox4;

		private DateTimePicker toTimePicker1;

		private DateTimePicker fromdateTimePicker1;

		private ComboBox doctorcomboBox;

		private GroupBox groupBox5;

		private Label label7;

		private GroupBox groupBox6;

		private DataGridView dataGridView1;

		private Label label69;

		private ComboBox comboBox7;

		private ClassDataBase dc;

		private GUI gui = new GUI();

		private dataClass codes;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			groupBox3 = new System.Windows.Forms.GroupBox();
			groupBox6 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			groupBox2 = new System.Windows.Forms.GroupBox();
			saveBtn = new System.Windows.Forms.Button();
			groupBox1 = new System.Windows.Forms.GroupBox();
			totaltextBox = new System.Windows.Forms.TextBox();
			proccestextBox = new System.Windows.Forms.TextBox();
			percenttextBox = new System.Windows.Forms.TextBox();
			salarytextBox = new System.Windows.Forms.TextBox();
			groupBox4 = new System.Windows.Forms.GroupBox();
			toTimePicker1 = new System.Windows.Forms.DateTimePicker();
			fromdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			groupBox5 = new System.Windows.Forms.GroupBox();
			this.label7 = new System.Windows.Forms.Label();
			label69 = new System.Windows.Forms.Label();
			comboBox7 = new System.Windows.Forms.ComboBox();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label4 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label6 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label7 = new System.Windows.Forms.Label();
			groupBox3.SuspendLayout();
			groupBox6.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox2.SuspendLayout();
			groupBox1.SuspendLayout();
			groupBox4.SuspendLayout();
			groupBox5.SuspendLayout();
			SuspendLayout();
			label.AutoSize = true;
			label.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label.Location = new System.Drawing.Point(572, 64);
			label.Name = "label5";
			label.Size = new System.Drawing.Size(74, 16);
			label.TabIndex = 43;
			label.Text = "اجمالي الخدمات";
			label2.AutoSize = true;
			label2.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label2.Location = new System.Drawing.Point(335, 65);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(43, 16);
			label2.TabIndex = 41;
			label2.Text = "الاجمالي";
			label3.AutoSize = true;
			label3.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label3.Location = new System.Drawing.Point(334, 31);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(35, 16);
			label3.TabIndex = 40;
			label3.Text = "النسبة";
			label4.AutoSize = true;
			label4.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label4.Location = new System.Drawing.Point(575, 28);
			label4.Name = "label4";
			label4.Size = new System.Drawing.Size(75, 16);
			label4.TabIndex = 39;
			label4.Text = "الراتب الاساسي";
			label5.AutoSize = true;
			label5.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label5.Location = new System.Drawing.Point(267, 58);
			label5.Name = "label1";
			label5.Size = new System.Drawing.Size(50, 16);
			label5.TabIndex = 38;
			label5.Text = "الي تاريخ";
			label6.AutoSize = true;
			label6.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label6.Location = new System.Drawing.Point(576, 58);
			label6.Name = "addressLabel";
			label6.Size = new System.Drawing.Size(48, 16);
			label6.TabIndex = 36;
			label6.Text = "من تاريخ";
			label7.AutoSize = true;
			label7.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label7.Location = new System.Drawing.Point(577, 25);
			label7.Name = "titelLabel";
			label7.Size = new System.Drawing.Size(61, 16);
			label7.TabIndex = 0;
			label7.Text = "اسم المساعد";
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.Controls.Add(groupBox6);
			groupBox3.Controls.Add(dateTimePicker1);
			groupBox3.Controls.Add(groupBox2);
			groupBox3.Controls.Add(groupBox1);
			groupBox3.Controls.Add(groupBox4);
			groupBox3.Location = new System.Drawing.Point(5, 10);
			groupBox3.Name = "groupBox3";
			groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox3.Size = new System.Drawing.Size(693, 468);
			groupBox3.TabIndex = 85;
			groupBox3.TabStop = false;
			groupBox6.BackColor = System.Drawing.Color.Transparent;
			groupBox6.Controls.Add(dataGridView1);
			groupBox6.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			groupBox6.Location = new System.Drawing.Point(6, 223);
			groupBox6.Name = "groupBox6";
			groupBox6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox6.Size = new System.Drawing.Size(681, 180);
			groupBox6.TabIndex = 90;
			groupBox6.TabStop = false;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
			dataGridView1.Location = new System.Drawing.Point(3, 18);
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.Size = new System.Drawing.Size(675, 159);
			dataGridView1.TabIndex = 0;
			dateTimePicker1.CustomFormat = "dd/MM/yyyy";
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Location = new System.Drawing.Point(11200, 32588);
			dateTimePicker1.Name = "dateTimePicker1";
			dateTimePicker1.Size = new System.Drawing.Size(251, 20);
			dateTimePicker1.TabIndex = 85;
			dateTimePicker1.Visible = false;
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(saveBtn);
			groupBox2.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			groupBox2.ForeColor = System.Drawing.Color.Black;
			groupBox2.Location = new System.Drawing.Point(156, 401);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(381, 56);
			groupBox2.TabIndex = 88;
			groupBox2.TabStop = false;
			saveBtn.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			saveBtn.Location = new System.Drawing.Point(117, 14);
			saveBtn.Name = "saveBtn";
			saveBtn.Size = new System.Drawing.Size(128, 37);
			saveBtn.TabIndex = 35;
			saveBtn.Text = "حفظ";
			saveBtn.UseVisualStyleBackColor = true;
			saveBtn.Click += new System.EventHandler(saveBtn_Click_1);
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(totaltextBox);
			groupBox1.Controls.Add(proccestextBox);
			groupBox1.Controls.Add(percenttextBox);
			groupBox1.Controls.Add(salarytextBox);
			groupBox1.Controls.Add(label);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(label4);
			groupBox1.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			groupBox1.ForeColor = System.Drawing.Color.Black;
			groupBox1.Location = new System.Drawing.Point(6, 122);
			groupBox1.Name = "groupBox1";
			groupBox1.Size = new System.Drawing.Size(679, 99);
			groupBox1.TabIndex = 87;
			groupBox1.TabStop = false;
			totaltextBox.Location = new System.Drawing.Point(185, 60);
			totaltextBox.Name = "totaltextBox";
			totaltextBox.Size = new System.Drawing.Size(146, 25);
			totaltextBox.TabIndex = 48;
			totaltextBox.Text = "0";
			totaltextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			totaltextBox.Leave += new System.EventHandler(totaltextBox_Leave_1);
			totaltextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(totaltextBox_KeyPress_1);
			proccestextBox.Location = new System.Drawing.Point(424, 58);
			proccestextBox.Name = "proccestextBox";
			proccestextBox.ReadOnly = true;
			proccestextBox.Size = new System.Drawing.Size(146, 25);
			proccestextBox.TabIndex = 47;
			proccestextBox.Text = "0";
			proccestextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			proccestextBox.TextChanged += new System.EventHandler(salarytextBox_TextChanged);
			percenttextBox.Location = new System.Drawing.Point(185, 24);
			percenttextBox.Name = "percenttextBox";
			percenttextBox.ReadOnly = true;
			percenttextBox.Size = new System.Drawing.Size(146, 25);
			percenttextBox.TabIndex = 45;
			percenttextBox.Text = "0";
			percenttextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			percenttextBox.TextChanged += new System.EventHandler(salarytextBox_TextChanged);
			salarytextBox.Location = new System.Drawing.Point(424, 24);
			salarytextBox.Name = "salarytextBox";
			salarytextBox.ReadOnly = true;
			salarytextBox.Size = new System.Drawing.Size(146, 25);
			salarytextBox.TabIndex = 44;
			salarytextBox.Text = "0";
			salarytextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			salarytextBox.TextChanged += new System.EventHandler(salarytextBox_TextChanged);
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.Controls.Add(label69);
			groupBox4.Controls.Add(comboBox7);
			groupBox4.Controls.Add(toTimePicker1);
			groupBox4.Controls.Add(label5);
			groupBox4.Controls.Add(fromdateTimePicker1);
			groupBox4.Controls.Add(label6);
			groupBox4.Controls.Add(label7);
			groupBox4.Controls.Add(doctorcomboBox);
			groupBox4.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			groupBox4.ForeColor = System.Drawing.Color.Black;
			groupBox4.Location = new System.Drawing.Point(6, 23);
			groupBox4.Name = "groupBox4";
			groupBox4.Size = new System.Drawing.Size(679, 95);
			groupBox4.TabIndex = 86;
			groupBox4.TabStop = false;
			toTimePicker1.CustomFormat = "dd/MM/yyyy";
			toTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			toTimePicker1.Location = new System.Drawing.Point(13, 52);
			toTimePicker1.Name = "toTimePicker1";
			toTimePicker1.RightToLeftLayout = true;
			toTimePicker1.Size = new System.Drawing.Size(251, 25);
			toTimePicker1.TabIndex = 39;
			toTimePicker1.ValueChanged += new System.EventHandler(doctorcomboBox_SelectedIndexChanged);
			fromdateTimePicker1.CustomFormat = "dd/MM/yyyy";
			fromdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			fromdateTimePicker1.Location = new System.Drawing.Point(322, 52);
			fromdateTimePicker1.Name = "fromdateTimePicker1";
			fromdateTimePicker1.RightToLeftLayout = true;
			fromdateTimePicker1.Size = new System.Drawing.Size(251, 25);
			fromdateTimePicker1.TabIndex = 37;
			fromdateTimePicker1.ValueChanged += new System.EventHandler(doctorcomboBox_SelectedIndexChanged);
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Location = new System.Drawing.Point(321, 21);
			doctorcomboBox.Name = "doctorcomboBox";
			doctorcomboBox.Size = new System.Drawing.Size(251, 24);
			doctorcomboBox.TabIndex = 0;
			doctorcomboBox.SelectedIndexChanged += new System.EventHandler(doctorcomboBox_SelectedIndexChanged);
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.Controls.Add(this.label7);
			groupBox5.Location = new System.Drawing.Point(246, -4);
			groupBox5.Name = "groupBox5";
			groupBox5.Size = new System.Drawing.Size(235, 35);
			groupBox5.TabIndex = 89;
			groupBox5.TabStop = false;
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Arial", 11f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			this.label7.Location = new System.Drawing.Point(67, 13);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(119, 18);
			this.label7.TabIndex = 0;
			this.label7.Text = "حسابات المساعدين";
			label69.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			label69.AutoSize = true;
			label69.BackColor = System.Drawing.Color.Transparent;
			label69.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label69.Location = new System.Drawing.Point(218, 25);
			label69.Name = "label69";
			label69.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			label69.Size = new System.Drawing.Size(68, 16);
			label69.TabIndex = 136;
			label69.Text = "اسم الخزينة :";
			comboBox7.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			comboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox7.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			comboBox7.FormattingEnabled = true;
			comboBox7.Location = new System.Drawing.Point(13, 21);
			comboBox7.Name = "comboBox7";
			comboBox7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			comboBox7.Size = new System.Drawing.Size(199, 24);
			comboBox7.TabIndex = 135;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			base.ClientSize = new System.Drawing.Size(702, 481);
			base.Controls.Add(groupBox5);
			base.Controls.Add(groupBox3);
			base.KeyPreview = true;
			base.Name = "AssistantAccount";
			Text = "حسابات المساعدين";
			base.Load += new System.EventHandler(DoctorAccount_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(DoctorAccount_KeyDown);
			groupBox3.ResumeLayout(false);
			groupBox6.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox4.ResumeLayout(false);
			groupBox4.PerformLayout();
			groupBox5.ResumeLayout(false);
			groupBox5.PerformLayout();
			ResumeLayout(false);
		}

		public AssistantAccount()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
			codes = new dataClass(".\\sqlExpress");
		}

		public void DataGrid()
		{
			dataGridView1.Columns[0].HeaderText = "االتاريخ";
			dataGridView1.Columns[0].DefaultCellStyle.Format = "dd/MM/yyyy";
			dataGridView1.Columns[1].HeaderText = "من التاريخ";
			dataGridView1.Columns[2].HeaderText = "الى التاريخ";
			dataGridView1.Columns[3].HeaderText = "الراتب الأساسى";
			dataGridView1.Columns[4].HeaderText = "النسبة";
			dataGridView1.Columns[5].HeaderText = "الاجمالى";
		}

		private void DoctorAccount_Load(object sender, EventArgs e)
		{
			DataTable dataTable = new DataTable();
			try
			{
				dataTable = codes.Search2("SELECT ID, Name FROM Empdata WHERE (Designation = N'Assistant')");
				gui.loadComboBox(doctorcomboBox, dataTable);
			}
			catch
			{
			}
			try
			{
				doctorcomboBox.SelectedItem = doctorcomboBox.Items[0];
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = new DataTable();
				dataTable2 = dc.GetTableText("select Date,DateFrom,DateTo,Salary,Percentage,Total from AssistantAccount where AssistantID = '" + doctorcomboBox.SelectedValue.ToString() + "' order by Date desc");
				dataGridView1.DataSource = dataTable2;
				DataGrid();
			}
			catch
			{
			}
			load();
			try
			{
				DataTable dataTable3 = codes.Search2("SELECT     dbo.Stock.ID, dbo.Stock.Name\r\nFROM         dbo.Stock INNER JOIN\r\n                      dbo.UserStock ON dbo.Stock.ID = dbo.UserStock.StockId where UserStock.UserId = '" + Main.userId + "' and Status = 'True'");
				comboBox7.DataSource = null;
				comboBox7.DataSource = dataTable3;
				comboBox7.DisplayMember = dataTable3.Columns[1].ToString();
				comboBox7.ValueMember = dataTable3.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void textBox3_TextChanged(object sender, EventArgs e)
		{
		}

		private void doctorcomboBox_SelectionChangeCommitted(object sender, EventArgs e)
		{
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
		}

		private void totaltextBox_KeyPress(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && totaltextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
				}
				else
				{
					MessageBox.Show("من فضلك ادخل ارقام فقط");
					e.Handled = true;
				}
			}
			catch
			{
			}
		}

		private void totaltextBox_Leave(object sender, EventArgs e)
		{
			try
			{
				if (totaltextBox.Text == "")
				{
					totaltextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void load()
		{
			try
			{
				try
				{
					string value = toTimePicker1.Value.Subtract(fromdateTimePicker1.Value).Days.ToString();
					DataTable dataTable = new DataTable();
					dataTable = dc.GetTableText("select Salary,isnull(Percentage,0) from Empdata where ID = " + doctorcomboBox.SelectedValue.ToString());
					int value2 = Convert.ToInt32(value) + 1;
					decimal num = Convert.ToDecimal(dataTable.Rows[0][0].ToString()) / 30m * Convert.ToDecimal(value2);
					salarytextBox.Text = $"{num:0.00}";
					percenttextBox.Text = dataTable.Rows[0][1].ToString();
				}
				catch
				{
					salarytextBox.Text = "0";
					percenttextBox.Text = "0";
				}
				if (percenttextBox.Text == "")
				{
					percenttextBox.Text = "0";
				}
				try
				{
					DataTable dataTable2 = new DataTable();
					dataTable2 = dc.GetTableText("select isnull(sum(Price),0) from PatientAccount where Assistant = '" + doctorcomboBox.Text + "'  and Date between '" + fromdateTimePicker1.Value.ToString("MM/dd/yyyy") + "' and '" + toTimePicker1.Value.ToString("MM/dd/yyyy") + "'");
					proccestextBox.Text = dataTable2.Rows[0][0].ToString();
					if (proccestextBox.Text == "")
					{
						proccestextBox.Text = "0";
					}
				}
				catch
				{
					proccestextBox.Text = "0";
				}
				totaltextBox.Text = (Convert.ToDecimal(proccestextBox.Text) * Convert.ToDecimal(percenttextBox.Text) / 100m + Convert.ToDecimal(salarytextBox.Text)).ToString();
				try
				{
					DataTable dataTable3 = new DataTable();
					dataTable3 = dc.GetTableText("select Date,DateFrom,DateTo,Salary,isnull(Percentage,0),Total from AssistantAccount where AssistantID = '" + doctorcomboBox.SelectedValue.ToString() + "' order by Date desc");
					dataGridView1.DataSource = dataTable3;
					DataGrid();
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void doctorcomboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				try
				{
					string value = toTimePicker1.Value.Subtract(fromdateTimePicker1.Value).Days.ToString();
					DataTable dataTable = new DataTable();
					dataTable = dc.GetTableText("select Salary,isnull(Percentage,0) from Empdata where ID = " + doctorcomboBox.SelectedValue.ToString());
					int value2 = Convert.ToInt32(value) + 1;
					decimal num = Convert.ToDecimal(dataTable.Rows[0][0].ToString()) / 30m * Convert.ToDecimal(value2);
					salarytextBox.Text = $"{num:0.00}";
					percenttextBox.Text = dataTable.Rows[0][1].ToString();
				}
				catch
				{
					salarytextBox.Text = "0";
					percenttextBox.Text = "0";
				}
				if (percenttextBox.Text == "")
				{
					percenttextBox.Text = "0";
				}
				try
				{
					DataTable dataTable2 = new DataTable();
					dataTable2 = dc.GetTableText("select isnull(sum(Price),0) from PatientAccount where Assistant = '" + doctorcomboBox.Text + "'  and Date between '" + fromdateTimePicker1.Value.ToString("MM/dd/yyyy") + "' and '" + toTimePicker1.Value.ToString("MM/dd/yyyy") + "'");
					proccestextBox.Text = dataTable2.Rows[0][0].ToString();
					if (proccestextBox.Text == "")
					{
						proccestextBox.Text = "0";
					}
				}
				catch
				{
					proccestextBox.Text = "0";
				}
				totaltextBox.Text = (Convert.ToDecimal(proccestextBox.Text) * Convert.ToDecimal(percenttextBox.Text) / 100m + Convert.ToDecimal(salarytextBox.Text)).ToString();
				try
				{
					DataTable dataTable3 = new DataTable();
					dataTable3 = dc.GetTableText("select Date,DateFrom,DateTo,Salary,isnull(Percentage,0),Total from AssistantAccount where AssistantID = '" + doctorcomboBox.SelectedValue.ToString() + "' order by Date desc");
					dataGridView1.DataSource = dataTable3;
					DataGrid();
				}
				catch
				{
				}
			}
			catch
			{
			}
		}

		private void saveBtn_Click_1(object sender, EventArgs e)
		{
			try
			{
				if (totaltextBox.Text != "0")
				{
					if (doctorcomboBox.SelectedItem != null)
					{
						if (comboBox7.SelectedIndex != -1)
						{
							DataTable dataTable = new DataTable();
							dataTable = dc.GetTableText("select * from Stock where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
							double num = Convert.ToDouble(dataTable.Rows[0][1].ToString());
							double num2 = Convert.ToDouble(totaltextBox.Text);
							double num3 = num - num2;
							if (num3 >= 0.0)
							{
								DataTable tableText = dc.GetTableText("select DateFrom,DateTo from AssistantAccount where AssistantID = '" + doctorcomboBox.SelectedValue.ToString() + "'");
								if (tableText.Rows.Count == 0)
								{
									string[] fields = new string[8] { "AssistantID", "Date", "DateFrom", "DateTo", "Salary", "Percentage", "Total", "StockId" };
									if (dc.Insert("AddassistantAccount", fields, Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), dateTimePicker1.Value.ToString("MM/dd/yyyy"), fromdateTimePicker1.Value.ToString("MM/dd/yyyy"), toTimePicker1.Value.ToString("MM/dd/yyyy"), salarytextBox.Text, percenttextBox.Text, totaltextBox.Text, Convert.ToInt32(comboBox7.SelectedValue.ToString())))
									{
										codes.Edit2("update Stock Set Value='" + num3.ToString() + "' where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
										codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId) values ('حساب مساعد' ," + Convert.ToDecimal(totaltextBox.Text) + ",'" + doctorcomboBox.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
										MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
										salarytextBox.Text = "0";
										percenttextBox.Text = "0";
										proccestextBox.Text = "0";
										totaltextBox.Text = "0";
										try
										{
											DataTable dataTable2 = new DataTable();
											dataTable2 = dc.GetTableText("select Date,DateFrom,DateTo,Salary,Percentage,Total from AssistantAccount where AssistantID = '" + doctorcomboBox.SelectedValue.ToString() + "' order by Date desc");
											dataGridView1.DataSource = dataTable2;
											DataGrid();
										}
										catch
										{
										}
									}
									else
									{
										MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
									}
									return;
								}
								bool flag = true;
								for (int i = 0; i < tableText.Rows.Count; i++)
								{
									DateTime value = fromdateTimePicker1.Value;
									DateTime value2 = toTimePicker1.Value;
									DateTime dateTime = Convert.ToDateTime(tableText.Rows[i]["DateFrom"]);
									DateTime dateTime2 = Convert.ToDateTime(tableText.Rows[i]["DateTo"]);
									if (!(value.Date >= dateTime.Date) || !(value.Date <= dateTime2.Date))
									{
										if (!(value2.Date >= dateTime.Date) || !(value2.Date <= dateTime2.Date))
										{
											flag = true;
											continue;
										}
										MessageBox.Show("تم دفع هذا الحساب خلال هذه الفترة", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
										flag = false;
										break;
									}
									MessageBox.Show("تم دفع هذا الحساب خلال هذه الفترة", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
									flag = false;
									break;
								}
								if (flag)
								{
									string[] fields = new string[7] { "AssistantID", "Date", "DateFrom", "DateTo", "Salary", "Percentage", "Total" };
									if (dc.Insert("AddassistantAccount", fields, Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()), dateTimePicker1.Value.ToString("MM/dd/yyyy"), fromdateTimePicker1.Value.ToString("MM/dd/yyyy"), toTimePicker1.Value.ToString("MM/dd/yyyy"), salarytextBox.Text, percenttextBox.Text, totaltextBox.Text))
									{
										codes.Edit2("update Stock Set Value='" + num3.ToString() + "' where ID = '" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "'");
										codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('حساب مساعد' ," + Convert.ToDecimal(totaltextBox.Text) + ",'" + doctorcomboBox.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(comboBox7.SelectedValue.ToString()) + "')");
										MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
										salarytextBox.Text = "0";
										percenttextBox.Text = "0";
										proccestextBox.Text = "0";
										totaltextBox.Text = "0";
									}
									else
									{
										MessageBox.Show("حدث خطأ أثناء حفظ البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
									}
								}
							}
							else
							{
								MessageBox.Show("قيمة الخزينة = (" + num + "جنيه) لا يمكن دفع اكثر من ذلك", "تنبيه");
							}
						}
						else
						{
							MessageBox.Show("من فضلك اختر اسم الخزينة", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
					else
					{
						MessageBox.Show("من فضلك اختر اسم طبيب صحيح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else
				{
					MessageBox.Show("من فضلك ادخل الإجمالي", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void totaltextBox_KeyPress_1(object sender, KeyPressEventArgs e)
		{
			try
			{
				if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.' || e.KeyChar == '\b')
				{
					if (e.KeyChar == '.' && totaltextBox.Text.Contains("."))
					{
						e.Handled = true;
					}
				}
				else
				{
					MessageBox.Show("من فضلك ادخل ارقام فقط");
					e.Handled = true;
				}
			}
			catch
			{
			}
		}

		private void totaltextBox_Leave_1(object sender, EventArgs e)
		{
			try
			{
				if (totaltextBox.Text == "")
				{
					totaltextBox.Text = "0";
				}
			}
			catch
			{
			}
		}

		private void DoctorAccount_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void salarytextBox_TextChanged(object sender, EventArgs e)
		{
		}
	}
}
