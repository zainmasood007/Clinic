using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Resources;
using System.Runtime.CompilerServices;

namespace DentistClinic.Properties
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "2.0.0.0")]
	[CompilerGenerated]
	[DebuggerNonUserCode]
	internal class Resources
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(resourceMan, null))
				{
					ResourceManager resourceManager = (resourceMan = new ResourceManager("DentistClinic.Properties.Resources", typeof(Resources).Assembly));
				}
				return resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return resourceCulture;
			}
			set
			{
				resourceCulture = value;
			}
		}

		internal static Bitmap _1
		{
			get
			{
				object @object = ResourceManager.GetObject("1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_03
		{
			get
			{
				object @object = ResourceManager.GetObject("1_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_031
		{
			get
			{
				object @object = ResourceManager.GetObject("1_031", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_032
		{
			get
			{
				object @object = ResourceManager.GetObject("1_032", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_033
		{
			get
			{
				object @object = ResourceManager.GetObject("1_033", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_034
		{
			get
			{
				object @object = ResourceManager.GetObject("1_034", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_06
		{
			get
			{
				object @object = ResourceManager.GetObject("1_06", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_10
		{
			get
			{
				object @object = ResourceManager.GetObject("1_10", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_13
		{
			get
			{
				object @object = ResourceManager.GetObject("1_13", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_16
		{
			get
			{
				object @object = ResourceManager.GetObject("1_16", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_19
		{
			get
			{
				object @object = ResourceManager.GetObject("1_19", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_21
		{
			get
			{
				object @object = ResourceManager.GetObject("1_21", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_25
		{
			get
			{
				object @object = ResourceManager.GetObject("1_25", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_27
		{
			get
			{
				object @object = ResourceManager.GetObject("1_27", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_29
		{
			get
			{
				object @object = ResourceManager.GetObject("1_29", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_31
		{
			get
			{
				object @object = ResourceManager.GetObject("1_31", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_33
		{
			get
			{
				object @object = ResourceManager.GetObject("1_33", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_35
		{
			get
			{
				object @object = ResourceManager.GetObject("1_35", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1_37
		{
			get
			{
				object @object = ResourceManager.GetObject("1_37", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _11
		{
			get
			{
				object @object = ResourceManager.GetObject("11", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _12
		{
			get
			{
				object @object = ResourceManager.GetObject("12", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _123_02
		{
			get
			{
				object @object = ResourceManager.GetObject("123_02", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _13
		{
			get
			{
				object @object = ResourceManager.GetObject("13", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1338741082_coins
		{
			get
			{
				object @object = ResourceManager.GetObject("1338741082_coins", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _14
		{
			get
			{
				object @object = ResourceManager.GetObject("14", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _1495474366_messages_16
		{
			get
			{
				object @object = ResourceManager.GetObject("1495474366_messages_16", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2
		{
			get
			{
				object @object = ResourceManager.GetObject("2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_03
		{
			get
			{
				object @object = ResourceManager.GetObject("2_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_031
		{
			get
			{
				object @object = ResourceManager.GetObject("2_031", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_06
		{
			get
			{
				object @object = ResourceManager.GetObject("2_06", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_10
		{
			get
			{
				object @object = ResourceManager.GetObject("2_10", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_13
		{
			get
			{
				object @object = ResourceManager.GetObject("2_13", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_16
		{
			get
			{
				object @object = ResourceManager.GetObject("2_16", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_19
		{
			get
			{
				object @object = ResourceManager.GetObject("2_19", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_21
		{
			get
			{
				object @object = ResourceManager.GetObject("2_21", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_25
		{
			get
			{
				object @object = ResourceManager.GetObject("2_25", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_27
		{
			get
			{
				object @object = ResourceManager.GetObject("2_27", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_29
		{
			get
			{
				object @object = ResourceManager.GetObject("2_29", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_31
		{
			get
			{
				object @object = ResourceManager.GetObject("2_31", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_33
		{
			get
			{
				object @object = ResourceManager.GetObject("2_33", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_35
		{
			get
			{
				object @object = ResourceManager.GetObject("2_35", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _2_37
		{
			get
			{
				object @object = ResourceManager.GetObject("2_37", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _21
		{
			get
			{
				object @object = ResourceManager.GetObject("21", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _22
		{
			get
			{
				object @object = ResourceManager.GetObject("22", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _22344
		{
			get
			{
				object @object = ResourceManager.GetObject("22344", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _3
		{
			get
			{
				object @object = ResourceManager.GetObject("3", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _3_0000
		{
			get
			{
				object @object = ResourceManager.GetObject("_3_0000", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _3_03
		{
			get
			{
				object @object = ResourceManager.GetObject("3_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _3_031
		{
			get
			{
				object @object = ResourceManager.GetObject("3_031", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _3_032
		{
			get
			{
				object @object = ResourceManager.GetObject("3_032", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _3_033
		{
			get
			{
				object @object = ResourceManager.GetObject("3_033", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _3_04
		{
			get
			{
				object @object = ResourceManager.GetObject("3_04", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _3_05
		{
			get
			{
				object @object = ResourceManager.GetObject("3_05", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _3_051
		{
			get
			{
				object @object = ResourceManager.GetObject("3_051", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _3_06
		{
			get
			{
				object @object = ResourceManager.GetObject("3_06", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _3_07
		{
			get
			{
				object @object = ResourceManager.GetObject("3_07", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _3_071
		{
			get
			{
				object @object = ResourceManager.GetObject("3_071", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _31
		{
			get
			{
				object @object = ResourceManager.GetObject("31", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _32
		{
			get
			{
				object @object = ResourceManager.GetObject("32", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _4
		{
			get
			{
				object @object = ResourceManager.GetObject("4", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _4_0000
		{
			get
			{
				object @object = ResourceManager.GetObject("_4_0000", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _4_03
		{
			get
			{
				object @object = ResourceManager.GetObject("4_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _4_04
		{
			get
			{
				object @object = ResourceManager.GetObject("4_04", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _4_05
		{
			get
			{
				object @object = ResourceManager.GetObject("4_05", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _4_051
		{
			get
			{
				object @object = ResourceManager.GetObject("4_051", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _4_052
		{
			get
			{
				object @object = ResourceManager.GetObject("4_052", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _4_06
		{
			get
			{
				object @object = ResourceManager.GetObject("4_06", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _4_07
		{
			get
			{
				object @object = ResourceManager.GetObject("4_07", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _4_071
		{
			get
			{
				object @object = ResourceManager.GetObject("4_071", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap _43
		{
			get
			{
				object @object = ResourceManager.GetObject("43", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a
		{
			get
			{
				object @object = ResourceManager.GetObject("a", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a1
		{
			get
			{
				object @object = ResourceManager.GetObject("a1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a10
		{
			get
			{
				object @object = ResourceManager.GetObject("a10", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a101
		{
			get
			{
				object @object = ResourceManager.GetObject("a101", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a11
		{
			get
			{
				object @object = ResourceManager.GetObject("a11", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a111
		{
			get
			{
				object @object = ResourceManager.GetObject("a111", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a1111
		{
			get
			{
				object @object = ResourceManager.GetObject("a1111", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a12
		{
			get
			{
				object @object = ResourceManager.GetObject("a12", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a121
		{
			get
			{
				object @object = ResourceManager.GetObject("a121", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a13
		{
			get
			{
				object @object = ResourceManager.GetObject("a13", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a131
		{
			get
			{
				object @object = ResourceManager.GetObject("a131", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a14
		{
			get
			{
				object @object = ResourceManager.GetObject("a14", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a141
		{
			get
			{
				object @object = ResourceManager.GetObject("a141", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a15
		{
			get
			{
				object @object = ResourceManager.GetObject("a15", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a2
		{
			get
			{
				object @object = ResourceManager.GetObject("a2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a3
		{
			get
			{
				object @object = ResourceManager.GetObject("a3", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a4
		{
			get
			{
				object @object = ResourceManager.GetObject("a4", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a5
		{
			get
			{
				object @object = ResourceManager.GetObject("a5", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a6
		{
			get
			{
				object @object = ResourceManager.GetObject("a6", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a7
		{
			get
			{
				object @object = ResourceManager.GetObject("a7", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a8
		{
			get
			{
				object @object = ResourceManager.GetObject("a8", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a9
		{
			get
			{
				object @object = ResourceManager.GetObject("a9", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap a91
		{
			get
			{
				object @object = ResourceManager.GetObject("a91", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap aa
		{
			get
			{
				object @object = ResourceManager.GetObject("aa", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Account1
		{
			get
			{
				object @object = ResourceManager.GetObject("Account1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Account2
		{
			get
			{
				object @object = ResourceManager.GetObject("Account2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Account3
		{
			get
			{
				object @object = ResourceManager.GetObject("Account3", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Account4
		{
			get
			{
				object @object = ResourceManager.GetObject("Account4", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Account5
		{
			get
			{
				object @object = ResourceManager.GetObject("Account5", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Account6
		{
			get
			{
				object @object = ResourceManager.GetObject("Account6", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Account7
		{
			get
			{
				object @object = ResourceManager.GetObject("Account7", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Account8
		{
			get
			{
				object @object = ResourceManager.GetObject("Account8", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Actions_resource_group_icon
		{
			get
			{
				object @object = ResourceManager.GetObject("Actions-resource-group-icon", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap add_document
		{
			get
			{
				object @object = ResourceManager.GetObject("add document", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap add_user_icon
		{
			get
			{
				object @object = ResourceManager.GetObject("add-user-icon", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap any
		{
			get
			{
				object @object = ResourceManager.GetObject("any", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap appointment_new
		{
			get
			{
				object @object = ResourceManager.GetObject("appointment-new", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap appointments
		{
			get
			{
				object @object = ResourceManager.GetObject("appointments", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Apps_Live_Messenger_alt_2_Metro_icon
		{
			get
			{
				object @object = ResourceManager.GetObject("Apps-Live-Messenger-alt-2-Metro-icon", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap arrows
		{
			get
			{
				object @object = ResourceManager.GetObject("arrows", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap b
		{
			get
			{
				object @object = ResourceManager.GetObject("b", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap b1
		{
			get
			{
				object @object = ResourceManager.GetObject("b1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Balance_icon
		{
			get
			{
				object @object = ResourceManager.GetObject("Balance-icon", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap blue
		{
			get
			{
				object @object = ResourceManager.GetObject("blue", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap blue_bar
		{
			get
			{
				object @object = ResourceManager.GetObject("blue-bar", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap c
		{
			get
			{
				object @object = ResourceManager.GetObject("c", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap C_03
		{
			get
			{
				object @object = ResourceManager.GetObject("C_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap C2_03
		{
			get
			{
				object @object = ResourceManager.GetObject("C2_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap C3_03
		{
			get
			{
				object @object = ResourceManager.GetObject("C3_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap C3_031
		{
			get
			{
				object @object = ResourceManager.GetObject("C3_031", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap chart_add_icon
		{
			get
			{
				object @object = ResourceManager.GetObject("chart-add-icon", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap check_user_icon
		{
			get
			{
				object @object = ResourceManager.GetObject("check-user-icon", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap checkbox
		{
			get
			{
				object @object = ResourceManager.GetObject("checkbox", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap clinic_login
		{
			get
			{
				object @object = ResourceManager.GetObject("clinic-login", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap clinic_login1
		{
			get
			{
				object @object = ResourceManager.GetObject("clinic-login1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap clinic_login2
		{
			get
			{
				object @object = ResourceManager.GetObject("clinic-login2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap clinic_splash
		{
			get
			{
				object @object = ResourceManager.GetObject("clinic-splash", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap clinic_splash1
		{
			get
			{
				object @object = ResourceManager.GetObject("clinic-splash1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap clinic_splash2
		{
			get
			{
				object @object = ResourceManager.GetObject("clinic-splash2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap clinic_splash3
		{
			get
			{
				object @object = ResourceManager.GetObject("clinic-splash3", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap clinic_splash4
		{
			get
			{
				object @object = ResourceManager.GetObject("clinic-splash4", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap clinic_splash5
		{
			get
			{
				object @object = ResourceManager.GetObject("clinic-splash5", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap color
		{
			get
			{
				object @object = ResourceManager.GetObject("color", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap color_circle1
		{
			get
			{
				object @object = ResourceManager.GetObject("color-circle1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap color1
		{
			get
			{
				object @object = ResourceManager.GetObject("color1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap color2
		{
			get
			{
				object @object = ResourceManager.GetObject("color2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap color21
		{
			get
			{
				object @object = ResourceManager.GetObject("color21", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap colored_08
		{
			get
			{
				object @object = ResourceManager.GetObject("colored_08", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap colored_26
		{
			get
			{
				object @object = ResourceManager.GetObject("colored_26", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap company
		{
			get
			{
				object @object = ResourceManager.GetObject("company", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static UnmanagedMemoryStream definite => ResourceManager.GetStream("definite", resourceCulture);

		internal static Bitmap Dental_Office_Interior_Design_image
		{
			get
			{
				object @object = ResourceManager.GetObject("Dental-Office-Interior-Design-image", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap DentalClinicsplash
		{
			get
			{
				object @object = ResourceManager.GetObject("DentalClinicsplash", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap dentoffice3_j023
		{
			get
			{
				object @object = ResourceManager.GetObject("dentoffice3-j023", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap dentoffice3m
		{
			get
			{
				object @object = ResourceManager.GetObject("dentoffice3m", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Doctor1
		{
			get
			{
				object @object = ResourceManager.GetObject("Doctor1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Doctor2
		{
			get
			{
				object @object = ResourceManager.GetObject("Doctor2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Doctor3
		{
			get
			{
				object @object = ResourceManager.GetObject("Doctor3", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Doctor4
		{
			get
			{
				object @object = ResourceManager.GetObject("Doctor4", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Doctor5
		{
			get
			{
				object @object = ResourceManager.GetObject("Doctor5", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Doctor6
		{
			get
			{
				object @object = ResourceManager.GetObject("Doctor6", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_03
		{
			get
			{
				object @object = ResourceManager.GetObject("easy_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_031
		{
			get
			{
				object @object = ResourceManager.GetObject("easy_031", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_06
		{
			get
			{
				object @object = ResourceManager.GetObject("easy_06", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_061
		{
			get
			{
				object @object = ResourceManager.GetObject("easy_061", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_08
		{
			get
			{
				object @object = ResourceManager.GetObject("easy_08", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_03
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_3
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-3", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_4
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-4", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_5
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-5", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_01
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_01", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_01_03
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-01_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_01_031
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-01_031", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_01_06
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-01_06", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_01_061
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-01_061", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_01_09
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-01_09", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_01_14
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-01_14", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_01_17
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-01_17", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_01_20
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-01_20", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_011
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_011", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_012
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_012", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_02
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_02", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_02_03
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-02_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_02_07
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-02_07", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_02_10
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-02_10", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_02_15
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-02_15", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_02_17
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-02_17", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_02_22
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-02_22", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_021
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_021", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_022
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_022", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_023
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_023", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_024
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_024", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_03
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_031
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_031", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_032
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_032", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_033
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_033", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_034
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_034", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_035
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_035", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_036
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_036", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_037
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_037", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_038
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_038", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_04
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_04", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_041
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_041", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_042
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_042", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_043
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_043", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_044
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_044", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_05
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_05", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_051
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_051", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_052
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_052", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_053
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_053", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_054
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_054", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_055
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_055", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_056
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_056", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_06
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_06", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_061
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_061", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_062
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_062", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_063
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_063", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_064
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_064", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_065
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_065", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_066
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_066", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_067
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_067", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_07
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_07", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_071
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_071", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_072
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_072", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_073
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_073", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_074
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_074", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_08
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_08", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_081
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_081", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_0811
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_0811", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_082
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_082", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_083
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_083", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_084
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_084", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_085
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_085", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_086
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_086", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_087
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_087", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_088
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_088", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_089
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_089", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_09
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_09", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_091
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_091", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_10
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_10", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_101
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_101", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_102
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_102", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_11
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_11", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_111
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_111", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_12
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_12", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_121
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_121", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_122
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_122", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_123
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_123", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_124
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_124", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_13
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_13", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_131
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_131", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_132
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_132", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_133
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_133", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_14
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_14", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_141
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_141", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_16
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_16", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_161
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_161", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_18
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_18", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_2_04
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-2_04", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_20
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_20", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_201
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_201", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_21
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_21", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_211
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_211", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_23
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_23", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_24
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_24", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_241
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_241", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_25
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_25", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_251
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_251", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_27
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_27", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_271
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_271", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_29
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_29", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_30
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_30", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_301
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_301", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_33
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_33", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_331
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_331", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_34
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_34", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_341
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_341", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_36
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_36", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_37
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_37", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_371
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_371", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_44
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_44", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_441
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_441", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_442
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_442", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_47
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_47", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_50
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_50", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_51
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_51", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_511
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_511", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_55
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_55", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_551
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_551", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_56
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_56", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_58
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_58", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_581
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_581", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_59
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_59", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_64
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_64", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_68
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_68", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_backgroung_01
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-backgroung_01", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_backgroung_011
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-backgroung_011", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_backgroung_012
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design-backgroung_012", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_En1
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_En1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design_En11
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design_En11", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design2_01_03
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design2-01_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design2_01_06
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design2-01_06", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design2_03
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design2_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design2_07
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design2_07", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design2_071
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design2_071", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic_design2_10
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic-design2_10", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_clinic1
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-clinic1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_0
		{
			get
			{
				object @object = ResourceManager.GetObject("Easy store Splash-عيادة الاسنان", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_W_03
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-W_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_W_031
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-W_031", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_W_032
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-W_032", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_W_06
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-W_06", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_W_061
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-W_061", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_W_08
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-W_08", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap easy_W_081
		{
			get
			{
				object @object = ResourceManager.GetObject("easy-W_081", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Edit_Users_icon
		{
			get
			{
				object @object = ResourceManager.GetObject("Edit-Users-icon", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap ExpectedBirthDate
		{
			get
			{
				object @object = ResourceManager.GetObject("ExpectedBirthDate", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap green_background21
		{
			get
			{
				object @object = ResourceManager.GetObject("green_background21", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Hardware_Printer_Picture_icon
		{
			get
			{
				object @object = ResourceManager.GetObject("Hardware-Printer-Picture-icon", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap img
		{
			get
			{
				object @object = ResourceManager.GetObject("img", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Income1
		{
			get
			{
				object @object = ResourceManager.GetObject("Income1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Income10
		{
			get
			{
				object @object = ResourceManager.GetObject("Income10", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Income11
		{
			get
			{
				object @object = ResourceManager.GetObject("Income11", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Income2
		{
			get
			{
				object @object = ResourceManager.GetObject("Income2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Income3
		{
			get
			{
				object @object = ResourceManager.GetObject("Income3", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Income4
		{
			get
			{
				object @object = ResourceManager.GetObject("Income4", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Income5
		{
			get
			{
				object @object = ResourceManager.GetObject("Income5", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Income6
		{
			get
			{
				object @object = ResourceManager.GetObject("Income6", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Income7
		{
			get
			{
				object @object = ResourceManager.GetObject("Income7", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Income8
		{
			get
			{
				object @object = ResourceManager.GetObject("Income8", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Income9
		{
			get
			{
				object @object = ResourceManager.GetObject("Income9", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap list
		{
			get
			{
				object @object = ResourceManager.GetObject("list", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap list_information
		{
			get
			{
				object @object = ResourceManager.GetObject("list_information", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap medical_report
		{
			get
			{
				object @object = ResourceManager.GetObject("medical-report", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static UnmanagedMemoryStream new_notification => ResourceManager.GetStream("new_notification", resourceCulture);

		internal static Bitmap Other1
		{
			get
			{
				object @object = ResourceManager.GetObject("Other1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Other2
		{
			get
			{
				object @object = ResourceManager.GetObject("Other2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Other3
		{
			get
			{
				object @object = ResourceManager.GetObject("Other3", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Other4
		{
			get
			{
				object @object = ResourceManager.GetObject("Other4", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap patient_icon
		{
			get
			{
				object @object = ResourceManager.GetObject("patient-icon", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient1
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient10
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient10", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient11
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient11", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient12
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient12", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient13
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient13", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient14
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient14", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient2
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient3
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient3", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient4
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient4", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient5
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient5", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient6
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient6", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient7
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient7", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient8
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient8", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Patient9
		{
			get
			{
				object @object = ResourceManager.GetObject("Patient9", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report1
		{
			get
			{
				object @object = ResourceManager.GetObject("Report1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report11
		{
			get
			{
				object @object = ResourceManager.GetObject("Report11", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report12
		{
			get
			{
				object @object = ResourceManager.GetObject("Report12", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report13
		{
			get
			{
				object @object = ResourceManager.GetObject("Report13", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report14
		{
			get
			{
				object @object = ResourceManager.GetObject("Report14", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report15
		{
			get
			{
				object @object = ResourceManager.GetObject("Report15", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report16
		{
			get
			{
				object @object = ResourceManager.GetObject("Report16", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report17
		{
			get
			{
				object @object = ResourceManager.GetObject("Report17", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report18
		{
			get
			{
				object @object = ResourceManager.GetObject("Report18", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report19
		{
			get
			{
				object @object = ResourceManager.GetObject("Report19", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report2
		{
			get
			{
				object @object = ResourceManager.GetObject("Report2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report21
		{
			get
			{
				object @object = ResourceManager.GetObject("Report21", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report22
		{
			get
			{
				object @object = ResourceManager.GetObject("Report22", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report23
		{
			get
			{
				object @object = ResourceManager.GetObject("Report23", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report3
		{
			get
			{
				object @object = ResourceManager.GetObject("Report3", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report31
		{
			get
			{
				object @object = ResourceManager.GetObject("Report31", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report32
		{
			get
			{
				object @object = ResourceManager.GetObject("Report32", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report4
		{
			get
			{
				object @object = ResourceManager.GetObject("Report4", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report41
		{
			get
			{
				object @object = ResourceManager.GetObject("Report41", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report410
		{
			get
			{
				object @object = ResourceManager.GetObject("Report410", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report411
		{
			get
			{
				object @object = ResourceManager.GetObject("Report411", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report412
		{
			get
			{
				object @object = ResourceManager.GetObject("Report412", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report42
		{
			get
			{
				object @object = ResourceManager.GetObject("Report42", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report43
		{
			get
			{
				object @object = ResourceManager.GetObject("Report43", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report44
		{
			get
			{
				object @object = ResourceManager.GetObject("Report44", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report45
		{
			get
			{
				object @object = ResourceManager.GetObject("Report45", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report46
		{
			get
			{
				object @object = ResourceManager.GetObject("Report46", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report47
		{
			get
			{
				object @object = ResourceManager.GetObject("Report47", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report48
		{
			get
			{
				object @object = ResourceManager.GetObject("Report48", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report49
		{
			get
			{
				object @object = ResourceManager.GetObject("Report49", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report5
		{
			get
			{
				object @object = ResourceManager.GetObject("Report5", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report6
		{
			get
			{
				object @object = ResourceManager.GetObject("Report6", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report7
		{
			get
			{
				object @object = ResourceManager.GetObject("Report7", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report8
		{
			get
			{
				object @object = ResourceManager.GetObject("Report8", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report9
		{
			get
			{
				object @object = ResourceManager.GetObject("Report9", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report91
		{
			get
			{
				object @object = ResourceManager.GetObject("Report91", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report92
		{
			get
			{
				object @object = ResourceManager.GetObject("Report92", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report93
		{
			get
			{
				object @object = ResourceManager.GetObject("Report93", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Report94
		{
			get
			{
				object @object = ResourceManager.GetObject("Report94", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Search_icon
		{
			get
			{
				object @object = ResourceManager.GetObject("Search-icon", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap search2
		{
			get
			{
				object @object = ResourceManager.GetObject("search2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Sec1
		{
			get
			{
				object @object = ResourceManager.GetObject("Sec1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Sec10
		{
			get
			{
				object @object = ResourceManager.GetObject("Sec10", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Sec2
		{
			get
			{
				object @object = ResourceManager.GetObject("Sec2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Sec3
		{
			get
			{
				object @object = ResourceManager.GetObject("Sec3", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Sec4
		{
			get
			{
				object @object = ResourceManager.GetObject("Sec4", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Sec5
		{
			get
			{
				object @object = ResourceManager.GetObject("Sec5", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Sec6
		{
			get
			{
				object @object = ResourceManager.GetObject("Sec6", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Sec7
		{
			get
			{
				object @object = ResourceManager.GetObject("Sec7", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Sec8
		{
			get
			{
				object @object = ResourceManager.GetObject("Sec8", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Sec9
		{
			get
			{
				object @object = ResourceManager.GetObject("Sec9", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap signup_2
		{
			get
			{
				object @object = ResourceManager.GetObject("signup-2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Slide_Show_icon
		{
			get
			{
				object @object = ResourceManager.GetObject("Slide-Show-icon", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Staff
		{
			get
			{
				object @object = ResourceManager.GetObject("Staff", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap support
		{
			get
			{
				object @object = ResourceManager.GetObject("support", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap team2
		{
			get
			{
				object @object = ResourceManager.GetObject("team2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap tooth2
		{
			get
			{
				object @object = ResourceManager.GetObject("tooth2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static UnmanagedMemoryStream translate_tts => ResourceManager.GetStream("translate_tts", resourceCulture);

		internal static Bitmap type_list
		{
			get
			{
				object @object = ResourceManager.GetObject("type_list", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_1_03
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-1_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_2
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_03
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_031
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_031", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_05
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_05", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_06
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_06", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_07
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_07", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_071
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_071", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_08
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_08", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_081
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_081", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_09
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_09", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_091
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_091", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_10
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_10", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_101
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_101", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_11
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_11", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_111
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_111", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_12
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_12", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_121
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_121", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_13
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_13", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_131
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_131", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_14
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_14", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_141
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_141", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_15
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_15", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_151
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_151", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_16
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_16", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_161
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_161", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_17
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_17", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_171
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_171", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_18
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_18", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_181
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_181", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_182
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_182", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_183
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_183", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_20
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_20", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_3_201
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-3_201", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled_ww1
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled-ww1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled1
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Untitled2
		{
			get
			{
				object @object = ResourceManager.GetObject("Untitled2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap W_03
		{
			get
			{
				object @object = ResourceManager.GetObject("W_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap W2_03
		{
			get
			{
				object @object = ResourceManager.GetObject("W2_03", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap white_08
		{
			get
			{
				object @object = ResourceManager.GetObject("white_08", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap white_26
		{
			get
			{
				object @object = ResourceManager.GetObject("white_26", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap white1
		{
			get
			{
				object @object = ResourceManager.GetObject("white1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap white2
		{
			get
			{
				object @object = ResourceManager.GetObject("white2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap wide_blue_bar
		{
			get
			{
				object @object = ResourceManager.GetObject("wide_blue_bar", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_1
		{
			get
			{
				object @object = ResourceManager.GetObject("اضافة خزينة لمستخدم", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_2
		{
			get
			{
				object @object = ResourceManager.GetObject("الايصالات", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_3
		{
			get
			{
				object @object = ResourceManager.GetObject("التحويل من خزينة لاخرى", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_4
		{
			get
			{
				object @object = ResourceManager.GetObject("الخزائن", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_5
		{
			get
			{
				object @object = ResourceManager.GetObject("الفواتير", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_6
		{
			get
			{
				object @object = ResourceManager.GetObject("الفواتير1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_7
		{
			get
			{
				object @object = ResourceManager.GetObject("بيانات المرضى", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_8
		{
			get
			{
				object @object = ResourceManager.GetObject("بيانات المرضى - Copy", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_9
		{
			get
			{
				object @object = ResourceManager.GetObject("تحاليل المرضى", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_10
		{
			get
			{
				object @object = ResourceManager.GetObject("تسوية كميات", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_11
		{
			get
			{
				object @object = ResourceManager.GetObject("تقارير اشعة وتحاليل", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_12
		{
			get
			{
				object @object = ResourceManager.GetObject("تقارير المساعدين", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_13
		{
			get
			{
				object @object = ResourceManager.GetObject("تقارير المساعدين1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_14
		{
			get
			{
				object @object = ResourceManager.GetObject("تقرير", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_15
		{
			get
			{
				object @object = ResourceManager.GetObject("تقرير التحويل بين الخزائن", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_16
		{
			get
			{
				object @object = ResourceManager.GetObject("تقرير تاريخ الولادة", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_17
		{
			get
			{
				object @object = ResourceManager.GetObject("تقرير حجوزات خدمات", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_18
		{
			get
			{
				object @object = ResourceManager.GetObject("تقرير حساب مساعد", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_19
		{
			get
			{
				object @object = ResourceManager.GetObject("تقرير دخول مستخدم", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_20
		{
			get
			{
				object @object = ResourceManager.GetObject("تقرير مدفوعات مساعد", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_21
		{
			get
			{
				object @object = ResourceManager.GetObject("تقرير معرفة عن", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_22
		{
			get
			{
				object @object = ResourceManager.GetObject("تقرير نقاط مريض", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_23
		{
			get
			{
				object @object = ResourceManager.GetObject("حركة صنف شاملة", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_24
		{
			get
			{
				object @object = ResourceManager.GetObject("حسابات المساعدين", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_25
		{
			get
			{
				object @object = ResourceManager.GetObject("خدمات المساعدين", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_26
		{
			get
			{
				object @object = ResourceManager.GetObject("رصيد اول المدة للمورد", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_27
		{
			get
			{
				object @object = ResourceManager.GetObject("رصيد اول المدة للمورد1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_28
		{
			get
			{
				object @object = ResourceManager.GetObject("زيارات الميديكال ريب", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_29
		{
			get
			{
				object @object = ResourceManager.GetObject("زيارات الميديكال ريب1", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_30
		{
			get
			{
				object @object = ResourceManager.GetObject("زيارات الميديكال ريب2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_31
		{
			get
			{
				object @object = ResourceManager.GetObject("زيارات الميديكال ريب3", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_32
		{
			get
			{
				object @object = ResourceManager.GetObject("زيارات الميديكال ريب4", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_33
		{
			get
			{
				object @object = ResourceManager.GetObject("عن البرنامج2", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_34
		{
			get
			{
				object @object = ResourceManager.GetObject("فئات الخدمات", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_35
		{
			get
			{
				object @object = ResourceManager.GetObject("قبل وبعد", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_36
		{
			get
			{
				object @object = ResourceManager.GetObject("قبل وبعد ", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_37
		{
			get
			{
				object @object = ResourceManager.GetObject("مديونيات المرضي", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal static Bitmap Bitmap_38
		{
			get
			{
				object @object = ResourceManager.GetObject("نقاط مريض", resourceCulture);
				return (Bitmap)@object;
			}
		}

		internal Resources()
		{
		}
	}
}
