using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace DentistClinic.Properties
{
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "9.0.0.0")]
	internal sealed class Settings : ApplicationSettingsBase
	{
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

		public static Settings Default => defaultInstance;

		[DebuggerNonUserCode]
		[SpecialSetting(SpecialSetting.ConnectionString)]
		[ApplicationScopedSetting]
		[DefaultSettingValue("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Clinic.mdf;Integrated Security=True;User Instance=True")]
		public string ClinicConnectionString1 => (string)this["ClinicConnectionString1"];

		[SpecialSetting(SpecialSetting.ConnectionString)]
		[DefaultSettingValue("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\DentalData.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True")]
		[DebuggerNonUserCode]
		[ApplicationScopedSetting]
		public string DentalDataConnectionString => (string)this["DentalDataConnectionString"];

		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		[UserScopedSetting]
		public string backImage
		{
			get
			{
				return (string)this["backImage"];
			}
			set
			{
				this["backImage"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		public string ServerName
		{
			get
			{
				return (string)this["ServerName"];
			}
			set
			{
				this["ServerName"] = value;
			}
		}

		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("")]
		public string DataBaseName
		{
			get
			{
				return (string)this["DataBaseName"];
			}
			set
			{
				this["DataBaseName"] = value;
			}
		}

		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		[UserScopedSetting]
		public string UserName
		{
			get
			{
				return (string)this["UserName"];
			}
			set
			{
				this["UserName"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("")]
		[DebuggerNonUserCode]
		public string Pass
		{
			get
			{
				return (string)this["Pass"];
			}
			set
			{
				this["Pass"] = value;
			}
		}

		[DefaultSettingValue("")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public string GetPassword
		{
			get
			{
				return (string)this["GetPassword"];
			}
			set
			{
				this["GetPassword"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		public bool LivePrint
		{
			get
			{
				return (bool)this["LivePrint"];
			}
			set
			{
				this["LivePrint"] = value;
			}
		}

		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("False")]
		public bool IpCheck
		{
			get
			{
				return (bool)this["IpCheck"];
			}
			set
			{
				this["IpCheck"] = value;
			}
		}

		[DebuggerNonUserCode]
		[UserScopedSetting]
		[DefaultSettingValue("")]
		public string Filename
		{
			get
			{
				return (string)this["Filename"];
			}
			set
			{
				this["Filename"] = value;
			}
		}

		[DefaultSettingValue("")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public string Language
		{
			get
			{
				return (string)this["Language"];
			}
			set
			{
				this["Language"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("Pioneers")]
		public string Pioneers
		{
			get
			{
				return (string)this["Pioneers"];
			}
			set
			{
				this["Pioneers"] = value;
			}
		}

		[DebuggerNonUserCode]
		[ApplicationScopedSetting]
		[SpecialSetting(SpecialSetting.ConnectionString)]
		[DefaultSettingValue("Data Source=BASSANT-PC\\SQLEXPRESS;Initial Catalog=ClinicEmptyDB;User ID=sa;Password=123")]
		public string ClinicEmptyDBConnectionString => (string)this["ClinicEmptyDBConnectionString"];

		[UserScopedSetting]
		[DefaultSettingValue("")]
		[DebuggerNonUserCode]
		public string BillPrinter
		{
			get
			{
				return (string)this["BillPrinter"];
			}
			set
			{
				this["BillPrinter"] = value;
			}
		}

		[UserScopedSetting]
		[DefaultSettingValue("False")]
		[DebuggerNonUserCode]
		public bool IsSecondary
		{
			get
			{
				return (bool)this["IsSecondary"];
			}
			set
			{
				this["IsSecondary"] = value;
			}
		}
	}
}
