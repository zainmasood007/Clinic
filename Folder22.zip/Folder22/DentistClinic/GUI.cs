using System.Data;
using System.Windows.Forms;

namespace DentistClinic
{
	internal class GUI
	{
		public void loadListBox(ListBox lst, DataTable dt)
		{
			lst.DataSource = dt;
			lst.DisplayMember = dt.Columns[1].ToString();
			lst.ValueMember = dt.Columns[0].ToString();
		}

		public void loadDataGrid(DataGridView dg, DataTable dt)
		{
			dg.DataSource = dt;
			dg.Columns[0].Visible = false;
		}

		public void loadComboBox(ComboBox cob, DataTable dt)
		{
			cob.DataSource = dt;
			cob.DisplayMember = dt.Columns[1].ToString();
			cob.ValueMember = dt.Columns[0].ToString();
		}
	}
}
