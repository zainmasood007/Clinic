using System;
using System.ComponentModel;
using System.Drawing;
using System.Management;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class Splash : Form
	{
		private IContainer components = null;

		public string fingerPrint = string.Empty;

		public static Splash Instance { get; set; }

		public Splash()
		{
			InitializeComponent();
		}

		private void Splash_Shown(object sender, EventArgs e)
		{
			try
			{
				fmlogin fmlogin2 = new fmlogin();
				if (!fmlogin.Exit)
				{
					base.Visible = false;
					fmlogin2.ShowDialog();
				}
				Close();
			}
			catch
			{
			}
		}

		private void Splash_Load(object sender, EventArgs e)
		{
		}

		private void Splash_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (Main.Exit)
			{
				Application.Exit();
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			SuspendLayout();
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.Blue;
			BackgroundImage = DentistClinic.Properties.Resources.clinic_splash4;
			base.ClientSize = new System.Drawing.Size(500, 657);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "Splash";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "Splash";
			base.TransparencyKey = System.Drawing.Color.Blue;
			base.Load += new System.EventHandler(Splash_Load);
			base.Shown += new System.EventHandler(Splash_Shown);
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(Splash_FormClosing);
			ResumeLayout(false);
		}

		public string GetID()
		{
			ManagementObjectCollection managementObjectCollection = null;
			ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("Select * From Win32_Processor");
			managementObjectCollection = managementObjectSearcher.Get();
			string result = "";
			foreach (ManagementObject item in managementObjectCollection)
			{
				result = item["ProcessorID"].ToString();
			}
			return result;
		}

		public long GetLong(string s)
		{
			return Convert.ToInt64(s, 16);
		}

		public string GetHex(long s)
		{
			string text = $"{s:x}".ToUpper();
			if (text.Length == 15)
			{
				text = "0" + text;
			}
			return text;
		}

		public long Encript(string s)
		{
			long num = Convert.ToInt64(s, 16);
			return num - 111111111111111L;
		}

		public string Decript(long s)
		{
			s += 111111111111111L;
			string text = $"{s:x}".ToUpper();
			if (text.Length == 15)
			{
				text = "0" + text;
			}
			return text;
		}

		public string InsertDash(string x)
		{
			string text = x.Substring(0, 4);
			string text2 = x.Substring(4, 4);
			string text3 = x.Substring(8, 4);
			string text4 = x.Substring(12);
			return text + "-" + text2 + "-" + text3 + "-" + text4;
		}

		public string DeleteDash(string x)
		{
			return x.Replace("-", "");
		}

		public string Encription(string s)
		{
			s = DeleteDash(s);
			s = Encript(s).ToString();
			s = GetHex(Convert.ToInt64(s));
			return InsertDash(s);
		}

		public string Decription(string s)
		{
			s = DeleteDash(s);
			long @long = GetLong(s);
			s = @long.ToString();
			s = Decript(@long);
			return InsertDash(s);
		}

		public string getSerial(string id)
		{
			string text = id.Replace("-", "");
			string text2 = "";
			for (int i = 0; i < text.Length; i += 8)
			{
				string text3 = "";
				if (i != 0)
				{
					text2 += "-";
				}
				string value = text.Substring(i, 8);
				string text4 = Convert.ToInt64(value, 16).ToString();
				for (int num = text4.Length - 1; num >= 0; num--)
				{
					text3 += text4[num];
				}
				text2 += $"{Convert.ToInt64(text3):x}".ToUpper();
			}
			return text2;
		}

		public string getSerialForSecondary(string id)
		{
			string text = id.Replace("-", "");
			string text2 = "";
			for (int i = 0; i < text.Length; i += 8)
			{
				string text3 = "";
				if (i != 0)
				{
					text2 += "-";
				}
				string value = text.Substring(i, 4);
				string value2 = text.Substring(i + 4, 4);
				string text4 = (Convert.ToInt64(value, 16) + 1L).ToString();
				string text5 = (Convert.ToInt64(value2, 16) + 2L).ToString();
				string text6 = text4 + text5;
				for (int num = text6.Length - 1; num >= 0; num--)
				{
					text3 += text6[num];
				}
				text2 += $"{Convert.ToInt64(text3):x}".ToUpper();
			}
			return text2;
		}

		public string getID(string serial)
		{
			string text = "";
			string text2 = "";
			string[] array = serial.Split('-');
			for (int i = 0; i < array.Length; i++)
			{
				text2 = "";
				string text3 = Convert.ToInt64(array[i], 16).ToString();
				for (int num = text3.Length - 1; num >= 0; num--)
				{
					text2 += text3[num];
				}
				string text4 = $"{Convert.ToInt64(text2):x}".ToUpper();
				while (text4.Length < 8)
				{
					text4 = "0" + text4;
				}
				text += text4;
			}
			return text;
		}

		public string Value()
		{
			if (string.IsNullOrEmpty(fingerPrint))
			{
				fingerPrint = GetHash("CPU >> " + cpuId() + "Clinic\nDISK >> " + diskId());
			}
			return fingerPrint;
		}

		public string GetHash(string s)
		{
			MD5 mD = new MD5CryptoServiceProvider();
			ASCIIEncoding aSCIIEncoding = new ASCIIEncoding();
			byte[] bytes = aSCIIEncoding.GetBytes(s);
			return GetHexString(mD.ComputeHash(bytes));
		}

		public string GetHexString(byte[] bt)
		{
			string text = string.Empty;
			for (int i = 0; i < bt.Length; i++)
			{
				byte b = bt[i];
				int num = b;
				int num2 = num & 0xF;
				int num3 = (num >> 4) & 0xF;
				text = ((num3 <= 9) ? (text + num3) : (text + (char)(num3 - 10 + 65)));
				text = ((num2 <= 9) ? (text + num2) : (text + (char)(num2 - 10 + 65)));
				if (i + 1 != bt.Length && (i + 1) % 2 == 0)
				{
					text += "-";
				}
			}
			return text;
		}

		public string identifier(string wmiClass, string wmiProperty, string wmiMustBeTrue)
		{
			string text = "";
			ManagementClass managementClass = new ManagementClass(wmiClass);
			ManagementObjectCollection instances = managementClass.GetInstances();
			foreach (ManagementObject item in instances)
			{
				if (item[wmiMustBeTrue].ToString() == "True" && text == "")
				{
					try
					{
						text = item[wmiProperty].ToString();
					}
					catch
					{
						continue;
					}
					break;
				}
			}
			return text;
		}

		public string identifier(string wmiClass, string wmiProperty)
		{
			string text = "";
			ManagementClass managementClass = new ManagementClass(wmiClass);
			ManagementObjectCollection instances = managementClass.GetInstances();
			foreach (ManagementObject item in instances)
			{
				if (text == "")
				{
					try
					{
						text = item[wmiProperty].ToString();
					}
					catch
					{
						continue;
					}
					break;
				}
			}
			return text;
		}

		public string cpuId()
		{
			string text = identifier("Win32_Processor", "UniqueId");
			if (text == "")
			{
				text = identifier("Win32_Processor", "ProcessorId");
				if (text == "")
				{
					text = identifier("Win32_Processor", "Name");
					if (text == "")
					{
						text = identifier("Win32_Processor", "Manufacturer");
					}
					text += identifier("Win32_Processor", "MaxClockSpeed");
				}
			}
			return text;
		}

		public string biosId()
		{
			return identifier("Win32_BIOS", "Manufacturer") + identifier("Win32_BIOS", "SMBIOSBIOSVersion") + identifier("Win32_BIOS", "IdentificationCode") + identifier("Win32_BIOS", "SerialNumber") + identifier("Win32_BIOS", "ReleaseDate") + identifier("Win32_BIOS", "Version");
		}

		public string diskId()
		{
			return identifier("Win32_DiskDrive", "Model") + identifier("Win32_DiskDrive", "Manufacturer") + identifier("Win32_DiskDrive", "Signature") + identifier("Win32_DiskDrive", "TotalHeads");
		}

		public string baseId()
		{
			return identifier("Win32_BaseBoard", "Model") + identifier("Win32_BaseBoard", "Manufacturer") + identifier("Win32_BaseBoard", "Name") + identifier("Win32_BaseBoard", "SerialNumber");
		}

		public string videoId()
		{
			return identifier("Win32_VideoController", "DriverVersion") + identifier("Win32_VideoController", "Name");
		}

		public string macId()
		{
			return identifier("Win32_NetworkAdapterConfiguration", "MACAddress");
		}
	}
}
