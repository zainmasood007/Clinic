using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmRptSuplierAccount : ReportBaseForm
	{
		private IContainer components = null;

		private Panel panel1;

		private ComboBox SuplierscomboBox;

		private Button btnSelect;

		private Label label1;

		private CrystalReportViewer crystalReportViewer1;

		private SqlCommand sqlSelectCommand1;

		private SqlConnection sqlConnection1;

		private SqlCommand sqlInsertCommand1;

		private SqlCommand sqlUpdateCommand1;

		private SqlCommand sqlDeleteCommand1;

		private SqlDataAdapter sqlDataAdapter1;

		private SqlCommand sqlSelectCommand2;

		private SqlConnection sqlConnection2;

		private SqlCommand sqlInsertCommand2;

		private SqlCommand sqlUpdateCommand2;

		private SqlCommand sqlDeleteCommand2;

		private SqlDataAdapter sqlDataAdapter2;

		private DataSet1 dataSet11;

		private GroupBox groupBox2;

		private GroupBox groupBox1;

		private ClassDataBase cr;

		private DataTable dt;

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmRptSuplierAccount));
			panel1 = new System.Windows.Forms.Panel();
			groupBox2 = new System.Windows.Forms.GroupBox();
			groupBox1 = new System.Windows.Forms.GroupBox();
			SuplierscomboBox = new System.Windows.Forms.ComboBox();
			label1 = new System.Windows.Forms.Label();
			btnSelect = new System.Windows.Forms.Button();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter1 = new System.Data.SqlClient.SqlDataAdapter();
			sqlSelectCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlConnection2 = new System.Data.SqlClient.SqlConnection();
			sqlInsertCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlUpdateCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDeleteCommand2 = new System.Data.SqlClient.SqlCommand();
			sqlDataAdapter2 = new System.Data.SqlClient.SqlDataAdapter();
			dataSet11 = new DataSet1();
			panel1.SuspendLayout();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			panel1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			panel1.BackColor = System.Drawing.Color.Transparent;
			panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			panel1.Controls.Add(groupBox2);
			panel1.Controls.Add(groupBox1);
			panel1.Controls.Add(crystalReportViewer1);
			panel1.Location = new System.Drawing.Point(6, 9);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(832, 639);
			panel1.TabIndex = 2;
			groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			groupBox2.Location = new System.Drawing.Point(6, 87);
			groupBox2.Name = "groupBox2";
			groupBox2.Size = new System.Drawing.Size(821, 2);
			groupBox2.TabIndex = 16;
			groupBox2.TabStop = false;
			groupBox1.Controls.Add(SuplierscomboBox);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(btnSelect);
			groupBox1.Location = new System.Drawing.Point(3, 3);
			groupBox1.Name = "groupBox1";
			groupBox1.Size = new System.Drawing.Size(707, 78);
			groupBox1.TabIndex = 15;
			groupBox1.TabStop = false;
			SuplierscomboBox.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			SuplierscomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			SuplierscomboBox.FormattingEnabled = true;
			SuplierscomboBox.Location = new System.Drawing.Point(272, 19);
			SuplierscomboBox.Name = "SuplierscomboBox";
			SuplierscomboBox.Size = new System.Drawing.Size(304, 21);
			SuplierscomboBox.TabIndex = 6;
			label1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			label1.AutoSize = true;
			label1.Font = new System.Drawing.Font("Arial", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label1.Location = new System.Drawing.Point(133, 21);
			label1.Name = "label1";
			label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			label1.Size = new System.Drawing.Size(121, 19);
			label1.TabIndex = 3;
			label1.Text = "Supplier Name";
			btnSelect.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			btnSelect.BackColor = System.Drawing.Color.Gainsboro;
			btnSelect.Font = new System.Drawing.Font("Arial", 11.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			btnSelect.Location = new System.Drawing.Point(582, 39);
			btnSelect.Name = "btnSelect";
			btnSelect.Size = new System.Drawing.Size(98, 33);
			btnSelect.TabIndex = 5;
			btnSelect.Text = "Search";
			btnSelect.UseVisualStyleBackColor = false;
			btnSelect.Click += new System.EventHandler(btnSelect_Click);
			crystalReportViewer1.ActiveViewIndex = -1;
			crystalReportViewer1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.DisplayGroupTree = false;
			crystalReportViewer1.Location = new System.Drawing.Point(5, 95);
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.Size = new System.Drawing.Size(822, 539);
			crystalReportViewer1.TabIndex = 3;
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			sqlSelectCommand1.CommandText = "SELECT        Supplier.*\r\nFROM            Supplier";
			sqlSelectCommand1.Connection = sqlConnection1;
			sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Car.mdf;Integrated Security=True;User Instance=True";
			sqlConnection1.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand1.CommandText = resources.GetString("sqlInsertCommand1.CommandText");
			sqlInsertCommand1.Connection = sqlConnection1;
			sqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[5]
			{
				new System.Data.SqlClient.SqlParameter("@SupName", System.Data.SqlDbType.NVarChar, 0, "SupName"),
				new System.Data.SqlClient.SqlParameter("@SupAddress", System.Data.SqlDbType.NVarChar, 0, "SupAddress"),
				new System.Data.SqlClient.SqlParameter("@NationalId", System.Data.SqlDbType.NVarChar, 0, "NationalId"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mobile", System.Data.SqlDbType.NVarChar, 0, "Mobile")
			});
			sqlUpdateCommand1.CommandText = resources.GetString("sqlUpdateCommand1.CommandText");
			sqlUpdateCommand1.Connection = sqlConnection1;
			sqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[17]
			{
				new System.Data.SqlClient.SqlParameter("@SupName", System.Data.SqlDbType.NVarChar, 0, "SupName"),
				new System.Data.SqlClient.SqlParameter("@SupAddress", System.Data.SqlDbType.NVarChar, 0, "SupAddress"),
				new System.Data.SqlClient.SqlParameter("@NationalId", System.Data.SqlDbType.NVarChar, 0, "NationalId"),
				new System.Data.SqlClient.SqlParameter("@Tel", System.Data.SqlDbType.NVarChar, 0, "Tel"),
				new System.Data.SqlClient.SqlParameter("@Mobile", System.Data.SqlDbType.NVarChar, 0, "Mobile"),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NationalId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NationalId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NationalId", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NationalId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mobile", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@SupplierID", System.Data.SqlDbType.Int, 4, "SupplierID")
			});
			sqlDeleteCommand1.CommandText = resources.GetString("sqlDeleteCommand1.CommandText");
			sqlDeleteCommand1.Connection = sqlConnection1;
			sqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[11]
			{
				new System.Data.SqlClient.SqlParameter("@Original_SupplierID", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierID", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupName", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupName", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupName", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupName", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupAddress", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupAddress", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupAddress", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_NationalId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "NationalId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_NationalId", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "NationalId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Tel", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Tel", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Tel", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Tel", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Mobile", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Mobile", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Mobile", System.Data.SqlDbType.NVarChar, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Mobile", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter1.DeleteCommand = sqlDeleteCommand1;
			sqlDataAdapter1.InsertCommand = sqlInsertCommand1;
			sqlDataAdapter1.SelectCommand = sqlSelectCommand1;
			sqlDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Supplier", new System.Data.Common.DataColumnMapping[6]
				{
					new System.Data.Common.DataColumnMapping("SupplierID", "SupplierID"),
					new System.Data.Common.DataColumnMapping("SupName", "SupName"),
					new System.Data.Common.DataColumnMapping("SupAddress", "SupAddress"),
					new System.Data.Common.DataColumnMapping("NationalId", "NationalId"),
					new System.Data.Common.DataColumnMapping("Tel", "Tel"),
					new System.Data.Common.DataColumnMapping("Mobile", "Mobile")
				})
			});
			sqlDataAdapter1.UpdateCommand = sqlUpdateCommand1;
			sqlSelectCommand2.CommandText = "SELECT        Supplier5.*\r\nFROM            Supplier5";
			sqlSelectCommand2.Connection = sqlConnection2;
			sqlConnection2.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Car.mdf;Integrated Security=True;User Instance=True";
			sqlConnection2.FireInfoMessageEventOnUserErrors = false;
			sqlInsertCommand2.CommandText = resources.GetString("sqlInsertCommand2.CommandText");
			sqlInsertCommand2.Connection = sqlConnection2;
			sqlInsertCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[6]
			{
				new System.Data.SqlClient.SqlParameter("@SupplierId", System.Data.SqlDbType.Int, 0, "SupplierId"),
				new System.Data.SqlClient.SqlParameter("@Daen", System.Data.SqlDbType.Money, 0, "Daen"),
				new System.Data.SqlClient.SqlParameter("@Madeen", System.Data.SqlDbType.Money, 0, "Madeen"),
				new System.Data.SqlClient.SqlParameter("@Raseed", System.Data.SqlDbType.Money, 0, "Raseed"),
				new System.Data.SqlClient.SqlParameter("@Bayan", System.Data.SqlDbType.NVarChar, 0, "Bayan"),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date")
			});
			sqlUpdateCommand2.CommandText = resources.GetString("sqlUpdateCommand2.CommandText");
			sqlUpdateCommand2.Connection = sqlConnection2;
			sqlUpdateCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[18]
			{
				new System.Data.SqlClient.SqlParameter("@SupplierId", System.Data.SqlDbType.Int, 0, "SupplierId"),
				new System.Data.SqlClient.SqlParameter("@Daen", System.Data.SqlDbType.Money, 0, "Daen"),
				new System.Data.SqlClient.SqlParameter("@Madeen", System.Data.SqlDbType.Money, 0, "Madeen"),
				new System.Data.SqlClient.SqlParameter("@Raseed", System.Data.SqlDbType.Money, 0, "Raseed"),
				new System.Data.SqlClient.SqlParameter("@Bayan", System.Data.SqlDbType.NVarChar, 0, "Bayan"),
				new System.Data.SqlClient.SqlParameter("@Date", System.Data.SqlDbType.DateTime, 0, "Date"),
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Daen", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Daen", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Daen", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Daen", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Madeen", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Madeen", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Madeen", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Madeen", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Raseed", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Raseed", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Raseed", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Raseed", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Date", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Date", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Date", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Date", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@Id", System.Data.SqlDbType.Int, 4, "Id")
			});
			sqlDeleteCommand2.CommandText = resources.GetString("sqlDeleteCommand2.CommandText");
			sqlDeleteCommand2.Connection = sqlConnection2;
			sqlDeleteCommand2.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[11]
			{
				new System.Data.SqlClient.SqlParameter("@Original_Id", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Id", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_SupplierId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, false, 0, 0, "SupplierId", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Daen", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Daen", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Daen", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Daen", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Madeen", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Madeen", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Madeen", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Madeen", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Raseed", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Raseed", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Raseed", System.Data.SqlDbType.Money, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Raseed", System.Data.DataRowVersion.Original, null),
				new System.Data.SqlClient.SqlParameter("@IsNull_Date", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, 0, 0, "Date", System.Data.DataRowVersion.Original, true, null, "", "", ""),
				new System.Data.SqlClient.SqlParameter("@Original_Date", System.Data.SqlDbType.DateTime, 0, System.Data.ParameterDirection.Input, false, 0, 0, "Date", System.Data.DataRowVersion.Original, null)
			});
			sqlDataAdapter2.DeleteCommand = sqlDeleteCommand2;
			sqlDataAdapter2.InsertCommand = sqlInsertCommand2;
			sqlDataAdapter2.SelectCommand = sqlSelectCommand2;
			sqlDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[1]
			{
				new System.Data.Common.DataTableMapping("Table", "Supplier5", new System.Data.Common.DataColumnMapping[7]
				{
					new System.Data.Common.DataColumnMapping("Id", "Id"),
					new System.Data.Common.DataColumnMapping("SupplierId", "SupplierId"),
					new System.Data.Common.DataColumnMapping("Daen", "Daen"),
					new System.Data.Common.DataColumnMapping("Madeen", "Madeen"),
					new System.Data.Common.DataColumnMapping("Raseed", "Raseed"),
					new System.Data.Common.DataColumnMapping("Bayan", "Bayan"),
					new System.Data.Common.DataColumnMapping("Date", "Date")
				})
			});
			sqlDataAdapter2.UpdateCommand = sqlUpdateCommand2;
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(846, 658);
			base.Controls.Add(panel1);
			base.Location = new System.Drawing.Point(0, 0);
			base.Name = "FrmRptSuplierAccount";
			Text = "Supplier Account Report";
			base.Load += new System.EventHandler(FrmRptSuplierAccount_Load);
			panel1.ResumeLayout(false);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}

		public FrmRptSuplierAccount()
		{
			InitializeComponent();
			cr = new ClassDataBase(".\\sqlExpress");
		}

		private void btnSelect_Click(object sender, EventArgs e)
		{
			dataSet11.Clear();
			sqlConnection1.ConnectionString = cr.ConnectionStr;
			sqlConnection2.ConnectionString = cr.ConnectionStr;
			sqlDataAdapter2.SelectCommand.CommandType = CommandType.Text;
			sqlDataAdapter2.SelectCommand.CommandText = "SELECT  * FROM Supplier5 WHERE SupplierId= '" + SuplierscomboBox.SelectedValue.ToString() + "'";
			sqlDataAdapter1.Fill(dataSet11);
			sqlDataAdapter2.Fill(dataSet11);
			RptSuplierAccount rptSuplierAccount = new RptSuplierAccount();
			rptSuplierAccount.SetDataSource(dataSet11);
			crystalReportViewer1.ReportSource = rptSuplierAccount;
		}

		private void FrmRptSuplierAccount_Load(object sender, EventArgs e)
		{
			LoadSupliers();
		}

		private void LoadSupliers()
		{
			try
			{
				dt = cr.GetTableText("SELECT     SupplierID, SupName FROM Supplier");
				SuplierscomboBox.DataSource = dt;
				SuplierscomboBox.DisplayMember = "SupName";
				SuplierscomboBox.ValueMember = "SupplierID";
			}
			catch
			{
				MessageBox.Show("لايوجد موردين");
			}
		}
	}
}
