using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class FrmSeviceOffers : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private NumericUpDown numericUpDown1;

		private Label label3;

		private ComboBox comboBox2;

		private Label label2;

		private GroupBox groupBox2;

		private Button button3;

		private Button button2;

		private Button button1;

		private GroupBox groupBox3;

		private Button button4;

		private ComboBox comboBox3;

		private GroupBox groupBox4;

		private DataGridView dataGridView1;

		private Label label4;

		private TextBox Number;

		private Label label1;

		private ComboBox comboBox1;

		private Button button5;

		private DateTimePicker dateTimePicker2;

		private DateTimePicker dateTimePicker1;

		private Label label6;

		private Label label5;

		private DataGridView dataGridView2;

		private NumericUpDown numericUpDown2;

		private Label label7;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Service;

		private DataGridViewTextBoxColumn Price;

		private DataGridViewTextBoxColumn Column2;

		private dataClass codes = new dataClass(".\\sqlExpress");

		private string id;

		private string company;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private decimal PriceService = 0m;

		private int Num = 0;

		private string SName = "";

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmSeviceOffers));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
			groupBox1 = new System.Windows.Forms.GroupBox();
			numericUpDown2 = new System.Windows.Forms.NumericUpDown();
			label7 = new System.Windows.Forms.Label();
			dataGridView2 = new System.Windows.Forms.DataGridView();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Service = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label6 = new System.Windows.Forms.Label();
			label5 = new System.Windows.Forms.Label();
			button5 = new System.Windows.Forms.Button();
			Number = new System.Windows.Forms.TextBox();
			label4 = new System.Windows.Forms.Label();
			numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			label3 = new System.Windows.Forms.Label();
			comboBox2 = new System.Windows.Forms.ComboBox();
			label1 = new System.Windows.Forms.Label();
			label2 = new System.Windows.Forms.Label();
			comboBox1 = new System.Windows.Forms.ComboBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			button3 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			button1 = new System.Windows.Forms.Button();
			groupBox3 = new System.Windows.Forms.GroupBox();
			button4 = new System.Windows.Forms.Button();
			comboBox3 = new System.Windows.Forms.ComboBox();
			groupBox4 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
			((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
			groupBox2.SuspendLayout();
			groupBox3.SuspendLayout();
			groupBox4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(numericUpDown2);
			groupBox1.Controls.Add(label7);
			groupBox1.Controls.Add(dataGridView2);
			groupBox1.Controls.Add(dateTimePicker2);
			groupBox1.Controls.Add(dateTimePicker1);
			groupBox1.Controls.Add(label6);
			groupBox1.Controls.Add(label5);
			groupBox1.Controls.Add(button5);
			groupBox1.Controls.Add(Number);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(numericUpDown1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(comboBox2);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(label2);
			groupBox1.Controls.Add(comboBox1);
			groupBox1.Font = null;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			numericUpDown2.AccessibleDescription = null;
			numericUpDown2.AccessibleName = null;
			resources.ApplyResources(numericUpDown2, "numericUpDown2");
			numericUpDown2.DecimalPlaces = 2;
			numericUpDown2.Font = null;
			numericUpDown2.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			numericUpDown2.Name = "numericUpDown2";
			label7.AccessibleDescription = null;
			label7.AccessibleName = null;
			resources.ApplyResources(label7, "label7");
			label7.Font = null;
			label7.Name = "label7";
			dataGridView2.AccessibleDescription = null;
			dataGridView2.AccessibleName = null;
			resources.ApplyResources(dataGridView2, "dataGridView2");
			dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView2.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView2.BackgroundImage = null;
			dataGridViewCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView2.Columns.AddRange(Column1, Service, Price, Column2);
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			dataGridView2.DefaultCellStyle = dataGridViewCellStyle2;
			dataGridView2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			dataGridView2.Font = null;
			dataGridView2.Name = "dataGridView2";
			dataGridView2.ReadOnly = true;
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
			dataGridView2.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(dataGridView2_UserDeletingRow);
			dataGridView2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(dataGridView2_MouseDoubleClick);
			dataGridView2.UserDeletedRow += new System.Windows.Forms.DataGridViewRowEventHandler(dataGridView2_UserDeletedRow_1);
			dataGridView2.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(dataGridView2_RowsRemoved);
			resources.ApplyResources(Column1, "Column1");
			Column1.Name = "Column1";
			Column1.ReadOnly = true;
			resources.ApplyResources(Service, "Service");
			Service.Name = "Service";
			Service.ReadOnly = true;
			resources.ApplyResources(Price, "Price");
			Price.Name = "Price";
			Price.ReadOnly = true;
			resources.ApplyResources(Column2, "Column2");
			Column2.Name = "Column2";
			Column2.ReadOnly = true;
			dateTimePicker2.AccessibleDescription = null;
			dateTimePicker2.AccessibleName = null;
			resources.ApplyResources(dateTimePicker2, "dateTimePicker2");
			dateTimePicker2.BackgroundImage = null;
			dateTimePicker2.CalendarFont = null;
			dateTimePicker2.CustomFormat = null;
			dateTimePicker2.Font = null;
			dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			dateTimePicker2.Name = "dateTimePicker2";
			dateTimePicker1.AccessibleDescription = null;
			dateTimePicker1.AccessibleName = null;
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.BackgroundImage = null;
			dateTimePicker1.CalendarFont = null;
			dateTimePicker1.CustomFormat = null;
			dateTimePicker1.Font = null;
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			dateTimePicker1.Name = "dateTimePicker1";
			label6.AccessibleDescription = null;
			label6.AccessibleName = null;
			resources.ApplyResources(label6, "label6");
			label6.Font = null;
			label6.Name = "label6";
			label5.AccessibleDescription = null;
			label5.AccessibleName = null;
			resources.ApplyResources(label5, "label5");
			label5.Font = null;
			label5.Name = "label5";
			button5.AccessibleDescription = null;
			button5.AccessibleName = null;
			resources.ApplyResources(button5, "button5");
			button5.BackgroundImage = null;
			button5.Font = null;
			button5.Name = "button5";
			button5.UseVisualStyleBackColor = true;
			button5.Click += new System.EventHandler(button5_Click_1);
			Number.AccessibleDescription = null;
			Number.AccessibleName = null;
			resources.ApplyResources(Number, "Number");
			Number.BackgroundImage = null;
			Number.Font = null;
			Number.Name = "Number";
			Number.TextChanged += new System.EventHandler(Number_TextChanged);
			label4.AccessibleDescription = null;
			label4.AccessibleName = null;
			resources.ApplyResources(label4, "label4");
			label4.Font = null;
			label4.Name = "label4";
			numericUpDown1.AccessibleDescription = null;
			numericUpDown1.AccessibleName = null;
			resources.ApplyResources(numericUpDown1, "numericUpDown1");
			numericUpDown1.DecimalPlaces = 2;
			numericUpDown1.Font = null;
			numericUpDown1.Maximum = new decimal(new int[4] { 999999999, 0, 0, 0 });
			numericUpDown1.Name = "numericUpDown1";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.Font = null;
			label3.Name = "label3";
			comboBox2.AccessibleDescription = null;
			comboBox2.AccessibleName = null;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.BackgroundImage = null;
			comboBox2.Font = null;
			comboBox2.FormattingEnabled = true;
			comboBox2.Name = "comboBox2";
			comboBox2.SelectedIndexChanged += new System.EventHandler(comboBox2_SelectedIndexChanged);
			label1.AccessibleDescription = null;
			label1.AccessibleName = null;
			resources.ApplyResources(label1, "label1");
			label1.Font = null;
			label1.Name = "label1";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "label2");
			label2.Font = null;
			label2.Name = "label2";
			comboBox1.AccessibleDescription = null;
			comboBox1.AccessibleName = null;
			resources.ApplyResources(comboBox1, "comboBox1");
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.BackgroundImage = null;
			comboBox1.Font = null;
			comboBox1.FormattingEnabled = true;
			comboBox1.Name = "comboBox1";
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(button3);
			groupBox2.Controls.Add(button2);
			groupBox2.Controls.Add(button1);
			groupBox2.Font = null;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			button3.AccessibleDescription = null;
			button3.AccessibleName = null;
			resources.ApplyResources(button3, "button3");
			button3.BackgroundImage = null;
			button3.Font = null;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			button2.AccessibleDescription = null;
			button2.AccessibleName = null;
			resources.ApplyResources(button2, "button2");
			button2.BackgroundImage = null;
			button2.Font = null;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			button1.AccessibleDescription = null;
			button1.AccessibleName = null;
			resources.ApplyResources(button1, "button1");
			button1.BackgroundImage = null;
			button1.Font = null;
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			groupBox3.AccessibleDescription = null;
			groupBox3.AccessibleName = null;
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.BackgroundImage = null;
			groupBox3.Controls.Add(button4);
			groupBox3.Controls.Add(comboBox3);
			groupBox3.Font = null;
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			groupBox3.Enter += new System.EventHandler(groupBox3_Enter);
			button4.AccessibleDescription = null;
			button4.AccessibleName = null;
			resources.ApplyResources(button4, "button4");
			button4.BackgroundImage = null;
			button4.Font = null;
			button4.Name = "button4";
			button4.UseVisualStyleBackColor = true;
			button4.Click += new System.EventHandler(button4_Click);
			comboBox3.AccessibleDescription = null;
			comboBox3.AccessibleName = null;
			resources.ApplyResources(comboBox3, "comboBox3");
			comboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			comboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox3.BackgroundImage = null;
			comboBox3.Font = null;
			comboBox3.FormattingEnabled = true;
			comboBox3.Name = "comboBox3";
			groupBox4.AccessibleDescription = null;
			groupBox4.AccessibleName = null;
			resources.ApplyResources(groupBox4, "groupBox4");
			groupBox4.BackColor = System.Drawing.Color.Transparent;
			groupBox4.BackgroundImage = null;
			groupBox4.Controls.Add(dataGridView1);
			groupBox4.Font = null;
			groupBox4.Name = "groupBox4";
			groupBox4.TabStop = false;
			dataGridView1.AccessibleDescription = null;
			dataGridView1.AccessibleName = null;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundImage = null;
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			dataGridView1.DefaultCellStyle = dataGridViewCellStyle5;
			dataGridView1.Font = null;
			dataGridView1.Name = "dataGridView1";
			dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(groupBox4);
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox2);
			base.Controls.Add(groupBox1);
			Font = null;
			base.Name = "FrmSeviceOffers";
			base.Load += new System.EventHandler(FrmCompaniesServicesPrices_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
			((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
			((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
			groupBox2.ResumeLayout(false);
			groupBox3.ResumeLayout(false);
			groupBox4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
		}

		public FrmSeviceOffers()
		{
			InitializeComponent();
		}

		public FrmSeviceOffers(string Company1)
		{
			InitializeComponent();
			company = Company1;
		}

		private void loadData()
		{
			try
			{
				DataTable dataTable = codes.Search2("select distinct(Service),id from CompanyService");
				comboBox2.DataSource = dataTable;
				comboBox2.DisplayMember = dataTable.Columns[0].ToString();
				comboBox2.ValueMember = dataTable.Columns[1].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select distinct name,OfferID from Offers");
				comboBox1.DataSource = dataTable;
				comboBox1.ValueMember = "OfferID";
				comboBox1.DisplayMember = "name";
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select distinct name,OfferID from Offers");
				comboBox3.DataSource = dataTable;
				comboBox3.ValueMember = "OfferID";
				comboBox3.DisplayMember = "name";
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = ((!(Settings.Default.Language == "en-GB")) ? codes.Search2("select  name [اسم العرض],id, OfferID ,ServiceID,Servicename [اسم الخدمة],serviceNum [العدد],Price [السعر],StartDate [بداية العرض],EndDate  [نهاية العرض],ServicePrice [سعر الخدمة داخل العرض] from Offers") : codes.Search2("select  name [Offer Name],id, OfferID ,ServiceID,Servicename [Service Name],serviceNum [Count],Price [Price],StartDate [Offer Start],EndDate  [Offer End],ServicePrice [Service Price In Offer] from Offers"));
				dataGridView1.DataSource = dataTable;
				dataGridView1.Columns[1].Visible = false;
				dataGridView1.Columns[2].Visible = false;
				dataGridView1.Columns[3].Visible = false;
			}
			catch
			{
			}
		}

		private void FrmCompaniesServicesPrices_Load(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2("select distinct(Service),id from CompanyService");
				comboBox2.DataSource = dataTable;
				comboBox2.DisplayMember = dataTable.Columns[0].ToString();
				comboBox2.ValueMember = dataTable.Columns[1].ToString();
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select distinct name,OfferID from Offers");
				comboBox1.DataSource = dataTable;
				comboBox1.ValueMember = "OfferID";
				comboBox1.DisplayMember = "name";
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = codes.Search2("select distinct name,OfferID from Offers");
				comboBox3.DataSource = dataTable;
				comboBox3.ValueMember = "OfferID";
				comboBox3.DisplayMember = "name";
			}
			catch
			{
			}
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = ((!(Settings.Default.Language == "en-GB")) ? codes.Search2("select  name [اسم العرض],id, OfferID ,ServiceID,Servicename [اسم الخدمة],serviceNum [العدد],Price [السعر],StartDate [بداية العرض],EndDate  [نهاية العرض],ServicePrice [سعر الخدمة داخل العرض] from Offers") : codes.Search2("select  name [Offer Name],id, OfferID ,ServiceID,Servicename [Service Name],serviceNum [Count],Price [Price],StartDate [Offer Start],EndDate  [Offer End],ServicePrice [Service Price In Offer] from Offers"));
				dataGridView1.DataSource = dataTable;
				dataGridView1.Columns[1].Visible = false;
				dataGridView1.Columns[2].Visible = false;
				dataGridView1.Columns[3].Visible = false;
			}
			catch
			{
			}
		}

		private void FillDataGrid()
		{
			DataTable dataTable = new DataTable();
			dataTable = codes.Search2(string.Concat("select id, OfferID, name [اسم العرض],ServiceID,Servicename [اسم الخدمة],serviceNum [العدد],Price [السعر],StartDate [بداية العرض],EndDate  [نهاية العرض] from Offers where OfferID = '", comboBox3.SelectedValue, "'"));
			dataGridView1.DataSource = dataTable;
			dataGridView1.Columns[0].Visible = false;
			dataGridView1.Columns[1].Visible = false;
			dataGridView1.Columns[3].Visible = false;
		}

		private void button4_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = ((!(Settings.Default.Language == "en-GB")) ? codes.Search2(string.Concat("select id, OfferID, name [اسم العرض],ServiceID,Servicename [اسم الخدمة],serviceNum [العدد],Price [السعر],StartDate [بداية العرض],EndDate  [نهاية العرض] from Offers where OfferID = '", comboBox3.SelectedValue, "'")) : codes.Search2(string.Concat("select id, OfferID, name [Offer Name],ServiceID,Servicename [Service Name],serviceNum [Count],Price [Price],StartDate [Offer Start],EndDate  [Offer End] from Offers where OfferID = '", comboBox3.SelectedValue, "'")));
				dataGridView1.DataSource = dataTable;
				dataGridView1.Columns[0].Visible = false;
				dataGridView1.Columns[1].Visible = false;
				dataGridView1.Columns[3].Visible = false;
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (comboBox2.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Service Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الخدمة");
					}
				}
				else if (comboBox1.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Offer Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم العرض");
					}
				}
				else if (numericUpDown1.Value >= 0m)
				{
					if (dataGridView2.Rows.Count == 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Choose Service for Offer");
						}
						else
						{
							MessageBox.Show("من فضلك اختر خدمات العرض");
						}
						return;
					}
					DataTable dataTable = codes.Search2(string.Concat("select id from Offers where OfferID ='", comboBox1.SelectedValue, "'"));
					if (dataTable.Rows.Count > 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Have Save This Offer Before");
						}
						else
						{
							MessageBox.Show("تم تسجيل هذا العرض من قبل");
						}
						return;
					}
					int num = Convert.ToInt32(codes.Search2("select isNull(max(OfferID),0) from Offers").Rows[0][0].ToString()) + 1;
					for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
					{
						codes.Add2("insert into Offers (OfferID,name,ServiceID,Servicename,Price,StartDate,EndDate,serviceNum,ServicePrice) Values ('" + num + "','" + comboBox1.Text + "', '" + dataGridView2.Rows[i].Cells[0].Value.ToString() + "','" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "','" + numericUpDown1.Value + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "','" + dataGridView2.Rows[i].Cells[2].Value.ToString() + "','" + dataGridView2.Rows[i].Cells[3].Value.ToString() + "')");
					}
					MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					numericUpDown1.Value = 0m;
					Number.Text = "1";
					dateTimePicker1.Value = DateTime.Now;
					dateTimePicker2.Value = DateTime.Now;
					dataGridView2.Rows.Clear();
					loadData();
					MethodsClass.UserMove("أضافة عرض");
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Price");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل السعر");
				}
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				if (comboBox2.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Service Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم الخدمة");
					}
				}
				else if (comboBox1.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Offer Name");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل اسم العرض");
					}
				}
				else if (numericUpDown1.Value >= 0m)
				{
					if (dataGridView2.Rows.Count == 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("Choose Service for Offer");
						}
						else
						{
							MessageBox.Show("من فضلك اختر خدمات العرض");
						}
						return;
					}
					DataTable dataTable = codes.Search2(string.Concat("select * from Offers where OfferID <>'", comboBox1.SelectedValue, "'and name='", comboBox1.Text, "'"));
					if (dataTable.Rows.Count > 0)
					{
						if (Settings.Default.Language == "en-GB")
						{
							MessageBox.Show("You Have Save This Offer Before");
						}
						else
						{
							MessageBox.Show("تم تسجيل هذا العرض من قبل");
						}
						return;
					}
					codes.Delete2("delete from Offers where OfferID='" + id + "'");
					int num = Convert.ToInt32(id);
					for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
					{
						codes.Add2("insert into Offers (OfferID,name,ServiceID,Servicename,Price,StartDate,EndDate,serviceNum,ServicePrice) Values ('" + num + "','" + comboBox1.Text + "', '" + dataGridView2.Rows[i].Cells[0].Value.ToString() + "','" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "','" + numericUpDown1.Value + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + dateTimePicker2.Value.ToString("MM/dd/yyyy") + "','" + dataGridView2.Rows[i].Cells[2].Value.ToString() + "','" + dataGridView2.Rows[i].Cells[3].Value.ToString() + "')");
					}
					MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					numericUpDown1.Value = 0m;
					Number.Text = "1";
					dateTimePicker1.Value = DateTime.Now;
					dateTimePicker2.Value = DateTime.Now;
					dataGridView2.Rows.Clear();
					loadData();
					MethodsClass.UserMove("تعديل عرض");
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please enter Price");
				}
				else
				{
					MessageBox.Show("من فضلك ادخل السعر");
				}
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				codes.Delete("delete from Offers where OfferID='" + id + "'");
				MethodsClass.UserMove("حذف عرض");
				numericUpDown1.Value = 0m;
				Number.Text = "1";
				button2.Visible = false;
				button3.Visible = false;
				button1.Visible = true;
				dateTimePicker1.Value = DateTime.Now;
				dateTimePicker2.Value = DateTime.Now;
				dataGridView2.Rows.Clear();
				loadData();
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				dataGridView2.Rows.Clear();
				button2.Visible = true;
				button3.Visible = true;
				button1.Visible = false;
				id = dataGridView1.CurrentRow.Cells[2].Value.ToString();
				comboBox1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
				numericUpDown1.Value = Convert.ToDecimal(dataGridView1.CurrentRow.Cells[6].Value.ToString());
				dateTimePicker1.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[7].Value.ToString());
				dateTimePicker2.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[8].Value.ToString());
				DataTable dataTable = codes.Search2("select ServiceID,Servicename,serviceNum,ServicePrice from Offers where OfferID='" + id + "'");
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					dataGridView2.Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString());
				}
				Number.Text = "1";
			}
			catch
			{
			}
		}

		private void groupBox3_Enter(object sender, EventArgs e)
		{
		}

		private void button5_Click_1(object sender, EventArgs e)
		{
			try
			{
				dataGridView2.Rows.Add(comboBox2.SelectedValue, comboBox2.Text, Number.Text, numericUpDown2.Value);
				numericUpDown1.Value += numericUpDown2.Value;
				Number.Text = "1";
				numericUpDown2.Value = 0m;
			}
			catch
			{
			}
		}

		private void dataGridView2_UserDeletedRow_1(object sender, DataGridViewRowEventArgs e)
		{
		}

		private void dataGridView2_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
		{
		}

		private void dataGridView2_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
		{
			try
			{
				numericUpDown1.Value -= PriceService * (decimal)Num;
			}
			catch
			{
			}
		}

		private void dataGridView2_MouseDoubleClick(object sender, MouseEventArgs e)
		{
			try
			{
				PriceService = Convert.ToDecimal(dataGridView2.CurrentRow.Cells[3].Value.ToString());
				Num = Convert.ToInt32(dataGridView2.CurrentRow.Cells[2].Value.ToString());
			}
			catch
			{
			}
		}

		private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				decimal value = Convert.ToDecimal(codes.Search2(string.Concat("select Price from CompanyService where ID='", comboBox2.SelectedValue, "'")).Rows[0][0].ToString());
				numericUpDown2.Value = value;
			}
			catch
			{
			}
		}

		private void Number_TextChanged(object sender, EventArgs e)
		{
			if (Number.Text == "")
			{
				Number.Text = "1";
				return;
			}
			decimal num = Convert.ToDecimal(codes.Search2(string.Concat("select Price from CompanyService where ID='", comboBox2.SelectedValue, "'")).Rows[0][0].ToString());
			numericUpDown2.Value = num * Convert.ToDecimal(Number.Text);
		}
	}
}
