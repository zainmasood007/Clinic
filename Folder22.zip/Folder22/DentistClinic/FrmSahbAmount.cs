using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using FloatTextBox;

namespace DentistClinic
{
	public class FrmSahbAmount : BaseForm
	{
		private IContainer components = null;

		private GroupBox groupBox1;

		private TextBox textBox1;

		private Label label4;

		private DateTimePicker dateTimePicker1;

		private Label label3;

		private ComboBox itemIdComboBox;

		private Label label2;

		private Label label1;

		private Button AddBtn;

		private Label label6;

		private ComboBox comboBox1;

		private ComboBox doctorcomboBox;

		private FloatText txtQty;

		private FloatText textBox3;

		private GroupBox groupBox3;

		private DataGridView dataGridView1;

		private Button button1;

		private DataGridViewTextBoxColumn Column1;

		private DataGridViewTextBoxColumn Column2;

		private DataGridViewTextBoxColumn Column3;

		private DataGridViewTextBoxColumn ItemId;

		private int patientId;

		private int doctorId;

		private string BuyPrice;

		private ClassDataBase dc = new ClassDataBase(".\\sqlExpress");

		private dataClass codes = new dataClass(".\\sqlExpress");

		private GUI gui = new GUI();

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			groupBox1 = new System.Windows.Forms.GroupBox();
			AddBtn = new System.Windows.Forms.Button();
			txtQty = new FloatTextBox.FloatText();
			textBox3 = new FloatTextBox.FloatText();
			comboBox1 = new System.Windows.Forms.ComboBox();
			label6 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			textBox1 = new System.Windows.Forms.TextBox();
			label4 = new System.Windows.Forms.Label();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label3 = new System.Windows.Forms.Label();
			itemIdComboBox = new System.Windows.Forms.ComboBox();
			label2 = new System.Windows.Forms.Label();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			groupBox3 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			ItemId = new System.Windows.Forms.DataGridViewTextBoxColumn();
			button1 = new System.Windows.Forms.Button();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			groupBox1.SuspendLayout();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			SuspendLayout();
			label.AutoSize = true;
			label.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label.Location = new System.Drawing.Point(483, 129);
			label.Name = "nameLabel";
			label.Size = new System.Drawing.Size(65, 16);
			label.TabIndex = 24;
			label.Text = "اسم الطبيب :";
			label.Visible = false;
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(AddBtn);
			groupBox1.Controls.Add(txtQty);
			groupBox1.Controls.Add(textBox3);
			groupBox1.Controls.Add(comboBox1);
			groupBox1.Controls.Add(label6);
			groupBox1.Controls.Add(label1);
			groupBox1.Controls.Add(textBox1);
			groupBox1.Controls.Add(label4);
			groupBox1.Controls.Add(dateTimePicker1);
			groupBox1.Controls.Add(label3);
			groupBox1.Controls.Add(itemIdComboBox);
			groupBox1.Controls.Add(label2);
			groupBox1.Location = new System.Drawing.Point(8, 2);
			groupBox1.Name = "groupBox1";
			groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox1.Size = new System.Drawing.Size(406, 193);
			groupBox1.TabIndex = 17;
			groupBox1.TabStop = false;
			AddBtn.BackColor = System.Drawing.Color.Gainsboro;
			AddBtn.Font = new System.Drawing.Font("Arial", 9f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			AddBtn.Location = new System.Drawing.Point(60, 152);
			AddBtn.Name = "AddBtn";
			AddBtn.Size = new System.Drawing.Size(61, 29);
			AddBtn.TabIndex = 23;
			AddBtn.Text = "اضافة";
			AddBtn.UseVisualStyleBackColor = false;
			AddBtn.Click += new System.EventHandler(AddBtn_Click);
			txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			txtQty.Location = new System.Drawing.Point(127, 157);
			txtQty.Name = "txtQty";
			txtQty.Size = new System.Drawing.Size(200, 20);
			txtQty.TabIndex = 42;
			txtQty.Text = "0";
			txtQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			textBox3.Location = new System.Drawing.Point(127, 123);
			textBox3.Name = "textBox3";
			textBox3.Size = new System.Drawing.Size(200, 20);
			textBox3.TabIndex = 41;
			textBox3.Text = "0";
			textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox1.Enabled = false;
			comboBox1.FormattingEnabled = true;
			comboBox1.Location = new System.Drawing.Point(128, 21);
			comboBox1.Name = "comboBox1";
			comboBox1.Size = new System.Drawing.Size(199, 21);
			comboBox1.TabIndex = 15;
			label6.AutoSize = true;
			label6.Font = new System.Drawing.Font("Arial", 8.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label6.Location = new System.Drawing.Point(333, 24);
			label6.Name = "label6";
			label6.Size = new System.Drawing.Size(53, 14);
			label6.TabIndex = 14;
			label6.Text = "اسم المريض";
			label1.AutoSize = true;
			label1.Font = new System.Drawing.Font("Arial", 9f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label1.Location = new System.Drawing.Point(342, 124);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(44, 15);
			label1.TabIndex = 12;
			label1.Text = "سعر البيع";
			textBox1.Location = new System.Drawing.Point(42, 87);
			textBox1.Name = "textBox1";
			textBox1.ReadOnly = true;
			textBox1.Size = new System.Drawing.Size(79, 20);
			textBox1.TabIndex = 11;
			label4.AutoSize = true;
			label4.Font = new System.Drawing.Font("Arial", 9f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label4.Location = new System.Drawing.Point(343, 60);
			label4.Name = "label4";
			label4.Size = new System.Drawing.Size(34, 15);
			label4.TabIndex = 8;
			label4.Text = "التاريخ";
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Location = new System.Drawing.Point(127, 55);
			dateTimePicker1.Name = "dateTimePicker1";
			dateTimePicker1.RightToLeftLayout = true;
			dateTimePicker1.Size = new System.Drawing.Size(200, 20);
			dateTimePicker1.TabIndex = 7;
			label3.AutoSize = true;
			label3.Font = new System.Drawing.Font("Arial", 9f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label3.Location = new System.Drawing.Point(342, 158);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(30, 15);
			label3.TabIndex = 5;
			label3.Text = "الكمية";
			itemIdComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			itemIdComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			itemIdComboBox.FormattingEnabled = true;
			itemIdComboBox.Location = new System.Drawing.Point(128, 87);
			itemIdComboBox.Name = "itemIdComboBox";
			itemIdComboBox.Size = new System.Drawing.Size(199, 21);
			itemIdComboBox.TabIndex = 4;
			itemIdComboBox.SelectedIndexChanged += new System.EventHandler(itemIdComboBox_SelectedIndexChanged);
			label2.AutoSize = true;
			label2.Font = new System.Drawing.Font("Arial", 9f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			label2.Location = new System.Drawing.Point(342, 90);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(34, 15);
			label2.TabIndex = 3;
			label2.Text = "الصنف";
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.Enabled = false;
			doctorcomboBox.Font = new System.Drawing.Font("Arial", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Location = new System.Drawing.Point(437, 126);
			doctorcomboBox.Name = "doctorcomboBox";
			doctorcomboBox.Size = new System.Drawing.Size(40, 24);
			doctorcomboBox.TabIndex = 25;
			doctorcomboBox.Visible = false;
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.Controls.Add(dataGridView1);
			groupBox3.Location = new System.Drawing.Point(8, 198);
			groupBox3.Name = "groupBox3";
			groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox3.Size = new System.Drawing.Size(406, 151);
			groupBox3.TabIndex = 26;
			groupBox3.TabStop = false;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			dataGridView1.BackgroundColor = System.Drawing.Color.LightSteelBlue;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridView1.Columns.AddRange(Column1, Column2, Column3, ItemId);
			dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
			dataGridView1.Location = new System.Drawing.Point(3, 16);
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.Size = new System.Drawing.Size(400, 132);
			dataGridView1.TabIndex = 0;
			Column1.HeaderText = "اسم الصنف";
			Column1.Name = "Column1";
			Column1.ReadOnly = true;
			Column2.HeaderText = "سعر البيع";
			Column2.Name = "Column2";
			Column2.ReadOnly = true;
			Column3.HeaderText = "الكمية";
			Column3.Name = "Column3";
			Column3.ReadOnly = true;
			ItemId.HeaderText = "ItemId";
			ItemId.Name = "ItemId";
			ItemId.ReadOnly = true;
			ItemId.Visible = false;
			button1.BackColor = System.Drawing.Color.Gainsboro;
			button1.Font = new System.Drawing.Font("Arial", 9f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
			button1.Location = new System.Drawing.Point(172, 355);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(75, 28);
			button1.TabIndex = 27;
			button1.Text = "حفظ";
			button1.UseVisualStyleBackColor = false;
			button1.Click += new System.EventHandler(button1_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(424, 392);
			base.Controls.Add(button1);
			base.Controls.Add(groupBox3);
			base.Controls.Add(groupBox1);
			base.Controls.Add(doctorcomboBox);
			base.Controls.Add(label);
			base.Name = "FrmSahbAmount";
			Text = "سحب كميات الأصناف";
			base.Load += new System.EventHandler(FrmSahbAmount_Load);
			groupBox1.ResumeLayout(false);
			groupBox1.PerformLayout();
			groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		public FrmSahbAmount(int pId, int dId)
		{
			InitializeComponent();
			patientId = pId;
			doctorId = dId;
		}

		public void LoadData()
		{
		}

		public void LoadItems()
		{
			try
			{
				DataTable dataTable = codes.Search2("select * from Items");
				itemIdComboBox.DataSource = null;
				itemIdComboBox.DataSource = dataTable;
				itemIdComboBox.DisplayMember = dataTable.Columns[1].ToString();
				itemIdComboBox.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
		}

		private void FrmSahbAmount_Load(object sender, EventArgs e)
		{
			LoadItems();
			itemIdComboBox.SelectedIndex = -1;
			LoadData();
			try
			{
				DataTable dt = dc.Select("SelectAllDoctor");
				gui.loadComboBox(doctorcomboBox, dt);
				doctorcomboBox.SelectedValue = doctorId;
			}
			catch
			{
			}
			DataTable dt2 = dc.Select("SelectAllPatient");
			gui.loadComboBox(comboBox1, dt2);
			comboBox1.SelectedValue = patientId;
		}

		private void itemIdComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				if (itemIdComboBox.SelectedIndex == -1)
				{
					textBox1.Text = "0";
					textBox3.Text = "0";
					return;
				}
				DataTable dataTable = codes.Search2(string.Concat("SELECT     dbo.Store.Qnt, dbo.Items.SalePrice, dbo.Store.BuyPrice\r\nFROM         dbo.Items INNER JOIN\r\n                      dbo.Store ON dbo.Items.Id = dbo.Store.ItemId where dbo.Store.ItemId='", itemIdComboBox.SelectedValue, "'"));
				textBox1.Text = dataTable.Rows[0][0].ToString();
				textBox3.Text = dataTable.Rows[0][1].ToString();
				BuyPrice = dataTable.Rows[0][2].ToString();
			}
			catch
			{
			}
		}

		private void AddBtn_Click(object sender, EventArgs e)
		{
			if (itemIdComboBox.SelectedIndex == -1)
			{
				MessageBox.Show("من فضلك ادخل اسم الصنف");
				return;
			}
			if (Convert.ToDecimal(textBox3.Text) < Convert.ToDecimal(BuyPrice))
			{
				MessageBox.Show("سعر البيع اقل من سعر الشراء");
				return;
			}
			if (txtQty.Text == "0")
			{
				MessageBox.Show("من فضلك ادخل الكمية");
				return;
			}
			if (Convert.ToDecimal(txtQty.Text) > Convert.ToDecimal(textBox1.Text))
			{
				MessageBox.Show("الكمية اكبر من المخزون");
				return;
			}
			bool flag = false;
			if (dataGridView1.Rows.Count == 0)
			{
				dataGridView1.Rows.Add(itemIdComboBox.Text, textBox3.Text, txtQty.Text, itemIdComboBox.SelectedValue.ToString());
				return;
			}
			for (int i = 0; i < dataGridView1.Rows.Count; i++)
			{
				if (itemIdComboBox.Text == dataGridView1.Rows[i].Cells[0].Value.ToString())
				{
					flag = true;
					break;
				}
			}
			if (flag)
			{
				MessageBox.Show("تم ادخال اسم الصنف قبل ");
				return;
			}
			dataGridView1.Rows.Add(itemIdComboBox.Text, textBox3.Text, txtQty.Text, itemIdComboBox.SelectedValue.ToString());
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (comboBox1.SelectedIndex == -1)
				{
					MessageBox.Show("من فضلك ادخل اسم المريض");
					return;
				}
				if (dataGridView1.Rows.Count == 0)
				{
					MessageBox.Show("من فضلك ادخل الاصناف");
					return;
				}
				double num = 0.0;
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					num += Convert.ToDouble(dataGridView1.Rows[i].Cells[1].Value) * Convert.ToDouble(dataGridView1.Rows[i].Cells[2].Value);
				}
				codes.Add2("insert into PatientAccount (PatientId, DoctorID, Bean, Price, Pay, Date, PricePay, BeanDate) values('" + patientId + "','" + doctorId + "','سحب كميات اصناف','" + num + "','False','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "',0,'" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "')");
				string text = codes.Search2("select max(ID) from PatientAccount").Rows[0][0].ToString();
				codes.Add2("insert into Sahb (PatientId, Date,PatientAccountId) values('" + patientId + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + text + "')");
				string text2 = codes.Search2("select max(ID) from Sahb").Rows[0][0].ToString();
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					codes.Add2("insert into Sahb_details (SahbId, ItemId, Price, Qty) values('" + text2 + "','" + dataGridView1.Rows[i].Cells[3].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[1].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "')");
					codes.Edit2("update Store set Qnt = Qnt - '" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "' where ItemId = '" + dataGridView1.Rows[i].Cells[3].Value.ToString() + "'");
					codes.Add2("insert into SahbItem (TypeSahb, ItemId, Qty, Date, Notes) values('استهلاك مرضى','" + dataGridView1.Rows[i].Cells[3].Value.ToString() + "','" + dataGridView1.Rows[i].Cells[2].Value.ToString() + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + comboBox1.Text + "')");
				}
				MessageBox.Show("تم حفظ البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				Close();
			}
			catch
			{
			}
		}
	}
}
