using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;

namespace DentistClinic
{
	public class SecretaryReserve : BaseForm
	{
		private ClassDataBase dc;

		private GUI gui = new GUI();

		private int id;

		private int patientId;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private dataClass codes = new dataClass(".\\sqlExpress");

		private int GridID;

		private int rowIndex = 0;

		private IContainer components = null;

		private GroupBox groupBox2;

		private Label label1;

		private DateTimePicker dateTimePicker1;

		private GroupBox groupBox1;

		private DataGridView dataGridView1;

		private Label label2;

		private ComboBox doctorcomboBox;

		private Button searchBtn;

		private Timer timer1;

		private Label label3;

		private Label label4;

		private Button button1;

		private Label label5;

		private GroupBox groupBox3;

		private Button button5;

		private Button button3;

		private Button button2;

		private DataSet1 dataSet11;

		private Button DeletBtn;

		private ComboBox comboBox2;

		private ContextMenuStrip contextMenuStrip1;

		private ToolStripMenuItem toolStripMenuItem_0;

		public SecretaryReserve()
		{
			InitializeComponent();
			dc = new ClassDataBase(".\\sqlExpress");
		}

		public void DataGrid(bool Prd)
		{
			string[] array = new string[3] { "ID", "detectDate", "Prd" };
			DataTable dataTable = codes.Search2("select ServiceName from Properties");
			new DataTable();
			if (doctorcomboBox.Text == "كل الأطباء" || doctorcomboBox.Text == "All Doctors")
			{
				if (codes.Search2("select AppointSystem from Properties").Rows[0][0].ToString() == "1")
				{
					codes.Search2("SELECT Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID' ,PatientData.FileNo, PatientData.Titel, PatientData.PName,'' As Services , PatientData.Tel, PatientData.Mob, PatientData.PAddress,PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes,PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy,PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime , '' as [Time] FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID INNER JOIN Empdata INNER JOIN Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID INNER JOIN PatientAccount ON Appointments.ID = PatientAccount.AppointNum WHERE (Appointments.detectDate = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "')   and (Appointments.Done='False' and  Appointments.Period='" + Prd + "') and PatientAccount.Bean ='" + dataTable.Rows[0][0].ToString() + "' and PatientData.Active = 'True' GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID,PatientData.FileNo, PatientData.Titel, PatientData.PName, PatientData.Tel, PatientData.Mob, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name,PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever,PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed,PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.Opretive, PatientData.Bleaching,Appointments.Status ,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime order by LEFT(Appointments.detectStartTime, 2),substring(Appointments.detectStartTime,4,2) asc");
				}
				else
				{
					codes.Search2("SELECT Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID' ,PatientData.FileNo, PatientData.Titel, PatientData.PName,'' As Services , PatientData.Tel, PatientData.Mob, PatientData.PAddress,PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes,PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy,PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime, '' as [Time] FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID INNER JOIN Empdata INNER JOIN Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID INNER JOIN PatientAccount ON Appointments.ID = PatientAccount.AppointNum WHERE (Appointments.detectDate = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "')   and (Appointments.Done='False' and  Appointments.Period='" + Prd + "') and PatientAccount.Bean ='" + dataTable.Rows[0][0].ToString() + "' and PatientData.Active = 'True' GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID,PatientData.FileNo, PatientData.Titel, PatientData.PName, PatientData.Tel, PatientData.Mob, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name,PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever,PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed,PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.Opretive, PatientData.Bleaching,Appointments.Status ,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime order by Appointments.appointNum asc");
				}
			}
			else if (codes.Search2("select AppointSystem from Properties").Rows[0][0].ToString() == "1")
			{
				codes.Search2("SELECT Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID' ,PatientData.FileNo, PatientData.Titel, PatientData.PName,'' As Services , PatientData.Tel, PatientData.Mob, PatientData.PAddress,PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes,PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy,PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime , '' as [Time] FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID INNER JOIN Empdata INNER JOIN Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID INNER JOIN PatientAccount ON Appointments.ID = PatientAccount.AppointNum WHERE (Empdata.ID = '" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "') AND (Appointments.detectDate = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "')   and (Appointments.Done='False' and  Appointments.Period='" + Prd + "') and PatientAccount.Bean ='" + dataTable.Rows[0][0].ToString() + "' and PatientData.Active = 'True' GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID,PatientData.FileNo, PatientData.Titel, PatientData.PName, PatientData.Tel, PatientData.Mob, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name,PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever,PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed,PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.Opretive, PatientData.Bleaching,Appointments.Status ,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime order by LEFT(Appointments.detectStartTime, 2),substring(Appointments.detectStartTime,4,2) asc");
			}
			else
			{
				codes.Search2("SELECT Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID' ,PatientData.FileNo, PatientData.Titel, PatientData.PName,'' As Services , PatientData.Tel, PatientData.Mob, PatientData.PAddress,PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes,PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy,PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime, '' as [Time] FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID INNER JOIN Empdata INNER JOIN Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID INNER JOIN PatientAccount ON Appointments.ID = PatientAccount.AppointNum WHERE (Empdata.ID = '" + Convert.ToInt32(doctorcomboBox.SelectedValue.ToString()) + "') AND (Appointments.detectDate = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "')   and (Appointments.Done='False' and  Appointments.Period='" + Prd + "') and PatientAccount.Bean ='" + dataTable.Rows[0][0].ToString() + "' and PatientData.Active = 'True' GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID,PatientData.FileNo, PatientData.Titel, PatientData.PName, PatientData.Tel, PatientData.Mob, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name,PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever,PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed,PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.Opretive, PatientData.Bleaching,Appointments.Status ,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime order by Appointments.appointNum asc");
			}
			if (Settings.Default.Language == "en-GB")
			{
				dataGridView1.Columns["PName"].HeaderText = "Patient Name";
				dataGridView1.Columns["PName"].Width = 150;
				dataGridView1.Columns["Services"].HeaderText = "Services";
				dataGridView1.Columns["Services"].Width = 150;
				dataGridView1.Columns[1].HeaderText = "Appointment No.";
				dataGridView1.Columns[1].Width = 100;
				dataGridView1.Columns["ID"].HeaderText = "Appointment Code";
				dataGridView1.Columns["Doctor ID"].Visible = false;
				dataGridView1.Columns["Patient ID"].Visible = false;
				dataGridView1.Columns["PAddress"].HeaderText = "Patient Address";
				dataGridView1.Columns["PAddress"].Width = 200;
				dataGridView1.Columns["BirthDate"].HeaderText = "Birth Date";
				dataGridView1.Columns["Tel"].HeaderText = "Phone";
				dataGridView1.Columns["Mob"].HeaderText = "Mobile";
				dataGridView1.Columns["Price"].HeaderText = "Price";
				dataGridView1.Columns["Time"].HeaderText = "Time";
				dataGridView1.Columns["ID"].HeaderText = "Appointment Code";
				dataGridView1.Columns["FileNo"].HeaderText = "File Number";
			}
			else
			{
				dataGridView1.Columns["PName"].HeaderText = "اسم المريض";
				dataGridView1.Columns["PName"].Width = 150;
				dataGridView1.Columns["Services"].HeaderText = "الخدمات";
				dataGridView1.Columns["Services"].Width = 150;
				dataGridView1.Columns[1].HeaderText = "رقم الكشف";
				dataGridView1.Columns[1].Width = 100;
				dataGridView1.Columns["ID"].HeaderText = "كود الكشف";
				dataGridView1.Columns["Doctor ID"].Visible = false;
				dataGridView1.Columns["Patient ID"].Visible = false;
				dataGridView1.Columns["PAddress"].HeaderText = "عنوان المريض";
				dataGridView1.Columns["PAddress"].Width = 200;
				dataGridView1.Columns["BirthDate"].HeaderText = "تاريخ الميلاد";
				dataGridView1.Columns["Tel"].HeaderText = "التليفون";
				dataGridView1.Columns["Mob"].HeaderText = "الموبايل";
				dataGridView1.Columns["Price"].HeaderText = "سعر الحجز";
				dataGridView1.Columns["Time"].HeaderText = "وقت الكشف";
				dataGridView1.Columns["FileNo"].HeaderText = "كود المريض";
			}
			try
			{
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					string text = "";
					DataTable dataTable2 = codes.Search2("select  Bean from ReserveService where AppointNum='" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "'");
					for (int j = 0; j < dataTable2.Rows.Count; j++)
					{
						text = ((!(text == "")) ? (text + " - " + dataTable2.Rows[j][0].ToString()) : dataTable2.Rows[j][0].ToString());
					}
					dataGridView1.Rows[i].Cells["Services"].Value = text;
				}
			}
			catch
			{
			}
			dataGridView1.Columns["Status"].Visible = false;
			if (Settings.Default.Language == "en-GB")
			{
				foreach (DataGridViewRow item in (IEnumerable)dataGridView1.Rows)
				{
					if (item.Cells["Status"].Value.ToString() == "Confirmed")
					{
						item.DefaultCellStyle.BackColor = Color.FromArgb(187, 240, 188);
					}
					else if (item.Cells["Status"].Value.ToString() == "Not Confirmed")
					{
						item.DefaultCellStyle.BackColor = Color.FromArgb(201, 226, 245);
					}
					else if (item.Cells["Status"].Value.ToString() == "Cancelled")
					{
						item.DefaultCellStyle.BackColor = Color.FromArgb(240, 209, 200);
					}
					else if (item.Cells["Status"].Value.ToString() == "Done")
					{
						item.DefaultCellStyle.BackColor = Color.Beige;
					}
					string value = "From " + item.Cells["detectStartTime"].Value.ToString() + " To  " + item.Cells["detectEndTime"].Value.ToString();
					item.Cells["Time"].Value = value;
				}
			}
			else
			{
				foreach (DataGridViewRow item2 in (IEnumerable)dataGridView1.Rows)
				{
					if (item2.Cells["Status"].Value.ToString() == "تم التأكيد")
					{
						item2.DefaultCellStyle.BackColor = Color.FromArgb(187, 240, 188);
					}
					else if (item2.Cells["Status"].Value.ToString() == "لم يؤكد")
					{
						item2.DefaultCellStyle.BackColor = Color.FromArgb(201, 226, 245);
					}
					else if (item2.Cells["Status"].Value.ToString() == "تم إلغاؤه")
					{
						item2.DefaultCellStyle.BackColor = Color.FromArgb(240, 209, 200);
					}
					else if (item2.Cells["Status"].Value.ToString() == "تم الكشف")
					{
						item2.DefaultCellStyle.BackColor = Color.Beige;
					}
					string value = "من " + item2.Cells["detectStartTime"].Value.ToString() + " الى  " + item2.Cells["detectEndTime"].Value.ToString();
					item2.Cells["Time"].Value = value;
				}
			}
			dataGridView1.Columns["detectStartTime"].Visible = false;
			dataGridView1.Columns["detectEndTime"].Visible = false;
			dataGridView1.Columns[12].Visible = false;
			dataGridView1.Columns[13].Visible = false;
			dataGridView1.Columns[14].Visible = false;
			dataGridView1.Columns[15].Visible = false;
			dataGridView1.Columns[16].Visible = false;
			dataGridView1.Columns[17].Visible = false;
			dataGridView1.Columns[18].Visible = false;
			dataGridView1.Columns[19].Visible = false;
			dataGridView1.Columns[20].Visible = false;
			dataGridView1.Columns[21].Visible = false;
			dataGridView1.Columns[22].Visible = false;
			dataGridView1.Columns[23].Visible = false;
			dataGridView1.Columns[24].Visible = false;
			dataGridView1.Columns[25].Visible = false;
			dataGridView1.Columns[26].Visible = false;
			dataGridView1.Columns[27].Visible = false;
			dataGridView1.Columns[28].Visible = false;
			dataGridView1.Columns[29].Visible = false;
			dataGridView1.Columns[30].Visible = false;
			dataGridView1.Columns[31].Visible = false;
			dataGridView1.Columns[32].Visible = false;
			dataGridView1.Columns[33].Visible = false;
			dataGridView1.Columns[34].Visible = false;
			dataGridView1.Columns[35].Visible = false;
			dataGridView1.Columns[36].Visible = false;
			dataGridView1.Columns["Time"].Width = 150;
		}

		public void Doctor(bool Prd)
		{
			try
			{
				string[] array = new string[3] { "ID", "detectDate", "Prd" };
				DataTable dataTable = codes.Search2("select ServiceName from Properties");
				DataTable dataTable2 = new DataTable();
				dataTable2 = ((doctorcomboBox.Text == "كل الأطباء" || doctorcomboBox.Text == "All Doctors") ? ((!(codes.Search2("select AppointSystem from Properties").Rows[0][0].ToString() == "1")) ? codes.Search2("SELECT Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID' ,PatientData.FileNo, PatientData.Titel, PatientData.PName,'' As Services , PatientData.Tel, PatientData.Mob, PatientData.PAddress,PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes,PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy,PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime , '' as [Time] FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID INNER JOIN Empdata INNER JOIN Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID INNER JOIN PatientAccount ON Appointments.ID = PatientAccount.AppointNum WHERE (Appointments.detectDate = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "')   and (Appointments.Done='False' and  Appointments.Period='" + Prd + "') and PatientAccount.Bean ='" + dataTable.Rows[0][0].ToString() + "' and PatientData.Active = 'True' GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID,PatientData.FileNo, PatientData.Titel, PatientData.PName, PatientData.Tel, PatientData.Mob, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name,PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever,PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed,PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.Opretive, PatientData.Bleaching,Appointments.Status ,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime order by Appointments.appointNum asc") : codes.Search2("SELECT Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID',PatientData.FileNo, PatientData.Titel, PatientData.PName,'' As Services , PatientData.Tel, PatientData.Mob, PatientData.PAddress,PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes,PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy,PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime, '' as [Time] FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID INNER JOIN Empdata INNER JOIN Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID INNER JOIN PatientAccount ON Appointments.ID = PatientAccount.AppointNum WHERE (Appointments.detectDate = '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "')   and (Appointments.Done='False' and  Appointments.Period='" + Prd + "') and PatientAccount.Bean ='" + dataTable.Rows[0][0].ToString() + "' and PatientData.Active = 'True' GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID,PatientData.FileNo, PatientData.Titel, PatientData.PName, PatientData.Tel, PatientData.Mob, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name,PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever,PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed,PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.Opretive, PatientData.Bleaching,Appointments.Status ,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime order by LEFT(Appointments.detectStartTime, 2),substring(Appointments.detectStartTime,4,2) asc")) : ((!(codes.Search2("select AppointSystem from Properties").Rows[0][0].ToString() == "1")) ? codes.Search2(string.Concat("SELECT Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID' ,PatientData.FileNo, PatientData.Titel, PatientData.PName,'' As Services , PatientData.Tel, PatientData.Mob, PatientData.PAddress,PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes,PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy,PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime , '' as [Time] FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID INNER JOIN Empdata INNER JOIN Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID INNER JOIN PatientAccount ON Appointments.ID = PatientAccount.AppointNum WHERE (Empdata.ID = '", doctorcomboBox.SelectedValue, "') AND (Appointments.detectDate = '", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "')   and (Appointments.Done='False' and  Appointments.Period='", Prd, "') and PatientAccount.Bean ='", dataTable.Rows[0][0].ToString(), "' and PatientData.Active = 'True' GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID,PatientData.FileNo, PatientData.Titel, PatientData.PName, PatientData.Tel, PatientData.Mob, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name,PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever,PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed,PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.Opretive, PatientData.Bleaching,Appointments.Status ,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime order by Appointments.appointNum asc")) : codes.Search2(string.Concat("SELECT Appointments.ID, Appointments.AppointNum, Empdata.ID AS 'Doctor ID', PatientData.ID AS 'Patient ID' ,PatientData.FileNo, PatientData.Titel, PatientData.PName,'' As Services , PatientData.Tel, PatientData.Mob, PatientData.PAddress,PatientData.BirthDate, PatientData.LastVistDate, Company.Name, PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes,PatientData.RheumaticFever, PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed, PatientData.PeriodontalTherpy,PatientData.Implant, PatientData.Opretive, PatientData.Bleaching, PatientData.PrviousHistoryOthers,Appointments.Status,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime, '' as [Time] FROM PatientData INNER JOIN Company ON PatientData.company = Company.ID INNER JOIN Empdata INNER JOIN Appointments ON Empdata.ID = Appointments.DoctorID ON PatientData.ID = Appointments.PatuentID INNER JOIN PatientAccount ON Appointments.ID = PatientAccount.AppointNum WHERE (Empdata.ID = '", doctorcomboBox.SelectedValue, "') AND (Appointments.detectDate = '", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "')   and (Appointments.Done='False' and  Appointments.Period='", Prd, "') and PatientAccount.Bean ='", dataTable.Rows[0][0].ToString(), "' and PatientData.Active = 'True' GROUP BY Appointments.ID, Appointments.AppointNum, Empdata.ID, PatientData.ID,PatientData.FileNo, PatientData.Titel, PatientData.PName, PatientData.Tel, PatientData.Mob, PatientData.PAddress, PatientData.BirthDate, PatientData.LastVistDate, Company.Name,PatientData.Allergies, PatientData.CardiacDisease, PatientData.KidneyDesease, PatientData.Diabetes, PatientData.RheumaticFever,PatientData.Asthma, PatientData.BloodDyscrasias, PatientData.HistoryOther, PatientData.Extraction, PatientData.Endodontics, PatientData.Fixed,PatientData.PeriodontalTherpy, PatientData.Implant, PatientData.PrviousHistoryOthers, PatientData.Lactating, PatientData.Pregnant, PatientData.HepatitisB,PatientData.Hepatitisc, PatientData.Opretive, PatientData.Bleaching,Appointments.Status ,NextVisit,Appointments.Accepted,PatientAccount.Price,Appointments.detectStartTime,detectEndTime order by LEFT(Appointments.detectStartTime, 2),substring(Appointments.detectStartTime,4,2) asc"))));
				gui.loadDataGrid(dataGridView1, dataTable2);
				DataGrid(Prd);
				if (dataGridView1.Rows.Count > 0)
				{
					if (Settings.Default.Language == "en-GB")
					{
						label3.Text = "Number Of Reservations: " + Convert.ToString(dataGridView1.Rows.Count.ToString());
						label4.Text = "Patient Name:" + Convert.ToString(dataTable2.Rows[0]["PName"].ToString());
					}
					else
					{
						label3.Text = "عدد الحجوزات : " + Convert.ToString(dataGridView1.Rows.Count.ToString());
						label4.Text = "اسم المريض :" + Convert.ToString(dataTable2.Rows[0]["PName"].ToString());
					}
				}
				else if (Settings.Default.Language == "en-GB")
				{
					label3.Text = "No Reservation";
					label4.Text = "";
				}
				else
				{
					label3.Text = "لا يوجد حجز";
					label4.Text = "";
				}
			}
			catch
			{
			}
		}

		private void SecretaryReserve_Load(object sender, EventArgs e)
		{
			MethodsClass.UserMove("الدخول الي قائمه الكشف");
			try
			{
				DataTable dataTable = new DataTable();
				dataTable = dc.Select("SelectAllDoctor");
				DataRow dataRow = dataTable.NewRow();
				if (Settings.Default.Language == "en-GB")
				{
					dataRow["Name"] = "All Doctors";
				}
				else
				{
					dataRow["Name"] = "كل الأطباء";
				}
				dataTable.Rows.InsertAt(dataRow, 0);
				doctorcomboBox.DataSource = dataTable;
				doctorcomboBox.DisplayMember = dataTable.Columns[1].ToString();
				doctorcomboBox.ValueMember = dataTable.Columns[0].ToString();
			}
			catch
			{
			}
			comboBox2.SelectedIndex = 0;
		}

		private void searchBtn_Click(object sender, EventArgs e)
		{
			bool prd = false;
			dataGridView1.DataSource = null;
			if (comboBox2.SelectedIndex == 1)
			{
				prd = true;
			}
			Doctor(prd);
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			bool prd = false;
			if (comboBox2.SelectedIndex == 1)
			{
				prd = true;
			}
			Doctor(prd);
		}

		private void SecretaryReserve_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.F1)
			{
				Process.Start("calc");
			}
		}

		private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					Appointments appointments = new Appointments(Convert.ToDecimal(dataGridView1.CurrentRow.Cells[0].Value.ToString()));
					appointments.ShowDialog();
					bool prd = false;
					dataGridView1.DataSource = null;
					if (comboBox2.SelectedIndex == 1)
					{
						prd = true;
					}
					Doctor(prd);
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Select Data First", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("من فضلك اختر بيانات اولا", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count == 1)
				{
					if (Settings.Default.Language == "en-GB")
					{
						codes.Edit2("update Appointments set Status='Done' where id='" + dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + "'");
					}
					else
					{
						codes.Edit2("update Appointments set Status='تم الكشف' where id='" + dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + "'");
					}
					bool prd = false;
					if (comboBox2.SelectedIndex == 1)
					{
						prd = true;
					}
					Doctor(prd);
				}
				else if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please select Patient");
				}
				else
				{
					MessageBox.Show("من فضلك اختر مريض");
				}
			}
			catch
			{
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = (DataTable)dataGridView1.DataSource;
				int index = dataGridView1.SelectedRows[0].Index;
				if (index > 0)
				{
					DataRow dataRow = dataTable.NewRow();
					dataRow.ItemArray = dataTable.Rows[index].ItemArray;
					dataTable.Rows.Remove(dataTable.Rows[index]);
					dataTable.Rows.InsertAt(dataRow, index - 1);
					dataGridView1.DataSource = dataTable;
					for (int i = 0; i < dataGridView1.Rows.Count; i++)
					{
						codes.Edit2("update Appointments set AppointNum = '" + (i + 1) + "' where ID='" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "'");
					}
					bool prd = false;
					if (comboBox2.SelectedIndex == 1)
					{
						prd = true;
					}
					Doctor(prd);
					dataGridView1.Rows[0].Selected = false;
					dataGridView1.Rows[index - 1].Selected = true;
				}
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = (DataTable)dataGridView1.DataSource;
				int index = dataGridView1.SelectedRows[0].Index;
				if (index < dataGridView1.Rows.Count)
				{
					DataRow dataRow = dataTable.NewRow();
					dataRow.ItemArray = dataTable.Rows[index].ItemArray;
					dataTable.Rows.Remove(dataTable.Rows[index]);
					dataTable.Rows.InsertAt(dataRow, index + 1);
					dataGridView1.DataSource = dataTable;
					for (int i = 0; i < dataGridView1.Rows.Count; i++)
					{
						codes.Edit2("update Appointments set AppointNum = '" + (i + 1) + "' where ID='" + dataGridView1.Rows[i].Cells[0].Value.ToString() + "'");
					}
					bool prd = false;
					if (comboBox2.SelectedIndex == 1)
					{
						prd = true;
					}
					Doctor(prd);
					dataGridView1.Rows[0].Selected = false;
					dataGridView1.Rows[index + 1].Selected = true;
				}
			}
			catch
			{
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			try
			{
				dataSet11.Clear();
				((DataTable)(object)dataSet11.ReportData).Rows.Add(1, doctorcomboBox.Text, dateTimePicker1.Value, dateTimePicker1.Value);
				for (int i = 0; i < dataGridView1.Rows.Count; i++)
				{
					DataTable dataTable = new DataTable();
					dataTable = ((!(doctorcomboBox.Text == "كل الأطباء") && !(doctorcomboBox.Text == "All Doctors")) ? codes.Search2(string.Concat("SELECT detectDate, packDate, Price FROM Appointments where AppointNum ='", dataGridView1.Rows[i].Cells["AppointNum"].Value.ToString(), "' and DoctorID ='", doctorcomboBox.SelectedValue, "' and detectDate ='", dateTimePicker1.Value.ToString("MM/dd/yyyy"), "'")) : codes.Search2("SELECT detectDate, packDate, Price FROM Appointments where AppointNum ='" + dataGridView1.Rows[i].Cells["AppointNum"].Value.ToString() + "' and detectDate ='" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "'"));
					DataTable dataTable2 = codes.Search2("select isnull(sum(Price),0), isnull(sum(PricePay),0), isnull((sum(Price)-sum(PricePay)),0) from PatientAccount where PatientId='" + dataGridView1.Rows[i].Cells["Patient ID"].Value.ToString() + "' and Appears='True'");
					DataTable dataTable3 = codes.Search2("SELECT        PatientAccount.Bean ,Teath.Name AS Expr1\r\nFROM            PatientAccount INNER JOIN\r\n                         Teath ON PatientAccount.TeathId = Teath.Id where PatientId='" + dataGridView1.Rows[i].Cells["Patient ID"].Value.ToString() + "'  and Appears='True'");
					string text = "";
					decimal num = 0m;
					decimal num2 = 0m;
					decimal num3 = 0m;
					num = Convert.ToDecimal(dataTable2.Rows[0][0].ToString());
					num2 = Convert.ToDecimal(dataTable2.Rows[0][1].ToString());
					num3 = Convert.ToDecimal(dataTable2.Rows[0][2].ToString());
					for (int j = 0; j < dataTable3.Rows.Count; j++)
					{
						if (j == 0)
						{
							text = text + dataTable3.Rows[j][0].ToString() + " " + dataTable3.Rows[j][1].ToString();
							continue;
						}
						string text2 = text;
						text = text2 + " / " + dataTable3.Rows[j][0].ToString() + " " + dataTable3.Rows[j][1].ToString();
					}
					bool flag;
					try
					{
						flag = Convert.ToBoolean(dataGridView1.Rows[i].Cells["Accepted"].Value.ToString());
					}
					catch
					{
						flag = false;
					}
					((DataTable)(object)dataSet11.RptReserve).Rows.Add(dataGridView1.Rows[i].Cells["AppointNum"].Value.ToString(), dataGridView1.Rows[i].Cells["Titel"].Value.ToString(), dataGridView1.Rows[i].Cells["PName"].Value.ToString(), dataGridView1.Rows[i].Cells["PAddress"].Value.ToString(), Convert.ToDateTime(dataTable.Rows[0][0].ToString()), Convert.ToDateTime(dataTable.Rows[0][1].ToString()), dataTable.Rows[0][2].ToString(), dataGridView1.Rows[i].Cells["Name"].Value.ToString(), num, num2, num3, flag, dataGridView1.Rows[i].Cells["Services"].Value.ToString());
				}
				FrmRptReserve frmRptReserve = new FrmRptReserve(dataSet11);
				frmRptReserve.ShowDialog();
			}
			catch
			{
			}
		}

		private void DeletBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataGridView1.SelectedRows.Count > 0)
				{
					string[] fields;
					string text;
					DataTable dataTable;
					if (Settings.Default.Language == "en-GB")
					{
						if (MessageBox.Show("Are you Sure You Want To Delete", "Notes", MessageBoxButtons.OKCancel) != DialogResult.OK)
						{
							return;
						}
						fields = new string[1] { "id" };
						codes.Search2("select * from Appointments where id='" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'");
						text = codes.Search2("select PricePay from dbo.PatientAccount where AppointNum ='" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'").Rows[0][0].ToString();
						dataTable = codes.Search2("select StockId from dbo.PatientAccount where AppointNum ='" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "' and StockId is not null");
						if (dc.Delete("DeleteAppointment", fields, dataGridView1.Rows[GridID].Cells["ID"].Value.ToString()))
						{
							codes.Delete2("delete from PatientAccount where AppointNum = '" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'");
							if (Convert.ToDecimal(text) > 0m)
							{
								codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('حذف كشف' ," + text + ",'" + dataGridView1.Rows[GridID].Cells["PName"].Value.ToString() + "','" + DateTime.Today.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(dataTable.Rows[0][0].ToString()) + "')");
								codes.Edit2("update Stock Set Value= Value - " + text + " where ID = '" + Convert.ToInt32(dataTable.Rows[0][0].ToString()) + "'");
							}
							MessageBox.Show("Data Delete Successfully", "Notes", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							bool prd = false;
							if (comboBox2.SelectedIndex == 1)
							{
								prd = true;
							}
							Doctor(prd);
						}
						else
						{
							MessageBox.Show("Error Happend While Delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
						}
						return;
					}
					if (MessageBox.Show("هل أنت متأكد من حذف هذه البيانات ؟", "تأكيد", MessageBoxButtons.OKCancel) != DialogResult.OK)
					{
						return;
					}
					fields = new string[1] { "id" };
					codes.Search2("select * from Appointments where id='" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'");
					text = codes.Search2("select PricePay from dbo.PatientAccount where AppointNum ='" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'").Rows[0][0].ToString();
					dataTable = codes.Search2("select StockId from dbo.PatientAccount where AppointNum ='" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "' and StockId is not null");
					if (dc.Delete("DeleteAppointment", fields, dataGridView1.Rows[GridID].Cells["ID"].Value.ToString()))
					{
						codes.Delete2("delete from PatientAccount where AppointNum = '" + dataGridView1.Rows[GridID].Cells["ID"].Value.ToString() + "'");
						if (Convert.ToDecimal(text) > 0m)
						{
							codes.Add2("insert into StokeMove ( Type,Price,bean,[date],StockId ) values ('حذف كشف' ," + text + ",'" + dataGridView1.Rows[GridID].Cells["PName"].Value.ToString() + "','" + DateTime.Today.ToString("MM/dd/yyyy") + "','" + Convert.ToInt32(dataTable.Rows[0][0].ToString()) + "')");
							codes.Edit2("update Stock Set Value= Value - " + text + " where ID = '" + Convert.ToInt32(dataTable.Rows[0][0].ToString()) + "'");
						}
						MessageBox.Show("تم حذف البيانات بنجاح", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						bool prd = false;
						if (comboBox2.SelectedIndex == 1)
						{
							prd = true;
						}
						Doctor(prd);
					}
					else
					{
						MessageBox.Show("حدث خطأ أثناء حذف البيانات", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					return;
				}
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Please Enter Data");
				}
				else
				{
					MessageBox.Show("من فضلك اختر سجل");
				}
			}
			catch
			{
			}
		}

		private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			try
			{
				GridID = dataGridView1.CurrentRow.Index;
			}
			catch
			{
			}
		}

		private void dataGridView1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				dataGridView1.Rows[e.RowIndex].Selected = true;
				rowIndex = e.RowIndex;
				dataGridView1.CurrentCell = dataGridView1.Rows[e.RowIndex].Cells[1];
				id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value);
				patientId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[3].Value);
				contextMenuStrip1.Show(dataGridView1, e.Location);
				contextMenuStrip1.Show(Cursor.Position);
			}
		}

		private void contextMenuStrip1_Click(object sender, EventArgs e)
		{
			DataTable dataTable = codes.Search2("select ServiceName from Properties");
			DataTable dt = codes.Search2("select Bean,Price from ReserveService where AppointNum = '" + id + "' and Bean != '" + dataTable.Rows[0][0].ToString() + "'");
			FrmAddServices frmAddServices = new FrmAddServices(patientId, dt);
			frmAddServices.ShowDialog();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.SecretaryReserve));
			groupBox2 = new System.Windows.Forms.GroupBox();
			searchBtn = new System.Windows.Forms.Button();
			doctorcomboBox = new System.Windows.Forms.ComboBox();
			comboBox2 = new System.Windows.Forms.ComboBox();
			dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			label2 = new System.Windows.Forms.Label();
			label1 = new System.Windows.Forms.Label();
			groupBox1 = new System.Windows.Forms.GroupBox();
			dataGridView1 = new System.Windows.Forms.DataGridView();
			timer1 = new System.Windows.Forms.Timer(components);
			label3 = new System.Windows.Forms.Label();
			label4 = new System.Windows.Forms.Label();
			button1 = new System.Windows.Forms.Button();
			label5 = new System.Windows.Forms.Label();
			groupBox3 = new System.Windows.Forms.GroupBox();
			button5 = new System.Windows.Forms.Button();
			button3 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			dataSet11 = new DataSet1();
			DeletBtn = new System.Windows.Forms.Button();
			contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(components);
			toolStripMenuItem_0 = new System.Windows.Forms.ToolStripMenuItem();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			groupBox2.SuspendLayout();
			groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
			groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			contextMenuStrip1.SuspendLayout();
			SuspendLayout();
			resources.ApplyResources(label, "label7");
			label.Name = "label7";
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(searchBtn);
			groupBox2.Controls.Add(doctorcomboBox);
			groupBox2.Controls.Add(comboBox2);
			groupBox2.Controls.Add(dateTimePicker1);
			groupBox2.Controls.Add(label);
			groupBox2.Controls.Add(label2);
			groupBox2.Controls.Add(label1);
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			resources.ApplyResources(searchBtn, "searchBtn");
			searchBtn.BackColor = System.Drawing.Color.Gainsboro;
			searchBtn.Name = "searchBtn";
			searchBtn.UseVisualStyleBackColor = false;
			searchBtn.Click += new System.EventHandler(searchBtn_Click);
			resources.ApplyResources(doctorcomboBox, "doctorcomboBox");
			doctorcomboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			doctorcomboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			doctorcomboBox.FormattingEnabled = true;
			doctorcomboBox.Name = "doctorcomboBox";
			comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			resources.ApplyResources(comboBox2, "comboBox2");
			comboBox2.FormattingEnabled = true;
			comboBox2.Items.AddRange(new object[2]
			{
				resources.GetString("comboBox2.Items"),
				resources.GetString("comboBox2.Items1")
			});
			comboBox2.Name = "comboBox2";
			resources.ApplyResources(dateTimePicker1, "dateTimePicker1");
			dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			dateTimePicker1.Name = "dateTimePicker1";
			resources.ApplyResources(label2, "label2");
			label2.Name = "label2";
			resources.ApplyResources(label1, "label1");
			label1.Name = "label1";
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.Controls.Add(dataGridView1);
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			dataGridView1.AllowUserToAddRows = false;
			dataGridView1.AllowUserToDeleteRows = false;
			dataGridView1.BackgroundColor = System.Drawing.Color.WhiteSmoke;
			dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			resources.ApplyResources(dataGridView1, "dataGridView1");
			dataGridView1.Name = "dataGridView1";
			dataGridView1.ReadOnly = true;
			dataGridView1.RowTemplate.Height = 30;
			dataGridView1.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_CellMouseUp);
			dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseDoubleClick);
			dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(dataGridView1_RowHeaderMouseClick);
			timer1.Interval = 3000;
			timer1.Tick += new System.EventHandler(timer1_Tick);
			resources.ApplyResources(label3, "label3");
			label3.BackColor = System.Drawing.Color.Transparent;
			label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			label3.ForeColor = System.Drawing.Color.Maroon;
			label3.Name = "label3";
			resources.ApplyResources(label4, "label4");
			label4.BackColor = System.Drawing.Color.Transparent;
			label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			label4.ForeColor = System.Drawing.Color.Maroon;
			label4.Name = "label4";
			resources.ApplyResources(button1, "button1");
			button1.Name = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			label5.BackColor = System.Drawing.Color.Beige;
			resources.ApplyResources(label5, "label5");
			label5.Name = "label5";
			groupBox3.BackColor = System.Drawing.Color.Transparent;
			groupBox3.Controls.Add(button5);
			groupBox3.Controls.Add(button3);
			groupBox3.Controls.Add(button2);
			resources.ApplyResources(groupBox3, "groupBox3");
			groupBox3.Name = "groupBox3";
			groupBox3.TabStop = false;
			resources.ApplyResources(button5, "button5");
			button5.Name = "button5";
			button5.UseVisualStyleBackColor = true;
			button5.Click += new System.EventHandler(button5_Click);
			resources.ApplyResources(button3, "button3");
			button3.FlatAppearance.BorderSize = 0;
			button3.Name = "button3";
			button3.UseVisualStyleBackColor = true;
			button3.Click += new System.EventHandler(button3_Click);
			resources.ApplyResources(button2, "button2");
			button2.FlatAppearance.BorderSize = 0;
			button2.Name = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			resources.ApplyResources(DeletBtn, "DeletBtn");
			DeletBtn.BackColor = System.Drawing.Color.Gainsboro;
			DeletBtn.Name = "DeletBtn";
			DeletBtn.UseVisualStyleBackColor = false;
			DeletBtn.Click += new System.EventHandler(DeletBtn_Click);
			contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { toolStripMenuItem_0 });
			contextMenuStrip1.Name = "contextMenuStrip1";
			resources.ApplyResources(contextMenuStrip1, "contextMenuStrip1");
			contextMenuStrip1.Click += new System.EventHandler(contextMenuStrip1_Click);
			toolStripMenuItem_0.Name = "خدماتالمريضToolStripMenuItem";
			resources.ApplyResources(toolStripMenuItem_0, "خدماتالمريضToolStripMenuItem");
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.LightSteelBlue;
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox3);
			base.Controls.Add(label4);
			base.Controls.Add(label3);
			base.Controls.Add(DeletBtn);
			base.Controls.Add(groupBox2);
			base.Controls.Add(label5);
			base.Controls.Add(button1);
			base.Name = "SecretaryReserve";
			base.Load += new System.EventHandler(SecretaryReserve_Load);
			base.KeyDown += new System.Windows.Forms.KeyEventHandler(SecretaryReserve_KeyDown);
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
			groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			contextMenuStrip1.ResumeLayout(false);
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
