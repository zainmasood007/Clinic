using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using FloatTextBox;

namespace DentistClinic
{
	public class FrmDiscountPoints : BaseForm
	{
		private dataClass codes = new dataClass(".\\sqlExpress");

		private GUI gui = new GUI();

		private ClassDataBase dc = new ClassDataBase(".\\sqlExpress");

		private GeneralMethods MethodsClass = new GeneralMethods();

		private IContainer components = null;

		private Button saveBtn;

		private GroupBox groupBox5;

		private FloatText txtQty;

		private FloatText floatText1;

		private ComboBox PatientComboBox;

		public FrmDiscountPoints()
		{
			InitializeComponent();
		}

		private void FrmDiscountPoints_Load(object sender, EventArgs e)
		{
			DataTable dt = new DataTable();
			try
			{
				DataTable dataTable = new DataTable();
				if (Convert.ToBoolean(codes.Search2("Select PatientNameArggement from Properties").Rows[0][0].ToString()))
				{
					dataTable = dc.GetTableText("SELECT     ID, PName FROM         PatientData where Active = 'True' order by PName");
					PatientComboBox.DataSource = dataTable;
					PatientComboBox.DisplayMember = dataTable.Columns[1].ToString();
					PatientComboBox.ValueMember = dataTable.Columns[0].ToString();
				}
				else
				{
					dataTable = dc.Select("SelectAllPatient");
					gui.loadComboBox(PatientComboBox, dt);
				}
			}
			catch
			{
			}
			try
			{
				DataTable dataTable2 = codes.Search2(string.Concat("select isnull(sum(PointAdd)-sum(PointDiscount),0) from Points where PatientId='", PatientComboBox.SelectedValue, "'"));
				floatText1.Text = Math.Round(Convert.ToDecimal(dataTable2.Rows[0][0]), 2).ToString();
			}
			catch
			{
			}
		}

		private void PatientComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				DataTable dataTable = codes.Search2(string.Concat("select isnull(sum(PointAdd)-sum(PointDiscount),0) from Points where PatientId='", PatientComboBox.SelectedValue, "'"));
				floatText1.Text = Math.Round(Convert.ToDecimal(dataTable.Rows[0][0]), 2).ToString();
			}
			catch
			{
			}
		}

		private void saveBtn_Click(object sender, EventArgs e)
		{
			try
			{
				if (txtQty.Text == "0" || txtQty.Text == "")
				{
					if (Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please enter Points Number");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل عدد النقاط");
					}
					return;
				}
				codes.Add(string.Concat("insert into Points(PatientId, PointAdd, PointDiscount, Date) values('", PatientComboBox.SelectedValue, "',0,'", txtQty.Text, "','", DateTime.Now.ToString("MM/dd/yyyy"), "')"));
				MethodsClass.UserMove("أستخدام نقاط مريض");
				PatientComboBox_SelectedIndexChanged(sender, e);
				txtQty.Text = "0";
			}
			catch
			{
			}
		}

		private void txtQty_TextChanged(object sender, EventArgs e)
		{
			if (Convert.ToDouble(txtQty.Text) > Convert.ToDouble(floatText1.Text))
			{
				if (Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("The number of points used is greater than the patient's balance");
				}
				else
				{
					MessageBox.Show("عدد النقاط المستخدمة اكبر من رصيد المريض");
				}
				txtQty.Text = "0";
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.FrmDiscountPoints));
			saveBtn = new System.Windows.Forms.Button();
			groupBox5 = new System.Windows.Forms.GroupBox();
			floatText1 = new FloatTextBox.FloatText();
			PatientComboBox = new System.Windows.Forms.ComboBox();
			txtQty = new FloatTextBox.FloatText();
			System.Windows.Forms.Label label = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label2 = new System.Windows.Forms.Label();
			System.Windows.Forms.Label label3 = new System.Windows.Forms.Label();
			groupBox5.SuspendLayout();
			SuspendLayout();
			label.AccessibleDescription = null;
			label.AccessibleName = null;
			resources.ApplyResources(label, "nameLabel");
			label.Name = "nameLabel";
			label2.AccessibleDescription = null;
			label2.AccessibleName = null;
			resources.ApplyResources(label2, "titelLabel");
			label2.Name = "titelLabel";
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label1");
			label3.Name = "label1";
			saveBtn.AccessibleDescription = null;
			saveBtn.AccessibleName = null;
			resources.ApplyResources(saveBtn, "saveBtn");
			saveBtn.BackColor = System.Drawing.Color.Gainsboro;
			saveBtn.BackgroundImage = null;
			saveBtn.Name = "saveBtn";
			saveBtn.UseVisualStyleBackColor = false;
			saveBtn.Click += new System.EventHandler(saveBtn_Click);
			groupBox5.AccessibleDescription = null;
			groupBox5.AccessibleName = null;
			resources.ApplyResources(groupBox5, "groupBox5");
			groupBox5.BackColor = System.Drawing.Color.Transparent;
			groupBox5.BackgroundImage = null;
			groupBox5.Controls.Add(floatText1);
			groupBox5.Controls.Add(label3);
			groupBox5.Controls.Add(PatientComboBox);
			groupBox5.Controls.Add(txtQty);
			groupBox5.Controls.Add(label2);
			groupBox5.Controls.Add(label);
			groupBox5.Font = null;
			groupBox5.Name = "groupBox5";
			groupBox5.TabStop = false;
			floatText1.AccessibleDescription = null;
			floatText1.AccessibleName = null;
			resources.ApplyResources(floatText1, "floatText1");
			floatText1.BackgroundImage = null;
			floatText1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			floatText1.Font = null;
			floatText1.Name = "floatText1";
			floatText1.ReadOnly = true;
			PatientComboBox.AccessibleDescription = null;
			PatientComboBox.AccessibleName = null;
			resources.ApplyResources(PatientComboBox, "PatientComboBox");
			PatientComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			PatientComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			PatientComboBox.BackgroundImage = null;
			PatientComboBox.FormattingEnabled = true;
			PatientComboBox.Name = "PatientComboBox";
			PatientComboBox.SelectedIndexChanged += new System.EventHandler(PatientComboBox_SelectedIndexChanged);
			txtQty.AccessibleDescription = null;
			txtQty.AccessibleName = null;
			resources.ApplyResources(txtQty, "txtQty");
			txtQty.BackgroundImage = null;
			txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			txtQty.Font = null;
			txtQty.Name = "txtQty";
			txtQty.TextChanged += new System.EventHandler(txtQty_TextChanged);
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackgroundImage = null;
			base.Controls.Add(saveBtn);
			base.Controls.Add(groupBox5);
			Font = null;
			base.Name = "FrmDiscountPoints";
			base.Load += new System.EventHandler(FrmDiscountPoints_Load);
			groupBox5.ResumeLayout(false);
			groupBox5.PerformLayout();
			ResumeLayout(false);
		}
	}
}
