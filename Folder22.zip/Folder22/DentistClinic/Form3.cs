using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using DentistClinic.Properties;
using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;

namespace DentistClinic
{
	public class Form3 : BaseForm
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		private static Server srvSql;

		public static string Databs;

		private GeneralMethods MethodsClass = new GeneralMethods();

		private string ServerName;

		private string DataBaseName;

		private string UserName;

		private string Pass;

		private IContainer components = null;

		private Button btnRestore;

		private Label label3;

		private ComboBox cmbDatabase;

		private GroupBox groupBox2;

		private Button btnCreate;

		private OpenFileDialog openBackupDialog;

		private SaveFileDialog saveBackupDialog;

		private GroupBox groupBox1;

		private FolderBrowserDialog folderBrowserDialog1;

		public Form3()
		{
			InitializeComponent();
		}

		private void Form3_Load(object sender, EventArgs e)
		{
			try
			{
				ServerConnection serverConnection = new ServerConnection(DentistClinic.Properties.Settings.Default.ServerName);
				Databs = DentistClinic.Properties.Settings.Default.DataBaseName;
				serverConnection.LoginSecure = false;
				serverConnection.Login = DentistClinic.Properties.Settings.Default.UserName;
				serverConnection.Password = DentistClinic.Properties.Settings.Default.Pass;
				srvSql = new Server(serverConnection);
				Databs = DentistClinic.Properties.Settings.Default.DataBaseName;
				ServerName = DentistClinic.Properties.Settings.Default.ServerName;
				DataBaseName = DentistClinic.Properties.Settings.Default.DataBaseName;
				UserName = DentistClinic.Properties.Settings.Default.UserName;
				Pass = DentistClinic.Properties.Settings.Default.Pass;
				foreach (Database database in srvSql.Databases)
				{
					cmbDatabase.Items.Add(database.Name);
				}
				cmbDatabase.Items.Remove("master");
				cmbDatabase.Items.Remove("model");
				cmbDatabase.Items.Remove("msdb");
				cmbDatabase.Items.Remove("tempdb");
			}
			catch
			{
			}
		}

		private void btnConnect_Click(object sender, EventArgs e)
		{
		}

		private void btnCreate_Click(object sender, EventArgs e)
		{
			try
			{
				if (srvSql != null)
				{
					if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
					{
						DentistClinic.Properties.Settings.Default.Filename = folderBrowserDialog1.SelectedPath;
						DentistClinic.Properties.Settings.Default.Save();
						Backup backup = new Backup();
						backup.BackupSetDescription = "ArchiveDataBase:" + DateTime.Now.ToShortDateString();
						backup.BackupSetName = "Archive";
						backup.Action = BackupActionType.Database;
						backup.Database = DataBaseName;
						string name = DentistClinic.Properties.Settings.Default.Filename + "\\EasyClinicBackups" + DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year + "   " + DateTime.Now.Hour + "-" + DateTime.Now.Minute + "-" + DateTime.Now.Second + ".bak";
						BackupDeviceItem item = new BackupDeviceItem(name, DeviceType.File);
						_ = srvSql.Databases[DataBaseName];
						backup.Initialize = true;
						backup.Checksum = true;
						backup.ContinueAfterError = true;
						backup.Devices.Add(item);
						backup.Incremental = false;
						backup.ExpirationDate = DateTime.Now.AddDays(3.0);
						backup.LogTruncation = BackupTruncateLogType.Truncate;
						backup.FormatMedia = false;
						backup.SqlBackup(srvSql);
						MessageBox.Show("Bakup of Database " + DataBaseName + " successfully created", "Server", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						MethodsClass.UserMove("نسخ أحتياطي من قاعدة بيانات ");
					}
				}
				else
				{
					MessageBox.Show("A connection to a SQL server was not established.", "Not Connected to Server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
				MessageBox.Show("no connection");
			}
		}

		private void btnRestore_Click(object sender, EventArgs e)
		{
			try
			{
				if (cmbDatabase.SelectedIndex == -1)
				{
					if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
					{
						MessageBox.Show("Please Choose DataBase");
					}
					else
					{
						MessageBox.Show("من فضلك ادخل قاعدة البيانات");
					}
				}
				else if (srvSql != null)
				{
					if (openBackupDialog.ShowDialog() == DialogResult.OK)
					{
						MethodsClass.UserMove("استرجاع بيانات من قاعدة بيانات ");
						MethodsClass.UserMove("تسجيل خروج ");
						Codes.Backup();
						Restore restore = new Restore();
						restore.Action = RestoreActionType.Database;
						restore.Database = Databs;
						BackupDeviceItem item = new BackupDeviceItem(openBackupDialog.FileName, DeviceType.File);
						restore.Devices.Add(item);
						srvSql.KillAllProcesses(restore.Database);
						restore.ReplaceDatabase = true;
						restore.SqlRestore(srvSql);
						MessageBox.Show("تمت عملية استرجاع بيانات  " + Databs + " بنجاح", "Server", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						Main.RestoreDB = true;
						Application.Restart();
						Application.Exit();
					}
				}
				else if (DentistClinic.Properties.Settings.Default.Language == "en-GB")
				{
					MessageBox.Show("Error in Connection DataBase", "Not Connected to Server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else
				{
					MessageBox.Show("خطأ فى الربط بقاعدة البيانات", "Not Connected to Server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
			}
			catch
			{
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
		}

		private void cmbDatabase_SelectedIndexChanged(object sender, EventArgs e)
		{
			btnCreate.Enabled = true;
			btnRestore.Enabled = true;
		}

		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DentistClinic.Form3));
			btnRestore = new System.Windows.Forms.Button();
			label3 = new System.Windows.Forms.Label();
			cmbDatabase = new System.Windows.Forms.ComboBox();
			groupBox2 = new System.Windows.Forms.GroupBox();
			btnCreate = new System.Windows.Forms.Button();
			openBackupDialog = new System.Windows.Forms.OpenFileDialog();
			saveBackupDialog = new System.Windows.Forms.SaveFileDialog();
			groupBox1 = new System.Windows.Forms.GroupBox();
			folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
			groupBox2.SuspendLayout();
			groupBox1.SuspendLayout();
			SuspendLayout();
			btnRestore.AccessibleDescription = null;
			btnRestore.AccessibleName = null;
			resources.ApplyResources(btnRestore, "btnRestore");
			btnRestore.BackgroundImage = null;
			btnRestore.Font = null;
			btnRestore.Name = "btnRestore";
			btnRestore.UseVisualStyleBackColor = true;
			btnRestore.Click += new System.EventHandler(btnRestore_Click);
			label3.AccessibleDescription = null;
			label3.AccessibleName = null;
			resources.ApplyResources(label3, "label3");
			label3.ForeColor = System.Drawing.Color.Black;
			label3.Name = "label3";
			cmbDatabase.AccessibleDescription = null;
			cmbDatabase.AccessibleName = null;
			resources.ApplyResources(cmbDatabase, "cmbDatabase");
			cmbDatabase.BackgroundImage = null;
			cmbDatabase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			cmbDatabase.Font = null;
			cmbDatabase.FormattingEnabled = true;
			cmbDatabase.Name = "cmbDatabase";
			cmbDatabase.SelectionChangeCommitted += new System.EventHandler(cmbDatabase_SelectedIndexChanged);
			cmbDatabase.SelectedIndexChanged += new System.EventHandler(cmbDatabase_SelectedIndexChanged);
			cmbDatabase.TextChanged += new System.EventHandler(cmbDatabase_SelectedIndexChanged);
			groupBox2.AccessibleDescription = null;
			groupBox2.AccessibleName = null;
			resources.ApplyResources(groupBox2, "groupBox2");
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.BackgroundImage = null;
			groupBox2.Controls.Add(label3);
			groupBox2.Controls.Add(cmbDatabase);
			groupBox2.Controls.Add(btnRestore);
			groupBox2.ForeColor = System.Drawing.Color.Black;
			groupBox2.Name = "groupBox2";
			groupBox2.TabStop = false;
			btnCreate.AccessibleDescription = null;
			btnCreate.AccessibleName = null;
			resources.ApplyResources(btnCreate, "btnCreate");
			btnCreate.BackgroundImage = null;
			btnCreate.Font = null;
			btnCreate.Name = "btnCreate";
			btnCreate.UseVisualStyleBackColor = true;
			btnCreate.Click += new System.EventHandler(btnCreate_Click);
			openBackupDialog.FileName = "Backup.bak";
			resources.ApplyResources(openBackupDialog, "openBackupDialog");
			saveBackupDialog.FileName = "Backup.bak";
			resources.ApplyResources(saveBackupDialog, "saveBackupDialog");
			groupBox1.AccessibleDescription = null;
			groupBox1.AccessibleName = null;
			resources.ApplyResources(groupBox1, "groupBox1");
			groupBox1.BackColor = System.Drawing.Color.Transparent;
			groupBox1.BackgroundImage = null;
			groupBox1.Controls.Add(btnCreate);
			groupBox1.ForeColor = System.Drawing.Color.Black;
			groupBox1.Name = "groupBox1";
			groupBox1.TabStop = false;
			resources.ApplyResources(folderBrowserDialog1, "folderBrowserDialog1");
			base.AccessibleDescription = null;
			base.AccessibleName = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.WhiteSmoke;
			BackgroundImage = null;
			base.Controls.Add(groupBox1);
			base.Controls.Add(groupBox2);
			Font = null;
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Name = "Form3";
			base.Load += new System.EventHandler(Form3_Load);
			base.FormClosed += new System.Windows.Forms.FormClosedEventHandler(Form1_FormClosed);
			groupBox2.ResumeLayout(false);
			groupBox2.PerformLayout();
			groupBox1.ResumeLayout(false);
			ResumeLayout(false);
		}
	}
}
