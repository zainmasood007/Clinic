using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using CrystalDecisions.Windows.Forms;
using DentistClinic.Reports;

namespace DentistClinic
{
	public class FrmGardRpt : ReportBaseForm
	{
		private dataClass Codes = new dataClass(".\\sqlExpress");

		private IContainer components = null;

		private GroupBox groupBox2;

		private CrystalReportViewer crystalReportViewer1;

		private DataSet1 dataSet11;

		public FrmGardRpt()
		{
			InitializeComponent();
		}

		private void FrmGardRpt_Load(object sender, EventArgs e)
		{
			try
			{
				dataSet11.Clear();
				DataTable dataTable = Codes.Search2("SELECT     dbo.Items.Name, dbo.Store.Qnt, dbo.Store.BuyPrice, dbo.Items.SalePrice\r\nFROM         dbo.Items INNER JOIN\r\n                      dbo.Store ON dbo.Items.Id = dbo.Store.ItemId");
				for (int i = 0; i < dataTable.Rows.Count; i++)
				{
					((DataTable)(object)dataSet11.Gard).Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString());
				}
				GardRpt gardRpt = new GardRpt();
				gardRpt.SetDataSource(dataSet11);
				crystalReportViewer1.ReportSource = gardRpt;
			}
			catch
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			groupBox2 = new System.Windows.Forms.GroupBox();
			crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			dataSet11 = new DataSet1();
			groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)dataSet11).BeginInit();
			SuspendLayout();
			groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			groupBox2.BackColor = System.Drawing.Color.Transparent;
			groupBox2.Controls.Add(crystalReportViewer1);
			groupBox2.Location = new System.Drawing.Point(2, 0);
			groupBox2.Name = "groupBox2";
			groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			groupBox2.Size = new System.Drawing.Size(763, 589);
			groupBox2.TabIndex = 5;
			groupBox2.TabStop = false;
			crystalReportViewer1.ActiveViewIndex = -1;
			crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			crystalReportViewer1.DisplayGroupTree = false;
			crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
			crystalReportViewer1.Location = new System.Drawing.Point(3, 16);
			crystalReportViewer1.Name = "crystalReportViewer1";
			crystalReportViewer1.SelectionFormula = "";
			crystalReportViewer1.Size = new System.Drawing.Size(757, 570);
			crystalReportViewer1.TabIndex = 1;
			crystalReportViewer1.ViewTimeSelectionFormula = "";
			dataSet11.DataSetName = "DataSet1";
			dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(767, 591);
			base.Controls.Add(groupBox2);
			base.Location = new System.Drawing.Point(0, 0);
			base.Name = "FrmGardRpt";
			Text = "جرد الأصناف";
			base.Load += new System.EventHandler(FrmGardRpt_Load);
			groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)dataSet11).EndInit();
			ResumeLayout(false);
		}
	}
}
